
Twist1.exe is run in x86 windows.
