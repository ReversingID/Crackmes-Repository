Reversing.Kr CrackMe - WindowsKernel


Please authenticate to lowercase.
