Windows8 MetroStyle App.

Password must be composed of uppercase letter and digit.

By 3735943886
