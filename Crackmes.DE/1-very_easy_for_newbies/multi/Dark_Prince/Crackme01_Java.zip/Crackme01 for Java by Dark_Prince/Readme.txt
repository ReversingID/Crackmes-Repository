p9-Hi, this is my first Crackme!
Rules:
Just find the correct key ,write a solution and submit it to crackmes.de
as it is written in java so JRE must be installed in your machine.
dark_prince
