Objectives:
1. Enable the Verify button (Patching Allowed)
2. Get the secret message and virify if it's correct (Patching not Allowed)

TheMSG by d4rK_r3v3rs3R
for http://www.crackmes.de