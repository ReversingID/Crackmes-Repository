      Readme for Crackme 2 by The FoX
     =================================

 [introduction]__ _
 Welcome to my second crackme. If you'vent yet tried the first one, go
 now get it from my homepages at http://zor.org/cb_

 The first crackme was single-serial only, this time you'll have to face a
 name+serial protection. I don't know about the level, but this is not
 for total newbies (even though serial is easy to sniff once heart of the
 protection is found).

 The crackme is coded in win32asm (compiled with MASM) and is not packed
 nor crypted in any way. I hope you enjoy cracking this little crackme,
 and learn something that you didn't know before.


 [hints]__ _
 Here's a working name+serial pair (not accepted as solution ;-)
   Name: The FoX
   S/N : G5ZV-OFLJ

 If you want to ask about something, feel free to mail me: cb@zapo.net


 [contact]__ _
 My email is, as said: cb@zapo.net
 You can also catch me from IRC, EFNet. My nick is TheFoX.


 [final words (ie. greets)]__ _
 Here's an uncomplete greets list (reverse-alphabetic):

 zwei zebbedi tschenzi sudd sonk1te sn_ sinny ruku prof_x
 pr1mus parab orkim lilith jim3op isit iffi haldir f1reangel
 f0dd esc` dnnuke djf dejavu crudd creak coollege cluesurf
 cdk cali 2ea3

 Sorries out for ones who I forgot.. mail me so I remember you next time ;-)