KeyGenMe-1 by synapse
--------------------------------------
Written in SpAsm 4.15c

Type: KeyGenMe

Protection:
- you'll just have to find out -

Objectives:
- get a valid name/serial
- make a keygen
- make a tut

Rules:
- no patching!

Another crackme written by me... this is just a normal name/serial crackme.. with some twist.. it has some tricks.. but it can be easily beaten.. if you managed to crack it, please make a keygen and a tut.. put it in a zip file and submit to www.crackmes.de... and if you want to, you can send it to me also... happy cracking!

- synapse [markz_a@yahoo.com]