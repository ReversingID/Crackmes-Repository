This is the first crackme I've made
It's not that hard to complete but it can be fun to do

Goal:
	Make a keygen
Rules:
	Don't alter any of the classes in the jar
	Feel free to decompile the jar
Bonus Info:
	The jar is obfuscated
	The serial only consists of letters and numbers