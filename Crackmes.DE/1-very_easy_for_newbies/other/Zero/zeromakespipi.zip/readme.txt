Name         :  ZeroMakesPiPi
Author       :  Zero[REN]
                Zero@Reverse-Engineering.net
                http://www.reverse-engineering.net
Type         :  crackme
Level        :  2/10 or 4/10, depending on RCE knowledge
Coded with   : Visual Studio .NET 2003, VC++ (Without .NET)
Coding Time  : 5 Minutes
Protection   : None, just a simple kind of "serial"
Needed Files : mfc71.dll (1.036 KB), msvcr71.dll (340 KB)


Description:
------------
Well, this is a very small and simple crackme. 
Actually I would place it 2/10 but if you look at the 
produced coded you may agree that this is (maybe) 
a 4/10 crackme. There is no .NET functionality in it,
but it may happen that you need the above mentioned files.

There is no special protection in it, no Anti-Tricks, the file
is not packed.

Your only task is to find the correct serial.
This is a small math calculation, so it may be hard for you
if you are not familar with math problems.


When you are done:
------------------
Submit your solution at http://www.crackmes.de
Do not contact me since it is really not necessary :p
