
==========================================
= Name:    T0_Easy_Crackme_from_^L00P    =
= Coder:   ^L00P                         =
= Cracker: MabeYou :)                    =
= Date:    21.06.2002                    =
==========================================


Intro.

 Another Wery Simple Crackme.


Level.

 To_Hard_To_You. 

 :)


You Need To:

 Make A KeyGen.


Allowed:

 All.
 Patching IS all0wed. But Your KeyGen MUST work for unpached Crackme

:)


Protection.

 It is maked In 100% ASM, so It wiLL be wery easy.
 Some Easter bug...  You WILLL see... :)
 Serial Check Routine is wery easy... And popular In some Kind... 
 Crack It, Key gen It, Have Fun, Drink A beer, Think A bit, And then You will see 
 Where I have got This SerialCheckRoutine, hmm, Forgot to say Keygening is REALY Easy

 :D



Outro.

 If You are Succesfuly maked a keygen, and Writted a Short Tutorial, 
 then send all this to: rel00p@yahoo.com
 You can trie to catch in efnet in chan #C4N or #REA (I am NOT wery offten in the chat :(




			...: EndOfReadMe      :...
			...: rel00p@yahoo.com :...
 			...: ^L00P .:. 2002   :...