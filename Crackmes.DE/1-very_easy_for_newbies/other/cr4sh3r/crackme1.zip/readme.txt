Wicked crackme v1.0 by LaFarge
#######################################

Hello!

This is a simple little crackme for newbies!

I coded it like in... 1 minute! Pure assembler!

Rules:

- U must make the nag messagebox desapear!
- U must make the right message to show!
- No jumps reversing


Goals:

- Read the rules
- Make a working loader
- Make a working patch

That's it!

Get on with it!