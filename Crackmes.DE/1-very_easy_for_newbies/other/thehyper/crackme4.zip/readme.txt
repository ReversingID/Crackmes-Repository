level 0+ 
========

another easy crackme

rulez
=====

1. pls no code patching.
2. just patch the bad serial to get the good guy message

the good guy message is "Brilliant!!"

thehyper
