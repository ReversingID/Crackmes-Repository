===================================================
Program name: CrackMe #2 by DaKneeMan_native.zip
Author:             DaKneeMan
CrackMe date: 24 April 2004
Type:                Name - Serial
URL:                http://www.crackmes.de
===================================================


This is my SECOND CRACKME (native).


I think it's very easy; anyway you rate it.


Rules: NO patch.
          NO sniff.
          ONLY KEYGEN!!!



Greets,
DaKneeMan