===================================================
Program name: CrackMe #2 by DaKneeMan.exe
Author:             DaKneeMan
CrackMe date: 23 April 2004
Type:                Name - Serial
URL:                http://www.crackmes.de
===================================================


This is my SECOND CRACKME.


I think it's very easy; anyway you rate it.


Rules: NO patch.
          NO sniff.
          ONLY KEYGEN!!!



Greets,
DaKneeMan