=============================
**     Sghetti Crackme     **
**          NO. 3          **
=============================

Instructions
------------
You have two crackmes this time.  Nothing real special just my first one after
an extremely long break.  Find the serial and/or the Username/Password combo.
Real basic stuff, noobs just get this one fairly quickly.



Contact: sghetti@sbcglobal.net
