Hey there pplz...
This is FireWorx and this is my 13:th crackme...

WeLL, uuuhm, i�m very tired now... cuz i just got back from work so well, i�m gonna take this fast so i can go to bed soon =)))

======
RULEZ!
======

No rulez, just to get a real serial...
I haven�t got my sice working now so i dunno how hard it is to crack!!!
Well, if u want do a keygen for it...
Very simple =)
Just a small reg proc..
could have sat all night to make it a bitch to keygen =) haha
well, if u got a real serial or did a keygen:!
send it to:
FireWorx@as-if.com
or aveny@hotmail.com
I�ll be pleased to get the source code of the keygen.

========
GREETS!!
========
Acid_BuRN!! PhoX ( away very long now =( ), DNNuke, TeChNiCh, Mister.E, Hac, Zappelin and all swedes on IRC!!! Well, greets to everyone in dF ':-_-:'

======
=HATE=        Tirre, That lame punk as bitch!!! FUCK YOU WHORE!!!!
======

===
URL
===
Http://surf.to/FireWorx
Email: Aveny@hotmail.com
 