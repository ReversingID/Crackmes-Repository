09/27/01

Hello!

This is TMG Official Trial Keygenme No.4 If you would like
to join our team or are just bored, take some time and code
a keygenerator for it.

Then you might want to contact us under tmgfreaks@softhome.net
or visit us on IRC (Efnet, channel #tmg2001).

Don't email or contact us for questions related to this
Keygenme. We won't give out any info - you have to make
it yourself this time.

But be warned. This one is nothing for newbies or just
average crackers. If you are an experienced reverser
and found out what's going on in the code, it's no
big deal to finish the keygen but if you are not.....

Good luck,


tE!
