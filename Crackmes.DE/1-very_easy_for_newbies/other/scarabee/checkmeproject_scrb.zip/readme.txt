'The Checkme Project'

This small crackme was intensionally coded for a friend of mine who wanted to have an easy exercise target for SMARTCHECK. 
As it turned out i think it is rather educational, so i decided to put it out in public ;-)

The crackme consists of 3 parts:

1st part: 
Hardcoded serial. Basic checking, so just find the password.

2nd part: 
Little more difficult, but still hardcoded. Same rule, just find the serial.

3rd part:
Easy name/serial check. Find a valid serial for your name, and explain how the algorythme works. If you feel like it, convert it into a keygen, as it is very easy.

If you finish all the parts, you should be able to understand the basics of smartcheck.

The only rule:

-> ONLY use Smartcheck. No other tools allowed!

Greetings to _RiPTiDE_ , _PUSHER_ and all who share this interest!
Happy checking!!

Send solutions, or whatever to:

scarabee_5@hotmail.com



