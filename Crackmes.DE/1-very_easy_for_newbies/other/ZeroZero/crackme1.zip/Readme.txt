ZeroZero Crackme#1 .:VB:.
Release Date: 2nd February 2004
--------------------------------

Ok, this is my first crackme, and:

1) It's coded in visual basic
2) No anti-SICE, anti-SmartCheck, ... No fucking shit. This Crackme is for newbies, to learn patching visual basic apps.

Rules/Notes:
1) Remove 1st Nag-Screen
2) Enable the button
3) Change 'Unregistered' Status for 'Registered'
4) Remove messagebox (Nag-2)

Well, as you see, its no Keygen, name serial ( sorry for users of SmartCheck ;p ), etc. You only should patch it. if you suceeded in cracking, Send Tuotorial.

Cracking this Crackme, you will learn(if you dont know) to killing nags, enable button, and changing text in VB Applications. I hope you'll learn. If you cant crack this, you'll learn with the future solution.

Enjoy!. Hope you learn something.
Note: i think this crackme level is 1 (1-10), because Nags, change text, and enable button are not difficult.

Comments, questions, donations: zerohutsa@hotmail.com

Greetz to Acid cool 178.
Thanx for download this Crackme.
