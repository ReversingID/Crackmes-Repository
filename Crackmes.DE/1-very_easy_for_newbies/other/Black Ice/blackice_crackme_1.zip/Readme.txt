


				BlackIce CRACKME #1
				(i don't have any fancy ascii stuff :(  oh well)

Name: BlackIce Crackme #1
Targets: Enable the 'CHECK' button, Get the correct serial for your name/nick

Rules: none really, Try to make a keylogger before resorting to patching

Comments: This is the first crackme i have made, so i not really sure how gd it is. I can crack it and i am a nOOb but then again i wrote it :P
Written in vb6 compilled into NATIVE code