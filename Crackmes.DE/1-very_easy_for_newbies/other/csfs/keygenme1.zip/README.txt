CSFS - Cackmes4Beginners -  KEygenme1

- Notes -
Find Out A VAlid Serial For 
Your Name But Remember Dont Always Look In The EAX Register.

- Rules -

NO PATCHING ALLOWED 

1. FIND A VALID SERIAL FOR YOUR NAME.
2. MAKE A KEYGEN AND SEND IT AND THE SOURCE CODE FOR IT TO CSFS4@HOTMAIL.COM
3. TRY TO MAKE THE KEYGEN IN VISUAL VASIC OR DELPHI

- THANKS :-) - 

kEYGEN MADE BY CSFS

