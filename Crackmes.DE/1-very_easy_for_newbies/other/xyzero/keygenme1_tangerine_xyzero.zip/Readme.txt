===================================================
Program	: KeygenMe #1 for Newbies - Tangerine
Level	: 1 (newbie)
Author 	: xyzero
Date	: 20.02.2004
Type    : Name/Serial
URL     : http://www.crackmes.de
===================================================

This is a simple C keygenme for newbies.
It�s easy => just code analysis ;-)
(you can check the correct serial @ 401262 :-)


Rulez:

(1) Make a keygen and write a tutorial.
(2) No patching. No keygen injection. "no killing moths or putting boiling water on the ants"...
(3) Enjoy!


===================================================



xyzero - xyzero@bol.com.br - www.reversor.tk

If you want send me the keygen! It�s FREE ;-)
(msn): xyzero@hotmail.com