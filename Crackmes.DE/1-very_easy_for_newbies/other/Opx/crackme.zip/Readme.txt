Hi there, .....
Lets try my CRACKME1.COM

Rulez : - guess my password
        - No patching and no Hex-edit
        - recommended for beginner

Opx