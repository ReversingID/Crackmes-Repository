hello everyone

here comes a crackme made by a friend of mine.
it is a keyfile based protection.
The aim of the crackme , is to code a Keymaker..
But it won't be that easy, i promise :)

the analyst,

www.Keygenning4newbies.cjb.net
www.oldreverser.cjb.net
