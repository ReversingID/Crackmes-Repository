	Hello everybody!!
Here is bLaCk-eye.
This is my first Crackme so it is verrrrry easy (y think so)
The ideeaa camed to me......
What the fuck just crack it if u can and send me a tut at mycherynos@yahoo.com
All tools and methods are allowed so crack it
One tip:Y made it in asm in about 10
Pretty fast ain't?

