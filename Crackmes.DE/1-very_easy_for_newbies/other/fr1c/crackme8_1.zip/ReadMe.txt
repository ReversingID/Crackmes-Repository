Yo!
This is my first CrackMe in VC++, so dont be mad if you find bugs :))
Ok, mission is to code a working keygenerator.
If you are not keygen machine :), find a serial for your name.
I think that's very easy.

I did not included ANTI-SOFTICE protection.
If you wanna try that protection, try my crackme #7.

You will see that exe file is packed.That's all.
Ok,i wish you good luck.

Contact me if you try this crackme.
(i wanna know where is my crackme).
thanks!

URL : www.fr1c.cjb.net
E-mail : Fr1cCracker@inet.hr

NC OFFICIAL SITE : www.kickme.to/NC
