	Welcome to my CrackMe number 6!
	Yeah..but , finally this is little more harder.
You need to remove nag , enable check key button,find real key (no patching) and if you can make keygen.
If you do something of those things , mail me at franjo@tmp.hr!

Made by Fr1c!
ICQ UIN: 14419920
E-mail: franjo@tmp.hr

You can find me on IRC at : #cracking4newbies , #digital.factory , #campercrew.

I'm member in dF and TCC.