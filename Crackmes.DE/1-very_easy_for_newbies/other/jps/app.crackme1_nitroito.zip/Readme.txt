wellcome to my 1st crackme

all you have to do is:

 1. Remove the NAG screen...
 2. Find a correct serial or create a keygen
    (NO PATCH) is to easy to patch... ]:)

it is a litle bit hardcoded, if you have patience 
for mathematics algoritms, it is your pleasure

see help on crackme for details...

for those guys who loves win32asm, this crackme was 
pure coded in Borland Delphi v6, it is a good example 
that it is possible to code small size progys with 
those kind of programing languages :]

_______________________________
Nitroito - Nitroito@hotmail.com
26-02-2004
