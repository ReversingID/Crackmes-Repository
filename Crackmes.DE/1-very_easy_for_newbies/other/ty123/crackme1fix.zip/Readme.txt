Update
------

May 1st, 2004
-- Fixed a bug (Crackme1 is not working when a long volume name is set).


Hi all!

This is my first crackme and it is for newbie.

No patch for this application is allowed.

Feel free to contact me via email.

----
ty123
ty123@18en.com