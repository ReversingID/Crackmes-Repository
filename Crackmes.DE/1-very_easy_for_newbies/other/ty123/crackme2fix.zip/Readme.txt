Update
------

May 1st, 2004
-- Fixed a bug (Crackme2 is not working when a long volume name is set).


Hi all!

This is my second crackme coded in win32asm and it is for newbie too.

You have to code a working serial number. A string "Congratulations!" will be shown at bottom with a valid serial number. Good luck!

No patch for this application is allowed.

Feel free to contact me via email.

----
ty123
ty123@18en.com