 .: FuzzyCAT's CrackMe #2 :.

Rate:  1-10
Tell me what u think.

@Goal:
1�Goal
!Remove the time limit, the prog closes after some time...
!Register it, make the prog accept you're registration
2�Goal
!Find the correct combination...

@Comments:
Files: CrackMe#2e.exe  -> it's easier, because it shows a messagebox
       CrackMe#2h.exe  -> harde it only shows a messagebox when u succeed

 It's my 2� CrackMe, the 1� was coded in VB and maybe easier,
yes for sure easier! ;)
 This one was based on Duelist CrackMe #3, u rokx!!
 [ Basta dizer que �s portugu�s!!! :) ]

Well lets hope not too long for my #3, already thinking in it...
Maybe i'll code it in ASM (Win32), but thats maybe :)

If achieved the 1� or the 2� goal or both, email me:
 -> FuzzyCAT@gmx.net <-

I cant say anything because i didnt cracked it yet...



@Greetz:  (no special order)
iNNU3Do :: Duelist :: DYCUS :: hmemcpy :: Northpole :: tKC :: LaZaRus
R!SC :: Prof.X :: PinguTM :: AgentData :: NU|<EM :: tKC :: AsmCoded
DarkShadow :: SiR_DawG :: PeeWee :: bm[tfgx] :: And all my friends!
-(if u should be here email me!)-
!-!
FuzzyCat@gmx.net
www.FuzzyCat.tsx.org  ||  FuzzyCat.virtualave.net