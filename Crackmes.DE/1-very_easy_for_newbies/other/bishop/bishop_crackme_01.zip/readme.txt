BiSHoP's VB Crackme#1

Protection:
Serial

Your goal:
Make a keygenerator

Send it to diablo337@hotmail.com and tell me
how you cracked.


About...
This crackme was made in VB4.
I only spend a few minutes coding it so I assume
it will be very easy for advanced VB crackers to
crack, but it might be difficult for newbies
considering that it is compiled to P-code and if
you try to disassemble it, no SDR is available.
Patching it would be lame, your goal is to make
a key generator.
The only alternative I see is to use Softice and
trace through the whole process.  Please correct
me if I am wrong!
BTW:  You need the vb4 runtime files to run this!
-BiSHoP