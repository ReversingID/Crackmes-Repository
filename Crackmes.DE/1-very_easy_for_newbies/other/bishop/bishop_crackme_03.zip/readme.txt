BiSHoP's VB Crackme#3

Protection:
Serial

Your goal:
Serial is easy to get, but if you want a challenge
make a key generator for it, GOOD LUCK :)

If you cracked it,
send your solution to diablo337@hotmail.com
and include a tutorial or description on how
you cracked it.


About...
Another lame crackme made in VB4.
This one includes a function which changes
ASCII characters and will be quite a challenge
for newbies.
-BiSHoP