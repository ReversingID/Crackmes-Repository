Hi folks ;)


This is my first crackme :)

And I make it in VB .Net , I know it's easy , but it's new for me !

Rules:
======

Any tools + any methods .



Please send to me a copy of the Tutorial when you're done ;)





Good luck,
HACKERGY