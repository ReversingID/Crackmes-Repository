1_ Find the correct serial for your name.
2_ Patch the crackme to accept all serial and cd-key.
3_ Make a keygenerator.
4_ Make an autokeygenerator.

When you crack it, send me the solution!!!!

If you fail or want to ask me something just mail me!

AttilhaZ
attilhaz@yahoo.it