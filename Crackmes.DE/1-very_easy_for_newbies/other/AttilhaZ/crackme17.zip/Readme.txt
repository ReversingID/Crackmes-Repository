Pass the Cd-Check protection.

You must crack first without patching, and then patching to accept all cd.

When you crack it, send me the solution!!!!

If you fail or want to ask me something just mail me!

AttilhaZ
attilhaz@yahoo.it