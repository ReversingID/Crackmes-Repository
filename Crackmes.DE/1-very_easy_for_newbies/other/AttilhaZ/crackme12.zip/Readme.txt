Register it without patching. This crackme use a keyfile.

When you crack it, send me the solution!!!!

If you fail or want to ask me something just mail me!

AttilhaZ
attilhaz@yahoo.it