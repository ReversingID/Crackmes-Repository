obviously the goal is to make a keyfile generator,
so no patches please.

get bonus points for a generic keyfile :)

    crp-

