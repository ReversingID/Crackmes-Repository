                ---====  Crackme v2.0 By Cyclops  ====---


Hi
  This is my second crackme.
  Its a Dos crackme with serial protection.
  I used some mathematical calculations to find serial.
  It is fairly simple to crack.
  send me your keygen to cyclops@omnilect.com


       Happy cracking & happy New Year 2005.
  