_khAttAm_'s What is my Password (WIMP) v4
-----------------------------------------

Unlike my last 3 three crackmes (WIMP 1, 2 and 3), the protection here is quite weak. I'll rate it as VERY EASY (2-3) ......... 

This is for absolute newbies............

No patching, a valid password/serial is required.

Best of luck, :)

ENJ0Y!! 

PS: This crackme is for absolute DOS mode. However, it runs in Windows environment, it may not under XP, if you have Ntfs. To run it under XP with Ntfs, you will need to  copy it to the root directory or a directory in the root directory with no long filename.