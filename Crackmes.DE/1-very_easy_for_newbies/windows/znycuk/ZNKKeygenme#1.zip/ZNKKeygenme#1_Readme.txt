Hi all,

This is my first Keygenme, written in ASM.

_ Find the solution
_ make a keygen
_ And submit a tuto

tested on WinXP SP2 but should work on SP1 and Win2K.

Good work !

Znycuk