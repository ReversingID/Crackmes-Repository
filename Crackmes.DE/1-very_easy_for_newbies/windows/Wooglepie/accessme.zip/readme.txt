Wooglepies' AccessME 1
Level: 2/10

In order to crack this one you'll have to find the correct
username/passwords to an account. Patching in order to make it
display a successful login session is NOT allowed.

Good luck.