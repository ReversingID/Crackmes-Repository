|UTW KeyGenMe v3|
-----------------

- Written by otromasf
- More hard that UTW KeyGenMe

Target:

- Make a keygen
- No patching allowed
- Write a tutorial

Good luck!