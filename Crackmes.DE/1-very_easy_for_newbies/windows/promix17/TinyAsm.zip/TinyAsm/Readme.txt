TinyAsm by Promix17
Level of dufficulty: 0

I've recently found my first crackme which was 
written in asm. A lot of memories have came...

The purpose is to find correct password
 
Good luck)))

E-mail: promix17@yandex.ru