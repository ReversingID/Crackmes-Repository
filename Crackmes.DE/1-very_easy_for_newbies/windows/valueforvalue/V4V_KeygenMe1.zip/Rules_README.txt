No patching is allowed, write a keygen it wont be hard. 
This is a beginner level keygen me no tricks or anti-debug.
Have fun. If you write a keygen sent it to me and I'll send you the source password.

valueforvalue76(at)gmail(dot)com