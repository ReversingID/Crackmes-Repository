Trope's CrackMe1
12/2004


This is my first of many. As I progress in my reversing skills, I will also code crackmes that will challenge me as I go along.

At this point, I am here - at this crackme.

RULES: No patching. Find correct serial(s)

VNF - Very Newbie Friendly.

See ya,
Trope
Solutions to webdevia@yahoo.com