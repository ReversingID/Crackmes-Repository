The purpose of this crackme is to get rid of the jump obfuscation. The code has been reversed and your job is to build a tool which gets rid of the jumps and re-orders the code back into it's proper order.In the proper order, I mean that the retn should be at the end of the code block instead of the beginning.


