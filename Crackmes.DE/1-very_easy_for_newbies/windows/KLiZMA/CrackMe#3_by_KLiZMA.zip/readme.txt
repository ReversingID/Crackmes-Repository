Hey!

KLiZMA wrote another crackme!
Run it and read rulz...
Solve it and make tutorial with keygen!
I know you can do it!


From RuSSiA with love... KLiZMA