Crackme Delphi 1.0 by Defc0n1.exe

Is a very very simple Crackme. I have done it and you neednt an amazing knowledge to solve it. I did it with OllyDbg, you would had it with no more than 5 clicks ;)

I wish you to enjoy.

Mail me at defc0n1@el-hacker.org