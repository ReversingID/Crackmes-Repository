Crackme Delphi 2.0 by Defc0n1.exe

Is more complex than the 1� version. It have a couple of mathematical operations, and i have add an username too. The username is so simple to see, but the password is more complex.

When you will have the solution, you will see the real files in the CIA computers =P (its a joke, obviuously)

I wish you to enjoy.

Mail me at defc0n1@el-hacker.org