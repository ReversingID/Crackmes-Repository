Find the valid serial(s). 
Good luck :)

Tested on windows XP only!

You might need this:
http://java.sun.com/j2se/1.4.2/download.html