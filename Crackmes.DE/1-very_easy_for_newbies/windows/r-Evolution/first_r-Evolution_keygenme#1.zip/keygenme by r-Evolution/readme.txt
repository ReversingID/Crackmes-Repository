Well this is our first crackme it's easy and not packed i suppose you won't have problems on cracking it.

Rulez:

No patching ----> so so easy
no selfkeygening ----->i like it but i prefer writting your own keygen
keygen ---> written on your favorite programming language

enjoy the cracking!!!!!
