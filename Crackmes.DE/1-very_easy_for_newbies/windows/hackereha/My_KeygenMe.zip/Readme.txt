Hi again:) again with u another mofo:P this time it's keygenme it is really simple and keygennable:P

Rules
1)No patching at all!
2)Since it's for newbies send a full solution and keygen!
3)Good luck maybe it will be ur first keygen:) (i hope so:))

regards hackereh@:)