this is a my first and very simple keygenme 
i write in assembly language
so i hope newbie like myself to RE enjoy it ;)

the goal is writing a keygen
serial not unique, it's mean every 
user have more than one correct serial

BlZbB