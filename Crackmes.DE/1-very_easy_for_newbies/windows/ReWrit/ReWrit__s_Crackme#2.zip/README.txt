
ReWrit's Crackme#2



This is my second Crackme, i hope its a bit harden then
the first one. =P
---------------


patch it so the correct password will
be visible (check the picture in zip file)
and upload a solution.


name:		ReWrit's Crackme#2
Difficulty:	1 - Very easy, for newbies
platform:	Windows
Language:	C/C++