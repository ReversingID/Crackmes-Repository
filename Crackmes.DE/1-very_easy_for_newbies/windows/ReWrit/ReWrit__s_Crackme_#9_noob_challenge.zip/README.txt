ReWrit's Crackme #9 .NET Noob Challenge

This crackme is dedicated to beginners
for .NET cracking. It has 5 parts:

  Part 1: Serial Fishing
  Part 2: Serial Fishing
  Part 3: Keygening
  Part 4: Serial Fishing and patching
  Part 5: Keygening and patching

Rules:
------------------------------------
Do not patch so other parts are
open, you have to get the password
for every part to unlock the next
one.
Dont patch the nag, you remove it
with the correct password.
------------------------------------

Name:		ReWrit's Crackme #9 .NET Noob Challenge
Difficulty:     1 - Very easy, for newbies
Platform:	Windows
Language:	.NET