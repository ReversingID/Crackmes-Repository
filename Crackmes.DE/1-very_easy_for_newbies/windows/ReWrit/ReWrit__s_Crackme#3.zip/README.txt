
ReWrit's Crackme #3

This one is probably as easy as:
ReWrit's Crackme #1
ReWrit's Crackme #2
...

well i dont know, leave a comment and say what
you think about this one. :)

-----------------------
  Rules:
* Make a keygen or self-keygen.
* Patch it so you allways get Good boy message.
* Upload a solution.
-----------------------

Name:		ReWrit's Crackme #3
Difficulty:	1 - Very easy, for newbies
Platform:	Windows
Language:	C/C++