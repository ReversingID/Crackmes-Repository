
ReWrit's Crackme #10

I Guess this crackme is pretty easy
but give it a try =)

Rules:
-------------------------------
* Only Keygens will be allowed
  (No Self-Keygen!)
-------------------------------

Name:		ReWrit's Crackme #10
Difficulty:	1 - Very easy, for newbies
Platform:	Windows
Language:	C/C++