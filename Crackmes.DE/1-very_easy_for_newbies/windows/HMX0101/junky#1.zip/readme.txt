==================
HMX0101's Junky #1
==================

This my new crackme with a
simple password protection
and packed with UPX.

To beat this crackme, you need:
	
	- Unpack it!
	- Find the correct passwords.
	- Write a tutorial

Rules:

	- Patching is not allowed!

==========
Greets to:
==========

ScR1pT_, Ank83, KLiZMA, Kerberos, R.E.M, 
CracksLatinos, and all members in crackmes.de

===============
Regards,
HMX0101 / R.E.M
===============