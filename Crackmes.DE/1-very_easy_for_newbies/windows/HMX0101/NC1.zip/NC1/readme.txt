Newbie Challenge #1 by HMX0101

Again me :)
This time, i'll be making a small series of crackmes
for newcomers to this interesting world :)

This one is easy.. or at least that was my intention..
Sorry if its too hard :P

This series will give you some reversing skills! :)

Prerequisites:
	- The cracker needs to know basics of ASM (this is a must!)
	- Math knowledge (if you know +,-,* and /, then you've this one! :)
	- A bit of Luck.. (well, this isn't hardly required.. but it will help you too :D)
	- Be good with girls/boys... optional.. hehe :P

The rules!
	- Find the password.. without using bruteforce!
	- Don't patch
	- DON'T BRUTEFORCE! (its just to make clear :D)

Enjoy!