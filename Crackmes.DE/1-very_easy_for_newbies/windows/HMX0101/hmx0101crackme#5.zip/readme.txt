HMX0101's Crackme #5
====================

Goals:
------

1. Change the variable to pass the 1st test (decimal)
2. Change the variable to pass the 2nd test (hexadecimal)
3. Create a file to pass the 3rd test
4. Change a boolean variable to pass the 4th test

Rules:
------

No rules !

Hint:
-----

- Some strings is encrypted!
- The boolean variable not is true or false!

=============
HMX0101/R.E.M