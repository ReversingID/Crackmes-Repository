=====================
HMX0101's Secretme #2
=====================

This is my new crackme with a
easy algorithm but a little bit long :D

To beat this crackme, you need:
	
	- Unpack it!
	- Try to make it works in your computer
	- Make a keygen/patch to insert your data
	  inside the crackme to register the crackme
	- Write a tutorial

Rules:

	- Patching the goodboy jump is not allowed.

==========
Greets to:
==========

TWiST, dila, moofy, ScR1pT_, Ank83, KLiZMA, Kerberos, 
R.E.M, CracksLatinos, and all members in crackmes.de

===============
Regards,
HMX0101 / R.E.M
===============