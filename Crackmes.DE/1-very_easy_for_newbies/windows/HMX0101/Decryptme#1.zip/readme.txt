======================
HMX0101's DecryptMe #1
======================

This is my new crackme with a
simple xor encrypted message.


To beat this crackme, you need:
	
	- Analyze the algo
	- Reverse the algo
	- Decrypt the goodboy message.
	- Write a tutorial

Rules:

	- Patching is not allowed.

==========
Greets to:
==========

Linden, _khAttAm_, l0calh0st, Ox87k, Ank83, TWiST, dila, moofy, ScR1pT_, 
KLiZMA, Kerberos, R.E.M, CracksLatinos, and all members in crackmes.de

===============
Regards,
HMX0101 / R.E.M
===============