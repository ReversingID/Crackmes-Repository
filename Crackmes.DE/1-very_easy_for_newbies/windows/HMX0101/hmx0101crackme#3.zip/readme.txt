This is my third crackme,
its very easy (i think!).

The rules are:
 - NO PATCHING !!!
 - NO SELFKEYGENNING !!!

The goals are:
 - Remove the nag !!!
 - Make a keygen
 - Write a tutorial

Created by HMX0101,
please submit the solutions on crackmes.de