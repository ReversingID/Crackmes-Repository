Crackme in assembly! by qHF
Level: 1 easy, for newbies
Built with NASM 1/25/2010

Acceptable Solutions:
Loader
Serial Fisher (the program gets the serial out of the crackme)
Keygen

Non Acceptable Solutions:
Just serial fishing your own serial
Patch
Anything else not in the list of acceptable solutions

Shouldn't be too hard at all...
my first program in assembly :P
Source on request
sorry if my coding is sloppy :)