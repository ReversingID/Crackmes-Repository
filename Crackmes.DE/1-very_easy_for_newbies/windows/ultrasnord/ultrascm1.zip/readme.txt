ultras's 1st crackme
=====================
Size		: 377 kb
Code		: Borland Delphi 7
Difficulty 	: 3

You Have To Enabled the serial text box,,,
(by following the program rule or reverse it),,,
Then find the correct serial and/or make the keygen,,,

This is my 1st crackme,,,
so if you found any bug or want to give some suggestion,,
or you want to ask me,,
just email me at :

ultras_muhsin@yahoo.co.id

= sorry for my bad english =





  

       