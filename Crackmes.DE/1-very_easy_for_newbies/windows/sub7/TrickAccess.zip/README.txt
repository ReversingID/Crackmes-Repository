Make A Crack / Keygen To Find The Secret Message :p

PWNED!!

Dis Is Prolly Easy... I dunno you guys tell me!