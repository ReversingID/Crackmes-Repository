Hello

My second Crackme A little bit harder than the first. FInd the password, make a gerator, and explain how do you solve it. :) 

..Enjoy cracking :).



Http://PinoyRakista.Tk