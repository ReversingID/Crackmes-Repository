Rules:

*Enable The Register Button.
*Get Rid of the 'Little fucker'
*Make the program accept any Serial... 
*Make an Message saying 'Right Serial'
*Remove the Error saying 'Wrong Serial'

That's all....