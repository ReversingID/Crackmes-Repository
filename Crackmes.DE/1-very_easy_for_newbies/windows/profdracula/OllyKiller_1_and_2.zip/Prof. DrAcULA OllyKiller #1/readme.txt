> This app does'nt let itself be debugged in Olly.
> You have to crack its protection so that it'll run in Olly.
> Enjoy!

                : Prof. DrAcULA
