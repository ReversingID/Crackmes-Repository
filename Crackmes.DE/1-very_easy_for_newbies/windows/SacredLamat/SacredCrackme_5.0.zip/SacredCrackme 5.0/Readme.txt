                                                                                                    
                                                                                                    
                                                                    . BBB7                SM rBM..7 
    Z;7MMMM rM8 M          8M iMMM    . Z0MM                  MM M    MMW  rM@   Mi:M   MMMMMMMMZ   
   MMMMMMMM    MMM     MMMMMM ZMM MM  M2  S@  M0 Z2Mi   MMM ;   MMM   MM2  MMW .   MMM W; @M        
   MMMM      aMM     SMMMMMMM  MM  MM  M      MM   0MM. MMMMM ;MM  7  M M WMMr   MMM       M        
    @MMMMMMM MMa MMMMMM,       MM 2M   M WM    MX i  MM MM@   BMW MM02M MMM8MM   MM, MMMZ  MW       
         MMM,MMXZ M  MM2     2 MM MM   MM8ri@MXMM    MM :M    MMrZ 0 MM MM,  MM  MM22 M    MZ       
       MMM  MMB   ;i   MMMaM;  MM   MB MMMMMM  XM   iW  iM   MMS    MMB  M    MMMMX   a    M        
    8MM    aMM     a     :B    MM    rS r;     ZMM8      MM WMMMMB  .          7Ma     a            
                                ;               ,        MMMMMMMr                                   
                               

-------------------------------SACREDLAMAT'S SacredCrackme 5.0------------------------------------
|                                    							         |
|  Find the correct serial for your name. Please don't patch. That's it!                         |
|                                    							         |
|  Have a nice day and enjoy!                                                                    | 
|                                    							         |
------------------------------------------=*o0o*=-------------------------------------------------