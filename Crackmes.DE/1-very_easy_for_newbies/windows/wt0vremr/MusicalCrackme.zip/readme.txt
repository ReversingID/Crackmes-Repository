===========================
Musical Crackme by wt0vremr
===========================

===========================
Difficulty:
 - Very Very Easy
===========================
Objective:
 - Find a valid
 - Make a keygen
 - Write a tutorial
===========================
Rules:
 - No patchng
 - No debugging
===========================
wt0vremr@gmail.com

