|-----------------------------
| EnableME#1 by EvOlUtIoN
|-----------------------------

This is my first crackme and i think it is very simple to solve.

Target: find the correct way to enable the button and patch the program.
Difficulty: 1/10 or 2/10
Language: Visual Basic 6.0
Packer: Not packed

Regards,

EvOlUtIoN