Greetings crackmes.de,

This time no real cryptanalysis involved.

All you have to do, find the pass :)

Enjoy,

-ksydfius