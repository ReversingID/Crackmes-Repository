================
- SimpleCiph3r -
- by: ksydfius -
================

Hello crackmes.de,

There isn't really much to say... you are given a simple cipher and you have
to break it.

Be careful, I have added just a tiny little anti-debugging in there, but it
shouldn't be a problem to bypass :)

Have fun,

-ksydfius

