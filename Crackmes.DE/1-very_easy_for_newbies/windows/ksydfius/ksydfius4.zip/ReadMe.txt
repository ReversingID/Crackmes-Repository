================
- Ksydfius-128 -
- by  ksydfius -
================

IMPORTANT: Please do NOT use this for your own security purposes, this is easily
broken, very weak hashing algorithm

Ksydfius-128 is a dumb 128-bit hashing algorithm designed by ksydfius that hashes
any input string

This time I implemented it in .NET so you can decompile and see the source and how
this algorithm works.

Of course I could have done it in assembly or VB to make it harder, but where's
the fun in that? :P

=======
- FAQ -
=======
Q: Is the algorithm reversible?
A: No, it is a hashing algorithm, so there will be multiple inputs that generate
   the same hash

Q: Is this a well-known algorithm (like MD5, SHA1, etc.) ?
A: No it is not, it is Ksydfius-128 which offers practically no security

Q: What is my goal?
A: Your goal is to simply find a string that generates the correct hash. You DO NOT
   have to find the original string.

Q: Can I brute-force the hash?
A: Well the text I have that generates the hash is too long to brute force

Q: Can I dictionary attack the hash?
A: Get a list with unprintable chars if you want to dictionary attack :)

Q: Why is the hash that my hash is being compared to so weird...?
A: That's not important, I just picked a random hash and chose that one

Q: Do I have to write code to find the string?
A: I did it by hand, so no coding necessary

Q: Your hashing algorithm sucks! Could you have made it harder?
A: Sure, wait for Ksydfius-256 :)

=============================

Have fun :)

-ksydfius

