=====================
- The XOR Algorithm -
- Coded by ksydfius -
=====================

Hello crackmes.de community,

This is a little program which in order to be cracked needs u
to do some cryptanalysis. Should be a nice little warmup for
my next few crypto ones :)

please dont expect this to be too hard, and dont try bruting the key ofc :)
because... i think that

115792089237316195423570985008687907853269984665640564039457584007913129639936

possibilities are too many !

have fun and enjoy !!!

-ksydfius

