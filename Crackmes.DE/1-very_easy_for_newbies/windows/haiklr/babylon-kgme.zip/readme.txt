_________________________________________

[x] [x] Babylon Keygenme [x] [x]
			README.TXT
_________________________________________

Hello !

Un petit keygenme ultra simple, mais qui j'esp�re en occupera quand m�me certain(e)s un petit bout de temps !
Le but n'est �videmment pas de proposer un couple nom/serial valide (le crackme est torch� en 2 min sinon !), mais de comprendre l'algo et de coder un keygen :]

Type : Keygenme
Level : Newbie
Langage : C (console)
Packed : Non

J'esp�re que quelques solutions/tutos/keygens verront le jour ! Merci de me les envoyer par MP ou par mail !

Bonne chance :]

haiklr - 28 mars 2006
	[klr63@hotmail.com - http://haiklr.new.fr]
