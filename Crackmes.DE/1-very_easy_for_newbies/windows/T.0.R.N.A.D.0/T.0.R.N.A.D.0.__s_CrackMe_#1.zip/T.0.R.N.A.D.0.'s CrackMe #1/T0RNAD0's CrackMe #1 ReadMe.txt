
>>>>    READ-ME FOR T.0.R.N.A.D.0.'s CrackMe #1
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

PLATFORM     ::   WINDOWS

LANGUAGE     ::   ANSI C++

DIFFICULTY   ::   1          [ Very Easy, for newbies ]

------------------==============-------------

SUBMITTED BY  ::   T.0.R.N.A.D.0.

------------------==============-------------

The Rules:
==========---

 ** Universal ** :     (*) NO BRUTE-FORCING
		       (*) NO PATCHING


The Tasks:
==========---

    1. Simply enter a secret code that would pass ALL the tests.


    2. Reverse the complete algorithm for checking the code.


    3. Write a descent tutorial.


IMPORTANT ::  Explain in your solution, how you found "the" secret code that would
              pass Test #3. Tests #1, #2 are easy enough.  NO BRUTE-FORCING.

              Pure Mathematics :)

	      The secret code is interesting enough, although very small.




~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_

	printf("T.0.R.N.A.D.0. - born 2 %X\n",49374);

_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~