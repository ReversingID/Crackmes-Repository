Hello,

pretty easy keygenme. Written for learning purposes. Compiled with tinycc. Have Fun. Do what you want with it!

	You can do these:
	BRONZE: Patch it!
	SILVER: Fish your key!
	GOLD: Write a keygen!


My solution, source code and other keygenmes and solutions are open to everyone at https://github.com/LuxXx/reverse-engineering


Greets LuxXx