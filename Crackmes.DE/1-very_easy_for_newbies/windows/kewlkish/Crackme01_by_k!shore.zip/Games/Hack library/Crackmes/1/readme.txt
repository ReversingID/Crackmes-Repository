Remember there is always someone who knows more than us out there
								----UNKNOWN
===============================================================================================================                
        $$		           		^^
	$$                                  ##
	$$		                @@         
	$$                           e
	$$                      R             	
	$$                  0
	$$              h 
	$$          s
	$$      !
	$$ k			
	$$
	$$ k ! s h 0 R e
	$$       
	$$ k
	$$    !
	$$         s
	$$             h
	$$                  0
	$$                      R
	$$                           e
	$$                             @@
	$$	                      	   ##
	$$                                       ^^  
===============================================================================================================
Welcome to my first crackme

Thanks for downloading my crackme
**********************************
This crackme is coded in VB. 
I think it will be easier to crack.

Rules :
#######
1)Just find the unlock code.
2)No patching allowed
3)Dont copy others solution

If you are unable to crack this pls mail me ,i won't give you the full crack 
but ill send you some tips and get you started again

k!sh0Re
Mail you solutions to : cop_rpk@yahoo.co.in

===============================================================================================================