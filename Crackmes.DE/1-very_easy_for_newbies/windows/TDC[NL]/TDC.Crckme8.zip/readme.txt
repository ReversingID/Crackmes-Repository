Written by: TDC
Date written: Sunday 16 October 2005

Rules:
=-=-=-=

No patching, find a valid serial and make a keygenerator.

Description:
=-=-=-=-=-=-=

It can be tricky, or not? Have fun keygenning :-)