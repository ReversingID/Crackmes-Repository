br0ken's  CrackMe4
23/05/2008


Hi all,

My main aim behind this cme was to give newbies a chance at bruting.
Most of the  "bruteMes" I found are pretty hard for a newbie/beginner
So, I coded this. 

However, if you're an intermediate/expert, you will find this boring.
You have been warned!


To do:
*****

Code a bruteforcer and find the pwd.

Rules:
*****

No patching :)


Hints
*****

1. Pwd length = find out (it's pretty obvious)

2. Charset = a-z

3. Try bruting the individual characters of the pwd instead of the whole thing, its          easier that way :)


Have fun!

Regards,
br0ken.
















