This is my second CrackMe written in C++
I made it a bit harder, so its not as easy as the first one.
I also took more time for that, as for the first one.

Rules:
*No patching
*Make a KeyGen
*Upload a solution + tutorial

Hint:
*Serial's are only numbers.

Happy Cracking.
