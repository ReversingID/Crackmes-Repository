

	      [*- Welcome to D4ph1's second crackme readme file :) -*]

			  -General info about the crackme-

- Author : D4ph1

- File : D4ph1 - Crackme#2.exe

- Programming Language : Assembler

- Compiler : MASM32

- OS : Windows

- Type : Name/Serial

- Difficulty : 1/10 [For Newbies]

- Protection : Not packed or protected by any program

- Target : Make a keygenerator.

- Rules : Patching is not allowed. You must understand the main idea of the algorithm, DON'T JUST RIP THE CODE!

- Tip : The Serial is generated using a key which produced by a mathematic quiz that some friends forced me to solve :)

- Greets : Mitsos for learning me the quiz, crackmes.de and everyone out there I know or know me!

PS : If you want, send me your solution to fistiks16(at)hotmail(dot)com and tell me your opinion about it, suggest something, ask...or anything :)


					-ENJOY-

D4ph1
											 D4ph1