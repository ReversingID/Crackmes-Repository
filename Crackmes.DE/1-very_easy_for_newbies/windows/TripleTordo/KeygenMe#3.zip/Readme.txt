KeygenMe#3 by TripleTordo
Release Date: 20th December 2010
Level: 1/10
--------------------------------

Hey! , this is my Third crackme. I hope you enjoy it.

******************
Rulez :
	- NO patching allowed
	- NO code ripping allowed
Just:	Find protection scheme , and Serial Genaretion Algorithm. Write a tuto and a working keygen.

ONLY KEYGENS ALLOWED.

Example:

Name:Triple
Serial:1158492848793R

******************
i Hope you enjoy it, and if you can't find a valid solution, i hope you will learn something.
Regards.


Thanx to: you, for try this.

Suggestions, donations, free sex to :

.: tripletordo@gmail.com :.

EOF