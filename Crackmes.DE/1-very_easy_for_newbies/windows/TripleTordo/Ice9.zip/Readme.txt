Ice9 by TripleTordo
Release Date: 3th July 2009
Compiler: Masm
Language: Pure win32ASM
Level: 1/10
--------------------------------

Hey! , this is my first crackme ( KeygenMe ),  its very easy, for Newbies. I hope you enjoy it.

******************
Rulez :
	- NO patching allowed
	- NO name/serial allowed
	- NO self-keygening, code ripping allowed
Just:	Find protection scheme ( serial creating algorithm ), explain it and make a tuto and your own keygen.

This is a KeygenMe. Only keygens are allowed. Its very easy, no protection/encription, only one little trick. Good Luck.

******************
i Hope you enjoy it, and if you can't find a valid solution, i hope you will learn something.
Regards.


Thanx to: flipflop, Defc0n1, and of course, to you, for try this.

Suggestions, donations, free sex to :

.: tripletordo@gmail.com :.

EOF