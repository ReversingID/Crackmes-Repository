Hello Crackerz,

thiz is my Sudoku-CrackMe for Newbies. It had some Rulez

	1. You're allowed to patch Ressources (but not the Check-Button it
			is Disabled unless you're registered and all fields
 			are filled --> to avoid Exepctions)
	2. It can happens when you start the CrackMe the first time you get
			a exception or it close itself (it isa bug soory for thiZ)
			just start again (it should run now)
	3. if you start a new game wait 2-4 seconds while it calculate the right
			numbers for the game
	4. if all fields are filled with numbers and you're registered
			--> the check-button is enabled and you can check that
			you solved the game
	5. Pleaze fill only Numbers in the Registration-Box

	6. use DeDe if you want to know how many functions i used (a lot)

last infos

::Coder::		::BaKaE::
::Language::		::Delphi::
::Level::		::1/10::
::Bad English::		::yes::

I expect first solutions for the CrackMe *one* day after uploading, so hurry up!!

ps: have fun cracking thiz and playing a little and support me if you want a second edition

BaKaE out

pps: thiz game has a copyright	      (allowed are backup-copies --> no pirate-copies)
