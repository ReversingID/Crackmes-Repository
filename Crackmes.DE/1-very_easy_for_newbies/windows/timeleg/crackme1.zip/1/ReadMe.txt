=======================
- CrackMe1 by timeleg -
=======================
Hi crackmes.de community,
This is a little and very simple crackme 

Difficulty: 1 - Very easy, for newbies
Goal:       1. Understand how program and verification algorithm works.
               Don't patch verification algorithm.
            2. Find a valid password.
            3. Write a tutorial.

have fun and enjoy !
timeleg86@gmail.com

{Slovak}
Zdravim Vas, crackme1 je vskutku jednoduche, na zahriatie. Patri do celku mojej diplomovej prace, tak Vas prosim pozrite a okometujte. Dakujem.
timeleg