Create a keygen not a patch!

-Basfreak