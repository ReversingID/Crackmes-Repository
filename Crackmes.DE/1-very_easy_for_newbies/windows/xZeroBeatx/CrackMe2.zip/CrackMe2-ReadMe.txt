        ________                       _____                    __             
       /\_____  \  DIGITAL REVOLUTION /\  _ `\  PRESS START... /\ \__          
  __  _\/____//'/'     __   _ __   ___\ \ \L\ \     __     __  \ \ ,_\  __  _  
 /\ \/'\    //'/'    /'__`\/\`'__\/ __`\ \  _ <'  /'__`\ /'__`\ \ \ \/ /\ \/'\ 
 \/>  </   //'/'___ /\  __/\ \ \//\ \L\ \ \ \L\ \/\  __//\ \L\.\_\ \ \_\/>  </ 
  /\_/\_\  /\_______\ \____\\ \_\\ \____/\ \____/\ \____\ \__/.\_\\ \__\/\_/\_\
  \//\/_/  \/_______/\/____/ \/_/ \/___/  \/___/  \/____/\/__/\/_/ \/__/\//\/_/
		___  _ ____ _ ___ ____ _       _    _ ___  ____ ____ ___ _   _ 
						    (c) 2008 by the EVIL EMPIRE

	.:::::::::::::::::::::::::::: ABOUT :::::::::::::::::::::::::::::.
	:: ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ ::+
	::								::
	:: E-Mail: MortenOlsen@live.com					::
	:: "Fire in the heart, gives smoke in the head"			::
	:: Security.AIOStudio.dk/crackme				::
	::								::
	':::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::'



	.::::::::::::::::::::::::::::: NAME :::::::::::::::::::::::::::::.
	:: ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ ::+
	::								::
	:: Difficulty:	Easy						::
	:: Platform:	Windows						::
	:: Language:	.NET						::
	::								::
	':::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::'



	.::::::::::::::::::::::::::: CrackME ::::::::::::::::::::::::::::.
	:: ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ ::+
	::								::
	:: What is a "CrackMe"?						::
	:: It is a simple file created with only one perpose... to be	::
	:: cracked. The file uses diffrent kind of copy-protection	::
	:: methods. CrackMes may be tests of commercial protection	::
	:: software, or simple practice assignements.			::
	::								::
	':::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::'



	.::::::::::::::::::::::::::::: GOAL :::::::::::::::::::::::::::::.
	:: ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ ::+
	::								::
	:: Okay this one is a bit more difficult then the first.	::
	:: This is an activation that uses a "Signature" file to	::
	:: validate your account. Therefore your job is now to 	write	::
	:: a "Signature Generator" that can generate the signature file	::
	:: based on a user name. Also please write how you did it.	::
	::								::
	':::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::'



	.:::::::::::::::::::::::::: BOTTOM LINE :::::::::::::::::::::::::.
	:: ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ ::+
	::								::
	:: This one does not feature the wall of fame. A new harder	::
	:: version will soon be out there for you to play with, with	::
	:: the "Wall of Fame".						::
	:: if you have any questions, or found any flaws, please	::
	:: contact me on the mail at the top or on "www.crackmes.de"	::
	::								::
	':::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::'