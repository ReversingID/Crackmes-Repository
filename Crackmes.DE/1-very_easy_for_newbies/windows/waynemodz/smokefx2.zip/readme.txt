Hello and Welcome!
to SmokeFX v2.0

Rules are simple!
Youve got to enter a username and serial key...
Your success or failure shall be displayed to you.

Crack Mode: Ive simplifed the crack process.

In this version there is an algorithm, 
Strings are Ciphered with Strings
and Integers with Integers.

Created with Delphi 7.0.

Good Luck People.

Wayne Modz
waynemodz@gmail.com
