Time:

5:16 PM 11/24/05

1. To unlock the button and text box you must have to type the correct serial to unlock... :lol:

2. no any patching... :lol:

3. you can't enable the button by patching... :lol:

4. the special thing of this crackme is "You must unlock by the correct serial"... :lol:

5. Find the correct serials... :lol:

6. After that write how you did it... :lol:

									have a nice day,,,
									Bye
									thank you
