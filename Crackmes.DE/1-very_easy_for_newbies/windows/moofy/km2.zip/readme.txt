moofy's keyme #2
level: 1/10 :)
NO PATCHING! When solved, write a tutorial and keygen. Its very simple. I tried
to get people confused with other stuff I threw in, but it probably wont trick ya :)
It can probably be cracked in less than 10 minutes.