moofy's namegenme 1
coded: 2/10/10
difficulty: 1-2/10 i guess

well, its been about 2 years since ive even touched a crackme, so
i present to you today something I coded today. its pretty simple i think.
you have to create a name from a randomly generated serial.

a little thought, if you think you know what the numbers mean, email me :]

my normal rules apply:
no self-namegenning
no patching
etc

after solving create a tutorial and submit to either me or crackmes.de
my email is icyflamez@gmail.com

please include the source and not just an exe.