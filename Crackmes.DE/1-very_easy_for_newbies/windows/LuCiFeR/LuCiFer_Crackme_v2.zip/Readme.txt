Hey jo guys!
Well this Crackme is my first C++ Crackme! (so it should be easy)

Well, i wrote a VB crackme (which nobody solved now) but many of you guys are pissed off of this crappy vb shit ;)
so i thought i shall learn c++ now and tried it! well here is the result of learning 2 days c++! 

2 versions of my Borland C++ Builder Crackme were rejected because some files would be missing!
so i tried doing it by Dev-C++,  well here it is now!

Rules:
1. Do not Patch
2. Sniff a serial for your name
3. write a keygen

Special thanx goes to d@b -> your my master ;)
this crackme is espacially for him (d@b), because he was pissed off sooooooo much of VB shit!

ThX LuCiFeR