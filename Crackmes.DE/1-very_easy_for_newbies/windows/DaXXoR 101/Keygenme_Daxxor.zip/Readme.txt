1.Disable the nag & Protection
2.Make a Keygen

