Miracle by ZeroZero
Release Date: 4th July 2004
Compiler: Masm
Language: Pure win32ASM
Level: 1/10
--------------------------------

Rulez:  patching, code ripping, etc are not allowed... Find a valid password, and explain the protection scheme.

Hey, it's very easy. When someone writes a solution for this crackme, i will put the password of source.zip in the readme file of the next crackme. Good Luck.

Thanx to:

- U, for trying this crackme
- .Gollum, for his imagination.

 ZeroZero   -=zerohutsa@hotmail.com=-