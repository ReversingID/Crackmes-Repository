
----------------------------------------------------------------------

'Little Headache' by rantasipi for crackmes.de

It uses some tricks that could be confusing for a total beginner...

Goal:

1. Understand how program and verification algorithm works.
   Don't patch verification algorithm.

2. Write a tutorial.

[no need for keygen]

Tested on WinXP SP3

Let's hope someone will learn from this!

-rantasipi

----------------------------------------------------------------------


