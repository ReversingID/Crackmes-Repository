Crackme by Sinok-
Find a working password, then post a solution.