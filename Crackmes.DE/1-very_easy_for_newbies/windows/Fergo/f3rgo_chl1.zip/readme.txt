F3rGO! Challenge 1.

This crackme is for begginers, and involves simples tasks. Patching is allowed. A full description of the tasks in the About dialog ;D

Enjoy!