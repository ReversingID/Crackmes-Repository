
 CrackMe #1 by dip22e

 Find a Serial
 Make a KeyGen

 Coded in Assembler.
 Happy Cracking :)
