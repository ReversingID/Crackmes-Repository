Hello,

This is my first crackme in C++ using a very simple
cypher encryption. If you have a question about this keygen
leave a comment on crackmes.de



Good luck cracking it.

mausy131


Author    : mausy131
Language  : C++
Compiler  : Microsoft Visual Studio 2010
Packed    : No
Protection: Cypher
Rules     : No patching!; Working Keygen + a good tutorial will be accepted