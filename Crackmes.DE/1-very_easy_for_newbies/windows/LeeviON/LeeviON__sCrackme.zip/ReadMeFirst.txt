This crackme has been made by LeeviON with flat assembler 1.68

You can patch it, but i would like to see someone making a program that is started before this crackme, and then it "cracks" this.. what was its name?

Thank you for downloading this crackme, altough it is very easy. Good luck!