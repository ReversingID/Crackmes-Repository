Hi !

This crackme is a product of 10 minutes writting.
It's only for newbies, becase it's damn to easy.
I promise to the advanced crackers that I will write another one !
It will be interesting for the newbies becase it is just simple math.

Rules:
1. no patching and no selfkeygen
2. write a keygen and a soluton

Best Regards and Have A Nice Cracking Day !
Ank83