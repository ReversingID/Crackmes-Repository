Very easy crackme for beginers :)

Rules:

No patching, Keygenn-it :D