***************************n00b**
**                             **
** Name        : Crackme No.1  **
** Coding      : Noob-Average  **
** Protection  : Noob-Average  **
**                             **
** Restrictions: No patching!  **
**                             **
**2oo8***************************

This simple crackme has 4 levels,
which basically holds the 4 basic
levels for each newbie .NET cracker
to beat before even considering
any commercial or harder crackmes
within its genre.

Tools needed:
-------------
.NET Reflector
Your favourite coding language
Brain
Music (to get in the mood :P)


..:: GREETZ ::..
----------------
Crosys (wazza - if life is a pow, u must be the mod :P)
0x87k (where ya at?)
lafarge (when is the next tune comin?:P)
HMX1010 (long time no see man, msn?!?:D)
Niyelana (just ask man;))
melatonin (we miss u dude:/)
futureproof (hola!)
ScareByte (when am i gonna see u on #phrozencrew again? :/)
...and probarly some more fellas too...

/Regards, n00b