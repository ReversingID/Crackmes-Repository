This is the first one from a series dedicated for those begginer programers who start to write their first protection schemes. I'd try to make Evolution series harder and harder to crack from version to version. Is some king of my evolution in protection shemes.
So I will start with a very dumb protection scheme, as at that time I knew nothing about cracking. I think today there are very many new programmers who use this stupid technique. But is good to have a starting point to begin with.
So don't blame me. Think of your first line of code when you first tryied to put a pass in yoour app.
I want very newbies to have something to start off.

In this crackme you have to do anything you want to play the little game.
There is nothing special. Remember, is it just for learning basics cracking and newer version will have better and better protection, based on your solutions.