ReHPer CrackMe v1.0

Hi All!

Compiler: CodeGear Delphi 2007

Level: 1/10

Packed: None

Mission:
 
 - Disable NAG Messages
 - Unlock 'CHECK' button
 - Patching 'CHECK' button protection
 - Patch CrackMe ;)
  > Write a tutorial. Send solution to crackmes.de ;)

From Russia, with Love. :)

Bye.