					-NTS-Crackme3

					     By
		
					   Cyclops
-------------------------------------------------------------------------------------------------

Crackme = NTS Crackme3

To_Do
-----

	Fish the serial.

Addons
------
	
	Create a Patcher. (Dont use DUP or any other, code ur own)
	Create a Loader. (Dont use DUP or any other, code ur own)

-------------------------------------------------------------------------------------------------

Gr33tz
------
	Greetz to all the reversers,crackers,coders in Reverse Code Engineering field.
	Greetz to all the Programmers who created such nice tools.
	Greetz to crackmes.de, where i started reversing and still learning.
	Greetz to all my friends from RCE world and REAL world, with out em i shouldn't be doin 
	this.

-------------------------------------------------------------------------------------------------

Contact
-------
	U can PM me on crackmes.de or mail me cyclops1428[at]yahoo.com

-------------------------------------------------------------------------------------------------

			   ( Part of Project PolyPhemous (c) Cyclops )