Welcome to my SECOND crackme. Wooohooo, big thing.
This project was started on 2000/01/03 (third january 2000
for those fools who use stupid date formats), around 19:00,
while having a severe case of influenza (that started sometime
last millenium (kinda, depending on whether you feel zero or
one based), around 1999/12/25). Finished 2000/01/24 21:44.

I'll try not to help too much, but I just can't help it,
helping you out a little might be a little too much help,
but help can be such a help when dealing with...well...

Anyway, this shouldn't prove too difficult for all you
cracking masters out there. This time, you have to make
a keygen that produces a keyfile. Simple as that, simple
as eating cherry pie while driving without hands on a
onewheeled bike. Perhaps easier, perhaps tougher, depending
on your skillz in various areas of life. If you can make it
produce the victory text without keyfiling it, just by doing
an oldfashioned patch, I'll be happy to see it.

(Is f0dder on acid or is that influenza really bad? Who can
tell? Can f0dder tell? Will he tell you? Great unexplained mystery!).

Perhaps this file is used by the crackme? Have you tried
renaming it? Deleting it? Changing it's contents? Do you DARE?
Perhaps there's a builtin superstealthed flashbios erasing
tripwire piece of code? Perhaps there isn't? Perhaps this piece
of software is not penguin friendly? Perhaps it's more of a sh33p thing?

IOW: HAVE FUN, dammit, and send me your keyfiles and keygens!
(Ohyeah...in a real life situation, the keyfiles would have
been different, more error tolerant, and easier to get to stupid
customers via email. Nuff said, that might've been too much help).

The pass for the source archive? Ah yes. If you reverse engineer the
crackme, getting an understanding of the code, you will KNOW the
password. It's the first line of the text you see when you see the
light...which you will. (Umm, not the MessageBox text, but the text
from the...well...secret place :-). Otherwise, you could always try
bruteforcing a rather long password...whatever path you choose, I
wish you luck. (Bruteforcing the archive password will probably
take longer time than bruteforcing the protection).

Updated 2000/02/12 (12. Feb 2000):
  At last I found the correct linker switch (/OPT:NoWin98), reduced
  executable file size from 60k to 47k. Should have just run the
  linker from the cmdline rather than browsing around MSDN, it would
  have saved me about 5 hours or so (but then I wouldn't have found
  all those *other* intersting articles ;-)

  Also, to be fair, I believe a little clarification on this crackme
  is needed. To keyfile it, you WILL need bruteforcing. And perhaps
  more bruteforcing than is feasible on most machines. There's no RSA
  or other puke (you'll see how easy it is, though probably timeconsuming).
  I still recommend you to give it a try, even if you don't feel like
  bruteforcing, for I have been told that this crackme is mighty interesting.

Updated 2000/03/08 (8. March 2000):
  I've included a hint inside the executable now, that should help
  you write a bruteforcer (ie, make it possible to "bruteforce" in
  one second). You should notice this help when you get "far enough".
  It might be too easy now, actually. But, then, you can always try
  finishing it without accepting the word of help.

signed f0dder, f0dder@yahoo.com
