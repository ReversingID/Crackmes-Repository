The XORdinary Crackme

After quite a while of lazyness i made this small crackme me again. I must honestly say that i have no idea weather this is a difficult one or either an extremely easy one.  
I do know that it is very easy to code, so i wonder what the result will be of this small efford in coding.

- The aim of the game: Decypher the text string into plain readable text!
- The rules : Everything's allowed, do as you please!

Looking back at my crackmes, i am pleased to see that nearly allmost my crackme's have been successfully cracked!!  All, besides one; Crackme #3. And believe it or not, it is REALLY one of the easiest ones. I've said this many times, and it's the truth.  Still, i cannot believe that most of you have been fooled in such an easy way ;-))  So common now, break this one aswell, as the ALGO is very easy.  You will agree with me once you cracked it. Just dont believe everything you THINK you see................

Ohwell.. for help, solutions, or whatever you can mail me at:

scarabee_5@hotmail.com

Some salutes fly out to:
_PUSHER_ , _RiPTiDE_ , Devilz, Ceeb, Nefertiti, CSFS, Basdog22 and the rest that share this interest.



