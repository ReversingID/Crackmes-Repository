well my 10th crackme!

no rules!
use everything!
allowed to patchme
allowed to crackme
allowed to keygenme


do whatever you want!