-=Password check=-

Patching Level: about 2?
Finding correct password level: 8?

Author: RooJ

Aim:
Finding the correct password may be too difficult so patching can be used as a last resort.. note that the crackme wasnt made to be hard to patch though so alot of the pleasure maybe taken away from cracking it :P. You should try to find a working password and write a tutorial about how you found it. Make sure you send the tutorial to me :D...

Authors Comments:
This should offer a challenge for most people, theres a possibility of more than one working password but finding one should be difficult. If you cant crack it but really want to, are unbelievably impatient or require information of some kind email any questions to: quibus_umbra@hotmail.com.

Also if you disagree with the levels let me know and if i agree ill alter them.

RooJ

========
for every coder, theres an equal and opposite decoder.