Hi all,

This is my first crackme for crackmes.de, i hope you'll enjoy it, here are the rules:

-get a working id/serial combination, then try to code a keygen

good luck, if you have any questions you can mail me at: kahel@altern.org