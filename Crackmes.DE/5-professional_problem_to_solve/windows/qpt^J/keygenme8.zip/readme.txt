Hello everybody,

Here's a new challenge from me.
No obfuscation tricks this time, though code is a bit virtualized.
The algo inside vm, is more harder, than vm itself.

so the rules are.
1)No patching
2)No any sort of bruteforcing
3)Keygen only

enjoy! :)