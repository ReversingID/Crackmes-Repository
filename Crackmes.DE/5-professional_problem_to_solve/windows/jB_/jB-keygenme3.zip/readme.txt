KeygenMe 3

No patching, no crappy self-keygen of course.
This keygenme has not been designed for beginners or 
intermediate crackers, nevertheless everybody is
invited to try it.
Of course there is a solution...

Once you have a valid keygen, send it to me with a small
tutorial: resrever@gmail.com . Same mail if you find a
bug or if you want to send comments.

Good luck, and happy reversing!
Thanks to minz for the 1 hour gfx.

Regards,
jB, May 2006
http://jardinezchezjb.free.fr

