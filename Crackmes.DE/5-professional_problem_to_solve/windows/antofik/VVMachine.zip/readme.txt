
  Hi all
   
  Today we will work with virtual machines (anyone who have been inside the ASProtect knows what it is ;-). Yeah, nowadays every protection developer consider it proper to use his own VM - it's so-called "very modern"... Only a few, the old ones (the fathers of protection:-), still can make their work using simple code, though not in the cost of reliability. Well, anyhow we - who call ourselves reversers - we just must know how it works. And inasmuch as VM choice at crackmes.de is not huge, I decided it would be useful to write another one VM keygenme. To make it a bit more interesting to you I added second embded VM (a very little and simple one) and several tricks which can frighten only a newbie reverser (though, if this one seems to be very difficult to you, do not hesitate to write to me: I'll try to answer all your questions)

  Brief info about keygenme:
 Packing: none
 Crypto: none
 Obfuscation: just anti-newbies tricks

 Task, as always, to write a working keygen

                                  	antofik
 