_khAttAm_'s What Is My Password v14 has come with new protection. 
-----------------------------------------------------------------
Usage Instructions:
1. UnRAR the contents of WIMP14.rar. You will get an ISO file named WIMP14.ISO. Hope you know what this file is. Yes, This is a CDROM Image. Mount it to a Virtual Drive. Use any virtual CD program such as Alcohol or daemon tools to do this. Read their readme for how to use them, if you don't know. You may use any other means to get the EXE file onto the harddisk. You may even burn this Image with your favourite burner, into a CD.
2. In the mounted CDROM, you will see two files. They are named as "_khAttAm_'s What Is My Password v14.exe" and "Source.rar", which contains the program source but is password protected. You will need to copy the file to hard disk and find the valid serial for the file "_khAttAm_'s What Is My Password v14.exe", by using your cracking skills. The password for the RAR file is the same as the password for the exe.

So, here are your objectives:
1. Copy the file "_khAttAm_'s What Is My Password v14.exe" to your HardDisk.
2. Find a valid serial for the file.

Best Of Luck

Greetz
-------
konstAnt, TDC, REM, deroko, ZeroCoder and everyone I missed.