Drakenza's Crackme1
7 Aug 2008
===================
Difficulty: Not for newbies :)
===================


Welcome. Thanks for downloading.
Your task is to create a keygen for the crackme.
Only one rule: No patching of any kind, including self-keygens.

No other information is given; that part is up to you :)

When you've solved it, please write a solution and submit it (with a keygen) to crackmes.de