 RLPack - New Year challenge
 
  This  is  the official RLPack unpackme. Unpacking is considered correct if the
unpacked  Unpack.exe  can unpack crackme.fsg.exe. You can not add ap0x unpacking
engine  .dll  files to unpackme to make it work. You can only use things located
inside  the  challenge  archive.  Due to the fact that Unpack.exe uses psapi.dll
challenge will work only on NT systems.
  The  first  one  to  unpack the official unpackme will get RLPack Full Edition
Personal license!
 
 Contact email: ap0x.rce@gmail.com

 Happy cracking ;)