The objective is to write a functional keygen. No hints.

Rendari Aka