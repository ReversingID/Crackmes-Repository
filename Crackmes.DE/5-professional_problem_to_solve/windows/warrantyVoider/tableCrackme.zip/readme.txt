compatibility
=============

I�m really sorry but this crackme will not run on all computers.

=> This crackme only runs on W2K/XP. Please don�t use another OS and then complain. I tested on W2K and XP SP2.

=> You need mfc71.dll (www.dll-files.com)

*******************************************************************************
=> I think the crackme is safe but please better run it inside VmWare etc. 
It might crash your system, not properly delete the files it creates, or worse.
*******************************************************************************

=> It looks shitty on W2K. I did the dialog with MFC in Visual Studio and couldn�t figure out how to use Pixels instead of DialogBase Units. Maybe you want to drop me a hint or URL? I�m completely new at this.


your task
=========

Write a keygen, write a good tutorial. 
Self-keygenning is forbidden on this one, because you could do a brute-force selfkeygen without understanding anything and miss all the fun.


the crackme
===========

To start the crackme, run crackme.cmd. Depending on the speed of your CPU and harddisk it will take up to half a minute before the dialog comes up. In the dialog you can enter the name "warantyVoider" and the serial "5B55873D" (dont press enter, this would close the dialog) to get the good-boy-message. If anything else happens the crackme is not compatible with your system. In the case I�m really sorry, don�t waste your time, download some other cool crackme. But let�s hjope that doesn�t happen...

There are two EXE files. The first one runs silently before the second one starts. The first one is obfuscated because you don�t need to analyse it to solve the crackme. 
