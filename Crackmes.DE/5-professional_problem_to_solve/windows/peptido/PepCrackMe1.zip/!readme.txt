OK, the scenario is the following...
This is an ActiveX DLL that is supposed to get called by an ASP application.
The DLL has a license check (which is read from the conf.ini file) and, if it is correct, it does what it is supposed to do. If the license is not correct, it doesn't.

This crackme includes an .exe file that will execute the methods in the DLL, which was created by me only to make this crackme easier to run (without the need for a web server, and stuff like that).
The exercise IS NOT to crack the .exe file. Doing this is absolutely trivial, and it doesn't make any sense really, because the .exe file is not doing anything really (in fact, in the real application, it wouldn't even exist. It would be ASP pages which code you can easily see).

The exercise is correct when the .exe file shows the message "Bien! Crackeado!".
In order to achieve this, you can obtain the serial, patch the .dll file, whatever you want.
The only thing that is not valid, again, is touching the .exe because, in fact, it wouldn't exist in a real application like this. What you have to do is crack the .dll (or get the serial) to make it behave correctly (and make the .exe believe it's working right).

You also can't find out what the DLL is supposed to be returning, and patch it to return just that. That is also trivial, and it misses the point, since the idea is that the DLL has lots of working code inside, it's not only the returning of the value that counts. You have to somehow make this logic run normally, as if the correct license code had been entered.

Finally, to run the crackme, you must register this DLL using regsvr32.exe...

Good luck!

==============================================================================================

Bueno, la situaci�n es as�...
Esta es una DLL ActiveX, que va a ser llamada desde una aplicaci�n ASP.
La DLL tiene un chequeo de licencia, (la misma se lee desde el archivo conf.ini), y, si est� bien, hace lo que debe hacer. Si no est� bien, no lo hace.

En este crackme hay adjunto un archivo .exe que va a ejecutar los m�todos de la DLL, que lo cre� s�lo para que sea m�s sencillo usar este crackme, sin necesidad de un servidor web y cosas as�.
El ejercicio NO ES crackear el .exe. Hacer esto es absolutamente sencill�simo, y no tiene ning�n sentido, porque el .exe no hace nada, la que hace cosas es la DLL. 

El ejercicio est� bien cuando el .exe muestra el cartel "Bien! Crackeado!".
Para esto pueden obtener el serial, patchear la .DLL, o hacer lo que les parezca.
Lo �nico que no vale, de nuevo, es tocar el .exe porque, de hecho, en la aplicaci�n real este ni siquiera va a existir, y no hace absolutamente nada. Lo que tienen que lograr es crackear la DLL para que se comporte correctamente (y hacer que el .exe crea que est� funcionando bien).

Tampoco vale descubrir qu� es lo que se supone que la DLL tiene que devolver (mirando el EXE), y modificarla para que devuelva eso...
La idea es que esta DLL tiene l�gica adentro, que tiene que correr correctamente, y tiene una protecci�n. Hay que romper la protecci�n, de manera tal que esta l�gica corra normalmente.

Ah!, Para correr el crackme, hay que registrar la DLL usando regsvr32.exe...

Bueno, les dejo el desaf�o. 
Suerte!