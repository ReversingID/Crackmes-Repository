Welcome to my new creation.


To begin with,
I have place emphasis on the intention behind this keygenme.
This isn't even a proper keygenme because I provide only one userid,
nevertheless, trust me, this will be enough ;)
However, the intention behind it is to test your mathematic skills.

The name spvm means "special purpose virtual machine".


Rules:

   Find at least one valid serial for the given userid.
   Do not exploit the vm if you find a weakness.
   If your solution is shorter than 18 chars, then you're a clever guy.





Greetz:
bLaCk-eye, jB, halsten, KernelJ
and other great reversers out there.


My info:
Email: mrhaandi@gmail.com
Homepage: http://mrhaandi.thecoderblogs.com/