Quantity Serial Protection #LEVEL 2#
by BlueOwl

Details:

 Anti-Cracking.......None
 Anti-Debugging......None
 Encryption..........None
 Packing.............None
 Serial..............32bit
 Language............Assembler
 Difficulty..........Medium/Hard

Mission:

 Creating a key generator, have fun.

User/Serial Examples:

 User1: BlueOwl
 Password1: GHICAEDK
 User2: Coding4Ever
 Password2: JDMBBDDB
