Imagination
-----------

This crackme has been coded in two or three days, so I don't think it will
be hard to defeat.
I just hope that the idea will be glad to you, it's not the "usual" username/serial,
this time you'll have to work with other things too (who said images? eheh).

If you need to contact me, you can do it at the following addresses:
-> to my home page: http://kratorius.cjb.net
-> to my mail addresS: kratorius@gmail.com
-> on irc: irc.azzurra.org @ kratorius

I would just say hello to Andreageddon, Quequero, evilcry and last but not least,
Ironspark. I dedicated this crackme to a very special friend, dany. I hope that
she'll read this a day.

Bye bye...
kratorius

PS: visit quequero's home page too at http://www.quequero.org, it's nice :)