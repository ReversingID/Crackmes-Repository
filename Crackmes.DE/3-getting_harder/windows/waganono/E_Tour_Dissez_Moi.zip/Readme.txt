***********************
** E-Tour-Dissez-Moi **
**        by         **
**     waganono      **
***********************

Level : 2+
Type : Keygen Me
Language : C

You have to code a keygen.
Main difficulty is how to modelize the problem (well known).


waganono
wokanono@gmail.com
http://melzas.free.fr