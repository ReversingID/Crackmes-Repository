Your goal is to unpack this executable so that it still displays the message and is totally
unencrypted. Meaning that you are able to view any calls or registers or text strings with
out haveing to do a reanalysis. Just one hint, the total size when you finish unpacking should be within 2kb of 5kb.