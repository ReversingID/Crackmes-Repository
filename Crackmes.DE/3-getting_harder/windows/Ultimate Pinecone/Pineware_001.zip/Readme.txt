My first crackme :)

Please, no patching, self keygenning, etc, just make a keygen for it.

Good luck!

http://pineware.freehostia.com/