Da rulz:
- No Patching
- No self keygenning (Forbidden!)
- Make a Keygen
- Write a tutorial and send it :)

Happy keygening & thanks for attention :)

Difficulty: 3 - Getting harder
Platform: Windows
Language: Assembler