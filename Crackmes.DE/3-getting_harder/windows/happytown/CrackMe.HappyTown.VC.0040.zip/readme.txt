Find Magic and make KeyGen!^_^

HappyTown
wxr277@163.com