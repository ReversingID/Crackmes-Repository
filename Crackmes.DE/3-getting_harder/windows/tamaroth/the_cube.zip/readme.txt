Hello!

This is my next small toy. This time there's no crypto and the protection is slightly different.
I think you'll have to show off your coding skills more than anything on this one!

Acceptable solutions must contain a working keymaker and a tutorial or a brief description.

Best regards,
tamaroth