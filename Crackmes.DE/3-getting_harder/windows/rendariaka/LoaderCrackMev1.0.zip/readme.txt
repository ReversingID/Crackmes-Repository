I never saw a crackme about loaders, so I made one.

Objective: Find the serial

Good Luck

Rendari Aka