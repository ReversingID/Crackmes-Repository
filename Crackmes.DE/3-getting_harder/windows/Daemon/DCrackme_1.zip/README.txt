RULES:
Yor Aim is to brute or find right serial.		
Making of keygen not neccesary, but it will be a plus
algorithm is very simple, it takes about 15 min from you
If you can solve this puzzle, you will see a final crypted string
Each mistake will call exit to OS without any message
I'll Hope, you dont waste you time, and learn something new \n");
and interesting about selfmodidication technique 
Final string consist from 1 word. You can try to decrypt it, but is it possibe, who knows