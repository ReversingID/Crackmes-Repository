OneXor by V!ctor.

Regards to all who downloaded my crackme.

OneXor - Hmm... It's revision of OneDword cme.
I think, it will be better name, then OneDword.
There is same idea (maybe naive, but...).
Your target is see GoodBoy with title 'OneXor by V!ctor' and one button
'OK'.
If you entered right psw, you will register, but if you now click 'Check'
button, you will see the Badboy. Why? IMHO, one registering for one user is
enough.
There is one password which shows goodboy first, and then shows badboy.
Try to find it so.
BOTH PASSWORDS ARE TYPEABLE!

And some rules:
1. Of course, NO PATCHING.
2. Write a tut.

Sorry for my english.

V!ctor.
tva_wn@mail.ru