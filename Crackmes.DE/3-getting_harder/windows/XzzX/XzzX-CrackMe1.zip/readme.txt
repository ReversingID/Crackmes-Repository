*******************************************
************** XzzX#CrackMe1 **************
*******************************************

author    : XzzX
created   : 26/05/2007
language  : Assembler / MASM

difficulty: 3/10
goal      : write a keygen
rules     : no patching - far too easy ;-)

info      : no packer
            no anti-debugging tricks

This is my first CrackMe but I think it's quite hard for a beginner to solve. ;-)

gl&hf