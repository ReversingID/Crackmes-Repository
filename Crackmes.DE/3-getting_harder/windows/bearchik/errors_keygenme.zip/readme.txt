Errors keygenme by Bearchik
-
Hi. This is very small and easy program. It is using famous match algorithm for create key.
But I used small triks to make keygenme interesting.

Best regards, Bearchik.
