
ReWrit's Crackme#7

This crackme has 3 parts:
part 1. Serial fishing (numeric serial)
part 2. Keygening (numeric serial)
part 3. Keygening (alphabetic serial)


Rules:
-------------------------
* Make a Keygen.
* No Self-Keygen.
* No Patching.
-------------------------


Name:		ReWrit's Crackme#7
Difficulty:	3 - Getting harder
Platform:	Windows
Language:	C/C++