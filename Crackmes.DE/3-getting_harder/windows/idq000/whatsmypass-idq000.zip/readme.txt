Hello cracker!	
	

	With the current advent of 'What's my passwords'...I decided to make my own.  I'm back with fun stuff in my Second C++ Crackme.  This utilizes some math stuff...but it should be no problem once you figure it out. 


Rules:
Like everone else:
-No patching
-Write a tutorial

Send all results to: idq000@prodigy.net

Good Luck!

TARGET: whatsmypass.exe
TARGET TITLE: "What is my password? by idq000"
VERISON: 1.0
COMPRESSOR/PROTECTOR: None.
STATUS: COMPLETE.