
>>>>    READ-ME FOR T.0.R.N.A.D.0.'s KeyGenMe #3
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

PLATFORM     ::   WINDOWS

LANGUAGE     ::   VB       [ No protection  ]

DIFFICULTY   ::   3        [ Getting harder ]

------------------==============-------------

SUBMITTED BY  ::   T.0.R.N.A.D.0.

------------------==============-------------

The Rules:
==========---

 ** Universal ** :     (*) NO BRUTE-FORCING

 Test #1,#2,#3   :     (*) NO RULES ! You may patch !!

 Test #4         :     (*) NO PATCHING NOW! Simply make a Keygen. [[ This won't be difficult ]]



The Tasks:
==========---

    1. TASK #1  ::  Defeat the Anti-Debugger.


    2. TASK #2  ::  Patch the app to run instead of closing.


    3. TASK #3  ::  Find your way to the Validation Section.
       [[ HINT  ::  The form appears BLANK at this test. Make it look better ;) ]]


    3. TASK #4  ::  Enter correct validation details and pass the validation check.


    4. Write a descent tutorial. ;)






~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_

	printf("T.0.R.N.A.D.0. - born 2 %X\n",49374);

_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~