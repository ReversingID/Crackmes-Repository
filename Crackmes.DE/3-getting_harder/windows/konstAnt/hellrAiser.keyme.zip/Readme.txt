Well, hellrAiser System Utility v 5 down.

As, _mAkA_ said it doesn't raises hell.

This version is a keyfile me.

Rulz...

1) No patching. 
2) Make a valid keyfile

******Important
Oh yeh where it asks a keyfile. Just click the "Copy Directory" button.
******End Important

Objectives...

1) Unpack it.
2) Write a good tutorial. Ragarding the unpacking and
   keyfile.
3) Program a good keyfile generator.

Rating:
Well this is my first keyfile me. Don't know much about rating 
it. Still rate it 8/10.

Greetz:
OorjaHalt, _khAttAm_, Gauri....
& crackmes.de
