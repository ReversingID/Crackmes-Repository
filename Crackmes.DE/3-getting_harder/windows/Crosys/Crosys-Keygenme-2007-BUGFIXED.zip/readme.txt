Goal: Write a keygenerator
Protection: Some crypto
Packer: None


Instructions:
Enter the serial #1 and press check key, the rest
is enabled if its valid.
Press finish to check the last key.

Greets to all my friends around...

