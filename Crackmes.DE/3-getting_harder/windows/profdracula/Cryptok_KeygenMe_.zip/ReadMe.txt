Prof. DrAcULA presents, Cryptok KeygenMe {3}
===========================================

It is the 3rd KeygenMe in the Cryptok-series.
Hope you enjoy this!

You have to:
1. Code a keygen(inline-keygen is not allowed).
2. On entering a valid-serial, Cryptok {3} displays a Goodboy-messagebox, but its text is encrypted.
You must code a decoding-dll that can decrypt this junk-text to original-text.
3. Find the password to get your prize from "Prize.rar". You will find it at a place where you have to get
foolish and where evolution occurs.

Solution for this KeygenMe means;
1. Tutorial explaining how it works.
2. No patching, no self-keygenning.
3. A working keygen and a decoding-dll, with source.
4. Find password to get prize from Prize.rar

Protection Level : For you to rate it

Hints: I think there are more than enough clues in KeygenMe.

See u with next Cryptok Relaese.