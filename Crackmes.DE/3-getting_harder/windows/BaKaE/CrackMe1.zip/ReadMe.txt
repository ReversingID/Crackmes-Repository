[CrackMe]		First CrackMe by BaKaE
[Language]		Delphi
[Protection]		find it ;-)
[Fun while Cracking]	of course (I hope it)
[hint]			lissen Music it calms you
[OS]			tested on XP Pro SP1 and XP Home SP2



thiz is my first crackme and i think it is 3/10.

rulez:

1. You must solve the ErroR-PaGe (You need to patch Only one Byte (Yes its a hint:P))
2. dont patch the algo or compares (equal --> not equal)
3. write a KeyGen
4. send me your Solution + KeyGen + your opinion of my first crackme
5. have fun