elf'z crackme #3
written in good old MASM
difficulty: 2-3



  ...upon  travelling  somewhere  in search for treasure you stumble upon some old
  crypt;  something   says   that  something really great and expensive awaits you
  there,  so  you   decide  to  take  a  look.  but... what the hell? the crypt is
  protected  by  some  strange   kind   of  security  lock. You see that it leaves
  disappering  marks  as  you  touch  it by the finger. Neverthless, you decide to
  explore this thing more carefully...

  Best wishes to you in your quest!

--

  (i  assume  that  by  opening the crypt, you'll get a magic word for opening the
  crypt archive)

--



  NOTES:
  Made  this in 2 evenings just because there was nothing new @ crackmes.de, and I
  was a little bored; no new and hard techniques here, but I believe this won't be
  too easy for newbs.
  Tested under virtual-w98, virtual-w2k, and XP.


elfz,

  2004-04-17, Riga, Latvia
  elfz@laacz.lv <MSN>