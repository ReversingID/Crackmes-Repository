wish by raven (2008)
_______________________________________________
Rules:
- No patching
- Solution is a tutorial and a working keygen!
_______________________________________________

Compiled with VC 2008, you will need the VC 2008 runtime!