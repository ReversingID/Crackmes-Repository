No patching!
Valid solution is only a keygen+tutorial ;)