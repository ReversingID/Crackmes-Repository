===================
ror32's Crackme #01
===================

code: C
date: 2011-02-06

The validation algorithm is simple arithmetic. 

If you figure out a way to generate a license key for a given user name, then
create a keygen and send it to me with the source code. Povided that the
keygen works, you will get the source code of this crackme and my keygen!

Rules:
1) No patching
2) No bruteforce

Tasks:
1) Find a license key for your name
2) Create a keygen that generates a license key for any given user name

e-mail: ror32@live.com
