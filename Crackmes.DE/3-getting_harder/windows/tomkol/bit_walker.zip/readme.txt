BiT WalkeR ChAlLeNgE by ToMKoL [c4U]

Welcome to this small keygenme. Your task is to made my keygenme say it's
registered by you. You can do whatever you want while reversing. Your final
solution can't patch or bruteforce my code. Everything is fully reverseable.
I've coded keygen for test purposes so it's possible to keygen it.

When you solve it write a keygen and detailed solution.

Tested on win xp sp3 (32 bit) and win 7 (32 bit). Works correct. Not testd on
other systems but should work fine.

Good luck to any one trying it.

ToMKoL [c4U]