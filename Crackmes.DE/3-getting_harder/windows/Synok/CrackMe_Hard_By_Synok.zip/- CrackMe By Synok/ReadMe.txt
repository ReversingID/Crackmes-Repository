This is a harder CrackMe..
I hope your a good cracker to solve this..

No protection!

Rules :
'�'�'�'
1 . Don't patch it the way it looks like it is cracked but isnt.
2 . Dont use any tool for stealing the work ;)
3 . Have fun cracking it!! :)

Adios,

---