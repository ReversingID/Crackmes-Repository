June 11 2008

Thorwak CrackMe #02

My second crackme. It should be at least a little
bit harder than my last one, I hope :)

No rules, do anything you want. Just find out
the password that will let you see the GoodBoy
message.

You may find bruteforcing is the way to go, and
I have made sure it is possible in a reasonable
amount of time if making a couple of not too far
fetched assumptions. It's probably possible to solve
this one with fairly basic cryptoanalysis as well
though. OK, enough with the hinting, get cracking :)


Written in C++, WIN32. Tested on a couple of
different Windows XP machines.
