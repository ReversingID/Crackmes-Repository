Hello,

Alert:
This crackme needs a internet connection and will download programcode from the net.
You can't see this code in the compiled EXE, so it's your chooise to trust me or not.
I assure you that it's no virus.

Your task:
Try to imaginate that you are an employee of a company, you start your program that you got from your employer.
At first, you will need an account. For this write a message to me (http://crackmes.de/users/bunnx/) and
I will send you your login data.
Or for thoose who are to serios for playing childish games use noname:nopassword and don't get in the online employees list :(

Now you should be able to receive your messages in the program, read them to get your target.

I will write here what to do, too:
- Patch the whole program to a offline version.
- Includes that the messaging /employees list functionality is pachted out, too.
- The patch should avoid every contact with the webserver.
- The patched program should contain the menu and all dummy functions. (You will see what that's mean.)

All this stuff is explained in the crackme, too.

bunnX