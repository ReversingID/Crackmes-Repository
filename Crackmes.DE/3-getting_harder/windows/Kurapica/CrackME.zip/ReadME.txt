This is the 15th .NET crackme now and It's not too hard to solve but It still needs some brain, 
NO PATCHING is allowed since 2 bytes are enough to solve it. 
I need a fully working keygen and a tutor to show the rest of us how you solved it.

You may need some tools so check the .NET thread @ www.reteam.org/board for any help.