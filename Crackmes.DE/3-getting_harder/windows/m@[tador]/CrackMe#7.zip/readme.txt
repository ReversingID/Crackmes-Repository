CrackMe #7 by m@[tador]

Compiler: Delphi 6.0 (No VCL)
Packer: N/A

1. Find valid Name/Serial pair.
2. There are some anti-debug tricks.
3. Try to crack it. You can patch it.
4. Writing keygen is the best way to show your cracking skills.

PS: It works nicely on WinXP, but i hadn't test it on another OS.
    Meybe this crackme will not work properly on lower versions of Windows.

Good luck!
