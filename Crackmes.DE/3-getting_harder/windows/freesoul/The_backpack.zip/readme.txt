Bruteforce is allowed if you explain why you needed to use it.

There are also more than one way to bruteforce this... 
I need an elegant one!

Shouldn't be applied directly to the input ! which is a 32-bit integer.

Hint is: A918DFA5B7D6B