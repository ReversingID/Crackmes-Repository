This crackme has not protection, it's just my first crypto keygenme...

I think it's easy... ah, and if you need some help, try pushing the "Try what?" button =)

A valid solution is at least keygen + little explanation
Remember that there should be more than 1 valid serial for each username

Thanks for trying this crackme
freesoul 