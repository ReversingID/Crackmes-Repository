Hi ;>
It's my first crackme, so dont laught :)
In this proggie, u have to find the correct password.
I used my new 32-bit hash algo, so findind collision is not so hard :)
Patching is not allowed of course ;P
Have Fun & Good Luck
j00ru!