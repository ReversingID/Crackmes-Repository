CLR SerialMe 0x02 By Cyclops
http://cyclops.ueuo.com
http://crackmes.de

Again a small puzzle.
Your task is to find a correct serial. As the code is in C# .NET, the source can be obatined by Reflector.

The only obfuscation here is my coding style and the Visual Studio Compiler :D

Rules: NO Patching, NO brute forcing.

You may exploit some flaws in checking function if you can find any!

Regards,
-Cyclops
-Mera Bharath Mahan
