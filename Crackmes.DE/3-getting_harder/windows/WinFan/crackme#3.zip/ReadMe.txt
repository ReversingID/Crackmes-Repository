Difficulty: 3 - Getting harder
Platform: Windows
Language: Borland Delphi

In this CrackMe, you need to enter a random code. You can only Enter "X" or "O". The length of the code is 16.
Once you enter the right code, you will get the "Correct!" message.


Your task is to write a trainer which gives the right code to you. The solution must include the source code 
of your trainer!

