Information:
============
- platform: Windows
- written in C++
- many anti debug tricks

Rules:
======
- Generate a valid keyfile
- Patches won't be accepted


Good luck and happy reversing!
- MaxXor