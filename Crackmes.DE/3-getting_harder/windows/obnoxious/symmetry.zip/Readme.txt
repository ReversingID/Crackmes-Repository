Obnoxious - symmetry :)

Rules:
	1.No Patching
	2.No Bruteforcing
	3.Keygen With multiple serials for each name prefered.

I m not sure whether to rate this crackme as 2 or 3 so i wd rather rate it as 2.5. Crack it and decide if it sd be 2 or 3. Have Fun.

Greetz Fly out to all my friends @ Crackmes.de {cyclops, TiGa, br0ken, costy, Bikers80(wheres ya man?), w02057, b2c, darkenza.........}


Note:

If you dont have "windings font" installed this is how you sd infer the result

J == success
K == no result yet
L == failure