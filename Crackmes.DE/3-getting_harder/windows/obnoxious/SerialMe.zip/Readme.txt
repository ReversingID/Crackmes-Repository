## Obnoxious Serialme :P ##

this crackme took a long time in the making. i was too busy playing travian :P

valid character set [0-9] [A-D]

rules
no patching
no bruteforcing

Greetz fly out to cyclops, andrewl.us, indomit(no wonder you will be the first to try it), tornado, tiGa, jim~, br0ken and all my friends @ crackmes.de