This is a keygenme.
The objective is to keygen it.
2006.12.23 upb

the last version regrettably contained a bug
which made it 'unsolvable'.
Well it was still possible to solve it but
it would not print the correct goodboy
message.
Thanks to andrewl for solving it and finding
the bug :)

This is the fixed version.
2009.06.06 upb