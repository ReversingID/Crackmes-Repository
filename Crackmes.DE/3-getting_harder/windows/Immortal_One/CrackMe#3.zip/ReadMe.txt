 


   CrackMe #3 by Immortal_One
                                                                                                                                                  �
                                                   
   Type......: Crackme        
   Task Level: 2/10     
   OS.....   : win98/(any?)                               
   tested on : 98se               
   Date......: 26.03.2005 
   Protection: keyfile 
   Packed    : FSG 2.0 -> bart/xt 
   
        
 
   greetings to:                                                                                                                                            
 
   all hardcore asm coderz (crackers) & kao 4 cracking crackme2   

                                                                            