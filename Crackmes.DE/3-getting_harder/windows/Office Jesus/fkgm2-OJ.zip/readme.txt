Here's a simple crypto keygenme.

Rules:
1) Keygen + Tutorial is the ultimate goal
2) Self-Keygenning and Phishing are more than welcome
3) Patching is acceptable as a last resort

Please report any bugs...

Good luck,
oJ