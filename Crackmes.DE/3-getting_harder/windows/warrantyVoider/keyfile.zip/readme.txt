Your task is to create a correct keyfile.

I hope you have a lot of fun.

Breaking the string obfuscation is not necessary, break it only if you are really bored ;-)
