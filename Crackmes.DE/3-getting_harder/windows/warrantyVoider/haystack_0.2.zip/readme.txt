And now for something completely different...

You have to enter your name and a passphrase.
The passphrase is different for every name, but always a valid english sentence.

The interesting functions are "encrypted" in a simple way
and some nonsense jumps are generated into the encryption/decryption.

Have fun, write a keygen!


(This crackme builds upon the tech in haystack0.1. If you�re stuck have a look at haystack0.1 http://crackmes.de/users/warrantyvoider/haystack_0.1/ )