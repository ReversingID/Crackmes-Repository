Welcome to TheGame.

TheGame was tested on .NET 2.0 and .NET 4.0 (WinXP,Win7), should work on other versions too.
There are no roules how to crack it. Preferable solution is keygen ofcourse :).

Enjoy

|sas0|