	Name:		Knight's Crackme #2
	Coder:		Knight
	Difficulty:	4/10
	Language:	C++
	Packer:		none
	OS:		WinXp sp2 (others not tested)

	Rulez:
	Defeat it, write keygen working with all names and solution 
	and submit it at crackmes.de. NO PATCHING ALLOWED!!!

	Note:
	I'm very proud to present you my second crackme.
	Somebody claimed that first one was too easy. Check this one ;)
	Actually algo is weak, but i think many of u won't manage to find
	serial checking routine. Hope u'll see something new. Enjoy!

	Regards

	Knight, knight@d2sector.net
	2005 - 06 - 14

	2005 - 08 - 05 Update
	
	Some bugfixes. Tried to modify algos as less as posible.
	For some names one of values shoulded be negative, and there
	was no way to enter it. Fixed.
	For some names one of values at some point was odd, when
	needed even. Fixed.
	Fixed bug when due to font issues some people couldn't enter
	full serial (enable AutoHScroll for text boxes).

	To check it, Knightd at first was unkeygenable due to negative
	values. Here's serial for updated version: FF80B-66FFF-66000-00014-0382B

	Name aaaaaa at first was unkeygenable due to odd/even
	problem. Here's serial for updated version: 5F408-60000-60000-0200C-63418

	Now really all names should have serials. Anyway if u found bug, please report me.
	And sorry for all those bugs.