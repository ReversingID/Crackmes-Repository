CSDXCrackme by Crackersixx!
---------------------------

Requirements:
	* Microsoft .Net Framework + Managed DirectX

Tasks:
	* Keygen
	* detailed tutorial

Im going to set the diffculty on this one at around 3/10 as it is a fullscreen directx application. It also features some anti-ildasm code and obfuscation. (and it's packed)

The algo itself is rather lousy, but the point is to be able to get far enough into this crackme to see the algo.

In your tutorials, please give as much detail about how you were able to reverse this app rather than just explaining the algo.

Hope you enjoy this one, cause it was fun writing it :)

(sorry for the looped lo-fi music, I dont have a sound engine yet)

-C6
cracker_sixx@comcast.net
www.reversers.net

