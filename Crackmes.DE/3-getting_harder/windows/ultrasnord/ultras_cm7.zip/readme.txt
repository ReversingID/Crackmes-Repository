ultras's Crackme7
=================
Size		: 387.5 kb
Code		: Borland Delphi 7
Difficulty 	: 3, I Think.

To-Do :
1. Find Correct Password That Lead You To Good Boy Message.

RULEZ :
= No Patching.

Hint : 
- Password Is HardCoded,, But.....


If you found any bug or want to give some suggestion,,
or you want to ask me,,
just email me at :

ultras_muhsin@yahoo.co.id

= sorry for my bad english =