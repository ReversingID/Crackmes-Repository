ultras's5th crackme
=====================
Size		: 385.5 kb
Code		: Borland Delphi 7
Difficulty 	: 3

To Do :
1. Remove Startup Nag Screen
2. Find Correct Serial And/Or Making Keygen
3. Remove Exit Nag Screen

This is my 5th crackme,,,
so if you found any bug or want to give some suggestion,,
or you want to ask me,,
just email me at :

ultras_muhsin@yahoo.co.id

= sorry for my bad english =





  

       