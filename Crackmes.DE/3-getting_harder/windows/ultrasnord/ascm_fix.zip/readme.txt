ultras's Auto Shutdown v1.1 crackme
===================================
Size		: 412 kb
Code		: Borland Delphi 7
Difficulty 	: I Don't Know. 1-3 I Think.

This Program is Used to auto shutdown your computer,,
but you have to register or crack it to use it :),,

RULEZ :
= No Patching.
= Find Correct Serial.

Hint : 
- There Is No Keygen Routine ( Multiple HardCoded Serial).


If you found any bug or want to give some suggestion,,
or you want to ask me,,
just email me at :

ultras_muhsin@yahoo.co.id

= sorry for my bad english =





  

       