~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      << EASY MATH QUEST >>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Date & time: 16:26, 11.03.07
Author: Kostya
Level: 3 - Getting harder (maybe a bit harder)

-----------------------------------------------------------------------


Hi, It's Kostya, again :)
Now your target is my Easy Math Quest (EMQ). It's more easier than previous.
Here are some rulez:
1. Don't patch
2. Find passwords (all passwords to see the "Goood message")
3. Btw: U can brute :) { if it helps (: }
4. Write a solution.

-----------------------------------------------------
Have a question?! Found a bug!?

contacts:
a) http://blognow.com.au/kostya
b) ICQ: 183313
c) e-mail: kostya@mail.vu
d) message at www.crackmes.de

thanx..