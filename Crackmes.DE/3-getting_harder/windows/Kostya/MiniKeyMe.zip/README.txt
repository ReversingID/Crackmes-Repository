    _____________________________________________________________
   //////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
  ///////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
 ////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
/////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
________________________ {..Main description..} _______________________


Author: Kostya
Level: 3 ( or maybe 4 )
Name: Mini-Crypto KeyMe
Protection Type: Serial only
Lang: ASSEMBLER

___________________ {..Comments & some description..} __________________

Description: 
------------
 It`s so easy algo! It is easy as my previous one, So that's
why i don't want to give u any hints :). I recommend u to
think about it first, because the algo is so easy. U can try
to brute force it, but dunno if it works ;). And u aslo can
try to reverse it :).
 Huh! Maybe some C0FFEE helps u. :) Or maybe u need to teach
yourself some University math :-)
 
RULEZ:
------

1/ Try to write a bruter (if u can brute it)
2/ No patching! Ok!? :) (or loaders)
3/ Find correct Serial & enter it to see messageBox :)
4/ Plz, write a tutorial! :) (the main topic)

_________________________ {..Some contacts..} __________________________

Contact me: kostya@mail.vu  ||  PM me @ crackmes.de (Name: Kostya)
Greetz to all crackmes.de members !! Thanx to all :)