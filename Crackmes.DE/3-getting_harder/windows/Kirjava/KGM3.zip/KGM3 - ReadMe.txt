
/*		Kirjavas KGM3		*/

Hello fellow reversers! KGM3 is a very simple VM keygenme.

Rules:
1. No patching!
2. A valid solution has a keygen and a tutorial!

Extra info:

Just a very simple algo with some anti-analysis tricks.