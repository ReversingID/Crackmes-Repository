Hello dear reader, objective of this crackme is to write keygen
If you do not want to write keygen, fishing is just fine. 

Crackme is composed of 2 files:
              crackme.exe - fancy dialog Box protected with my debug protector
                            (if you are bored you may reverse it but it's waste of time)
                            (note: protecotr has a lot of changes and is not same as in
                            deroko's dump me)
                            
              ring0.sys   - everything is here (I know who will solve it and probably how
                            b/c of his earlier solutions at crackmes.de =) )
              
              readme.1st.txt - this file 
                                                
difficulty : 
              10/10 if you don't have SoftICE, syser or maybe IDA
              3/10 if you have these tools
             
           
***NOTE0****: Program is TESTED ONLY ON XP SP1 and SP2 but win2k should also work...          

Have fun...
                                                 S verom u Boga, deroko
