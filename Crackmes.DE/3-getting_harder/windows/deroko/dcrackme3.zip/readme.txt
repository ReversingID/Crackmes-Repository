Dump-me...

I was bored today so I wrote protector. Is has some nice features...

Not final, but b/c I don't have time to work more on it... "project" is pending

Objective:
dump file and fix imports...

3-4/10 ... 

                           S verom u Boga, deroko...
                           
                            



