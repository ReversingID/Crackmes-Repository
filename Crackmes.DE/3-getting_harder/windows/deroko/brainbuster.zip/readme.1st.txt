Here comes crackme (keygen) with a weak serial algo, but with strong 
anti-debug, I also think that 1 of 3 protections, that are implemented
here, you will see for the first time... So if you like it, please give
me some credits if you plan to use it somewhere, somehow =)

Well if this thinge would have some strong chipher to play with serial
I would rate it 6-7/10, but since keycheck is weak this crackme is 
only 3/10 =)

Tested on : xp sp2 and win2k sp4 (yap I got 'em both)

Patching? No, and here are 2 reasons:

1. I can, or better to say could, protect whole dialog proc so you
   wouldn't be able to make simple jmp to good/bad message, doh,
   I could protect them also so you wouldn't know where they are
2. I tought to give you hint by showing where are GetDlgItemTextA,
   MessageBoxA, and so on...
3. Patching won't give you password for .rar archive =)
   what is key for "brainbuster", well that's also your
   key for rar...
   
Code is writen completely in tasm32... the best asm compiler!!

Well that's it, happy cracking... and brainbusting...

                                            S verom u Boga, deroko                                        