
-----------------------------------------------------------------------------------------------------------------------------
						     Snake
-----------------------------------------------------------------------------------------------------------------------------

Date:				11 - August - 2004
Type:				KeygenMe
Difficulty Level:		Cracking 2/10 - Keygenning 5/10 (I think) :)
Programming Language:		Uhm... Opcodes, but just consider it as ASM ;)
Platform:			Win2k and probably below but i don't know about XP, i can't test it.
Compression/Encryption:		None, it's all plain visible.




Hi there "young eager minds of tomorrow",

Finally i've coded another CrackMe after such a long time.
I wanted to code a CrackMe for several months i think, but i never had any real original idea.
I don't know if this type of protection is really original but it just popped in my head today and so i coded it :)
Hmm, maybe it looks a little bit like KW's CrackMe...

Your task is to find a valid Serial for your Name, write a Tutorial of how the CrackMe works and then code a keygen.
There are multiple Serials valid for a Name and it would be wonderfull if you can code a keygen which gives the shortest
Serial for any Name, but this is not necessary :)

I think this is all i had to say (And i hope i didn't forget anything... ;).


Cya...

CoDe_InSiDe

Email:	code.inside@home.nl