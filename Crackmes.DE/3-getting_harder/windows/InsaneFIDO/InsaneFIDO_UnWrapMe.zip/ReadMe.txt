This is my first attempt at producing a crackme type app. So
please do not be too harsh with your criticism. I have tried
to be original with my code and techniques.

Newbies should find it a rather difficult challenge but I
do not think advanced reversers will have much difficulty,
although they may find bits of the code interesting.

The concept is similar to the Reflexive Wrapper used on games.
However, the concept is the only similarity with that wrapper
and I hope it is more difficult to reverse than it.

I coded it on Win XPSP2 and have no idea if it will run on
Win2000.  It will NOT run on Win9x/Me or Vista.

The unwrapped file should display with the XP theme on Win XP
but the wrapped version should not.  At least it does not on 
my machine.

Anyway, enough drivel.  I hope you have as much fun tearing this
apart as I had putting it together.

cheers
InsaneFIDO
