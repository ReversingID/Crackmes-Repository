Because my first crackme was really fast solved, I created another crackme.
I hope, it is a little bit harder.

The main target is: Create a keygen.

Have Fun!