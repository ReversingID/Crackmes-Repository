v1.1 - Correction on the serial check

A diferent crackme, that requires some basic math habilities...
Ultra clean code, some cool tricks and a cool algorithm. (:

Rules:
1 - Find the 24 valid serials;
2 - All the serials must work outside of debugger;
3 - No BruteForce;
4 - No Patching;

Enjoy it!