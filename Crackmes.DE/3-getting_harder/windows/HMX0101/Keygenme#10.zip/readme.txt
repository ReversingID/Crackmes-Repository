Another crypto-keygenme from me :p
This time is a little bit easy... if you know some things ;)

Solution = Tutorial + Keygen

Rules: 

	- Don't patch!!!

Greets to:
Ox87k, l0calh0st, Ank83, lord_phoenix, x15or, BugHunter,
and all people from crackmes.de, ARTEAM and iNFLUENCE forum...