===========================
HMX0101's CryptoKeygenme #1
===========================

This is my new crackme with a crypto-algo not so hard and easy
antidebugging tricks, this time is not for newbies.

To beat this crackme, you need:
	
	- Analyze the algo
	- Make a keygen
	- Write a tutorial

Rules:

	- Patching is not allowed.

==========
Greets to:
==========

Linden, _khAttAm_, l0calh0st, Ox87k, Ank83, TWiST, dila, moofy, ScR1pT_, 
KLiZMA, Kerberos, R.E.M, CracksLatinos, and all members in crackmes.de

===============
Regards,
HMX0101 / R.E.M
===============