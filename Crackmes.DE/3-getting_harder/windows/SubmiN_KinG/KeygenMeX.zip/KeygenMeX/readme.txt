KeygenMeX by n00b
-----------------
Just a simple keygenme for those
who are into .NET ;)

Rules:
------
1: NO PATCHING!
2: NO BRUTEFORCING!
3: KEYGEN ONLY!

Rating in difficaulty: 3/10!

/n00b