a Tutorial must include:

How you unpacked the program

How you cracked the program

How you found a serial

DaXXoR101@gmail.com