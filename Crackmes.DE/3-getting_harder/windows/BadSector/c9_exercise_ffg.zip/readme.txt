Exercise crackme (fixed4good)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

believe it or not all bugs have been
removed and it works fine now.

only thing that is missing is keygen
but that's your part. get to work now...
yes i know you could do it a long time ago...

tnx to black-eye, bf!, and mario