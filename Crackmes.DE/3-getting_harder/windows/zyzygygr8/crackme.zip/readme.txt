This is my first crackme .

The task is very simple.When you run the executable,you will see a message,the objective is to change the message to anything ,without generating an error. 

Patch the way you want to,but it should display some other message.

Please let me know about the crackme. Thanks :)

Let me know if I can improve it.

Language: Win32Asm

Greetz:all i know,stew2 @ #win32asm for helping me out from the mess, and #win32asm,people behind crackmes.de ,board,everything.

I would rate this as a 4-5/10 crackme(not sure though :P )

Mail the tutorials to :

zyzygygr8atyahoodotcom

