CrackMe of medium difficulty (I think).

I am a Swiss student in computer sciences, doing his diploma on software protection. I would like to know what you think of the following software protection I have been developping.

I believe it is quite difficult to understand how it works and how it is possible to crack it. You can use whatever you want to break it, even patching the software if you need to.

I'll be very happy to read your solutions or your thought on this protection.

The software uses an evaluation period system, and the license used is stored in a file. Of course a license is tied with some hardware. What should be hard for you to figure out is that there is a random delay before the licence is validated, so it's quite hard to find the code used to validate it. But I would not say more, you'll have to figure it out for yourself.

In case you are not able to start the software you have to install the Visual C++ 005 Redistributable Package, available here: http://www.microsoft.com/downloads/details.aspx?displaylang=en&FamilyID=32bc1bee-a3f9-4c13-9c99-220b62a191ee

The demonstration software displays jokes (in French I'm very sorry for that) and, in case you are not registered, it does not display the end of the joke but instead a text saying that you have to register to view the full story.