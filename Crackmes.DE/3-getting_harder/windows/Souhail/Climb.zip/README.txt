Crackme by : Souhail
http://rce4fun.blogspot.com

Try to find the flag inside the crackme. You've got all the resources you need to complete this challenge within the binary.

Good Luck...