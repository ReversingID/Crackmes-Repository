Hello!
This is crackme written in Visual Basic 6.0
This one is not so simple, because it uses the features of VB6, make it difficult to reverse it.  
