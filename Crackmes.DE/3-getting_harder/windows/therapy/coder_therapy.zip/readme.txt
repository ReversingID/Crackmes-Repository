 -------------------------------------------------------------------------------------
  Program: Coder Crackme
  Author: therapy
  Protection: password 
  Difficulty: maybe 2-3/10 (because of being out of the ordinary)
 -------------------------------------------------------------------------------------

  Hi there!


      Here's my new crackme, where you'll have to 'code' in some kind of language to
  solve the puzzle. There is nothing special in this crackme, no encryption, special
  trick or anything, and you won't learn anything new if you solve this. But it will
  surely test your brain and thinking! This is both a coding and cracking challenge.
  Anyway, I better like those crackmes which focus on fun:)
      
      If you start the program, you'll see the Result group. This will inform you
  about your program code. You have solved the puzzle, when the bottommost line 
  contains 'TRUE'. By then, you'll see why :)
  
  Hints:
      * try to analyze the program as a whole, deadlisting is useful here. The code
        is pretty organized and straightforward.
      * try to "extend your field of view" and use the instructions you are given
      * some instructions have parameters
  

      If you think you solved it, found a bug, or just need a hint, don't forget
  to mail me at therapynet@hotmail.com.


  Greets,
     therapy
