Find a valid s/n and keygen it.
CrackMe by ~Hellsp@wN~
Date: 02.08.2004