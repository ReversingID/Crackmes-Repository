Gen A KeyGenerator

CrackMe #4 by vhly[FR]

Update for the My Loader class 's bug of String.replace("","")

to change it is String.replace('.','/');