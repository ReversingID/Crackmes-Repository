 BoR0's first crackme

Task is to remove nag at startup and to change the message after progress bar fills. It is very challenging because its manually packed and thanks to X-Loco for telling me how. Its packed twice, so watch what you are doing. After unpacking and done, you might see some funny messages (strings) in hiew while editing the program ;)

Thats all for now, see ya next time :-P

Thanks to:
X-Lock, Detten, chainie, Zephyrous, kiyo, L_Anshar, newt
and everyone from BiW and LocklesS

copyright (c) july the 2003