Long time no see i suppose...
I finally found my way back to crackmes.de ;)

Here i bring you my 'Keygen Me #2'.  As always my crackmes do not hold very difficult algorythmes. It's not different this time, yet the fun is in getting there :)

So go ahead and have your share of fun on this one..

The rules,as usual:

-> NO patching
-> Code a keygen
-> Have fun


Scarabee '03
scarabee_5@hotmail.com

