CrackMe-4 by synapse
--------------------------------------
Written in SpAsm 4.15c

Type: Serial/KeyGenMe?

Protection:
- you'll just have to find out -

Objectives:
- get a valid serial
- make a keygen <--- if the crackme is keygennable - im not sure if it's keygennable -
- make a tut
- submit zip file(keygen,tut) to www.crackmes.de / to me(optional)

Rules:
- no patching!

Another crackme written by me... this is my first serial crackme... it's just a normal serial crackme.. no anti stuff.. no compression/encryption.. but it's kinda hard.. i dont know if this crackme is keygennable.. if you managed to crack it(of course you can!), please make a keygen and a tut.. put it in a zip file and submit it to www.crackmes.de... and if you want to, you can send it to me also... happy cracking!


- synapse [markz_a@yahoo.com]