 
 (o_
 //\  <--a penguin
 V_/_  

RooJ Crackme 2

Your Goal:

No patching on this one. Make a keygen and a tutorial on how you did it. Theres no debug protection or anything so feel free to use all tools at your disposal. send your tutorials to me @ quibus_umbra@hotmail.com

Happy Cracking :D

RooJ.

========
for every coder, theres an equal and opposite decoder.