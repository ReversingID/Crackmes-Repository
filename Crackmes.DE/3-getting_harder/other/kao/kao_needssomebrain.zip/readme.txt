Hello!


Another  month,  another  crackme... I made this to be a bit
harder  than previous one. No crypto but math knowledge will
help much. 


You must write a keygen, that generates valid serial for any
name  entered.   Patches  and  serials  do  not  count  as a
solution.  Please  TEST  your  SOLUTION  with LOTS  of names
as there might be some "problems". ;)


It  would  be  really  nice  to see a tutorial about how you
reversed/keygenned it.


There is no need for brute-force. Just use your brain if you
have some. If you don't, ask your friends for help. ;)


Happy New Year!
		kao

Riga, Latvia, 2003
kaspars@hotbox.ru


Greets in no particular order:
	Roma (he was first to send solution for JustStarted)
	elfZ (would you like some more vodka? I am still on vacation :)
	OorjaHalt (try to crack this one.. )
	7of9 (for discussion about JustStarted)
