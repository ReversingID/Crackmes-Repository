================================================================
             MADE BY Ap0x on 8:50 PM 11/30/2003
================================================================
Hi folks, and welcome to my 5th cracking challange :)
Note:
 Program is written in VB 6.0 so you have to have 
 msvbrun600.dll to run the program. To crack the
 program you have to generate a key file, find the right
 serial and matrix code :) YEA enter the Matrix... To make
 it harder i added a special little thingy :) So do not trust 
 every serial that pops out in EAX.... It wont be too hard to
 crack i would give it level 3/10

 If you crack this progi please mail me tpericin[at]hotmail.com
 and describe your way of cracking...

         NO PATCHING ALLOWED.... JUST GET THE SN :)
================================================================