;----------------------------
;Crackme #1 "locked" by Crick
;----------------------------
; Julio / 2001 - Revised August / 2002
;-------------------------------------

The solution must be find a good serial. Crackme tells you when your serial is correct.

Exe isn't packed to easy the task ;)

Tutorial needed to pass this crackme.
No manual-patching allowed.

Warning! there is an encrypted executable zone. Be careful to execute without decryp.

Enjoy!

Crick. (Send tutos to: crick@wanadoo.es)