Try to write a valid keygen for this crackme.
If you manage to do this without patching, then
feel free to send a tutorial+keygen to me or http://www.crackmes.de

Difficulty : 3/10

Good luck :)


r_etarded@yahoo.com
-------------------------------
Greets: (in no particular order)
cik siti, Ancient_One, Kwai_Lo, ManKind, Bengaly, ytc, snaker, fuss, 
Detten, chainie, Unpacking Gods crew, Stingduk, iesha, _pusher_, 
loco, kiyo, cluesurf, Goofy, BiW-Reversing team, and all 
crackers/reversers out there..