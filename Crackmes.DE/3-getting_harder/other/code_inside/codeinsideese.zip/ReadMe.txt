Hi there,

Welcome to my "Extra Security Encryption" (ESE) Crypto Algo :)
Your task is "simple":

Try to Decrypt the file "Encrypted.txt" :)

To do that you need the right "Key" ofcourse ;)
If you encrypt a file, then that existing file will be overwritten.
when you then try to encrypt the encrypted file with the same Key
that file will be decrypted again ;)

Hope this explains enough, now try to break it ;))
When you broke the Protection send the solution to my Email and to the
CrackMe website.
My Email will be revealed when you've broken the Protection ;)
To anyone that knows my Email, don't ask me anything i will *NOT* help
you hehehe ;P

Have Fun!

Cya...

CoDe_InSiDe