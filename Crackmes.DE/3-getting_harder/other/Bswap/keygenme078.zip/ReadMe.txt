KeygenMe 0.78 notes,

The Program is 100% written in Masm 7  (all you need).

Goal : Try to make a key maker level (3/10).

In this keygenme you get a private key (the same idea as 0.77). 
But the program is rewritten and the key check is new (just 443 bytes).
If you manage to calculate one key, making a key maker
would be an easy job for you. This was just for private fun and training. 

And the usual disclaimer:
Whatever happens when you running this program, 
I'm not responsible for anything.  
  
If you have any comment or questions please mail,

goodwill80@hotmail.com

I want to greet everyone who knows me.

Cybult , Blue Mind, Detten , Tomkol , ^L00P , Iczelion , Kwasek, 
Harlequin, Thigo, Roy, muaddib and Zero.

Bswap.
Holland - 2003
