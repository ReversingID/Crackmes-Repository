#################################################################
# : By TNTCoder
# : Basic KeygenMe
# : Level 3/10
# : Algorithm - Simple as i could keep it, within limits ;)
# : 20\02\04
#################################################################
#
#  Heres my first KeygenMe for crackmes.de, tried to keep this
#  as simple as possible to help out newbies, coded in C++ so
#  shoudnt cause to many problems. As i said algorithem is on a
#  very basic level. Rules, just no patching. 
#  Requires Keygen and explanition of key generation.
#
#
#
#
#
##################################################################
# Contact me : tntcoder4@hotmail.com
##################################################################



