aerophagia's secret crackme :P

Just make a working keygen. no patching etc allowed.