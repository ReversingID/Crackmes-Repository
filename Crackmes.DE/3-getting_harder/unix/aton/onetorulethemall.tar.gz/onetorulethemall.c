#include <stdio.h>
#include <unistd.h>

// onetorulethemall.c 2006 by aton@packetdropped.org
// rules: no patching

void done(void)
{
	printf("Cracked!!!\n");
	printf("you are the lord of the base pointer\n");
	exit(0);
}

void myprint(char *str)
{
	char buffer[100];
	int n=0;

	for (n=0; n<=100;n++)
		buffer[n]=str[n];

	printf("%s", buffer);
}

int main(int argc, char *argv[])
{
	if (argc>1) myprint(argv[1]);

	return 0;
}

