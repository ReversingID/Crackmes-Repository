A very simmple little crackme for you but hopefully an entertaining one.

I dont want to give to much away but suffice to say that you have to put the pieces together to make your com program.
You will get the password for opening the zip file if you are successful.

Harlequin 1/2003

Harlequin_h  hotmail


