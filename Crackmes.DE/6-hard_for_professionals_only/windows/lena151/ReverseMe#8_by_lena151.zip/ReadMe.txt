ReverseMe#8bylena151

Goal is to register the ReverseMe. This is visualised if it says at startup "REGISTERED to:" followed by the name you registered it for.

Mostly byte coded in assembler (masm).

Not packed. 

You may either patch, fish or keygen. Obviously, no aesthetic-patching-only!  More info in About box.

On a sidenote: it was also a challenge for me as I had never byte coded such a long part in one target. Don't be surprised when you see the disassembled file in a debugger!

Info: it's not the algo that makes the challenge! The algo is short and easy, the real challenge lies elsewhere! 

If you have a solution, please explain how you did it.

Success and have fun!

Regards,
lena151.