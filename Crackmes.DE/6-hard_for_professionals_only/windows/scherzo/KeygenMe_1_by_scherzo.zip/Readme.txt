Welcome to a very interesting crypto-math KeygenMe!!!
Probably, you will see some new things for you, I hope.

Objectives:
	- Understand the algorithm
	- Write a tutorial
	- Make a keygen

Rules:
	- No patches

OS:
	- This KeygenMe work perfectly only with Windows2000 and WindowsXp

Enjoy it and good luck!!!
You will need :)

scherzo