Hello!

This is my another keygenme. Your task is to generate keymaker. Some parts of this keygenme are not reversible, so you might have to patch some values (no code patching though).

Don't give up! You will need an extensive knowledge of cryptography and mathematics to solve this one.

Best regards,
tamaroth
