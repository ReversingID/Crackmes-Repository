
Kaine#5 - 20/05/2005



!!! AVERTISSEMENT !!!

- Avant de lancer ou d'analyser cet executable, sauvegardez vos travaux en cours ! 
- Ce binaire ne tourne que sous windows 2000 et XP et n�c�ssite des droits administrateur.
- Certains antivirus consid�rent ce binaire comme un malware. Il n'en est rien, libre � vous de l'executer ou non.



!!! RECOMMANDATIONS !!!

- Est "incompatible" avec SoftIce (crash de la machine)
- Ne fonctionne pas sous VM. Ca n'est pas une protection mais une incompatibilit�.
- N'aime pas non plus les debuggers ring 3 :)
- N'aime pas trop Armadillo :p



!!! REMERCIEMENTS !!!

Je tiens � remercier tr�s chaleureusement les personnes suivantes :

- Neitsa, un de ses anti debuggers maison (et in�dit !) a �t� int�gr� au binaire.
- Yolejedi, il m'a aid� � beta tester le binaire et � corriger un bug. Un grand merci :)
- Deicide, parceque c'est Deicide :p (Tchin ;))
- BeatriX, Kharneth et elooo, car ils ont la facheuse (mais n�anmoins bonne) habitude de p�ter tous mes crackmes :) J'esp�re que vous serez pas (trop) d��us.

Ainsi que les personnes suivantes pour leurs encouragements, leur travail et leur sympathie :

Kef, TTO, lautheking, Crisanar, Holyview, Deamon, yarglub, Kaz, Genaytyk, meow, mimas, GBillou, SynApsus, mars, tous les membres de ForumCrack, les geeks de #UCT, et tous ceux dont j'admire le travail mais que je n'ai pas l'honneur de conna�tre...


J'esp�re que vous prendrez autant de plaisir � casser cette protection que j'en ai eu � la coder :)

Amusez vous bien !

Bonne journ�e.


Kaine.  

