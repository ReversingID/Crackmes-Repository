These are the crypto challenges from Shmoocon
2010's "Ghost in The Shellcode" CTF event:

http://www.shmoocon.org/gits.html

Goal was to make algos that can be grasped
quickly (minimal reversing), but remain
challenging to keygen.

crypto3.exe: difficulty 2
crypto5.exe: difficulty 3
crypto1.exe: difficulty 3
crypto2.exe: difficulty 4
crypto5.exe: difficulty 6-7

They only had room for four, so crypto4 was
left out, being the most difficult. I will
give you some major clues on it: there is no
scheme in the system, no trapdoor. It's pure
math. The function is a bijection. Remember
that an extension field is a vector space
over its ground field. Source is provided
also.

Example codes are given in each respective
crackmes' GUI.

Keygen for them all is only solution!

--
andrewl
jan26_2010
http://crackmes.de
http://andrewl.brainstemprojects.com



