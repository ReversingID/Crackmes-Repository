
 elf'z crackme 4
---------------------------------------------

  Kind:       register-me
  Platform:   win
  Language:   fasm
  Packed:     nope
  Protected:  slightly
  Tested:     WinXP, virtual W2k, virtual W98
  Difficulty: 4, really NOT newbie-friendly


  Here's  a  little toy for all you to play around. All you have to do
  is to get this program registered. And, of course - no patching! :)

  As  usual,  after  you've done with this, you may access the sources
  and  a  little greeting from me in the archive. The password will be
  whatever  the  stuff  is  required to get this program registered to
  grandmother.  And,  I  sincerely  hope  that I won't have to see the
  solutions  which start by stating the zip cracker used to get to the
  sources (been there, seen that).

  And,  my  slight  apologies to all who expected to see the sequel to
  "elf'z crackme 3: ancient crypt". Maybe next time :)


  Best regards, and good luck - 

  elfz <elfz@laacz.lv>
    
    05-Feb-2005,
    Riga, Latvia
    http://elfz.laacz.lv



