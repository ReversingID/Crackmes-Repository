       Bust Me #1
-------------------------

Packed with Invius v1.0a (written by me).
Unpacking this should be a challenge.

I am looking for a place to host Invius online.
If you are willing to host the program, please contact me.

Find a serial for your name. 
A keygen would be nice, but is not required.

This crackme will only run on Win2k or newer.

-------------------------
B.P.X :: bpx_crk@yahoo.ca