Started few months ago, I have decided to release my third challenge: The CrackGenMe #3

As usual, no rule:
- For noobs => Display the "Good boy" message
- For crackers => Find a serial and solution for The Square
- For warriors => Make a nice keygen (for the serial and The Square)
- For Gods => Same as warrior but with a nice tutorial

I hope you will be numerous to try and succeed this challenge.
It has been really hard to code, so I hope it will be hard enough to debug.
I have done many tests so I hope you won't have problem.

I really hope to have a solution for this challenge.
It would be the best gift you could do for me because I spent many time to code it.

Have fun with my last challenge.
