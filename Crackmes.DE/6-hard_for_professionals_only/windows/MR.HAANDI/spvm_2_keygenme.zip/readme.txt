Welcome to the second Spvm keygenme.


The VM itself grew a little and,
again, some math skills are required to solve this one.

The mathematical method behind this crackme
is also used in mips' crackme, which was fun to solve.


Rules:

   Find at least one valid serial for the given userid.
   Do not exploit the vm if you find a weakness.




Greets:
bLaCk-eye, KernelJ, jB, divinomas, halsten
and other great reversers out there.


My info:
Email: mrhaandi@gmail.com
Homepage: http://mrhaandi.thecoderblogs.com/
