It's been 4 years since my last (failure) keygen here are crackmes.de,
I've spent some time to redo my mistakes and I can finally introduce my second KeygenMe/PatchMe.

If you cannot write a keygen, you could always puzzle your mind with a patch.
patching would be very diffucult unless you understood the keygen process itself.

Have fun!

