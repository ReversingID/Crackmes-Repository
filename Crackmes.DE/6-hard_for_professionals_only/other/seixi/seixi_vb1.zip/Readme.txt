
VB 6.0 CrackMe

Not for beginners but quite easy for advanced beginners.

Tip: don't be too happy when you enable the "Register" button ;-)

When you crack it please send me valid serial to Seixi@Mail.com and i'll include you in next crackme "Greetings"

Thanx for reading this, hope u have some fun.


					Seixi




				Seixi@Mail.com