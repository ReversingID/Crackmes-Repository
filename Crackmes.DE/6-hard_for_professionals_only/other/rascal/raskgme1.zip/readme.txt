- RaSCaL's Keygenme #1 (31/10/01) -

Few words:

Not much to say... Keygenerator is the only solution accepted.
Executable is simply packed with UPX v1.07 (i dont really care about
unpacking it .. do as you wish). Only thing is for sure: you MUST
use your brain ;)

If you have any comments/solutions you want to share with me,
here is my email address: cracker-rascal@hushmail.com

Good luck,

RaSCaL / TMG