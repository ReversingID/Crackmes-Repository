Crackme 9 by ThrawN
-------------------

Yet another crackme in such a short time. This will be the last of the useless stupid algos iv used since Version 1 ;)

Dont patch dont make loaders dont give up. Email me your working keygen or your working name/serial combination. Make a tutorial so others can understand its inners.

Greets out to: (In no particular order)
FANTASY, DiSTiNCT, eMINENCE, MrFrost, SP33D, Y0ke, Seifer666, Warezpup, BuLLeT, Carpathia, and the rest i couldnt be boffered inserting here.


ThrawN  *+* FANTASY *+* DiSTINCT *+*
www.thrawn.da.ru thrawnc@hotmail.com