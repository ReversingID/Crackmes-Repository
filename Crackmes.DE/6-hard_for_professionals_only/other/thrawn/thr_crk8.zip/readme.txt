CRACKME 8 by ThrawN
-------------------

This is a keygenme and nothing else. Dont boffer getting a name/serial or patch cause thats not the point :) i found my serial after 3 lines of debuggin. 
Make a 100% working keygen and solution.

This may be a little hard for newbies to understand so maybe its not a learner level?
Make sure your keygen works 100% (Most experienced crackers will probely find out why).

Send solutions to thrawnc@hotmail.com

Greets out to: (In no particular order)
FANTASY, DiSTiNCT, eMINENCE, TNT CRACKERS, Mrfrost, SP33d, Y0ke, ASAR, The_morph, Seifer666, Warezpup, BuLLeT, tE!, and all other wh0res i forgot to mention.


ThrawN  *+* FANTASY *+* DiSTINCT *+*
www.thrawn.da.ru thrawnc@hotmail.com