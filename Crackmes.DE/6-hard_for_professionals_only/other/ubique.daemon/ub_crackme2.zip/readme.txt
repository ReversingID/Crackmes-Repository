Ubique.Daemons CrackMe #2 ReadME

This is my second CrackMe, so maybe there a little more ...
I'm just trying to get along with Visual Basic / C++.
You will need the VB6 Runtime FIles, I think. 
You can find them where you got this crackMe. 

Try to find the right serial for your name.
If you found it, write a keygen or a tutorial on it.

Mail your solution to me (ubique.daemon@gmx.net) and to there where you got it from.

The next one is soon to come
