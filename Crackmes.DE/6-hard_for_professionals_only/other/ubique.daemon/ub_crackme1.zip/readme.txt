Ubique.Daemons CrackMe #1 ReadME

This is my first CrackMe, so don't expect that much of it. 
I'm just trying to get along with Visual Basic / C++.
You will need the VB6 Runtime FIles, I think. 
You can find them where you got this crackMe. 

Just enter a serial and test if it's right. 
There a more than a few, so maybe you get it by testing. 
Maybe you should use SIce to get it.

Mail your solution to me (ubique.daemon@gmx.net) and to there where you got it from.
Try to KeyGen it, write a tutorial, bla, bla, bla, ...

The next one is soon to come

inter arma enim silent leges
