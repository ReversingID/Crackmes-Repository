Hi there, this is my first crackme i hope ya like it.

Rulez:
   - You have to make a keygen not an patch or reverse engineer it!
   - Make a nice tutorial in where you explain how it works.
   - Mail me the keygen (yours) and the tutorial.

This crackme got 2 levels well actually 3 but the last is really hard i think!
I've included an keygen i made so u guys can see that it can be done.

Protection(s):

- Name
- Serial
- Algoritmic scheme

And it's written in VB 5

Email: webmaster@logik2000.com

have phun and good luck.