No patches plz only keygen. The algo is simple :)

Written in VB5, anti smartcheck
Please send your tut to hasher666@hotmail.com