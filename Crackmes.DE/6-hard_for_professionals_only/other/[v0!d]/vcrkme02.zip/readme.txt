[v0!d] - Crackme v0.02 :
~~~~~~~~~~~~~~~~~~~~~~~~
[This crack me is totally written for newbiez]

RuleZ :
~~~~~~~

1. Patching is not allowed.
2. Find the correct code.
3. write a tut (with boring details), send it to me with the correct code
4. making a keygen is optional 

that's it!

P.S : to all advanced crackers plz don't try to crack this
cuz u will really be wasting ur time !!! :P

send ur solution to : v0id2k1@hotmail.com
cya
[v0!d]