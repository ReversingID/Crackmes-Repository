r0m4n's crackme 1
______
||rulez||
none!!!
__________
||protection||
the crackme is coded it delphi and is packed.

when you're done send a keygen/tut/serial&name to r0m4n@yahoo.com

greeting to
every cracker in the world!!

r0m4n
