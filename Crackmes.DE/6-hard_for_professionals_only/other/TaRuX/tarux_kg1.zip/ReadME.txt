-------///--------------///--------------///--------------///--------------///-------
------///--------------///--------------///--------------///--------------///--------

                                       TARUX! KeygenME#1

---------------------------------------

 Coder     : TaRuX! [17 Years old]
 Email      : kallida@caramail.com
 Country : Morocco
 Date      : �28-�08-�2002 13:04 GMT
 Level     : YOU DECIDE !! (I estimate 4-6/10)

-----------------------------------------

 Hello everyBody !! this is my first crackME !!
 Send solutions (keygen I prefer) 
 with the name of compiler and packer to  : kallida@caramail.com

 RULZ            : NO CRACK !!! , NO PATCH !!! , ONLY KEYGEN !!!!
 PROTECTION :  Unique ID ...
                        a routine to calcul serial 
                       (this routine include Unique ID in calcul)
                       and .. ???????????????????

-------------------------------------------

Thanks to  :
  - all members of arab's-gate forum who opening my eyes to this new world ...
  - Krobar for it GREATE website where I have learned a lot of thing !!!  

