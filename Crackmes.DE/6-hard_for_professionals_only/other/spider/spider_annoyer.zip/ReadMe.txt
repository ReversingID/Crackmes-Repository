                            Annoyer                     ;Date: 25/03/2002
                                    by Spider

Hello everybody! In order to solve the crackme, the goal is to remove
the annoying nag.
You can use all the tools of this world.

I hope you'll like it.


                               GREETINGS
 AndreaGeddon, Quequero, +Malattia, Yado, [kill3xx], TheMR, Bubbo, Case, 
albe, _Blackdeath_, ph0b0s, Cieli Sereni, DsE, cHr, True-love, Quake2^AM,
 CrazyKiwi, _d31m0s_, Ritz, Pbdz, x86, NikDH, Dark-Angel, Giocrack, Dades
                 CyberPK, unics, my friend BluDestiny,
   RingZer0's crew, UIC's students and #crack-it's e #asm's frequenters.


For any comments, critics, greets, reproaches, questions or
other mail to: spider_xx87@hotmail.com

Byeez,
   Spider

e-mail   : spider_xx87@hotmail.com
my URL   : http://bigspider.cjb.net

UIC's URL: quequero.cjb.net
