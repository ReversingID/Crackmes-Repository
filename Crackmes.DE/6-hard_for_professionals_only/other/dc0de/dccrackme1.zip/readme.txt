First crackme by dc0de.
08/04/2002(UK)
04/08/2002(US)

Name/Serial protection.
Coded in Delphi.
Executable is packed

1. Figure out the protection and write a keygen.
2. Then try patching it to kill the Nag.
3. Patch it so you can enter any serial(probably easiest thing to do)
4. Have fun.