Hi there. This is my third crackme. You have to destroy the nag screen, find the serial for your name, make a keygen and send me the solution or at the crackme's website. Pay attention to "a trick"...

Italiani, visitate il mio sito a http://www.thehellsite.com/

The Hellfish 2001