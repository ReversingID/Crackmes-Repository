Hi Welcome to my second Crackme.

This one should be a little easier than the first :-)
Written in W32asm it shouldn't be too difficult at all but hopefully entertaining.

Your objective is to produce a valid Name/Serial combination.

There is no patching allowed and you will grow old brute forcing ;-)

A valid combination will earn you the password to the attached HCrkMe2RAR.exe file.
This contains the source code and an explanation of what I did.
An idea taken from f0dder but pretty good for checking your work too :-)

I would not try brute forcing the .rar either I used rar instead of .zip for its password
strength. I will tell you now the password is longer than 10 digits contains Alpha
upper/lower and special characters. Don't waste your time its easier to crack the program.


Please write me your solution at: CrackMe2@Harlequin00.cjb.net


Hope you enjoy


Harlequin