Niftybitz presents on 06-03-2002:

CRACKMEISTER v1.0
-----------------

This crackme is once again a DOS one, because i like writing DOS crackmes. It's
written in pure 80x86 assembly code and does not contain stupid anti-softice tricks
or other stupid tricks like fake jumps and such.

To successfully crack this thing, you will have to succeed in following these rules:

1. Generate a valid password, which prints the success message on the screen.
2. NO PATCHING ALLOWED! I REPEAT -> NO PATCHING ALLOWED!

I also implemented some stupid own invented (invented while coding:)) anti-tampering
routine, to scare off REAL newbies, as a non-real newbie, would also circumvent 
this non-working trick.

Send me the solution in the form of the sourcecode of a program which generates a 
valid password. The language the program is written in doesn't matter.

Please note:	

i've already written a solution for my crackme myself and it's not difficult once
you know what's going on.

A hint:

In generating a password quickly, it would be wisely to know the length of the password!

Happy hunting!

Ciao,

Niftybitz.




