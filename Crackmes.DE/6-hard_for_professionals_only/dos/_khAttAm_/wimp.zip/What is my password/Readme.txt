Think you are good at finding passwords??
Try finding an appropriate password/serial for this dos application.