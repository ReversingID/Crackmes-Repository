HyperUnpackMe1
++++++++++++++

HyperUnpackMe1 is a packed notepad.exe  

Your job is to unpack it. It is protected with my software protector.

Happy unpacking!!!!!

TheHyper