You need to find the correct USERNAME and PASSWORD to login

! pay attention to the title "ID : number" (and it's input/output) and attributes ;) <-- little help

Q / A


- Patching?

 * You may patch this app but the goal is to get the correct usernam and pass
 
- Ollydbg and smartcheck friendly checkox?

 * Some little help to shut down the olly and smartcheck killer
 
- p-code ?

 * no it's native code ;)
 
 
