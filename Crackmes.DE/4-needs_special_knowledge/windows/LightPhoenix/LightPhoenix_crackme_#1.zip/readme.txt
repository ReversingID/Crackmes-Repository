	Name:		LightPhoenix's Crackme #1
	Coder:		LightPhoenix
	Difficulty:	4/10
	Language:	C/C++
	Packer:		none
	OS:		WinXp
	Date:		06/19/2005

	Rulez:
	Solve it, write keygen & solution how you did it.
	NO PATCHING ALLOWED!!!

	LightPhoenix - light.phoenix@gmail.com