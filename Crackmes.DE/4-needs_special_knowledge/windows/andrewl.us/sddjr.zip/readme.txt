SDDecoder keygenme by gbe32241 is a truly amazing work, worth anybody's examination.

In this knock-off, the strengthening factors are removed, namely:

- the input and output transforms are separated from the core function
- the key size is reduced from 128 bits to 64 bits
- some other minor simplifications

Here is a list of example codes.

0B9406A6A5CF8D68
7C2E3DC7A9357094
04FEB466BEDCDB92
21E55E6A6B309F70
A8FAC8E4DF56C998
D597329D34D0ED3A
33D0A0EA1092124B
28AC66DD28697C52
1E380939AF1BF545
4FC1636FB7EEAFB0
93B2C52E2B77BD8F

andrewl
crackme.de
sep9_2009

