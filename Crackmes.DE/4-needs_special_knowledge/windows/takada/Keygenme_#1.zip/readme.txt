#########################
Takada's Keygenme #1
#########################

This is my first crackme
No packers are used
But I think, it is too hard for keygen

Intro:
Input all data 
Press Enter
If you receive a message Then you are good cracker
Else
You are bad cracker


To beat this crackme, you need:
	
	- Analyze the algo
	- Make a keygen
	- Write a tutorial

Rules:

	- Patching the goodboy jump not allowed.

Sends tut and keygen to my mail : takadaviet@yahoo.com
