Hi!

This is my first crackme ever, and I think it's not too easy.
It has some homemade crypto/hashing stuff and a few other small surprises. :-)

A working keygen would be very nice. (selfkeygen should be impossible)
Crackme was tested on Win2k & WinXP, 9x is not supported.

Have Fun...

contact: phewled[0x40]gmail.com
