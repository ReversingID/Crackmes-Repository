Keygenme 2008 v1.0
Crosys
crackmes.de
-------------------------

Main-task: make a keygenerator
About the protection: crypto

-------------------------

Greetings: 
Knight, r0ck, HMX0101, smoke, Cyclops, TiGa, zairon,
red477, Zero, dwarrior, Ox87k, Guetta, lord_Phoenix, jB, bLaCk-eye..(+ those i forgot)

And a special greetings to all crackmes.de members who is supporting crackmes.de
Thank you.
