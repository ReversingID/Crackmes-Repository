crackme.exe    The crackme
crackme.ini    Ini file used by crackme
crackme.???    RegKey file used by crackme (missing!!! - this is what the customer gets after payment.)
crackme-o.png  Image of unlicensed/uncracked
crackme-c.png  Image of licensed/cracked
user?.zip      PLEASE DON'T OPEN*

crackme.exe is a little "Hello World" demo of my new ShareWareProtection. It's written in PureBasic. (Both crackme and the encryptor)

In this little demo there is no RegInputMask so you have to edit crackme.ini - and you have to find out what license key is missing and where crackme it takes from.
I hope there is no way to get it running without the key!  ;)

Of course you can buy/license the sw (open user?.zip) and build a license free copy!
But i want you to crack it and make a copy without user name in the title bar.
Or write a KeyGen to create your own crackme.??? RegKey file. But don't use user?.zip to help you doing this!

Have fun!

*Please don't open user1.zip or user2.zip until you cracked it! - It's the key!

