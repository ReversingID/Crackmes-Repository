Crackme 4 #Hard By ZloY
----------------------------
+ Crackme Packed UPX 2.93w !
----------------------------
Find GOOD Code and contact me for ICO then give prize :))
GoodBye !

17.03.2007(c) ZloY