Here is another one. Every name has 2 serials, so it would be nice
if your keygen would cycle through them instead of showing only one.
It's not mandatory though.

Rules:
NO patching!
A stand-alone keygen is the only valid solution.

I hope you enjoy solving this. :)