This KGM is a result of quite a lot of research, so I hope you'll like it. :)
You'll need to be good with cryptography to solve this.
The difficulty depends on the person solving it.

Accepted solutions: serial, keygen

Good Luck! :)