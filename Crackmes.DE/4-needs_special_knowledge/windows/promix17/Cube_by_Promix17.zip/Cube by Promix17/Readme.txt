Primitive Math v1.0
Written by Promix17

Level of dufficulty: 6/10

I think it's the most difficult crackme I've ever done. The goal is to write a
valid keygen. The crackme is really solvable, but it may take a lot of time to
fully understand a protection code. However, programming the keygen isn't easy
enougth, too. Hope that the idea of this crackme will be interesting for you.

Don't give up!

Good luck)))
