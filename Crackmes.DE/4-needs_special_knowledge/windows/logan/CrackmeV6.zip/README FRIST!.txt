//////////////////////////////////////////////////////////////////////////////////////
//Filename: CrackmeV6.exe				//
//DLL: Non					//
//Difficulty: 4 - Needs special knowledge			//
//Platform: Windows 2000/XP Only(Tested on XP Pro SP2))	//
//Language:C++					//
//	         	 MadeBy: Logan			//
//Rules:						//
//1. No patching					//
//2. Keygen Only					//
//3. No  BrouteForce					//
//4. No crying					//
//////////////////////////////////////////////////////////////////////////////////////
-=>Warning:
-=>File may and probably will close any dangerous(Debuggers, Disassemblers and others) softwares.
-=>Please use this file with cautious, I am not responsible for any kind of data
-=>lost or file demage that beening caused by this file.
-=>File may and probably will close Internet Explorer.

Notes:
If I had more power I could made this crackme more efficient,
Crackme starts a bit slow.
This is one annoying crackme ;).
I hope you will have fun cracking it.

This crackme is more about killing the things that helps you crack
then super special algorithm.