  P H O E N I X 3

        by
     Phoenix87

Finally the third chal-
lenge is going to 
start with this new
version of Phoenix
CrackMe serie.

The aim is to write a
valid keygen that works
with both the exes
and to discover the Easter
Eggs of the crackme.
There are up to 3 EEs.
Will u find 'em???

Patch is allowed, if u
find the right way of
patching this CrackMe!

Best Regards from...

...Phoenix87!