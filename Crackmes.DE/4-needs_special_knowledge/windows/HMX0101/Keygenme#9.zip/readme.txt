This time i've prepared a harder crackme...
Somebody without crypto-knowledge, plz don't loose your time ;)

Like other of my crackmes, the only allowed solution,
is a keygen :D

Rules: 

	- Don't patch!!!

Greets to:
Ox87k, l0calh0st, Ank83, lord_phoenix, BugHunter,
and all people from crackmes.de, ARTEAM and iNFLUENCE forum...