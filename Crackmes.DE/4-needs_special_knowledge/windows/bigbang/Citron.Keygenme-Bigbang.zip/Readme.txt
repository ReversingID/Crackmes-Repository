Here's a keygenme. Patching not allowed, only keygens.
Mail your solution to thebigbang@gmail.com

Have fun,
Bigbang
http://bigbang.cracking.in/