===========================
 bunnX's getaccess crackme 
===========================

Try to get the right password.
Patching is allowed for the cracking process but not the solution!
Write a tutorial how you have done.

The accepted solution is the real password.
(Try to imaginate, that you want to use this password for other purposes, too.)