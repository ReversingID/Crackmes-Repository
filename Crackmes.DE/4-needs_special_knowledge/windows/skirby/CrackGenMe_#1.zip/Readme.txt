Hi everybody,

Here is my first challenge. The CrackGenMe #1
It was made for beginners but also for advanced crakers.

Goals:
- For warriors: make a keygen
- For slacker: display the success message

Peculiarities:
- patching is allowed but not code injection
- serial number is only composed of aplha-numeric characters
- no packer or compressor was used
- no tip based on computer name, hard drive number or something like that

I hope you will write a tuto if you find the solution.

Do not hesitate to ask me if you need more informations.


Skirby