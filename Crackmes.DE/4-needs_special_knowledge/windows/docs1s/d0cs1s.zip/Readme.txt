d0cs1s v1

features:

md5 hash generator
rc4 encryption
custom dual sliding key system

serial encryption is diffrent for each computer!