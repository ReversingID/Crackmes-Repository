
You are given an application and you are supposed to find a vulnerability and exploit it. 
You have to make a message box pop up as shown below: 
 (Displays Hacked! in the pop-up with the OK button to exit the program)
It should also show your name and password in the area in which it is showing not registered.
Include the relevant files needed in your solution.

Watch out for hints in the discussion area!!
Happy reverse engineering!!

Regards,
abcd





