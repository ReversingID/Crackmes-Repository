ah0i folks!

I am working on GPGPU projects quite a while now, and a few days ago an idea popped into my mind: GPU shaders could be used for serial number validation! So I have coded this little crackme. It uses DirectX as the graphics API, and it uses pixel shader for serial validation. It asks for a name (3-12 characters), and a picture of size 128x128 pixels called "key.bmp" has to be in the folder of the exe. If the key picture and the name match, DirectX renders a goodboy picture, otherwise it renders a colored square. Serial algo is easy, but you'll need to understand how DirectX and shaders work to solve this one. 

The objective is to understand (and explain in a tutorial) how your inputs are used by the GPU, and what the pixel shader does. If you feel like that, you should make a keygen, too. When you have a solution, feel free to e-mail me for the source code.

Since the program has been compiled with the 2008 November DirectX SDK, you will need at least the 2008 November runtimes. Here is the link for those who don't like googling: http://www.microsoft.com/downloads/details.aspx?FamilyID=886acb56-c91a-4a8e-8bb8-9f20f1244a8e&DisplayLang=en

Good luck!

//*** UPDATE ******************************************************************************
// It was reported that the crackme's dialog box doesn't show up on some machines, and
// I think it is because I am using DialogBoxParam incorrectly. I pass NULL as the first
// parameter (HINSTANCE) instead of the actual HINSTANCE value. I've fixed this issue,
// and I hope the program will now work for everybody.
//*****************************************************************************************

sghctoma /*sghctoma@gmail.com*/ 
2009.01.26.