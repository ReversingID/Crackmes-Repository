------------------------------------------------------------------------
                       m0dchip's Walanghiyang Crackme
-------------------------------------oOo--------------------------------
This is my second crackme. I have written it in Borland Turbo Pascal
(as with the first one). The crackme is not packed/protected. I think
this will be slightly harder then my first crackme so I will be rating
its difficulty as 5/10. I hope you enjoy cracking this piece.

Please don't patch. You could also try writing a keygen. Thanks.

Hope to see you in my next crackme!!!
-------------------------------------oOo--------------------------------
 Greets to: 3h3N6 | J!GS | Bochog | P_A_P_A_geoff | R0MM3L2K5/The_rOOt
 	    Adz | Kaloy | rash | coniackskii | DR_Loverinto | and sa
 	    lahat ng parokyano ng Crackmes.de