This is a two-in-one crackme. Solving ONE problem will be enough to submit a solution. Of course I hope you will solve both problems.

How to start it
==================
Put all three files in a folder and start "loader.exe". This loads the dongle driver then starts the crackme. I recommend running it in VMWARE.


Problem 1: The serial itself
=============================
Write a keygen that works reliably. If you are really good, you can figure out what's going on just by observing. You do not even have to reverse anything. Bonus if you write the keygen algorithm by yourself, as I did and don't copy from a textbook. 

Problem 2: The dongle
======================
The crackme will crash if the dongle.sys driver is not installed. Also the driver makes the crackme slow and ugly. So remove the dongle! 

Compatibility
=============
The crackme was tested on both W2K and XP. It will NOT RUN on a SMP machine (hyperthreading, etc.). 


Have Fun!
WV