hello folks,

thiz iz my fifth CrackMe and my hardest one.
I hope you enjoy it :>

RuleZ:
	1. patching NOT allowed (just patching with ressource-editors is allowed)
	2. write a keygen
	3. avoid to bruteforce
	4. find the little EasterEgg (contains the name of another Cracker)

see ya