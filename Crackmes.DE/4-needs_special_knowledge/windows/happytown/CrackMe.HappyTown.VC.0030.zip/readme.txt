HappyTown's CrackMe_0030(keygenme)

No patching!
This crackme is not for beginners. Paste Ur solution on bbs.pediy.com
or www.crackmes.de if U get a valid keygen.

HappyTown
[2oo6-11-o9]