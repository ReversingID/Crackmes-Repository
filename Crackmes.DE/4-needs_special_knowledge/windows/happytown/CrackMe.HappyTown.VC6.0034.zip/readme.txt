Hi, this is my another crypto keygenme.
Your task is to find out what's going on in this keygenme
and write a keygen and/or  tutorial. Only keygen is acceptable.

Greetz:
	jB(you are a smart keygenner! :D)
	HorstStein(are U still there?)
	& every cracker in the world.

HappyTown
wxr277@163.com