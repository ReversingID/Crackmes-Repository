a keygenme by Lesco:
Difficulty: 3/10
Packers: none
Crypto: none
Language: C++
Rules:
-no patching
Mission: Create a keygen

Happy reversing!
