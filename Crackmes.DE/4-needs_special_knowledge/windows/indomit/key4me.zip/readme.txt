>>> Key4me <<<

I present you a new puzzle crackme. 
I think it will be interesting. :)

Rules:
   1. No Patching.
   2. Write Keygen.
   3. Be sure that your keygen will work for all names (important!) :)

PS: Please report me if you find any bugs, flaws or exploits :)
------------------
   indomit
   Jun. 3, 2009.
------------------