Rules

Keygen it ;)

About

Here's a little math riddle for you.
No advanced thoughts this time, just some recursion.
Anyway, don't get confused by all the climbing,
but try to see behind it and identify the routines.

What I'd like to see is an elegant keygen
(I had to add 10 lines to have one).
Just use the same BigInteger library as me:
http://www.codeproject.com/KB/cs/biginteger.aspx

Extra task:
Try to find out what the person on the photo
(source: http://en.wikipedia.org/)
has to do with the algorithm.



Greetz:
bLaCk-eye, jB, halsten, KernelJ
and other great reversers out there.

My info:
Email: mrhaandi@gmail.com
Homepage: http://mrhaandi.thecoderblogs.com/


MR.HAANDI