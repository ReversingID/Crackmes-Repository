Welcome to the WeakAES keygenme.

It is often the case that developers simply rely on 
the strength of a cryptographic problem 
and do not follow exact standards.
Often this is a bad idea and from time to time we hear 
"RSA 4096 broken" or "ECDLP 512 defeated".

You remember reading this first passage before?
Well, this time you are supposed to break custom AES.

I have built in a backdoor and placed a few hints. 
Have fun breaking it.


Goals:

    Gold:   Write a key generator to 
            produce a valid signature for any given name.

    Silver: Write a generator for valid (name, signature) pairs.

    Bronze: Find a valid (name, signature) pair.


Rules:
    
    No patching.



Greets:
bLaCk-eye, KernelJ, jB, divinomas, halsten, Numernia
and other great reversers out there.


My info:
Email: mrhaandi@gmail.com
