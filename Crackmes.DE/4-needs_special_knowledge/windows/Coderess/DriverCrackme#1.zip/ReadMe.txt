
DriverCrackme #1
==============================================
Use VM (VmWare)
Tested only on Windows XP sp2, sp3

Tasks
1. Find License key, General Key for your nickname
2. Write keygen
3. Write solution 

Thanx to: Roman, Unity, daFix