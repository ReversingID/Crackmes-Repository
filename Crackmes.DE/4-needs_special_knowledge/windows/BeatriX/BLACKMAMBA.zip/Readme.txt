****************************
*
*	BlackMamba
*	by BeatriX
*	may 2008
****************************



1) What is this crackme ? 
=========================

	The idea of this crackme is born of an article about Petri Nets from Thorsten Schneider entitled "Hardening Registration Number Protection Schemes against Code Engineering with Multithreaded Petri Nets". This crackme is an experimental binary. The difficulty for me was to play between resilience of my petri nets implementation and the time to execute it.

2 ) What must I do ? 
=====================

	You just have to find the right password and to tell me how you found it. I don't think it is possible in a reasonable time to bruteforce it. 

3 ) Is it a difficult crackme ?  
===============================

	It is not an easy crackme because of multi-multi-multi-threading use and junkcode insertion.


BeatriX from FRET 
http://binary-reverser.org
http://beatrix2004.free.fr
mail: beatrix2004(at)free(dot)fr
