Octopus crackme
by BeatriX

1. Introduction
===============

This crackme is coded in asm and compiled with masm32. It is protected against analysis with some easy junkcode. It is not the real difficulty here but it can be a good introduction to learn how to defeat obfuscation. The register scheme is quite funny I think :) There are no maths, no crypto, no anti-debug tricks.

2. What must I do ?
===================

a) You just have to find the right password !
b) Try to find why this crackme is called "octopus" ;)

BeatriX (French Reverse Engineering Team)
http://beatrix2004.free.fr
BeatriX2004(at)free(dot)fr