


EXE is simple VB6 - not packed.


Your TASK: Keygen it.

Rulez:

	No Cracking or code or resource editing allowed!

	Post your solution on forum!





Good luck, and have a nice day!

					ChupaChu