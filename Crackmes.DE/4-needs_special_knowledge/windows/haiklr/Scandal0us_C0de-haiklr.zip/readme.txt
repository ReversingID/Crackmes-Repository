Scandal0us C0de

My last keygenme coded in asm.
Just use your brain, a pen and a paper, it's only logical and maths, as the last time ^^
BRUTEFORCING and PATCHING are always forbidden ! 
Writing a keygen/tutorial is the only solution allowed ;)

Have fun !

haiklr


klr63@hotmail.com
http://haiklr.new.fr