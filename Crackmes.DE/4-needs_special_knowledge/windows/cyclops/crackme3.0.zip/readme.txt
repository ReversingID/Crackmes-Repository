			Cyclops CrackMe v3.0
			--------------------

	Hi ,
		this is  my third crackme.
		In this one I used some hashing techniques.
		Dont patch the file as it would be too easy.
		Try to understand the algo
		& make a KeyGen.

		Mail me ur KeyGen with source code.
		
			Happy Cracking!!!


	PS:It is compiled in MFC(VC++).
	   So it need mfc42.dll,mfco42.dll,msvcrtd.dll.

	Mail::cyclops1428@yahoo.com


			Greetz to all AIT friendz!!!  