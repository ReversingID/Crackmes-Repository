Level 3-7. It' small program written in assembler, but code is highly obfuscated, hardly readable and full of anti-tricks. No heavy cryptography. Key generation procedure is trivial.

Your task is to fight the way to the check procedure, write keyfile generator and brief tutorial. No patching nor bruting. Tested on Win XP SP3.