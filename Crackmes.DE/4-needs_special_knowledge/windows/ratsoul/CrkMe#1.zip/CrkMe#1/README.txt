CrkMe #1 by ratsoul
------------------
e-mail: ratsoul at autistici.org
--------------------------------

a) find a valid: name/serial
b) write a tutorial
x) no patching
x) no brute

I hope you enjoy :)
- ratsoul
