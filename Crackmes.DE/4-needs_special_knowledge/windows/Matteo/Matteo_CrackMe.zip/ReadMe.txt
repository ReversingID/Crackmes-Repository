-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA1

Hi!
I dare you to make an attempt to beat my first crackme. Impossible things happen inside.

The goal is to keygen the program.
Bonus: Try to document as many tricks as only possible.

Information:
- - The program uses a common mechanism to check whether it is registered or not.
- - It has been packed using some obfuscation methods so that it may be required to unpack the program before continuing.
- - Owing to antidebugger protections that have been added, anti-anti techniques might be useful.
- - Patching is not a necessity.
- - The program has successfully run under Windows 8 x64, Windows 7 x64, Windows XP x32. The last one only in Virtual Box environment.

EXTRA: Due to a kernel protection it's impossible to meet PacMan in Windows 8 (and probably any Windows x64).
If you want to meet PacMan (and you do!), run the program under Windows XP, attach a debugger on the fly and then read at the EntryPoint.

PS. Let me know if you can't understand some magic going on behind the scene.

Contact me by E-Mail "matteo.crackme@gmail.it" (GPG public key at hkp://keys.gnupg.net)
Fingerprint: 683E0BA7359F2830DBDE1D96ED59DF71FD861B1E

Good luck!
Matteo
-----BEGIN PGP SIGNATURE-----
Version: GnuPG v2

iQIcBAEBAgAGBQJU6NIiAAoJELzIg3mUJLyYyDUP/0u1FHVlInMGa//1A5bIM5ml
wHGvluin5qhdiBgSlZPRyO3EETVIMmakl6sA2eOE4Klsx+gHidmAe421Ue5VZ3U4
4W5cJZPk2HcAkwDcz0daKuP2IxzSdPTKxUtNM6AD1mhqp3NZH6EMEppTYFzKWzEx
+rS3lHjPsHYcg7oFbwZBTzpK2WctNoCEh7oQEGrm5FoW7p9Zvsx1E5CIpxJdl7+K
OMJnnSq4SEO/ArvwnQc3hPbpYA4zoWYXsghh5f5ERT651O2XOt0BGQPnD6yo8VfE
1Dd+M6gs2s/NFNI8kTbqI6kMzgRNMWtTWUJlRP/TBVo/RRQHN4tLANfEquFYO+eP
EZW7HrVxGN6TIegwix0fy7uFp1M3sWxg6xmdw1W8mZXg8f5t7jLMi4ug6yRDegKR
yYZYVMUOeG7TicItjhbxQUccYrlNnZgpXXJV0SYBTOrlsDhtuIUlzDsC0SKco66M
YTMNTz9dr/2bVYnGmCOGJtDFM1m0sM7OZzxlJ5kr9AybkrlHMJmHLLKi73H5lsDw
NSCAi0FVws2XBG/faxBcyl3xB2JGksXSV970snrgZHkqAEXM9nXNBnIG6FillyvC
pFe2tpsm9lWptJftsy2IitlqAyTP0LBEDcUUy3qk+d4ar5QL7F9Fonc/43yKWHV2
MeBJr/uBLLJQAQnFNukr
=EPaj
-----END PGP SIGNATURE-----
