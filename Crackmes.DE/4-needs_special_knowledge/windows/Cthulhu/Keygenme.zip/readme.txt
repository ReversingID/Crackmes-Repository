Cthulhu's Keygen-me #1

This is my first Keygen me. Specially written to this great RCE site.
I Hope you have fun with it. GOOD LUCK!

Rules:
No rules ;-) Just create a valid keyfile and write a tutorial explaining how you did it.