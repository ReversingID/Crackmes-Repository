Hello guys. I am back with another Keygen me.
This time I think its a bit hard..
So I'll rate it at Difficulty-5.

May be I am wrong abt the difficulty, & there is a big chance, that Numernia Or andewl will rip it apart without breaking much sweat.

But I am sure that you guys will enjoy it :)

Rules : - No patching.
Donot post serials or hints in the board.

A working stand-alone keygen is the only soln :)

Regards
KKR