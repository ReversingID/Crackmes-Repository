Hi!

Here's the third one, some maths this time. Can you remember how to solve
higher grade equations? ;)

-Rules:
.No patching!
.No self-keygenning!

-Hints:
.You should not be afraid of small or big numbers!

-Tasks:
.Find all possible, "straight-forward" serials!
(.Make a keygen:)
.If you want to float downriver (big hint here!) use the little weakness to find
infinitely many serials!
.Have fun...