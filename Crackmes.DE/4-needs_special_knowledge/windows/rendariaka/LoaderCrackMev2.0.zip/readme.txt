This is a much improved (not visually) version of my previous loader crackme.

Objective: Find the serial

Good Luck

Rendari Aka