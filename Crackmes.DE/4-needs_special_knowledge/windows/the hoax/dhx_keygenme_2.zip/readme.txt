WHAT
  dihux's keygenme nr. 2 v1.00

ABOUT
  My first keygenme was made in 06.2003 featuring basic RSA.
  Now, 06.2009, it's time for my second keygenme. As you
  might notice, it could've been made much harder. But that
  is not my intention this time either.

PROTECTION
  Level 4 / 10 (crackmes.de scale).
  P.key: Calculation. Also made bruteable, thus level 4/10
  A.key: Calculation.

RULES OF THE KEYGENME
  - NO PATCHING
  - Make a fully working keygen which can produce multiple
    activation keys for a desired name
  - A single serial for the product key is accepted
  - What is really going on with the product key checks?
    It would be nice if you could identify what each part
    mathematically-wise is. Solve it in any non-patching way
    you want. Source and details about checks may be
    provided to solvers, or to people in big need of help.

GREETINGS
  Brainrain, andrewl, pDriLl, elessar, Bondevik...and all
  lost friends over the years

CONTACT
  IRC: EFNet at #cracking or #unpacking
  E-MAIL: dhx_xor(a_t)hotmail(d_o_t)com

                                             dihux // 06.2009