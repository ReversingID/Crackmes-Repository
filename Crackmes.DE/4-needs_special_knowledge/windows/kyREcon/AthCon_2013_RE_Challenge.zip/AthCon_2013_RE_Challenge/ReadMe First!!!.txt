Athcon 2013 RE Challenge
............................


Authors: Kyriakos Economou (@kyREcon) & Nikolaos Tsapakis


Tested in the following Windows OS Versions -x86 only!-: 

Win XP (SP3) 

Win Vista (SP2)

Win 7 (SP1)

Win 8 (Developer Preview) 



MD5: 17D2B912E8FC8748BAF2186AE508863B

SHA-1:0078AF3DA5B8728F36F0CA75F023353AECB004DC
  
SHA-256: CB6407FE9A4DEFB9C7D46AB9CED3ED394EBA20E6E7E26402564A475C379D85EE



Please read the whole document before proceeding. Ignorance is not an excuse!






Description
..............

This is a Reverse Engineering Challenge. Just a solution is not enough. A fairly detailed report about how you cracked it, and the key points of it, is necessary in order to claim the prizes.


If you only submit a valid solution, we might want to ask you how you did it and congratulate you in private (and later in public after the end of the contest), but you will not have the right to claim any of the prizes.





Rules
.......

i) You can use any kind of tool of your choice.

ii) No Brute-forcing!

iii) No code patching!

iv) Asking for hints is not allowed. 

    - However, We may give one out if a lot of people ask about the same thing. - 

v) No solution sharing while the contest is active. We keep the right to cancel
   the contest if we suspect cheating.




Prizes
.........

The following prizes will be given to the first person that will solve the challenge and submit* a fairly detailed report about it. 
 


i) A free ticket for the 2-days conference AthCon 2013 ( Athens/Greece 6-7 June 2013).

ii) A 100 euros Amazon voucher. -Sponsored by the authors of the challenge-


If the first person that will have the right to claim the prizes is not able to come in the conference,
he will still have the right to claim the prize sponsored by the authors of the challenge.

In that case, the free ticket for Athcon 2013 will go to the next person that will have the right to claim it.



Prizes cannot be exchanged for money...,or physical contact! :OP


We do want to give the prizes and be proud of it, so keep this contest fair and clean!



*Valid submissions are only those occured before the end of the given deadline.





Submit your solutions
.......................


Send your solutions to: kyrecon@athcon.org





Disclaimer
..............

By participating in this contest, you agree that the organizers of Athcon IT security conference, the authors of this challenge, as well as any person involved in this process may assume no responsibility for any incovenience caused by this challenge, including computer and any kind of equipment damage, as well as psychological and sentimental damages such as a nerve breakdown, etc..etc.

The organizers of Athcon Security Conference keep the right to cancel the contest at any time. In that case you will not have the right to claim any of the prizes even if you have submitted the solution before the contest is cancelled. 




Having said that, we wish you good luck, and don't forget to have fun with it. :o)


Choose your destiny...



- Athcon 2013 / www.athcon.org -













