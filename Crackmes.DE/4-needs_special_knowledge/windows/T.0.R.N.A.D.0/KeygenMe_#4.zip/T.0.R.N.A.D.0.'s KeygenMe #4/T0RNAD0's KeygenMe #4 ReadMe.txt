
>>>>    READ-ME FOR T.0.R.N.A.D.0.'s KeyGenMe #4
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

PLATFORM     ::   WINDOWS

LANGUAGE     ::   C / C++  

DIFFICULTY   ::   4        [ Needs Special Knowledge ]

------------------==============-------------

SUBMITTED BY  ::   T.0.R.N.A.D.0.

------------------==============-------------

The Rules:
==========---

    (*) NO PATCHING

    (*) NO BRUTE-FORCING



The Tasks:
==========---

    1. Try to get Status as "VALID :) !".


    2. Find the algorithm for the computations involved.


    3. Make keygen to VALID Key for ANY name. Please note that VALID KEYS EXIST FOR ALL NAMES.


    4. Write a descent tutorial. ;)



Hint:
==========---

Think about solving a 15-puzzle.  ;)



~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_

	printf("T.0.R.N.A.D.0. - born 2 %X\n",49374);

_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~