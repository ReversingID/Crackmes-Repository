SomethingToHide V1.0 by halsten
-------------------------------

This crackme is full of surprises, all I have to say is that you need a drink
with it and a clear mind as well. So I hope you enjoy it.

What is required from you is to write a working keygen for it.

P.S: Name must be greater than 5 characters.

Language: ASM
Difficulty: 4
PLATFORM: Windows

Greets goes to:
	- jB
	- bLaCk EyE
	- TiGa
	- ZaiRoN
	- tnw
	- Mjinhew
	- azmo
	- ColdFever

And to the people I forgot, you weren't on my mind for some reason and you probably 
don't deserve any thanks anyway.

--
halsten
http://iamhalsten.thecoderblogs.com