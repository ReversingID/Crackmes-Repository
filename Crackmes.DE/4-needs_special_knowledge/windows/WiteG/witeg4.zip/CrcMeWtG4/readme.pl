                     CrackMe 4
                   -=*********=-

Opis:
*****
Witam w moim czwartym crackme na poziomie medium++.
Tak mi sie wydaje ;)

Twoim celem jest wygenerowanie poprawnego kodu dla
wlasnego nicka a potem napisanie keygena. Jak Ci sie
bedzie chcialo mozesz skrobnac tutka.
Patche i loadery nie dozwolone. Brute-force zbedny
poniewaz :
* jak zwykle wszystko co potrzeba jest odwracalne *.

Jak juz zlamiesz ten programik przyslij mi rozwiazanie
(witeg@poczta.fm) albo zlap mnie na IRCu. Jesli wyjasnisz
co i jak poinformuje o Twym wyczynie na mojej stronce.
Milej zabawy.

WiteG//xtreeme
www.witeg.prv.pl