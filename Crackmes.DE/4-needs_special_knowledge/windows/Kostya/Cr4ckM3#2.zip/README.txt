This is my second KeygenMe, so I decided to make it more
difficult then i made before (KeygenMeNo1). So try to solve
it and write a solution with your keygen. Or if you can't
write a keygen, try to make a bruter for this keygenme.

Now level:  2 or 3 or maybe 4
Name: KeygenM3Crypt #2 (CAFFEINE_CRACKME)

I actually don't know what level this crackme can be :) so
plz, rate for the level :), and post here :)

----------------------------------------
$$$$$$$$ Here are some rulez: $$$$$$$$$
----------------------------------------
		
1.	You should avoid some very-very-simple-standart anti-debbuging
	tricks..
			
2.	You need to find correct serial (this is the main task)
		
3. 	Try to make your keygen for my keygenme, if you can't reverse
	some parts of it, try to make a bruter 
	(only fast bruters are accepted ;))
			
4.	If you made it, plz, PM me @ crackmes.de!!!
	Name: Kostya or send an e-mail to kostya@mail.vu
	And plz write a solution :)!!!!

----------------------------------------

BTW: it has a lof of correct serials ;)
P.s: I think you should write a bruter, don't actually know :))
     And of course no self-keygenning ( NO patchin' at all :))