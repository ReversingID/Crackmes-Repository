Welcome to my next CrackMe !!! (actually PatchMe ;)

Note ---> This CrackMe only works on win98 ;)

Ok, well your main task is to get to the "Congratulations"
Message Box :)

Rules:

1.	No Patching *g* it's supposed to be Patched so doh ;)
2.	Don't let it jump to the "Congratulations" Message Box that
	would be too easy, just remove the checks :)
3.	I think i don't need to tell more :)

Have Fun...

Send your Tutorial "on how you did it" to:

code.inside@home.nl

Cya...

CoDe_InSiDe

http://codeinside.cjb.net