TaGaDaPaF's KeyGenMe#1
=======================

Hello, this time you will have to find the algo (very simple algo), but do you know where ?

btw "(_*_)" means your serial is not valid, and "gagne!" means its a good one (its a french word meaning won!)
Have fun!

02/07/04
