A very simple crackme.

The algo was by a friend of mine Remmy all I did was drop it into a Win32 shell.
Not much to say simply retrieve the serial.
Shouldn't be too difficult but it is a very good example of how simplicity doesn't
mean easy. The algo is only 50 bytes in total.
Please include a good explantion and any source code!

Enjoy.

Remmy adapted by Harlequin
12/02
