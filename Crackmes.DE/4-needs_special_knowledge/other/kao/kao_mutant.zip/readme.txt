
    "Think? Why think! We have computers to do that for us."
                                              /Jean Rostand/



Exercise:	Mutant
Author:		kao
Type:		keygenme
Difficulty:	1/10 (calculating one serial),
		4/10 (coding keygen)



Hi,

This  crackme  is  more  like a coding challenge because you
will  probably spend little time trying to understand what's
going on and most of the time thinking HOW to keygen it.

It is not very hard to solve this crackme for any particular
name.  In fact, that should take few minutes, calculator and
sheet of paper to do so.

Real fun will begin when you will try to keygen it. ;) It is
not   an  easy  task,  but it is still possible to make FAST
keygen. You just have to think. Think hard!

Patches  and  serials  do  not  count as a solution. So - be
creative and please, please, please publish a source of your
keygen!


Good luck and have fun!

kao.

Riga, Latvia, 2004
kaspars@hotbox.ru


Greets to 
        elfZ        don't be so lazy, publish your solutions 
                    on crackmes.de
        oorjaHalt   can you handle this? ;)
        .Goolum     awesome crackmes!
        Therapy     waiting for your next CM!
        Roma        haven't heard from you for a looong time
        YOU         thanks for reading...
