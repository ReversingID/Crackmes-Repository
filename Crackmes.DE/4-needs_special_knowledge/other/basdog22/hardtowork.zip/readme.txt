***********************************
*|```````````````````````````````|*
*| Author: basdog22              |*
*| Language: VBasic 6            |*
*| Protections: A lot of them    |*
*| Packed: No                    |*
*|_______________________________|*
***********************************

Hello again,
This time i made a (All in one crackme).
It has more protections than you think.

Your goal is to make a keygen for it and also
patch all the other protections. Note that if 
you only find a name/serial combo or just make 
a keygen for it will be half sollution. You must
also find all the protections and bypass them.

Send a short tutorial explaining how you solved
it and explaining what this crackme does to 
http://crackmes.de

SeeYa
basdog22