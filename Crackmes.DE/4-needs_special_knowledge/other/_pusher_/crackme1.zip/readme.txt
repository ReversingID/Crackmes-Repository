This crackme is coded by _pusher_
if you feel skilled then this is for you.
i would't recomend this for a newbie
there are some trix.. 

unpack it if you want to.
The only rules are.. keygen it.


//_pusher_

my site is http://athenasunix.mine.nu