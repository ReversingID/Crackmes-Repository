Make a keygen for that crackme
level 4/10 (i think)

Good luck,
MiNoS