Ipoly (crackme) by Ghiribizzo 1998
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This is actually the product of various ideas that I've been playing around
with. The main aim was to test how good a serial scheme needs to be to prevent
keygens from being made. We know that we can make schemes arbitrarily difficult,
but I suspect that a scheme need not be impossible to be safe.

The scheme here uses a fairly simple scheme, but I suspect the majority of
crackers will not be able to produce a keygen for it - not due to any lack of
cracking skill, but rather through shortcomings in certain areas of knowledge.
However, when I give such a challenge, I expect to be proved wrong ;)

The scheme necessarily requires the use of floating point codes. I haven't used
FPU instructions up till now and I know of some very good crackers who are in
the same position. However, the Intel reference manuals provide everything
required to use FPU opcodes.

One problem that did crop up was that SoftICE v3.23/v3.24 for 95/98 does not
deal with the floating point registers properly. Luckily, Turbo Debug worked
fine. I'd be interested to hear if anyone know of recent versions of SoftICE
that handle the FPU correctly.

Description
-----------

The crackme is in two parts. The first part takes the name and generates an 8
byte license code. The challenge is to find a correct serial or write a keygen
that will provide the correct serial.

Name Hash
---------

The name hash uses the LFSR from the keygen competition to create a 'unique'
licence for a user. The method is pretty ad hoc: it basically uses the first 8
bytes of the name to seed the generator then it takes the number of letters in
the name and the first letter to determine how many 'clocks' will be 'skipped'
before taking 8 bytes for the licence.
The result of the LFSR requires some extra processing to make the scheme work.
The value of the licence code is printed out for your convenience.

Serial Hash
-----------

You can ignore the Name Hash part of the crackme and work with the given licence
code and start to analyse the code from location 1A5h onwards. The serial is
comprised of 8 integers. I was going to encode the serial so that it would be
just a single string, but it is easier to see the algorithm this way.

Notes
-----

The Name Hash checking only checks to ensure that the name will have a valid
key code. It does not check to remove 'easy' names. Consequently, there is a
class of names that have easily calculated keys. Two trivial ones result in
licences: 12340000 and 14250000. Those who cannot calculate a key for their
own name can try to find these 'easy' names which is a small reversing task
in itself.

I have tried to make the code as 'verbose' as possible to make it easier to
analyse the scheme. If you manage to code a keygen or make a serial, please
email me: ghiribizzo@geocities.com

Sample
------

C:\>Ipoly

Ipoly (crackme) � Ghiribizzo 1998

Enter name  : Ghiribizzo
Licence code: D2F3E345

Enter Key #1: 853
Enter Key #2: 349
Enter Key #3: -7
Enter Key #4: -1
Enter Key #5: 780
Enter Key #6: 1560
Enter Key #7: 780
Enter Key #8: 1560

Congratulations!

C:\>

Good Luck!