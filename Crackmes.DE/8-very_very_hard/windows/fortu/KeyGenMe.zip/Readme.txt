This is a very very hard KeyGenMe. 

Try your luck.

Rules are as usual: Don't Patch, write a KeyGen, write a tutorial.