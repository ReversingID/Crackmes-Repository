Well, crackers an fuxers

Yet another crackme me from me(konstAnt). A registry replacement this time. Not the best one but probably a good one. Ok, a easy one this time and little bit crypto this time. He..He...
I would like OoRja mainly to try it. Well crackers not so hard until you find a serial which is hard enough to make you busy. Not a hard as _khAttAm_ but is on the line to meet his standard. Ha..Ha.. The _khAtArA_ banging on the top coder. That's a gerat news.

Well, Rulzs:
1) No pacthing.
2) Find a valid serial.
3) Write a good tut.
4) If possible make a keygen.

Hints:
1)loader concept
2) Packed with UPX


A more difficult than previous than....
I'm so lazy that I even don't like to write
a detailed readme. From next time.....(shh.shh)
I would ask _khAttAm_ to write my crackme.

Ok a crypto and other mixture this time:

The main theme of the program is to find 
a valid passw0rd and your "All" menu will
be enabled.

Greetz:
In the crackme.
