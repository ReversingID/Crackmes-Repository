This crackme is a testapp for my pe protector beria.
Some time ago I released an early version of beria, but it had
many flaws and I decided to completely rewrite the code.
So this one has nothing (but the name) to do with the old beria.
I tested it successfully on Win2000 SP 4 and Win XP SP 2 but it will
not run on Win 95/98/Me!

rules:
Everthing is allowed!
The crackme is solved when the right text appears in the textbox!

Please give me a lot of feedback for further development!


have fun!

symbiont