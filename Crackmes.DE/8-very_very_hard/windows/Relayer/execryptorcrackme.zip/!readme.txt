Official EXECryptor crackme
You need solve one of the next goals:

1. Patch code and disable sn checking
2. Create new valid sn
3. Create keygen

in file CrackMe.sn you can find list of valid sn for easy of your work :)

with best protection
SoftComplete Development
http://www.softcomplete.com
http://www.strongbit.com
