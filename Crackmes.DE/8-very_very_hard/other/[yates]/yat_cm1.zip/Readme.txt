____           ______  __    ____             ____
/\  _\         /\  _  \/\ \__/\  _`\          /\__ \
\ \ \/   __  __\ \ \_\ \ \ ,_\ \ \_\_\    ____\/_/\ \
 \ \ \  /\ \/\ \\ \  __ \ \ \/\ \  _\_   /',__\  \ \ \
  \ \ \_\ \ \_\ \\ \ \/\ \ \ \_\ \ \_\ \/\__, `\  \_\ \
   \ \___\/`____ \\ \_\ \_\ \__\\ \____/\/\____/  /\___\
    \/___/`/___/> \\/_/\/_/\/__/ \/___/  \/___/   \/___/
             /\___/
             \/__/
========================================================
              [yAtEs] Crackme v1.0
========================================================

Hey :) this is my first crackme, i'm not really a crackme
type of person but i've become interested in developing
security for applications, so try this :P

I've protected an application i wrote called PE-PRO, its
a small(hmm ok big) app which dumps pe sections and gives
out import info, i wrote that to test my PE skills, anyway!
the crackme.... if you can crack this mail me ASAP :D
hehe, i think this protection is very strong to the average
cracker,..prove me wrong and mail me @ Jamesluton@hotmail.com

Note: When it says correct key, you haven't cracked it unless
      the program runs after clicking ok :)


special thanks to my friends carpathia and risc for answering
some questions to which i eventually just ignored and did it
a completey different way ;)


gREETz to: Everyone i know....blah blah blah, hah! who am i kidding,
           noone is even reading this file.

Hardcore You Know The Score
  [www.yates2k.co.uk]