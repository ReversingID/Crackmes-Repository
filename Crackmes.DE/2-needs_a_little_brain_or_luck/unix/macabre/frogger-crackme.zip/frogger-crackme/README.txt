macabre's frogger crackme lvl 2
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

Level: 2
Platform: Linux
Restrictions: NO patching.  No Hijacking

Goal: Find User/Key pair to make it print 'Cracked!!'

Notes: No anti-debugging code.

Jump Jump ..oo ribbet oo...
