This is my first PS3 crackme!  This is meant to work on linux on the PS3.

It was written and tested on Ubuntu 7.10 but hopefully will work on others.

The debugging symbols have not been stripped.  It utilizes an embeded SPE
processor and requires the libspe2 to run.  You should also know it's a
powerpc64 Elf executable.  Enjoy!

macabre

Rules:

Don't patch unless it's to make a self keygen.
Serial Fishing is fine.

Good luck
