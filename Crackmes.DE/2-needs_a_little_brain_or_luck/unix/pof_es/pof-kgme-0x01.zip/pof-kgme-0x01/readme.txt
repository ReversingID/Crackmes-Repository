[ ===== pof KGME 0x01 ===== ]

GOAL:
  - Find the correct password

RULES:
  - No patching!

BONUS:
  - Use only GPL'd tools
  - Write a keygen

