                 ##############################################
                 #                                        _   #
                 #   _  _  _  _  _  _  _  _  _  _  _  _  / |  #
                 #  | || || || || || || || || || || || | | |  #
                 #   \_, | \_, | \_, | \_, | \_, | \_, | |_|  #
                 #   |__/  |__/  |__/  |__/  |__/  |__/       #
                 #                                            #
                 ##############################################


Hi!
This is my first crackme, written in pure NASM (Linux).

Rules:
	* Create a keygen
	* No bruteforcing
	* No patching

That's it.
Have fun!


PS:	As this is my first crackme, don't be too hard with me - we all learn as
	we code. :)

