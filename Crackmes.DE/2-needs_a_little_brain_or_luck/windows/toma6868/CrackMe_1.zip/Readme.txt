Author: Toma6868

---------------------------------
Hello ! This is my first KeyGenMe written in Visual Basic...

All you have to do is to find a valid name/serial (no patching), find the algorithme... make a KeyGen and to finish, write a Tuto !

Enjoy ;-)