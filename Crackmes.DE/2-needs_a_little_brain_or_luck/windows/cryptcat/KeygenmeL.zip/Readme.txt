KeygenmeL : Cryptcat
-------------------------
Language: ?
Packers & Protection: None
2 - Needs a little brain (or luck).
-------------------------

Display the congratulation message.
Write a keygen for the program.
Submit a tutorial to crackmes.de

~Cryptcat~