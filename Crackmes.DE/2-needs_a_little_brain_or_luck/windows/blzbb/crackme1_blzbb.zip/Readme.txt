
This is my first crackme

Rule:
 -no patch
 -find correct name and serial
 
 if you like make a keygen
 
 BlZbB
 
