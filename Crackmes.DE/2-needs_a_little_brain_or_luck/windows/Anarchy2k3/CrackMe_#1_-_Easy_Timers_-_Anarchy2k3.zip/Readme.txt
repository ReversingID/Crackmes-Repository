CrackMe #1 - Easy Timers - By Anarchy2k3

Coded with Delphi 2009, verification routine use one or two timers ;-)

It's easy with little lucky or Ollydbg !

Please contact me to : anarchy2k3@hotmail.com for any comments.

Have a nice day !

Anarchy2k3 - July 2009