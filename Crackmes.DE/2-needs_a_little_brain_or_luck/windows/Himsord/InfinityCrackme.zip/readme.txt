Welcome to Infinity!
Please keep in mind that this is our first crackme, so don't expect an awesome crackme.


###INFORMATION###

-We implemented various anti-debugging functions, you better watch out!
-This crackme was coded in Visual C++, so...
 ...you need Visual C++ Redistributable 20xx installed (if you haven't installed it yet)!


###RULES###

1) Do NOT patch the key-algorithm itself / the output (Change "You didn't crack me" to "You cracked me")! 
   
2) A complete keygen is preferred, self keygenning is okay as well.

3) Feel free to use every tool you want.

Have fun!

###VIRUSTOTAL###

https://www.virustotal.com/en/file/7269b397b32a7d98cd3bf01cd4314106fa32063787553a527c5122d98d7d362a/analysis/1451840623/

~expl0itr & lasertrap