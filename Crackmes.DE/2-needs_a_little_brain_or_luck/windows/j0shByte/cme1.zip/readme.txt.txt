-------------------------------------
|Made by Reverse engineering student|
|     j0shByte (Z3r0_Byt3) 2007     |
-------------------------------------

1. Disable stupid nag
2. Make keygen.

No packer,and no antidebug/antidisasm trick present.
Dont let program flow confuse you.
Enjoy :)
Also if you dont like me cme,explain why.

j0shByte@gmail.com
feel free to contact me on ICQ 284-848-285 

