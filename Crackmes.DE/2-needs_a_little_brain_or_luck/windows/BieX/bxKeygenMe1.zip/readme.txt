Keygen Me =D
..it can be somewhat frustrating if you havent made a memory-reprogramming [writeProcessMemory()] keygen before.