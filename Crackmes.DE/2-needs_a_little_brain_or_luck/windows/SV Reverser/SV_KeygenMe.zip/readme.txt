Hi

My first KeygenMe.
Goal : Find a valid name/code and/or code a keygen to have the good messagebox.
Patching is not allowed. No anti-debug. 100% asm.
I hope you will find an interest in reversing it ;)

Enjoy,

SV