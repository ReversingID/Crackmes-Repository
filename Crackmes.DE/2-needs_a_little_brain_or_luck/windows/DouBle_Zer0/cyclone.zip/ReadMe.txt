Very Very simple crackme...
Tasks:

1) Remove anti-reversing technique
2) find hardcoded pass or patch application


"Show Me Your Attitude"

my e-mail: m.amit30@gmail.com



/
Amit Malik
(DouBle_Zer0)
Offensive Computing Base