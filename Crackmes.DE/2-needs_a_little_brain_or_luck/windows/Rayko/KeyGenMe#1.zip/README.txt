*********************************
*     KeyGenMe#1 By Rayko       *
*********************************

Rules:

-No patching
-Keygen is required
-Write tutorial (if you want)
-Upload solution
-Have Fun!

the algorithm MIGHT require a little brain though, especially to write the keygen

it's a simple straightforward crackme/keygenme though, since i'm pretty new to c++