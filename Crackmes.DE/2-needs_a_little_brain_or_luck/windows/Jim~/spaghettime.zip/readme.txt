# SpaghettiMe
#
# .NET KeyGenMe
#
# By: JiM~
# On: 27 May 2008

After growing tired of the onslaught of simple 
.NET targets on crackmes.de, I decided to give 
a shot at making a keygenme that takes a little 
more thinking by involving some recursion. You 
won't be able to copypaste code to generate a
serial in this one ;)

Have fun! I look forward to your solutions :)