WinFan's KeyGenMe#1

Your task is to reverse the serial algo and write a keygen! (Keygen can be written in any language you want) 


Language: Borland Delphi 6 (Console)
OS: Windows (tested on XP, should work on others)

