Crackme#1byRamirez

This is simple crackme. 
Analyze it, crack it, write a keygen. 
Send your solution including simple tutorial, keygen and source code of keygen.

Selfkeygen or ripping code of crackme not allowed.

