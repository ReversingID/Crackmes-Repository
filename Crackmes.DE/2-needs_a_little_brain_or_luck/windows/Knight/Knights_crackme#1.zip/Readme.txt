Coder:		Knight
File name:	Crackme 1.exe
Language:	C++
Packer:		UPX
Difficulty:	2/10

Write a working keygen and tutorial how you defeated 
it and submit your solution at www.crackmes.de .
No patching allowed!!!

I haven't faced crackme that uses recursion, so i
decided to write one on my own. I think there everything
is very easy once you understand wtf it is doing.
Hope you'll like it. Enjoy.

Regards


Knight, knight@d2sector.net

2005 05 23