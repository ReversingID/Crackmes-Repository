Easy Math by Fireshark
**********************
It's easy math for a reason.

Find the correct input :D

If you manage to do that, then the program will give you a challenge solution.

Have fun!

-fireshark