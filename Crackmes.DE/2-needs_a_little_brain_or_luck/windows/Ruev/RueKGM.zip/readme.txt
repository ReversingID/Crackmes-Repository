Coded by Rue.
A simple mathematical KeygenMe.

Rules:
[+] Keygen
[-] No Patching
[-] No Bruteforcing.

Contact: rue.virii@gmail.com