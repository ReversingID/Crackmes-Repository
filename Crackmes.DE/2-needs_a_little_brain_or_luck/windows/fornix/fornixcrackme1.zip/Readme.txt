FORNIX'S FIRST CRACKME


Here I present before you my first CrackMe

I've coded it in 100% Assembly. Please X'cuse me if you find the music
annoying. I've just learned how to play xm music files in an exe. 
I'll be writing a tutorial on doing it very soon. You can find the
tutorial and loads more related to cracking at http://fusionrulez.cjb.net. 


ABOUT CRACKME
RATING   4/10  A bit tough I guess.

NO PATCHING. NOT A SINGLE BYTE OF THE FILE SHOULD BE TOUCHED.
I demand a keygen for this. 
The file is not packed for simplicity
The serial is machine dependant. Make sure it works on other machine before
submitting the keygen.
No advanced bit operations used
No explicit calls to GetDlgItemText and GetWindowText.
Well enough of clues. You are on your own from now or you'll lose the thrill of discovering!
Send a Keygen to me. If possible, write a tutorial on how you did it and I'll put it up on
my site. 

-Fornix
email: 	fornix@fusionrulez.cjb.net
website:http://fusionrulez.cjb.net

