 -------------------
|Utopia ResolveMe 02|
 -------------------

- The CrackMe have 2 levels to resolve. (03/10) and (04/10)

- It's a different crackme, NO name, NO serial, only sliders and checkbox

- Use any tools what you want

- No patching please!!

- You must discover the correct combination; only one serial works.

------------------------------------------------------------
COMCTL32.OCX is required, copy on windows\system32 directory
------------------------------------------------------------

enjoy


by deurus (August/2009)









