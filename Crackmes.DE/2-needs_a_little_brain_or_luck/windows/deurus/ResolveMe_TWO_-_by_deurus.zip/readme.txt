+-------------------------+
|Crackme: ResolveMe TWO   |
|coder: deurus            |
|Languaje: Visual J++     |
|Tested in: Windows XP sp2|
+-------------------------+

+-------------------------------------------------------------------------+
|This crackme requires the microsoft java virtual machine installed       |
|URL: https://www.alibre.com/alibrelibraries/ftp/JavaVM/9xNT4/msjavx86.exe|
+-------------------------------------------------------------------------+

+--------------------------------------------------+
|RULES                                             |
|                                                  |
|- Make a tuto and a keygen and send to crackmes.de|
|- No patch                                        |
|- No self-keygening                               |
+--------------------------------------------------+

enjoy
