what we have learned from Evolution 4:

what was bad:
Using a resource editor (reshacker) we can easily bypass/delete main initialization procedures. Also we can change many properties of the objects inside de app. Using Dede we can analyze the procedurees and see where the application terminates and other delphi functions in clear text.
What was good:
 Some patches influenced the normal flow of the program, so Tornado had to patch in many places.
So, lets work arround these facts: Evolution 5.


In this crackme you have to do anything you want to play the little game.

thanx to tornado and all

