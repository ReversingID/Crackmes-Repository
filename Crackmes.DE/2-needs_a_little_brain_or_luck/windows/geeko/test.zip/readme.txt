Long time no see. Time trials.

In this crackme you have to enable full fuctionality for another 30 days after expiration (from first run), or (harder): full functionality till 2099 WITHOUT patching the proggy or turning back the system clock.

g'luck!

questions?

Geeko