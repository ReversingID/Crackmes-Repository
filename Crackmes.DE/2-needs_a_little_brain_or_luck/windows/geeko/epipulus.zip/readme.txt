Find the correct combination to see the good boy message.
Make a geygen.
You may bruteforce.
Don't patch

g'luck

Geeko