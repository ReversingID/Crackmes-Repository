crackme written in delphi+ASM
tested on win2k, must work on any 32bit windoz

This is good one, my first protection published on this site.
I read a lot about cracking and protecting programs in the last few month. 
I am newbie but growing I think.
The fact is that I never saw or heard about such a protection scheme, as I discovered.
I think is hard to crack (or I mistake), since there it is not similar to other protections.
The idea is very simple (stupid simple)!!! U won't believe your eyes.
But simple things make great jobs.
Is so simple (and strong) than even if I tell you de mechanism, u still can't crack it!!! (I think)

U have just to enter a code to activate the 'good boy' message. Find the code or bypass it.

Warnings:
-there is not only one trap in this crackme
-the application may crash if you don't use the right code (save your work bla bla.. :-)

enjoy!
see ya soon

geeko
