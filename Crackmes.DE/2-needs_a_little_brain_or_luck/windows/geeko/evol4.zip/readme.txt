what we have learned from Evolution 3:


USing the main form's initialization events only for password checking can be easily be cracked by skipping them.
Here comes Evolution 4

In this crackme you have to do anything you want to play the little game.

thanx to indomit and all

