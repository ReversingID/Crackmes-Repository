StraightKeez.exe daybreak 56N366N3 is a valid username/key.
It takes command line arguments of [username] [key].


No patching just keygen.