FuelVM v0.1

Written on and off over the course of 2 weeks.  Pure assembly in MASM.  Assembler written in python.  Theres about 8 registers and 10 different instructions with many more planned.

To solve the algorithm write a keygen that will generate a valid key for any username!

Please comment on any bugs.  Newer versions will include anti-* as well as novel (fun) obfuscation.
	
	-daybreak