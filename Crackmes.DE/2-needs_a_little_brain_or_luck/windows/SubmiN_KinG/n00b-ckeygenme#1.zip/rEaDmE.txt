***********************************n00b***********************************
**************************************************************************
** Target    : CKeygenMe #1						**
** Protection: ;)							**
** Language  : C#							**
** Tools     : ;)							**
** Rating    : ;)							**
** Difficault: 5/10 - medium						**
**************************************************************************
***********************************n00b***********************************

Short Info:
-----------
This keygenmes is using a custom crypto-solution I came up with while I
was working on some other stuffs, and Im also using my very own Obfuscator
on the target aswell - its not possible to get the tool off from anywhere,
so its homemade by other words ;)

Rules:
------
-No patching...
-No self-keygenning (says itself)...

When done:
----------
Send your solution, and make yourself proud by overcoming this little
tricky keygenme :=)

(C)2007 n00b