Well, it's been a while since I've been in the crackmes.de scene, so I decided to come back with yet another crackme.  This one is just a tad bit harder.

Rules:
(*) No Brute-Forcing
(*) No Patching
(*) When solved, please submit a tutorial and valid keygen


For tutorials, tools, and help on ALL RCE topics, please visit BlackStorm Reverse Engineering team at:  http://portal.b-at-s.info


Greetings to Kurapica, revert, Apakekdah, SRC, lena151, obnoxious and everyone else contributing to BlackStorm!