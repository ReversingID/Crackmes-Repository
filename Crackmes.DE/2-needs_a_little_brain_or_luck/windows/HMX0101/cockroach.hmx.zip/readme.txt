First keygenme coded by me in C ;P
Its overbloated to be my first one haha :D

Only valid solution is: keygen!
Greetz to: Numernia, Encrypto, Till.ch, _pusher_, everlast, and everyone I forgot :)

Powered by: crypto ;p