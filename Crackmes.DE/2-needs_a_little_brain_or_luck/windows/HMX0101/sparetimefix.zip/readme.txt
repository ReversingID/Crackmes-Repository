New keygenme, this time coded in C#..
Since I'm new to this language, this one is easy :)

As usual: Keygen, and no patching!
Greets fly out to: Numernia, Encrypto, Cyclops, pusher, everlast, Till.ch, HVC, Adv., and all my other friends I forgot ;P