This is my 4th Crackme,
the goals are:
 -eliminate all protections
 -make a keygen
 -write a tutorial

the rules are
 -patch ONLY the protections

Done by,
HMX0101( R.E.M )

 