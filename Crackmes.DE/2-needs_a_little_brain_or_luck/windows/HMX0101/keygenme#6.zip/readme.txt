=====================
HMX0101's Keygenme #6
=====================

After a long time without write a crackme,
i going to release this easy crackme :P,
with a shit algo, but with some antidebug
tricks :D, SPECIALLY FOR NEWBIES maybe for
the pro crackers this is boring XD

To beat this crackme, you need:
	
	- Make a keygen
	- Write a tutorial

Rules:

	- Patching the goodboy jump not allowed.
	- Selfkeygen, loaders or patches
          are not allowed (because the algo is very easy)

==========
Greets to:
==========

btcentral_test, Shub-Nigurrath, Taliesin, monkey, TDC, 
Linden, _khAttAm_, l0calh0st, Ox87k, Ank83, TWiST, dila,
moofy, ScR1pT_, KLiZMA, Kerberos, R.E.M, CracksLatinos, 
and all members in crackmes.de