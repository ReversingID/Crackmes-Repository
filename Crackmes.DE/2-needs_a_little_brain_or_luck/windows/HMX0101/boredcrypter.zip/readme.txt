Bored // HMX0101
	24/07/08

I've got "bored" and wrote this crap :)
Your task is to decrypt a message, just
analyzing and reversing (?) the encryption algo ;)

Pretty simple... :D

Rules:
 - Don't brute (hey, who knows? :D)
 - Write a tut :)

Regards...