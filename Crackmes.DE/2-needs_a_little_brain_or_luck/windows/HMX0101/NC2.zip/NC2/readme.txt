Newbie Challenge #2 by HMX0101

The next one in the series!
This time you don't have to do serial fishing :D
You've to do something more interesting!... Keygenning! :)

This one looks more simple and easy than previous one :P
The algo is pretty straightforward, so.. :D

The rules!
	- Make a nice keygen... I've one, you're jealous? :)
	- Don't patch

Enjoy!