===================================
Easy crackme with some lame tricks,
to beat it you need:

 - Unwrap it manually! or write a unwrapper for this lammer protection :)
 - Make a keygen (the keygen must generate more than 1 valid serial)
 - Write a tutorial :D

Rules: 

 - Don't patch the serial comparation
   or any jump to register it :)

Greets to:

Ox87k, Ank83, l0calh0st, Ricardo Narvaja,
and all members in CracksLatinos, crackmes.de and ARTeam forum.
===================================
Enjoy it!
12/09/2006

 

