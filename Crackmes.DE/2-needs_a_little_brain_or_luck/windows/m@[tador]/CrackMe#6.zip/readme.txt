CrackMe #6 by m@[tador]

Compiler: Delphi 6.0 (No VCL)
Packer: N/A

1. Find valid Name/Serial pair.
2. Writing keygen is very hard, try to selfkeygen it.

Patching not allowed.

Good luck!
