					-NTS-Crackme

					     By
		
					   Cyclops
-------------------------------------------------------------------------------------------------

.What is NTS ?
	
		Newbie Training Series is a Series of crackmes with different protection systems
 	in the wild. It all started when one of my friend asked me to find some simple crackmes
 	so that he can start Reverse Code Engineering. Then i thought, "why cant i write some
	crackmes?" And yes, i thought upon some basic cracking steps and written some crackmes.
	And here it is, NTS. This can be used as a "Complete_Newbies" Cracking target.

.Whoz this for ?
		
		Sorry, this is not for any "Crackers". Intended only for Complete Newbies.

.Hey this protection is LAME, i can do it in 1 mins.....

		Ya, some protections are very LAME. But remember, all greatest crackers started 
	with may be ONE BYTE PATCHING or SERIAL FISHING. Every body Need a Startup, this is only
	for that.

.Ok, I have Done all of it. Whatz next ?

	Dont ask me, just grab some tougher crackme and apply ur skill ;)


-------------------------------------------------------------------------------------------------

.Gr33tz

	Greetz to all the reversers,crackers,coders in Reverse Code Engineering field.
	Greetz to all the Programmers who created such nice tools.
	Greetz to crackmes.de, where i started reversing and still learning.
	Greetz to all my friends from RCE world and REAL world, with out em i shouldn't be doin 
	this.
	Special Greetz to all Team REAL members and ofcourse -+= U =+-

-------------------------------------------------------------------------------------------------

Contact
-------
	U can PM me on crackmes.de or mail me cyclops1428[at]yahoo.com

-------------------------------------------------------------------------------------------------

			   ( Part of Project PolyPhemous (c) Cyclops )