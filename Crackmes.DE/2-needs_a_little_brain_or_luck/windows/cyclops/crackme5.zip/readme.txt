			Crackme 5.0
			    By 
			  Cyclops
-----------------------------------------------------------------------

Hi 
This is my 5th crackme.
This crackme had a passcode protection.
Just type in the passcode.
Note that there is no text field to enter the key code.
So just type the key code in the window.
This is a simple crackme so donot patch it just crack it!!!


Send the solutions to :cyclops@hackersclub.net

		Happy cracking...................
EOF