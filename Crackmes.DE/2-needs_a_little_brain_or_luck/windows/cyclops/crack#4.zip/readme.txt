			Cyclops CrackMe v4.0
			--------------------

Hi , 
	This is my 4th crackme.
	I have coded this in VC++ 6.0 using MFC.
	So need the file MFC42d.dll .U can find the files from the 
	Cyclops CrackMe 3.0 zip file situated in the crackmes.de

	This crackme also uses some cryptic algo to calculate the 
	serial number.
	The algo is not huge it can be cracked easily.

	Do not patch the .EXE as it should be too easy.
	
	Send the keyGen with src to
		cyclops1428@yahoo.com

		Bye and Happy Cracking!!!!


		(c) Cyclops

EOF