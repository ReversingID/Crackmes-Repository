1)Donot post serials at Crackmes.de
2)Donot giveout hints.
3)No patching.
4)Keygen + tut is the only soln.

How hard it is :

Its level 1.5 Max(can even be less than that).
Written just for fun :)

Greetz flyout to all at crackmes.de
Greetz flyout to members of RED CReW & TEAM iNF :)

HAPPY REVERSING & KEYGENNING.

REGARDS
KKR/RED CReW