Hi,

This is my first Crackme! Its all Written in Assembler, Everything is allowed,
you can patch etc, try to remove the nag too, write a small txt how you've done it,
if you bother, write a keygen , that's all. Hope u enjoy it!

///////////////////////////////////////////////// Bispoo 2008 /////////////////////