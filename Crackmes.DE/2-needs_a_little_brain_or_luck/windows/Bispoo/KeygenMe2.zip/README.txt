Hi All,

Continuing my first Keygenme here is Version 2 already!!! it got a few new tricks
up the sleeve, and like before Everything is allowed, write a small txt how you've done it, if you bother, write a keygen , that's all. Hope u enjoy it!

///////////////////////////////////////////////// Bispoo 2008 /////////////////////