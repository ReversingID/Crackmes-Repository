Hi All,

Here is my KeygenMe 3!!! Hope its improved from the last ones,

Copper Medal : Fish a serial for your name
Silver Medal : Understand the algo
Gold Medal: Code a Keygen

that's all. Hope u enjoy it!

///////////////////////////////////////////////// Bispoo 2008 /////////////////////