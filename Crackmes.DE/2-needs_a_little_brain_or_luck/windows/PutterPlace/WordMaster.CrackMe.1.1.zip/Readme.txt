WordMaster CrackMe v1.1
-----------------------

My recently submitted crackme was rejected because I used UPX to
compress it. Since then, I have removed that protection, and now
it contains something else you have to crack.

You must, first, bypass the "EXE corrupted" message. Then you have
to make this program last FOREVER. You are only allowed to patch
this file.

Please submit your patched file to putterplace@yahoo.com as an
attachment. Please be sure that you zip the file before sending.


-PutterPlace