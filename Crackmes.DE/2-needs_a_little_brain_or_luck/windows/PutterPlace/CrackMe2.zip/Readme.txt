------------------------
PutterPlace's CrackMe #2
------------------------

This one shouldn't be very hard to break. Much easier than my last one. All you have to do is get the proggy to accept any name and registration code. This program check the registration info when it starts up, so you have to make it to where it will always be shown as valid information. If you succeed then the nag screen will no longer appear.

Rules:

1.)  Patching only.
2.)  Do not keygen this crackme. That is not why it's here.

Submit your solutions to crackmes.de, and also email them to me at 'putterplace@cox.net'.