---------------------------------------
I                                     I
I Welcome to Linch's Premium CrackMe! I
I_____________________________________I

This is my first CrackMe coded with Batch (Cmd).
Please don't ask me for help! I did not manage to solve it yourself.
Lucky Cracking ;)

Hope you can crack this very fast and send me an solution :D

Happy Cracking!