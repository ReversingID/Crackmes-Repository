UPX'd
by BlueOwl

 In this crackme the mission is to view the originally packed code. Aka
 view the code that generates the message "Example of playing with UPX."
 Before this code the secret mission password will be shown, which you
 need to get. 

 Basically what i want to accomplish is show you that you can do some
 nice "tweakings" of upxed programs to make them harder to unpack. :)
 All the protections will trigger unique messageboxes.

Mission

 Find the mission password, which will also open the .zip file. Be sure
 to explore all the protections and write a nice tutorial about them.
 Have fun!

Details

 Packing.............UPX
 Anti-depacking......Yes (upx -d the file and see the result :))
 Anti-dumping........Yes
 Anti-debugging......Yes (simple)

Last words

 Thanks go to betatester Sinclaire for pointing out a security flaw :).
