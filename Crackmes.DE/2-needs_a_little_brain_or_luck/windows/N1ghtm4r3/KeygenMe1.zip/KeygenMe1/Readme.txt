No patch, brute force, etc!
Valid solution is only a keygen+tutorial ;)