Welcome and thank you for downloading my KeygenMe!
The goal of this is to create a keygen that generates a working key for the .exe provided.
Patching is not allowed!

Estimated difficulty (0-10): 2-3
Compiled with: MSVC++

If you manage to keygen it, please provide a solution and submit at the project page on crackmes.de!

From Finland with love,
Ollie