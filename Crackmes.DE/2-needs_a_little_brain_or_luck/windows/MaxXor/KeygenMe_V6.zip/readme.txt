Information:
============
- platform: Windows
- written in C

Rules:
======
- generate a working keygen
- patches won't be accepted


Good luck and happy reversing!
- MaxXor