Just a little crackme.

KeyGen please.

--
Bratalarm