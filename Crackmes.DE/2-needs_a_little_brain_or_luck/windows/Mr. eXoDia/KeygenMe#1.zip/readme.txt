KeygenMe #1 T.P.o.D.T:

Created by:
Mr. eXoDia // T.P.o.D.T 2010
mr.exodia@tpodt.tk
http://www.tpodt.tk

Level: ??? I wanted to make an easy KeygenMe but It's almost impossible to fish for me :)
       5/10???

Rules:

Newbie: Patch this one and send me a tutorial how you did that
Advanced: Make a keygen for me (I like c++) and upload a tutorial + your source

Info:

Take a look @ http://www.tpodt.tk for tutorials (Unpacking)

Comming soon:

OdbgScript, an intoduction (#1 of a comming serie)

Mr. eXoDia // T.P.o.D.T 2010
http://www.tpodt.tk