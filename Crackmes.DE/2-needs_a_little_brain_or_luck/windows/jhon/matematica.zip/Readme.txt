Objetivos:
	1. Encontrar la ecuaci�n matem�tica que comprueba el serial.
	2. Resolver la ecuaci�n.
	3. Resolver la cascara al ingresar el serial.
	4. Listo!
	
Objectives:
	1. Find the mathematical equation that checks the serial.
	2. Solve the equation.
	3. Skipping key entry system. (Resolve The System)
	4. Ready!
	
Jhonjhon_123