===================================
l0calh0st's KeygenME #1
===================================
Gr33ts to : Ank83, HMX0101, Ox87k, members and mods of Crackmes.de and YOU!!!

This is my first keygenme.
Just write a tut and keygen for it and send it to crackmes.de
Hint : Written in C++ :)
 
