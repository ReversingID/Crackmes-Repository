

This is a picture crackme...

You have to enter the correct value in the textbox...

By this it checks the picture with the real password...

Good luck..

Thanks to
========================
konstAnt, and cracker who try this