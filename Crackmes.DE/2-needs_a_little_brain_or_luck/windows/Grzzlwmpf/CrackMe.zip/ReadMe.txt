I didn't think about a name... You can choose one yourself ^^

===Insructions===

1: Use the Fail-MsgBox to give you the correct serial or

2: Crack it, so it accept ANY serial or

3: write a KeyGen or

4: find my personal Backdoor ^^

You can choose any of them.
Have Fun!

