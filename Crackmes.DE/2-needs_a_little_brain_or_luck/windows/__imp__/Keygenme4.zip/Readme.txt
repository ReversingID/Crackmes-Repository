Target:   KeygenMe #4
Author:   __imp__
Platform: Windows
Language: .NET (C#)
=============================================

No protection placed, so you can decompile it.

Rules:
+) Keygen;
-) No patching;
-) No bruteforcing.

P.S. Note that a correct password is NOT unique
for a name - it's not a bug:)
