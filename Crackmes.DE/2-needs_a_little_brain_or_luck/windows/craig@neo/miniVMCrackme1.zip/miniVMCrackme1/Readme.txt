miniVM Crackme v1
=================

Author: Craig Smith
Diffuculty: 2 with VM source
Rules: No Patching
Goal: Find a valid password, write a solution detailing the techniques
      used to analyze the VM.

Description: This is an example virtual machine crackme used to demonstrate
how VMs work.  It's a companion crackme to a talk I'm giving at
Recon 08 (http://recon.cx/)  At the con I will be releasing the code to
the Virtual CPU so the difficulty is assuming you have read the slides
and have the VM commented source code handy.  You can try with out it but
the difficulty is slightly higher. ;)

The algorithm is simple which is why the goal is more focused on documenting
ways to analyze VMs.  NOTE:  even though the VM is called miniVM it's
actually rather large :P

Download: After the Con check out http://labs.neohapsis.com/ for source
