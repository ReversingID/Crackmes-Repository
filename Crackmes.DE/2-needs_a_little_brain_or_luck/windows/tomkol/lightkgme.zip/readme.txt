LiGHT KeYGeNmE by ToMKoL [c4U]

Welcome to my keygenme. All you have to do is
to write fully working keygen. Everything is
fully reversible. No patch or bruteforce is
allowed. Only reversed algo is acceptable
solution. Source of keygenme and fully working
keygen is attached. To get to it you must
register keygenme for my name. When you solve
it send me a mail to tom_c4u@o2.pl