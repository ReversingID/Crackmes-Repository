Hi,
this is my 2nd crackme...
It is written in and compiled with delphi 7.
Difficulty:2-10

What you have to do: Register the app with a username and its corresponding serial so that the nags are removed (or remove them on your own!!!)

Have Fun!!!
Falcon1

http://www15.brinkster.com/george77v


Remarks:A big thank you goes to 1) all the members of BiW who are always
there at their forums(www.reversing.be) ready to help you in your reversing quest...
                                2) crackmes.de for maintaining a large database of crackmes
                                3) `ile` for having the patience to listen to my problems on mIRC 



Created At:16 August 2005