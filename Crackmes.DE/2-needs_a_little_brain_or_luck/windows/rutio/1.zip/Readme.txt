This is my first KeygenMe.
There are no anti-debug tricks, or obfuscation.
Rules: No patch/bruteforce allowed.
Enjoy.

/Lutio