Hi young crax0r ;-d 
i have a something for u 
keygen this bitch and send me the sources of your keygen + some tut if ya want :P
or just 1 working key :D

pxor@go2.pl

greets to all crax0rs/hax0rs/c0ders other mf's :P

if u found any bug in this keygenme u know what to do :d