__RULES__

1.) Patch only the "nag" and the "<Name>"!
2.) No self-keygenning!

__TASKS__

1.) Remove the "nag"!
2.) Put your name to "<Name>"!
3.) Remove the "special protection"!
4.) Code a keygen!