Keygen it, understand it (not too hard)

no patching


dc0de 2005