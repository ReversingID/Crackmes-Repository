This minimal program will prompt the user to enter a string which is then hashed. However, a nag (in the form of a message box) is displayed before the result is shown.

Can you remove this nag while keeping the program functional?

Either patch these changes to the file, or describe what changes you make.

NOTE: make sure you get the hash print-out after running the program. It is tested for Windows 7 but should work on other Windows versions as well. If you get the result printed, it works. 

####
submitted to http://crackmes.de