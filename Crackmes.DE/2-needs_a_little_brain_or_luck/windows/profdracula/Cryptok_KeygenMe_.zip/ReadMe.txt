Prof. DrAcULA presents, Cryptok KeygenMe 1
==========================================

It is the first KeygenMe in the Cryptok-series.
Hope you enjoy this!

Solution for this KeygenMe means;
1. Tutorial explaining how it works.
2. A working keygen with source(for a clean conscience plz don't rip code).

Protection Level : 2 (almost)

See u with next Cryptok Relaese.