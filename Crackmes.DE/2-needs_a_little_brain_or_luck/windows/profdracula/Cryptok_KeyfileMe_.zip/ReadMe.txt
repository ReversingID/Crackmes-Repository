Prof. DrAcULA presents, Cryptok KeyfileMe {4}
============================================

It is the 4th crackme in the Cryptok-series.
Hope you enjoy this!

You have to:
1. Code a keyfile-maker(inline-keygen is not allowed).

Solution for this KeyfileMe means;
1. Tutorial explaining how it works.
2. No patching, no self-keygenning.
3. A working keyfile-maker, with source.

Protection Level : For you to rate it

See u with next Cryptok Relaese.