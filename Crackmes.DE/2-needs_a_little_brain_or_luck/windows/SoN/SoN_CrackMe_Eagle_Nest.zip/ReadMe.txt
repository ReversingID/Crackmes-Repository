SoN CrackMe Eagle Nest

Objective: Write the dongle software that will feed the CrackMe a correct code when requested.

Rules: No patching of the exe.


This is another product of SoN's short creative burst. We enjoyed writing it so you should enjoy
cracking it! It should work with all versions of Windows but it's only been tested on XP SP2 and 
2000 Server. If you find any problems just let us know. Again, enjoy it and we hope you learn
something new.


Here we are then. London, Earth... Solar system. I did it.