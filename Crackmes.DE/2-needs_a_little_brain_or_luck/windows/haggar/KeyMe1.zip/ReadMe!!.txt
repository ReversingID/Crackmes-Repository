Hi folks!

This lame crackme is for totally newbie's , but beware of very simple but very annoying anti-Olly trick(s).

Do not run this crackme if you are surfing the net, or you have important documents opened. Close all and then try to solve this crackme. I stole trick from one protector. I threw some junk code inside just that it is not so obvious.


Your primary task is to find valid serial. It's simple but it needs to be bruted. No, it's not crypto (far away from that) and serial consist only from numbers and .... you'll see.



So find serial and explain anti-stuff. Good luck :)



PS

Tested only on Windows XP SP1.