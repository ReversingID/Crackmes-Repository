Hi and welcome to new crackme!



1. Your primary objective is to create generic keygen. It should be very easy. And no junk code this time.
2. Secondary goal is to describe anti-stuff. It is also easy and nothing new, so that won't be problem too.
3. And for the end, write solution to help others who don't have such skills as you :)



Greetings goes to everybody on this great site. Special greetings goes to l0calh0st for solving (and writing nice solution) my first KeyMe1.
 


Regards, haggar ;)



PS

Sorry for shitty coding and possible bugs, I tried my best. If you have any suggestions , please give your comment.