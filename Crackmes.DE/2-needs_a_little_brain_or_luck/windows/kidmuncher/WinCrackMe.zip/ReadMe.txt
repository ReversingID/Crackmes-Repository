This is a very easy Windows Crack Me.

Instructions :

1 - Crack Me.
2 - Write a Keygen .

KIDMUNCHER - 12/08/2009