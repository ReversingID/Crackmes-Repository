********************************************************
*                   ScrewMe #1 by Dynasty                         *
*                                                                                 *
*	               Jan, 2008                                     *
*                                                                                 *
*    for the sake of all newbie reversers out there,      *
*                  in particular those of                              *
*                                                                                 * 
*                 http://deezdynasty.xdir.org/ !                *
********************************************************


Level 1, if that. 1st one I've ever made so tear into me if you like. 
I suppose you can't expect much better from an inexperienced "coder". 
Not original enough for you? Then suck my ass ;)

***************** Description  ***************************
-- not packed
-- no crypto
-- very, very easy anti-xxx (if i may even call it that)
-- nice serial routine (well I like it, so sue me!)

******************* RULES: ******************************
-- GET THE GOOD BOY MESSAGE.
-- NO PLAIN STUPID PATCHING.
-- NO PLUGINS is always more fun ;)
-- TUTORIALS AND FEEDBACK MORE THAN WELCOME
-- KEYGEN the fuck out of it if you can (tho you might
        need more than that...)

********************************************************
       *************** Contact *********************

Send your tutorials, keygens, comments, candy, cute banging hot
girlfriends, or even naked pictures at

                       deezdynasty@gmail.com

Otherwise, I guess you can just post on my stupid forum :(

	http://deezdynasty.xdir.org/forum/


~~~~~~~~~~~~~~~~ QUICK GREETZ ~~~~~~~~~~~~~~~~~~

== Ez�qui3l : of course, if it wasn't for him, there wouldn't even 
be a CrackMe to start with. He simply ROCKS. THankS dude!

== Kaine : for his advice even tho I didn't manage to do half
of what he suggested! (Nxt time man, I promise ;))

== Me : cuz ... well just because you can't forbid me to.

== YOU : for taking an interest, as little as it may be, in this
piece of crap.

~~~~~~~~~~~~~~~~~~ Dynasty - 2K8 ~~~~~~~~~~~~~~~~~~~


