#---------------------#
|  DevilMayCrack #1   |
+---------------------+
+---------------------+
|Rules:               |
+---------------------+
| 1. No patching!     |
| 2. Make KeyGen      |
| 3. Write a tutorial |
| 4. Feedback pls     |
+---------------------+
|  Have a nice day.   |
#---------------------#