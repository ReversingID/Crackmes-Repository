Welcome back!

	This is my new generation of crackme's written in C++!  I'm back and with a new arsenal of weapons such as the newly built API's (just kidding) and other fun stuff in my First C++ Crackme.  For any novice, this crackme should take no time (and maybe even for some beginners).

Name can only be in a one work style.  Like:

John_Doe
JohnDoe
John

-but not-

John Doe
Joe Noodle
Party pooper
Hell's Kitchen

Rules:
Like everone else:
-No patching
-Keygen it (algorithm will make you snicker once you find it out.)

Send all results to: idq000@prodigy.net

Good Luck!

TARGET: cnew.exe
TARGET TITLE: "First C++ Crackme by idq000"
VERISON: 1.0
COMPRESSOR/PROTECTOR: None.
STATUS: COMPLETE/REVISON1.