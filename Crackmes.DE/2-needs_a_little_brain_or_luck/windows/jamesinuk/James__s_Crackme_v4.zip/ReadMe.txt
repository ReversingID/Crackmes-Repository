James�s Crackme v4 

This is a test of observation. You must manipulate this crackme (without patching) until you get the success message.

Once you have managed to solve this crackme, write a tutorial.

You need an internet connection by the way�but since you downloaded this anyway�it�s all good.

Good luck, James
