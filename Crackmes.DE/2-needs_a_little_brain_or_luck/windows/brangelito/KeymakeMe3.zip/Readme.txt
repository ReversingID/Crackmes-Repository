KeymakeMe #3

This keygenme should be pretty fun, because it's
kinda unique. The scheme isn't keygennable if you
don't know a valid key already.

Thus, I will give you one:
XXB691C349AD753912BC9E1F9F1587XX

However four of the hexadecimal digits are 
missing (they are marked with X). Your objective 
is to bruteforce these digits, then use this 
serial to keygen other valid serials.

As you'll also notice that the algo really
isn't bruteforcable, at least not without some 
limiting modifications..

Good Luck!
/Brangelito