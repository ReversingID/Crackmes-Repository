KeymakeMe #1

Partial bruteforcing is allowed, if math knowledge isn't sufficient. 
No patching allowed. 
Enjoy!
