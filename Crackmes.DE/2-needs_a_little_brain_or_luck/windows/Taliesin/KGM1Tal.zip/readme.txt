KeyGenMe 1 by Taliesin

Window32 - Tested on XP and Win98.
Assembler - MASM32.


To complete:

1. Bypass debugger checks.
2. Write a keygenerator.
3. Submit keygen and tutorial.

Completion should be relatively easy.  Only a few debugger checks.  Algorithm for serial is not too complex.


Greetings go out to:

l0calh0st
HMX0101