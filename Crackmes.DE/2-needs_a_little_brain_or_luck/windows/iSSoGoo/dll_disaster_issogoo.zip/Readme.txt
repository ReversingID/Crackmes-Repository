Name:...........'.dll .disaster'
Author:.........iSSoGoo
Date:...........2013-04-02
Difficulty:.....2/10
Contact:........issogoo(at)gmail.com


Task:
	In this Crackme (it's not really a Keygenme) I wanted to show you how you could use some 'leftovers' to exploit a program.
	Your task is to find the right place to 'inject' your .dll file and let the program show the goodboy-message.

Rules:
	The rules are simple: Don't change anything (neither the .exe nor the .dll that are included)! 
	No Patching, no loaders, no WriteProcessMemory etc.
	You are only allowed to read from the process!
	I wrote my own solution and it's less than 20-30 lines of code (Assembler). 

Notes:
	This one is easy, so it's doable for beginners, too. It has a 2/10 rating, but I thinks somewhere between 1 and 2.