+----------------------------------------+
|  ****Triangle KeyGenMe by iSSoGoo****  |
+----------------------------------------+
|                                        |
| Rules:                                 |
|    1. Don't patch anything!            |
|    2. Don't make a serialfisher!       |
|    3. Don't make it self-keygenning!   |
|    4. Write a KeyGen                   |
|    5. Write a nice tutorial            |
|                                        |
+----------------------------------------+
|                                        |                             
| Achievements:                          |
|                                        |
|    Bronze:                             |
|        - Rip the code to make a KeyGen |
|                                        |
|    Silver:                             |
|        - Code your own program         |
|                                        |
|    Gold:                               |
|        - Code your own program         |
|        - Find out why it's called      |
|           'Triangle KeyGenMe'          |
|                                        |
+----------------------------------------+
|                                        |
| Contact:                               |
|    issogoo (at) gmail.com              |
|                                        |
+----------------------------2013-Jul-08-+