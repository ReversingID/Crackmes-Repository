Target:.........KeygenMe #3 
Author:.........iSSoGoo
Date:...........2014-05-13
Language:.......C++
Protection:.....Serial


Intro:
------
After solving TDC's 'CrackME [#4]' I was a bit disappointed that it wasn't a KeygenMe, but only a PasswordMe.
So I used the main routine to make a KeygenMe.


Note:
-----
The code is pretty clear and easy to understand, but to write a proper keygen you must have some brains!
After all I know a bit bruteforcing is necessary, but you can easily generate multiple keys per second, so nothing too difficult.


Rules:
------
No patching, self-keygenning (is this even possible?) or anything else.
A valid solution includes a proper keygen and a little tutorial.



Medals:
-------

Bronce: 
 - ???

Silver
 - Write a 'stupid' Keygen & Tutorial

Gold:
 - Write a 'smart' Keygen & Tutorial

Platinum (if possible):
 - Write a keygen that needs no bruteforcing




Fix-Note:
---------

I used the wrong nMaxCount value for GetDlgItemText ;)


Virus-Scan:
-----------

https://www.virustotal.com/de/file/e4978f0a0297e5b8713c35ae10a9455c1a9e59412251ff5b5cb274d20043d857/analysis/1401398823/