================================================
This is my first CrackMe. :)
================================================
Rules:
1. Do not Patch
2. Sniff a serial for your name
3. write a keygen

================================HappyTown=======