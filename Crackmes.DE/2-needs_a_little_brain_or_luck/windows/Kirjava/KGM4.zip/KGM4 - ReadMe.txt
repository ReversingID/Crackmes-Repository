
/*		Kirjava's KGM4		*/

Goal:
Make a keygen! Self-keygenning/patching is allowed, but discouraged.

Good luck and have fun!