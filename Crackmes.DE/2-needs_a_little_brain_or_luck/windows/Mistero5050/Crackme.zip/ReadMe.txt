RULES:
-Do not patch
-Find the password

This is my first crackme so please go easy on it :)
My email: armellini.federico@gmail.com