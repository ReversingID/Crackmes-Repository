
ReWrit's Crackme #12
---------------------

Another Crackme.

Rules / Goals:
--------------------------------------
* Write a keygen and tutorial
* No Patching(includes self-keygen)
--------------------------------------

Name:		ReWrit's Crackme #12
Difficulty:	2 - Needs a little brain (or luck)
Platform:	Windows
Language:	C/C++





Thx to kcynice for helping me with the gui