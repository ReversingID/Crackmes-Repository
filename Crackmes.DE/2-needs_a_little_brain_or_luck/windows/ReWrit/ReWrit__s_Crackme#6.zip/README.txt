
ReWrit's Crackme#6



Rules:
--------------------------------
* Only Keygen will be accepted.
* Self-Keygen is not allowed.
--------------------------------


Name:          ReWrit's Crackme#6
Difficulty:    2 - Needs a little brain (or luck)
Platform:      Windows
Language:      C/C++