
ReWrit's Crackme #11
----------------------------------------------
This is my first crackme/keygenme
that has "One-name-many-serials",
my other crackmes only have one
serial for each name so give this
bastard a try =)

Special thx to Numernia for helping
me with this crackme.


Rules / Goals:
----------------------------------------------
* Gold:   Keygen and solution + Bronze
* Solver: Try it and rate it
* Bronze: -

* No Self-keygen, i want a real
  keygen
----------------------------------------------

Name:		ReWrit's Crackme #11
Difficulty:	1 - Very easy, for newbies
Platform:	Windows
Language:	C/C++