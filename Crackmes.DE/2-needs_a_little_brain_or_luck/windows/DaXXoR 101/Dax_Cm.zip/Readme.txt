Find the valid keyfile! 
no patching.

Only tested on winxp
DaXXoR101@gmail.com