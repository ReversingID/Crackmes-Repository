1.  The file is not packed.
2.  I have used some common antireverse engineering techniques, I did not invent these techniques so I take no credit for them.  

TO COMPLETE:
1.  Make a keygen
2.  Make a tutorial

You must actually show how you got rid of my antidebugging techniques, your solution will not be accepted if you do not show how to get past the antidebugging techniques.  No bruteforcing, serial fishing, or cracking allowed.

Most importantly, have fun!