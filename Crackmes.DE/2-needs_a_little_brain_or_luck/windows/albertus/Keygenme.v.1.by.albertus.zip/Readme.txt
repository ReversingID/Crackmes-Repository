This is my first crackme, so I'll be happy to see any feedback. 
Patching is not allowed. Please write tutorial and keygen.