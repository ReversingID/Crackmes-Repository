|UTW KeyGenMe v4|
-----------------

- Written by otromasf
- More hard that UTW KeyGenMe(v3)

Target:

- Make a keygen
- No patching allowed
- Write a tutorial

----
NOTE: Is possible it doesnt work on SP1 Platforms...
----

Good luck!