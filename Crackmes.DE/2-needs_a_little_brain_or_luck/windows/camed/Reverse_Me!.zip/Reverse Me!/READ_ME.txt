Reverse Me! 1-7
(c) camed/chomikos
http://camedcomputing.wordpress.com
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Helpful software:
- IDA - https://www.hex-rays.com/products/ida/support/links.shtml (Interactive Disassembler)
- Wireshark - https://www.wireshark.org/
- Cain & Abel - http://www.oxid.it/cain.html
- Process Monitor - https://technet.microsoft.com/pl-pl/sysinternals/processmonitor

Of course you can also use another software, these are only my recommandations.

About:
Reverse Me! software is designed to teach begginer reverse-engineers basics of reverse engineering.
All of challanges are easy, none of them needs additional DLL which reverse-engineer should program.
All of them look very simillar, but they are checking completly another skills.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Have fun!
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
