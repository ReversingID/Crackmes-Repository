BTCentral Crackme 3

I have written a protection method for EXEs,
this protection method contains multiple checks
throughout and no error messages. If the file
has not loaded your crack simpily does not work.

Aims:

1) Remove EXE's Protection.
2) Change text displayed on the EXE form.

Have fun!