This is my second crackme wirtten for crackmes.de

It is written in Visual Basic 6.

The target is simple: enable the "Check" button and write a keygen or simply find a correct serial for yuor name.

Rules: Patching is allowed only for enabling the button, patching the serial checking routine is not valid.


Cheers,

EvOlUtIoN