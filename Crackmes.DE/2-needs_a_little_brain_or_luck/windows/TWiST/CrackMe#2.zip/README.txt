Hi,

Welcome to this crackmes. I hope you'll enjoy it.

Your objectives are:
1) Create a keygen for it
2) Remove the starting nags, and the 'Will you patch me too" nag :-). The other nag will be removed when you enter a valid serial :-)
3) Replace the XXXXXXXXX with your name

I hope you'll enjoy it!
Bye!


 