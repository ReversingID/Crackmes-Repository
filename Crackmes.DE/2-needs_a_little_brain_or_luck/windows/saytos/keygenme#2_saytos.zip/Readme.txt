.:.:. Keygenme#2  .:.:.
---------------------------------

Compiled in : MASM

Date        : 5.01.2007 3.57 am

YES         : keygen with src

NO          : self-keygenning,patch,serial-fishing

Tested on   : WinXp SP2

Happy cracking :)

 saytos
       /2007

