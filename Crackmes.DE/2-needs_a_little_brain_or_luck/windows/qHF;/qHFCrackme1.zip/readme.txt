Rules:
No Patching

Keygen is a must!
tutorial if you have the time.
but minimum is a solution.

~qHF