serial - File to enter valid serial

Challenge: Find a valid serial key!

Limits: None! Do what you want. Use anything.

Post full solution with a valid serial please.

Notes:

-You'll probably only be able to use FreeBASIC
to crack the serial
-You can change the statements which determine
a valid serial or not, but thats not fun. I will
only accept a solution with a valid serial

I may open-source serial.bas at some point.

Good luck (this should be easier than my encrypt program ;)