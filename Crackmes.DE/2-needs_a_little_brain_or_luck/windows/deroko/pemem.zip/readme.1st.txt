keygen crackme

Only one rule, do not patch good jmp, everything else is allowed including
keygen, self-keygen and coding loaders to get good key =)

                                        S verom u Boga, deroko/ARTeam
                                        
                                        