Objective:

Find key for RAR...

This is easy crackme (maybe not so easy)... 3/10...

If you find correct key please contact me at deroko@gmail.com
so I can send you nice source file that is included in RAR as
bin dump =)

                                   deroko...