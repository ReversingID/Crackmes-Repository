snow by _raven
_________________________________________________
Compiled with Microsoft Visual C++ 2005

Rules:
- No patching!
- Solution is a working keygen and a tutorial!

It uses a modified algo of my Justfun keygenme.
_________________________________________________