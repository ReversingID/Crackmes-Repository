Rules:
1. Get the serial. It will be different every time,
   so you should make an keygen that generates
   serial with the same algorythm.
2. Do not patch!
3. Write a tutorial

Hints:
Serial consists of 30 numbers!!