Hola!

Crap! My 1st UnpackMe rejected. Why? 
It was very intelligent...
Very good fighting in comments died...

After 2 months...
KLiZMA wrote another unpackme for you.

Rulz:

1. Unpack it maliciously...
2. Change "UNREGISTERED" to "REGISTERED"
3. Write tutorial about...


Phanx:
- Ox87k, Kerberos, Ank83, HMX0101, CP3
- crackmes.de
- AHTeam and xt
- my girlfriend


                                     KLiZMA
                         -==fR0M RuSSiA WiTh l0VE=--