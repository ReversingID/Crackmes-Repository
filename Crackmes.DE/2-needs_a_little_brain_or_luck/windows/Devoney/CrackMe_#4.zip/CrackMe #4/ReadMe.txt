CrackMe #4 - By Devoney

Name: 		HideWindow
Difficulty:	2 (on a scale of 1 to 10)
Executable: 	MainApp.exe
Goal:		Unlock the menu item "Hide Window" by filling in the right password
Security:	Password protected


Additional Information:
I have made this crackme because I am trying to get the hang of C/C++. 
It is compiled by a standard BloodShed Dev-C++ installation.
I have rated this crackme as 2 (scale 1:10) because it easy but it uses one trick concerned the reading of the password - thats a hint ;) -
If you dont know about GetDlgItemInt then this is still doable for you ;) If you do know about it, then you will find the trick quiete easily.


About Patching:
I dont care if you patch -Try http://www.crackmes.de/users/devoney/crackme_3.0/ if you like to patch ;) -
But if you patch you will not learn how this one is solved properly by yourself ;) and you will not discover the trick by yourself.


Your Reward:
The last time I posted a crackme the reward where chills down your spine if you looked up the location in the message at the end.
This time your reward is the possibility to use a functional application.


Goodluck, have fun and mail me with questions/solutions/greetings etc.
Devoney (klerkdemike@hotmail.com)
