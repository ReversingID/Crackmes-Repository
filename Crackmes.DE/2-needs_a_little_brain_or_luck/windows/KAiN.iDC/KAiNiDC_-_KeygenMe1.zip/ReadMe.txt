Hi, This is my first KeygenMe,
All you'll need will be (+,*,-,/, and Xor Operands).

The rules are:
 - NO PATCHING !!!
 - NO SELFKEYGENNING !!!

The goals are:
 - Remove KeygenMe Protections.
 - Make a keygen
 - Write a tutorial

Created by KAiN.iDC,
please submit the solutions on crackmes.de