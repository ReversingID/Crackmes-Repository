br0ken's  CrackMe3
22/05/2008


Levels
******

Paper Medal = For Attempting

Bronze Medal = Phishing/Patch

Silver Medal = SelfGen

Gold Medal = Keygen + src + tut

-----------------
For a solution to be valid on crackmes.de, you must do it the GOLD way :)
-----------------

Have fun!

Regards,
br0ken.