
Serial/Keygen Me


Date  - 26th March 2008

Level - 2/10

To do - 1. Find a valid password.

	2. Make a password generator - ***OPTIONAL***


Rules - 1. No rules, do anything you want, as long as the password works
	
	   on the unmodified exe.


It's got some math invloved, shouldn't be much of a trouble.


Regards,
br0ken.
