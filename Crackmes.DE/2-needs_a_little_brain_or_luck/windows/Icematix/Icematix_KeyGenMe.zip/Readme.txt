Hi.
This is the first crackme I ever made in my life, so I hope its not too bad. :)

Its a standard-KeyGenMe asking you for a serial to access the goodboy.

To achieve this I combined two simple encodings.

No solution is accepted without adding a working keygen ! :)

That means no patching etc.

Well, I can only wish you some fun ! :D

Greetings,
Icematix