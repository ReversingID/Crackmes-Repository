Written by: TDC
Date written: Thursday 3 November 2005

Rules:
=-=-=-=

No patching at all, just find the tricks and avoid them :-)

Description:
=-=-=-=-=-=-=

Little checksum generator, some multiplies, nice little design and song.... yeah another good crackme IMHO :-) Thanks to Linden for the idea.