Written by: TDCNL
Date written: Sunday 22 January 2006

Rules:
=-=-=-=

Absolutely no patching of the codes to make it show goodboy message. Give the program it's serial and it will give you goodboy message.

Description:
=-=-=-=-=-=-=

Crackme for all of REM users and other guys/gals :)