Written by: TDC
Date written: Thursday 3 November 2005

Rules:
=-=-=-=

No patching at all again, now more anti-debug tricks and some string hide obfuscation.

Description:
=-=-=-=-=-=-=

I don't tell too much :P If u want to become true level 3 keygenner, do this one yourself :-)