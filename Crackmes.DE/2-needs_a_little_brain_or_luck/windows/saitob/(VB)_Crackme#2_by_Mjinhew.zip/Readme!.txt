Crackme#2 by Mjinhew
Language: Visual Basic .NET
Main Class: Approximately 140 lines of code

NOTE: REQUIRES THE DOT NET FRAMEWORK.

Mission:
Bad: Find a valid serial
Not that bad: Make a keygen
Good: Make a keygen in a non framework based environment
THE VERY BEST: Make a keygen in a non framework based environment
 + a tutorial

Hint: It's created 10 serials for your System ID where only 1 is correct. Remember that in your keygen ;)

Send your solution to tobberg@gmail.com or to crackmes.de

Happy Cracking