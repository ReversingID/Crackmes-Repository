alright so i had a funny idea for a crackme and somehow i managed to throw it together into a working program..

the base program was an empty c++ program full of NOPS then i worked my magic in olly to write the actual program :)

please have fun with this.. i was not sure what difficulty to rate it.. but i think it is somewhat difficult :) 

a keygen is what im looking for and i will also except a self keygen but i would love to see one of each. 

no patching though... that would be way too easy lol :)

thank you and have fun

FJLJ