====================
= Crypto Machine I =
= "Weak Algorithm" =
=   by  ksydfius   =
====================

Welcome to Crypto Machine I.

This is a program that will encrypt your plaintext with a key.
Provide the key as a set of hex bytes, separated by a space

Example: 12 34 56 78 90 AB CD EF

The encryption algorithm used is very weak, and goes to show that
sometimes simpler is not always better :)

Your aim, as usual, is to analyse the encryption algorithm and
decrypt the following cipher text:

A9 4C A9 ED A5 65 1E 10 76 CA 82 7A 90 69 EF 68 E6 01 38 A4 43 
8A 5B 70 A8 6E EA 92 E9 2D 9A 5A 3D 50 A4 2A 29 2B 1B E6 56 12 
AC 2C B4 6C A4 F3 83 EC B7 ED 31 B3 E1 4B 37 0B 62 32 0C 6B A6 
D1 9E 07 31 7B 47 28 11 D1 99 07 FE 57 EA A0 5F 07 6D 3E 38 4B 
AE 4C BB EB 79 1C 2F 31 9D DA A7 6F 87 8B 88 B9 49 E2 53 25 FD 
49 51 28 B6 48 11 4A BD A1 06 C1 5F D1 0F F6 A4 31 51 1C 5A E4 
FF 74 21 F4 48 20 7B 55 BA 9A D4 8F 46 B7 80 5C 17 CE 85 3D 9F 
02 52 56 05 63 BD 0B A9 19 60 88 62 F8 4D E6 B1 77 16 EE 0C 2D 
80 8D 06 F4 E1 B6 B3 83 21 78 84 A0 68 FC C5 E8 ED 8D 71 E4 0D 
26 95 49 C7 3A BB 0D BB B0 C3 A6 47 45 FE 08 91 14 51 3F E4 14 
2E 20 21 1B E7 6A B3 0B 3E A9 29 E5 5F 49 BA 05 A4 A7 E5 DA 59 
4A 22 A7 7B 4D FB 8A 15 5C D2 4F D9 01 B4 B2 46 69 53 45 DE A4 
A7 E5 B5 7A 1E 25 F5 11 2E F2 22 4A DD 04 25 57 01 B5 6E 8D 87 
96 7C 0C 10 CD 13 ED 9A 5E 3C 59 D0 8F 9D 8B B2 C6 2A 7D CC 68 
19 23 08 63 58 4C 05 19 B3 BF 85 52 90 6A BE A8 22 29 21 DD 47 
49 42 99 47 1B 23 F5 DB CF D2 90 1D B4 B7 C1 16 6B 0F 69 BD 15

Have fun,

-ksydfius

Note: The plain text contains printables (0x20 to 0x7A inclusive) and is 100% readable

