=======================
- The XOR Algorithm 2 -
-  Coded by ksydfius  -
=======================

Hello crackmes.de community,

well this is the 2nd edition of my series of cryptanalytic challenges

since the first one was way too easy, i have made a simple slight change to
the algorithm

do u think this change made the algorithm more secure? :P

have fun,

-ksydfius

