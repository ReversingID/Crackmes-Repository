=========================
=   Crypto Machine II   =
= "Stronger Algorithm?" =
=     by  ksydfius      =
=========================

Welcome to Crypto Machine II "Stronger Algorithm"

As usual, your aim is to analyse the encryption algorithm and
decrypt the following cipher text:

27 C9 A1 C4 1B F3 7A 1C EC 2D 7F 88 5C A6 45 DE C6 8F 78 A3 ED 
FF 3E D7 0A 04 1B 01 27 8F E1 F9 14 DF 36 9B 45 93 AA 38 B3 05 
48 A3 F6 F4 D5 7F 4D CE AC E9 86 43 D8 54 AF CD 5A 04 E5 42 88 
C8 DF E0 DE 68 9F C3 8A F0 4D 52 D4 76 DC 80 D3 7B E1 17 91 1C 
65 53 B7 B3 C5 E6 6B B7 2D 0D 8B B4 0A 82 AD 89 55 42 BE 50 CE 
C5 78 9B F8 92 88 1A 75 06 1B 0C 3D 59 3E 81 49

Below, you have a plaintext encrypted with the same key used to
encrypt the above text. Use this to your advantage :)

Plain Text (no line breaks):
Modern cryptography is heavily based on mathematical theory and computer science practice; cryptographic algorithms are designed around computational hardness assumptions, making such algorithms hard to break in practice by any adversary. It is theoretically possible to break such a system but it is infeasible to do so by any known practical means. These schemes are therefore termed computationally secure; theoretical advances, e.g., improvements in integer factorization algorithms, and faster computing technology require these solutions to be continually adapted. There exist information-theoretically secure schemes that provably cannot be broken even with unlimited computing power, but these schemes are more difficult to implement than the best theoretically breakable but computationally secure mechanisms.

Cipher Text:
12 E8 2D 76 2B 4F 45 E6 2F 0F 55 42 0A E4 D9 00 11 FD D4 FD 16 EF AD 1E 38 EE B7 10 ED 2C 7E BD 70 D4 EE E9 F3 B4 63 BB 5A 90 31 28 68 24 1A 4A E0 68 77 BF 28 8E 25 C0 28 15 96 41 D4 97 83 C5 68 79 0E 5D EC 7C 42 D8 69 C2 CE 74 80 09 B5 C0 71 A9 E7 43 C4 29 4F E2 E0 10 7B 7B 2F 0F 55 42 0A E4 D9 00 11 FD E4 00 BD 3C 2C 0D 32 FD 8C 31 59 22 F8 02 D0 7B 62 EB 48 C6 DE B7 A6 0B 36 B8 22 69 53 5B 18 81 A2 19 90 88 96 99 AA 17 F6 55 E2 DE 69 7C E1 3B 09 BF FB A9 C3 FC DE AD 93 7A BE 7B 5C 3A 67 01 F8 FC 4B 16 7E D1 08 EE A4 D0 7D D2 33 A6 C0 72 BB 04 D0 31 EC EA E1 ED 49 51 CA 82 35 99 14 D7 C5 D1 55 5C 35 93 1D 19 6C 70 63 85 C9 6D F9 F5 58 42 69 99 68 08 3B E8 12 19 92 EB 36 5B F0 45 ED 2E E5 F2 D0 2F 84 3B 5D A2 91 E6 92 FC 29 49 91 80 0A 5D 0E 20 72 4E DA 96 EB 5E 4B 2D 94 D8 50 88 D7 E8 7E 8F 5B 7C 19 8F 3B D8 E6 16 F5 98 1B 2E CF 3F BC D1 5C 6A 0C FD 7E 20 BB F7 BC C9 5B F8 11 A9 7E 82 35 98 A5 83 DE A6 F4 9D D5 11 E4 A9 0C 46 69 E9 08 E1 E6 EE F5 A7 14 41 28 24 B7 A5 F0 6D DC B2 E9 16 1D 83 00 02 47 8C 64 7C BF 91 62 F0 A2 EB 27 3D 9E 22 36 33 96 66 6F 36 3C 71 C8 E6 AC 4E 2B EA 12 ED 87 47 8B 6D 57 20 C3 52 25 1E 78 2B C2 D7 FA 80 C2 FF F4 52 10 A5 EC 7C 3E B5 BC 24 E3 57 FD E5 0C 17 93 8E 84 10 C7 DE B2 7E AB 8D 4C D8 09 28 B5 70 7E D3 F9 3F BC 95 2F 44 39 52 3D E2 0B AF 08 49 E8 F3 7F 77 84 86 B3 6B B0 47 8D 1A E0 C3 C5 6E 73 C7 F3 28 79 F3 EF 9E 42 E8 A1 8F 4D 7A AE 45 D2 53 3D 65 B4 B2 62 2A A8 50 82 8A C3 FA C7 5F FF 91 88 AE 65 28 81 9F 4C BB 63 BE 2E 03 EA 4F C7 E8 E8 FA A1 AC 11 CC 73 4A 19 9D 48 9E AE 42 63 BF 67 EC 5C 95 ED 5A 4C 52 74 97 41 D3 5C D9 AA 92 7E 3B 6E 9D B1 48 42 0C 2A A8 21 97 A9 72 01 2E 99 15 CD A0 E7 7C 36 07 68 8A 51 14 D8 A9 76 E9 34 FB 8D D3 A5 A5 AD 4A 3C 0B D7 F2 70 0C 89 78 6E C9 5B F8 FB 00 09 A5 7C 0F 0F 48 B2 05 A6 17 35 20 24 E7 48 79 5C BE 56 55 96 38 70 E8 68 C8 0F 99 A4 F3 DE D6 73 13 EA 54 FE FD 31 59 2E 51 A5 A9 E7 41 CB 1F 2F DE 82 D2 83 56 57 F4 08 B5 F5 A7 20 55 89 2F 92 76 0C 77 C5 19 21 28 DE 29 4A F4 E7 96 10 9D 19 B5 54 00 04 95 FC F3 C5 68 79 0E 5D EC 7C 36 07 5A 25 A3 92 50 FA 5F DA F3 A7 25 8D 33 A1 E7 50 B6 7A 17 93 88 11 A4 A8 D4 EF AD 15 DF D4 DD F8 74 57 F2 70 0B 0C F7 29 50 C0 50 F9 24 19 3B DD E7 C2 89 E1 8F C2 FE 40 BB FB 63 55 61 28 F4 D1 EF B1 D0 9B 84 1F FA 29 E6 75 79 E2 D8 7F 8E DD E6 14 90 2D 07 29 3B BC ED 5A 5C 86 44 2D 66 00 3B 03 FC 4F 45 15 8E F8 55 2D 77 CA 29 B8 42 F9 2E F6 9A 5A A1 4E F0 A4 94 99 A4 F3 C0 5A 26 7D 1F 23 58 BE 65 6E 7D 

Have fun!

-ksydfius

