greetz crackmes.de users,

this is a little crackme i made which will hopefully show u that
not everything is as hard as it seems.
dont bother trying to brute force it :)
if u truly understand the program, u can find the pass in 1 sec

enjoy :)

-ksydfius