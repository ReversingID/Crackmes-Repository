This is my third crackme :)
ok make a keygen
upload a solution
RULES
*****************
No bruteforcing
No selfkeygening
********************
patching is allowed :P

good luck & have fun!
