This unpackme was packed with my own protector written some time ago in C.

No special taks, just unpack it.


Have fun ;)