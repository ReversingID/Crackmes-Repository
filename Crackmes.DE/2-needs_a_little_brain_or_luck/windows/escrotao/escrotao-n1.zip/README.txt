This is my first crackme I think it is a bit easy. 
Lets see what you think.

You should find a valid serial and write a keygen 
without patching the crackme.

I didnt test this crackme in Vista, the keygen could
be different depending on windows version, so when
posting a solution post the windows used.

Escrotao.