============ Dreadnought ================

This Crackme is just some Test of AntiDebug- 
Tricks and Code-Obfuscation. There is nothing really
special to expect. Might be a bit full of Junkcode...

Have fun anyways,

DeepBlue aka +++ATH0