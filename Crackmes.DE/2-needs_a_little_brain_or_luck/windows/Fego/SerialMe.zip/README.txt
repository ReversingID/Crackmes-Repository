Your Goal is to find the correct serial for the CrackME.
Honestly i dont know how hard it can be so try it out your self and let me know.
Written in pure Assembly using MASM.

For anything (really anything) contact me at

federicogorla at hotmail dot com

I'll see ya!