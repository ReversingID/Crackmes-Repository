Hello!

This is my second KeyGenMe. It's not so easy, as my first keygenme, but YOU CAN crack it! =)

In Name please write Latinic symbol ("A".."Z", "a".."z") and (or) numbers ("0".."9").

Coded in Delphi

File is of course not packed :)

Good luck!

10/09/2005 