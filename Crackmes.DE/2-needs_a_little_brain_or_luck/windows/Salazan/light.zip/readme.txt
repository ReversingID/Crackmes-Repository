Light keygenme

Rules:
1) Try to keygen it... less then in ten minutes :)
2) Submit your solution

Thank's.