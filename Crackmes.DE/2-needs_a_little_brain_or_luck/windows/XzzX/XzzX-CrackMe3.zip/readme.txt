*******************************************
************** XzzX#CrackMe3 **************
*******************************************

author    : XzzX
created   : 01/07/2007
language  : Assembler / MASM

difficulty: 2/10

goal      : gold   : write a keygen
	    silver : find a serial for your name
            bronze : patch it :-(

	    additional point: How is the algo called?

rules     : for a solution you have to do it the gold way ;-)

info      : no anti-debugging tricks
            no packer

Don't cheat! ;-)

If you encounter a problem/bug/question/etc feel free to write a comment or send me a pm.

Please send me your solution when you've solved it. ;-)

gl&hf
XzzX