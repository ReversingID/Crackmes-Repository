I present you my second FPU KeygenMe. You may be wondering where's the first one.
Well, I decided not to publish it here, because I think it's not as interesting
as this one. The algo may look a bit long at first look, but it's not really.
The real stuff is at the end. There are no cryptos, hashes or anything like that,
just pure math. :)

Rules:

- No Patching!
- A Keygen is the only solution.

Good luck and I hope you like it. :)