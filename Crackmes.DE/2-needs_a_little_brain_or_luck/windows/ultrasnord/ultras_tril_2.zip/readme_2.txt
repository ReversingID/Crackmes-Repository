ultras's Trilogi #2
===================
Size		: 387.0 kb
Code		: Borland Delphi 7
Difficulty 	: 1-2

To Do :
1. Find The Way TO GoodBoy Message.
2. No Patching.

# - Don't Forget To Move On To ultras's Trilogi #3 After Beat This. 0(^_^)0

if you found any bug or want to give some suggestion,,
or you want to ask me,,
just email me at :

ultras_muhsin@yahoo.co.id


= sorry for my bad english =