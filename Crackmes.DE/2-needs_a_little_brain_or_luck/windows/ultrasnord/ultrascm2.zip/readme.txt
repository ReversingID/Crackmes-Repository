ultras's 2nd crackme
=====================
Size		: 378.5 kb
Code		: Borland Delphi 7
Difficulty 	: 3

You Have To Remove The Nag Screen (By Patching It),,,
Then find the correct serial and/or make the keygen,,,

This is my 2nd crackme,,,
so if you found any bug or want to give some suggestion,,
or you want to ask me,,
just email me at :

ultras_muhsin@yahoo.co.id

= sorry for my bad english =





  

       