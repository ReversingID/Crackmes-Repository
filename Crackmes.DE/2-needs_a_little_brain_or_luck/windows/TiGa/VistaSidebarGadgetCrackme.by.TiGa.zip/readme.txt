Date:			August 19th 2007

Target:			VistaSidebarGadgetCrackme by TiGa
			on www.crackmes.de
			sebastech(at)sympatico.ca

Format:			Windows Vista Sidebar Gadget (.gadget)

Work to do:		Find out what is a .gadget
			Remove the nags
			Activate the backdoor
			Turn the crackme into a keygen in .gadget format
			Write a solution

Optional Work to do:	Write a keygen in a "traditional" programming language (.exe)

			It's not numbered because I don't plan on making another one!