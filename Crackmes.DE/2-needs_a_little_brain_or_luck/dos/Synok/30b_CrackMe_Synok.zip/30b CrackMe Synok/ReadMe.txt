30 Byte Brother - Synok

This time I added some bytes to the CrackMe, tighting the belt
and making it harder. If you didn't guess on the previous
Crackme, you might have an angel with you this time.
A little harder, but not too much.

Code in ASM.
Size is 30 Bytes as said above.

Have fun guys,

- Synok -