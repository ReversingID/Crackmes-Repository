My first Crackme(keygenme)
All instructions inside.

Protection:
common(name and password).
Not packed.

My e-mail ---------> AndSoOn@one.lt

P.S
I will white mutch better crackme soon(i hope so...because i'm working on 3 other projects);
And sorry for bad gramatical errors because i'm not english.