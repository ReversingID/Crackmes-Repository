#include <stdio.h>
#include <string.h>
#include "ende.h"

void main()
{
	char key[256], fni[256], fno[256], buf[256];
	int len;
	FILE *fpi, *fpo;
	ende_key_t *ek;

	printf("in: ");
	fflush(stdin);
	gets(fni);

	printf("out: ");
	fflush(stdin);
	gets(fno);

	printf("key: ");
	fflush(stdin);
	gets(key);

	ek = ende_prepare(key, strlen(key));
	fpi = fopen(fni, "rb");
	fpo = fopen(fno, "wb");

	while((len = fread(buf, sizeof(unsigned char), 256, fpi)))
	{
		ende_mutate(ek, buf, len);
		ende_process(buf, buf, len, ek);
		fwrite(buf, sizeof(unsigned char), len, fpo);
	}

	fclose(fpi);
	fclose(fpo);
	ende_release(ek);

	printf("done\n");

	getchar();
}
