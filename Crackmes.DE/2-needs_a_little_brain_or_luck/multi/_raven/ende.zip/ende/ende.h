#ifndef _ENDE_H_
#define _ENDE_H_

typedef struct _ende_key
{
	unsigned char *key;
	unsigned int klen;
} ende_key_t;

ende_key_t *ende_prepare(void *skey, unsigned int klen);
void ende_release(ende_key_t *ekey);
int ende_process(void *data_dst, void *data_src, unsigned int dlen, ende_key_t *ekey);
void ende_mutate(ende_key_t *ekey, void *data, unsigned int dlen);

#endif
