Ok your simple thing:
1. snif your serial
2. write a keygen
3. send the solution (with keygen src) to evil_nwo@hotmail.com

Only 1 RULE
DON'T PATCH :D

[CrackZ]Yoda