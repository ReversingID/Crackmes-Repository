#!/bin/bash
cd "$(dirname "$0")"

/usr/sbin/nginx -g "daemon off;"

