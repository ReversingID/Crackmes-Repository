The goal is to find correct PIN's and corresponding correct flag (CTF based crackme).

To run crackme use docker:

docker build -t secure-console ./
docker run -d -p 8080:80 -ti secure-console

Or use live mirror:

http://console.icats.cc/