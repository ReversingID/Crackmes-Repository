Hi man,

This is my first crackme, you task: produce a valid keyfile + write the tutor + submit it :)


The idea was not to write a very hard algorithm to reverse but you to deal with some SEH tricks. This crackme is thought for those ppl who've never dealt with the SEH tricks, i hope it helps you...

Also this crackme tries to fill a deep gap into www.crackmes.de, for some reason ppl don't include anti-debug into their proggies... i consider this a mistake.

Hint: there're 3 SEH tricks, at the end you have your reward.



Enjoy it,
Havok

PS. If you need some literature about the SEH consult DAEMON's cave, at www.anticrack.de.