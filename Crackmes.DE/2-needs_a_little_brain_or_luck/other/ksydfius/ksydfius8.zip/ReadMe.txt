Greetings crackmes.de,

This is a bit unusual of a crackme, but nevertheless it can be done.
Its just that the platform it runs on, is a bit "different"

Just find the right input...

Enjoy,

-ksydfius

