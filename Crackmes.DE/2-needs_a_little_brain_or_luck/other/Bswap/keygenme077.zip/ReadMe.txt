KeygenMe 0.77 notes,

The Program is 100% written in Masm 7.  (all you need).

Goal: You get a Private key, try to make a key maker (level 2/10)

This was just for private fun and training.
Keygenme 0.77 exist of 3 dialog boxes, 3 dive rend timers, 
2 cursors, 2 icons and a lot of data. It is 100% possible to make a
key maker (I did it myself). 

And the usual disclaimer:
Whatever happens when you running this program, I
am not responsible for anything.  
  
If you have any comment or questions please mail,

goodwill80@hotmail.com

I want to greet everyone who knows me.

Cybult , Blue Mind, Detten , Tomkol , ^L00P , Iczelion , Kwasek, 
Thigo, Roy, muaddib and Zero.

Bswap.


