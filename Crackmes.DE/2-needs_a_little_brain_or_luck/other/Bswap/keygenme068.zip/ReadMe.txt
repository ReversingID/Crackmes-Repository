CrackMe 0.68 notes,

This is a simple asm Keygenme.
The Program is 100% written in Masm 7.0 (I think
the best asm program there is!).
Try to make a keymaker (it is not difficult).

This was just for private fun and training,

And the usual disclaimer:
Whatever happens when you running this program, I
am not responsible for anything. 
It has no dirty tricks. But it is a little tricky.
The key checking routine are only 282 bytes!
  
If you have any comment or questions please mail,

goodwill80@hotmail.com

I want to greet everyone who knows me, But this time especially,
Cybult , Detten , Tomkol , ^L00P , Iczelion and Kwasek (great work!)

BSWAP