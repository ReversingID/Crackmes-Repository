KeygenMe 0.72 notes,

The Program is 100% written in Masm 7.0 (I think
the best asm program there is!).
Goal : Try to make a keymaker (it is not that difficult).

This was just for private fun and training.
In fact this is a really easy key to unsolve.
But if you think you are better than the rest,
it is possible to make a GOLD key.		 ;0}

And the usual disclaimer:
Whatever happens when you running this program, I
am not responsible for anything.  
  
If you have any comment or questions please mail,

goodwill80@hotmail.com

I want to greet everyone who knows me, But this time especially,
Cybult , Ranga, Detten , Tomkol , ^L00P , Iczelion , Kwasek, 
Thigo, Roy, muaddib and Zero (from www.crackmes.de)

Bswap.
