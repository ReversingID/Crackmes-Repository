X-prime by ZeroZero
Release Date: 31th May 2004
Compiler: Delphi 7
packer: Upx
Level: 2/10
--------------------------------

Ok, in this crackme are many valid serials. Rulez:

1) no patching, code injection, etc allowed

2) all toolz are allowed

3) when U find the protection scheme, write a tuto and keygen/bruteforcer and send to zerohutsa@hotmail.com, and of course, to crackmes.de.


Note: When U check a valid serial, the good boy message will be appear.

Greetz to:

.: all members of crackmes.de :.
.: to U for try this crackme :.
.: to ExpertDuke for solution of my 1st crackme :.

Hey, keygen this and enjoy (keygen?... or bruteforcer; there are many valid serials).

Thanx for try.

ZeroZero   -=zerohutsa@hotmail.com=-