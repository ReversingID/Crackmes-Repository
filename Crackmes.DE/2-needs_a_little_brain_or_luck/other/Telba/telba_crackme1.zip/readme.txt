Telba`s crackme #1
Rules:
Crack the program and send a walkthrough to "telba@abv.bg"
Simple,isn`t it?...
