CRACKME 7 by ThrawN
-------------------

This is my 7th crackme. Rules are simple - No patching No loaders etc.. Only a correct serial and perhaps a keygen :). Make a tut also and i will post on my homepage along with the crackme.

And if your bored sometime try and reconstruct the exe for something to do.

Send solutions to thrawnc@hotmail.com

Greets out to: (In no particular order)
             All fantasy members - you know who you are
             eMINENCE  - you know who you are 
             Mrfrost  - Your always a good/wise mate to have :)
             SP33D  -  Well where would i be today if i didnt know you ;)
             YOKE  -  SMS fr33k
             ASAR  -  For testing this crackme
             The_Morph  -  For all the great times in GCW
             EX-LUCID members - Outcast3k, Meyitzo, M_ TiSM
             Seifer666 - Thankz for your help in the past
             BuLLeT  -  The most helpfull man on earth ;)
Special Special Greets to IZM (wink wink) maybe one day we can sort dis shit out?


ThrawN - That darn voice
www.thrawn.da.ru