Hi. This is my 4th crackme. You have to make a keygen for this app.
You can use only softice and your favourite programming language.
Enjoy
	The Hellfish 2001