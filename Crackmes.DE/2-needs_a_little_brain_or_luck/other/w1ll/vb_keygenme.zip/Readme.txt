Simple Math VB KeygenMe

Compiler: Visual Basic 6 SP6
Packer: UPX 1.24
Difficulty: 2
Crypto: None Used

Rules & Tasks:
- No Patching
- Figure out the algo (its simple)
- Fish a Valid Serial / Make a Keygen
