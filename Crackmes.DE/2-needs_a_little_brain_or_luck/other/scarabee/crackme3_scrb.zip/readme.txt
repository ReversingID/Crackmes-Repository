Scarabee crackme #3.

Again this is not a too difficult crackme,but it has a few tricks. Fully coded in VB6 and NOT packed this time. 

Some small rules:

1. You may ONLY patch the nagscreen.
2. Find a valid serial (ofcourse).
3. Code a keygen.

For questions, or whatever, you can reach me at:
scarabee_5@hotmail.com

Have phun.

Scarabee.