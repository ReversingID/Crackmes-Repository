Crackme #2 by Scarabee

Rather easy i suppose.  
Unpack the crackme, enable the textfields and find the serial to make a keygenerator.

Scarabee
scarabee_5@hotmail.com 