
***************************************************


CrackMe		:	Evolution by d@b 2004

Date		:	07-Jun-2004

Type		:	KeyGenMe
	
Level		:	2/10

Language	:	Assembly

Compiler	:	MAsm32

Encryption	:	Some

Packing		:	None

Anti-Debugger	:	None

Platform	:	Windows XP , 2000 , NT 4.0


***************************************************


Introduction
============


	.... get cracking dude ....



The Challenge
=============


Convert this KeyGenMe in to a Key Generator .... ;)

The protection scheme will be defeated, once you are presented with the correct congratulations message box.


Rules
=====


0. No Patching Allowed.

1. No ASM ripping allowed.

2. You are ONLY allowed to modifying or add code to the KeyGenMe such that the original algo is the same.

3. You must add the neccessary code to the KeyGenMe to convert it to a Key Generator.

4. Your Key Generator must work on these platforms :- Windows XP , 2000 , NT 4.0.

5. You cannot use the MessageBox function to display the serial.


Good Luck! 


.... Free Your Mind ....


Regards,

d@b

E-Mail : dab@rogers.com