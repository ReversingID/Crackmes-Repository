Keygenme 3 by upb 2004.01.04

This is a keygenme. That means no patching, make a keygen :)
I used no packing or antidebugging tricks etc.