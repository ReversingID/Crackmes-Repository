Crackme 6 - sonkite
--------------------
Well your task is to make it say CRACKED! or whatever you like.
The rules are simple no patching & no code in the file. It is possible.

Greetz to all i know - sonkite@gmx.net