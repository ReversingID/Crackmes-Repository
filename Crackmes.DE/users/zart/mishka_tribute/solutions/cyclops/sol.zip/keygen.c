#include<stdio.h>

main()
{
	char name[0x100];
	int i=1,j=0,k;
	unsigned long t1=0x43ba,t2=0x6e6fa,t3=0;
	printf("Enter the name: ");
	fgets(name,0x100,stdin);
	name[strlen(name)-1]=0x00;
	while(name[i])
	{
		for(k=0;k<i;k++)
		{
			t3*=t1;
			t3+=name[i];
			t1*=t2;
		}
		i++;
	}
	printf("Serial : %u\n",t3);
	getchar();
	return 0;
}
