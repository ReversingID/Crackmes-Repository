// James'sCrackMe.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>
#include <stdio.h>


int _tmain(int argc, _TCHAR* argv[])
{
	char szName[100];


	printf("Enter username:");
	gets_s(szName,99);

	 int i = 0;
	 int len = strlen(szName);
	 unsigned int calc_value=0;
     while ( i < len )
		 calc_value = calc_value + szName[i++] - 0x3C7F;

     printf("Serial = %s-%d", "SR8" , calc_value);

	 getchar();

	return 0;
}

