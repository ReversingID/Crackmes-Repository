#include<stdio.h>
#include<conio.h>
#include<string.h>
main()
 {
	 long int i,sum=0;
     char name[255];
     printf("Keygen for James' KeygenMe\n\nCoded by br0ken\n\n");
     printf("\nName [3-14 chars] : ");
	 scanf("%s",name);
    for(i=0;i<strlen(name);i++)
{
	sum = sum + name[i];
	sum = sum - 15487;    
}
printf("\nSerial :       SR8-%d",sum);
getch();
return 0;
}