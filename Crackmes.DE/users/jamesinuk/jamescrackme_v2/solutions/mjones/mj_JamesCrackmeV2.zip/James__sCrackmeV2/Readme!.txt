Author      : James Cockayne
Relese date : 30/1/08

This is my second crackme so it isnt too hard i didnt write it to be as hard as i could just with funner ways of getting a serial and more techniques used!

I have included a keygen with this crackme butt.... you have to have the password which is the serial for the name "CrackMe" and the auth code of "Jamesinuk!" have fun!
If you would like a copy of the soure code please email me at Jamesdcockayne@hotmail.co.uk!



Good look!
You wont need it!