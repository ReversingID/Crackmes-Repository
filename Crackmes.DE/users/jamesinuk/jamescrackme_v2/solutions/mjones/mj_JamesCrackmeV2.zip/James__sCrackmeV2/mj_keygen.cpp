/**
 * Filename: mj_keygen.cpp
 * Author: mjones
 * Date: February 13, 2008
 * Crackme: JamesCrackme V2 by jamesinuk
 * Compiled with MinGW: g++ -o mj_keygen.exe mj_keygen.cpp
 */

#include <string>
#include <iostream>

#define CODELETTERVAL 0x94
#define CODETOTALVAL 0xBB8
#define MISCTOTALVAL 0xFA0
#define CODESTRING "0000000000"

using namespace std;
int main() {	
	int eax = 0;
	int edx = 0;
	int ebp_1cc = 0;
	int ebp_1d0 = 0;
	int ebp_1d4 = 0;
	int ebp_1d8 = 0;
	
	string name;
	string code = CODESTRING;

	while (name.length() <= 2 || name.length() > 15) {
		cout << "[3-15 chars] Name: ";
		cin >> name;
	}

	for (int i = 0; i < name.length(); i++) {
		eax = (int)code[i];
		edx = (int)name[i];
		
		edx += eax;
		eax = edx;
		eax <<= 2;
		eax += edx;
		eax += eax;
		ebp_1cc = eax;
		
		eax = (int)code[i];
		eax -= CODELETTERVAL;
		ebp_1d0 = eax;
		eax = ebp_1d0;
		
		eax += ebp_1d4;
		eax -= MISCTOTALVAL;
		ebp_1d4 = eax;
		
		eax = ebp_1cc;
		eax += CODETOTALVAL;
		ebp_1d8 = eax;
	}
		
	cout << "Code: " << CODESTRING << endl;
	cout << "Serial: " << name 
		 << "-" << ebp_1cc
		 << "-" << ebp_1d0
		 << "-" << ebp_1d4
		 << "-" << ebp_1d8
		 << endl;
	
	return 0;
}
