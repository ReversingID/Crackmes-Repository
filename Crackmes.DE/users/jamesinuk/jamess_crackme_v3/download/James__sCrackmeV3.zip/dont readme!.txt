James's Crackme V3

My third crackme
This was originally designed to be for a encryption program i made but i never got round to fully finishing it 
so i decided to transform it into a crackme/keygenme.

Find the authorization number anyway possible

You can-.patch it
        .self keygen it
        .brutefource (if you have several days to spare!)
        .find the auth number in olly

If you�re feeling smart make a keygen and a tutorial for it!

Note: You may need to make the canvas in paint to large or it might draw off the edge of the canvas

        
