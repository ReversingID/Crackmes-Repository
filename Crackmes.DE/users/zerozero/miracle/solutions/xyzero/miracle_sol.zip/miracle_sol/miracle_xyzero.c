// Miracle by ZeroZero Password
// miracle_xyzero.c - DEV-C++ 4.0
// xyzero - www.reversor.tk
// 16.07.2004

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>

int STDCALL

WinMain (HINSTANCE hInst, HINSTANCE hPrev, LPSTR lpCmd, int nShow)

{
    HWND hWnd;
    unsigned char check[]={0x29,0x34,0x3C,0x5D,0x45,0x32,0x2B,0x2C};
    unsigned char mask2[]={0x30,0x30,0x20,0x5C,0x7E,0x35,0x30,0x30};
    unsigned char mask1[]={0x5A,0x65,0x72,0x6F,0x5A,0x65,0x72,0x6F};
    unsigned char serial[12]="";
    char answer[100]="";
    unsigned int i;

    for(i=0;i<8;i++)
            serial[i] = (check[i]^mask2[i])^mask1[i];

    wsprintf(answer,"Miracle by ZeroZero Password\n\nNAME:\t(at least 4 characters)\nSERIAL:\t%s\n\nxyzero - 16.07.2o04",serial);
    MessageBox(hWnd,answer,"REVERSOR Password",0);
    return 0;
}

