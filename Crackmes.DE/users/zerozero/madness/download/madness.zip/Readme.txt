Madness by ZeroZero
Release Date: 31th May 2004
Compiler: Delphi 7
packer: Upx
Level: 4/10
--------------------------------

Ok, it's packed with upx, but you can unpack at the way that you want.

All toolz are allowed, but there are one rule:

-- No patching, etc,... only keygenning is allowed


			.: Keygen this, Can U ? :.

Madness, by ZeroZero. Greetz to d@b for Goolyman crackme solution.

Please, send your solution to zerohutsa@hotmail.com, and of course, to crackmes.de.

Enjoy !!
Zerozero