
Open AScrackme.html

written in ActionScript 3 (and Alchemy)

running on winXP

this is my first CrackMe.

vary easy. 

e-mail:kong@shadowkong.com

2012/08/25