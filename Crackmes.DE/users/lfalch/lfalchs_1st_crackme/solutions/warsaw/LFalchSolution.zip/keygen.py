def to32(x): return x & 0xFFFFFFFF
def to48(x): return x & 0xFFFFFFFFFFFF

def javaHash(s):
    h = 0
    for x in map(ord, s):
        h = h*31 + x
    return to32(h)

class JavaRand(object):
    def __init__(self, seed):
        if seed >= (1<<31): #adjust for signedness
            seed -= (1<<32)
        self.seed = to48(seed ^ 0x5DEECE66DL)

    def next(self, bits):
        self.seed = to48(self.seed * 0x5DEECE66DL + 0xBL)
        return to32(self.seed >> (48-bits))

    def nextInt(self, n):
        if ((n & -n) == n):
            return to32((n * self.next(31)) >> 31)

        bits = self.next(31)
        val = bits % n
        while (bits - val + (n-1) < 0):
            bits = self.next(31)
            val = bits % n
        return val

def keygen(name):
    chars = '01234589abcdefghijklmnopqrstuvwxyz'
    r = JavaRand(javaHash(name) | javaHash("LFalch"))

    target = ''.join(chars[r.nextInt(len(chars))] for _ in range(16))
    return target