[v0!d] - Crackme v0.01 :
~~~~~~~~~~~~~~~~~~~~~~~~
[This crack me is totally written for newbiez]

RuleZ :
~~~~~~~

1. Patching is not allwoed, cuz it is 2 easy to crack ...
2. Find a correct code for ur name...
3. Code a keygen, write a tut, then send it to me...

that's it!

P.S : to all advanced crackers plz don't try to crack this
cuz u will really be wasting ur time !!! :P

send ur solution to : v0id2k1@hotmail.com
cya
[v0!d]