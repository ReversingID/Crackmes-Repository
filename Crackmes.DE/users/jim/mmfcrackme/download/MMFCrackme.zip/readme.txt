MMFCrackme by JiM~

Heres a crackme I created with Multimedia Fusion 2, 
a powerful event-based rapid game development 
application from a french company, Clickteam.

Any solution is acceptable.  Feel free to patch, keygen, or
do whatever you please to make my crackme validate.

Good luck and have fun! :)