using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Text;
using System.Security.Cryptography;
using System.Windows.Forms;
using System.Data;

namespace Keygen
{
	/// <summary>
	/// Zusammenfassung f�r Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button gen;
		private System.Windows.Forms.TextBox tb_snr;
		private System.Windows.Forms.Button abt;
		private System.Windows.Forms.TextBox tb_username;
		/// <summary>
		/// Erforderliche Designervariable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Erforderlich f�r die Windows Form-Designerunterst�tzung
			//
			InitializeComponent();

			//
			// TODO: F�gen Sie den Konstruktorcode nach dem Aufruf von InitializeComponent hinzu
			//
		}

		/// <summary>
		/// Die verwendeten Ressourcen bereinigen.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Vom Windows Form-Designer generierter Code
		/// <summary>
		/// Erforderliche Methode f�r die Designerunterst�tzung. 
		/// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
		/// </summary>
		private void InitializeComponent()
		{
			this.tb_username = new System.Windows.Forms.TextBox();
			this.gen = new System.Windows.Forms.Button();
			this.tb_snr = new System.Windows.Forms.TextBox();
			this.abt = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// tb_username
			// 
			this.tb_username.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.tb_username.Location = new System.Drawing.Point(16, 24);
			this.tb_username.Name = "tb_username";
			this.tb_username.Size = new System.Drawing.Size(283, 20);
			this.tb_username.TabIndex = 0;
			this.tb_username.Text = "username";
			this.tb_username.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tb_username_KeyDown);
			this.tb_username.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_username_KeyPress);
			// 
			// gen
			// 
			this.gen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.gen.Location = new System.Drawing.Point(16, 88);
			this.gen.Name = "gen";
			this.gen.TabIndex = 1;
			this.gen.Text = "Generate";
			this.gen.Click += new System.EventHandler(this.gen_Click);
			// 
			// tb_snr
			// 
			this.tb_snr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.tb_snr.Location = new System.Drawing.Point(16, 56);
			this.tb_snr.Name = "tb_snr";
			this.tb_snr.ReadOnly = true;
			this.tb_snr.Size = new System.Drawing.Size(283, 20);
			this.tb_snr.TabIndex = 2;
			this.tb_snr.Text = "";
			// 
			// abt
			// 
			this.abt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.abt.Location = new System.Drawing.Point(224, 88);
			this.abt.Name = "abt";
			this.abt.TabIndex = 3;
			this.abt.Text = "About";
			this.abt.Click += new System.EventHandler(this.abt_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(312, 124);
			this.Controls.Add(this.abt);
			this.Controls.Add(this.tb_snr);
			this.Controls.Add(this.gen);
			this.Controls.Add(this.tb_username);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "Form1";
			this.Text = "KeyGen for a crackme by alsor";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Der Haupteinstiegspunkt f�r die Anwendung.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void gen_Click(object sender, System.EventArgs e)
		{
			string username = tb_username.Text;

			if (username.Length >= 3 && username.Length <= 30)
			{

				string snr_1 = ""; // first part of the SNR
				string snr_2 = ""; // second part of the SNR
				string snr_3 = ""; // third part of the SNR
				string snr_4 = ""; // fourth part of the SNR
				string snr_5 = ""; // fifth part of the SNR

				//byte[] bytes = Encoding.ASCII.GetBytes(test);
			
				int result = 0x0;
				string str_result = "";
				int temp = 0x0;
				int temp2 = 0x0;

				int EDX = 0x0;
				int ECX = 0x0;

				int EBX = 0x0;


				// first part of the SNR

				for (int x=0;x<username.Length;x++)
				{// go through the whole string, beginning at the first char

					temp = Convert.ToInt32(username[x]); // Convert char[x] to a hex value

					temp += result;

					temp *= 0x772;

					temp2 = temp * temp; //square - keep temp!
					temp = temp2 + temp; //add squared value to temp

					temp *= 0x474;

					temp += temp;

					result = temp;
				}
				//Show the calculated value: MessageBox.Show (string.Format("{0:x}", result));

				str_result = string.Format("{0:x}", result);

				if (str_result.Length > 4)
					snr_1 = str_result.Substring (0,4);
			

				

				result = 0x0;
				str_result = "";
				temp = 0x0;
				temp2 = 0x0;
				
				// second part of the SNR

				for (int x=username.Length-1;x>=0;x--)
				{// go through the whole string, beginning at the last char

					temp = Convert.ToInt32(username[x]); // Convert char[x] to a hex value

					temp += 0x11;

					temp -= 0x5;

					temp *= 0x92;

					temp += temp;

					temp *= 0x819;

					//origin: add this value to stack at [EBP-10]
					//but we won't ;-)

					result += temp;
				}
				//Show the calculated value: MessageBox.Show (string.Format("{0:x}", result));

				str_result = string.Format("{0:x}", result);

				if (str_result.Length > 4)
					snr_2 = str_result.Substring (0,4);






				result = 0x0;
				str_result = "";
				temp = 0x0;		//origin: EDX
				temp2 = 0x0;


				// third part of the SNR

				System.Text.ASCIIEncoding enc = new System.Text.ASCIIEncoding();
	
//			Trial of creating the MD5-hash of the entered username
//
//				System.Security.Cryptography.MD5 md5_ = new System.Security.Cryptography.MD5CryptoServiceProvider();
//				byte[] bytes = md5_.ComputeHash(enc.GetBytes(username));
//				
//				//only a test: MessageBox.Show (enc.GetString(bytes));			
//
//				/* Show the createt value: */
//				string ausgabe = "";
//				foreach (byte b in bytes) { ausgabe += String.Format("{0:X}", b)+" "; } 
//				
//				MessageBox.Show(ausgabe,"",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);

				/*
				  Anonw09/&720("=)=!)&")?`"(=(�)
  
				  the MD5-hash generated with "normal" MD5 is
				   580fcbb476212fa9bb0e9dc1edc5d5c9 
	
				  with different magic constans (see md5modded.cs) it will be:
				   02B3A642C59FBF0DFD92336B686E3628
				*/

//			username + "w09/&720("=)=!)&")?`"(=(�)"
//			username + 77 30 39 2F 26 37 32 30 28 22 3D 29 3D 21 29 26 22 29 3F 60 22 28 3D 28 A7 29

//				string string_addstring = '"w09/&720("=)=!)&")?`"(=(�)"';
				byte[] byte_addstring =  {0x77,0x30,0x39,0x2F,0x26,0x37,0x32,0x30,0x28,0x22,0x3D,0x29,
										 0x3D,0x21,0x29,0x26,0x22,0x29,0x3F,0x60,0x22,0x28,0x3D,
										 0x28,0xA7,0x29};

//			This won't be the same as the byte values because of 0xA7
//				string string_addstring = enc.GetString(byte_addstring);


				byte[] buffer = new byte[username.Length+byte_addstring.Length];
				byte[] test2 = enc.GetBytes(username);

				test2.CopyTo(buffer,0);
				byte_addstring.CopyTo(buffer,test2.Length);
			
				str_result = MD5.GetMd5Bytes(buffer);  //Different MD5-routine with other magic constants

				//MessageBox.Show(str_result,"snr 3");

				if (str_result.Length > 8)
					snr_3 = str_result.Substring (0,8);




				result = 0x0;	//origin: EDI
				str_result = "";
				temp = 0x0;
				temp2 = 0x0;	//origin: EAX
				
				// fourth part of the SNR

				for (int x=username.Length-1;x>=0;x--)
				{// go through the whole string, beginning at the last char

					temp = Convert.ToInt32(username[x]); // Convert char[x] to a hex value

					result += temp;

					result += 0x929;

					result += 0x767;

					result += temp2;

					result *= 0x8392;

					temp2 = result;

					temp2 -= 0x33;

					temp2 *= result;

					temp2 += result;
				}
				//Show the calculated value: MessageBox.Show (string.Format("{0:x}", result));

				str_result = string.Format("{0:x}", result);

				if (str_result.Length > 4)
					snr_4 = str_result.Substring (0,4);




				result = 0x0;
				str_result = "";
				temp = 0x0;		//not needed: origin: SS:[EBP-14]
				temp2 = 0x0;	//not needed: origin: SS:[EBP-4]

				EDX = 0x0;
				ECX = 0x0;

				EBX = 0x0;
				
				// fifth part of the SNR

				//not needed: temp = 0x1;	//see 0045B968

				for (int x=0;x<username.Length;x++)
				{// go through the whole string, beginning at the first char

					//not needed: ECX = temp;
					EDX = Convert.ToInt32(username[x]); // Convert char[x] to a hex value
					
					EBX += EDX;
					EBX += EBX;
					
					EDX = EBX;

					EDX *= EBX;
					EBX *= EDX;

					//XOR EBX, 10
					EBX ^= 0x10;

					//OR EBX,44
					EBX |= 0x44;

					EDX = EBX * 0x373;

					EDX += 0x443;

					EBX = EDX;

					//not needed: EDX = temp2;
					//not needed: ECX = temp;

					EDX = Convert.ToInt32(username[x]); // Convert char[x] to a hex value

					EBX += EDX;

					EBX *= EBX;

					//not needed: temp++;
				}
				//Show the calculated value: MessageBox.Show (string.Format("{0:x}", EBX));

				str_result = string.Format("{0:x}", EBX);

				if (str_result.Length > 4)
					snr_5 = str_result.Substring (0,4);

				

				//show the calculated snr
				string snr = snr_1+"-"+snr_2+"-"+snr_3+"-"+snr_4+"-"+snr_5;
				tb_snr.Text = snr.ToUpper();
			}
			else
				MessageBox.Show ("Please enter more than 2 and less than 31 chars!","Error",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);

		}

		private void abt_Click(object sender, System.EventArgs e)
		{
			MessageBox.Show("        Keygen for WarRock's KeygenMe #3 WR"+
				"\r\n\r\n            written by alsor" + 
				"\r\n" + 
				"\r\n\r\n        with a modified version of the MD5-routine derived by"+
				"\r\n\r\n          2002-2005 GL Conseil/Flow Group SAS" +
				"\r\n\r\n          1990-2, RSA Data Security, Inc. Created 1990.",
				"About ...",MessageBoxButtons.OK,MessageBoxIcon.Information,MessageBoxDefaultButton.Button1);
		}

		private void tb_username_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Enter)
			{
				gen_Click ("",new System.EventArgs());
				e.Handled = true;
			}			
		}

		private void tb_username_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == 13) //Enter
				e.Handled = true;
		}
	}
}
