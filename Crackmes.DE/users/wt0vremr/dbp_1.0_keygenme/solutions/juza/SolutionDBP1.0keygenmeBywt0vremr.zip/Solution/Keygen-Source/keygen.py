#!/usr/bin/env python

"""Keygen - DBP 1.0 Keygenme by wt0vremr"""

__author__ = "juza"
__copyright__ = "juza"
__license__ = "GPL"
__version__ = "1.0"
__maintainer__ = "juza"
__email__ = "iamjuza@gmail.com"

import os
import hashlib

class utilities:

    @staticmethod
    def mmxToDwords(value):
        return [ ((value >> b) & 0xFFFFFFFF ) for b in [32, 00]]

    @staticmethod
    def dwordsToMMX(dwords):
        tuble = []
        mm0 = 0

        for dword in [ ((dd << v) & 0xFFFFFFFFFFFFFFFF) for dd, v in zip(dwords, [32, 00]) ]:
            tuble.append(dword)

        for dword in tuble:
            mm0 |= dword
            
        return mmx(mm0)

    @staticmethod
    def mmxToWords(value):
        return [ ((value >> b) & 0xFFFF ) for b in [48, 32, 16, 00]]

    @staticmethod
    def wordsToMMX(words):
        tuble = []
        mm0 = 0
        
        for word in [ ((dw << v) & 0xFFFFFFFFFFFFFFFF ) for dw, v in zip(words, [48, 32, 16, 00]) ]:
            tuble.append(word)

        for word in tuble:
            mm0 |= word

        return mmx(mm0)

    @staticmethod
    def mmxToBytes(value):
        return [ ((value >> b) & 0xFF ) for b in [56, 48, 40, 32, 24, 16, 8, 0]]

    @staticmethod
    def bytesToMMX(dbs):
        tuble = []
        mm0 = 0
        
        for byte in [ ((db << v) & 0xFFFFFFFFFFFFFFFF ) for db, v in zip(dbs, [56, 48, 40, 32, 24, 16, 8, 0]) ]:
            tuble.append(byte)

        for byte in tuble:
            mm0 |= byte

        return mmx(mm0)

    @staticmethod
    def mmxsub(mm0, mm1):
        dbs = []
        for m1, m2 in zip(mm0.getBytes(), mm1.getBytes()):
            dbs.append((m1 - m2) & 0xFF)
            
        return utilities.bytesToMMX(dbs)

class mmx():

    def __init__(self, value):
        self.value = (value & 0xFFFFFFFFFFFFFFFF)

    def get(self):
        return self.value & 0xFFFFFFFFFFFFFFFF

    def getDWords(self):
        return utilities.mmxToDwords(self.value)

    def getDWord(self, i):
        return utilities.getDWorld()[i]

    def getWords(self):
        return utilities.mmxToWords(self.value)

    def getWord(self, i):
        return utilities.getWords()[i]

    def getBytes(self):
        return utilities.mmxToBytes(self.value)

    def getByte(self, i):
        return utilities.getBytes()[i]

if __name__ == '__main__':

    print '''
 __                         __                            
/\_\     __      ___ ___   /\_\  __  __  ____      __     
\/\ \  /'__`\  /' __` __`\ \/\ \/\ \/\ \/\_ ,`\  /'__`\   
 \ \ \/\ \_\.\_/\ \/\ \/\ \ \ \ \ \ \_\ \/_/  /_/\ \_\.\_ 
  \ \_\ \__/.\_\ \_\ \_\ \_\_\ \ \ \____/ /\____\ \__/.\_\
  
   \/_/\/__/\/_/\/_/\/_/\/_/\ \_\ \/___/  \/____/\/__/\/_/
                           \ \____/                       
                            \/___/  [at] gmail [dot] com                       
        '''
    print "Keygen - DBP 1.0 Keygenme by wt0vremr"

    username = raw_input("Username: ")
	
    i = 2
    serial = ord(username[0])

    while i < (len(username) + 1):
        serial += i
        serial *= ord(username[0])
        i += 1

    serial = serial & 0xFFFFFFFFFFFFFFFF
    backup = serial

    mm0 = mmx(serial)

    sparts = mm0.getWords()

    for i in range(len(sparts)):
        sparts[i] = sparts[i] >> 0x08

    mm0 = utilities.wordsToMMX(sparts)
    sparts = mm0.getWords()

    for i in range(len(sparts)):
        sparts[i] = sparts[i] << 0x0C

    mm0 = utilities.wordsToMMX(sparts)
    mm1 = mmx(backup)
    mm2 = utilities.mmxsub(mm0, mm1)

    serial = "%X" % (mm2.get())
    print "Serial:", hashlib.sha1(serial).hexdigest()[31:]

    os.system('pause')
