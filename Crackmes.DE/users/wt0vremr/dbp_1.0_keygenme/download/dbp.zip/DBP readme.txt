[stupid stuff]
Dear customer! Allow me to itroduce the most genial benchmark in the world - Dummy Benchmark Pro 1.0 Super Mega Enterprise XP! Main features:
 - Multithread Pi counting with Monte Carlo algorythm.
 - Uuuhh.... That's all.
[/stupid stuff]

If talking serious,  you have to write a keygen for this crackme. If you have a valid serial, you are able to start benchmark.
Rules:
 - No patching
 - Code a keygen
 - Self-keygening is NOT allowed
 - Submit solution to crackmes.de

If you have any questions, feel free to mail me:
wt0vremr[commercial at]gmail[littledot]com

Note: better runs on XP - 7.