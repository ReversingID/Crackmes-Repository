#include<stdio.h>
#include<conio.h>
int main()
{
    int i,x,y,z;
    FILE *YourFirstCrackme;
    int offset_NAG_SCREEN[5] = {1038,1039,1040,1041,1042};
    int offset_IS_DBG_PRESENT[2] = {1313,1314};
    int offset_CHECK_CDROM[3] = {1421,1422,1423};
    int offset_JUMP_TO_INT[2] = {1445,1446};
    char nops_DBG_PRESENT[] = {144,144};
    char nops_Nag[] = {144,144,144,144,144};
    char cdrom[] = {59,192,144};
    char antidbg_int[] = {235,72};
if((YourFirstCrackme = fopen("YourFirstCrackme.exe","r+")) != NULL)
{
for(i=0; i<5; i++){
fseek(YourFirstCrackme,offset_NAG_SCREEN[i],SEEK_SET);
fprintf(YourFirstCrackme,"%c",nops_Nag[i]);
}
for(x=0; x<2; x++){
fseek(YourFirstCrackme,offset_IS_DBG_PRESENT[x],SEEK_SET);
fprintf(YourFirstCrackme,"%c",nops_DBG_PRESENT[x]);
}
for(y=0; y<3; y++){
fseek(YourFirstCrackme,offset_CHECK_CDROM[y],SEEK_SET);
fprintf(YourFirstCrackme,"%c",cdrom[y]);
}
for(z=0; z<2; z++){
fseek(YourFirstCrackme,offset_JUMP_TO_INT[z],SEEK_SET);
fprintf(YourFirstCrackme,"%c",antidbg_int[z]);
}
printf("YourFirstCrackme has been succesfully cracked!!");
getchar();
}
else{
printf("Cannot locate YourFirstCrackme");
getchar();
}
return 0;
}