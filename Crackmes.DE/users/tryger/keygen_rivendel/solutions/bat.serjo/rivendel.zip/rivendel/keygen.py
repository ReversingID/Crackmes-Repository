import os, sys


def cleaned(user, pwd, cnt, unk, userLen):
	if cnt == userLen*3:
		return 0
	
	if cnt < userLen * 2:
		if cnt < userLen:
			
			arg3 = (((unk&0xff) + 15) ^ ord(user[cnt]))&0xff
			
			if pwd[cnt] == arg3:
				lvar = cnt+1
				
				if lvar == userLen:
					cleaned(user, pwd, lvar, arg3 - 10, userLen)
				else:
					cleaned(user, pwd, lvar, arg3, userLen)
			else:
				raise Exception("Shit you missed at %s %d - %c %s" % (user, cnt, arg3, pwd))
			
		else:
			
			arg3 = ((18 - (unk&0xff)) ^ ord(user[ (cnt/userLen) % userLen ]))&0xff
			
			if pwd[cnt] == arg3:
				lvar = cnt + 1
				if lval == userLen * 2:
					cleaned(user, pwd, lval, arg3 + 113, userLen)
				else:
					cleaned(user, pwd, lval, arg3, userLen)
			else:
				raise Exception("Shit you missed at %s %d - %c %s" % (user, (cnt/userLen) % userLen, arg3, pwd))	
	else:
		# [...] [...] [XXX]
		arg3 = ((((unk&0xff) - 76) * 2) ^ ord(user[ (cnt/userLen) % userLen ])) & 0xff
		
		if pwd[cnt] == arg3:
			lvar = cnt + 1
			cleaned(user, pwd, lval, arg3, userLen)
		else:
			raise Exception("Shit you missed at %s %d - %c %s" % (user, (cnt/userLen) % userLen, arg3, pwd))


res = ''

def addRes(val):
	global res

	#print "%s %d - %c %s" % (user, cnt, arg3, pwd)
	#print "%x" % val,
	res = res + '%.2x' % val

def cracked(user, pwd, cnt, unk, userLen):
	lvar = 0
	
	if cnt == userLen*3:
		return 0
	
	if cnt < userLen * 2:
		if cnt < userLen:
			
			arg3 = (((unk + 15)) ^ ord(user[cnt]))&0xff
			
			#if pwd[cnt] != arg3:
			addRes( arg3 )
			
			lvar = cnt+1
			
			if lvar == userLen:
				cracked(user, pwd, lvar, arg3 - 10, userLen)
			else:
				cracked(user, pwd, lvar, arg3, userLen)
			
		else:
			
			arg3 = (((18 - unk)) ^ ord(user[ (cnt/userLen) % userLen ])) & 0xff
			
#if pwd[cnt] != arg3:
			addRes( arg3 )
				
			lvar = cnt + 1
			if lvar == userLen * 2:
				cracked(user, pwd, lvar, arg3 + 113, userLen)
			else:
				cracked(user, pwd, lvar, arg3, userLen)
	else:
		# [...] [...] [XXX]
		arg3 = ( ( ((unk - 76) * 2) ) ^ ord(user[ (cnt/userLen) % userLen ]) ) & 0xff
		
		addRes( arg3 )
		#if pwd[cnt] != arg3:
		
		lvar = cnt + 1
		cracked(user, pwd, lvar, arg3, userLen)


def IterCrack(user, pwd, cnt, arg3, userLen):
	lvar = 0
	for cnt in range(0, userLen*3):
		if cnt <= userLen * 2:
			if cnt <= userLen:
				if cnt < userLen:
					arg3 = (((arg3 + 15)) ^ ord(user[cnt]))&0xff
					addRes( arg3 )
				else:
					#addRes( arg3 )
					arg3 -= 10
			else:
				if cnt < userLen*2:
					arg3 = (((18 - arg3)) ^ ord(user[ cnt % userLen ])) & 0xff
					addRes( arg3 )
				else:
					#addRes( arg3 )
					arg3 += 113
		else:
			# [...] [...] [XXX]
			arg3 = ( ( ((arg3 - 76) * 2) ) ^ ord(user[ cnt % userLen ]) ) & 0xff
			addRes( arg3 )
			print cnt


def prepFile(fname, usr, passwd):
	data = ''
	for i in range(0, len(passwd), 2):
		data = data+chr(int(passwd[i:i+2], 16))
	
	#data = passwd #passwd.decode('hex')
	
	with open(fname,'wb+') as fd:
		fd.write(usr)
		fd.write('\n')
		fd.write(data)
		fd.write('\n')


if "__main__" == __name__:
	cmd = sys.argv[1]
	
	if cmd == "-use":
		user = sys.argv[2]
		rawBytes = sys.argv[3:]
		
		rawStream = ''
		for rb in rawBytes:
			rawStream += rb
		
		prepFile('input.raw', user, rawStream)
	else:
		user = cmd
		userLen = len(user)
		
		pwd = '0'*userLen*3
		cracked(user, pwd, 0, 0, userLen)
		print res
		prepFile('input.raw', user, res)
		
		
		userLen = len(user)
		pwd = '0'*userLen*3
		res = ''
		
		IterCrack(user,pwd,0,0,userLen)
		print res
		prepFile('input2.raw', user, res)