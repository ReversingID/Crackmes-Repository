'''
Created on Apr 24, 2015

@author: serj
'''
import sys
import errno
import struct 

import envi
import envi.archs.i386 as e_i386

import vtrace
from vtrace.breakpoints import Breakpoint


class PtracePatch ( Breakpoint ):
    def notify( self, event, trace ):
        rctx = trace.getRegisterContext()
        #self.resolveAddress( trace )
        curaddr = rctx.getProgramCounter()
        jumpaddr = curaddr + 5 #bytes: e894fcffff
        #trace.setRegister( e_i386.REG_EIP, jumpaddr )
        rctx.setProgramCounter(jumpaddr)

class BranchPatch ( Breakpoint ):
    def setRedirectAddr(self, desiredAddr):
        self.desiredAddr = desiredAddr
    
    def notify( self, event, trace ):
        rctx = trace.getRegisterContext()
        rctx.setProgramCounter( self.desiredAddr )

#1 part
#0x080485b7
#2 part
#0x080485ec
#3 part
#0x08048622

class PrintAL ( Breakpoint ):
    def notify( self, event, trace ):
        rctx = trace.getRegisterContext()
        
        al  = rctx.getRegister(e_i386.REG_AL)
        print '%.2x ' % al,


if __name__ == '__main__':
    trace = vtrace.getTrace()
    trace.execute('%s' % sys.argv[1])
    trace.requireAttached()
    
    #maps = trace.getMemoryMaps()
    #for m in maps:
    #    print m
    
    _ppach1 = PtracePatch(0x80487c7)
    trace.addBreakpoint( _ppach1 )

    _bb1 = BranchPatch(0x080485ca)
    _bb1.setRedirectAddr(0x0804863c)
    trace.addBreakpoint( _bb1 )
    
    _bb2 = BranchPatch(0x080485ff)
    _bb2.setRedirectAddr(0x0804866c)
    trace.addBreakpoint( _bb2 )
    
    _bb3 = BranchPatch(0x08048635)
    _bb3.setRedirectAddr(0x080486a0)
    trace.addBreakpoint( _bb3 )
    
    
    _pal1 = PrintAL(0x080485b7)
    trace.addBreakpoint( _pal1 )
    
    _pal2 = PrintAL(0x080485ec)
    trace.addBreakpoint( _pal2 )
    
    _pal3 = PrintAL(0x08048622)
    trace.addBreakpoint( _pal3 )
    
    trace.setMode("RunForever", True)
    trace.run()
    