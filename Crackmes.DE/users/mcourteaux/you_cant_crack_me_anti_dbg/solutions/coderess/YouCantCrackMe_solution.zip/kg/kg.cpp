/********************************************************************************************/
/* keygen.cpp 
* 
*  Compile................MSVS6
*  Language...............C/C++
*  Programm...............Keygen for 
*  Date|Time..............11 June | 22:12
*  Programmer.............Coderess
* 
*********************************************************************************************/


#include <windows.h>
#include "resource.h"
#include "AggressiveOptimize.h"


HINSTANCE hInstance;
HWND hWnd;
HICON hIcon;

CHAR lpName[50];
CHAR buf[25];
CHAR lpKey[25];

#define ABOUT_TEXT	"Keygen for YouCantCrackMe by mcourteaux \n\nKeygened by Coderess \n"
#define ABOUT_CAPT	"About"

#define XOR			^
#define OR			|
#define	AND			&


UINT FirstFunc(PCHAR lpName, DWORD nLen)
{
	ULONG	Res = 0;
	DWORD	sum = 0;
	__int64 even = 0;
	DWORD	d	= 0;

	for (UINT i=0; i<nLen; i++)  
	{
		sum = sum + lpName[i];
	}

	even = sum;
	even = even * 0x51EB851F;
	d	 = even >> 32;
	d	 = d >> 4;
	sum  = sum >> 0x1F;
	d	 = d - sum;

	return (d); 
}


#define pi 3.141592000000000

BOOL CALLBACK KeygenProc(HWND hWnd)
{
	CHAR	ch=0;
	double  dfp=0;
	DWORD	CWR_=0;
	int		f1=0, f2=0;
	DWORD	var1=0;

	DWORD nLen = GetDlgItemText(hWnd, IDC_EDIT1, lpName, 50);
	if (nLen < 5 || nLen >49) return (FALSE);
	
	f2 = FirstFunc(lpName, nLen);

	__asm FINIT			// CWR=0x37F

	for (DWORD i = 0, a = 0, j = 1, k = nLen; i < 19+1; i++, j++, k--, a++) 
	{
		f1 = f2;
		f1 = f1 + lpName[a];

		ch = lpName[k-1] XOR i;
		dfp = ch * pi;
		dfp = dfp / j;
		dfp = dfp + f1;

		WORD char1=0;

		_asm FSTCW	CWR_		// Read CWR

		char1 = (WORD)CWR_;
		char1 = char1 OR 0x0C00;
		var1  = (DWORD)dfp;
		f1	  = var1;
		var1  = nLen XOR 0x10;
		f1	  = f1 - var1;

		if ((f1 AND 1)==0)	f1 = (~f1)+1;		// neg

		while (1)
		{
			if (f1 > '@' || f1 > 'Y') break;
			f1 = f1 + 0x1A;
		}

		while (1)
		{
			if (f1 > '`' || f1 <= 'Z') break;
			f1 = f1 + 0x1A;
		}

		while (1)
		{
			if (f1 <= 'z') break;
			f1 = f1 - 0x1A;
		}

		lpKey[i] = f1;

		// again
		if (a == nLen-1) 
		{
			a = -1;
			k = nLen + 1;
		}
	}

	SetDlgItemText(hWnd, IDC_EDIT2, lpKey);
	return (TRUE);
}


BOOL CALLBACK DlgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg) {
 
	case WM_CLOSE:
		EndDialog(hWnd, 0);
		break;

	case WM_COMMAND:
		switch (wParam)
		{
			// Gen. key
			case IDC_BUTTON1:
				KeygenProc(hWnd);
				break;
				
			// About
			case IDC_BUTTON3:
				MessageBox(hWnd, ABOUT_TEXT, ABOUT_CAPT, MB_ICONINFORMATION | MB_OK);
				break;

			// Exit
			case IDC_BUTTON2:
				EndDialog(hWnd, 0);
				break;
			}
		break;
		}


	return FALSE;
}


int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{		
	DialogBoxParam(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_DIALOG1), 0, (DLGPROC)DlgProc, 0);
	return (0);
}

