/********************************************************************************************/
/* keygen.cpp 
* 
*  Compile................MSVS6
*  Language...............C/C++
*  Programm...............Keygen for 
*  Date|Time..............8 June | 16:27am
*  Programmer.............Coderess
* 
*********************************************************************************************/


#include <windows.h>
#include "resource.h"

#include "AggressiveOptimize.h"


HINSTANCE hInstance;
HWND hWnd;
HICON hIcon;

CHAR lpName[25];
CHAR buf[25];
CHAR lpKey[25];

#define ABOUT_TEXT	"Keygen for CrackMe1 by MC \n\nKeygened By Coderess \n"
#define ABOUT_CAPT	"About"
#define STR			"aicgetocnpqbwm"
#define XOR			^

BOOL CALLBACK KeygenProc(HWND hWnd)
{
	BOOL bDelim=0, bFlag=0;
	
	ULONG nLen = GetDlgItemText(hWnd, IDC_EDIT1, lpName, 25);
	
	lstrcat(lpName, STR);

	CHAR chr=0;

	for (int i=0, j=0; i<16; i++, j++)
	{
		chr = lpName[i];
		if (chr <= '?' || chr > 'Z')
		{
			goto metka1;
		}else{
			goto metka2;
		}

metka1:
		__asm{
				movzx ecx, chr
				movsx ax, cl
				imul eax, eax, 0x067
				movzx eax, ax
				shr eax, 8
				mov dl, al
				sar dl, 3
				mov al, cl
				sar al, 7
				sub dl, al
				mov al, dl
				shl al, 2
				add al, dl
				shl al, 2
				sub cl, al
				mov al, cl
				add al, 0x062
				mov chr, al
		}

metka2:
	
		chr = chr XOR 0x21;
		if (chr==0)
		{
			chr = chr + 3; 
		}

		__asm{		
				movzx eax, chr
				sar eax, 2
				mov ecx, eax
				add ecx, i
				mov eax, 0x02AAAAAAB
				imul ecx
				mov eax, ecx
				sar eax, 0x01F
				sub edx, eax
				mov eax, edx
				add eax, eax
				add eax, edx
				add eax, eax
				sub ecx, eax
				mov eax, ecx
				//cmp eax, 2
				//jg @crackme1_004015C5   
				mov bFlag,eax
			}

		if (bFlag<=2) 
		{
			chr = tolower(chr);
		}

		if (i==4 || i==8 || i==12){
			lpKey[j] = '-';
			lpKey[j+1] = chr;
			j++;
			continue;
		}

		lpKey[j] = chr;
	}


	SetDlgItemText(hWnd, IDC_EDIT2, lpKey);
	return (TRUE);
}

BOOL CALLBACK DlgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg) {
 
	case WM_CLOSE:
		EndDialog(hWnd, 0);
		break;

	case WM_COMMAND:
		switch (wParam)
		{
			// Gen. key
			case IDC_BUTTON1:
				KeygenProc(hWnd);
				break;
				
			// About
			case IDC_BUTTON3:
				MessageBox(hWnd, ABOUT_TEXT, ABOUT_CAPT, MB_ICONINFORMATION | MB_OK);
				break;

			// Exit
			case IDC_BUTTON2:
				EndDialog(hWnd, 0);
				break;
			}
		break;
		}


	return FALSE;
}


int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{		
	DialogBoxParam(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_DIALOG1), 0, (DLGPROC)DlgProc, 0);
	return (0);
}

