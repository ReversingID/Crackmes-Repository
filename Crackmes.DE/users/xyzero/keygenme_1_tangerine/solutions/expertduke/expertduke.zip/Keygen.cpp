// l.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "stdlib.h"

int _tmain(int argc, _TCHAR* argv[])
{
	printf(" Keygen KeygenMe #1 for Newbies - Tangerine\n");
	printf(" By: ExpertDUKE\n\n");
	printf(" $$$  $   $  $$$  $$$  $$$$  $$$$$  ##   #  # #  # ###\n");
	printf(" $     $ $   $  $ $    $  $    $    # #  #  # # #  #\n");
	printf(" $$$    $    $$$  $$$  $$$     $    #  # #  # ##   ###\n");
	printf(" $     $ $   $    $    $ $     $    # #  #  # # #  #\n");
	printf(" $$$  $   $  $    $$$  $  $    $    ##   #### #  # ###\n");
	printf("\n\nEnter name: ");
    char M,i;
    char Name[20];
    unsigned long ebp14,ebpc,eax,edi,esi,ecx;
	unsigned long  edx,ebp4,ebp10,s1,s2,s3;
	gets(Name);
    eax=strlen(Name);
    edi=0;
    ecx=eax*45;
    edx=ecx*2;
    esi=edx*3;
    ebp4=esi;
    esi=eax*ebp4;
	ebp4+=eax;
	ebp14=0;
	for(i=0;i<eax;i++){
		  edi=i;
          esi=esi+eax;
          edi=Name[i];
          edi=edi*ecx;
          edi=edi+edx;
          ebp14=ebp14+edi;
          ecx++;
          edi=esi+ecx;
          edx=edx+edi;
	}
     edi=0;
     esi=edx;
     esi*=45;
     esi+=ecx;
	 ebp10=0;
	for(i=0;i<eax;i++){
         ecx=Name[i];
         ecx++;
         esi+=45;
         ecx*=edx;
         ebp10+=ecx;
         ebp4+=esi;
         edx++;
         edi++;
	 }

     ecx=0;
	 ebpc=0;
	for(i=0;i<eax;i++){
         esi=Name[i];
         esi*=ebp4;
         esi+=edx;
         ebpc+=esi;
         edx++;
         ecx++;
	 }
     edx=ebp10;
     ecx=(eax+2)*ebpc;
     s3=ecx;
     ecx=ebp14;
     eax*=ecx;
     edx+=ecx;
     s2=edx;
     s1=eax;

    printf("Serial: %u-%u-%u\n",s1,s2,s3); 

	system("pause");
	return 0;
}

