===KeyGenMe if You can!===

Try and get a valid key for the program.

You will not be able to self-keygen this one
or fish a serial out.

A valid solution entails a keygen, but post your
valid keys in the comments if too lazy to make one.

I can provide the source code to those who have posted
a solution but don't spread it around. Message 
me if you want it.

-- mre521
