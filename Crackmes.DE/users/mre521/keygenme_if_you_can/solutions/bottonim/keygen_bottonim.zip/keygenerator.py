#!/usr/bin/env python
# August, the 23 th 2015
# this is a keygen for "KeyGenMe if You can" crackme
# dedicated to my daughter Greta_Azzura
# Thanks to the coder Mre521
# and to Gergo, Frais, Mahara and Chinca, Duccio and Caos

import sys
import random

debug=0

def computeValues(username):
  val1093=0
  val1094=0
  val1095=0
  val1096=0
  tmpVal=0
  for ii in range(0,len(username)):
    if debug>0:
      print "starting loop " + str(ii) + "---- "
      print "ASCII: %x" % ord(username[ii])
    val1094=ord(username[ii]) ^ 0xFF
    if debug>0:
      print "val1094: %x" % val1094
    tmpVal=val1093
    if debug>0:
      print "val1093(tmpVal): %x" % val1093
    for jj in range(0,3+1):
      tmpVal=tmpVal & 0xFF
      if debug>0:
	print "sub_loop " + str(jj)
	print "macroDiff %x" % ((tmpVal & 0xFF) -0x80)
	print "macroDiff2 %x" % (~((tmpVal & 0xFF)-0x80))
	print "valC %x" % abs((~((tmpVal & 0xFF)-0x80))>>0xF)
      remainder=0
      if tmpVal > 0x80:
	remainder=1
      #tmpVal=tmpVal*2+(abs((~((tmpVal & 0xFF)-0x80))>>0xF) & 0x1)
      tmpVal=tmpVal*2+remainder
      if debug>0:
	print "tmpVal %x" % tmpVal
    val1095=tmpVal & 0xFF
    if debug>0:
      print "val1095: %x" % val1095
    val1096=(val1094-val1095+val1096) & 0xFF
    if debug>0:
      print "val1096: %x" % val1096
    val1093=ord(username[ii])
    if debug>0:
      print "val1093 (at end loop): %x" % val1093
  if debug>0:
    print "done "+str(val1096) + "oppure %x" % val1096
  return val1096

def toAscii(valore):
  valore2=0
  if valore<0xA:
    valore2=valore+0x30
  else:
    valore2=valore+0x37
  return chr(valore2)
      
def toString(in_string):
  destString="".join(in_string)
  destString2=""
  for ii in range(0,len(destString)):
    destString2=destString2+"%x" % ord(destString[ii])
  destString2=destString2.upper()
  return destString2

def extractValue(in_value):
  valAscii=ord(in_value)
  #if valAscii==0:
  #   return -1
  if debug>0:
    print 'value:'+in_value+' valAscii:'+str(valAscii)
  value2=0
  if valAscii > 0x39:
    if debug>0:
      print "letter"
    value2=valAscii-0x37
  else:
    if debug>0:
      print 'number'
    value2=valAscii-0x30
  if debug:
    print in_value+' '+str(value2)
  return value2
   
def bytes(integer):
    return divmod(integer, 0x10)

def computesSecondXorParam(xoredValue,firstXorParam):
  tempValue=xoredValue^firstXorParam
  if debug:
    print "firstXorParam: %x" % firstXorParam
    print "xoredValue: %x" % xoredValue
    print "xor: %x" % tempValue
  for ii in range(0,4):
    remainder=0
    tempValue=tempValue & 0xFF
    if tempValue>0x80:
      remainder=1
    tempValue=tempValue*2+remainder;
    if debug:
      print "secondXorParam(loop " + str(ii) +  "): %x" % tempValue + " remainder:" + str(remainder)
  return tempValue & 0xFF

if debug:
    print "n. of parameters:" +  str(len(sys.argv))
if len(sys.argv) == 2:
  username=sys.argv[1]
elif len(sys.argv) == 1:
  username="mre521"
  username="b3nder"
  #username="AntonDevil"
else:
  print "USE " + str(sys.argv[0]) + " [username]"
  exit()

if len(username)<6:
  print "This keygen works only for a long username. at least 6 characters"
  exit()

#first xor param (from username)
firstXorParam=computeValues(username)

destString=[ c for c in "LNSDF"]

xoredValue=random.randint(10,0x7F)
print "xoredValue %x" % xoredValue
counter=0
for ii in range(0,len(username)):
  #print "loop ii:"+str(ii)
  if counter==len(destString):
    print "resetting counter"
    counter=0
  destString[counter]= chr( ord(destString[counter]) ^ ord(username[ii])  )
  counter=counter+1

print "before additing:" + toString(destString)
for ii in range(0,len(destString)):
  if debug:
    print "after sum: %x" % (ord(destString[ii])+xoredValue)
  destString[ii]=chr(ord(destString[ii])+xoredValue) 

print "after summing:" + toString(destString)
secondXorParam=computesSecondXorParam(xoredValue,firstXorParam)
print "secondXorParam: %x" % secondXorParam

#additing a 0 if it is the case
if secondXorParam<=0xF:
  destString.append(chr(0))
destString.append(chr(secondXorParam))

destString2=toString(destString)

print "string:"+destString2
print "hashing done"

stringNum=[extractValue(c) for c in destString2]

solution=['0' for c in range(0,10)]

#1,2
solution[0]=toAscii(stringNum[1])
solution[1]=toAscii((stringNum[0]>>1)+((stringNum[3]&0x3)<<3))

#3,4
solution[2]=toAscii(0x4*(stringNum[2] & 0x7)+(stringNum[3]>>2))
solution[3]=toAscii(((stringNum[2] & 0x8) >>3) + ((stringNum[5] & 0xF)<<1 ))

#5,6
solution[4]=toAscii(   (stringNum[4]) + ((stringNum[7] & 0x1)<<0x4))  
#print chr((stringaNum[4]) + ((stringaNum[7] & 0x1)<<0x4)+0x37)
solution[5]=toAscii(    (stringNum[7] >>1)+((stringNum[6] & 0x3)<<0x3))

#7,8
solution[6]=toAscii(  ((stringNum[6] & 0xC)>>2) + ((stringNum[9] & 0x7)<<2) )
solution[7]=toAscii(  ((stringNum[9] & 0x8)>>3) + ((stringNum[8] )<<1) )

#9,A
solution[8]=toAscii( stringNum[11]+ (stringNum[10]&0x1)*0x10 )
solution[9]=toAscii(  ((stringNum[10] & 0xF)>>1)  )

serial="".join(solution)
print "solution("+ username + "): " +serial
