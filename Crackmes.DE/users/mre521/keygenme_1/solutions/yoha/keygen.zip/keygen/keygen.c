// keygen for mre521's KeygenMe #1
// http://crackmes.de/users/mre521/keygenme_1/

// compile with
// gcc -Wall -Wextra -Werror -pedantic -ansi -std=c99 -O3 keygen.c
// the only requisite flag is -std=c99

// The serial is of the form: WWWW-XXXX-YYYY-ZZZZ.
// Bytes of WWWW are noted W0, W1, ...
// Bits of W0 are noted W0W0W0W0.
//
// Actually, 'A' means 0, 'B' 1, etc.
//
// decodeCipher takes the KEY (serial) and compute
// an inclusive or one the concatenation of some bytes
// of the serial:
//
// CIPHER:
// 32      24      16       8       0
//   W0W0X0X0X0X0Y0Y0Y0Y0Z0Z0Z0Z0
//   W2W2W2W2X2X2X2X2Y2Y2Y2Y2Z2Z2Z2Z2
// 
// HIDDENKEY:
// 32      24      16       8       0
//   W1W1X1X1X1X1Y1Y1Y1Y1Z1Z1Z1Z1
//   W3W3W3W3X3X3X3X3Y3Y3Y3Y3Z3Z3Z3Z3

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

// rotate right
#define ROR(X, S) ( ((X)>>(S)) | ((X)<<(32-(S))) )

typedef unsigned long u32;

static u32 getCipher(char* key)
{
	u32 ret = 0;
	char shift = 28;
	for (int p = 0; p < 4; p++)
		for (int i = 0; i < 4; i += 2, shift -= 4)
			ret |= (key[5*p+i]-'A') << shift;
	return ret;
}
static u32 getHiddenKey(char* name, u32 cipher)
{
	u32 sum = 0;
	char* c;
	for (c = name; *c; c++)
		sum += *c;
	sum = cipher-sum;
	for (c--; c>=name; c--)
	{
		sum += *c;
		sum = ROR(sum, *c % 32);
	}
	return ~sum;
}
static void setHiddenKey(char* key, u32 hidden)
{
	key[ 1] += (hidden >> 28) & 0xF;
	key[ 3] += (hidden >> 24) & 0xF;
	key[ 6] += (hidden >> 20) & 0xF;
	key[ 8] += (hidden >> 16) & 0xF;
	key[11] += (hidden >> 12) & 0xF;
	key[13] += (hidden >>  8) & 0xF;
	key[16] += (hidden >>  4) & 0xF;
	key[18] += (hidden >>  0) & 0xF;
}

static void usage(int argc, char** argv)
{
	(void) argc;

	fprintf(stderr,
		"Usage: %s name\n"
		"Generate a serial for the given name\n"
		,
		argv[0]
	);
}
int main(int argc, char** argv)
{
	if (argc < 2)
	{
		usage(argc, argv);
		exit(0);
	}

	char* name = argv[1];
	char key[] = "AAAA-AAAA-AAAA-AAAA";

	// randomize the even bytes to get a random cipher
	srand(time(NULL));
	for (int p = 0; p < 4; p++)
		for (int i = 0; i < 4; i+=2)
			key[5*p+i] += rand() % ('Z'-'A');

	u32 cipher = getCipher(key);             // get the corresponding cipher
	u32 hidden = getHiddenKey(name, cipher); // compute the expected hiddenKey
	setHiddenKey(key, hidden);               // update the odd bytes of the key

	printf("%s\n", key);
	return 0;
}
