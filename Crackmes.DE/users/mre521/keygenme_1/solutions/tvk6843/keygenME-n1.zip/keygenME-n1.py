char_set = range(65, 126)

def rotr(x, n, bits = 32):
  n = n % bits
  mask = (2L ** n) - 1
  mask_bits = x & mask
  return (x >> n) | (mask_bits << (bits - n))

def check_cipher(string, cipher):
  esi = 0
  for ch in string:
    esi = esi + ord(ch)
  esi = (cipher - esi) & 0xffffffff
  for ch in string[::-1]:
    n = ord(ch)
    esi = esi + n
    esi = rotr(esi, n)
  return (~esi) & 0xffffffff

def split_key(key):
  hidden = []
  cipher = []
  while len(key) > 0:
    subkey = key[0:4]
    for idx in range(len(subkey)):
      if idx % 2 == 0:
        cipher.append(ord(subkey[idx]))
      else: 
        hidden.append(ord(subkey[idx]))
    key = key[5:]
  return cipher, hidden

def compose_key(cipher, hidden):
  key = ''
  idx = 0;
  while len(cipher) > 0 and len(hidden) > 0:
    if idx % 4 == 0 and len(key) > 0:
      key = key + '-'
    key = key + chr(cipher[0]) + chr(hidden[0])
    idx = idx + 2;
    cipher = cipher[1:]
    hidden = hidden[1:]
  return key

def array_to_int(array_int, number):
  m = 0
  for n in array_int:
    m = (m << 4) | (n - 0x41)
  return (number | m) & 0xffffffff

def int_to_array(number, min_bits = 32):
  array_int = []
  while (number != 0) and (min_bits / 4 > len(array_int)):
    array_int.append((number & 0x1f) + 0x41)
    number = number >> 4
  array_int.reverse();
  return array_int

def decode_cipher(key, cipher, hidden):
  cipher_int, hidden_int = split_key(key)
  return array_to_int(cipher_int, cipher), array_to_int(hidden_int, hidden)

def change_cipher_array(cipher_array):
  changed = False
  if len(cipher_array) == 0:
    for i in range(8):
      cipher_array.append(char_set[0])
    changed = True
  else:
    for idx in range(len(cipher_array)):
      cipher_array_idx = char_set.index(cipher_array[idx]) + 1
      if cipher_array_idx >= len(char_set):
        cipher_array[idx] = char_set[0];
      else:
        changed = True
        cipher_array[idx] = char_set[cipher_array_idx];
        break;

  return (changed, cipher_array)

print 'The keygen produces multiple solutions, press ctrl-C to break'
print
name = raw_input('What is your name? ')
cipher_array = []

while True:
  changed_cipher, cipher_array = change_cipher_array(cipher_array)
  if not changed_cipher:
    break;

  cipher = 0
  cipher = array_to_int(cipher_array, cipher);
  hidden = check_cipher(name, cipher)
  hidden_array = int_to_array(hidden)

  print 'Found key!!! Name is %s and Key is %s' % (name, compose_key(cipher_array, hidden_array))


