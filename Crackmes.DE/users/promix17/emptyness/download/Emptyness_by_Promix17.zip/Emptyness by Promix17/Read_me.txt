Emptyness 1.0
Written by Promix17

Level of difficulty: 3

What should you do? You should find the correct password)))
You can ask me - where the edit box is, but I think you can
understand it by yourself :-) Note: patches aren't allowed!

Send me your solutions, questions, comments and offers. 

E-mail: promix17@yandex.ru
 