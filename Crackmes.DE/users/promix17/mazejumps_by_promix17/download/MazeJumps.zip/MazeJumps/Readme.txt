MazeJumps v1.0
Written by Promix17

Level of dufficulty: 3/10

The goal is to register this program with the keyfile.

This crackme has unusual code structure. Hope you will like it.

Good luck)))
