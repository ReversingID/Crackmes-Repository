# Python code to remove JMPs & junk from obfuscated code in IDA
# for crackme - MazeJumps
# based on a script created by alexander dot hanel at gmail dot come
# edit by solutionmes at gmail dot come

from idaapi import *
import idautils
import idc
import sys

class JMPJMP:
    def __init__(self):
        self.errorStatus = 'Good'
        self.buffer = []
        self.condJmps = ['jo', 'jno', 'jb', 'jnae', 'jc', 'jnb', 'jae', 'jnc', 'jz', \
                                'je', 'jnz', 'jne', 'jbe', 'jna', 'jnbe', 'ja', 'js', 'jns', \
                                'jp', 'jpe', 'jnp', 'jpo', 'jl', 'jnge', 'jnl', 'jge', 'jle', \
                                'jng', 'jnle', 'jg']
        self.condJmpsAddr = set([])
        self.retn = ['retn', 'ret', 'retf']
        self.callAddr = set([])
        self.call = 'call'
        self.callByte = 0xe8
        self.jmp = 'jmp'
        self.visitedAddr = set([])
        self.target = set([])
        self.stopaddr = [0x4092F0, 0x4092EA, 0x4092E4, 0x4092DE]

    def getCode(self, addr):
        #Jump(addr)
        MakeUnknown(addr, 5, 0)
        instLen = MakeCode(addr)
        return instLen

    def getJmpAddress(self, addr):
        "returns the address the JMP instruction jumps to"
        self.getCode(addr)
        return GetOperandValue(addr, 0)

    def checkAddr(self,addr):
        'checks if the address is valid'
        if addr is BADADDR:
            print "Could not find find function start address"
            self.errorStatus = 'Bad!'

    def getNext(self, addr):
        "returns the next address and instructions"
        next = addr + self.getCode(addr)
        #print "next "+GetDisasm(next)
        return next, GetDisasm(next), GetMnem(next), Byte(next)

    def getCur(self, addr):
        "returns address, dissasembly, the mnemoic and byte"
        self.getCode(addr)
        #print "cur "+GetDisasm(addr)
        return addr, GetDisasm(addr), GetMnem(addr), Byte(addr)

    def formatLine(self,addr):
        'format the line to mimic IDA layout'
        return   idaapi.COLSTR(SegName(addr) + ':' + '%08X' % addr, idaapi.SCOLOR_INSN) + '\t' + idaapi.COLSTR(GetDisasm(addr) , idaapi.SCOLOR_INSN)

    def printBuffer(self):
        'print the buffer that contains the instructions minus jmps'
        v = idaapi.simplecustviewer_t()
        if v.Create("JMP CleanUp Viewer"):
            for instru in self.buffer:
                v.AddLine(instru)
            v.Show()
        else:
            print "Failed to create viewer, wa waa waaaaa"

    def simplify(self, addr, target = list([]) ):
        # check if valid addresss
        if addr in self.visitedAddr:
            return
        else:
            current_addr, current_inst, current_mnem, byte = self.getCur(addr)
            temp = current_addr
            self.buffer.append('__start: %s' % hex(temp))
            while(1):
                #print "%X"%current_addr
                if current_addr in self.stopaddr:
                    break
                if current_addr == -1:
                    print "Invalid address"
                    self.errorStatus = 'Bad!'
                    return

                jmpAddr = 0

                self.checkAddr(current_addr)
                if self.errorStatus != 'Good':
                    return
                if current_mnem in self.jmp:
                    # uncomment if you want to see the jmp instruction in the output
                    #self.buffer.append(self.formatLine(current_addr))
                    jmpAddr = self.getJmpAddress(current_addr)
                    self.visitedAddr.add(current_addr)
                    current_addr, current_inst, current_mnem, byte = self.getCur(jmpAddr)
                    continue

                # check junk instructions
                if byte == 0x90:
                    jmpAddr = current_addr + 1
                    self.visitedAddr.add(current_addr)
                    current_addr, current_inst, current_mnem, byte = self.getCur(jmpAddr)
                    continue
                if (byte == 0x40 and Byte(current_addr+1) == 0x48) or \
                   (byte == 0x41 and Byte(current_addr+1) == 0x49) or \
                   (byte == 0x44 and Byte(current_addr+1) == 0x4C) or \
                   (byte == 0x4C and Byte(current_addr+1) == 0x44) or \
                   (byte == 0x24 and Byte(current_addr+1) == 0xFF) or \
                   (byte == 0x50 and Byte(current_addr+1) == 0x58) or \
                   (byte == 0x51 and Byte(current_addr+1) == 0x59) or \
                   (byte == 0x52 and Byte(current_addr+1) == 0x5A) or \
                   (byte == 0x60 and Byte(current_addr+1) == 0x61) or \
                   (byte == 0x74 and Byte(current_addr+1) == 0x00) or \
                   (byte == 0x75 and Byte(current_addr+1) == 0x00):
                    jmpAddr = current_addr + 2
                    self.visitedAddr.add(current_addr)
                    current_addr, current_inst, current_mnem, byte = self.getCur(jmpAddr)
                    continue
                if (byte == 0x24 and Byte(current_addr+2) == 0x00) or \
                   (byte == 0x24 and Byte(current_addr+2) == 0xFF) or \
                   (byte == 0x44 and Byte(current_addr+2) == 0x4C) or \
                   (byte == 0x4C and Byte(current_addr+2) == 0x44) or \
                   (byte == 0x60 and Byte(current_addr+2) == 0x61) or \
                   (byte == 0x80 and Byte(current_addr+2) == 0x00) or \
                   (byte == 0x80 and Byte(current_addr+2) == 0xFF) or \
                   (byte == 0x83 and Byte(current_addr+2) == 0x00) or \
                   (byte == 0x75 and Word(current_addr+1) == 0x9001) or \
                   (byte == 0x74 and Word(current_addr+1) == 0x9001):
                    jmpAddr = current_addr + 3
                    self.visitedAddr.add(current_addr)
                    current_addr, current_inst, current_mnem, byte = self.getCur(jmpAddr)
                    continue
                if (Word(current_addr) == 0x0434 and Word(current_addr+2) == 0x0434) or \
                   (Word(current_addr) == 0x5434 and Word(current_addr+2) == 0x5434) or \
                   (Word(current_addr) == 0x4140 and Word(current_addr+2) == 0x4948) or \
                   (Word(current_addr) == 0x4948 and Word(current_addr+2) == 0x4041) or \
                   (byte == 0x50 and Byte(current_addr+3) == 0x58) or \
                   (byte == 0x51 and Byte(current_addr+3) == 0x59) or \
                   (byte == 0x52 and Byte(current_addr+3) == 0x5A) or \
                   (byte == 0x60 and Byte(current_addr+3) == 0x61) or \
                   (byte == 0xF7 and Byte(current_addr+2) == 0xF7 and Byte(current_addr+1) == Byte(current_addr+3)):
                    jmpAddr = current_addr + 4
                    self.visitedAddr.add(current_addr)
                    current_addr, current_inst, current_mnem, byte = self.getCur(jmpAddr)
                    continue

                # check for conditonal jmps, if so add to the target aka come back to list
                if current_mnem in self.condJmps:
                    self.buffer.append(self.formatLine(current_addr))
                    jmpAddr = self.getJmpAddress(current_addr)
                    target.append(jmpAddr)
                # if call, we will need the call address
                elif current_mnem in self.call and byte == self.callByte:
                    self.buffer.append(self.formatLine(current_addr))
                    #target.append(GetOperandValue(current_addr,0))
                    #print self.formatLine(current_addr)
                else:
                    self.buffer.append(self.formatLine(current_addr))

                if current_mnem in self.retn or current_addr in self.visitedAddr:
                    break
                self.visitedAddr.add(current_addr)
                current_addr, current_inst, current_mnem, byte = self.getNext(current_addr)

            self.buffer.append('__end: %s ' % hex(temp))
            self.buffer.append('')
            for revisit in target:
                if revisit in self.visitedAddr:
                    continue
                else:
                    self.simplify(revisit, target)

        return

def main():
    simp = JMPJMP()
    simp.simplify(0x401000)
    simp.simplify(0x40812F)
    simp.simplify(0x405ADD)
    simp.printBuffer()


if __name__ == "__main__":
    main()