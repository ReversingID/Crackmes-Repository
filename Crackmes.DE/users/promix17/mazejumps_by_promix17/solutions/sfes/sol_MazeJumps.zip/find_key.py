from z3 import *

# add a condition: the symbol ch should be alpha char or space
def isalpha(s, ch, alpha_l):
    sub_eq = False
    for i in alpha_l:
        sub_eq = Or(sub_eq, ch == i)
    s.append(sub_eq)

# our alphabet
alpha = " abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
alpha_l = []
for i in alpha:
    alpha_l.append(ord(i))

# constants of crackme
a1 = 0xF45A675D
b1 = 0x4DDAFA31
c1 = 0xBAE3DC73
a2 = 0xAADD357D
b2 = 0x44FAFC3C
c2 = 0xF23F2C88

# create an object Solver Z3
solver = Solver()

# create vars
# k0 and k1 - DWORD (32 bits)
key = []
for i in xrange(2) :
    key.append(BitVec("k%d"%i, 32))

# write the expression:
# (1)
check1 = (key[0] ^ a1) + (key[1] ^ b1)
# (2)
check2 = (key[0] ^ a2) + (key[1] ^ b2)
# add a conditions for (1) and (2)
solver.append(check1 == c1, check2 == c2)

# (3) get text (first 4 bytes) for MessageBoxA
mes1 = key[0] ^ 0xF0F101B;
# (4) get text  (next 4 bytes) 
mes2 = key[1] ^ 0x6F04530A;

# add a condition that the k0 (bytes) should be all alpha characters or spaces
isalpha(solver, key[0] & 0xFF, alpha_l)
isalpha(solver, (key[0] >> 8) & 0xFF, alpha_l)
isalpha(solver, (key[0] >> 16) & 0xFF, alpha_l)
isalpha(solver, (key[0] >> 24) & 0xFF, alpha_l)

# add a condition that the k1  (bytes) should be all alpha characters or spaces
isalpha(solver, key[1] & 0xFF, alpha_l)
isalpha(solver, (key[1] >> 8) & 0xFF, alpha_l)
isalpha(solver, (key[1] >> 16) & 0xFF, alpha_l)
isalpha(solver, (key[1] >> 24) & 0xFF, alpha_l)

# add a condition for mes1
isalpha(solver, mes1 & 0xFF, alpha_l)
isalpha(solver, (mes1 >> 8) & 0xFF, alpha_l)
isalpha(solver, (mes1 >> 16) & 0xFF, alpha_l)
isalpha(solver, (mes1 >> 24) & 0xFF, alpha_l)

# add a condition for mes2
isalpha(solver, mes2 & 0xFF, alpha_l)
isalpha(solver, (mes2 >> 8) & 0xFF, alpha_l)
isalpha(solver, (mes2 >> 16) & 0xFF, alpha_l)
# the least significant byte mes2 must be 0
nilbyte = (mes2 >> 24) & 0xFF
solver.append(nilbyte == 0)

# start the calculation with search of all solutions
while solver.check() == sat:
    # find one solution
    solution = solver.model()
    # k0, k1 convert to a string
    str_x = ""
    x = int(str(solution[key[0]]))
    str_x = chr(x & 0xFF)+chr((x >> 8) & 0xFF)+chr((x >> 16) & 0xFF)+chr((x >> 24) & 0xFF)
    x = int(str(solution[key[1]]))
    str_x += chr(x & 0xFF)+chr((x >> 8) & 0xFF)+chr((x >> 16) & 0xFF)+chr((x >> 24) & 0xFF)
    # print a solution
    print ("Key: "+str_x)

    # add a condition: exclude the solution found
    solver.add(Or(key[0] != solution[key[0]], key[1] != solution[key[1]]))
