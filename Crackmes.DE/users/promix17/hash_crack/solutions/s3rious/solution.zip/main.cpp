//---------------------------------------------------------------------------------------
/*
**  Hash Crack by Promix17
**  Password Cracker
**
**  This program crack the 3 program hashes, by brute forcing all possible passwords.
**  Encryption algorithm has a simple flaw: Each character of the password is hashed
**  independently from others. Thus we reduce dramatically the search space, and
**  crack the hashes easy.
**
**  02/11/2012 - __1n5@NEc0deR__
*/
//---------------------------------------------------------------------------------------
#include <stdio.h>
#include <string.h>


char init_hash[] =
{
"\x45\x40\x0D\x34\xF3\x78\x12\x87\x40\xCD\x42\xEC\x4C\xEB\x60\xA5"
"\xE2\x60\xE3\xE2\xEE\x8A\x4D\xE8\x42\xDC\xA7\x81\xE5\x9E\xDC\x81"
"\xE9\x9F\x2B\x3C\xCC\x8D\x42\xC2\xDC\x28\x0C\x8C\xA3\xB0\x38\x12"
"\xF4\xC2\x8E\x78\x2F\xA5\x67\x06\x86\xAA\x06\xDC\x04\x6E\x55\x24"
"\x5E\x96\x0E\x77\x00\x00\x00\x00\xB9\x09\xF4\x77\x65\x54\xC1\x8C"
"\x5A\xDA\x97\x08\x16\x52\xFC\x8C\xC0\x18\x59\x72\x94\x8A\x97\x1B"
"\xFE\x76\x80\x26\x65\xDF\x59\xBC\xB5\x8A\x46\xCB\x4A\xE1\xE7\xD1"
"\x53\x98\xEC\x86\x0B\x84\xF8\x73\xAE\x1A\x19\x08\xC3\x4F\x9C\x03"
"\xF7\x08\xC9\x19\x29\x23\x54\xDB\xB0\xB1\x9F\x00\xA9\x30\x3A\x05"
"\xF9\x9B\xD5\x46\x41\x71\x53\x58\x8D\xCD\x61\x3F\x00\x00\x00\x00"
};

char hash1[] = {
    "A04C4DE7BACAED32F66E0DE40AA38A249C66ADF6E05B4CC09ECAAE709853C406"
    "ACFA2FF66DA34CF009B1F7328134CE249E78405CB2D4DFD822330430F5D27190"
};
char hash2[] = {
    "4AA977C10E3EDF310603EF91B4967494207704E4B4EEB5B2A4CBEED42F17E705"
    "30AB18C1B89D8584163256F43182FF1398B20E01E04D845902BB9636D7EEA2B0"
};
char hash3[] = {
    "E3010516EEDA26116D47C7D528BF43C3322B16932713A684627BD7B536AF9B67"
    "D87E4D2588CE7572B4FE2512530A2D105E43861233B3B4461E8E1C14897A28F6"
};

// message box secret message. msg is XORed with correct password.
char msg[]  = { "\x10\x04\x04\x02\x17\x1B\x0A\x00\x45\x2C\x40\x52\x49\x00" };
//---------------------------------------------------------------------------------------
/*
**  hash_me():
**      Here is the encryption algorithm. hash_me() takes the password and the
**      password length as arguments, and creates a hash which returned in hash
**      argument.
**
**  Return Value: None.
*/
//---------------------------------------------------------------------------------------
void hash_me
(
    char *password,                     // password to hash
    int password_len,                   // password length
    char *str                           // hash to return
)
{
    char v_1, v_a9, v_aa,               // local variables of fucntion
         hash[160];                     // initial hash
    int i,j,k;                          // iterators


    memcpy( hash, init_hash, 160);      // get a copy of original hash

    /* copy password at the end of the hash */
    strncpy( hash+0x8c, password, password_len);

    /*
    ** Here is the encryption algorithnm
    */
	for(i=0; i<0x10; i++ )              // i = LOCAL.2
	{
        v_aa = 0x1;
        v_a9 = (hash[0x8c + i] & 0xf) << 4;
        v_1  =  hash[0x8c + i] >> 4;

		hash[0x8b] = 0x80;


		for(j=0; j<0x4; j++ )           // j = LOCAL.44
		{
            /** hash[0x8c + i] = password[i] !!! **/

			hash[j + 4*i] ^= hash[0x8c + i] *
                             hash[0x48 + j + 4*i] +
                             hash[0x8c + i];

            hash[j + 4*i] += hash[0x48 + (hash[j + 4*i] & 0x3f)];

            hash[ (hash[0x48 + (hash[j + 4*i] & 0x3f)] & 0xff)
                    % (0x40 - (i<<2) - j) + (j + 4*i) ]
                        *= hash[j + 4*i] ^ hash[0x8c + i];

            hash[j + 4*i] &= ~hash[0x8b];
            hash[j + 4*i] &= ~v_aa;
            hash[j + 4*i] ^= hash[0x8b] & v_a9;
            hash[j + 4*i] ^= v_1 & v_aa;


			for( k=0; k<0x40; k++ )     // k = LOCAL.25
            {
				hash[0x48 + k] ^= hash[0x48 + (hash[j + 4*i] & 0x3f)] +
                                  hash[j + 4*i];
            }

            hash[0x44] = 0x40; // = LOCAL.25
            hash[0x8b] >>= 1;
            hash[0x8b] &= 0x7f;

            v_aa = (v_aa << 1) & 0xff;
		}
	}

    /*
    **  Now, convert first 0x40 characters from hex to string
    */
    for( i=0; i<0x40; i++ )
        sprintf( str+2*i, "%02X", hash[i]&0xff );

    /*
    **  display the hash (DEBUG)
    */
/*
    printf( "Hashing password: %s\n\n", password );

    for( i=0; i<0xA; i++ )          // for each row
    {
        for( j=0; j<0x10; j++ )     // rows of 16 characters each
        {
            printf( "%2X ", hash[i*0x10 + j] & 0xff );
        }
        printf( "\n" );
    }

    printf( "\n\nHash: %s\n", str );
*/
}

//---------------------------------------------------------------------------------------
/*
**  crack_hash():
**      This function cracks the hash, and displays the password. crack_hash(),
**      is based on a simple flaw of encryption algorithm: Each character of the
**      password is hashed independently from others. Thus we guess the first
**      character by brute-forcing all possible characters. Then we continue with
**      the second character, and so on...
**
**  Return Value: None.
*/
void crack_hash
(
    char *hash                      // Hash to crack
)
{
    char password[17] = { "\0" },   // password array
         hash4[ 256 ] = { "\0" };   // hash

    memset( password, '\0', 16 );

    printf( "\nCracking Hash: %s.........\n\n\n", hash );

    for( int i=0; i<16; i++ )       // for each character of the password
    {
        /* Try all possible characters. Start from SPACE (0x20) */
        for( int j=0x20; j<0xff; j++ )
        {
            password[i] = j;        // set possible password

            hash_me( password, 16, hash4 );         // hash password

            if( !strncmp( hash+8*i, hash4+8*i, 8) ) // character match ?
            {
                /* We found 1 character of the password. Go on! */
                printf( "Character matched: %c\n", j );
                break;
            }
        }
    }

    /*
    **  Check if password cracked correctly.
    */
    if( strcmp( hash, hash4 ) ) printf( "\nCannot crack the Hash!\n\n" );
    else printf( "\nHash cracked successfully.\nPassword is: %s\n\n", password );
}
//---------------------------------------------------------------------------------------
int main( void )
{
    printf( "; --------------------------------------------------------------- ;\n");
    printf( ";                      Hash Crack by Promix17                     ;\n");
    printf( ";                         Password Cracker                        ;\n");
    printf( "; --------------------------------------------------------------- ;\n");

    /* crack password hash */
    crack_hash( hash2 );


    /* Now, crack the other hashes.... */

    printf( "; --------------------------------------------------------------- ;");
    crack_hash( hash1 );

    printf( "; --------------------------------------------------------------- ;");
    crack_hash( hash3 );


    return 0;
}
//---------------------------------------------------------------------------------------
