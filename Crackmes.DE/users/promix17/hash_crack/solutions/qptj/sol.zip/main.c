#include <string.h>
#include <stdio.h>
#include <windows.h>

hash_ ();

const char* fix__004032EC = "%02X";
char* in = "0000000000000000";
char buff1[2048]="";
char temp[100]="";
char out[80]="";
const char* hash1 = "4AA977C10E3EDF310603EF91B4967494207704E4B4EEB5B2A4CBEED42F17E70530AB18C1B89D8584163256F43182FF1398B20E01E04D845902BB9636D7EEA2B0";
const char* hash2 = "A04C4DE7BACAED32F66E0DE40AA38A249C66ADF6E05B4CC09ECAAE709853C406ACFA2FF66DA34CF009B1F7328134CE249E78405CB2D4DFD822330430F5D27190";
const char* hash3 = "E3010516EEDA26116D47C7D528BF43C3322B16932713A684627BD7B536AF9B67D87E4D2588CE7572B4FE2512530A2D105E43861233B3B4461E8E1C14897A28F6";


main()
{
	printf("Hash cracker for Promix17 crackme\n");
	printf("Cracking hash N1...\t");
	CrackIt(hash1);
	printf(in);
	printf("\n");
	printf("Cracking hash N2...\t");
	CrackIt(hash2);
	printf(in);
	printf("\n");
	printf("Cracking hash N3...\t");
	CrackIt(hash3);
	printf(in);
	printf("\n");
	getch();
}

CrackIt(char* theHash)
{
	int i=0,j=0;
	do {
		do {
			in[j]=i;
			i++;
			hash(in,16,out);
			lstrcpyn(&buff1[8*i],&out[j*8],9);
		} while (i != 256);
		i=0;
		lstrcpyn(temp,&theHash[j*8],9);
		in[j]=(strstr(&buff1[8],temp)-&buff1[8])/8;
		j++;
	} while (j != 16);
}

hash(char pw,int len, char out)
{
	__asm {
		push out
		push len
		push pw
		call hash_
		add esp, 4*3
	}
}

hash_()
{
	__asm {
		add esp,0xC
		
fix__00401A30:                               ;<= Procedure Start

        PUSH EBP
        MOV EBP,ESP
        SUB ESP,0xB0
        PUSH ESI
        PUSH EDI
        MOV BYTE PTR SS:[EBP-0xA8],0x45
        MOV BYTE PTR SS:[EBP-0xA7],0x40
        MOV BYTE PTR SS:[EBP-0xA6],0xD
        MOV BYTE PTR SS:[EBP-0xA5],0x34
        MOV BYTE PTR SS:[EBP-0xA4],0xF3
        MOV BYTE PTR SS:[EBP-0xA3],0x78
        MOV BYTE PTR SS:[EBP-0xA2],0x12
        MOV BYTE PTR SS:[EBP-0xA1],0x87
        MOV BYTE PTR SS:[EBP-0xA0],0x40
        MOV BYTE PTR SS:[EBP-0x9F],0xCD
        MOV BYTE PTR SS:[EBP-0x9E],0x42
        MOV BYTE PTR SS:[EBP-0x9D],0xEC
        MOV BYTE PTR SS:[EBP-0x9C],0x4C
        MOV BYTE PTR SS:[EBP-0x9B],0xEB
        MOV BYTE PTR SS:[EBP-0x9A],0x60
        MOV BYTE PTR SS:[EBP-0x99],0xA5
        MOV BYTE PTR SS:[EBP-0x98],0xE2
        MOV BYTE PTR SS:[EBP-0x97],0x60
        MOV BYTE PTR SS:[EBP-0x96],0xE3
        MOV BYTE PTR SS:[EBP-0x95],0xE2
        MOV BYTE PTR SS:[EBP-0x94],0xEE
        MOV BYTE PTR SS:[EBP-0x93],0x8A
        MOV BYTE PTR SS:[EBP-0x92],0x4D
        MOV BYTE PTR SS:[EBP-0x91],0xE8
        MOV BYTE PTR SS:[EBP-0x90],0x42
        MOV BYTE PTR SS:[EBP-0x8F],0xDC
        MOV BYTE PTR SS:[EBP-0x8E],0xA7
        MOV BYTE PTR SS:[EBP-0x8D],0x81
        MOV BYTE PTR SS:[EBP-0x8C],0xE5
        MOV BYTE PTR SS:[EBP-0x8B],0x9E
        MOV BYTE PTR SS:[EBP-0x8A],0xDC
        MOV BYTE PTR SS:[EBP-0x89],0x81
        MOV BYTE PTR SS:[EBP-0x88],0xE9
        MOV BYTE PTR SS:[EBP-0x87],0x9F
        MOV BYTE PTR SS:[EBP-0x86],0x2B
        MOV BYTE PTR SS:[EBP-0x85],0x3C
        MOV BYTE PTR SS:[EBP-0x84],0xCC
        MOV BYTE PTR SS:[EBP-0x83],0x8D
        MOV BYTE PTR SS:[EBP-0x82],0x42
        MOV BYTE PTR SS:[EBP-0x81],0xC2
        MOV BYTE PTR SS:[EBP-0x80],0xDC
        MOV BYTE PTR SS:[EBP-0x7F],0x28
        MOV BYTE PTR SS:[EBP-0x7E],0xC
        MOV BYTE PTR SS:[EBP-0x7D],0x8C
        MOV BYTE PTR SS:[EBP-0x7C],0xA3
        MOV BYTE PTR SS:[EBP-0x7B],0xB0
        MOV BYTE PTR SS:[EBP-0x7A],0x38
        MOV BYTE PTR SS:[EBP-0x79],0x12
        MOV BYTE PTR SS:[EBP-0x78],0xF4
        MOV BYTE PTR SS:[EBP-0x77],0xC2
        MOV BYTE PTR SS:[EBP-0x76],0x8E
        MOV BYTE PTR SS:[EBP-0x75],0x78
        MOV BYTE PTR SS:[EBP-0x74],0x2F
        MOV BYTE PTR SS:[EBP-0x73],0xA5
        MOV BYTE PTR SS:[EBP-0x72],0x67
        MOV BYTE PTR SS:[EBP-0x71],6
        MOV BYTE PTR SS:[EBP-0x70],0x86
        MOV BYTE PTR SS:[EBP-0x6F],0xAA
        MOV BYTE PTR SS:[EBP-0x6E],6
        MOV BYTE PTR SS:[EBP-0x6D],0xDC
        MOV BYTE PTR SS:[EBP-0x6C],4
        MOV BYTE PTR SS:[EBP-0x6B],0x6E
        MOV BYTE PTR SS:[EBP-0x6A],0x55
        MOV BYTE PTR SS:[EBP-0x69],0x24
        MOV BYTE PTR SS:[EBP-0x60],0xB9
        MOV BYTE PTR SS:[EBP-0x5F],9
        MOV BYTE PTR SS:[EBP-0x5E],0xF4
        MOV BYTE PTR SS:[EBP-0x5D],0x77
        MOV BYTE PTR SS:[EBP-0x5C],0x65
        MOV BYTE PTR SS:[EBP-0x5B],0x54
        MOV BYTE PTR SS:[EBP-0x5A],0xC1
        MOV BYTE PTR SS:[EBP-0x59],0x8C
        MOV BYTE PTR SS:[EBP-0x58],0x5A
        MOV BYTE PTR SS:[EBP-0x57],0xDA
        MOV BYTE PTR SS:[EBP-0x56],0x97
        MOV BYTE PTR SS:[EBP-0x55],8
        MOV BYTE PTR SS:[EBP-0x54],0x16
        MOV BYTE PTR SS:[EBP-0x53],0x52
        MOV BYTE PTR SS:[EBP-0x52],0xFC
        MOV BYTE PTR SS:[EBP-0x51],0x8C
        MOV BYTE PTR SS:[EBP-0x50],0xC0
        MOV BYTE PTR SS:[EBP-0x4F],0x18
        MOV BYTE PTR SS:[EBP-0x4E],0x59
        MOV BYTE PTR SS:[EBP-0x4D],0x72
        MOV BYTE PTR SS:[EBP-0x4C],0x94
        MOV BYTE PTR SS:[EBP-0x4B],0x8A
        MOV BYTE PTR SS:[EBP-0x4A],0x97
        MOV BYTE PTR SS:[EBP-0x49],0x1B
        MOV BYTE PTR SS:[EBP-0x48],0xFE
        MOV BYTE PTR SS:[EBP-0x47],0x76
        MOV BYTE PTR SS:[EBP-0x46],0x80
        MOV BYTE PTR SS:[EBP-0x45],0x26
        MOV BYTE PTR SS:[EBP-0x44],0x65
        MOV BYTE PTR SS:[EBP-0x43],0xDF
        MOV BYTE PTR SS:[EBP-0x42],0x59
        MOV BYTE PTR SS:[EBP-0x41],0xBC
        MOV BYTE PTR SS:[EBP-0x40],0xB5
        MOV BYTE PTR SS:[EBP-0x3F],0x8A
        MOV BYTE PTR SS:[EBP-0x3E],0x46
        MOV BYTE PTR SS:[EBP-0x3D],0xCB
        MOV BYTE PTR SS:[EBP-0x3C],0x4A
        MOV BYTE PTR SS:[EBP-0x3B],0xE1
        MOV BYTE PTR SS:[EBP-0x3A],0xE7
        MOV BYTE PTR SS:[EBP-0x39],0xD1
        MOV BYTE PTR SS:[EBP-0x38],0x53
        MOV BYTE PTR SS:[EBP-0x37],0x98
        MOV BYTE PTR SS:[EBP-0x36],0xEC
        MOV BYTE PTR SS:[EBP-0x35],0x86
        MOV BYTE PTR SS:[EBP-0x34],0x0B
        MOV BYTE PTR SS:[EBP-0x33],0x84
        MOV BYTE PTR SS:[EBP-0x32],0xF8
        MOV BYTE PTR SS:[EBP-0x31],0x73
        MOV BYTE PTR SS:[EBP-0x30],0xAE
        MOV BYTE PTR SS:[EBP-0x2F],0x1A
        MOV BYTE PTR SS:[EBP-0x2E],0x19
        MOV BYTE PTR SS:[EBP-0x2D],8
        MOV BYTE PTR SS:[EBP-0x2C],0xC3
        MOV BYTE PTR SS:[EBP-0x2B],0x4F
        MOV BYTE PTR SS:[EBP-0x2A],0x9C
        MOV BYTE PTR SS:[EBP-0x29],3
        MOV BYTE PTR SS:[EBP-0x28],0xF7
        MOV BYTE PTR SS:[EBP-0x27],8
        MOV BYTE PTR SS:[EBP-0x26],0xC9
        MOV BYTE PTR SS:[EBP-0x25],0x19
        MOV BYTE PTR SS:[EBP-0x24],0x29
        MOV BYTE PTR SS:[EBP-0x23],0x23
        MOV BYTE PTR SS:[EBP-0x22],0x54
        MOV BYTE PTR SS:[EBP-0x21],0xDB
        MOV BYTE PTR SS:[EBP-0x1C],0xA9
        MOV BYTE PTR SS:[EBP-0x1B],0x30
        MOV BYTE PTR SS:[EBP-0x1A],0x3A
        MOV BYTE PTR SS:[EBP-0x19],5
        MOV BYTE PTR SS:[EBP-0x18],0xF9
        MOV BYTE PTR SS:[EBP-0x17],0x9B
        MOV BYTE PTR SS:[EBP-0x16],0xD5
        MOV BYTE PTR SS:[EBP-0x15],0x46
        MOV BYTE PTR SS:[EBP-0x14],0x41
        MOV BYTE PTR SS:[EBP-0x13],0x71
        MOV BYTE PTR SS:[EBP-0x12],0x53
        MOV BYTE PTR SS:[EBP-0x11],0x58
        MOV BYTE PTR SS:[EBP-0x10],0x8D
        MOV BYTE PTR SS:[EBP-0xF],0xCD
        MOV BYTE PTR SS:[EBP-0xE],0x61
        MOV BYTE PTR SS:[EBP-0xD],0x3F
    ;    CMP DWORD PTR SS:[EBP+0xC],0x10
    ;    JG fix__00401D22
    ;    CMP DWORD PTR SS:[EBP+0xC],0
    ;    JGE fix__00401D27

fix__00401D22:

   ;     JMP fix__004020DC

fix__00401D27:

        MOV EcX,DWORD PTR SS:[EBP+0xC]
        MOV Esi,DWORD PTR SS:[EBP+8]
        LEA Edi,DWORD PTR SS:[EBP-0x1C]
		rep movsb

        MOV DWORD PTR SS:[EBP-8],0
        JMP fix__00401D4D

fix__00401D44:

        MOV EAX,DWORD PTR SS:[EBP-8]
        ADD EAX,1
        MOV DWORD PTR SS:[EBP-8],EAX

fix__00401D4D:

        CMP DWORD PTR SS:[EBP-8],0x10
        JGE fix__00402085
        MOV ECX,DWORD PTR SS:[EBP-8]
        MOVZX EDX,BYTE PTR SS:[EBP+ECX-0x1C]
        AND EDX,0x8000000F
        JNS fix__00401D6C
        DEC EDX
        OR EDX,0xFFFFFFF0
        INC EDX

fix__00401D6C:

        MOV BYTE PTR SS:[EBP-0xA9],DL
        MOV EAX,DWORD PTR SS:[EBP-8]
        MOVZX EAX,BYTE PTR SS:[EBP+EAX-0x1C]
        CDQ
        AND EDX,0xF
        ADD EAX,EDX
        SAR EAX,4
        MOV BYTE PTR SS:[EBP-1],AL
        MOVZX ECX,BYTE PTR SS:[EBP-0xA9]
        SHL ECX,4
        MOV BYTE PTR SS:[EBP-0xA9],CL
        MOV BYTE PTR SS:[EBP-0x1D],0x80
        MOV BYTE PTR SS:[EBP-0xAA],1
        MOV DWORD PTR SS:[EBP-0xB0],0
        JMP fix__00401DBC

fix__00401DAD:

        MOV EDX,DWORD PTR SS:[EBP-0xB0]
        ADD EDX,1
        MOV DWORD PTR SS:[EBP-0xB0],EDX

fix__00401DBC:

        CMP DWORD PTR SS:[EBP-0xB0],4
        JGE fix__00402080
        MOV EAX,DWORD PTR SS:[EBP-8]
        MOV ECX,DWORD PTR SS:[EBP-0xB0]
        LEA EDX,DWORD PTR DS:[ECX+EAX*4]
        MOV EAX,DWORD PTR SS:[EBP-8]
        MOVZX ECX,BYTE PTR SS:[EBP+EAX-0x1C]
        MOV EAX,DWORD PTR SS:[EBP-8]
        MOV ESI,DWORD PTR SS:[EBP-0xB0]
        LEA EAX,DWORD PTR DS:[ESI+EAX*4]
        MOVZX EAX,BYTE PTR SS:[EBP+EAX-0x60]
        IMUL ECX,EAX
        MOV EAX,DWORD PTR SS:[EBP-8]
        MOVZX EAX,BYTE PTR SS:[EBP+EAX-0x1C]
        ADD ECX,EAX
        MOVZX EDX,BYTE PTR SS:[EBP+EDX-0xA8]
        XOR EDX,ECX
        MOV EAX,DWORD PTR SS:[EBP-8]
        MOV ECX,DWORD PTR SS:[EBP-0xB0]
        LEA EAX,DWORD PTR DS:[ECX+EAX*4]
        MOV BYTE PTR SS:[EBP+EAX-0xA8],DL
        MOV ECX,DWORD PTR SS:[EBP-8]
        MOV EDX,DWORD PTR SS:[EBP-0xB0]
        LEA EAX,DWORD PTR DS:[EDX+ECX*4]
        MOV ECX,DWORD PTR SS:[EBP-8]
        MOV EDX,DWORD PTR SS:[EBP-0xB0]
        LEA ECX,DWORD PTR DS:[EDX+ECX*4]
        MOVZX EDX,BYTE PTR SS:[EBP+ECX-0xA8]
        AND EDX,0x8000003F
        JNS fix__00401E45
        DEC EDX
        OR EDX,0xFFFFFFC0
        INC EDX

fix__00401E45:

        MOVZX ECX,BYTE PTR SS:[EBP+EDX-0x60]
        MOVZX EDX,BYTE PTR SS:[EBP+EAX-0xA8]
        ADD EDX,ECX
        MOV EAX,DWORD PTR SS:[EBP-8]
        MOV ECX,DWORD PTR SS:[EBP-0xB0]
        LEA EAX,DWORD PTR DS:[ECX+EAX*4]
        MOV BYTE PTR SS:[EBP+EAX-0xA8],DL
        MOV ECX,DWORD PTR SS:[EBP-8]
        MOV EDX,DWORD PTR SS:[EBP-0xB0]
        LEA ECX,DWORD PTR DS:[EDX+ECX*4]
        MOV EDX,DWORD PTR SS:[EBP-8]
        MOV EAX,DWORD PTR SS:[EBP-0xB0]
        LEA EDX,DWORD PTR DS:[EAX+EDX*4]
        MOVZX EAX,BYTE PTR SS:[EBP+EDX-0xA8]
        AND EAX,0x8000003F
        JNS fix__00401E93
        DEC EAX
        OR EAX,0xFFFFFFC0
        INC EAX

fix__00401E93:

        MOVZX EAX,BYTE PTR SS:[EBP+EAX-0x60]
        MOV EDX,DWORD PTR SS:[EBP-8]
        SHL EDX,2
        MOV ESI,0x40
        SUB ESI,EDX
        SUB ESI,DWORD PTR SS:[EBP-0xB0]
        CDQ
        IDIV ESI
        LEA EAX,DWORD PTR SS:[EBP+EDX-0xA8]
        MOV EDX,DWORD PTR SS:[EBP-8]
        MOV ESI,DWORD PTR SS:[EBP-0xB0]
        LEA EDX,DWORD PTR DS:[ESI+EDX*4]
        MOVZX EDX,BYTE PTR SS:[EBP+EDX-0xA8]
        MOV ESI,DWORD PTR SS:[EBP-8]
        MOVZX ESI,BYTE PTR SS:[EBP+ESI-0x1C]
        XOR EDX,ESI
        MOVZX ECX,BYTE PTR DS:[EAX+ECX]
        IMUL ECX,EDX
        MOV EDX,DWORD PTR SS:[EBP-8]
        SHL EDX,2
        MOV ESI,0x40
        SUB ESI,EDX
        SUB ESI,DWORD PTR SS:[EBP-0xB0]
        MOV EAX,DWORD PTR SS:[EBP-8]
        MOV EDX,DWORD PTR SS:[EBP-0xB0]
        LEA EAX,DWORD PTR DS:[EDX+EAX*4]
        MOVZX EDX,BYTE PTR SS:[EBP+EAX-0xA8]
        AND EDX,0x8000003F
        JNS fix__00401F0E
        DEC EDX
        OR EDX,0xFFFFFFC0
        INC EDX

fix__00401F0E:

        MOVZX EAX,BYTE PTR SS:[EBP+EDX-0x60]
        CDQ
        IDIV ESI
        MOV EAX,DWORD PTR SS:[EBP-8]
        MOV ESI,DWORD PTR SS:[EBP-0xB0]
        LEA EAX,DWORD PTR DS:[ESI+EAX*4]
        LEA EDX,DWORD PTR SS:[EBP+EDX-0xA8]
        MOV BYTE PTR DS:[EDX+EAX],CL
        MOV EAX,DWORD PTR SS:[EBP-8]
        MOV ECX,DWORD PTR SS:[EBP-0xB0]
        LEA EDX,DWORD PTR DS:[ECX+EAX*4]
        MOVZX EAX,BYTE PTR SS:[EBP-0x1D]
        NOT EAX
        MOVZX ECX,BYTE PTR SS:[EBP+EDX-0xA8]
        AND ECX,EAX
        MOV EDX,DWORD PTR SS:[EBP-8]
        MOV EAX,DWORD PTR SS:[EBP-0xB0]
        LEA EDX,DWORD PTR DS:[EAX+EDX*4]
        MOV BYTE PTR SS:[EBP+EDX-0xA8],CL
        MOV EAX,DWORD PTR SS:[EBP-8]
        MOV ECX,DWORD PTR SS:[EBP-0xB0]
        LEA EDX,DWORD PTR DS:[ECX+EAX*4]
        MOVZX EAX,BYTE PTR SS:[EBP-0xAA]
        NOT EAX
        MOVZX ECX,BYTE PTR SS:[EBP+EDX-0xA8]
        AND ECX,EAX
        MOV EDX,DWORD PTR SS:[EBP-8]
        MOV EAX,DWORD PTR SS:[EBP-0xB0]
        LEA EDX,DWORD PTR DS:[EAX+EDX*4]
        MOV BYTE PTR SS:[EBP+EDX-0xA8],CL
        MOV EAX,DWORD PTR SS:[EBP-8]
        MOV ECX,DWORD PTR SS:[EBP-0xB0]
        LEA EDX,DWORD PTR DS:[ECX+EAX*4]
        MOVZX EAX,BYTE PTR SS:[EBP-0xA9]
        MOVZX ECX,BYTE PTR SS:[EBP-0x1D]
        AND EAX,ECX
        MOVZX EDX,BYTE PTR SS:[EBP+EDX-0xA8]
        XOR EDX,EAX
        MOV EAX,DWORD PTR SS:[EBP-8]
        MOV ECX,DWORD PTR SS:[EBP-0xB0]
        LEA EAX,DWORD PTR DS:[ECX+EAX*4]
        MOV BYTE PTR SS:[EBP+EAX-0xA8],DL
        MOV ECX,DWORD PTR SS:[EBP-8]
        MOV EDX,DWORD PTR SS:[EBP-0xB0]
        LEA EAX,DWORD PTR DS:[EDX+ECX*4]
        MOVZX ECX,BYTE PTR SS:[EBP-1]
        MOVZX EDX,BYTE PTR SS:[EBP-0xAA]
        AND ECX,EDX
        MOVZX EAX,BYTE PTR SS:[EBP+EAX-0xA8]
        XOR EAX,ECX
        MOV ECX,DWORD PTR SS:[EBP-8]
        MOV EDX,DWORD PTR SS:[EBP-0xB0]
        LEA ECX,DWORD PTR DS:[EDX+ECX*4]
        MOV BYTE PTR SS:[EBP+ECX-0xA8],AL
        MOV DWORD PTR SS:[EBP-0x64],0
        JMP fix__0040200B

fix__00402002:

        MOV EDX,DWORD PTR SS:[EBP-0x64]
        ADD EDX,1
        MOV DWORD PTR SS:[EBP-0x64],EDX

fix__0040200B:

        CMP DWORD PTR SS:[EBP-0x64],0x40
        JGE fix__00402060
        MOV EAX,DWORD PTR SS:[EBP-8]
        MOV ECX,DWORD PTR SS:[EBP-0xB0]
        LEA EDX,DWORD PTR DS:[ECX+EAX*4]
        MOVZX EAX,BYTE PTR SS:[EBP+EDX-0xA8]
        MOV ECX,DWORD PTR SS:[EBP-8]
        MOV EDX,DWORD PTR SS:[EBP-0xB0]
        LEA ECX,DWORD PTR DS:[EDX+ECX*4]
        MOVZX EDX,BYTE PTR SS:[EBP+ECX-0xA8]
        AND EDX,0x8000003F
        JNS fix__00402046
        DEC EDX
        OR EDX,0xFFFFFFC0
        INC EDX

fix__00402046:

        MOVZX ECX,BYTE PTR SS:[EBP+EDX-0x60]
        ADD EAX,ECX
        MOV EDX,DWORD PTR SS:[EBP-0x64]
        MOVZX ECX,BYTE PTR SS:[EBP+EDX-0x60]
        XOR ECX,EAX
        MOV EDX,DWORD PTR SS:[EBP-0x64]
        MOV BYTE PTR SS:[EBP+EDX-0x60],CL
        JMP fix__00402002

fix__00402060:

        MOVZX EAX,BYTE PTR SS:[EBP-0x1D]
        CDQ
        SUB EAX,EDX
        SAR EAX,1
        MOV BYTE PTR SS:[EBP-0x1D],AL
        MOVZX EAX,BYTE PTR SS:[EBP-0xAA]
        SHL EAX,1
        MOV BYTE PTR SS:[EBP-0xAA],AL
        JMP fix__00401DAD

fix__00402080:

        JMP fix__00401D44

fix__00402085:

        MOV DWORD PTR SS:[EBP-8],0
        JMP fix__00402097

fix__0040208E:

        MOV ECX,DWORD PTR SS:[EBP-8]
        ADD ECX,1
        MOV DWORD PTR SS:[EBP-8],ECX

fix__00402097:

        CMP DWORD PTR SS:[EBP-8],0x40
        JGE fix__004020C3
        MOV EDX,DWORD PTR SS:[EBP-8]
        MOVZX EAX,BYTE PTR SS:[EBP+EDX-0xA8]
        PUSH EAX
        PUSH fix__004032EC                   ; ASCII "%02X"
        MOV ECX,DWORD PTR SS:[EBP-8]
        MOV EDX,DWORD PTR SS:[EBP+0x10]
        LEA EAX,DWORD PTR DS:[EDX+ECX*2]
        PUSH EAX
        CALL dword ptr [ sprintf ]
        ADD ESP,0xC
        JMP fix__0040208E

fix__004020C3:

fix__004020DC:

        POP EDI
        POP ESI
        MOV ESP,EBP
        POP EBP
        sub esp, 0xC
	}
}