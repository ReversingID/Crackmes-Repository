Entangled Code by Promix17
Level of dufficulty: 3

The purpose is to find correct password.

Hope, it will be interesting

Don't give up and good luck :-)

Send me your solutions, questions, comments and offers. 

E-mail: promix17@yandex.ru