Console Infinity 1.0
Written  by Promix17

Level of dufficulty: 2~3

Simple rules: find the right password for this programm and register it  :-) 
If you find code, send me your solution. Can't do it??? Then you can buy the 
registration code for only 19.99$! Hope that it will be interesting for you!

Send me your responses, comments and offers. 

E-mail: promix17@yandex.ru 

Note: Patches aren't allowed!!! 