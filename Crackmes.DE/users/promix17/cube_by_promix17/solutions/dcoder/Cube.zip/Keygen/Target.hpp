#pragma once
#ifndef __TARGET_H__
#define __TARGET_H__

#include "Types.hpp"

extern const u8 ImageFile[225734];

#endif

