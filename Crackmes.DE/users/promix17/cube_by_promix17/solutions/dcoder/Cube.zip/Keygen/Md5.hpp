#pragma once
#ifndef __MD5_H__
#define __MD5_H__

#include "Types.hpp"

void Md5(u8 *out, const u8 *in, u64 inlen);

#endif

