#pragma once
#ifndef __SHA1_H__
#define __SHA1_H__

#include "Types.hpp"

void Sha1Compress(u32 (&H)[5], const u32 (&Block)[16]);

#endif



