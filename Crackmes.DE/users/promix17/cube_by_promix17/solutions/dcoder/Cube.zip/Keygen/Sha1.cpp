
#include "Sha1.hpp"

static inline u32 rotl32(const u32 x, const u32 c)
{
	return (x << c) | (x >> (32 - c));
}

static inline u32 f0(const u32 x, const u32 y, const u32 z)
{
	return (z ^ (x & (y ^ z)));
}

static inline u32 f1(const u32 x, const u32 y, const u32 z)
{
	return (x ^ y ^ z);
}

static inline u32 f2(const u32 x, const u32 y, const u32 z)
{
	return ((x & y) | (z & (x | y)));
}

static inline u32 f3(const u32 x, const u32 y, const u32 z)
{
	return (x ^ y ^ z);
}


void Sha1Compress(u32 (&H)[5], const u32 (&Block)[16])
{
	u32 a, b, c, d, e;
	u32 W[80];

	a = H[0];
	b = H[1];
	c = H[2];
	d = H[3];
	e = H[4];

	for(size_t i = 0; i < 16; ++i)
		W[i] = Block[i];

	for(size_t i = 16; i < 80; ++i)
		W[i] = rotl32(W[i-3] ^ W[i-8] ^ W[i-14] ^ W[i-16], 1);

	for(size_t i = 0; i < 20; ++i)
	{
		u32 t = rotl32(a, 5) + f0(b, c, d) + e + 0x5A827999U + W[i];
		e = d;
		d = c;
		c = rotl32(b, 30);
		b = a;
		a = t;
	}

	for(size_t i = 20; i < 40; ++i)
	{
		u32 t = rotl32(a, 5) + f1(b, c, d) + e + 0x6ED9EBA1U + W[i];
		e = d;
		d = c;
		c = rotl32(b, 30);
		b = a;
		a = t;
	}

	for(size_t i = 40; i < 60; ++i)
	{
		u32 t = rotl32(a, 5) + f2(b, c, d) + e + 0x8F1BBCDCU + W[i];
		e = d;
		d = c;
		c = rotl32(b, 30);
		b = a;
		a = t;
	}

	for(size_t i = 60; i < 80; ++i)
	{
		u32 t = rotl32(a, 5) + f3(b, c, d) + e + 0xCA62C1D6U + W[i];
		e = d;
		d = c;
		c = rotl32(b, 30);
		b = a;
		a = t;
	}


	H[0] += a;
	H[1] += b;
	H[2] += c;
	H[3] += d;
	H[4] += e;
}