

#include <cstdio>
#include <cassert>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <utility>
#include <string>
#include <memory>
#include <array>
#include <stdexcept>
#include <unordered_map>
#include <map>

#include "Types.hpp"
#include "Sha1.hpp"
#include "Md5.hpp"
#include "Target.hpp"

using namespace std;

template<typename T, size_t N>
size_t ArraySize(T const (&)[N])
{
	return N;
}

static inline u32 Rotl32(const u32 x, const u32 c)
{
	return (x << c) | (x >> (32-c));
}

static inline u32 Rotr32(const u32 x, const u32 c)
{
	return (x >> c) | (x << (32-c));
}

static inline u32 ByteSwap(const u32 x)
{
	const u32 t = Rotl32(x, 16);
	return ((t&0x00FF00FF)<<8) | ((t&0xFF00FF00)>>8);
}

template<typename T>
static inline void Perm1(T &a1)
{
	//static const size_t perm[] = {0, 9, 2, 11, 4, 5, 6, 7, 8, 21, 10, 23, 14, 12, 15, 13, 3, 17, 1, 19, 20, 18, 22, 16};
	auto t = a1[12];
	a1[12] = a1[14];
	a1[14] = a1[15];
	a1[15] = a1[13];
	a1[13] = t;
	t = a1[3];
	a1[3] = a1[11];
	a1[11] = a1[23];
	a1[23] = a1[16];
	a1[16] = t;
	t = a1[1];
	a1[1] = a1[9];
	a1[9] = a1[21];
	a1[21] = a1[18];
	a1[18] = t;
}

template<typename T>
static inline void Perm2(T &a1)
{
	//static const size_t perm[] = {2, 0, 3, 1, 8, 9, 6, 7, 12, 13, 10, 11, 16, 17, 14, 15, 4, 5, 18, 19, 20, 21, 22, 23};
	auto t = a1[0];
	a1[0] = a1[2];
	a1[2] = a1[3];
	a1[3] = a1[1];
	a1[1] = t;
	t = a1[4];
	a1[4] = a1[8];
	a1[8] = a1[12];
	a1[12] = a1[16];
	a1[16] = t;
	t = a1[5];
	a1[5] = a1[9];
	a1[9] = a1[13]; 
	a1[13] = a1[17];
	a1[17] = t;
}

template<typename T>
static inline void Perm3(T &a1)
{
	//static const size_t perm[] = {0, 1, 7, 5, 4, 20, 6, 21, 10, 8, 11, 9, 2, 13, 3, 15, 16, 17, 18, 19, 14, 12, 22, 23};
	auto t = a1[8];
	a1[8] = a1[10];
	a1[10] = a1[11];
	a1[11] = a1[9];
	a1[9] = t;
	t = a1[3];
	a1[3] = a1[5];
	a1[5] = a1[20];
	a1[20] = a1[14];
	a1[14] = t;
	t = a1[2];
	a1[2] = a1[7];
	a1[7] = a1[21]; 
	a1[21] = a1[12];
	a1[12] = t;
}

template<typename T>
static inline void Permute(T &buf, const size_t n)
{
	for(size_t i = 0; i < n/3 + 1; ++i) 
	{
		switch(n%3)
		{
		case 0:
			Perm1(buf);
			break;
		case 1:
			Perm2(buf);
			break;
		case 2:
			Perm3(buf);
			break;
		}
	}
}

template<typename T>
static void MixUser(T &buf, char const *in)
{
	for(auto *i = in; *i; ++i)
		Permute(buf, *i % 9U);

	int x = 0;
	for(auto *i = in; *i; ++i)
	{
		auto const c = *i;
		x = (x + x * c) ^ (c * c);
		Permute(buf, x % 9U);
	}
}

template<typename T>
static void MixSerial(T &buf, char const *in)
{
	for(auto *i = in; *i; ++i)
	{
		auto const c = *i - 'A';
		Permute(buf, c);
	}
}

class CubeCipher
{
	u32 mCounter;
	u32 mKeyIndex;
	u32 mArray512[512];
	u32 mArray256[256];
	u32  mArray16[ 16];

	u32 mKeyBuffer[4096];

	int mShaIdx;
	u32 ShaKey[5];
	u32 ShaBuffer[5];
	u32 ShaWorkspace[16];

	template<typename T>
	void SetKey(T const& buf)
	{
		for(size_t i = 0; i < 5; ++i)
			ShaKey[i] = ByteSwap(reinterpret_cast<const u32 *>(buf)[i]);
		fill(begin(ShaWorkspace), end(ShaWorkspace), 0);
	}

	u32 ShaIterate(const u32 n)
	{
		if( n/5 != mShaIdx )
		{
			copy(begin(ShaKey), end(ShaKey), begin(ShaBuffer));
			ShaWorkspace[0] = mShaIdx = n / 5;
			Sha1Compress(ShaBuffer, ShaWorkspace);
		}
		return ShaBuffer[n % 5];
	}

	inline u32 At(const u32 d)
	{
		return mArray512[(d&0x7FC)>>2];
	}

	inline void Mix(u32 &w0, u32 &w1, u32 &w2, u32 &w3)
	{
		u32 s0, s1, s2, s3;
		s0 = At(w0) + w1;
		s3 = Rotr32(w0, 9);
		w1 = Rotr32(s0, 9);
		s1 = At(s0) + w2;
		w2 = Rotr32(s1, 9); 
		s2 = At(s1) + w3;
		w3 = Rotr32(s2, 9);
		w0 = At(s2) + s3;
	}

	inline void MixXor(u32 &w0, u32 &w1, u32 &w2, u32 &w3)
	{
		u32 t, s;

		t = w0&0x7FC;
		w0 = Rotr32(w0, 9);
		w1 = (At(t) + w1) ^ w0;
		s = w1&0x7FC;
		w1 = Rotr32(w1, 9);
		w2 = (At(s) ^ w2) + w1;
		t += w2&0x7FC;
		w2 = Rotr32(w2, 9);
		w3 = (At(t) + w3) ^ w2;
		s += w3&0x7FC;
		w3 = Rotr32(w3, 9);
		w0 = (At(s) ^ w0) + w3;
		t += w0&0x7FC;
		w0 = Rotr32(w0, 9);
		w1 = (At(t) ^ w1);
		s += w1&0x7FC;
		w1 = Rotr32(w1, 9);
		w2 = At(s) + w2;
		t += w2&0x7FC;
		w2 = Rotr32(w2, 9);
		w3 = At(t) ^ w3;
		s += w3&0x7FC;
		w3 = Rotr32(w3, 9);
		w0 = At(s) + w0;
	}

	void FillKeyBuffer(const u32 Counter, u32 (&KeyBuffer)[4096])
	{
		u32 *BufferPtr = KeyBuffer;
		for(size_t i = 0; i < 4; ++i)
		{
			u32 w0 = mArray16[4*i + 0] ^ Rotr32(Counter,  0);
			u32 w1 = mArray16[4*i + 1] ^ Rotr32(Counter,  8);
			u32 w2 = mArray16[4*i + 2] ^ Rotr32(Counter, 16);
			u32 w3 = mArray16[4*i + 3] ^ Rotr32(Counter, 24);

			for(size_t j = 0; j < 2; ++j)
				Mix(w0, w1, w2, w3);

			u32 u3 = w3;
			u32 u2 = w2;
			u32 u1 = w1;
			u32 u0 = w0;
			
			Mix(w0, w1, w2, w3);

			for(size_t k = 0; k < 64; ++k)
			{
				MixXor(w0, w1, w2, w3);
				BufferPtr[0] = ByteSwap(mArray256[4*k + 0] + w1);
				BufferPtr[1] = ByteSwap(mArray256[4*k + 1] ^ w2);
				BufferPtr[2] = ByteSwap(mArray256[4*k + 2] + w3);
				BufferPtr[3] = ByteSwap(mArray256[4*k + 3] ^ w0);
				BufferPtr += 4;
				if(k&1)
				{
					w0 = u0 + w0;
					w1 = u2 + w1;
					w2 = u0 ^ w2;
					w3 = u2 ^ w3;
				}
				else
				{
					w0 = u3 + w0;
					w1 = u1 + w1;
					w2 = u3 ^ w2;
					w3 = u1 ^ w3;
				}
			}
		}
	}

	static inline void XorBuffer(u8 *out, const u8 *in, const u8 *KeyBuffer, const size_t n)
	{
		for(size_t i = 0; i < n; ++i)
			out[i] = in[i] ^ KeyBuffer[i];
	}

	inline void Regenerate()
	{
		mKeyIndex = 0;
		mCounter += 1;
		FillKeyBuffer(mCounter, mKeyBuffer);
	}

public:

	template<typename T>
	CubeCipher(T const& buf) : mShaIdx(-1), mCounter(0), mKeyIndex(0)
	{
		SetKey(buf);

		for(size_t i = 0; i < 512; ++i)
			mArray512[i] = ShaIterate(i);
		for(size_t i = 0; i < 256; ++i)
			mArray256[i] = ShaIterate(i + 4096);
		for(size_t i = 0; i < 16; ++i)
			mArray16[i] = ShaIterate(i + 8192);

		FillKeyBuffer(mCounter, mKeyBuffer);
	}

	void Crypt(u8 *out, const u8 *in, size_t n)
	{
		while( n >= 4096 - mKeyIndex )
		{
			XorBuffer(out, in, reinterpret_cast<const u8 *>(mKeyBuffer) + mKeyIndex, 4096 - mKeyIndex);
			out += 4096 - mKeyIndex;
			in += 4096 - mKeyIndex;
			n  -= 4096 - mKeyIndex;
			Regenerate();
		}
		XorBuffer(out, in, reinterpret_cast<const u8 *>(mKeyBuffer) + mKeyIndex, n);
		mKeyIndex += n;
	}

	~CubeCipher() {}
};



static bool SanityCheck()
{
	const u8 Sanity[16] = 
	{
		0xF5, 0x37, 0x69, 0x85, 0xA4, 0x3A, 0xAE, 0x6B,
		0x4F, 0x88, 0xA0, 0xE3, 0x87, 0xEA, 0x55, 0xB9
	};
	u8 Digest[16];
	u8 KeySeed[] = "0WGWb0rWbGGbbYW0rYrYrY0G";
	auto m = unique_ptr<u8[]>(new u8[ArraySize(ImageFile)]);

	MixUser(KeySeed, "Dcoder");
	MixSerial(KeySeed, "ABCDEFGH");
	CubeCipher CC(KeySeed);
	CC.Crypt(m.get(), ImageFile, ArraySize(ImageFile));
	Md5(Digest, m.get(), ArraySize(ImageFile));

	return equal(begin(Sanity), end(Sanity), begin(Digest));
}

static inline bool IsValidBmp(const u8 *bmp)
{
	return bmp[0] == 0x42 && // 'B'
	       bmp[1] == 0x4d && // 'M'
	       bmp[2] == 0xc6 && // Size[0]
	       bmp[3] == 0x71 && // Size[1]
	       bmp[4] == 0x03 && // Size[2]
	       bmp[5] == 0x00;   // Size[3]
}


static string Bruteforce()
{
	const u8 Target[16] = 
	{
		0x13, 0x4F, 0x0B, 0x02, 0xAD, 0xBA, 0xD5, 0xB7,
		0x0D, 0x78, 0xE8, 0x85, 0xBE, 0xDB, 0x44, 0xEC
	};

	char KeySeed[] = "0WGWb0rWbGGbbYW0rYrYrY0G";
	u8 Buffer[16] = {0};

	for(;;)
	{
		CubeCipher CC(KeySeed);
		CC.Crypt(Buffer, ImageFile, 16);

		if( IsValidBmp( Buffer ) )
			return string(KeySeed);

		Permute(KeySeed, rand()%3);
	}
}

void DecryptImage()
{
	u8 KeySeed[] = "WWWWrrrrGGGGbbbbYYYY0000";
	auto m = unique_ptr<u8[]>(new u8[ArraySize(ImageFile)]);

	CubeCipher CC(KeySeed);
	CC.Crypt(m.get(), ImageFile, ArraySize(ImageFile));

	ofstream fd("image.bmp", ios_base::binary | ios_base::out);
	fd.write(reinterpret_cast<const char *>(m.get()), ArraySize(ImageFile));
	fd.close();
}


template<size_t /*Precomputed*/N>
class Solver
{
public:
	typedef array<u8, 11> solution_type;
	typedef array<u8, 24> problem_type;
	typedef map<problem_type, solution_type> map_type;
private:
	problem_type mStart;
	static const problem_type mTarget;
	static const map_type mPreTable;


	static problem_type InitTarget()
	{
		const char Target[] = "WWWWrrrrGGGGbbbbYYYY0000";
		problem_type p;
		copy(Target, Target+24, begin(p));
		return p;
	}

	static inline problem_type Eval(const problem_type &e, const solution_type &s, const size_t n)
	{
		problem_type p = e;
		for(size_t i = 0; i < n; ++i)
		{
			auto const v = s[i];
			Permute(p, v);
		}
		return p;
	}

	bool IsFinished(const solution_type &s, const size_t n)
	{
		problem_type p = Eval(mStart, s, n);
		return equal(begin(p), end(p), begin(mTarget));
	}

	static inline void Increment(solution_type &s, const size_t n)
	{
		unsigned cy = 1;
		for(size_t i = 0; i < n; ++i)
		{
			auto v = s[i];
			v += cy;
			if(v >= 9)
			{
				v -= 9;
				cy = 1;
			}
			else cy = 0;
			s[i] = v;
		}
	}

	static inline u64 Pow(const u64 b, const u64 e) 
	{
		u64 n = 1;
		for(u64 i = 0; i < e; ++i)
			n *= b;
		return n;
	}

	/*
	size_t Search(solution_type &s)
	{
		for(size_t len = 0; len < 11; ++len) 
		{
			const u64 n = Pow(9, len);
			s.fill(0);
			for(u64 i = 0; i < n; ++i)
			{
				if( IsFinished(s, len) )
					return len;
				Increment(s, len);
			}
		}
		throw runtime_error("I was sure there was a solution here somewhere...");
	}
	*/

	size_t Search(solution_type &s)
	{
		for(size_t len = 0; len < 11; ++len) 
		{
			const u64 n = Pow(9, len);
			s.fill(0);
			for(u64 i = 0; i < n; ++i)
			{
				if( IsFinished(s, len) )
					return len;
				if( mPreTable.count(Eval(mStart, s, len)) > 0 )
				{
					auto const &sol = mPreTable.at(Eval(mStart, s, len));
			
					for(size_t k = 0; k < N; ++k)
						s[k+len] = sol[k];

					if( !IsFinished(s, N+len) || (len + N) > 11 )
						throw runtime_error("Weird stuff going on");

					return len + N;
				}
				Increment(s, len);
			}
		}
		throw runtime_error("I was sure there was a solution here somewhere...");
	}

	static inline u8 Invert(u8 m) 
	{
		switch(m)
		{
		case 0:
			return 6;
		case 1:
			return 7;
		case 2:
			return 8;
		case 6:
			return 0;
		case 7:
			return 1;
		case 8:
			return 2;
		default:
			return m;
		}
	}

	static inline solution_type InvertSolution(const solution_type &s, const size_t n)
	{
		solution_type t; t.fill(0);
		for(size_t i = 0; i < n; ++i)
			t[i] = Invert(s[n-i-1]);
		return t;
	}

	static map_type Precompute()
	{
		const size_t n = Pow(9, N);
		solution_type s; s.fill(0);
		map_type m;

		for(size_t i = 0; i < n; ++i)
		{
			problem_type p = Eval(mTarget, s, N);
			solution_type s_ = InvertSolution(s, N);

			m.insert(make_pair(p, s_));

			Increment(s, N);
		}

		return m;
	}

public:
	
	Solver(const char *start)
	{
		copy(start, start + 24, begin(mStart));
	}

	string operator()()
	{
		try
		{
			string sn;
			solution_type s;
			size_t n = Search(s);
			for(size_t i = 0; i < n; ++i)
				sn += s[i] + 'A';
			return sn;
		}
		catch(exception &e)
		{
			return string(e.what());
		}
	}

	~Solver(){}
};

template<size_t N> const typename Solver<N>::problem_type Solver<N>::mTarget = Solver<N>::InitTarget();
template<size_t N> const typename Solver<N>::map_type Solver<N>::mPreTable = Solver<N>::Precompute();

static string Generate(const string &Name)
{
	char KeySeed[]  = "0WGWb0rWbGGbbYW0rYrYrY0G";

	MixUser(KeySeed, Name.c_str());
	Solver<5> solve(KeySeed);

	return solve();
}

int main(int argc, char **argv)
{
	//SanityCheck();
	//cout << Bruteforce() << endl;
	//DecryptImage();
	
	string name;
	cout << "Name: ";
	getline(cin, name);
	cout << "Code: " << Generate(name) << endl;

	return 0;
}

