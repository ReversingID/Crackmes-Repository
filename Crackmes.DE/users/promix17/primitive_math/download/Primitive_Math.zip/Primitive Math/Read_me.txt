Primitive Math v1.0
Written by Promix17

Level of dufficulty: 5

This is quite difficult CrackME: you should be not only good cracker - you should
know some math yet... But don't worry about last at the beginning - find, reverse
and understand protection code first :-) I hope you will like this CrackME. Don't
give up!!! It's a really solvable and keygenable CrackME.

And of cause the purpose is to make a keygen. Good luck!

Send me your solutions, questions, comments and offers. 

E-mail: promix17@yandex.ru
 