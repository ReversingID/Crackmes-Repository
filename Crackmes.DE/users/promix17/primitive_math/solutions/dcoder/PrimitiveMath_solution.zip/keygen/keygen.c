
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int crc1(char *str, int len)
{
  int i,h;
  for(i=0,h=0; i < len; ++i)
    h += str[i];
  return h%20+'A';
}

int crc2(char *str, int len)
{
  int i,h;
  for(i=0,h=0; i < len; ++i)
    h += str[i] ^ i;
  return h%10;
}

int main(int argc, char **argv)
{
  char serial[16] = {0};
  int i, h ;
  
  if(argc != 2)
  {
    printf("Usage: %s <username>\n", argv[0]);
    return -1;
  }
  
  sprintf(serial, "12DXWXSPG%dA", crc2(argv[1], strlen(argv[1])));
  printf("%c%c%s\n", crc1(argv[1], strlen(argv[1])), crc1(serial, strlen(serial)), serial);

  return 0;
}


