# Primitive Math v1.0
# by Promix17
#
# This crackme has two sorts of protection in itself, but i must say that the griefest part was
# the amount of bugs and errors this crackme spat upon entering wrong serial. for a brief intro-
# duction, I will say that this crackme is also annoying and do not test run it if you have IDA
# or olly running in background. Short after loading the little bugger into the debugger, we no-
# ice that it's crypted. After decryption we find out that main program unpacks and executes
# two additional files. First one is the core of the crackme, and we will take a look at this
# shortly. It's also crypted, like most of the important procedures here. The biggest problem is
# that during serial check, some of the decrypting code relies on the checksum of the code, but
# the decrypted code is then crypted with WRONG key, thus render it unusable for the second time.
# It's quite annoying when you have to run your crackme from the start EVERY time you want to 
# check another serial. Second one is kept in temp and is called svchost.exe. I guess author 
# wanted to make it less obvious for a random user that additional process is running. To me it 
# looked more like a malware type of stealthy behaviour that i do not like, at all. On top of 
# that the additional process runs indefinetaly, so every time you launch keygenme this additional
# process is spawned, but never killed. Thus soon, if you're not careful enough you can have shit
# loads of those processess running free on your system. The simplies way to circuvement this is
# to open a dummy process (that does absolutely nothing) in olly or smth, so that the file cannot
# be overwritten but it doesn't linger in our system.
#
# Well, that part is behind us. Now let's get to the core. As i mentioned before most vital parts
# of the crackme are crypted. But the WinMain isn't (except small fragments). We can easily find
# it. After we enter the serial, it checks if our name is at least 6 characters long and if our
# serial is exactly 13 characters long, after that it checks first, second and one before last
# character. First two characters are rather obvious, algorithms are very simple and not worth
# mentioning. The one before last, however, is more tricky. Directly in code we see it picks a
# random value, divides it and gets a value from an array. The real point is that this array is
# created in normal window proc. It works basically the same as previous one, with the exception
# that it xor'es the value of a character with the counter before it's added to the sum.
#
# That part is rather simple, where it gets tricky, is slightly further. You can get there by put-
# ting hardware breakpoints on some memory areas. You'll notice that code is caught later on.
# There we have the main protection, which is basically a simple VM (with a stack) and few equations.
# The entire VM is pretty simple, if you wish, you can have a look at vm.txt file which contains
# a C-like pseudocode of the VM with (hopefully) enough explanation on what it does. Here i would
# like to thank Dcoder for helping me out with cosh and sinh functions, without his help I'd be 
# prolly stuck there for months. Having all of the instructions, we notice that the entire checking
# routine consists of comparing two functions. Let's assume:
#
# f(x) - function that is interpreted by VM, we supply this one
# g(x) - constant function that is compared against what we've supplied
# a - constant value equal to 10^-7
# n - an iterator
#
# Comparing process lasts 10 rounds, for iterator starting at 0 and ending at 9. During one loop 
# we see that firstly crackme computes a value:
#
# (f(n+a) - f(n-a)) / 2a = F(x)
# 
# Then it computes g(n), FYI g(x) looks like this:
#
# (sqrt(x)*cos(x) + 0.5*sin(x)/sqrt(x))*cosh(sqrt(x)*sin(x))
#
# Then the results of both are subtracted from each other and checked if the result of that sub
# is "insignificant". We can easily assume, that author ment the results be identical, but due 
# to error margin, he had to assume some safe margin that would be acceptable.
# 
# This comparison exists for every iteration of this function, so for them to be equal, we have to
# figure out what function should we supply to the VM. My first thought was to compute polynomial
# interpolation. After all, we have only 10 points on which those functions must be equal. But that
# idea failed before even I started to calculate some stuff. I realised that we will be limited by
# the length of the input. So I had to find out another way. Anyone with half a brain and high 
# school diploma(i assume that you have basic calculus in high school, why wouldn't you!?), noticed
# that first equation is generally a derivative (Newton's difference quotient). So in order for 
# g(x) and F(x) be equal, F'(x) = g(x) must occur. This can be simply achieved by computing infinitive
# integral of g(x). Now, this is more tricky part, and in most cases you'd need at least knowledge 
# from Calculus 1 that you get on your uni. Sadly enough, i had it ages ago. Therefore I've used 
# 3rd party tools (namely SAGE) to calculate this integral. The result of that integral is much 
# better than the polynomial, we get:
#
# f(x) = sinh(sqrt(x)*sin(x))
#
# Those are the commands I supplied:
# 
# g=1/2*(2*sqrt(x)*cos(x) + sin(x)/sqrt(x))*cosh(sqrt(x)*sin(x))
# g.Integral(x)
#
# As you can see it, it's much much shorter than any polynomial that we would've created.
#
# There's also one thing, that i haven't mentioned earlier. There are two checks made on our serial
# prior to executing. The code adds up number of letters A,P,X and then calculates:
#
# (A+P+X)^2 - this value is saved and then used to decrypt code somewhere else. The way to find out what
#             number can it be, is rather simple. You look at the ciphered code, instantly you notice 
#             number of 10h one after another, by simple trial and error you try to use 10h as a key
#             so as a result you will have 0 in that spot. If that wouldn't work, we can grab next
#             square root and try then. There are only 15 different values that can be used, so in
#             worst case scenario, you would have to check this 15 times.
# The other equation that is checked, is:
# 6*X == 1 (mod 11)
# this can be easily solved, and as a result we have:
# X = 11n + 2
# Where n is a natural number, since our serial cannot be longer than 13 characters, we have to assume
# that n = 0, and therefore we have 2 letters X in our serial, combined with previous one, we have
# either:
# 2 letters A and none P
# 1 letter A and 1 P
# No letters A and 2 P
#
# With that in mind, we can construct most of our serial
#
# First we will need to compute square root of our number, therefore code:
# 12D 
# |||
# ||--- divides 1 by 2
# |---- pushes 2
# ----- pushes 1
# Now we have to push our variable and power it:
# 12DXW
#    ||
#    |--- exponentiates variable to 0.5 power
#    ---- pushes the variable
#
# Ok, so we have on stack sqrt(x), we need to compute sin(x), in order to do that we need to push
# variable and then compute sin on it, so:
# 12DXWXS
#      ||
#      |--- compute sine
#      ---- push variable
#
# So we have in our stack sqrt(x) and sin(x), now we need to multiply it and then compute hyperbolic
# sine from the result.
#
# 12DXWXSPG
#        ||
#        |--- sinh(stack)
#        ---- multiplies stack values
#
# Great! We have our function, and the length fits perfectly! There is a small problem though. As you
# might remember first two characters and one before last are name dependant (second is serial dependant,
# but that in turn is name dependant, so ...). Let's assume that instead of unknown characters in our 
# serial I'll put question mark characters. In that case, our current pattern looks like this:
#
# ??12DXWXSPG??
#
# We have 1 P, and no A, we need to fit in somewhere additional P or A and not fuck up what we've built
# so far. Thankfully, the way integrals are calculated, we can add aditional constant value to the result
# and after differentiating this constant will be irrelevant.
# This is great!
# So if we push some random number on one before last position (we know it's a number from previous checks)
# our serial is:
# ??12DXWXSPG?A
# What is left to do, is to fill in those question marks with appropiate values, which is very simple. Below
# you have my sample keygen code in python, and sample pairs are:
#
# tamaroth
# ER12DXWXSPG0A
#
# crackmes.de
# IE12DXWXSPG7A
#
# Finally, after that there is one last check/computation. What it does is basically check if the equation
# we've entered is indeed the sinh one, otherwise the table that is created will not decipher "good boy"
# code and will crash.
#
# Overwall the idea for crackme was quite fun and interesting, the way it was done, however, was rather 
# poor and buggy. Had it been properlly written it would've been much more fun. But this was frustrating
# more often than usual due to hideous anti-tricks, i would've understood killing crackme process or modyfying
# some crucial values, but disabling tools of our trade was just plain annoying.
# Anyway, hopefully promix will release next crackme that will be less buggy.
#
# tamaroth/tamaroth.eu
#

import os, sys, re
usage = "usage: %s name" %         os.path.basename(sys.argv[0])

def secondC(ch):
    s = 0
    i = 0
    for i in range(0,len(ch)):
        s = s + ord(ch[i])
    return chr((s%0x14)+0x41)
	
def firstC(ch):
    s = 0
    i = 0
    for i in range(0,len(ch)):
        s = s + (ord(ch[i]) ^ i)
    return chr((s%10)+0x30)

if len(sys.argv) != 2:
    print usage
else:
    ss = sys.argv[1]
    if len(ss) < 6:
        print "name must be at least 6 characters long..."
        exit()
    output = sys.stdout
    a = firstC(ss)
    sr = "12DXWXSPG" + a + "A"
    f = secondC(sr)
    e = secondC(ss)
    print e + f + sr
