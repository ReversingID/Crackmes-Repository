DKeygenMe
~~~~~~~~~
Objective: 
:Create a keygen.
:No patching
Contents:
:No packers
:No protectors
:Multi-threaded
Language:
:D
Difficulty:
:4 - Needs special knowledge

~~~~~~~~~~~~
cryptcat
~~~~~~~~~~~~