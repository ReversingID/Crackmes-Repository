#include <stdio.h>
#include <windows.h>

int main()
{
	unsigned int arr[54];//54 dwords
	char name[19];//len = 18
	char password[145];//max 8*18 chars +1 null
	password[0]=0;//empty string

	printf("Give a name: ");
	char input[25];
	scanf("%24s",input);//get string from stdin
	int inputLen=strnlen_s(input,25);//get len
	if (inputLen<18)//if less then 18 copy the input data until the len is 18
	{
		strncpy_s(name,input,inputLen);
		int lenNome=strnlen_s(name,19);
		do 
		{
			if (inputLen< 18-lenNome)
				strncat_s(name,input,inputLen);
			else
				strncat_s(name,input,18-lenNome);
			lenNome=strnlen_s(name,19);
		} while (lenNome<18);
		printf("Name was short, now is: %s\n",name);
	}
	else
	{
		strncpy_s(name,input,18);//no need to cut as only first 18 chars are used
		if (inputLen!=18)
			printf("Name long, max 18 chars, now is: %s\n",name);
	}

	int pathLen;
	printf(	"\nGive the command line length (or its string)\n"
			"If you double click on exe it should be the path and program name (C:\\something\\keygen.exe)\n"
			"If you run from cmd it should be the program name only (keygen.exe)\n"
			"input: ");
	int ret=scanf("%d",&pathLen);//length is used so get it
	if (ret==0)//if not integer
	{
		char path[256];
		scanf("%255s",path);
		pathLen=strnlen_s(path,256);//get as string and find its length
	}

	//1- create array
	int arrayIndex=0;
	int nameIndex=0;
	for (int j=0; j<3; j++)
	{
		for (int i=0; i<6; i++)
		{
			arr[arrayIndex]=(unsigned int)name[nameIndex];//name chars
			arr[arrayIndex+1]=j+1;//1,2,3
			arr[arrayIndex+2]=((nameIndex)%6)+1;//between 1 and 6
			arrayIndex+=3;//fill like a struct
			nameIndex++;
		}
	}
	/*
	Array:
	first char (all as integer)
	1
	1
	second char
	1
	2
	third char
	1
	3
	...
	*/

	//2- xor array
	arrayIndex=0;
	for (int i=0; i<18; i++)
	{
		arr[arrayIndex] = 2 * (arr[arrayIndex] ^ (arr[arrayIndex+2] + 3 + pathLen));
		arr[arrayIndex] = 2 * (arr[arrayIndex] ^ (arr[arrayIndex+1] + 3 + pathLen));
		arrayIndex+=3;
	}

	//3- make pw
	for (int i=0; i<18; i++)
	{
		char pwPart[8];
		sprintf_s(pwPart,"%x", arr[3*i]);//hex to string
		strncat_s(password,pwPart,8);
	}

	printf("\nPassword is: %s\n",password);
	system("PAUSE");
	return 0;
}