//thought it was packed with upx, but not.........

#include <windows.h>
#include <stdio.h>
#include <string.h>

int adjust(int c)
{	return (c%5);
}

int checkit(char *string1)
{	int l,t,r;
	l=0;
	t=0x8991b;
   l=l+2;
   while(l<=strlen(string1))
   {  t=((int)(adjust(string1[l-1]))*982367)^t;
   	l=l+2;
   }
   t=t^0x8991b;
   return t;
}

void main(int argc, char *argv[])
{	char str1[10];
	int i,u,j,r;
	printf("Keygen for GenoCide crackme 10 by Cronos\n");
	printf("Usage: keygen name (name>4 chars)\n");
	if(argc<2) return;
   strcpy(str1,argv[1]);
   strupr(str1);
   j=checkit(str1);
   r=0x01460;
   printf("Name: %s Serial:%lu Unlock Code:%05lu\n",str1,j,r);
}