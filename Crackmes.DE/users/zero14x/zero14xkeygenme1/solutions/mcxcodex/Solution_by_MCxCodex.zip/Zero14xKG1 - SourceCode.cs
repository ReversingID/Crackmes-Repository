private void btnGenerate_Click(object sender, EventArgs e)
{
  string sInput = txtName.Text;
  char[] cInput = sInput.ToCharArray();
  string sResult = "";  
  int iMultiply = 0, iLen = txtName.Text.Length * 100;
 
  if (iLen < 3)
    txtSerial.Text = "Name must be >= 3 chars";
  else {
        
    iMultiply = iLen * cInput[0] * cInput[1] * cInput[2];

    sResult = Convert.ToString(Convert.ToChar(cInput[2] - 10)) + Convert.ToString(Convert.ToChar(cInput[1] - 5)) +
              Convert.ToString(Convert.ToChar(cInput[0] - 1)) + Convert.ToString(iMultiply);

    txtSerial.Text = sResult + "-" + sInput;
  }      
}