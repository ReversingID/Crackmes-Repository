#include <IOSTREAM>
#include <strings.h>
using namespace std;

int main()
{
        char login[100], pass[105];
        int temp;
        printf("Enter login: ");
        cin >> login;
        if (strlen(login)>3)
        {
                pass[0] = login[2] - 10;
                pass[1] = login[1] - 5;
                pass[2] = login[0] - 1;
                pass[3] = '\0';
                temp = login[0] * login[1] * login[2] * 100 * strlen(login);
                printf("%s%d-%s",pass,temp,login);
        }
        else
                printf("\nLogin must been greater or equal 3\n");
        cin >> login;
        return 0;   
}
