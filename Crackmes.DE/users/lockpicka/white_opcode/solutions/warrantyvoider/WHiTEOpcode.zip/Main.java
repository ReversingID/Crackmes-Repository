import java.util.zip.CRC32;

public class Main {
	static String b = "C03N5C7111AB81EF1000";


    public static void check(String s)
    {
	    if (s.length()<3) return;
        int k;
        int l;
        char ac[] = s.toCharArray();
        char ac1[] = s.toCharArray();
        char ac2[] = b.toCharArray();
        int i = s.length();
        ac1[i - 3] = '\0';
        char c1 = ac[i - 3];
        int j = 0xab779c;
        k = 0xf2b219ad;
        l = (l = 0xf2b21a66) ^ 0x2a4db9fe;
        if(Float.compare(i % 4, 0.0F) != 0)
            k = 45125;
        char c2 = ac[i - 1];
        char c3 = ac[i - 1];
        c2 &= '\377';
        c3 = (char)((c3 = (char)((c3 = (char)((c3 = (char)((c3 &= '\017') * (i / 4))) * (c2 >> 4))) << 2)) & 0xf);
        if((c3 = ac2[c3]--) == c2)
        {
            if(i != 8)
                k = j + 1;
        } else
        {
            k = j;
        }
        if(crc(ac1) != -2119)
            k ^= 0x323ffcd4;
        if(c1 != '1')
            k -= 0x58c50334;
        l ^= 0x2a4db9fe;
        l += 69;
        l -= 254;
        if(k == l){
	        System.out.println("\n***********************************************\nCorrect!: "+s+"\n********************************************");
        }
    }

    public static short crc(char ac[])
    {
        CRC32 crc32 = new CRC32();
        for(int i = 0; i < ac.length; i++)
            crc32.update(ac[i]);

        return (short)(int)crc32.getValue();
    }


	public static void main(String[] args) {
		Thread.currentThread().setPriority(java.lang.Thread.MIN_PRIORITY);
		for (long ii=0;;ii++)check(String.format("%08x",ii));
	}
}
