import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.zip.CRC32;
import javax.swing.*;

public class WHiTE
{

    public WHiTE()
    {
    }

    private static void a(String s, String s1)
    {
        JFrame jframe = new JFrame(s);
        JFrame.setDefaultLookAndFeelDecorated(true);
        SpringLayout springlayout = new SpringLayout();
        Container container;
        (container = jframe.getContentPane()).setLayout(springlayout);
        jframe.setResizable(false);
        Toolkit toolkit;
        Dimension dimension = (toolkit = Toolkit.getDefaultToolkit()).getScreenSize();
        jframe.setLocation(dimension.width / 2 - 100, dimension.height / 2 - 60);
        JLabel jlabel = new JLabel(s1);
        container.add(jlabel);
        int i = s1.length();
        springlayout.putConstraint("West", jlabel, i * 2, "West", container);
        springlayout.putConstraint("North", jlabel, i * 2, "North", container);
        springlayout.putConstraint("East", container, i * 2, "East", jlabel);
        springlayout.putConstraint("South", container, i * 2, "South", jlabel);
        jframe.pack();
        jframe.setVisible(true);
    }

    public static void a(String s)
    {
        int k;
        int l;
        char ac[] = s.toCharArray();
        char ac1[] = s.toCharArray();
        char ac2[] = b.toCharArray();
        int i = s.length();
        ac1[i - 3] = '\0';
        char c1 = ac[i - 3];
        int j = 0xab779c;
        k = 0xf2b219ad;
        l = (l = 0xf2b21a66) ^ 0x2a4db9fe;
        float f;
        if(Float.compare(f = i % 4, 0.0F) != 0)
            k = 45125;
        char c2 = ac[i - 1];
        char c3 = ac[i - 1];
        c2 &= '\377';
        c3 = (char)((c3 = (char)((c3 = (char)((c3 = (char)((c3 &= '\017') * (i / 4))) * (c2 >> 4))) << 2)) & 0xf);
        if((c3 = ac2[c3]--) == c2)
        {
            if(i != 8)
                k = j + 1;
        } else
        {
            k = j;
        }
        if(a(ac1) != -2119)
            k ^= 0x323ffcd4;
        if(c1 != '1')
            k -= 0x58c50334;
        l ^= 0x2a4db9fe;
        l += 69;
        l -= 254;
        if(k != l) goto _L2; else goto _L1
_L1:
        "Excellent";
        "Correct Serial";
          goto _L3
_L2:
        "Error";
        "Incorrect Serial";
_L3:
        a();
    }

    public static short a(char ac[])
    {
        CRC32 crc32 = new CRC32();
        for(int i = 0; i < ac.length; i++)
            crc32.update(ac[i]);

        return (short)(int)crc32.getValue();
    }

    public static void a()
    {
        JFrame.setDefaultLookAndFeelDecorated(true);
        JFrame jframe;
        (jframe = new JFrame("WHiTE OPCoDE")).setDefaultCloseOperation(3);
        jframe.setResizable(false);
        Toolkit toolkit;
        Dimension dimension = (toolkit = Toolkit.getDefaultToolkit()).getScreenSize();
        jframe.setLocation(dimension.width / 2 - 100, dimension.height / 2 - 60);
        SpringLayout springlayout = new SpringLayout();
        Container container;
        (container = jframe.getContentPane()).setLayout(springlayout);
        a = new JTextField("Serial", 20);
        container.add(a);
        JButton jbutton;
        (jbutton = new JButton("Check it!")).setPreferredSize(new Dimension(100, 25));
        container.add(jbutton);
        JButton jbutton1;
        (jbutton1 = new JButton("Quit")).setPreferredSize(new Dimension(100, 25));
        container.add(jbutton1);
        jbutton.addActionListener(new b());
        jbutton1.addActionListener(new a());
        springlayout.putConstraint("West", a, 5, "West", container);
        springlayout.putConstraint("North", a, 5, "North", container);
        springlayout.putConstraint("West", jbutton1, 0, "West", a);
        springlayout.putConstraint("North", jbutton1, 25, "North", a);
        springlayout.putConstraint("North", jbutton, 25, "North", a);
        springlayout.putConstraint("East", jbutton, 0, "East", a);
        springlayout.putConstraint("East", container, 5, "East", a);
        springlayout.putConstraint("South", container, 5, "South", jbutton1);
        jframe.pack();
        jframe.setVisible(true);
    }

    public static void main(String args[])
    {
        Runtime.getRuntime().traceMethodCalls(false);
        Runtime.getRuntime().traceInstructions(false);
        SwingUtilities.invokeLater(new c());
    }

    protected static JTextField a;
    static String b = "C03N5C7111AB81EF1000";


    // Unreferenced inner class b
    static class b
        implements ActionListener
    {

        public final void actionPerformed(ActionEvent actionevent)
        {
            WHiTE.a(WHiTE.a.getText());
        }

            b()
            {
            }
    }


    // Unreferenced inner class a
    static class a
        implements ActionListener
    {

        public final void actionPerformed(ActionEvent actionevent)
        {
            System.exit(0);
        }

            a()
            {
            }
    }


    // Unreferenced inner class c
    static class c
        implements Runnable
    {

        public final void run()
        {
            WHiTE.a();
        }

            c()
            {
            }
    }

}
