import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JTextField;

final class b
    implements ActionListener
{

    b()
    {
    }

    public final void actionPerformed(ActionEvent actionevent)
    {
        WHiTE.a(WHiTE.a.getText());
    }
}
