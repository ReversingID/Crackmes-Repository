final class c
    implements Runnable
{

    c()
    {
    }

    public final void run()
    {
        WHiTE.a();
    }
}
