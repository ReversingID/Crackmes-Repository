import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

final class a
    implements ActionListener
{

    a()
    {
    }

    public final void actionPerformed(ActionEvent actionevent)
    {
        System.exit(0);
    }
}
