import java.util.Random;
import java.util.zip.CRC32;
import javax.swing.JTextField;

public class Main {
	public static void main(String[] args) {
		new Fenster(keygen());			// Fenster means window in german ^^
	}

	public Main() {
	}

	protected static JTextField a;
	static String b = "C03N5C7111AB81EF1000";

	// this is the original checksum method from the WHiTE code
	public static short a(char ac[]) {
		CRC32 crc32 = new CRC32();
		for(int i = 0; i < ac.length; i++)	// creating checksum
			crc32.update(ac[i]);
		return (short)(int)crc32.getValue();	// cast checksum to short int
	}

	// i think i dont need to comment this method,
	// the description of the serial-pattern is at my tutorial
	// and this method only follows the rules and uses numbers and capitals
	public static String keygen() {
		int tmp;
		char tmp_char = 'A';
		char key[];
		char backup;
		do{
			String str = "";
			for(int count = 0; count < 8; count++) {
				Random rand = new Random();

				if(rand.nextInt(2) == 0)
					tmp = rand.nextInt(10);
				else {
					tmp = rand.nextInt(26);
					tmp += 65;
					tmp_char = (char)tmp;
					tmp = -1;
				}

				if(count == 5)
					str += 1;
				else if(count == 7)
					str += 'C';
				else {
					if(tmp == -1)
						str += tmp_char;
					else
						str += tmp;
				}
			}
			key = str.toCharArray();
			backup = key[key.length - 3];
			key[key.length - 3] = '\0';
		} while(a(key) != -2119);
		key[key.length - 3] = backup;
		return String.valueOf(key);
	}

	/*
	public static void a(String s) {	// String s is the input of the user
		char ac[] = s.toCharArray();	// cast input to char-array
		char ac1[] = s.toCharArray();	// cast input to char-array
		char ac2[] = b.toCharArray();	// cast key to char-array

		int i = s.length();		// int i is the length of the input

		ac1[i - 3] = '\0';		// the third last char will be overwritten by '\0' at ac1

		char c1 = ac[i - 3];		// char c1 is a backup of the overwritten char
		char c2 = ac[i - 1];		// char c2 is the last char of the input
		char c3 = ac[i - 1];		// char c3 is the last char of the input

		c2 &= '\377';			// the char '\377' will be assigned to c2

		c3 &= '\017';			// c3 modify start
		c3 *= (char)(i / 4);
		c3 *= (c2 >> 4);
		c3 <<= 2;
		c3 &= 0xf;			// c3 modify end

		int k = 0xf2b219ad;		// this is the k value we need at the end

		if(Float.compare(i % 4, 0.0F) != 0)		// if int i isnt divisible by 4
			k = 45125;				// then overwrite k

		int j = 0xab779c;		// we never need int j
		if(ac2[c3] == c2)		// if the c3-index of the key (ac2) is equal to c2
		{
			if(i != 8)		// then, if the input-length isnt 8
				k = j + 1;	// then overwrite k
		}
		else
		{
			k = j;			// overwrite k
		}

		if(a(ac1) != -2119)		// if checksum isnt -2119
			k ^= 0x323ffcd4;	// then calculate (overwrite) k

		if(c1 != '1')			// if the third-last char of the input isnt 1
			k -= 0x58c50334;	// then calculate (overwrite) k

		int l;				// l is the second most important variable
		l = 0xf2b21a66 ^ 0x2a4db9fe;	// l calculation start
		l ^= 0x2a4db9fe;
		l += 69;
		l -= 254;			// l calculation end
		//we could omit the calculation and directly assign the right value to l, but its not necessary

		if(k == l)			// if k is equal to l ---> SUCCESS
			System.out.println("Valid");
		else
			System.out.println("Not Valid");
	}
	*/
}
