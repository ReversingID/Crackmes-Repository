import java.awt.BorderLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

// Fenster means window in german ^^
public class Fenster {

	protected JFrame window;
	protected JTextField text;

	public Fenster(String first_key) {
		int x = (Toolkit.getDefaultToolkit().getScreenSize().width / 2) - 100;
		int y = (Toolkit.getDefaultToolkit().getScreenSize().height / 2) - 50;
		
		window = new JFrame("WHiTE KeyGen");
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		text = new JTextField();
		text.setText(first_key);
		text.setHorizontalAlignment(JTextField.CENTER);
		text.setEditable(false);
		JButton button = new JButton("Generate Key");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				text.setText(Main.keygen());
			}
		});
		window.add(text, BorderLayout.NORTH);
		window.add(button, BorderLayout.SOUTH);
		window.setSize(300, 100);
		window.setLocation(x, y);
		window.setVisible( true );
	}
}
