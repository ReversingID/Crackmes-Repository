// SockDlg.h : header file
//

#if !defined(AFX_SOCKDLG_H__219F8F9A_2EA2_4C2D_BE9A_08540F537D51__INCLUDED_)
#define AFX_SOCKDLG_H__219F8F9A_2EA2_4C2D_BE9A_08540F537D51__INCLUDED_

#include "MySocket.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CSockDlg dialog

class CSockDlg : public CDialog
{
// Construction
public:
	void OnSend();
	void OnReceive();
	void OnClose();
	void OnConnect();
	void OnAccept();
	CSockDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CSockDlg)
	enum { IDD = IDD_SOCK_DIALOG };
	CListBox	m_ctlList1;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSockDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CSockDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	BOOL m_bConnected;
	CMySocket m_sConnectSocket;
	CMySocket m_sListenSocket;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SOCKDLG_H__219F8F9A_2EA2_4C2D_BE9A_08540F537D51__INCLUDED_)
