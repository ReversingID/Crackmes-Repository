// SockDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Sock.h"
#include "SockDlg.h"
#include "Base64.h"
#include <iostream>
#include <string>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSockDlg dialog

CSockDlg::CSockDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSockDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSockDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSockDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSockDlg)
	DDX_Control(pDX, IDC_LIST1, m_ctlList1);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSockDlg, CDialog)
	//{{AFX_MSG_MAP(CSockDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSockDlg message handlers

BOOL CSockDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	// Set the socket dialog pointers
	m_bConnected = false;
	m_sConnectSocket.SetParent(this);
	m_sListenSocket.SetParent(this);

	// Server, create a socket bound to the port specified
	m_sListenSocket.Create(22);
	// Listen for connection requests
	m_sListenSocket.Listen();


	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSockDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CSockDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSockDlg::OnAccept()
{
	// Check Connected Status
	if (m_bConnected)
	{
		// Create a rejection socket
		CAsyncSocket sRejectSock;
		// Create a message to send
		CString strMsg = "U2VydmVyIEJ1c3kh";
		// Accept using the rejection socket
		m_sListenSocket.Accept(sRejectSock);
		// Send the rejection message
		sRejectSock.Send(LPCTSTR(strMsg), strMsg.GetLength());
		// Close the socket
		sRejectSock.Close();
	}
	else
	{
		// Accept the connection request
		m_sListenSocket.Accept(m_sConnectSocket);
		m_bConnected = true;
		AfxMessageBox("Client Connected");
	}
}

void CSockDlg::OnConnect()
{
//	AfxMessageBox("Client Connected");
}

void CSockDlg::OnClose()
{
	m_sConnectSocket.Close();
	m_bConnected = false;
	AfxMessageBox("Client Disconnected");
}

void CSockDlg::OnReceive()
{
	char *pBuf = new char[1025];
	int iBufSize = 1024;
	int iRcvd = -1, iSent = -1, iLen = -1;
	CString strRecvd(""), strBase64("");

	// Receive the message
	iRcvd = m_sConnectSocket.Receive(pBuf, iBufSize);
	// Did we receive anything?
	if (iRcvd == SOCKET_ERROR)
	{
		AfxMessageBox("SOCKET_ERROR");
	}
	else
	{
		// Truncate the end of the message
		pBuf[iRcvd] = NULL;
		// Copy the message to a CString
		strRecvd = pBuf;
		// Add the message to the received list box
		m_ctlList1.AddString(strRecvd);
		// Sync the variables with the controls
		UpdateData(FALSE);

		//Base64 Encoding
		iLen = strRecvd.GetLength();
		std::string sBase64 = base64_encode((unsigned char *)(LPCSTR)strRecvd, iLen);
		strBase64 = (const char*)sBase64.c_str();

		iLen = strBase64.GetLength();
		// Send the message
		iSent = m_sConnectSocket.Send(LPCTSTR(strBase64), iLen);
		// Were we able to send it?
		if (iSent == SOCKET_ERROR)
		{
			AfxMessageBox("SOCKET_ERROR");
		}
		else
		{
			strBase64 = "KCH-" + strBase64;
			// Add the message to the list box.
			m_ctlList1.AddString(strBase64);
			// Sync the variables with the controls
			UpdateData(FALSE);
		}
	}
	delete pBuf;
}

void CSockDlg::OnSend()
{
//	AfxMessageBox("Message Sent");
}
