// Sock.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Sock.h"
#include "SockDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSockApp

BEGIN_MESSAGE_MAP(CSockApp, CWinApp)
	//{{AFX_MSG_MAP(CSockApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSockApp construction

CSockApp::CSockApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CSockApp object

CSockApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CSockApp initialization

BOOL CSockApp::InitInstance()
{
	if (!AfxSocketInit())
	{
		AfxMessageBox(IDP_SOCKETS_INIT_FAILED);
		return FALSE;
	}

	// Standard initialization

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	CSockDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
	}
	else if (nResponse == IDCANCEL)
	{
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
