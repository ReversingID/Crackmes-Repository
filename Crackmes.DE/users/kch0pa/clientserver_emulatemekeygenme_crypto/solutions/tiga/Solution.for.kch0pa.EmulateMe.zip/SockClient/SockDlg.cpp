// SockDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Sock.h"
#include "SockDlg.h"
#include "Base64.h"
#include <iostream>
#include <string>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSockDlg dialog

CSockDlg::CSockDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSockDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSockDlg)
	m_sName = _T("");
	m_sSerial = _T("");
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSockDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSockDlg)
	DDX_Control(pDX, IDC_BSEND, m_ctlBsend);
	DDX_Control(pDX, IDC_LIST1, m_ctlList1);
	DDX_Text(pDX, IDC_ENAME, m_sName);
	DDV_MaxChars(pDX, m_sName, 900);
	DDX_Text(pDX, IDC_ESERIAL, m_sSerial);
	DDV_MaxChars(pDX, m_sSerial, 1024);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSockDlg, CDialog)
	//{{AFX_MSG_MAP(CSockDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_EN_CHANGE(IDC_ENAME, OnChangeEname)
	ON_BN_CLICKED(IDC_BSEND, OnBsend)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSockDlg message handlers

BOOL CSockDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	// Set the socket dialog pointers
	m_bConnected = false;
	m_sConnectSocket.SetParent(this);
	m_sListenSocket.SetParent(this);

	// Server, create a socket bound to the port specified
	m_sConnectSocket.Create();
	// Listen for connection requests
	m_sConnectSocket.Connect("127.0.0.1", 22);


	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSockDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CSockDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSockDlg::OnAccept()
{
//	AfxMessageBox("Client Connected");
}

void CSockDlg::OnConnect()
{
	m_bConnected = true;
//	AfxMessageBox("Server Connected");
}

void CSockDlg::OnClose()
{
	m_sConnectSocket.Close();
	m_bConnected = false;
	m_ctlBsend.EnableWindow(false);
	UpdateData(false);
//	AfxMessageBox("Server Disconnected");
}

void CSockDlg::OnReceive()
{
//	AfxMessageBox("Received");

	char *pBuf = new char[1025];
	int iBufSize = 1024;
	int iRcvd = -1, iLen = -1;
	CString strRecvd(""), strSerial("");

	// Receive the message
	iRcvd = m_sConnectSocket.Receive(pBuf, iBufSize);
	// Did we receive anything?
	if (iRcvd == SOCKET_ERROR)
	{
		AfxMessageBox("SOCKET_ERROR");
	}
	else
	{
		// Truncate the end of the message
		pBuf[iRcvd] = NULL;
		// Copy the message to a CString
		strRecvd = pBuf;

		//Base64 Decoding
		iLen = strRecvd.GetLength();
		std::string sName = base64_decode((std::string)(LPCSTR)strRecvd);
		//Updating Decoded Name
		m_sName = (const char*)sName.c_str();
		UpdateData(false);

		//Serial Comparison
		strSerial = "KCH-" + strRecvd;
		if (m_sName != "Server Busy!")
		{
			if (m_sSerial == strSerial )
				AfxMessageBox("You did it!");
			else
				AfxMessageBox("Try again!");
		}
	}
	delete pBuf;
}

void CSockDlg::OnSend()
{
//	AfxMessageBox("Message Sent");
}

void CSockDlg::OnChangeEname() 
{
	UpdateData(true);

	if (m_bConnected)
		m_ctlBsend.EnableWindow(true);
	else
		m_ctlBsend.EnableWindow(false);

	if (!m_sName.IsEmpty())
	{
		std::string sBase64 = base64_encode((unsigned char *)(LPCSTR)m_sName, m_sName.GetLength());
		m_sSerial =(const char*)sBase64.c_str();
		m_sSerial = "KCH-" + m_sSerial;
	}
	else
		m_sSerial.Empty();

	UpdateData(false);
}

void CSockDlg::OnBsend() 
{
	UpdateData(true);

	int iLen = -1, iSent = -1;

	if (m_bConnected)
	{
		if (!m_sName.IsEmpty())
		{
			// Get the length of the message
			iLen = m_sName.GetLength();
			// Send the message
			iSent = m_sConnectSocket.Send(LPCTSTR(m_sName), iLen);
			// Were we able to send it?
			if (iSent == SOCKET_ERROR)
			{
				AfxMessageBox("SOCKET_ERROR");
			}
		}
	}
	else
	{
	}		
}
