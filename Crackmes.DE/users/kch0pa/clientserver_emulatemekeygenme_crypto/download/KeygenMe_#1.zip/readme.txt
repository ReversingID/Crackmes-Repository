Rules: No reversing of any kind on the Server!!!
Objectives: GOLD: Code a keygen and emulate server, without using SmartCheck!
            SILVER: Emulate the server and code a keygen, using Smartcheck.
            BRONZE: Emulate the server or coding a keygen.



Good Luck!