#include <iostream>
using namespace std;

void main()
{
	char szPart1[5]={0,0,0,0,0};
	char szPart2[5]={0,0,0,0,0};
	char szResult1[5]={0,0,0,0,0};
	char szResult2[5]={0,0,0,0,0};

	cout << "Part 1:" << endl;

	for(unsigned char c1=0x20; c1<128; c1++)
	{
		szPart1[0]=c1;
		for(unsigned char c2=0x20; c2<128; c2++)
		{
			szPart1[1]=c2;
			for(unsigned char c3=0x20; c3<128; c3++)
			{
				szPart1[2]=c3;			
				for(unsigned char c4=0x20; c4<128; c4++)
				{
					szPart1[3]=c4;
					
					_asm
					{
						MOV EAX, DWORD PTR szPart1
						MOV EDI,0x310890
						CDQ
						IMUL EDI
						XOR EAX, 0x96547
						MOV DWORD PTR szResult1, EAX
						XOR ECX,ECX
					LOOP1:
						MOV AL,BYTE PTR [ECX+szPart1]
						XOR AL,BYTE PTR [ECX+szResult1]
						SHL AL,2
						MOV BYTE PTR [ECX+szResult1],AL
						INC ECX
						CMP ECX,4
						JNZ LOOP1
					}
					
					for(int i=0; i<4; i++)
					{
						if(szResult1[i]>0x7a)
						{
							 while (szResult1[i]>0x7a)
								szResult1[i] -= 10;
						}
						if(szResult1[i]<0x30)
						{
							while(szResult1[i]<0x30)
								szResult1[i] += 10;
						}
					}					
	
					if(!memcmp(szResult1, "8x@r", 4))
					{
						cout << szPart1 << endl;
						
					}
				}
			
			}
		}
	}
   
	cout << "Part 2:" << endl;

	for(unsigned char c1=0x20; c1<128; c1++)
	{
		szPart2[0]=c1;
		for(unsigned char c2=0x20; c2<128; c2++)
		{
			szPart2[1]=c2;
			for(unsigned char c3=0x20; c3<128; c3++)
			{
				szPart2[2]=c3;			
				for(unsigned char c4=0x20; c4<128; c4++)
				{
					szPart2[3]=c4;
					_asm
					{
						MOV EAX, DWORD PTR szPart2					
						MOV EDI,0x666666
						CDQ
						IMUL EDI
						XOR EAX,0x365799
						ROR EAX,0x31 
						MOV DWORD PTR szResult2,EAX
						XOR EAX,EAX
						XOR ECX,ECX		
					LOOP2:
						MOV AL,BYTE PTR [ECX+szPart2]
						XOR AL,BYTE PTR [ECX+szResult2]
						XOR AL,0x31
						ROR AL,0x12
						MOV BYTE PTR [ECX+szResult2], AL
						INC ECX
						CMP ECX,0x8
						JNZ LOOP2
					}

					for(int i=0; i<4; i++)
					{
						if(szResult2[i]>122)
						{
							 while ( szResult2[i] > 122 )
								szResult2[i] -= 10;
						}
						if(szResult2[i]<48)
						{
							while(szResult2[i]<48)
								szResult2[i] += 10;
						}
					}
	
					if(!memcmp(szResult2, "tr25", 4))
					{
						cout << szPart2 << endl;
					}
				}
			}
		}
	}

	system("pause");
}