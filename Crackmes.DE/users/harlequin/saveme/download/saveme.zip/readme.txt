I started this one with enthusiasm but that soon waned. Then after completing it and asking for NT/XP testers a big problem was discovered.

It took a lot longer to fix the problem than it did to create the original and I could not have done it without the help and patience of cupegasus.

I include the source code although now very little of it is mine but rather a mixture of cupegasus's, another guy's and mine. I have not checked the comments etc I just present it as is so I can finally see the back of the thing.
To be honest I lost all interest in this through the problems encountered along the way and I only release it now out of respect for the work cupegasus put in to helping me make it run on XP.

It was never meant to be a hard crackme just a little different you should have far less trouble cracking it than we did writing it :-)

It is a simple screen saver. There are two levels and a password for each. The two passwords one after the other will give you the source code.

Beware running without knowing the password will lock you out of your system as per any screen saver!! So dont run it if you have something else important going on in the background.

Enjoy.

Thank you again cupegasus.