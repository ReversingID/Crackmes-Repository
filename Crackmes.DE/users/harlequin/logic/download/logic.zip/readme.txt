A very simple Tea break quickie.

I have given you two alternatives to break this one,
the code (plain w32asm) or the graphics. The choice
is yours.
Either way should not be too difficult if you know
your bits and bobs.

The password for the source code is all the 'High'
letters followed by all the 'Low' letters in alpha
order.

Enjoy