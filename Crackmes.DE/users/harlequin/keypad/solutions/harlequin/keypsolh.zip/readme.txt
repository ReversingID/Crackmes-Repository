Once again a solution to my own crackme :-)


This way is not mine but rather the code of someone far more intelligent, I have just tampered with it a little to allow the matrix to be input from a file.
I had a hell of a time trying to convert the double values to ascii character values and in the end decided just to leave them as print formated double ascii values.
Of course I would not expect you to have developed this solution as it's complexity far outweighs that of the problem but if you have made it this far I thought you may be interested.

You can find the original program here:

http://www.qfilter.com/math.html