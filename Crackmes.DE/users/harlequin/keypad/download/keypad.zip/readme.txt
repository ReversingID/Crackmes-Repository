Hello and welcome.

I tried to make this little crackme more interesting for you, I hope you enjoy
it.
Harlequin

tnx go to Remmy for the basic algo.

Now on with the explanation:



Rummaging through the attic you come across a small fireproof safe. You remember
your Grandad showing you the box when you were a child.
"This is where I keep all my most important and secret papers." He told you.

Wow! you think, all these years and still unopened.
You examine the box and find that it has some sort of digital keypad locking
device on the front. Unfortunatly the keypad appears to be broken beyond repair.
Driven by you insatiable curiosity you decide to write to the manufacturers of
the safe to see if they can offer any assistance.

After several weeks of impatient waiting you finally recieve a parcel in the
post.

The attached letter offers appologies from the manufacturers saying they can do
very little to help. They say that production of the safe was terminated several
years previously and the company is now in receivership. During the years it was
produced there were only ten different keypad configurations made for the model
you have. A search of their warehouse turned up the last ten remaining
replacement keypads.
They have sent the pads in the attached box. Apparently it is a skilled but
simple job to replace the keypad on the box you have.

From the letter you learn that each pad when fitted has a different encoded
output. To open the box you will need to determine which keypad was originally
fitted and then decipher the locking code.

Finally the letter offers you lots of luck, suggests a local dynamite supplier,
and there are a few mischievious chuckles at the end.

On the reverse of the letter in quickly scrawled handwritting is a note:

A final thought! It was customary for users of the old model safes to further
seal the documents within them. A standard coding practice was to take the first
digit of the unlock code and the char it produced, then the second digit and its
code ........etc  the final string would be the document code.
For example if keypad#6 were fitted and the unlock code were E79.
The document code would be: Ek7e9Y.


Wonder what grandad kept in his little box of secrets you think to yourself as
you carefully fit keypad#1.
Your journey begins..........





















 