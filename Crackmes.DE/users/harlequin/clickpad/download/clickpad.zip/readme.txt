I think the asm speaks clearly enough but....

Click to generate your key, when your key is big enough the password will be
decoded. Its basically a very simple XOR protection ;-)
If you have the correct key then the password will open the source.zip.
The final password is recognizable and you will have no doubt that it is the correct one.

Good luck and enjoy.

Another asm file for you to play with Bswap my friend.

