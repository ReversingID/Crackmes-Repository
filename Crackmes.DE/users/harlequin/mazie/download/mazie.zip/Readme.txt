_____
Mazie

Mazie has a problem she cant get out of the labrynth can you help her?
Unfortunatly you have lost the help file and rules for the game but with
your experience and skills you should have no trouble determining them
from the code.

When you get Mazie home to the top right corner the path you took will
give you the password you require to open the source code zip.

There is no packing, no encryption, no SI/debugger tricks, just the code
(plain assembler) read it well and your job will be an easy one.
 
There are 4 levels to your journey each one a little harder than the last. 
You will know if you are going the right way as you reach each one.
You can achieve your objective any way you like but when you rescue Mazie
please write about your adventures.

Have fun

Harlequin.

Many thanks to Bswap for testing.
Many thanks to Ben and cupegasus on the crackmes forum who took the time to point out my NT problems.