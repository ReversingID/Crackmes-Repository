#ifndef SLIDERSGA_STDAFX_H_INCLUDED
#define SLIDERSGA_STDAFX_H_INCLUDED
		
// windows related includes
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

// runtime library
#include <stdio.h>

// stl
#pragma warning(disable:4786)
#include <map>
#include <list>
#include <vector>


// c++ related includes
#include <math.h>

// assertion and debug
#include <crtdbg.h>

/**********************************************************/
static void debugPrint(char *format, ...)
{
	char debugString[MAX_PATH];
	va_list printArguments;

	// prepare string
	va_start( printArguments, format );
	_vsnprintf(debugString, sizeof(debugString), format, printArguments);
	va_end( printArguments );

	// output to debug window
	::OutputDebugString(debugString);
}

#ifdef _DEBUG
	#define GA_LOG(x) (x)
#else
	#define GA_LOG(x)
#endif

#endif
