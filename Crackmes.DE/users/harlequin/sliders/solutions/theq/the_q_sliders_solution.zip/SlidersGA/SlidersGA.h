#ifndef SLIDERSGA_H_INCLUDED
#define SLIDERSGA_H_INCLUDED

#define TOTAL_GENES			(15)
#define	INIT_PHENOTPYE		(0x0DEC0DED1)
#define DESIRED_PHENOTYPE	(0x0183BC64F)
#define TOP_SCORE			(32)

#define POOL_SIZE				(50)
#define SOLUTIONS_TO_MIX		(10)
#define SOLUTIONS_TO_MUTATE		(25)
/*
	<-							solutions pool								   ->
	<- top solutions											bad solutions  ->
	<- solutions to mix -> <- solutions to mutate -> <- solutions to re-create ->
*/

struct SlidersSolution
{
	BYTE	_genotype[TOTAL_GENES];
	DWORD	_phenotype;
	int		_score;
};

class SlidersGA  
{
public:
	SlidersGA();
	virtual ~SlidersGA();

	bool				searchForSolution();

protected:
	// pool functions
	bool				initPool();
	bool				clearPool();
	bool				processPool();
	bool				sortPool();
	bool				evolvePool();
	bool				printTopSolution();
	bool				printTopScores();

	// solution functions
	SlidersSolution*	createEmptySolution();
	SlidersSolution*	createRandomSolution();
	bool				clearSolution(SlidersSolution* sol);
	bool				processSolution(SlidersSolution* sol);
	bool				mixSolutions(SlidersSolution* par1, SlidersSolution* par2, SlidersSolution* child1, SlidersSolution* child2);
	bool				mutateSolution(SlidersSolution* sol);

private:
	bool				searchForGene(BYTE* geneBuffer, int size, BYTE geneToFind);
	bool				shuffleSolutions(SlidersSolution* par1, SlidersSolution* par2, SlidersSolution* child);
	bool				crossSolutionsOverCenter(SlidersSolution* par1, SlidersSolution* par2, SlidersSolution* child);
	SlidersSolution*	_pool[POOL_SIZE];

public:
	// hash functions
	static DWORD opcode0(DWORD ebxValue);
	static DWORD opcode1(DWORD ebxValue);
	static DWORD opcode2(DWORD ebxValue);
	static DWORD opcode3(DWORD ebxValue);
	static DWORD opcode4(DWORD ebxValue);
	static DWORD opcode5(DWORD ebxValue);
	static DWORD opcode6(DWORD ebxValue);
	static DWORD opcode7(DWORD ebxValue);
	static DWORD opcode8(DWORD ebxValue);
	static DWORD opcode9(DWORD ebxValue);
	static DWORD opcodeA(DWORD ebxValue);
	static DWORD opcodeB(DWORD ebxValue);
	static DWORD opcodeC(DWORD ebxValue);
	static DWORD opcodeD(DWORD ebxValue);
	static DWORD opcodeE(DWORD ebxValue);
};

#endif
