#include "stdafx.h"
#include "SlidersGA.h"
#include <time.h>

SlidersGA::SlidersGA()
{
   srand( (unsigned)time( NULL ) );
}

SlidersGA::~SlidersGA()
{

}

DWORD SlidersGA::opcode0(DWORD ebxValue)
{
//	xor     ebx, 357AF135h
	return( ebxValue ^ 0x357AF135 );
}

DWORD SlidersGA::opcode1(DWORD ebxValue)
{
//	ror     ebx, 7
	_asm	mov eax, ebxValue
	_asm	ror eax, 7
	_asm	mov ebxValue, eax
	return( ebxValue );
}

DWORD SlidersGA::opcode2(DWORD ebxValue)
{
//	add     ebx, 427BD630h
	return( ebxValue + 0x427BD630 );
}

DWORD SlidersGA::opcode3(DWORD ebxValue)
{
//	or      ebx, 19247FEDh
	return( ebxValue | 0x19247FED );
}

DWORD SlidersGA::opcode4(DWORD ebxValue)
{
//	xor     ebx, 531FA753h
	return( ebxValue ^ 0x531FA753 );
}

DWORD SlidersGA::opcode5(DWORD ebxValue)
{
//	sub     ebx, 427BD630h
	return( ebxValue - 0x427BD630 );
}

DWORD SlidersGA::opcode6(DWORD ebxValue)
{
//	shl     ebx, 4
	_asm	mov eax, ebxValue
	_asm	shl eax, 4
	_asm	mov ebxValue, eax
	return( ebxValue );
}

DWORD SlidersGA::opcode7(DWORD ebxValue)
{
//	not     ebx
	_asm	mov eax, ebxValue
	_asm	not eax
	_asm	mov ebxValue, eax
	return( ebxValue );
}

DWORD SlidersGA::opcode8(DWORD ebxValue)
{
//	rol     ebx, 7
	_asm	mov eax, ebxValue
	_asm	rol eax, 7
	_asm	mov ebxValue, eax
	return( ebxValue );
}

DWORD SlidersGA::opcode9(DWORD ebxValue)
{
//	bswap   ebx
	_asm	mov eax, ebxValue
	_asm	bswap eax
	_asm	mov ebxValue, eax
	return( ebxValue );
}

DWORD SlidersGA::opcodeA(DWORD ebxValue)
{
//	neg     ebx
	_asm	mov eax, ebxValue
	_asm	neg eax
	_asm	mov ebxValue, eax
	return( ebxValue );
}

DWORD SlidersGA::opcodeB(DWORD ebxValue)
{
//	add     ebx, 0A732E5C9h
	return( ebxValue + 0x0A732E5C9 );
}

DWORD SlidersGA::opcodeC(DWORD ebxValue)
{
//	add     ebx, 1874FAB0h
	return( ebxValue + 0x1874FAB0 );
}

DWORD SlidersGA::opcodeD(DWORD ebxValue)
{
//	shr     ebx, 0Ah
	_asm	mov eax, ebxValue
	_asm	shr eax, 0x0A
	_asm	mov ebxValue, eax
	return( ebxValue );
}

DWORD SlidersGA::opcodeE(DWORD ebxValue)
{
//	not     ebx
	_asm	mov eax, ebxValue
	_asm	not eax
	_asm	mov ebxValue, eax
	return( ebxValue );
}


// opcodes jump table
typedef DWORD(__cdecl* OPCODE_FUNC)(DWORD);
OPCODE_FUNC	g_opcodeTable[TOTAL_GENES] = 
{ 
	&SlidersGA::opcode0, &SlidersGA::opcode1, &SlidersGA::opcode2, &SlidersGA::opcode3,
	&SlidersGA::opcode4, &SlidersGA::opcode5, &SlidersGA::opcode6, &SlidersGA::opcode7,
	&SlidersGA::opcode8, &SlidersGA::opcode9, &SlidersGA::opcodeA, &SlidersGA::opcodeB,
	&SlidersGA::opcodeC, &SlidersGA::opcodeD, &SlidersGA::opcodeE
};

//
// solution functions
//
SlidersSolution* SlidersGA::createEmptySolution()
{
	SlidersSolution* sol = new SlidersSolution;
	ZeroMemory(sol, sizeof(SlidersSolution));
	return sol;
}

SlidersSolution* SlidersGA::createRandomSolution()
{
	SlidersSolution* sol = new SlidersSolution;
	ZeroMemory(sol, sizeof(SlidersSolution));

	BYTE possibleGenes[TOTAL_GENES] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0xA, 0xB, 0xC, 0xD, 0xE };
	BYTE geneBuffer[TOTAL_GENES];
	int	 bufferSize = TOTAL_GENES;
	BYTE geneToSkip = 0xFF;
	int  pi, bi;

	for(int si=0; si<TOTAL_GENES; si++)
	{
		// copy possibleGenes to geneBuffer
		for(pi=0, bi=0; pi<TOTAL_GENES; pi++)
		{
			if (possibleGenes[pi] != geneToSkip)
			{
				geneBuffer[bi] = possibleGenes[pi];
				bi++;
			}
		}
		memset(possibleGenes, 0xFF, sizeof(possibleGenes));
		memcpy(possibleGenes, geneBuffer, bufferSize);

		int rndVal = rand() % bufferSize;
		sol->_genotype[si] = possibleGenes[rndVal];
		
		geneToSkip = sol->_genotype[si];
		bufferSize--;
	}
	
	return sol;
}

bool SlidersGA::clearSolution(SlidersSolution* sol)
{
	delete sol;
	return true;
}


bool SlidersGA::processSolution(SlidersSolution* sol)
{
	int i;
	BYTE geneVal;

	// init solution phenotype
	sol->_phenotype = INIT_PHENOTPYE;
	
	// process genotype 
	for(i=0; i<TOTAL_GENES; i++)
	{
		geneVal = sol->_genotype[i];
		sol->_phenotype = g_opcodeTable[geneVal] ( sol->_phenotype );
	}
	
	// calc score
	DWORD diff = sol->_phenotype ^ DESIRED_PHENOTYPE;
	sol->_score = 0;
	for(i=0; i<32; i++)
	{
		if ( !(diff & 1) )
		{
			sol->_score++;
		}
		diff >>= 1;
	}
	return true;
}

bool SlidersGA::searchForGene(BYTE* geneBuffer, int size, BYTE geneToFind)
{
	for(int i=0; i<size; i++)
	{
		if (geneBuffer[i] == geneToFind)
		{
			return true;
		}
	}
	return false;
}

bool SlidersGA::shuffleSolutions(SlidersSolution* par1, SlidersSolution* par2, SlidersSolution* child)
{
	for(int i=0; i<TOTAL_GENES; i++)
	{
		int idx1 = par2->_genotype[i];
		child->_genotype[i] = par1->_genotype[idx1];
	}
	return true;
}

bool SlidersGA::crossSolutionsOverCenter(SlidersSolution* par1, SlidersSolution* par2, SlidersSolution* child)
{
	BYTE possibleGenes[TOTAL_GENES] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0xA, 0xB, 0xC, 0xD, 0xE };
	BYTE geneBuffer[TOTAL_GENES];
	int	 bufferSize = TOTAL_GENES;
	BYTE geneToSkip = 0xFF;

	for(int i=0; i<TOTAL_GENES; i++)
	{
		// copy possibleGenes to geneBuffer
		for(int pi=0,bi=0; pi<TOTAL_GENES; pi++)
		{
			if (possibleGenes[pi] != geneToSkip)
			{
				geneBuffer[bi] = possibleGenes[pi];
				bi++;
			}
		}
		memset(possibleGenes, 0xFF, sizeof(possibleGenes));
		memcpy(possibleGenes, geneBuffer, bufferSize);

		if (i < (TOTAL_GENES / 2) )
		{
			child->_genotype[i] = par1->_genotype[i];
		}
		else
		{
			if ( searchForGene(child->_genotype, (i-1), par2->_genotype[i]) == false )
			{
				child->_genotype[i] = par2->_genotype[i];;
			}
			else if ( searchForGene(child->_genotype, (i-1), par1->_genotype[i]) == false )
			{
				child->_genotype[i] = par1->_genotype[i];
			}
			else
			{
				child->_genotype[i] = possibleGenes[0];
			}
		}

		geneToSkip = child->_genotype[i];
		bufferSize--;
	}

	int parSum = 0;
	int childSum = 0;
	for(int j=0; j<TOTAL_GENES; j++)
	{
		parSum	+= par1->_genotype[j];
		childSum+= child->_genotype[j];
	}

	if (parSum != childSum)
	{
		return false;
	}
	return true;
}


bool SlidersGA::mixSolutions(SlidersSolution* par1, SlidersSolution* par2, SlidersSolution* child1, SlidersSolution* child2)
{
	// non-leanar mix .. turned out not to be good
	/* 
	shuffleSolutions(par1, par2, child1);
	shuffleSolutions(par2, par1, child2);
	*/

	// more suttle mix .. 
	if ( crossSolutionsOverCenter(par1, par2, child1) == false )
	{
		*child1 = *par1;
	}
	if ( crossSolutionsOverCenter(par2, par1, child2) == false )
	{
		*child2 = *par2;
	}

	return true;
}

bool SlidersGA::mutateSolution(SlidersSolution* sol)
{
	// swap genes
	int idx1 = rand() % TOTAL_GENES;
	int idx2 = idx1;
	while(idx2 == idx1)
	{
		idx2 = rand() % TOTAL_GENES;
	}

	BYTE gene1 = sol->_genotype[idx1];
	BYTE gene2 = sol->_genotype[idx2];
	sol->_genotype[idx1] = gene2;
	sol->_genotype[idx2] = gene1;
	return true;
}

//
// pool functions
//
bool SlidersGA::initPool()
{
	for(int pi=0; pi < POOL_SIZE; pi++)
	{
		_pool[pi] = createRandomSolution();
	}
	return true;
}

bool SlidersGA::clearPool()
{
	for(int pi=0; pi < POOL_SIZE; pi++)
	{
		clearSolution( _pool[pi] );
	}
	return true;
}

bool SlidersGA::processPool()
{
	for(int pi=0; pi < POOL_SIZE; pi++)
	{
		processSolution( _pool[pi] );
	}
	return true;
}

int poolSortFunc( const void *arg1, const void *arg2 )
{
	DWORD aPtr = *(DWORD*)arg1;
	SlidersSolution* a = (SlidersSolution*)aPtr;
	DWORD bPtr = *(DWORD*)arg2;
	SlidersSolution* b = (SlidersSolution*)bPtr;
	return (b->_score - a->_score);
};


bool SlidersGA::sortPool()
{
	qsort( (void*)_pool, POOL_SIZE, sizeof(SlidersSolution*), poolSortFunc );
	return true;
}


bool SlidersGA::evolvePool()
{
	int pi;
	// mix top solutions
	for(pi=0; pi < SOLUTIONS_TO_MIX; pi+=2)
	{
		SlidersSolution* child1 = createEmptySolution();		
		SlidersSolution* child2 = createEmptySolution();		
		SlidersSolution* par1 = _pool[pi];
		SlidersSolution* par2 = _pool[pi+1];
		mixSolutions(par1, par2, child1, child2);
		clearSolution(par1);
		clearSolution(par2);
		_pool[pi]	= child1;
		_pool[pi+1] = child2;
	}

	// mutate middle solutions
	for(pi=SOLUTIONS_TO_MIX; pi < (SOLUTIONS_TO_MIX+SOLUTIONS_TO_MUTATE); pi++)
	for(pi=0; pi < (SOLUTIONS_TO_MIX+SOLUTIONS_TO_MUTATE); pi++)
	{
		mutateSolution( _pool[pi] );
	}

	// re-create bad solutions
	for(pi=(SOLUTIONS_TO_MIX+SOLUTIONS_TO_MUTATE); pi < POOL_SIZE; pi++)
	{
		clearSolution(_pool[pi]);
		_pool[pi] = createRandomSolution();
	}

	return true;
}

bool SlidersGA::printTopSolution()
{
	SlidersSolution* topSol = _pool[0];
	printf("Found solution:");
	for(int i=0; i<TOTAL_GENES; i++)
	{
		if (i%4==0)
		{
			printf("\n");
		}
		printf("%2X, ", (topSol->_genotype[i]+1));
	}
	printf("\n");
	return true;
}

bool SlidersGA::printTopScores()
{
	printf("Top scores: %d, %d, %d, %d, %d\n", _pool[0]->_score, _pool[1]->_score, _pool[2]->_score, _pool[3]->_score, _pool[4]->_score);
	return true;
}



//
// main loop - searchForSolution()
// 
bool SlidersGA::searchForSolution()
{
	initPool();

	int iter = 0;
	while(true)
	{
		processPool();
		sortPool();
		if (_pool[0]->_score == TOP_SCORE)
		{
			printTopScores();
			printTopSolution();
			break;
		}
		if (iter % 1000 == 0)
		{
			printTopScores();
		}
		evolvePool();
		iter++;
	}

	clearPool();
	return true;
}
