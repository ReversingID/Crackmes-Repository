#include "stdafx.h"
#include "SlidersGA.h"

int main(int argc, char* argv[])
{
	printf("Genetic Algorithm Solution to Harlequin's SLIDERS crackme\nBy The+Q\n");
	SlidersGA sga;
	sga.searchForSolution();
	return 0;
}

