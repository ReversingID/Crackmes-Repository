Hi

Well this one took suprisingly little to write. 
If you are like me it will keep you entertained for quite some time.


The correct serial when you have it should be used forwards and appended backwards and lower case as the key to the zip file.
eg if the key were:

123456789ABCDEF
the zip key would be:
123456789ABCDEFfedcba987654321

You could of course brute force the zip :-) but that would not be playing fair.

Hope you enjoy it.

