#include <windows.h>
#include <stdio.h>

int main()
{
	char		Key[28] = "uAV9vfqaCjJ1kz8nJYvHfhmxVeL\0";
	char		WinKey[255];
	long		Counter;
	HKEY		RegHandle;
	long		KeyLen;

	printf("KeyGen for Harlequin's #1 Crackme");

	KeyLen = 255;

	memset(WinKey, 0, 255);

	RegOpenKeyEx(HKEY_LOCAL_MACHINE, "Software\\Microsoft\\Windows\\CurrentVersion", 0, KEY_READ, &RegHandle);
	Counter = RegQueryValueEx(RegHandle, "ProductKey", NULL, NULL, &WinKey[0], &KeyLen);
	if(!Counter)
	{
		//just make sure it is null terminated
		WinKey[KeyLen] = 0;

		//tell em what their key is
		printf("\n\nWindows Serial: %s", WinKey);

		for(Counter = 0; Counter < 27; Counter++)
			Key[Counter] = Key[Counter] + WinKey[Counter];

		//output the key now
		printf("\nSerial: %s", Key);
	}
	else
	{
		printf("\nError reading registry");
	}

	RegCloseKey(RegHandle);
	
	printf("\n\nCtrl+C to close");
	while(1)
		Counter++;

	return 0;
}