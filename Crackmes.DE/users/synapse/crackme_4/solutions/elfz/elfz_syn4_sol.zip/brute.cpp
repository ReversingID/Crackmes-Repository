// synapse crkme 4 kind-of-keygen
// compile with bcc32

#include <iostream>
#include <stdlib.h>

using std::cout;


char* ser = "0000000000000\n";




void funStuff() {
  switch(rand()%5) {
    case 0:
      cout << "I'm the best    :"; break;
    case 1:
      cout << "No, I'm better  :"; break;
    case 2:
      cout << "Choose me       :"; break;
    case 3:
      cout << "D'ya like me?   :"; break;
    case 4:
      cout << "I'm so nice...  :"; break;
  }
}





int main() {

   srand(time(0)); // just for fun stuff ;)
   
   unsigned int dword_4039B0, dword_4039B4, dword_4039B8, dword_4039C0, dword_4039C4, unk_4039C8, res;

   while(true) {
    asm {
       xor     ecx, ecx
       xor     ebx, ebx
       xor     eax, eax
       mov     ebx, ser
       movzx   eax, byte ptr [ebx+1]
// ; who could care less about some push-es?
//       push    eax 
       movzx   ecx, byte ptr [ebx+0Ah]
       add     eax, ecx
       movzx   ecx, byte ptr [ebx+6]
       add     eax, ecx
       mov     dword_4039B0, eax
       movzx   eax, byte ptr [ebx+2]
       movzx   ecx, byte ptr [ebx+9]
       mul     ecx
       movzx   ecx, byte ptr [ebx+8]
       mul     ecx
       movzx   ecx, byte ptr [ebx+4]
       sub     eax, ecx
       mov     dword_4039B4, eax
       movzx   eax, byte ptr [ebx+3]
       movzx   ecx, byte ptr [ebx+5]
       add     eax, ecx
       movzx   ecx, byte ptr [ebx+7]
       sub     eax, ecx
       movzx   ecx, byte ptr [ebx+0Ch]
       mul     ecx
       mov     ecx, dword_4039B4
       mul     ecx
       movzx   ecx, byte ptr [ebx+0Bh]
       add     eax, ecx
       movzx   ecx, byte ptr [ebx]
       sub     eax, ecx
       mov     ecx, dword_4039B0
       mul     ecx
       movzx   ecx, byte ptr [ebx+2]
       add     eax, ecx
       movzx   ecx, byte ptr [ebx+0Ch]
       add     eax, ecx
       movzx   ecx, byte ptr [ebx+8]
       add     eax, ecx
       mov     unk_4039C8, eax
       movzx   eax, byte ptr [ebx]
       movzx   ecx, byte ptr [ebx+1]
       mul     ecx
       movzx   ecx, byte ptr [ebx+2]
       mul     ecx
       movzx   ecx, byte ptr [ebx+0Ch]
       sub     eax, ecx
       mov     dword_4039B0, eax
       movzx   eax, byte ptr [ebx+3]
       movzx   ecx, byte ptr [ebx+3]
       mul     ecx
       mov     dword_4039B8, eax
       movzx   eax, byte ptr [ebx+0Bh]
       movzx   ecx, byte ptr [ebx+0Ch]
       mul     ecx
       mov     ecx, dword_4039B8
       add     eax, ecx
       mov     dword_4039B4, eax
       movzx   eax, byte ptr [ebx+4]
       movzx   ecx, byte ptr [ebx+6]
       mul     ecx
       movzx   ecx, byte ptr [ebx+9]
       add     eax, ecx
       movzx   ecx, byte ptr [ebx+0Ah]
       add     eax, ecx
       mov     ecx, eax
       mov     eax, dword_4039B4
       sub     eax, ecx
       mov     dword_4039B4, eax
       mov     eax, dword_4039B0
       mov     ecx, dword_4039B4
       add     eax, ecx
       movzx   ecx, byte ptr [ebx+0Ch]
       add     eax, ecx
       mov     dword_4039B0, eax
       movzx   eax, byte ptr [ebx+0Ch]
       movzx   ecx, byte ptr [ebx+0Ch]
       add     eax, ecx
       movzx   ecx, byte ptr [ebx+8]
       add     eax, ecx
       mov     dword_4039B4, eax
       mov     eax, dword_4039B0
       mov     ecx, dword_4039B4
       sub     eax, ecx
       mov     dword_4039C0, eax
       movzx   eax, byte ptr [ebx]
       movzx   ecx, byte ptr [ebx+1]
       add     eax, ecx
       movzx   ecx, byte ptr [ebx+2]
       add     eax, ecx
       movzx   ecx, byte ptr [ebx+3]
       add     eax, ecx
       movzx   ecx, byte ptr [ebx+4]
       add     eax, ecx
       movzx   ecx, byte ptr [ebx+5]
       add     eax, ecx
       movzx   ecx, byte ptr [ebx+6]
       add     eax, ecx
       movzx   ecx, byte ptr [ebx+7]
       add     eax, ecx
       movzx   ecx, byte ptr [ebx+8]
       add     eax, ecx
       movzx   ecx, byte ptr [ebx+9]
       add     eax, ecx
       movzx   ecx, byte ptr [ebx+0Ah]
       add     eax, ecx
       movzx   ecx, byte ptr [ebx+0Bh]
       add     eax, ecx
       movzx   ecx, byte ptr [ebx+0Ch]
       add     eax, ecx
       movzx   ecx, byte ptr [ebx+0Ch]
       mul     ecx
       mov     ecx, dword_4039C0
       add     eax, ecx
       mov     dword_4039C0, eax
       movzx   eax, byte ptr [ebx]
       movzx   ecx, byte ptr [ebx+0Ch]
       add     eax, ecx
       mov     dword_4039B0, eax
       movzx   eax, byte ptr [ebx]
       movzx   ecx, byte ptr [ebx+1]
       mul     ecx
       movzx   ecx, byte ptr [ebx+0Ch]
       mul     ecx
       movzx   ecx, byte ptr [ebx+3]
       mul     ecx
       mov     ecx, dword_4039B0
       add     eax, ecx
       mov     dword_4039B4, eax
       movzx   eax, byte ptr [ebx+0Ch]
       movzx   ecx, byte ptr [ebx]
       sub     eax, ecx
       mov     ecx, eax
       mov     eax, dword_4039B4
       mul     ecx
       mov     ecx, dword_4039C0
       add     eax, ecx
       mov     dword_4039C0, eax
       mov     ecx, dword_4039C0
       mov     eax, unk_4039C8
       mov     edx, 0

       // fix to prevent div 0
       or ecx, ecx
       jnz isok

       // this serial is terribly incorrect, so screw it
       movzx eax, byte ptr [ebx + 0ch]
       inc eax
       jmp screwit


isok:
       div     ecx
screwit:
       mov res, eax
    }
    
    if (res == ser[12]) {
      funStuff();
      cout << ser;
    }

    // brute forcing sucks.
    ser[12]++;
    if (':' == ser[12]) {
      ser[12] = '0'; ser[11]++;
      if (':' == ser[11]) {
        ser[11] = '0'; ser[10]++;

        if (':' == ser[10]) {
          ser[10] = '0'; ser[9]++;
        
          if (':' == ser[9]) {
            ser[9] = '0'; ser[8]++;
          
            if (':' == ser[8]) {
              ser[8] = '0'; ser[7]++;
            
              if (':' == ser[7]) {
                ser[7] = '0'; ser[6]++;
                
                if (':' == ser[6]) {
                  ser[6] = '0'; ser[5]++;
                
              
                  if (':' == ser[5]) {
                    ser[5] = '0'; ser[4]++;
                  
                    if (':' == ser[4]) {
                      ser[4] = '0'; ser[3]++;
                    
                      if (':' == ser[3]) {

cout << ".";

                        ser[3] = '0'; ser[2]++;
                      
                        if (':' == ser[2]) {
                          ser[2] = '0'; ser[1]++;

                          if (':' == ser[1]) {
                            ser[1] = '0'; ser[1]++; 
                            if (':' == ser[0]) {
                              printf("that's all folks.");
                              break;
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }


 }
 return 0;

}
