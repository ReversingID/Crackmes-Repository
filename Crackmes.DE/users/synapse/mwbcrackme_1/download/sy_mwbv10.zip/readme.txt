Messing with Bytes v1.0 by synapse
---------------------------------------
Created using SpAsm 4.15c

Rules:
- no patching! (if possible!)

Goal:
- enable the button so that it can be pressed
- catch: see below

the ideal solution for this crackme is by creating a program that will send a certain command to the crackme so that it will register itself... that's very easy for my part(coz i have the source).. i dont know if this is possible for your part... because of this, i placed a hint(see below) so that patching can be prevented.. if you still think it's not possible.. then you can patch it... if you successfully made a regkey file for the crackme or successfully patched it.. the button will be enabled and the text "unregistered" will turn into "Good Work! =)"..

regkey(prog)						  mwb v1.0 (crackme)
--------------						  ------------------
|	     |		command	to be sent		  |		   |
|            |	----------------------------------- |>    | 		   |
|            |	  	see hint below			  |		   |
-------------- 						  ------------------

Hint:
mwbhWnd = handle of the crackme
call 'USER32.SendMessage' mwbhWnd &WM_COMMAND IDM_REG 0 <-== in SpAsm syntax
invoke SendMessage, mwbhWnd, WM_COMMAND, IDM_REG, 0     <-== in MASM32 syntax

just mail me if you want to look at the regkey file(prog) that i made.. the regkey file is also made using SpAsm 4.15c... i am currently making the 2nd version of this crackme.. my goal is to make the crackme check its CRC/MD5 checksum by itself... so that patching can be prevented... but im having trouble of making the "CRC/MD5/or any checksum checking" code.. if anyone knows how, please send the code to me.. if you can convert it to SpAsm syntax.. please do so.. im having a hard time converting..

- synapse [mark_a@yahoo.com]