#include <windows.h>
#include "resource.h"

HINSTANCE hInst;             // main function handler
HWND hmwb;	// handle of MwB v1.0
//--------------------No need to use CreateProcess------------//
//STARTUPINFO StartupInfo;
//PROCESS_INFORMATION ProcInfo;

BOOL CALLBACK DialogProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message) // what are we doing ?
	{ 	 
		case WM_INITDIALOG: 
		{
			/* 
			memset(&StartupInfo,0,sizeof(STARTUPINFO));
			memset(&ProcInfo,0,sizeof(PROCESS_INFORMATION));
			StartupInfo.cb=sizeof(STARTUPINFO);
			StartupInfo.dwFlags=STARTF_USESHOWWINDOW;
			StartupInfo.wShowWindow=SW_SHOWDEFAULT; 
			CreateProcess(NULL,"mwbv10.exe",NULL,NULL,FALSE,NORMAL_PRIORITY_CLASS,NULL,NULL,&StartupInfo,&ProcInfo);
			*/
			//another way to lunch the app
			WinExec("mwbv10.exe",SW_SHOWDEFAULT);
			return true;
		}
		break;

		case WM_COMMAND: 
		{
			switch (LOWORD(wParam)) // what we pressed on?
			{
				case IDOK:
					hmwb=FindWindow("SimpleWinClass",NULL);
					SendMessage(hmwb,WM_COMMAND,0x7D03,0);
				break;
				case IDCANCEL: 
					EndDialog(hWnd,0); // Kill Dialog
				break;
			}
		}
		break;

		case WM_CLOSE: // We colsing the Dialog
		{
			EndDialog(hWnd,0); // Kill Dialog
		}
		break;
	}
	return 0;
}

//int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
int Start()
{
	hInst=GetModuleHandle(NULL);
	DialogBoxParam(hInst, MAKEINTRESOURCE(IDD_DLG), NULL, (DLGPROC)DialogProc,0);
	return 0;
}