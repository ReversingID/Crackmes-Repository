KeyGenMe-2 by synapse
--------------------------------------
Written in SpAsm 4.15c

Type: KeyGenMe

Protection:
- you'll just have to find out -

Objectives:
- get a valid name/serial
- make a keygen
- make a tut
- submit zip file(keygen,tut) to www.crackmes.de / to me(optional)

Rules:
- no patching!

Another crackme written by me... this is my second keygenme... it's again just a normal name/serial crackme.. no SMC stuff(im having a hard time coding this!).. no anti stuff.. but it's definitely harder than the first one.. this is also based on the first one.. but i changed the algo of course... if you managed to crack it(of course you can!), please make a keygen and a tut.. put it in a zip file and submit it to www.crackmes.de... and if you want to, you can send it to me also... happy cracking!

PS: If you know how to write a SMC in asm.. that can be put into a crackme.. please email me.. an example of this is +crue's crackme v1... +crueme1...

- synapse [markz_a@yahoo.com]