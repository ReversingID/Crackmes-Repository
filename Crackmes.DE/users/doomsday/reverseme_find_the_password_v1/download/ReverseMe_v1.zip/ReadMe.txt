     ~ ReverseMe v1 By DoomsDay ~

              ~ Details ~
 Platform......................Windows
 Language....................Assembler
 Difficulty....Needs special knowledge

 Solution Requirements:
  1) Reverse the algorithm completely.
  2) Find the correct password.
  3) Post a tutorial; doesn't have to 
     cover the entire process.

 Notes:
  * There is only one valid password.
  * No patching allowed.