Made by: T[9]Uvatha on Aug 29th 2004

Greetz:
������
Don't be rude on me, this is my first Crackme... I hope you like it even tho next ones gonna be alot better.


Instructions:
������������
The goal of this crackme is to enable the 2 controls, then find the serial, which is a bit harder because it's not hardcoded.

If you can, by any means, permanently enable the 2 controls and find the serial, then you will have successfully cracked this crackme.


Plans:
�����
I plan on making a serie of quality crackme's, trying to reproduce protection schemes in my VB applications while I'm learning cracking new ones. Next crackme's will cover a lot of cracking tricks, with explanations included in the crackme itself, helping you while u advance in the crackme stages. It's gonna be a kind of game you win when every obstacles blocking your way will have been cracked.

I'm also planning on making a website about cracking, including tutorials, crackme's, and the tools of the trade. New info in the next crackme ;)


Final words:
�����������
I hope you like this crackme, l8rz crackers!


Thx goes to:
�����������
-http://www.crackmes.de for their marvelous website about crackmes,
-Everyone on crackmes.de, coders and solvers,
-And of course, you, who is actually reading this.


Contact me at:
�������������
BladeZSlayer@Hotmail.com