#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include "resource.h"



const BYTE TEA_KEY[16] = {0xDF, 0x10, 0xDB, 0x04, 0x06, 0xEE, 0x9D, 0x16, 
						0xF1, 0xB8, 0xEB, 0x16, 0xE4, 0xB2, 0xAC, 0xAC};

void FirstMod(WORD *inp)
{
	for(int i = 0; i < 0x10; i++)
		inp[i] = (((inp[i] ^ 0x4EB) + 0xCC00) ^ 0x740A) - 0x5354;
}

void SecondMod(WORD *inp)
{
	for(int i = 0; i < 0x10; i++)
		inp[i] = (((inp[i] ^ 0x20CD) + 0xE0EA) ^ 0x4EB) - 0x7A53;

}

void ThirdMod(char *inp)
{
	for(int i = 0; i < 0x20; i++)
	{
		if(inp[i] >= 0x41 && inp[i] < 0x5B)
		{
			inp[i] -= 0x41;
			inp[i] = (inp[i] + 0xD) % 0x1A;
			inp[i] += 0x41;
		}
		else if(inp[i] >= 0x61 && inp[i] < 0x7B)
		{
			inp[i] -= 0x61;
			inp[i] = (inp[i] + 0xD) % 0x1A;
			inp[i] += 0x61;
		}
	}
}

void FourthMod(char *inp)
{
	for(int i = 0; i < 0x20; i++)
	{
		if(inp[i] >= 0x30 && inp[i] < 0x3A)
			inp[i] = 0x69 - inp[i];
		else if(inp[i] >= 0x41 && inp[i] < 0x5B)
			inp[i] = 0x9B - inp[i];
		else if(inp[i] >= 0x61 && inp[i] < 0x7B)
			inp[i] = 0xDB - inp[i];
	}
}

DWORD CRC(char *buff, int len)
{
	DWORD crc = 0xFFFFFFFF;
	DWORD tmp;
	for(int i = 0; i < len; i++)
	{
		tmp = buff[i];
		tmp ^= (crc & 0xFF);
		for(int j = 0; j < 8; j++)
		{
			if(tmp & 1)
			{
				tmp >>= 1;
				tmp ^= 0xEDB88320;
			}
			else
				tmp >>= 1;
		}
		crc >>= 8;
		crc ^= tmp;
	}
	return ~crc;
}

void EncTEA(DWORD *inp, const DWORD *key, int rounds)
{
	DWORD v1, v2, d = 0;
	v1 = inp[0];
	v2 = inp[1];
	for(int i = 0; i < rounds; i++)
	{
		d += 0x9E3779B9;
		v1 += ((v2 << 4) + key[0]) ^ (v2 + d) ^ ((v2 >> 5) + key[1]);
		v2 += ((v1 << 4) + key[2]) ^ (v1 + d) ^ ((v1 >> 5) + key[3]);
	}
	inp[0] = v1;
	inp[1] = v2;
}

void Generate(HWND hWnd)
{
	DWORD key;
	char pass[33] = "-=+>Ray_0f_The_Sun<=-by_";
	if(GetWindowTextLength(GetDlgItem(hWnd, IDC_NAME)) != 8)
		return;
	GetDlgItemText(hWnd, IDC_NAME, pass + 24, 9);
	SetDlgItemText(hWnd, IDC_NAME, pass);
	FourthMod(pass);
	ThirdMod(pass);
	SecondMod((WORD*)pass);
	for(int i = 0; i < 4; i++)
		EncTEA((DWORD*)pass + i * 2, (const DWORD*)TEA_KEY, 0x20);
	FirstMod((WORD*)pass);
	key = CRC(pass, 32);
	SetDlgItemInt(hWnd, IDC_SERIAL, key, FALSE);
}

static BOOL CALLBACK DlgAbout(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
	case WM_INITDIALOG:
		SetDlgItemText(hwnd, IDC_EDIT1, "2005 - 07 - 22");
		SetDlgItemText(hwnd, IDC_EDIT2, "Knight");
		SetDlgItemText(hwnd, IDC_EDIT3, "ICT Official Trial Crackme - Level 1 (ICT.Trial-1.exe)");
		break;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDOK:
			EndDialog(hwnd, 0);
			break;
		}
		break;
	default:
		return FALSE;
	}
	return true;
}

static BOOL CALLBACK DlgFunc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
	case WM_INITDIALOG:
		SendMessage(hwnd, WM_SETICON, ICON_SMALL, (LPARAM)LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1)));
		SendMessage(hwnd, WM_SETICON, ICON_BIG, (LPARAM)LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1)));
		return TRUE;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDC_BEXIT:
			EndDialog(hwnd, 0);
			break;
		case IDC_BABOUT:
			DialogBox(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_ABOUT), hwnd, DlgAbout);
			break;
		case IDC_BGEN:
			Generate(hwnd);
			break;
		}
		break;
	case WM_CLOSE:
		EndDialog(hwnd, 0);
	default:
		return FALSE;
	}
	return TRUE;
}

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	return DialogBox(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, DlgFunc);
}
