#include <iostream.h>
#include <conio.h>
//Written by Detten
//15-oct-2001
int main () {

char name[20];
int i=0;
int serial=0;

cout<<"Name :";
cin>>name;

while (name[i]!='\0')
	{
     	serial+=(name[i]*name[i]);
      serial+=(name[i]/2);
      serial-=name[i];
      i++;
   }

cout<<endl<<"Serial = "<<serial;
getch();
}
