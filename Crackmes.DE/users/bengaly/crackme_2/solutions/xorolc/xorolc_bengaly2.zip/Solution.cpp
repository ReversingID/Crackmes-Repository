#include <stdio.h>
#include <string.h>


unsigned char Name[25]={0};
unsigned long Serial;
int i;


int main(){  

printf("Please Enter Your Name: ");
gets(Name);
i = strlen(Name);

asm{
	mov	ecx,	[i]
	xor	esi,	esi
	xor	ebx,	ebx
	xor	eax,	eax
	Name:
	mov	dl,	BYTE PTR [Name+eax]
	and	edx,	000000FFh
	mov	ebx,	edx
	imul	ebx,	edx
	add	esi,	ebx
	mov	ebx,	edx
	sar	ebx,	1
	add	esi,	ebx
	sub	esi,	edx
	inc	eax
	dec	ecx
	jne	Name
	mov	Serial, esi
}
printf("Your Serial: %lu",Serial);
return 0;
}