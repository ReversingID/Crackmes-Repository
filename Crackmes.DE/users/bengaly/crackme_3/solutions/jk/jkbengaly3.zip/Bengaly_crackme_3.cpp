// KGTemplateDlg.cpp : implementation file
//

#include "stdafx.h"
#include "KGTemplate.h"
#include "KGTemplateDlg.h"
#include "stdlib.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CKGTemplateDlg dialog

CKGTemplateDlg::CKGTemplateDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CKGTemplateDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CKGTemplateDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CKGTemplateDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CKGTemplateDlg)
	DDX_Control(pDX, IDC_EDIT2, m_serial);
	DDX_Control(pDX, IDC_EDIT1, m_username);
	DDX_Control(pDX, IDC_BUTTON2, m_generate);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CKGTemplateDlg, CDialog)
	//{{AFX_MSG_MAP(CKGTemplateDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton3)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CKGTemplateDlg message handlers

BOOL CKGTemplateDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CKGTemplateDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CKGTemplateDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


void CKGTemplateDlg::OnButton2() 
{
	/*
	
	Bengaly Crack Me 3.0

	Key Generator
	12-12-01

	By: jK! [pGC]

	Comment:
				Thanks to Bengaly for providing me with 15 minutes of cracking pleasure ;)

				crack on crax0r0r. heh

algo routine:   
:0040130B 8B1D3F304000            mov ebx, dword ptr [0040303F]
:00401311 0FBE901F354000          movsx edx, byte ptr [eax+0040351F]
:00401318 2BDA                    sub ebx, edx
:0040131A 0FAFDA                  imul ebx, edx
:0040131D 8BF3                    mov esi, ebx
:0040131F 2BD8                    sub ebx, eax
:00401321 81C343353504            add ebx, 04353543
:00401327 03F3                    add esi, ebx
:00401329 33F2                    xor esi, edx
:0040132B B804000000              mov eax, 00000004
:00401330 49                      dec ecx
:00401331 75D8                    jne 0040130B
:00401333 56                      push esi
:00401334 683F314000              push 0040313F
:00401339 E84A000000              call 00401388
:0040133E 5E                      pop esi
:0040133F 3BC6                    cmp eax, esi */

CString username;
char user[100];
int len;
int retval;
char result[100];
char hash[] = " %@$erwr#@$$!@#21$@^&*&(%rthdhdfw423%#DSgfY$%^#$%bre#B@@ #G3re";
// Thankfully, i translated this string correctly, if not I probably would've scrapped
// this attempt on this crack me =)


m_username.GetWindowText(username);
wsprintf(user, "%s", username);
len = lstrlen(user);

if (len > 3) {

__asm {
	xor ebx, ebx
	xor edx, edx
	xor eax, eax
	xor ecx, ecx
	mov ecx, len
	mov eax, 0x00000001
_jK:
	mov ebx, dword ptr [user]
	movsx edx, byte ptr [eax+hash]
	sub ebx, edx
	imul ebx, edx
	mov esi, ebx
	sub ebx, eax
	add ebx, 0x04353543
	add esi, ebx
	xor esi, edx
	mov eax, 0x00000004
	dec ecx
	jne _jK

	mov retval, esi

}

wsprintf(result,"%lu",retval);
m_serial.SetWindowText(result);
} else {
	AfxMessageBox("Username must be greater than 3 chars!");
}


}
	



	

void CKGTemplateDlg::OnButton3() 
{
	AfxMessageBox("Bengaly's Crack Me [KeyGen Me] #3\n\nKey Generator by: jaykay < jK! / PGC >\n\nGreets to:\nAll of PGC, Webmasta, Lithium, Devine, f0dder, Sandman and Fravia.");
	
}
