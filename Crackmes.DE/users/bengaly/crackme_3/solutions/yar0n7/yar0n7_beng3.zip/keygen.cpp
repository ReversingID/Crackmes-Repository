#include <windows.h>
#include "resource.h"


BOOL CALLBACK DlgProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{	
	char name[64]={0x0};
	char pswd[64]={0x0};
	char tbl[]=" %@$erwr#@$$!@#21$@^&*&(%rthdhdfw423%#D";
	int len;
	DWORD tmp;
	switch (message)
	{    
	case WM_CLOSE:
		EndDialog(hWnd,0);
		break;
	case WM_COMMAND:
		{
			switch (LOWORD(wParam))
				{
					case ID_GENERATE:
						{
							len=GetDlgItemText(hWnd,ID_NAME,name,64);
							if (len){
							__asm{
								   mov ecx,len
								   mov eax,1	
								   again:                             
										mov     ebx, dword ptr[name]
										movsx   edx, tbl[eax] 
										sub     ebx, edx
										imul    ebx, edx
										mov     esi, ebx
										sub     ebx, eax
										add     ebx, 4353543h
										add     esi, ebx
										xor     esi, edx
										mov     eax, 4
										dec     ecx
									jnz     short again
									mov tmp,esi
								}
							wsprintf(pswd,"%lu",tmp);//Here we convert the
	//real serial from a number to a string.In the crackme, the entered serial
	//is converted to its decimal value for the check if the entered serial
	//is the right one.
							SetDlgItemText(hWnd,ID_PSWD,pswd);	
							}
							else 
								 MessageBox(hWnd,"Enter a name please!","",MB_OK);
	
							break;
						}

				}
		}

	}
   return 0;
}

int pascal WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nCmdShow)
{
  DialogBox(hInstance,MAKEINTRESOURCE(IDD_DIALOG1),NULL,(DLGPROC)DlgProc);
  return 0;
}

