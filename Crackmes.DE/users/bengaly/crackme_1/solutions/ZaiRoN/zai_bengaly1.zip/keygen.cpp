#include <stdio.h>
#include <string.h>
#include <conio.h>

int main()
{
        char name[15];
        int i;
        __int32 val=0;

        printf("keygen for Bengaly's first crackme");
        printf("\nby ZaiRoN\n");
        printf("\nyour name (length(name)>1): ");
        gets(name);
        for (i=0;i<(strlen(name)-1);i++)
        {
                val += (name[i]-0x2A) * (name[i+1]-0x41);
        }

        printf("\nand your serial: %u", val);
        getch();

        return 0;
}                

