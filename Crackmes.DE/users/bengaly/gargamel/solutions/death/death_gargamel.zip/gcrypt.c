/* Gargamel crypt algorithm implementation */
/* Key size = 512bits (effective: 256bits) */
#include <stdio.h>
#include <string.h>

#include "table.h"

/* Gargamel encryptor */
void Encrypt(unsigned char *pMsg, unsigned char *pKey, unsigned char *pOut, long lSize)
{
    long lCurrent;
    long lRemaining;
    long lIndex;

    lCurrent = 0;

    while (lCurrent < lSize) {
        lRemaining = lSize - lCurrent;
        lIndex = lRemaining >> 9;
        lRemaining ^= (long )pKey[lIndex * 2];
        lRemaining %= 0x1A;
        pOut[lCurrent] = pMsg[lCurrent] + (unsigned char )lRemaining;

        lCurrent++;
    }
}

/* Gargamel decryptor */
void Decrypt(unsigned char *pCipher, unsigned char *pKey, unsigned char *pOut, long lSize)
{
    long lCurrent;
    long lRemaining;
    long lIndex;

    lCurrent = 0;

    while (lCurrent < lSize) {
        lRemaining = lSize - lCurrent;
        lIndex = lRemaining >> 9;
        lRemaining ^= (long )pKey[lIndex * 2];
        lRemaining %= 0x1A;
        pOut[lCurrent] = pCipher[lCurrent] - (unsigned char )lRemaining;

        lCurrent++;
    }
}

int main(int argc, unsigned char *argv[])
{
    unsigned char *pInput;
    unsigned char *pOutput;
    FILE *pInFile;
    FILE *pOutFile;
    long lLength;

    if (argc < 4) {
        printf("Usage: gcrypt <input> <output> <E|D>\n");
        return(1);
    }

    pInFile = fopen(argv[1], "rb");
    if (pInFile) {
        pOutFile = fopen(argv[2], "wb");
        if (pOutFile) {
            lLength = _filelength(fileno(pInFile));
            pInput = (unsigned char *)malloc(lLength);
            if (pInput) {
                pOutput = (unsigned char *)malloc(lLength);
                if (pOutput) {
                    /* Read message */
                    fread(pInput, lLength, sizeof(unsigned char), pInFile);

                    /* Decrypt */
                    if (toupper(*argv[3]) == 'D')
                        Decrypt(pInput, KEY, pOutput, lLength);
                    else if (toupper(*argv[3]) == 'E')
                        Encrypt(pInput, KEY, pOutput, lLength);
                    else
                        printf("Fuckoff\n");

                    /* Write message */
                    fwrite(pOutput, lLength, sizeof(unsigned char), pOutFile);

                    free(pOutput);
                } else {
                    printf("Not enough memory for output buffer\n");
                    return(5);
                }
                free(pInput);
            } else {
                printf("Not enough memory for input buffer\n");
                return(4);
            }
            fclose(pOutFile);
        } else {
            printf("Error opening output file %s\n", argv[2]);
            return(3);
        }
        fclose(pInFile);
    } else {
        printf("Error opening input file %s\n", argv[1]);
        return(2);
    }

    return(0);
}
