;;;;;;;;;;;;;;;;;;;;
; -- Crackme #1 -- ;
;;;;;;;;;;;;;;;;;;;;

 This is the first crackme that i would say it's kinda descent to publis
 it's not very hard and  it's not very easy either, so it will need some
 patience  and skills to get the job done, i won't give  any description
 more than that, have fun ;)

 BTW: This is a more of a 2 in 1 Crackme :)


Email: sinclaire@xillioncomputers.com

Peace...Out
--
Sinclaire/DCA