				list of files		

solution.txt:			soultion to this crackme
crackme_original.exe:		original haystack 1 crackme (tested on Windows 7 and Windows XP-SP2)
crackme_patched.exe:		patched crackme (shows good boy message for any serial number like =>???)
keygen.exe:			key generator
haytracer.exe:			trivial tracer (traces programms protected by haystack 1) (tested on Windows 7 and Windows XPSP2)
deobf.idc:			jumps deobfuscator to IDA PRO (makes connections between decrypted chunks)
simplePwd_protected.exe:	simple console application protected with haystack 1.
simplePwd_unprotected.exe:	simple console application whithout protection.
msvcr71.dll,mfc71.dll:		mfc runtimes for crackme.
