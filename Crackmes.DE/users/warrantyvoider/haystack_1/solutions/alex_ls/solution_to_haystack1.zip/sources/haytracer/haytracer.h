#define _WIN32_WINNT 0x500
#include <windows.h>
#include <stdio.h>
#include <conio.h>

//RDTSC OPCODE
#define _rdtsc 0x310f
//POPAD OPCODE
#define _popad 0x61
//PUSHAD OPCODE
#define _pushad 0x60

