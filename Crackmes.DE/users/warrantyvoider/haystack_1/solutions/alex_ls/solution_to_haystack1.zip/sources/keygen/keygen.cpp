// keygen to BarbecueMe_1
// coded by alex_ls

// includes
#include "baseinit.h"

// global wnd variables
static HINSTANCE hInstance;
HICON hIcon;

void generate(char* sz_name)
{
	unsigned long hash,h1,h2;
	
	h1=*(unsigned long*)(sz_name+0x0)^0x84629517;
	h2=*(unsigned long*)(sz_name+0x4)^0x83620582;
	hash=h1*0x26F5^h2*0x26EF;
	for(unsigned char i=0;i<0x10;i++)
	{
		h1*=sz_name[i];
		hash^=h1;
	};
	hash&=0x7FFFFFFF;
	sprintf(sz_name,"=>%d",hash);
	return;
};

// generate serial
DWORD WINAPI create_serial(HWND hwnd)
{
	char    sz_name[0xff]={0};
	DWORD   dw_namelen;
	dw_namelen = GetDlgItemTextA(hwnd, IDC_NAME, (char*)sz_name, dw_namelen);
	
	// get username from dialog
	if ((dw_namelen >=8 )&& (dw_namelen <= 16))
	{
		generate(sz_name);
		SetDlgItemText(hwnd, IDC_SERIAL, sz_name);
	}
	else
		SetDlgItemText(hwnd, IDC_NAME, NAMELENGTH_ERROR);
	return 0;
}
// wndproc function
INT_PTR CALLBACK wnd_proc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam)
{
	switch (Message)
	{
		// init dialogbox
		case WM_INITDIALOG:
			
			SetWindowText(hwnd, NAME_INFO);
			SetDlgItemText(hwnd, IDC_NAME, "crackmes.de");
			SetDlgItemText(hwnd, IDC_SERIAL, "=>1803606519");
			SendDlgItemMessage(hwnd, IDC_NAME, EM_LIMITTEXT, MAX_NAME,0);
			SetFocus(GetDlgItem(hwnd,IDC_NAME));
			
			// Icon
			hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDD_DIALOG1));
			return true;
		break;

		// commands
		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
				// push generate button
				case IDC_CREATESERIAL:
					create_serial(hwnd);
					break;
				// push exit button
				case IDC_EXIT:
					EndDialog(hwnd, 0);
					break;
			}
		break;
		
		// exit prog
		case WM_CLOSE:
			EndDialog(hwnd, 0);
		break;
		
		default:
			return FALSE;
	}
	return TRUE;
}

// main func
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInst, LPSTR lpCmd, int nShow)
{
	hInstance = GetModuleHandle(NULL);
	hInst =		hInstance;
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, (DLGPROC)wnd_proc, (LPARAM)NULL);
	return 0;
}