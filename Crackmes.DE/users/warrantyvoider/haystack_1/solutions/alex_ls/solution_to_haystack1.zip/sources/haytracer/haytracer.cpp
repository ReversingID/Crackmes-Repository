#include "haytracer.h"

//logo stuff
void show_logo()
{
	printf("haytracer ver1.0\ncoded by alex_ls (2010)\n");
}

void show_usage()
{
	show_logo();
	printf("usage: haytracer trace_file trace_address\n");
	printf("press any key...");_getch();
};

unsigned long get_imgsize(unsigned long img_base, HANDLE h_proc)
{
	unsigned long  pe_offset,img_size,len;
	
	ReadProcessMemory(h_proc, (void*)(img_base+0x3c), &pe_offset,4,&len);
	ReadProcessMemory(h_proc, (void*)(img_base+pe_offset+0x50), &img_size,4,&len);
	return img_base+img_size;					

}

void set_breakpoint(HANDLE h_proc,void *address,unsigned char *orig)
{
	unsigned char bp=0xcc;
	unsigned long len;
	ReadProcessMemory (h_proc, address,orig,1,&len);
	WriteProcessMemory(h_proc, address,&bp,1,&len);
	return;
}
//main function
int main(int argc,char **argv)
{
	if(argc!=3)
	{
		show_usage();
		return -1;
	};

	show_logo();

	PROCESS_INFORMATION lp_process;
	LPCTSTR lp_appname=argv[1];
	LPCTSTR lp_curfolder=NULL;
	LPTSTR  lp_commandline=NULL;
	STARTUPINFO lp_startinfo;

	//get kiuser address
	FARPROC kiUser = GetProcAddress(GetModuleHandle("NTDLL"),"KiUserExceptionDispatcher");
	if(kiUser==0) return -1;

	//create a debug process
	GetStartupInfo(&lp_startinfo);
	BOOL b_res=CreateProcess(lp_appname, lp_commandline, NULL,	NULL, FALSE,DEBUG_PROCESS|DEBUG_ONLY_THIS_PROCESS,NULL,lp_curfolder,&lp_startinfo,&lp_process);
	
	if(b_res)
	{
		
		DEBUG_EVENT					debug_event;//debug event structure
		CONTEXT						ctx;		//thread context structure
		
		unsigned long	status;
		
		bool			b_active=true;

		unsigned long	trace_address;
		unsigned long	peb_debug;
		
		unsigned long	len=0;
		unsigned long	instruction_counter=0;
		
		unsigned long	peb;
		unsigned long	teb;
		unsigned long	img_size;
		unsigned long	img_base;
		
		unsigned char	orig_byte=0;
		unsigned short	rcheck;


		//main debug loop
		printf("please,wait for a while...\n");
		while(b_active)
		{
			WaitForDebugEvent(&debug_event, INFINITE);
			status=DBG_EXCEPTION_NOT_HANDLED;
			switch(debug_event.dwDebugEventCode)
			{
				case CREATE_PROCESS_DEBUG_EVENT:
				{
					//get img size
					img_base=(unsigned long)debug_event.u.CreateProcessInfo.lpBaseOfImage;
					img_size=get_imgsize(img_base,lp_process.hProcess);

					//get the TEB
					teb=(unsigned long)debug_event.u.CreateProcessInfo.lpThreadLocalBase;
					//get the PEB
					ReadProcessMemory(lp_process.hProcess, (void*)(teb+0x30), &peb,4,&len);
					//clear debug flag
					ReadProcessMemory(lp_process.hProcess, (void*)(peb), &peb_debug,4,&len);
					peb_debug&=0xff00ffff;
					WriteProcessMemory(lp_process.hProcess, (void*)(peb), &peb_debug,4,&len);

					//set brakepoint to trace address
					sscanf(argv[2],"%x",&trace_address);
					set_breakpoint(lp_process.hProcess,(void*)trace_address,&orig_byte);
					
					status=DBG_CONTINUE;
				};
				break;
				case EXIT_PROCESS_DEBUG_EVENT:
				{
					b_active=false;
					status=DBG_CONTINUE;
				};
				break;
				case EXCEPTION_DEBUG_EVENT:
				{
					if(debug_event.u.Exception.ExceptionRecord.ExceptionCode==EXCEPTION_BREAKPOINT)
					{
						ctx.ContextFlags=CONTEXT_CONTROL;
						GetThreadContext(lp_process.hThread,&ctx);
						//check ours breakpoints
						if(ctx.Eip==trace_address+1)
						{
							WriteProcessMemory(lp_process.hProcess,(void*)trace_address,&orig_byte,1,&len);
							ctx.Eip--;

							ReadProcessMemory (lp_process.hProcess,(void*)(ctx.Eip),&rcheck,2,&len);
							if(rcheck==_rdtsc)
							{
								rcheck=0xd233;
								WriteProcessMemory (lp_process.hProcess,(void*)(ctx.Eip),&rcheck,2,&len);
							};
							ctx.EFlags|=0x100;//set tf trap flag
							
							status=DBG_CONTINUE;
							SetThreadContext(lp_process.hThread,&ctx);
						};
					} else
					if(debug_event.u.Exception.ExceptionRecord.ExceptionCode==EXCEPTION_SINGLE_STEP)
					{
						ctx.ContextFlags=CONTEXT_CONTROL|CONTEXT_INTEGER;
						GetThreadContext(lp_process.hThread,&ctx);
						//check eip range while single step
						if((ctx.Eip<img_size)&&(ctx.Eip>img_base))
						{
							ReadProcessMemory (lp_process.hProcess,(void*)(ctx.Eip),&rcheck,2,&len);
							//if the current opcode is POPAD - dump it and exit
							if((rcheck&0xff)==_popad) 
							{
								printf("\nthe next chunk has been succesfully decrypted!\nyou may dump it with any tool you like!\nEIP=%04x\n\n",ctx.Eip);
								printf("press any key to continue if you have dumped it already...\n");_getch();
								instruction_counter=0;
								//b_active=false;
							} else
							//check if the current breakpoint is RDTSC - fix it
							if(rcheck==_rdtsc)
							{
								ctx.Eax=0;
								ctx.Edx=0;
								ctx.Eip+=2;
							};
							//set tf flag for single step tracing
							ctx.EFlags|=0x100;
							++instruction_counter;
						} else
						{	
							//exception is occured
							if((ctx.Eip-8<(DWORD)kiUser)&&(ctx.Eip+8>(DWORD)kiUser))
							{
								//get seh handler
								ReadProcessMemory(lp_process.hProcess, (void*)teb, &trace_address,4,&len);
								ReadProcessMemory (lp_process.hProcess,(void*)(trace_address+0x4),&trace_address,4,&len);
							}
							else
							//check either the new SEH handler was set or EIP to the next chunk has been changed
							{
								//get thread context
								ReadProcessMemory (lp_process.hProcess,(void*)(ctx.Ebp+0x10),&trace_address,4,&len);
								//get eip
								ReadProcessMemory (lp_process.hProcess,(void*)(trace_address+0xb8),&trace_address,4,&len);
							};
							//set new breakpoint and clear tf flag
							set_breakpoint(lp_process.hProcess,(void*)trace_address,&orig_byte);
							printf("instructions=%06d\r",instruction_counter);
						};
						//printf("exception address=%04x\n",ctx.Eip);
						status=DBG_CONTINUE;
						SetThreadContext(lp_process.hThread,&ctx);
					};
				};
				break;
			};
			ContinueDebugEvent(debug_event.dwProcessId,debug_event.dwThreadId,status);
		};
		
		CloseHandle(lp_process.hProcess);
		CloseHandle(lp_process.hThread);
	};
	return 0;
}


