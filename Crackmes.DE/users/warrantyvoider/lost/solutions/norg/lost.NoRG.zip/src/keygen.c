/*
Solving a maze (C)

(C) Weyfour WWWWolf, February/March 2000. Use as you see
fit (most likely 'rm -f maze.c' =), just give me credit.

<URL: http://www.iki.fi/wwwwolf/>
<wwwwolf@iki.fi>
http://www.beastwithin.org/users/wwwwolf/code/entertain/maze.c.gz
*/

#include <stdio.h>
#include <windows.h>
#include <commctrl.h> 
#include "resource.h"

HINSTANCE  hInst;
extern char maze[];
extern int  side_len, x_start, y_start, x_finish, y_finish;
extern void init(char *name);
extern void generate(void);


#define WALL '#'
#define FLOOR ' '
#define TRAVERSED '.'
#define PATH '*'
#define SMAX 0x2000
int stack[SMAX];
int sptr, x, y;

int  namelen;
char name[0x10], serial[0x1000], fake_wall = WALL;

/* Push number to stack */
void push(int n)
{
	if(sptr++ > SMAX) {
		exit(1);
	} else {
		stack[sptr] = n;
	}
}

int pop(void)
{
	if(--sptr < 0) {
		exit(1);
	} else {
		return(stack[sptr+1]);
	}
}

unsigned char *maze_XY(int x, int y){
	if (x < side_len && x >= 0 && y < side_len && y >=0)
		return &maze[x * side_len + y];
	else
		return &fake_wall;
}

void print_maze(char * name){
	char CRLF[2] = "\r\n";
	FILE  *f;
	int x, y;

	f = fopen(name, "wb");
	for (y = 0; y < side_len; y++ ){
		for (x = 0; x < side_len; x++){
			fwrite(maze_XY(x, y), 1, 1, f);
		}
		fwrite(&CRLF, 1, 2, f);
	}
	fclose(f);
}

BOOL solve(char set, char retreat)
{
	BOOL solved;
	x      = x_start; 
	y      = y_start;
	solved = FALSE;
	sptr   = 0;

//	print_maze("s0");

	*maze_XY(x_finish, y_finish) = FLOOR;

	push(x);
	push(y);

	while(!solved && sptr > 0) {
		if(x == x_finish && y == y_finish){
			serial[sptr/2-1] = 0;
			solved = TRUE;
			break;
		}

		*maze_XY(x, y) = set;

		if (*maze_XY(x-1, y) == FLOOR) { /* Free square in left */
			serial[sptr/2-1] = 'l';
			*maze_XY(x, y) = set;
			push(x);
			push(y);
			x = x-1;
		} else if (*maze_XY(x+1, y) == FLOOR) { /* Free square in right */
			serial[sptr/2-1] = 'r';
			*maze_XY(x, y) = set;
			push(x);
			push(y);
			x = x+1;
		} else if(*maze_XY(x, y+1) == FLOOR) { /* Free square in down */
			serial[sptr/2-1] = 'd';
			*maze_XY(x, y) = set;
			push(x);
			push(y);
			y = y+1;
		} else if(*maze_XY(x, y-1) == FLOOR) { /* Free square in up */
			serial[sptr/2-1] = 'u';
			*maze_XY(x, y) = set;
			push(x);
			push(y);
			y = y-1;
		} else { /* We ran into dead end */
			*maze_XY(x, y) = retreat;
			y = pop();
			x = pop();
		}
	}

//	print_maze("s1");

	return solved;
}
BOOL CALLBACK DialogProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{       
        switch (message)
        {    
        case WM_CLOSE:
                EndDialog(hWnd,0);
                break;
        case WM_COMMAND:
			switch (LOWORD(wParam)){ 
			case ID_GENERATE:
						ZeroMemory(name, sizeof(name));
                        namelen = GetDlgItemTextA(hWnd, IDC_NAME, name, 15);
                        if (namelen < 5 || namelen > 8){
                                SetDlgItemTextA(hWnd, IDC_SERIAL, "Name must be 5-8 chars");
                                break;
                        }

						init(name);
						generate();
						if (solve(PATH, TRAVERSED))
                            SetDlgItemTextA(hWnd, IDC_SERIAL, serial);
						else
							SetDlgItemTextA(hWnd, IDC_SERIAL, "unsolvable");
                break;
                }
        case WM_INITDIALOG:
                break;
        }
     return 0;
}

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{
        hInst=hInstance;
        DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, (DLGPROC)DialogProc,0);
        return 0;
}
