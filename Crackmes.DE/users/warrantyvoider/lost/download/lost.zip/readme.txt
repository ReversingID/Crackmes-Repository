Ok, this is an easy but hopefully fun one.

Figuring out how the serial works should be pretty easy.
Writing the keygen should be fun, but forget about bruteforcing.

There will be multiple valid serials for a username,
but will you find always the most efficient? (hint, hint)

- pure C
- no ASM
- my first keygen with NO OBFUSCATION AT ALL Yeah!


ps: get off your lazy butts and solve my other crackmes! ;-)