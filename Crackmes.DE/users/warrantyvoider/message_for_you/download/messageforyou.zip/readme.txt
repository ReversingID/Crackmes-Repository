Aren�t you bored of programs that always execute their instructions in the same order?
We simulate a message-driven application that executes not only the serial checker but also other less useful operations.

(Fear not: This is not the work of the dreaded Haystack-assembler-generator but real C++ created by a simple script.)

The serial checker is very simple and has only seven operations, the formula can be written in one line.

Difficulty: 3 if you have IDA PRO, more if you don't

====================

<rant>
I just grew grey hair trying to reverse/understand a certain real-world application.
Apps written in C lend themselves to reversing, apps written in high C++ for advanced object frameworks don't. 
The program logic tends to be terribly fragmented from an reversers point of view. Functions are never called directly but dynamically because of polymorphy.
Reference counting techniques result in pointers never pointing to anything remotely useful. 
My friends, I want to share my pain with you ;-)
Seriously, I just wanted to simulate one aspect of this program that I found particularly annoying: It was heavily message driven. How do you solve it?
</rant>
