void Generate(PCHAR Name, PCHAR Serial)
{
	unsigned long NameHash = 0;
	unsigned long NameHashFinal = 0;
	int i;
	int j;
	int NameLength;

	NameLength = strlen(Name);
	for(i=0;i<NameLength;i++)
	{
		for(j=0;j<NameLength;j++)
		{
			NameHash = NameHash + Name[i];
			NameHash = 2*NameHash;
			NameHash = NameHash^(2*(Name[i]+Name[j]));
			NameHashFinal = NameHashFinal+NameHash;
		}
	}
	NameHashFinal = (NameHashFinal - 0xf5a73c0);
	__asm{
		mov eax, NameHashFinal
		rol eax,0x15
		BSWAP eax
		rol eax,0x05
		mov NameHashFinal,eax
	}
	NameHashFinal = (NameHashFinal ^ 0x8D37423A);
	wsprintf(Serial,"%x",NameHashFinal);
	CharUpper(Serial);
}
