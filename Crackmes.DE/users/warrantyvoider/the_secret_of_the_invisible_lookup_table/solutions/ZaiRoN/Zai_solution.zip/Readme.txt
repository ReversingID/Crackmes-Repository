Hi.

What's that?
------------
Sorry but the zip file I wanted to submit is too big, 8Mb. I prefer to let you know what you are downloading before.

The zip file contains the tutorial, the keygen and an avi file; yes, it's a video tutorial. That's the reason why if you want to read it you have to download such a big file... 
I used a tool of mine that was born just for fun when I was trying to solve this crackme; I can't upload the tool because it's still under development, it's bugged and I really don't know if you'll find it usefull in some ways. So, I decided to make a video tutorial trying to explain you what I did and what it does.
However, you don't need this tool to solve the crackme, a ring0 debugger would suffice to follow the tutorial.

Now that you know everything from the pack you can download it from here:
http://woodmann.com/zairon/Zai_TableCrackMe.zip


Cheers,
ZaiRoN