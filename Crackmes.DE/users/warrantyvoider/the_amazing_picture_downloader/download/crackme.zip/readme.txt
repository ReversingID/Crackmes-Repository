Task:
	The program downloads pictures of cats and dogs, but the function that downloads pictures of beautiful women is disabled.
	Your task is to patch the program to enable the disabled function. 
	
Program:
	The program is just a regular Visual Studio C++ program. 
	But it is packed by the packer I�m developing.
	This is the third crackme packed with my packer. 
	deroko cracked the first two and wrote great tutorials.
	Maybe you would like to have a look at them.
	http://crackmes.de/users/warrantyvoider/the_amazing_unit_converter_patchme/
	http://crackmes.de/users/warrantyvoider/the_return_of_the_amazing_unit_converter/
	
Packer improvements:
	* imports protection improved
	* imports protection and decrypter tighter integrated
	* VC++ aligns functions at 16-Byte-Boundaries by filling with 0xCC. 
	  The packer now find these code caves and uses them in evil ways.
	* my first feeble attempt at protecting against dumping/attaching 
	* Getting the *#@�$%& packer to work with programs created by *#@�$%& Visual Studio 
	  was a *#@�$%& *#@�$%& if you know what I mean ;-)
	* still no protection against SOFTICE. If you know a cool trick, PM me!
	
	
Compatibility:
	XP only (W2K might or might not work).
	I tested on 4 different systems running XP.
	
	
	***************************************************************************	
	*=> You will need msvcr71.dll and mfc71.dll to run this program,          *
	*	 (program will crash or freeze if you don�t have them)                  *
	*   so get them at http://www.dll-files.com/  etc.                        *
	***************************************************************************
	
	
Acknowledgements:
	The image display and gui stuff is taken from an MSDN example app by Paul DiLascia.
	