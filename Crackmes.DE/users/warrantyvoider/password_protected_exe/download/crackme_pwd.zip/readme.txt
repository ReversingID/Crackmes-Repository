I have to stay in bed on doctors' orders. I'm bored. Good thing he didn't say anything about my laptop.  

There are a few programs out there that protect .EXE files with a password. It is hard to come up with a scenario where something like this would be useful (much less  paying $50 for it is justified). 

Anyway I tested three of these programs and had a bit of fun breaking them. The logic is mostly 

if (password == "password")
	runProgram();
else
	complain();

So you can break most of these protections by changing one byte. Some store the password in plaintext in the .EXE, etc. Still bored out of my skull, I wrote password-protect-EXE-file-program of my own. It actually uses a cool new concept called encryption, so you might have to brute-force it. (Should only take seconds, the password is VERY easy).

When I tested it I ran into some unexpected trouble that might impact the stability of the target program. I did an ugly hack to ignore this problem and this target .exe seems to run fine, but I'm not happy. Can you tell what I am talking about?

Have fun!
WV