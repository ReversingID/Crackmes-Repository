#include <windows.h>
#include "resource.h"
#include <stdio.h>
#include <math.h>
#define WIN32_LEAN_AND_MEAN

unsigned long nh1 (char *name)
{
	unsigned long var1=0x19919;
	unsigned long var2=0x955D;
	unsigned long var3=0x375D;
	unsigned long h;
	char *ptr=name;
	while (*ptr!='\0')
	{
		long ch;
		ch = *ptr;
		var1 *= ch;
		var1 += 0x0F791;
		var2 += ch;
		var2 *= 0x162DF;
		var3 *= 5;
		var3 ^= ch;
		ptr++;
	}
	h = var1;
	h ^= var2;
	h ^= var3;
	h %= 0x4ED759F;
	return h;
}

unsigned long nh2 (char *name)
{
	unsigned long h=0;
	long ch;
	char *ptr=name;
	int ctr=0;
	while (ctr!=0x7B)
	{
		if (*ptr=='\0')
			ptr=name;
		ch = *ptr;
		h += ch;
		h *= 0x16D71;
		h *= ch;
		h += 0x15661;
		ptr++;
		ctr++;
	}
	h %= 0x183ECF3;
	return h;
}

unsigned long f(unsigned long diff) // Not used in Key generation
{ 
	unsigned long d1,d2;
	float f1,f2; 
	unsigned long s;
	unsigned int i;

	d1=d2=diff; 
	d1 = d1>>1; 

	f1 = (float) d1; 
	f1 =f1 * 2; 
	d2 = diff & 1; 

	f2 = (float) d2; 
	f1 += f2; 
	f2 = sqrt(f1); 
	f2 = floor(f2); 
	d2 = f2; 
	d2 += 1; 
	s=1;  
	for (i=2;i<d2;i++) 
	{ 
		if (diff%i==0) 
			s += i + (diff/i); 
	} 
	return s; 
}

BOOL CALLBACK DlgProc (HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
	char name[21];
	unsigned long n1=32685250,n2=34538270;
	char str1[21],str2[21];
	switch (msg)
	{
	case WM_COMMAND:
		switch (LOWORD(wParam)) 
		{
		case IDNAME :
			GetDlgItemText(hWnd,IDNAME,name,20);
			if (lstrlen(name)<6)
			{
				SetDlgItemText(hWnd,IDMESG,"Name must be atleast 6 chars");
				SetDlgItemText(hWnd,IDSERIAL1,"");
				SetDlgItemText(hWnd,IDSERIAL2,"");
			}
			else
			{
				n1 += nh1(name);
				n2 += nh2(name);
				sprintf (str1,"%u",n1);
				sprintf (str2,"%u",n2);
				SetDlgItemText(hWnd,IDMESG,"Serial Is :");
				SetDlgItemText(hWnd,IDSERIAL1,str1);
				SetDlgItemText(hWnd,IDSERIAL2,str2);
			}
		}
		return TRUE;
	case WM_CLOSE:
		EndDialog(hWnd,0);
		return TRUE;
	}
	return FALSE;
}



int APIENTRY WinMain(HINSTANCE hinst, HINSTANCE hinstPrev, LPSTR lpCmdLine, int nCmdShow)
{
	return(DialogBox(hinst,MAKEINTRESOURCE(IDD_DIALOG1),0,DlgProc));
}

