The serial algorithm contains a mathematical riddle you might have heard of already.
Bonus points for recognising/googleing it instead of bruteforcing.

protection:
=> Building upon the tech of haystack0.2 I again encrypted some functions. This time there�s more obfuscation in the crypter/decrypter, but this can�t stop you, right?
=> and there�s a little annoying obfuscation macro in the c code
=> No debugger detection (we have to save something for haystack0.4 ...)

Have fun, write a keygen!
WV