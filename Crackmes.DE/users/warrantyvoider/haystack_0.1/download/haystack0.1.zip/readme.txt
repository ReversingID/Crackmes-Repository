Ok, a while back I tested my wannabe-exe-protector on you, and 
didn�t get any feedback. (http://crackmes.de/users/warrantyvoider/haystack_1/) 
I guess it was too tedious, and i labeled the problem as level 5 
while it should probably have been at least a 7.
I�m really sorry to have frustrated you.

So now for a second round, a simple crackme. One function (guess which?)
is protected by the exe-protector with all options turned off.

=> no debugger detection
=> no obfuscation
=> simple XOR "encryption"

This is to get you familiarised with the concept.

Have fun, write a keygen!

VW
