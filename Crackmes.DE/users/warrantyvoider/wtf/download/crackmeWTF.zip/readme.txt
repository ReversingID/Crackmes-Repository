This one does a really weird thing I haven�t seen in any other crackme, have fun figuring it out.
100% pure ANSI-C, no inline assembly.

It�s a lot less scary than it looks. At some point you should scream "HEUREKA!"...

protection:
Strings are haystack-obfuscated not to make it too obvious.
(There�s no need to break the string encryption, DON'T WASTE YOUR TIME!)

Have fun, write a keygen!
WV