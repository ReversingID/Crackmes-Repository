#include <windows.h>
#include <stdio.h>
#include "resource.h"

char * generate (char * tname)
{
	//DWORD tmp;
	char name[9];
	unsigned long serial;
	unsigned long local3=0xDEADBEEF ^ 0x44;
	char str[]="This pro";
	char *ptr=name;
	int i;
	lstrcpy(name,tname);
	for (i=0;i<8;i++)
	{
		name[i] ^= str[i];
	}
	_asm
	{
		push eax
		push edx
		push ecx
		mov eax, dword ptr name
		mov edx,0dh
		mul edx
		mov ecx,dword ptr local3
		mul ecx
		mov ecx,0FF9Dh
		xor edx,edx
		div ecx
		lea eax, dword ptr [edx+edx]
		shr eax,1
		xor eax,1
		sub eax,0Dh
		shl eax,2
		mov dword ptr [serial],eax
	
		mov eax,92492492h
		mov edx, dword ptr [serial]
		mov ecx,92492492h
		div ecx
		mov eax,92492492h
		sub eax,edx
		mov edx, dword ptr [serial]
		mov ecx,92492492h
		div ecx
		mov dword ptr[serial],eax

/*		xor eax,eax
		mov dword ptr[tmp],eax
		jmp start
reloop:
		mov eax,dword ptr [tmp]
		add eax,1
		mov dword ptr [tmp], eax
start:
		mov edx,dword ptr [serial]
		mov ecx,92492492h
		div ecx
		test edx,edx
		jnz reloop
		mov dword ptr [serial],eax
		*/
		pop ecx
		pop edx
		pop eax
	}
	sprintf (name,"%ld",serial);
	strcpy (tname,name);
	//MessageBox(0,name,"SERIAL",0);
	return tname;
}


BOOL CALLBACK KeyFunc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
	char name[21];
	int nlen;
	switch (msg)
	{
	case WM_COMMAND :
		switch (LOWORD(wParam)) 
		{
		case IDNAME :
			GetDlgItemText(hWnd,IDNAME,name,20);
			nlen = lstrlen(name);
			if (nlen<5 || nlen>8)
				SetDlgItemText(hWnd,IDSERIAL,"Name must be 5-8 chars");
			else
				SetDlgItemText(hWnd,IDSERIAL,generate(name));
		}
		return TRUE;
	case WM_CLOSE:
		EndDialog(hWnd,0);
		return TRUE;
	}
	return FALSE;
}

int WINAPI WinMain (HINSTANCE hinst,HINSTANCE hPrevInst,LPSTR lpCmd,int nCmdShow)
{
	return(DialogBox(hinst,MAKEINTRESOURCE(IDD_DIALOG1),0,KeyFunc));	
}
