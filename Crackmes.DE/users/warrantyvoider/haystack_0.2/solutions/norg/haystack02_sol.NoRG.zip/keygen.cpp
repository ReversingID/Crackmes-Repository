#include <windows.h>
#include <stdio.h>
#include <conio.h>

char *part0[] = {
	"Bill Gates ", "Linus Thorwald ", "Some guy ", "The cow ", "The pizza ", "Cthulhu ", "My lawyer ", 
	"Everybody ", "Elvis ", "Santa Claus ", "Chewing gum ", "Your mother ", "Arthur Dent "};

char *part1[] = {
	"killed ", "stole ", "kisses ", "secretly loves ", "paints ", "reads ", "eats ", "dismisses ", "publicly criticises " };

char *part2[] = {
	"typewriters ", "Ollydbg ", "princess Leia ", "Denmark ", "cellphones ", "seven dwarves ", "navel fluff ", 
	"beer ", "lipstick ", "the Pope ", "the meaning of life "};

char *part3[] = {
	"and ", "because ", "but ", "until ", "for it is foretold that ", "while "};

char *part4[] = {
	"your missing sock ", "Mozart ", "the universe ", "nobody ", "my playstation ", 
	"the girl next door ", "everything you ever wanted "};

char *part5[] = {
	"should be kept refridgerated.", "spontaneously combusts.", "can't sing.", "is missing a tooth.",
	"doesn't have a spam filter.", "sucks.", "dumped core.", "feels a disturbance in the force.",
	"is machine washable."};

char name[0x100];
char serial[0x100];
int  code[6], name_seed;

int get_name_seed()
{
	int var1, var2, var3;
	char *curchar = &name[0];
	__asm{
		mov		var1, 0EEA3h
		mov		var2, 195A3h
		mov		var3, 17E7Fh

	loc_40112E:
		mov		ecx, curchar					; <- name
		movsx	edx, byte ptr [ecx]
		test	edx, edx
		jz		short loc_401189
							
		mov		eax, curchar
		
		movsx	ecx, byte ptr [eax]
		imul	ecx, var1
		mov		var1, ecx
		
		mov		edx, var1
		add		edx, 17299h
		mov		var1, edx
		
		mov		eax, curchar
		movsx	ecx, byte ptr [eax]
		add		ecx, var2
		mov		var2, ecx
		
		mov		edx, var2
		imul	edx, 18757h
		mov		var2, edx
		
		mov		eax, var3
		shl		eax, 2
		mov		var3, eax
		
		mov		ecx, curchar
		movsx	edx, byte ptr [ecx]
		xor		edx, var3
		mov		var3, edx
		
		mov		eax, curchar
		add		eax, 1
		mov		curchar, eax
		
		jmp		short loc_40112E
		
	
	loc_401189:	   
		
		mov		ecx, var1
		xor		ecx, var2
		xor		ecx, var3

////after call

		mov     eax, ecx
		xor     edx, edx
		mov     ecx, 486486
		div     ecx
		mov     eax, edx
	}
}

int main(int argc, char *argv[])
{
	printf("warrantyVoider's haystack 0.2 -- keygen by NoRG.\n");
	printf("==========\n\n\n");

bad_name:

	printf("Enter your name : ");
	gets(name);

	if (strlen(name) < 5) {
		printf("Please at least 5 chars!\n\n\n");
		goto bad_name;
	}

	name_seed = get_name_seed();

	code[5]   = name_seed / 54054;
	if (code[5] >= sizeof(part5) / sizeof(part5[0]))
		code[5] = sizeof(part5) / sizeof(part5[0]) - 1;
	name_seed = name_seed - code[5] * 54054;

	code[4]   = name_seed / 7722;
	if (code[4] >= sizeof(part4) / sizeof(part4[0]))
		code[4] = sizeof(part4) / sizeof(part4[0]) - 1;
	name_seed = name_seed - code[4] * 7722;

	code[3]   = name_seed / 1287;
	if (code[3] >= sizeof(part3) / sizeof(part3[0]))
		code[3] = sizeof(part3) / sizeof(part3[0]) - 1;
	name_seed = name_seed - code[3] * 1287;

	code[2]   = name_seed / 117;
	if (code[2] >= sizeof(part2) / sizeof(part2[0]))
		code[2] = sizeof(part2) / sizeof(part2[0]) - 1;
	name_seed = name_seed - code[2] * 117;

	code[1]   = name_seed / 13;
	if (code[1] >= sizeof(part1) / sizeof(part1[0]))
		code[1] = sizeof(part1) / sizeof(part1[0]) - 1;
	name_seed = name_seed - code[1] * 13;
	code[1] = 8 - code[1];

	code[0]   = name_seed;
	if (code[0] >= sizeof(part0) / sizeof(part0[0])) {
		printf("Can't find serial for your name.");
	} else {
		sprintf(serial, "%s%s%s%s%s%s", 
			part0[code[0]], part1[code[1]], part2[code[2]], 
			part3[code[3]], part4[code[4]], part5[code[5]]);
		
		printf("Passphrase :\n\n%s", serial);
	}
	
	getch();

	printf("\n\nPress enter...");


	return TRUE;
}
