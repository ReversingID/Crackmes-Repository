/*
Note: I do know that the methods i use may be
shortened up considerably but this is to show
"newbies" in C++ how to manipulate the code 
themselves easily and understand what's going
on. As well as showing a near direct representation
of what was happening in the ASM code, into C++
*/

#include <windows.h> //*
#include <iostream>  //* Included headers, some aren't really neccessary, but i just slapped them on lol  
#include <cmath>     //*
using namespace std; // using a standard namespace
int main () {       // this is where the main program will be at
    int a, x, i, s; //intergers to be used when dealing with...intergers (note: i just ealized it spells out "axis", did not know that honest, i was just writing random chars to be used s the variables
    int holdera, holderb, holderc; //extra varialbes to deal with placeholding numbers and the such
    char rail[256]; //first array  - Takes entered username and sperates al the chars into each special pcket of its own
    char rail2[256];//2nd array - will pop the serial chars into this one
    char t, c;     //Chars to manipulate to put into char arrays
    cout<<"Heya! Type in your username: "; //speaks for itself eh? cout = Console OUTput
cin.getline(rail, 256);                   // cin = Console INput, .getline takes the entire line, including spaces and puts ito array "rail" and it'll take a max of 256 members
a = strlen(rail);                         //sets int a = the string length of rail
i = 0;             //Self explanatory
s = 0;            //Self Explanatory
while ( i <= a ) { //While i is less then or equal to a......
      t = rail[i]; //char t will equal the corresponding value ifrom the user's input
      x = int(t); //int x will equal the ASCII value of the char t
      holdera = x - 2; // holdera will equal that hex value - 2 (first part of the scheme A*A*A*A*)
      t = char(holdera); //convert the ASCII value of holdera back into a char
      rail2[s] = t;     //Serial array will contain the value of t
      holdera = x * 103; //holdera is "erased" and now equals the original ASCII value of the char times 103
      holderb = holdera >> 8; //holderb = holdera shift right logically 8 units 
      holdera = holderb >> 2; //holdera = holderb shift right logically 2 units
      holderc = holdera + x; //Holderc = holdera + original ASCII value of char
      s += 1;                //S = S + 1; (inorder to move to next position in solution array)
      holderc -= 2;         //holderc = holderc - 2;
      c = char(holderc);    // char c = char value of holderc
      rail2[s] = c;         //solution array = char c
      s += 1;              //increase s by 1 to go to next spot in solution array
      i += 1;              //increase i by 1 to go to next spot in entered username as well as to increment to a point out of this loop
      } //end of loop go back to top
system("cls");  //clear screen
cout<<"Your serial is : "; //self explanatory
i = 0; //reset i to 0
a = a * 2; //takes original length of entered username and multiply by 2 (because of solution array has 2 chars for ever username 1 char
while ( i < a ) { //begin loop: while i is less then a
      cout<<rail2[i]; //output the value of solution array , starting from begining
      i += 1; //increase i by one so you can slowly increment throughout the array, displaying the serial chars on screen
      } //end loop, go back to top
      cin.ignore(); //incase the program presses "enter", it will ignore that
      cin.get(); //wait for user to type in enter
      return(0); // return "0" to program saying it succesfully executed
      } //end of main function
