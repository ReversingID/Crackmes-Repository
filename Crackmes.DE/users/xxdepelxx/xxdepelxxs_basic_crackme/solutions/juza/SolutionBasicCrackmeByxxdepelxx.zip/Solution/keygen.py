username = "iamjuza"
serial2 = "Shooter"
serial1 = ""

serial1 = "SCT-" + username[len(username) - 3:] + str(len(username)) + username[:3]

print "Username:", username
print "Serial 1:", serial1
print "Serial 2:", serial2