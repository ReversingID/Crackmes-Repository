﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace CrackMeSolution1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Rijndael RJ = Rijndael.Create();
        MD5CryptoServiceProvider MD = new MD5CryptoServiceProvider();
        string key = "!@#$%^&*(){}?/>.<,\"':;][/*-+~`";
        string EncryptedText = "0JcT5U3uSlmaNmEJnzPg+/OL2z5RngZt0UJGUiyvF/HHz7wbKlKp+cUFzLrQOLgi";

        private void Form1_Load(object sender, EventArgs e)
        {
            this.label1.Text = "DragonPxX's crack me or keygen me solution // Protection: Hardcoded Rijndael Encryption";
            this.Text = "DragonPxX's crack me or keygen me solution";
            this.RJ.Key = MD.ComputeHash(Encoding.ASCII.GetBytes(this.key));
            this.RJ.Mode = CipherMode.ECB;
            byte[] inputBuffer = Convert.FromBase64String(EncryptedText);
            textBox1.Text =  Encoding.ASCII.GetString(this.RJ.CreateDecryptor().TransformFinalBlock(inputBuffer, 0, inputBuffer.Length));

        }
    }
}
