Compressed serial 
disabled buttons 
.net 3.5 
=================
contact : progvig@yahoo.com