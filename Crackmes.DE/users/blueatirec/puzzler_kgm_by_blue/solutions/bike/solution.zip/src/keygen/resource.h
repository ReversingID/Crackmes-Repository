#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDD_DIALOG                              101
#define IDC_GENERATE                            1004
#define IDC_CLOSE                               1005
#define IDC_EDIT                                1006
