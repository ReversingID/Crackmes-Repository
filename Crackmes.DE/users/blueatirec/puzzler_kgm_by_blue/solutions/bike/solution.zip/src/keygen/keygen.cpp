#include <windows.h>
#include <time.h>
#include "resource.h"
#include "wincrypt.h"
#pragma comment(lib, "crypt32.lib")

char        key[100];
//---------------------------------------------------------------------------
HWND hWnd;
LRESULT CALLBACK DlgProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);
void Keygen();
DWORD GenerateNumber();
void ExpandBits(char *, char *, DWORD *);
BOOL Base64Encode(unsigned char *, DWORD, unsigned char *, DWORD *);
//---------------------------------------------------------------------------
INT WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine, int nCmdShow)
{
    DialogBox(hInstance, MAKEINTRESOURCE(IDD_DIALOG),
              hWnd, (DLGPROC)DlgProc);

    return FALSE;
}
//---------------------------------------------------------------------------
LRESULT CALLBACK DlgProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
    switch(Msg)
    {
    case WM_INITDIALOG:
        srand(time(0));
        SetFocus(GetDlgItem(hWnd, IDC_GENERATE));
        break;
    case WM_CLOSE:
        DestroyWindow(hWnd);
        break;
    case WM_COMMAND:
        switch(wParam)
        {
        case IDC_GENERATE:
            Keygen();
            SetDlgItemTextA(hWnd, IDC_EDIT, key);
            return TRUE;
        case IDC_CLOSE:
            DestroyWindow(hWnd);
            break;
        }
        break;
//    default:
  //      return DefWindowProc(hWnd, Msg, wParam, lParam);
    }
    return FALSE;
}
void Keygen()
{
    DWORD       dwLen=100, len;
    char        szNumber[100];
    char        binaryKey[100];

    // transform valid number to string
    itoa(GenerateNumber(), szNumber, 10);
    // from each bit B from the string makes a random byte but with lsb=B
    ExpandBits(szNumber, binaryKey, &len);
    // convert the resulted buffer to base64, this is the initial key
    Base64Encode((BYTE*)binaryKey, len, (BYTE*)key, &dwLen);
}

// Generate an 8 digit number(in base 10) whose digit sum % 8 = 4
DWORD GenerateNumber()
{
    int         i;
    DWORD       number;
    DWORD       digit;
    DWORD       sum;

    // random the first 6 digits
    // avoid 1 as first digit, to avoid 12345678 by chance
    number = rand() % 8 + 2;
    sum = number;
    for (i=0; i<5; i++)
    {
        digit = rand() % 10;
        number = number * 10 + digit;
        sum += digit;
    }
    // make the seventh digit so that the sum so far is multiple of 8
    digit = 8;
    if (sum % 8 != 0) digit = 8 - sum % 8;
    number = number * 10 + digit;
    // the last digit is 4
    number = number * 10 + 4;
    return number;
}

void ExpandBits(char *modifiedKey, char *key, DWORD *length)
{
    size_t      len;
    int         i,j,k;

    len = strlen(modifiedKey);
    k = 0;
    for (i=0; i<len; i++)
    {
        for (j=7; j>=0; j--)
        {
            // byte should not be 0, because in crackme 0 means end of buffer
            key[k] = (rand() % 0x100) | 3;
            key[k] = (key[k] << 1) | ((modifiedKey[i] >> j) & 1);
            k++;
        }
    }
    key[k] = 0;
    *length = k;
}
BOOL Base64Encode(unsigned char *buffer, DWORD len, unsigned char *buffer64, DWORD *len64)
{
    DWORD       i;
    DWORD       l;
    unsigned char base64[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

    l = len/3;
    for (i=0; i<l; i++)
    {
        buffer64[i*4]     = base64[buffer[i*3] >> 2];
        buffer64[i*4 + 1] = base64[((buffer[i*3] & 3) << 4) | (buffer[i*3 + 1] >> 4)];
        buffer64[i*4 + 2] = base64[((buffer[i*3 + 1] & 0xf) << 2) | (buffer[i*3 + 2] >> 6)];
        buffer64[i*4 + 3] = base64[buffer[i*3 + 2] & 0x3f];
    }
    if (len % 3 == 1)
    {
        buffer64[l*4]     = base64[buffer[l*3] >> 2];
        buffer64[l*4 + 1] = base64[(buffer[i*3] & 3) << 4];
        buffer64[l*4 + 2] = buffer64[l*4 + 3] = '=';
        *len64 = (l + 1) * 4;
    }
    else
    if (len % 3 == 2)
    {
        buffer64[l*4]     = base64[buffer[l*3] >> 2];
        buffer64[l*4 + 1] = base64[((buffer[l*3] & 3) << 4) | (buffer[l*3 + 1] >> 4)];
        buffer64[l*4 + 2] = base64[((buffer[l*3 + 1] & 0xf) << 2)];
        buffer64[l*4 + 3] = '=';
        *len64 = (l + 1) * 4;
    }
    else
    {
        *len64 = l * 4;
    }
    buffer64[*len64] = 0;
    return TRUE;
}
