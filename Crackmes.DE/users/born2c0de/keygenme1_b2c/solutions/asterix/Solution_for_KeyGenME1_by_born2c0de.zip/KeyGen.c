#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define  MAX  256

void term(void);

int main(void)
{
    char name[MAX];
    unsigned len, i, val;

    atexit(term);
   
    printf("KeyGen for [KeyGenME #1 by born2c0de] by @sterix\n");

    printf("\nEnter name: ");
    gets(name);        

    len = strlen(name);

    if (len < 3) {
	fprintf(stderr, "\nERROR: The length of name needs 3 or more characters.\n");
	return 1;
    }

    if (len % 2 == 0) {
	fprintf(stderr, "\nERROR: The length of name needs parity.\n");
	return 2;
    }

    for (i = 0, val = 0; i < len; i += 2)
	val += (unsigned char)name[i] * (unsigned char)name[i+1];

    val += name[strlen(name) - 1] * 123;

    printf("\nYour Serial: %X\n", val);

    return 0;
}

void term(void)
{
    system("pause");
}