[README]

:Keygenme1_b2c by born2c0de


: Create a Keygen for this Program.
: Patching Not Allowed.
: The algorithm is really simple but the hard part is to understand the code,
   since it is in 16 bit ASM (and may be packed).

All the Best!!!