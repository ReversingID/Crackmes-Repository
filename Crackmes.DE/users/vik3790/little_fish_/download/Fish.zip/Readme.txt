Well people, this is my first crackme, the algorithm to get the password is
very easy, but you need to find a way to open the window that allows you to 
enter your user name and password.
I hope you enjoy it and find it interesting.
Don�t forget to write a keygen and a tutorial.