#include <stdio.h>
#include <string.h>
#include <stdlib.h>

//The possible characters in the password, Modify as needed
static const char charset[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ";
static int serial_len;
static char* serial;

unsigned int calcValue()
{
    unsigned int hardcoded = 0x1337C0DE, i = 0;
    
    while(1)
    {        
        hardcoded += *((unsigned int*)&serial[i]);
        if (serial[i] == 0xA) break;
        i++;
    }
    return hardcoded;
}

int bruteforce(int chPos)
{
    for (int i = 0; i < strlen(charset); i++)
    {
        serial[chPos] = charset[i];
        
        if (chPos < serial_len - 1)
        {
            if (bruteforce(chPos + 1)) return 1;
        }
        
        else if (calcValue() == 0xA4F4CAB) return 1;        
    }
    return 0;    
}

int main()
{
    printf("Enter the length of serial: ");
    scanf("%d", &serial_len);
    
    if (!serial_len) return 1;
    
    printf("\nBruteforcing serials of length %d...\n", serial_len);
    
    serial = (char*) malloc(serial_len + 10); //Let's keep some extra space
    memset(serial, 0, serial_len + 10);
    
    serial[serial_len] = 0x0D;
    serial[serial_len + 1] = 0x0A;
    
    if (bruteforce(0))
        printf("Serial Found: %s", serial);
    else
        printf("No serials of length %d could be found.\n", serial_len);    
    
    free(serial);
    return 0;
}