#include <stdio.h>
#include <string.h>

int main()
{
    char serial[400];
    memset(serial, 0, 400);
    
    puts("Enter the password : ");
    gets(serial);
    
    strcat(serial, "\x0d\x0a");
    
    unsigned int hardcoded = 0x1337C0DE, i = 0;
    
    while(1)
    {        
        hardcoded += *((unsigned int*)&serial[i]);
        i++;
        if (serial[i] == 0xA) break;        
    }
    printf("\nFinal value: 0x%08X\n", hardcoded);   //Must be 0xA4F4CAB
    return 0;
}