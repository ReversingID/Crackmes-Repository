import struct
import immlib

DESC = 'An Immunity Debugger PyCommand for disassembling nop-vm'

dbg = immlib.Debugger()

def disasm(code):
    '''
    @param code The Code Buffer
    @return (string representation of instr, instr length)
    '''
    b1 = struct.unpack_from('<B' ,code, 0)[0]

    if b1 != 0x65: b2 = struct.unpack_from('<B', code, 1)[0]

    if b1 == 0x65:  # exit_vm
        return ('ret', 1)

    elif b1 == 0x75: # vmcall
        dword = struct.unpack_from('<I', code, 3)[0]
        return ('vmcall 0x%X' %(dword), 7)

    elif b1 == 0x97:
        r1 = struct.unpack_from('<B' ,code, 3)[0]
        if b2 == 0xAE:  # mov <r1>, <r2>
            r2 = struct.unpack_from('<B' ,code, 4)[0]
            return ('mov r_%s, r_%s' %(r1, r2), 5)
        elif b2 == 0xFF:    # mov <r1>, dword
            dword = struct.unpack_from('<I', code, 4)[0]
            return ('mov r_%s, 0x%X' %(r1, dword), 8)

    elif b1 == 0x59:
        if b2 == 0xAE:  # push <r1>
            reg = struct.unpack_from('<B', code, 3)[0]
            return ('push r_%s' %(reg), 4)
        elif b2 == 0xFF:    # push <dword>
            dword = struct.unpack_from('<I', code, 3)[0]
            return ('push 0x%X' %(dword), 7)

    elif b1 == 0xE8:
        if b2 == 0xAE: # call <r1>
            reg = struct.unpack_from('<B', code, 3)[0]
            return ('call r_%s' %(reg), 4)
        if b2 == 0xFF: # call <dword>
            dword = struct.unpack_from('<I', code, 3)[0]
            return ('call 0x%X    ;%s' %(dword, dbg.getComment(dword)), 7)

    elif b1 == 0xF6:
        r1 = struct.unpack_from('<B', code, 3)[0]
        if b2 == 0xAE: # cmp <r1>, <r2>
            r2 = struct.unpack_from('<B', code, 4)[0]
            return ('cmp r_%s, r_%s' %(r1, r2), 5)
        elif b2 == 0xFF:    # cmp <r1>, <dword>
            dword = struct.unpack_from('<I', code, 4)[0]
            return ('cmp r_%s, 0x%X' %(r1, dword), 8)

    elif b1 == 0x4B:
        if b2 == 0xAE: # jmp <r1>
            reg = struct.unpack_from('<B', code, 3)[0]
            return ('jmp r_%s' %(reg), 4)
        elif b2 == 0xFF: # jmp <dword>
            dword = struct.unpack_from('<I', code, 3)[0]
            return ('jmp 0x%X' %(dword), 7)

    elif b1 == 0xAE:
        if b2 == 0xAE: # jz <r1>
            reg = struct.unpack_from('<B', code, 3)[0]
            return ('jz r_%s' %(reg), 4)
        elif b2 == 0xFF: # jz <dword>
            dword = struct.unpack_from('<I', code, 3)[0]
            return ('jz 0x%X' %(dword), 7)

    elif b1 == 0x13:
        if b2 == 0xAE: # jnz <r1>
            reg = struct.unpack_from('<B', code, 3)[0]
            return ('jnz r_%s' %(reg), 4)
        elif b2 == 0xFF: # jnz <dword>
            dword = struct.unpack_from('<I', code, 3)[0]
            return ('jnz 0x%X' %(dword), 7)

    elif b1 == 0x33:
        r1 = struct.unpack_from('<B', code, 3)[0]
        if b2 == 0xAE: # mov <r1>, dword ptr [<r2>]
            r2 = struct.unpack_from('<B', code, 4)[0]
            return ('mov r_%s, dword ptr [r_%s]' %(r1, r2), 5)
        elif b2 == 0xFF: # mov <r1>, dword ptr [<dword>]
            dword = struct.unpack_from('<I', code, 4)[0]
            return ('mov r_%s, dword ptr [0x%X]' %(r1, dword), 8)

    elif b1 == 0xA1:
        r1 = struct.unpack_from('<B', code, 3)[0]
        if b2 == 0xAE: # and <r1>, <r2>
            r2 = struct.unpack_from('<B', code, 4)[0]
            return ('and r_%s, r_%s' %(r1, r2), 5)
        elif b2 == 0xFF: # and <r1>, <dword>
            dword = struct.unpack_from('<I', code, 4)[0]
            return ('and r_%s, 0x%X' %(r1, dword), 8)

    elif b1 == 0x1D:
        r1 = struct.unpack_from('<B', code, 3)[0]
        if b2 == 0xAE: # add <r1>, <r2>
            r2 = struct.unpack_from('<B', code, 4)[0]
            return ('add r_%s, r_%s' %(r1, r2), 5)
        elif b2 == 0xFF: # add <r1>, <dword>
            dword = struct.unpack_from('<I', code, 4)[0]
            return ('add r_%s, 0x%X' %(r1, dword), 8)
        
    else:
        return ('Undefined Opcode', -1)

def main(args):    
    if not args:
        dbg.log('Usage: !disasm <start address>', 0)
        return 'Insufficient arguments; check log for details'            
    start = int(args[0], 16)
    
    dbg.log('', 0)  # Add blank line
    dbg.log('Disasembling from 0x%X ' %(start), 0, True)
    
    disas_offset = 0
    while True:
        (strrep,i_len) = disasm(dbg.readMemory(start + disas_offset, 10))
        if i_len == -1:
            break        
        dbg.log(strrep, start + disas_offset)
        disas_offset += i_len
    dbg.log('', 0)
    return 'Disassembling done'