ultras's 4th crackme
=====================
Size		: 381 kb
Code		: Borland Delphi 7
Difficulty 	: 3

You Have To find the correct serial and/or make the keygen,,,

This is my 4th crackme,,,
so if you found any bug or want to give some suggestion,,
or you want to ask me,,
just email me at :

ultras_muhsin@yahoo.co.id

= sorry for my bad english =





  

       