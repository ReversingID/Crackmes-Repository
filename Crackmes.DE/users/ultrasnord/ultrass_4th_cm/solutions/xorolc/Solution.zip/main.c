/* 
   -------------------------------------------------------------------------
   - Filename  : main.c
   - Purpose   : KeyGen for Ultrasnord's Crackme #4
   - Created   : 08.27.08
   - Protection: Serial number + wacky tricks
   - Difficulty: Author says level 3.....I agree
   -------------------------------------------------------------------------
   - Copyright (C) 2008  [Xorolc]
   -
   - This program is free software: you can redistribute it and/or modify
   - it under the terms of the GNU General Public License as published by
   - the Free Software Foundation, either version 3 of the License, or
   - (at your option) any later version.
   -
   - This program is distributed in the hope that it will be useful,
   - but WITHOUT ANY WARRANTY; without even the implied warranty of
   - MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   - GNU General Public License for more details.
   - 
   - You should have received a copy of the GNU General Public License
   - along with this program.  If not, see http://www.gnu.org/licenses/
   -------------------------------------------------------------------------   
*/
#define WIN32_LEAN_AND_MEAN

/* Includes */
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include "resource.h"

/* save a few bytes */
#pragma comment(linker,"/FILEALIGN:0x200 /MERGE:.data=.text /MERGE:.rdata=.text /SECTION:.text,EWR /IGNORE:4078")

/* Defines */
#define CTRLMSG HIWORD(wParam)
#define CTRLID  LOWORD(wParam)

#define IsLeapYear(y) ((!(y % 4)) ? (((!(y % 400)) && (y % 100)) ? 1 : 0) : 0)

/* Globals */
HMENU hmenu;
HINSTANCE g_inst;
HWND hDlg, hwndName, hwndSerial;
SYSTEMTIME sTime;

char AppTitle[]		="Ultrasnord's Crackme #4 KeyGen";
char AboutTitle[]	="Ultrasnord's Crackme #4 KeyGen Info";
char szSerial[50]	= {0};
char szName[10]		= {0};

int len				= 0;


/* Our Function Prototypes */
void InitApp( HWND );
void CalculateSerial();
void CenterDialog( HWND );
int EncodeDate( short, short, short );

BOOL CALLBACK DialogProcedure( HWND, UINT, WPARAM, LPARAM );
int WINAPI WinMain( HINSTANCE, HINSTANCE, LPSTR, int );

BOOL CALLBACK DialogProcedure( HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam ){

	switch( uMsg ){

	case WM_INITDIALOG:
		InitApp( hDlg );
		SetWindowText(hDlg, AppTitle );
		CenterDialog( hDlg );
		break;

	case WM_CLOSE:
		EndDialog( hDlg, TRUE );
		break;

	case WM_LBUTTONDOWN: // Drag dialog with mouse trick
		ReleaseCapture();
		SendMessage( hDlg, WM_NCLBUTTONDOWN, HTCAPTION, 0 );
		break;

	case WM_COMMAND:
		switch( CTRLID ){

		case IDC_OK:
			CalculateSerial();
			SetWindowText( hwndSerial, szSerial );
			break;

		case IDC_EXIT:
			EndDialog( hDlg, TRUE );
			break;

		}

		break;

		default:
			return FALSE;
	}
	return TRUE;
}


int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow ){
	g_inst = hInstance;
	DialogBox( hInstance,MAKEINTRESOURCE(IDD_DIALOG),NULL,( DLGPROC )DialogProcedure );
	return FALSE;
}


/* Custom Functions */

void CalculateSerial(){

	int j	= 1;
	int i	= 0;
	int n1	= 0;
	int iDate;

	double f1 = 0.0f;

	char szTmp[50] = {0};

	ZeroMemory( szTmp, sizeof(szTmp) );
	ZeroMemory( szName, sizeof(szName) );
	ZeroMemory( szSerial, sizeof(szSerial) );

	GetWindowText( hwndName, szName, sizeof(szName) );

	len = lstrlen( szName );

	if( len != 7 )
		return;
	
	for(i=0; i<len; i++){
		n1 = ( szName[i] * (len * len)  ) ^ len;
		n1 = n1 >> 1;
		n1 = (n1 + len) - 1;
		wsprintf( szTmp, "%d%d", n1,len-j );
		lstrcat(szSerial, szTmp );

		f1 = atof( szSerial );

		f1 /= j;
		f1 *= j+1;

		j++;
	}

	GetLocalTime( &sTime );

	iDate = EncodeDate( sTime.wYear, sTime.wMonth, sTime.wDay );

	ZeroMemory( szTmp, sizeof(szTmp) );
	ZeroMemory( szSerial, sizeof(szSerial) );

	sprintf( szTmp, "%.15G%d", f1, iDate);

	len = lstrlen( szTmp );

	i = 0;

	while( szTmp[i] != '+' ){
		szSerial[i] = szTmp[i];
		i++;
	}
	j = i;
	i++;

	if( szTmp[i] = '0' )
		i++;

	while( i < len ){
		szSerial[j] = szTmp[i];
		i++;
		j++;
	}

	SetWindowText( hwndSerial, szSerial );

	return;
}

int EncodeDate( short wYear, short wMonth, short wDay ){
	static const short MonthDaySums[2][12] = {
		{0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335},
		{0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334}
	};

	const int DateDelta = 693594;
	double dTDateTime	= 0.0;
	int i = 0;
	int y = 0;

	i = wYear - 1;
	y = IsLeapYear( wYear );

	wDay += MonthDaySums[y][wMonth - 1];

	dTDateTime = i*365 + i/4 - i/100 + i/400 + wDay - DateDelta;
	
	y = ( len * len ) * len;
	i = dTDateTime;
	i ^= y;
	i -= ( len * 2 );

	return i;
}

void InitApp( HWND hDlg ){

	hwndName	= GetDlgItem( hDlg, IDC_NAME );
	hwndSerial	= GetDlgItem( hDlg, IDC_SERIAL );

	SendMessage( hwndName, EM_LIMITTEXT, 7, 0 );
	SetWindowText( hwndSerial, "Name must be 7 characters ONLY!!" );
}

void CenterDialog(HWND hwndDlg){

	RECT Dlg, Desktop;
	DWORD Height, Width, DeskX, DeskY;

	GetWindowRect(hwndDlg, &Dlg);
	GetWindowRect(GetDesktopWindow(), &Desktop);

	Width = Dlg.right - Dlg.left;
	Height = Dlg.bottom - Dlg.top;
	DeskX = (Desktop.right - Width) >> 1;
	DeskY = (Desktop.bottom - Height) >> 1;	

	MoveWindow(hwndDlg, DeskX, DeskY, Width, Height, FALSE);

	return;
}
