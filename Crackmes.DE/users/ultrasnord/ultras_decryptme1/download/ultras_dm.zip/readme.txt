ultras's decryptme
==================
Size		: 442.0 kb
Code		: Borland Delphi 7
Difficulty 	: 1-3

This Is My First DecryptMe so i'm not sure about difficulty,,,

RULEZ : - No Patching.
        - BruteFOrce Allowed.

if you found any bug or want to give some suggestion,,
or you want to ask me,,
just email me at :

ultras_muhsin@yahoo.co.id


= sorry for my bad english =    