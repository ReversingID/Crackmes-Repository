/* 
   -------------------------------------------------------------------------
   - Filename  : main.c
   - Purpose   : KeyGen for Ultrasnord's Trilogi #2
   - Created   : 08.14.08
   - Protection: Serial number + wacky tricks
   - Difficulty: Author says level 2.....I agree
   -------------------------------------------------------------------------
   - Copyright (C) 2008  [Xorolc]
   -
   - This program is free software: you can redistribute it and/or modify
   - it under the terms of the GNU General Public License as published by
   - the Free Software Foundation, either version 3 of the License, or
   - (at your option) any later version.
   -
   - This program is distributed in the hope that it will be useful,
   - but WITHOUT ANY WARRANTY; without even the implied warranty of
   - MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   - GNU General Public License for more details.
   - 
   - You should have received a copy of the GNU General Public License
   - along with this program.  If not, see http://www.gnu.org/licenses/
   -------------------------------------------------------------------------   
*/
#define WIN32_LEAN_AND_MEAN

/* Includes */
#include <windows.h>
#include <winsock.h>
#include "resource.h"

/* save a few bytes */
#pragma comment(linker,"/FILEALIGN:0x200 /MERGE:.data=.text /MERGE:.rdata=.text /SECTION:.text,EWR /IGNORE:4078")

/* Defines */
#define CTRLMSG HIWORD(wParam)
#define CTRLID  LOWORD(wParam)

/* Globals */
HMENU hmenu;
HINSTANCE g_inst;
HWND hDlg, hwndSerial, hwndCustomerID;

WSADATA wsa;
struct hostent *hHost;

char AppTitle[]		="Trilogi #2 KeyGen";
char AboutTitle[]	="Trilogi #2 KeyGen Info";
char szSerial[50]	= {0};
char szTmp1[50]		= {0};
char szComp[10]		= {0};

BOOL bIsSwapped		= FALSE;

/* Our Function Prototypes */
void SwapButtons();
void InitApp( HWND );
void EnableCrackme();
void CenterDialog( HWND );
BOOL CALLBACK DialogProcedure( HWND, UINT, WPARAM, LPARAM );
int WINAPI WinMain( HINSTANCE, HINSTANCE, LPSTR, int );

BOOL CALLBACK DialogProcedure( HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam ){
	switch( uMsg ){

	case WM_INITDIALOG:
		InitApp( hDlg );
		SetWindowText(hDlg, AppTitle );
		hmenu = GetMenu( hDlg );
		CenterDialog( hDlg );
		break;

	case WM_CLOSE:
		EndDialog( hDlg, TRUE );
		break;

	case WM_LBUTTONDOWN: // Drag dialog with mouse trick
		ReleaseCapture();
		SendMessage( hDlg, WM_NCLBUTTONDOWN, HTCAPTION, 0 );
		break;

	case WM_COMMAND:
		switch( CTRLID ){

		case IDC_ENABLE:
			EnableCrackme();
			break;

		case IDC_SET:
			SwapButtons();
			break;

		case IDM_EXIT:
			EndDialog( hDlg, TRUE );
			break;

		case IDM_ABOUT:
			MessageBox( hDlg,
						"[Xorolc]'s KeyGen for Ultrasnord's Trilogi #2\n\n\r"
						"If you didn't crack the first in the trilogi you\n\r"
						"can use the enable crackme button to enable the\n\r"
						"register button in this crackme. Also, before you\n\r"
						"enter the generated CustomerID and serial make sure\n\r"
						"you click the swap buttons button or the info you enter\n\r"
						"will not be accepted.",
						AboutTitle, MB_OK );
			break;


		}

		break;

		default:
			return FALSE;
	}
	return TRUE;
}


int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow ){
	g_inst = hInstance;
	DialogBox( hInstance,MAKEINTRESOURCE(IDD_DIALOG),NULL,( DLGPROC )DialogProcedure );
	return FALSE;
}


/* Custom Functions */

void InitApp( HWND hDlg ){

	int ret	= 0;

	char szHostName[255]	= {0};
	char * szLocalIP;
	WORD wVersionRequested;

	ZeroMemory( &wsa, sizeof(wsa) );

	hwndSerial		= GetDlgItem( hDlg, IDC_SERIAL );
	hwndCustomerID	= GetDlgItem( hDlg, IDC_CUSTOMERID );

	wVersionRequested = MAKEWORD(1, 1);

	ret	= WSAStartup( wVersionRequested, &wsa );

	if( ret != 0 ){
		MessageBox( hDlg, "Failed to start Winsock 1.1", "Err", MB_OK );
		return;
	}

	gethostname( szHostName, 255 );
	hHost = gethostbyname( szHostName );

	szLocalIP = inet_ntoa (*(struct in_addr *)*hHost->h_addr_list);

	SetWindowText( hwndCustomerID, szLocalIP );
	SetWindowText( hwndSerial, "XIIIXVXVIII" );

	WSACleanup();
}

void CenterDialog(HWND hwndDlg){

	RECT Dlg, Desktop;
	DWORD Height, Width, DeskX, DeskY;

	GetWindowRect(hwndDlg, &Dlg);
	GetWindowRect(GetDesktopWindow(), &Desktop);

	Width = Dlg.right - Dlg.left;
	Height = Dlg.bottom - Dlg.top;
	DeskX = (Desktop.right - Width) >> 1;
	DeskY = (Desktop.bottom - Height) >> 1;	

	MoveWindow(hwndDlg, DeskX, DeskY, Width, Height, FALSE);

	return;
}


void SwapButtons(){

	if( !bIsSwapped ){
		SwapMouseButton( TRUE );
		bIsSwapped = TRUE;
	}
	else{
		bIsSwapped = FALSE;
		SwapMouseButton( FALSE );
	}

	return;
}

void EnableCrackme(){

	char szFileName[]	= "c:\\windows\\system32\\ultras1.log";
	char szPath[]		= "c:\\Crackme\\Ultrasnords Trilogi 1\\"; /* Any path will due */
	char szRegKey[]		= "Software\\ultrasnord\\hiji\0";

	HANDLE hFile;
	HKEY hKey;

	DWORD dwBytesWritten = 0;

	DeleteFile( szFileName );
	hFile	= CreateFile( szFileName, GENERIC_WRITE, 0, 0, CREATE_ALWAYS, 0, 0 );
	WriteFile( hFile, szPath, 33, &dwBytesWritten, 0 );

	CloseHandle( hFile );

	RegCreateKey( HKEY_CURRENT_USER, szRegKey, &hKey );

	RegSetValueEx( hKey, "beres", 0, REG_SZ, "ok", 5 );
	RegSetValueEx( hKey, "path", 0, REG_SZ, szPath, 33 );

	RegCloseKey( hKey );

	return;
}