ultras's 6th crackme (Object CrackMe )
=======================================
Size		: 400.5 kb
Code		: Borland Delphi 7
Difficulty 	: 3



To Do :
1. Defeat Startup Protection (Patching Allowed Here...)(The protection Maybe Execute or NOt )
2. Defeat Level1 (the checkboxes and radio buttons),,Find The Correct Combination (No Patching)(no resource editor),,
3. Defeat Level2 (Trackbar),,Find The Correct Combination (No Patching),,
4. Defeat Level3 find correct password,,,(and defeat the protection),,,

This is my 6th crackme,,,
if you found any bug or want to give some suggestion,,
or you want to ask me,,
just email me at :

ultras_muhsin@yahoo.co.id


my next crackme will come late,,
because i will face test at my college,,
so be patient to all my fans :)..
lol,,

= sorry for my bad english =





  

       