/* 
   -------------------------------------------------------------------------
   - Filename  : main.c
   - Purpose   : KeyGen for Ultrasnord's Trilogi #1
   - Created   : 08.08.08 magical huh?
   - Protection: Serial number + wacky tricks
   - Difficulty: Author says level 2.....I agree
   -------------------------------------------------------------------------
   - Copyright (C) 2008  [Xorolc]
   -
   - This program is free software: you can redistribute it and/or modify
   - it under the terms of the GNU General Public License as published by
   - the Free Software Foundation, either version 3 of the License, or
   - (at your option) any later version.
   -
   - This program is distributed in the hope that it will be useful,
   - but WITHOUT ANY WARRANTY; without even the implied warranty of
   - MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   - GNU General Public License for more details.
   - 
   - You should have received a copy of the GNU General Public License
   - along with this program.  If not, see http://www.gnu.org/licenses/
   -------------------------------------------------------------------------   
*/
#define WIN32_LEAN_AND_MEAN

/* Includes */
#include <windows.h>
#include "resource.h"

/* save a few bytes */
#pragma comment(linker,"/FILEALIGN:0x200 /MERGE:.data=.text /MERGE:.rdata=.text /SECTION:.text,EWR /IGNORE:4078")

/* Defines */
#define CTRLMSG HIWORD(wParam)
#define CTRLID  LOWORD(wParam)

/* Globals */
HMENU hmenu;
HINSTANCE g_inst;
HWND hDlg, hwndName, hwndSerial, hwndCompany;
char AppTitle[]		="Trilogi #1 KeyGen";
char AboutTitle[]	="Trilogi #1 KeyGen Info";
char szSerial[50]	= {0};
char szTmp1[50]		= {0};
char szComp[10]		= {0};

/* Our Function Prototypes */
void SetButtons();
void InitApp( HWND );
void CalculateSerial();
void CenterDialog( HWND );
void ReverseString( char *);
BOOL CALLBACK DialogProcedure( HWND, UINT, WPARAM, LPARAM );
int WINAPI WinMain( HINSTANCE, HINSTANCE, LPSTR, int );

BOOL CALLBACK DialogProcedure( HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam ){
	switch( uMsg ){

	case WM_INITDIALOG:
		InitApp( hDlg );
		// SendMessage( hDlg, WM_SETICON, (WPARAM)ICON_BIG, (LPARAM)LoadIcon(g_inst, MAKEINTRESOURCE(IDI_ICON)) );
		SetWindowText(hDlg, AppTitle );
		hmenu = GetMenu( hDlg );
		CenterDialog( hDlg );
		break;

	case WM_CLOSE:
		EndDialog( hDlg, TRUE );
		break;

	case WM_LBUTTONDOWN: // Drag dialog with mouse trick
		ReleaseCapture();
		SendMessage( hDlg, WM_NCLBUTTONDOWN, HTCAPTION, 0 );
		break;

	case WM_COMMAND:
		switch( CTRLID ){

		case IDC_NAME:
			if( CTRLMSG == EN_UPDATE ){
				CalculateSerial();
			}
			SetWindowText( hwndCompany, szComp );
			SetWindowText( hwndSerial, szSerial );
			break;

		case IDC_SET:
			SetButtons();
			break;

		case IDM_EXIT:
			EndDialog( hDlg, TRUE );
			break;

		case IDM_ABOUT:
			MessageBox( hDlg,
						"[Xorolc]'s KeyGen for Ultrasnord's Trilogi #1\n\n\r"
						"Just type in your name and your serial will be\n\r"
						"generated for you. Then before entering in your info\n\r"
						"make sure you hit the ""Set Buttons"" button or the\n\r"
						"generated info will fail. Also, due to how the serial\n\r"
						"is calculated it might not work %100 of the time.\n\r"
						"This is due to using free space as part of the serial.\n\n\r"
						"I suggest closing all other apps and then updating your\n\r"
						"name to get the lastest valid serial.\n\r",
						AboutTitle, MB_OK );
			break;


		}

		break;

		default:
			return FALSE;
	}
	return TRUE;
}


int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow ){
	g_inst = hInstance;
	DialogBox( hInstance,MAKEINTRESOURCE(IDD_DIALOG),NULL,( DLGPROC )DialogProcedure );
	return FALSE;
}


/* Custom Functions */

void CalculateSerial(){

	char szName[16]	= {0};
	char szTmp2[50]	= {0};

    ULARGE_INTEGER dwFreeBytes;
	DWORD dwFreeMem   = 0;
	DWORD dwFreeSpace = 0;

	int len = 0;

	MEMORYSTATUS mBuffer;

	ZeroMemory( szName, sizeof(szName) );
	ZeroMemory( szTmp2, sizeof(szTmp2) );
	ZeroMemory( szTmp1, sizeof(szTmp1) );
	ZeroMemory( szComp, sizeof(szComp) );
	ZeroMemory( szSerial, sizeof(szSerial) );

	GetWindowText( hwndName, szName, sizeof(szName) );

	len = lstrlen( szName );

    GetDiskFreeSpaceEx( NULL, NULL, NULL, &dwFreeBytes );
	dwFreeSpace = dwFreeBytes.QuadPart / 0x400; /* divide by 1000 */

	wsprintf( szTmp1, "%d", dwFreeSpace );
    lstrcpy( szSerial, szTmp1 );    /* serial part 1 */
    
    ReverseString( szName );
    
    lstrcat( szSerial, szTmp1 );    /* serial part 2 */

    lstrcpy( szComp, "PERSONAL" );
    if( len & 0x01 )
        lstrcpy( szComp, "HOME" );
    
    ReverseString( szComp );
    
    lstrcat( szSerial, szTmp1 );    /* serial part 3 */
    
    GlobalMemoryStatus( &mBuffer );
    
    dwFreeMem = mBuffer.dwTotalPhys;
    dwFreeMem = dwFreeMem >> 10;
    
    wsprintf( szTmp1, "%i", dwFreeMem );
    lstrcat( szSerial, szTmp1 );	/* serial part 4 */

	return;
}

void InitApp( HWND hDlg ){

	hwndName	= GetDlgItem( hDlg, IDC_NAME );
	hwndSerial	= GetDlgItem( hDlg, IDC_SERIAL );
	hwndCompany	= GetDlgItem( hDlg, IDC_COMPANY );

	SendMessage( hwndName, EM_LIMITTEXT, 15, 0 );
}

void CenterDialog(HWND hwndDlg){

	RECT Dlg, Desktop;
	DWORD Height, Width, DeskX, DeskY;

	GetWindowRect(hwndDlg, &Dlg);
	GetWindowRect(GetDesktopWindow(), &Desktop);

	Width = Dlg.right - Dlg.left;
	Height = Dlg.bottom - Dlg.top;
	DeskX = (Desktop.right - Width) >> 1;
	DeskY = (Desktop.bottom - Height) >> 1;	

	MoveWindow(hwndDlg, DeskX, DeskY, Width, Height, FALSE);

	return;
}

void ReverseString( char *szString ){
	int l, m;

	ZeroMemory( szTmp1, sizeof(szTmp1) );

	l = lstrlen( szString );

	for( m=0; m<l; m++ ){
		szTmp1[m] = szString[l-m-1];
	}
     
     return;
}

void SetButtons(){

	BYTE bKeyState[256];

	GetKeyboardState((LPBYTE)&bKeyState);

	if( !bKeyState[VK_CAPITAL] & 1 )
		keybd_event( VK_CAPITAL, 0, KEYEVENTF_EXTENDEDKEY, 0 );

	if( !bKeyState[VK_SCROLL] & 1 )
		keybd_event( VK_SCROLL, 0, KEYEVENTF_EXTENDEDKEY, 0 );

	if( bKeyState[VK_NUMLOCK] & 1 )
		keybd_event( VK_NUMLOCK, 0, KEYEVENTF_EXTENDEDKEY, 0 );

	return;
}