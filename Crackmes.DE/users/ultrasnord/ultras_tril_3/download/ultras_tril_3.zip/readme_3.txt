ultras's Trilogi #3
===================
Size		: 385.0 kb
Code		: Borland Delphi 7
Difficulty 	: 1-2

To Do :
1. Find The Way TO GoodBoy Message.
2. No Patching.

# - Thanx For Trying This Crackme..
# - Next Will be DecryptMe {Coming Soon},,Still Learning About Crypto,,,LolZ.


if you found any bug or want to give some suggestion,,
or you want to ask me,,
just email me at :

ultras_muhsin@yahoo.co.id


= sorry for my bad english =