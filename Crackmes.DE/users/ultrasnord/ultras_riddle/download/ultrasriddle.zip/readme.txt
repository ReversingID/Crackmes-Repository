ultras's riddle
=======================================
Size		: 404.0 kb
Code		: Borland Delphi 7
Difficulty 	: 3

To Do :
1. Find The Correct Combination,,,That Will Lead you To Good Boy Message,,,

Rulez :
1.No Patching At All,,,
==========================================
This is my 7th crackme,,,
But I think This Is A Puzzle Not A Crackme,,,
Hope This Will Fun,,,
=============================================
FOund Bug?,,Need Some Helps?,,
just email me at :

ultras_muhsin@yahoo.co.id
============================================
Please Give Some Comment Or Suggestion About This Crackme/puzzle,,,
Good Or Bad,,,
I really need it,,,
=============================================

= sorry for my bad english =