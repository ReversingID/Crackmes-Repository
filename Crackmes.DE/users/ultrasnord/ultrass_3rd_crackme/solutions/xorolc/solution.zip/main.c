/* 
   -------------------------------------------------------------------------
   - Filename  : main.c
   - Purpose   : KeyGen for Ultrasnord's Trilogi #1
   - Created   : 08.08.08 magical huh?
   - Protection: Serial number + wacky tricks
   - Difficulty: Author says level 2.....I agree
   -------------------------------------------------------------------------
   - Copyright (C) 2008  [Xorolc]
   -
   - This program is free software: you can redistribute it and/or modify
   - it under the terms of the GNU General Public License as published by
   - the Free Software Foundation, either version 3 of the License, or
   - (at your option) any later version.
   -
   - This program is distributed in the hope that it will be useful,
   - but WITHOUT ANY WARRANTY; without even the implied warranty of
   - MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   - GNU General Public License for more details.
   - 
   - You should have received a copy of the GNU General Public License
   - along with this program.  If not, see http://www.gnu.org/licenses/
   -------------------------------------------------------------------------   
*/
#define WIN32_LEAN_AND_MEAN

/* Includes */
#include <windows.h>
#include "resource.h"

/* save a few bytes */
#pragma comment(linker,"/FILEALIGN:0x200 /MERGE:.data=.text /MERGE:.rdata=.text /SECTION:.text,EWR /IGNORE:4078")

/* Defines */
#define CTRLMSG HIWORD(wParam)
#define CTRLID  LOWORD(wParam)

/* Globals */
HWND hDlg, hwndID, hwndSerial;

char AppTitle[]		="Ultrasnords CrackMe #3 KeyGen";
char AboutTitle[]	="Ultrasnords CrackMe #3 KeyGen Info";
char szID[50]		= {0};
char szSerial[50]	= {0};

SYSTEMTIME sTime;


/* Our Function Prototypes */
void CalculateID();
void InitApp( HWND );
void CenterDialog( HWND );
void CalculateSerial( char *, int);
BOOL CALLBACK DialogProcedure( HWND, UINT, WPARAM, LPARAM );
int WINAPI WinMain( HINSTANCE, HINSTANCE, LPSTR, int );

BOOL CALLBACK DialogProcedure( HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam ){
	switch( uMsg ){

	case WM_INITDIALOG:
		InitApp( hDlg );
		SetWindowText(hDlg, AppTitle );
		CenterDialog( hDlg );
		CalculateID();
		break;

	case WM_CLOSE:
		EndDialog( hDlg, TRUE );
		break;

	case WM_LBUTTONDOWN: // Drag dialog with mouse trick
		ReleaseCapture();
		SendMessage( hDlg, WM_NCLBUTTONDOWN, HTCAPTION, 0 );
		break;

	case WM_COMMAND:
		switch( CTRLID ){

		case IDC_EXIT:
			EndDialog( hDlg, TRUE );
			break;

		}

		break;

		default:
			return FALSE;
	}
	return TRUE;
}


int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow ){
	DialogBox( hInstance,MAKEINTRESOURCE(IDD_DIALOG),NULL,( DLGPROC )DialogProcedure );
	return FALSE;
}


/* Custom Functions */

void CalculateSerial( char *szDate, int len){

	int m1 = 0, m2 = 0, m3 = 0, i = 0;
	char szTmp[7]	= {0};
	
	m1 -= len;
	m2 = m1;
	m1 -= len;
	m1 = ( m1 * len ) + ( len * 2 );
	m1 += (len * len * len * len);
	m1 -= m2;
	
	for(i=0; i<len-3; i++ ){
		ZeroMemory( szTmp, sizeof(szTmp) );
		wsprintf( szTmp, "%d", m1 );
		lstrcat( szSerial, szTmp );
	}

	return;
}

void CalculateID(){

	char szDate[11]	= {0};
	char szTmp[3]	= {0};

	int i, len, m1, m2;

	ZeroMemory( szID, sizeof(szID) );
	ZeroMemory( &sTime, sizeof(sTime) );
	ZeroMemory( szDate, sizeof(szDate) );
	ZeroMemory( szSerial, sizeof(szSerial) );

	GetLocalTime( &sTime );
	
	len = wsprintf( szDate, "%d/%d/%d", sTime.wMonth, sTime.wDay, sTime.wYear );

	m1 = 0;
	m2 = 0;
	for( i=1; i<len+1; i++ ){
		m1 = ( i * i ) ^ i;
		m2 = ( i ^ m1 ) + ( i * 2 );
		ZeroMemory( szTmp, sizeof(szTmp) );
		wsprintf( szTmp, "%d", m2 );
		lstrcat( szID, szTmp );
	}

	CalculateSerial( szDate, len );

	lstrcat( szID, szDate );
	lstrcat( szSerial, szDate );

	SetWindowText( hwndID, szID );
	SetWindowText( hwndSerial, szSerial );

	return;
}


void InitApp( HWND hDlg ){

	hwndID		= GetDlgItem( hDlg, IDC_USERID );
	hwndSerial	= GetDlgItem( hDlg, IDC_SERIAL );
}

void CenterDialog(HWND hwndDlg){

	RECT Dlg, Desktop;
	DWORD Height, Width, DeskX, DeskY;

	GetWindowRect(hwndDlg, &Dlg);
	GetWindowRect(GetDesktopWindow(), &Desktop);

	Width = Dlg.right - Dlg.left;
	Height = Dlg.bottom - Dlg.top;
	DeskX = (Desktop.right - Width) >> 1;
	DeskY = (Desktop.bottom - Height) >> 1;	

	MoveWindow(hwndDlg, DeskX, DeskY, Width, Height, FALSE);

	return;
}
