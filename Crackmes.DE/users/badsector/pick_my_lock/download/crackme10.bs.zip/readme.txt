Pick My Lock crackme
by BadSector//K23
---------------------

Welcome to my crackme no.10 :)
This one is different than my previous crackmes. I tried to make
it interesting but not too hard. This time you will deal with some
old and easy encryption methods. Not much of a challenge for crypto
lovers but still coding a keygen could be a little tricky.

If you want to discuss about this crackme, my email is: badsector@online.hr

Have fun!