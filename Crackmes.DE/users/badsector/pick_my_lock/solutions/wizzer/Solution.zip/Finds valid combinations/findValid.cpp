#include <iostream>
//#include "stdafx.h"
#include <tchar.h>
#include "windows.h"
//#include "time.h"

typedef unsigned long DWORD;
using namespace std;

HANDLE				hLogfile;


//will be used to draw '!'

//char 
byte chessTable[200];
byte numTable[20];

byte bruteNum[10]={0,0,0,0,0,0,0,0,0};

byte *_memStartOfTable_=chessTable;


void FillTable()	{
	byte curPos=0;
	memset(chessTable,0,200);	
//	curPos+=12;

	for(int i=0; i<12; i++)	{
		chessTable[curPos]=0x21;
		curPos++;
	}

	curPos+=4;


	for(int i=0; i<10; i++)	{
		chessTable[curPos]=0x21;
		chessTable[curPos+11]=0x21;



		curPos+=16;
	}

//	pos+=4;

	for(int i=0; i<12; i++)	{
		chessTable[curPos]=0x21;
		curPos++;
	}
}

bool isOver=false;

int	GetNextNum()	{

	if(!isOver)	{

	if (bruteNum[9]==9) {
        bruteNum[9]=0;
//		bruteNum[8]++;
	} 	else {
		bruteNum[9]++;
		return -1;
	}

	if (bruteNum[8]==9) {
       	bruteNum[8]=0;
//		bruteNum[7]++;
	} 	else {
		bruteNum[8]++;
		return -1;
	}

	if (bruteNum[7]==9) {
       	bruteNum[7]=0;
//		bruteNum[6]++;
	} 	else {
		bruteNum[7]++;
		return -1;
	}

	if (bruteNum[6]==9) {
       	bruteNum[6]=0;
//		bruteNum[5]++;
	} 	else {
		bruteNum[6]++;
		return -1;
	}

	if (bruteNum[5]==9) {
       	bruteNum[5]=0;
//		bruteNum[4]++;
	} 	else {
		bruteNum[5]++;
		return -1;
	}

	if (bruteNum[4]==9) {
       	bruteNum[4]=0;
//		bruteNum[3]++;
	} 	else {
		bruteNum[4]++;
		return -1;
	}

	if (bruteNum[3]==9) {
       	bruteNum[3]=0;
//		bruteNum[2]++;
	} 	else {
		bruteNum[3]++;
		return -1;
	}

	if (bruteNum[2]==9) {
       	bruteNum[2]=0;
//		bruteNum[1]++;
	} 	else {
		bruteNum[2]++;
		return -1;
	}

	if (bruteNum[1]==9) {
       	bruteNum[1]=0;
//		bruteNum[0]++;

		/*if(bruteNum[0]==10) {
			isOver=true;
			return -1;
		}*/

	} 	else {
		bruteNum[1]++;
		return -1;
	}

//	if (bruteNum[0]==9) {
			
//			return -1;
     //  	bruteNum[5]==0;
	//	bruteNum[4]++;
//	} 	else {
	bruteNum[0]++;
	if(bruteNum[0] >9) {
			isOver=true;
	}

		return -1;
	//}
	}

}


void	FillNumTable()	{
	memset(numTable,0,20);

	//Set primary num aka lines in board
	byte cnt=0;
	for(int i=0; i<20; i+=2)	{
		numTable[i]=cnt;
		cnt++;
	}

	
	int bruteCnt=0;
	for(int i=1; i<21; i+=2)	{
		numTable[i]=bruteNum[bruteCnt];
		bruteCnt++;
		
	}


}

//void FillFromTill(int start, int amount)	{
//
//	int end=start; 
//	end+=amount;
//
//	for (int i=start; i<end; i++)	{
//		table[i]=0x41;
//	}
//}
//int beginMark=30;
//int somePointer=40;
//int firstRun=0;


int main(int argc, _TCHAR* argv[])	{

	if((hLogfile=CreateFile("validKeys.txt",GENERIC_WRITE,FILE_SHARE_READ,NULL,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL))==INVALID_HANDLE_VALUE)
	{
		return -1;
			
	} 

	bool IsFound=false;
	
	_memStartOfTable_+=17;

	////my own test VALID KEY!!!
	//bruteNum[0]=5;
	//bruteNum[1]=0;
	//bruteNum[2]=6;
	//bruteNum[3]=1;
	//bruteNum[4]=7;
	//bruteNum[5]=2;
	//bruteNum[6]=8;
	//bruteNum[7]=3;
	//bruteNum[8]=9;
	//bruteNum[9]=0;

	while(!isOver)	{
	FillTable();

	FillNumTable();

	DWORD _mainLoopCounter_0A;
	DWORD _someInnerLoopCounter;

	DWORD _foundValidVars_0A;
	
	DWORD _firstTempDWORD;
	DWORD _secondTempDWORD;

	int varOk=0;

	

	////
	//for (int i=0; i<999999999; i++)
	//{
	//	GetNextNum();

	//	for (int i=0; i<10; i++)
	//	std::cout<<bruteNum[i];

	//	std::cout<<'\n';

	//}

	//return 0;
	////


	

	//FillXFunc
	
	


	__asm	{
//		_FillXFunc      proc near               ; CODE XREF: sub_401259+33p
			sub     eax, eax

loc_40132B:                  

			mov     ecx, 0Ah
			call    sub_401346
			imul    esi, [ebx+20h], 73696874h
			and     [ecx+6Eh], ah
			outsb
			outsd
			jns      loc_4013AC // if not zero then found
			outsb
//			db      67h
			aas
//			endp

sub_401346:
			add     esp, 4
			mov     esi, offset numTable//_vars

						

loc_40134E:    
			lodsb
			shl     eax, 4
			add     eax, _memStartOfTable_ //no offset
			sub     edi, edi
			xchg    eax, edi
			lodsb
			add     edi, eax
			mov     al, 78h
			cmp     byte ptr [edi], 0
			jnz     loc_401367
			stosb
			jmp     loc_40136A



loc_401367:    
//			sub     eax, eax
			mov		varOk, 0
			jmp		__exit

loc_40136A:              
			loop    loc_40134E
			mov		varOk,	1
			//jmp		__exit
//			retn


__exit:		
//			mov		varOk, 0
//			retn
	}

	if(varOk!=0)	{

//bruteforcing routine
	__asm	{
		//	_importantProc  proc near             
		call    _in_ImportandProc
	//		jz      short loc_4013E3
	//		outsd
	//		and     [ebp+61h], ah
	//		jnb     near ptr loc_4013F0+3
	//		and     [esi+6Fh], ah
	//		jb      near ptr loc_40139E+1
	//		jns     loc_4013F0
	//		jnz     loc_4013C2
			// _importantProc  endp

_in_ImportandProc:
			add     esp, 4
			mov     al, 78h
			mov     esi, 0
			mov     _mainLoopCounter_0A, esi // Set starting 0
			mov     _foundValidVars_0A, esi // Set starting 0


_do_validation_all_vars:
			mov     ecx, 0Bh        // Address + OB = search scope

loc_40139E:                
			mov     edi, esi
			shl     edi, 4
//			add     edi, offset _memStartOfTable_ // adds then takes val from address, if ECX 0 then BAD
			add     edi, _memStartOfTable_ // adds then takes val from address, if ECX 0 then BAD

	//		mov		[edi], 0x78

			repne scasb
			inc     esi

loc_4013AC:      
			or      ecx, ecx        // if not zero then found
			jz      _ifFoundIncrease
			inc     _foundValidVars_0A

_ifFoundIncrease:
			cmp     esi, 0Ah
			jnz     _do_validation_all_vars // Address + OB = search scope
			cmp     _foundValidVars_0A, 0Ah

loc_4013C2:                      
			jnz     _BadPlace
			mov     _someInnerLoopCounter, 0

_InnerLoopInit:            
			// _mainValidation
			cmp     _mainLoopCounter_0A, 0Ah
			jz       _AllVarsValid_Exit_
			mov     eax, _someInnerLoopCounter
			shl     eax, 4

_InnerLoop_GoAgain_with_prev_InnerLoopCounter_Val:

			add     eax,  _memStartOfTable_ //40306Dh
			mov     _firstTempDWORD, eax
			add     eax, 0Ah        // Increase address pointer to 0A

loc_4013F0:                            
			mov     _secondTempDWORD, eax
			mov     al, 78h         // what to search
			mov     ecx, 0Bh        // Address + OB = search scope
			mov     edi, _firstTempDWORD
			repne scasb
			or      ecx, ecx
			jnz      _ifFoundGoInner
			inc     _someInnerLoopCounter
			inc     _mainLoopCounter_0A
			cmp     _mainLoopCounter_0A, 0Ah
			jnz      _InnerLoopInit

_AllVarsValid_Exit_:                  
			mov     eax, 1

			jmp		_BadPlace //If ok then exit
	//		retn

// ---------------------------------------------------------------------------

_ifFoundGoInner:  
			mov     ecx, edi
			dec     ecx
			mov     esi, _firstTempDWORD
			sub     ecx, esi
			or      ecx, ecx        // don't know why first time jumps
			jz       loc_401443
			mov     esi, edi
			sub     esi, 2

loc_401437:         
			cmp     byte ptr [esi], 78h
			jz      _BadPlace
			dec     esi
			loop    loc_401437

loc_401443:                           
			mov     ecx, _secondTempDWORD
			sub     ecx, edi
			or      ecx, ecx
			jz      loc_40145C
			mov     esi, edi

loc_401451:  
			lodsb
			cmp     al, 78h
			jz      _BadPlace
			loop    loc_401451

loc_40145C:    
			cmp     _someInnerLoopCounter, 0
			jz       loc_40147D
			mov     esi, edi
			dec     esi
			mov     ecx, _someInnerLoopCounter

loc_40146E:                 
			sub     esi, 10h
			lodsb
			dec     esi
			cmp     al, 78h
			jz      _BadPlace
			loop    loc_40146E

loc_40147D:                           
			cmp     _someInnerLoopCounter, 9
			jz       _hmJump
			mov     esi, edi
			dec     esi
			mov     ecx, 9
			sub     ecx, _someInnerLoopCounter

_seek_Stolbik_BAD:   
			add     esi, 10h
			lodsb
			dec     esi
			cmp     al, 78h
			jz      _BadPlace
			loop    _seek_Stolbik_BAD

_hmJump:         
		call    _mainValidation
			ja       loc_401512
			jns      loc_4014C6
			imul    esi, [ebx+20h], 73696874h
			and     [ebx+68h], ah
			arpl    gs:[ebx+20h], bp
			jnb      loc_401528
			and     [edi+ebp*2+6Eh], ch
//			db      67h
			aas
			aas
	
		//	endp	//_in_ImportandProc 

_mainValidation:
		add     esp, 4

loc_4014C6:    
			cmp     _someInnerLoopCounter, 0
			jz       loc_4014F3
			mov     esi, edi
			dec     esi
			mov     ecx, _someInnerLoopCounter

loc_4014D8:    
			cmp     byte ptr [esi-1], 21h
			jz       loc_4014F3
			sub     esi, 11h
			lodsb
			dec     esi
			cmp     al, 78h
			jz      _BadPlace
			cmp     byte ptr [esi-10h], 21h
			jz       loc_4014F3
			loop    loc_4014D8

loc_4014F3:    

			cmp     _someInnerLoopCounter, 0
			jz       loc_40151C
			mov     esi, edi
			dec     esi
			mov     ecx, _someInnerLoopCounter

loc_401505:                
			cmp     byte ptr [esi+1], 21h
			jz       loc_40151C
			sub     esi, 0Fh
			lodsb
			dec     esi
			cmp     al, 78h

loc_401512:    
			jz       _BadPlace
			cmp     byte ptr [esi-10h], 21h
			jz       loc_40151C
			loop    loc_401505

loc_40151C:                  

			cmp     _someInnerLoopCounter, 9
			jz       loc_401549
			mov     esi, edi
			dec     esi

loc_401528:    
			mov     ecx, 9
			sub     ecx, _someInnerLoopCounter

loc_401533: 
			cmp     byte ptr [esi-1], 21h
			jz       loc_401549
			add     esi, 0Fh
			cmp     byte ptr [esi], 78h
			jz       _BadPlace
			cmp     byte ptr [esi+0Fh], 21h
			jz       loc_401549
			loop    loc_401533

loc_401549:                

			cmp     _someInnerLoopCounter, 9
			jz       _gotoAgain_till_0A_forGOOD
			mov     esi, edi
			dec     esi
			mov     ecx, 9
			sub     ecx, _someInnerLoopCounter

loc_401560: 
			cmp     byte ptr [esi+1], 21h
			jz       _gotoAgain_till_0A_forGOOD
			add     esi, 11h
			cmp     byte ptr [esi], 78h
			jz       _BadPlace
			cmp     byte ptr [esi+11h], 21h
			jz       _gotoAgain_till_0A_forGOOD
			loop    loc_401560

_gotoAgain_till_0A_forGOOD:   

			inc     _someInnerLoopCounter
			inc     _mainLoopCounter_0A
			jmp     _InnerLoopInit
			// ---------------------------------------------------------------------------
			//   dd 65726F6Dh
			//---------------------------------------------------------------------------
			aas
			aas


_BadPlace:     
			xor     eax, eax
			//retn
			//endp


	//	endp	//_in_ImportandProc 
// ---------------------------------------------------------------------------


	}
	
	/*for(byte i=0; i<10; i++)	{
	
	std::cout<< (int)bruteNum[i];
	}
	std::cout<<'\n';*/
	
	if(_mainLoopCounter_0A==0x0A)	{
		
		string strFound="Founded: ";
		
		char tmp;
		for(int i=0; i<10; i++)	{
	
		
		itoa(bruteNum[i],&tmp,10);
		strFound+=tmp;
		
		}
	
		std::cout<<strFound.c_str()<<'\n';
		
		

		DWORD written;
		WriteFile(hLogfile,strFound.c_str(),strFound.length(),&written,0); 
		WriteFile(hLogfile,"\n",1,&written,0);

//		IsFound=true;
//		MessageBox(0,"Found !!!","",0);
	}//if found

	}//if varOk is good


	GetNextNum();	//moving to following num

	}//end while(!IsOver)

	CloseHandle(hLogfile);
	
	MessageBox(0,"End","",0);
	
	return 0;
}
//	int counter=0;
//
//	FillTable();
//
////	for(int i=0; i<9; i++)	{
//
////	if((beginMark-somePointer)==0)	{		//some zero check, maybe used for loop
////	}
//	if(firstRun==0)	{
//		firstRun=1;
//
//		int localsomePointer=somePointer;
//
//	}
//	int start=beginMark;
//	start++;
//	beginMark++;
//	
//	FillFromTill(start,9);
//
//	
//
//	if((counter==0)	|| (counter!=9)){
//		
//		int	start=beginMark;
//		start-=2;
//		int cnt=9;
//		cnt-=counter;
//
//		for(int i=0; i<cnt; i++)	{
//		start+=16;
//
//		FillFromTill(start,1);
//	//	start--;
//		}
//	
//
//	}
//
//	if(counter==9)	{
//
//	}
//
////}
//	int x=0;
//
//	MessageBox(0,"Hello","",0);
//
//	return 0;
//}
