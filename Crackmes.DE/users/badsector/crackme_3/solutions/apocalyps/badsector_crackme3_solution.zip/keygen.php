<?php
echo "[x] Keygen Written by Apocalyps � 2004 [x]\n";
echo "------------------------------------------\n";

$sText = "Frank";

echo "Name input: $sText \n";
$len = strlen($sText);

//Part1
    for ($i = 0; $i <= strlen($sText) - 1; $i++)
    {
        $sChar = substr($sText, $i, 1);
        $iASCII = ord($sChar);
            $sHex = $iASCII - $len;
            $total[$i] = $sHex;
            $len = $len - 1;
    }

//Part2
$eind = count($total);
$x=0;
for($i = 1;$i<=count($total);$i++){
        $sChar = $total[$eind-1];
        if($sChar < 65)$sChar=$sChar+32;
        if($sChar > 90)$sChar=$sChar-32;
        $serial[$i+$x] = $sChar;
        if($i==4){
                $x++;
                $serial[$i+1] = "-";
        }
        $eind = $eind - 1;
}
echo "Your Serial:";
foreach($serial as $k => $a){
        if($k==2){
                echo chr($a+1);
        }
        elseif($k==5){
                echo "$a";
        }
        else{
                echo chr($a);
        }
}

?>
