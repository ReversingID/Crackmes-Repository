#include <windows.h>
#include "resource.h"

BOOL CALLBACK DlgProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  switch (message)
  {
    case WM_INITDIALOG:
      SetDlgItemText(hWnd, EditID1, "*Sorcerer*");
      break;

    case WM_COMMAND:
{
  switch (LOWORD (wParam))
  {
    case ButtonID1:
      MessageBox(hWnd, "KeyGenerator for Bad Sector #1\nMade by: *Sorcerer*", "About", MB_OK);
      break;

    case ButtonID2:
      SendMessage(hWnd,WM_CLOSE,0,0);
      break;

    case EditID1:
    {
    
      int serial = 0;
      DWORD serial2 = 0x654789;
      char buffer[255] = "";
      char finalserial[255] = "";

      GetDlgItemText(hWnd, EditID1, buffer, 255);

      int size = lstrlen(buffer);

      if (size >= 4)
                {
      int i;          
      for (i = 0; i < size; i++)
             {
             
      if (buffer[i] != 0x20)
      { serial += (buffer[i]*4); }
      
             }       

      for (i = 0; i < size; i++)
      {
      serial2--;       
      serial2 += (serial2*2);
      serial2--;
      }

      wsprintf(finalserial,"BS-%lX-%lu", serial2, serial);

      SetDlgItemText(hWnd, EditID2, finalserial);
                }
      else
      SetDlgItemText(hWnd, EditID2, "Enter at least 4 chars");

    }
      break;
  }

}
      break;

    case WM_CLOSE:
      EndDialog(hWnd,0);
      break;
}
return 0;
}



int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nCmdShow)
{
  DialogBox(hInstance,MAKEINTRESOURCE(DialogID1),NULL,(DLGPROC)DlgProc);
  return 0;
}
