/////////////////////////////////////////////////////////////////////////////
//
// Dialog
//

#define DialogID1                       101
#define EditID1                         1001
#define EditID2                         1002
#define ButtonID1                       1003
#define ButtonID2                       1004
