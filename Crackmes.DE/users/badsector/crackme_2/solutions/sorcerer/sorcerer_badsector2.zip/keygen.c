#include <windows.h>
#include "resource.h"

BOOL CALLBACK DlgProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  switch (message)
  {
    case WM_INITDIALOG:
      SetDlgItemText(hWnd, EditID1, "Sorcerer");
      break;

    case WM_COMMAND:
{
  switch (LOWORD (wParam))
  {
    case ButtonID1:
      MessageBox(hWnd, "KeyGenerator for BadSector #2\nMade by: *Sorcerer*", "About", MB_OK);
      break;

    case ButtonID2:
      SendMessage(hWnd,WM_CLOSE,0,0);
      break;

    case EditID1:
    {
    
      char serial[255] = "";
      char buffer[255] = "";
      char lookup[15] = "/BCTyMTC)T{LF";
      int pointer = 0;
      
      GetDlgItemText(hWnd, EditID1, buffer, 255);

      int size = lstrlen(buffer);
      int lookupsize = lstrlen(lookup);

      if (size >= 5)
                {
      int i;          
      for (i = 0; i < lookupsize; i++)
             {     
      *(serial+i) += (lookup[i]^0x0c);
      *(serial+i) = (serial[i]+0x20);
      *(serial+i) = (serial[i]^0x15);
      *(serial+i) = (serial[i]-0x0c);
             }
             
      for (i = 0; i < size; i++)
             {     
      if (buffer[i] > 0x41 && buffer[i] < 0x7a)
      { pointer = 0; }
      else
      { pointer = 1; }    
             }                                
      
      if (pointer == 1)
      { SetDlgItemText(hWnd, EditID2, "Bad Name!"); }
      
      else
      
      SetDlgItemText(hWnd, EditID2, serial);
                }
      else
      SetDlgItemText(hWnd, EditID2, "Enter at least 5 chars");

    }
      break;
  }

}
      break;

    case WM_CLOSE:
      EndDialog(hWnd,0);
      break;
}
return 0;
}



int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nCmdShow)
{
  DialogBox(hInstance,MAKEINTRESOURCE(DialogID1),NULL,(DLGPROC)DlgProc);
  return 0;
}
