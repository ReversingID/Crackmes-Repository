
 CrackMe no.7 info
 coded by BadSector / K23

	Welcome to my next crackme. I didn't wanted to make it real
	hard  actually i think you will find it quite easy but only
	if you have some crypto knowledge. All rules are in the
	about box. Good luck, don't give up and have fun!

	You are welcome to send your solutions to bsector@iname.com 