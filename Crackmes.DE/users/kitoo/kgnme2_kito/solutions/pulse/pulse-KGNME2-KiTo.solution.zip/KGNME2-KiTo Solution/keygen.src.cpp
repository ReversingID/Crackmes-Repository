#include "stdafx.h"
#include "stdlib.h"

char name[20];
int i,serial;

int main()
{
	printf("Keygen for KiTO's Keygen Me 2 by pulse\n\n");
	
	printf("Name: ");
	gets(name);

	if (strlen(name) >= 4)
	{
		for (i=0; i < strlen(name); i++)
		{
			serial = serial+name[i];
		}
		
		serial = serial*0x539;

	printf("Serial: %d\n\n",serial);
	system("pause");
	}
	
	else 
	{
		printf("Name must be 4+ chars.\n\n");
		system("pause");
	}

	return 0;
}
