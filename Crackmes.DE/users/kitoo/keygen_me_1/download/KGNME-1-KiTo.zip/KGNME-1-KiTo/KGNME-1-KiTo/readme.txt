
      ___                                   ___     
     /__/|        ___           ___        /  /\    
    |  |:|       /  /\         /  /\      /  /::\   
    |  |:|      /  /:/        /  /:/     /  /:/\:\  
  __|  |:|     /__/::\       /  /:/     /  /:/  \:\ 
 /__/\_|:|____ \__\/\:\__   /  /::\    /__/:/ \__\:\
 \  \:\/:::::/    \  \:\/\ /__/:/\:\   \  \:\ /  /:/
  \  \::/~~~~      \__\::/ \__\/  \:\   \  \:\  /:/ 
   \  \:\          /__/:/       \  \:\   \  \:\/:/  
    \  \:\         \__\/         \__\/    \  \::/   
     \__\/                                 \__\/    
		Just KeyGen this baby!
	Level: 2/10 (should be pretty easy I think...)
	Coded in c++

	For u swedish cracking guys... http://www.geocities.com/debuggah/
	Hmm... greetz is in teh exe....