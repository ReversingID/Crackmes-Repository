/* 
 * fungos - fungos@gmail.com
 * http://bucaneiros.no-ip.org/~fungos
 * Just decrypt the built in password of grainne2.
 */

#include <stdio.h>
#include <stdlib.h>

int main()
{
	unsigned char key[] = {"Jsysy?pIGMg"};
	unsigned int i;
	
	for (i = 0; i < 10 ; i++)
	{
	    key[i] ^= (0x1a + i);
	}
	
	fprintf(stdout, "Password is: %s\n", key);
	
	return EXIT_SUCCESS;
}

