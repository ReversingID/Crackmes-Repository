/*
 * fungos - fungos@gmail.com
 * http://bucaneiros.no-ip.org/~fungos
 * This will just patch the bad boy from grainne2 so all passwords are accepted.
 */

#include <stdio.h>
#include <stdlib.h>

int main()
{
	unsigned char b1, b2;
	FILE *fp = fopen("grainne2", "r+");

	if (!fp)
	{
		fprintf(stdout, "file 'grainne2' not found.\n");
		return EXIT_FAILURE;	
	}

	fseek(fp, 0x2c2, SEEK_SET);

	b1 = fgetc(fp);
	b2 = fgetc(fp);
	
	if (b1 == 0x75 && b2 == 0x27)
	{
		fprintf(stdout, "Patching...");
		
		fseek(fp, 0x2c2, SEEK_SET);
		fputc(0x90, fp);
		fputc(0x90, fp);

		fclose(fp);
		fprintf(stdout, "done.\n");
        	return EXIT_SUCCESS;
	}

	fclose(fp);
	fprintf(stdout, "Invalid binary.\n");
        return EXIT_FAILURE;
}

