This is my solution to crackme grainne2 from stefanie - http://www.crackmes.de/users/stefanie/grainne2/

key.c - to find the correct key for this crackme
patch.c - to patch this crackme so any key will be accepted
keygen.c - to patch built in password with a new one from user input
grainne2.asm - reconstructed and deobfuscated source code with some explaination inside. read it.

Fungos Bauux (aka fungos)
http://bucaneiros.no-ip.org/~fungos
fungos@gmail.com
