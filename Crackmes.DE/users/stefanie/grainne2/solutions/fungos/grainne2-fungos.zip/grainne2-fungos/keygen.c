/*
 * fungos - fungos@gmail.com
 * http://bucaneiros.no-ip.org/~fungos
 * This is a test for patching built in password with a new one from user input. Just for fun :D
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv)
{
	unsigned int i;
	unsigned char key[] = {"Jsysy?pIGMg"};
	FILE *fp;

	fprintf(stdout, "fungos grainne2 fake keygen :-)  (fungos@gmail.com)\n");
	if (argc != 2)
	{
		fprintf(stdout, "usage: %s <new key>\n\n", argv[0]);
		return EXIT_SUCCESS;
	}

	if (strlen(argv[1]) != 11)
	{
		fprintf(stderr, "password need be 11 chars long.\n");
		return EXIT_FAILURE;
	}

	fp = fopen("grainne2", "r+");

	if (!fp)
	{
		fprintf(stdout, "file 'grainne2' not found.\n");
		return EXIT_FAILURE;	
	}

	// find string and validate

	fseek(fp, 0x1a2, SEEK_SET);
	for (i = 0; i < strlen(key); i++)
	{
		if (fgetc(fp) != key[i])
		{
			fclose(fp);
			fprintf(stderr, "Invalid binary.\n");
			return EXIT_FAILURE;
		}
	}

	// patch string	
	
	fseek(fp, 0x1a2, SEEK_SET);

	fprintf(stdout, "Keygening :D ");
	for (i = 0; i < strlen(key); i++)
	{
		if (i < 10)
        		fputc(argv[1][i] ^ (0x1a + i), fp);
		else
			fputc(argv[1][i], fp);	
	}
	
	fclose(fp);	
	fprintf(stdout, "done.\n");
        return EXIT_SUCCESS;
}

