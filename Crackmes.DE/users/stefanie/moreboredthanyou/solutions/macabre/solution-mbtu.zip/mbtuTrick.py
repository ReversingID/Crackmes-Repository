# subterfugue Trick
#
# AU Crew - macabre
#
from Trick import Trick

import sys

class mbtu(Trick):
    def usage(self):
        return """
	Used for quickly defeating the MoreBoredThanYou crackme
	by stefanie (aka niel anthony acuna)
        Intercepts the Ptrace debugger trap and socketcalls
"""

    def __init__(self, options):
        self.verbose = 0
	if options.has_key('verbose'):
	     self.verbose = 1
    
    def callbefore(self, pid, call, args):
	if call == 'ptrace':
		if self.verbose == 1:
		    sys.stderr.write('[+] Intercepted PTRACE call and faked response\n')
	        return (None, 0, None, None)
	if call == 'socketcall':
		if self.verbose == 1:
		    sys.stderr.write('[+] Intercepted socketcall and faked response\n')
		return (None, 0, None, None)

    def callmask(self):
        return { 'ptrace' : 1 , 'socketcall' : 1 }

