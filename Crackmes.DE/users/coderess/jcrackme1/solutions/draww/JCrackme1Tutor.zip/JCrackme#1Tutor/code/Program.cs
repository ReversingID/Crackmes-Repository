﻿using System;
using System.IO;
using System.Text;

namespace JCrackme1Solution
{
    class Program
    {
        static void Main(string[] args)
        {
            char[] alfabe = new char[] { '0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F' };
            StringBuilder sb = new StringBuilder();
            Random rnd = new Random();
            sb.Append("DRAWWALIEN");
            for (int i=0; i<9990; i++)
            {
                sb.Append(alfabe[rnd.Next(0, 15)]);
            }
            sb.Append('#');
            for (int j = 0; j < 100; j++)
            {
                sb.Append(alfabe[rnd.Next(0, 15)]);
            }
            using (StreamWriter outfile = new StreamWriter("keyfile.txt"))
            {
                outfile.Write(sb.ToString());
            }
        }
    }
}
