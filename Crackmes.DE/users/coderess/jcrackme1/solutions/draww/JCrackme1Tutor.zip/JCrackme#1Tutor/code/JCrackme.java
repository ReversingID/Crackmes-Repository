import java.awt.Color;
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout.ParallelGroup;
import javax.swing.GroupLayout.SequentialGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.UnsupportedLookAndFeelException;

public class JCrackme
  extends JFrame
{
  private JButton jButton1;
  private JLabel jLabel1;
  private JLabel jLabel2;
  private JPanel jPanel1;
  
  public JCrackme()
  {
    initComponents();
  }
  
  private void initComponents()
  {
    jPanel1 = new JPanel();
    jLabel1 = new JLabel();
    jButton1 = new JButton();
    jLabel2 = new JLabel();
    
    setDefaultCloseOperation(3);
    setTitle("JCrackme#1");
    setBackground(new Color(102, 102, 102));
    
    jPanel1.setBackground(new Color(102, 102, 102));
    
    jLabel1.setForeground(new Color(255, 255, 255));
    jLabel1.setText("Registration data:");
    
    jButton1.setBackground(new Color(51, 255, 0));
    jButton1.setForeground(new Color(0, 51, 153));
    jButton1.setText("Check it!");
    jButton1.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent evt)
      {
        JCrackme.this.jButton1ActionPerformed(evt);
      }
    });
    jLabel2.setForeground(new Color(255, 255, 255));
    jLabel2.setText("You must put keyfile.txt in folder with JCrackme#1");
    
    GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
    jPanel1.setLayout(jPanel1Layout);
    jPanel1Layout.setHorizontalGroup(jPanel1Layout
      .createParallelGroup(GroupLayout.Alignment.LEADING)
      .addGroup(jPanel1Layout.createSequentialGroup()
      .addContainerGap()
      .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
      .addGroup(jPanel1Layout.createSequentialGroup()
      .addComponent(jLabel1)
      .addGap(0, 0, 32767))
      .addGroup(jPanel1Layout.createSequentialGroup()
      .addComponent(jLabel2)
      .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(jButton1, -1, 93, 32767)))
      .addContainerGap()));
    
    jPanel1Layout.setVerticalGroup(jPanel1Layout
      .createParallelGroup(GroupLayout.Alignment.LEADING)
      .addGroup(jPanel1Layout.createSequentialGroup()
      .addContainerGap()
      .addComponent(jLabel1)
      .addGap(2, 2, 2)
      .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
      .addComponent(jButton1)
      .addComponent(jLabel2))
      .addContainerGap(-1, 32767)));
    
    GroupLayout layout = new GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(layout
      .createParallelGroup(GroupLayout.Alignment.LEADING)
      .addComponent(jPanel1, -2, -1, -2));
    
    layout.setVerticalGroup(layout
      .createParallelGroup(GroupLayout.Alignment.LEADING)
      .addComponent(jPanel1, -2, -1, -2));
    
    pack();
    setLocationRelativeTo(null);
  }
  
  private void jButton1ActionPerformed(ActionEvent evt)
  {
    if (checkFileLength("keyfile.txt") < 0)
    {
      JOptionPane.showMessageDialog(this, "Bad keyfile! Try more harder it is really easy!", "Error data", 0);
      return;
    }
    JOptionPane.showMessageDialog(this, "Your keyfile successfully adopted!\nOur Congratulations! Write a solution and keygen!", "Successfull data", 1);
  }
  
  public static int checkFileLength(String fileName)
  {
    File f = new File(fileName);
    StringBuilder sb = new StringBuilder();
    long length = 0L;
    if (!f.exists()) {
      return -1;
    }
    length = f.length();
    System.out.println(length);
    if (checkLength(length) == 1) {
      return -1;
    }
    try
    {
      BufferedReader br = new BufferedReader(new FileReader(f.getAbsoluteFile()));
      try
      {
        String s;
        while ((s = br.readLine()) != null)
        {
          sb.append(s);
          sb.append("\n");
        }
        int l1 = (int)length - 101;
        char endc = sb.charAt(l1);
        sb.deleteCharAt(l1);
        System.out.println(endc);
        int i;
        for (int l = 0; l <= l1; l++) {
          if ((sb.charAt(l) != '\n') && 
            ((sb.charAt(l) < 'A') || (sb.charAt(l) > 'Z')) && ((sb.charAt(l) < '0') || (sb.charAt(l) > '9')) && ((sb.charAt(l) < 'A') || (sb.charAt(l) > 'F'))) {
            return -1;
          }
        }
        int a = endc;
        a ^= 0x30;
        if (a == 19) {
          return 0;
        }
      }
      finally
      {
        br.close();
      }
      System.out.println();
    }
    catch (IOException e)
    {
      throw new RuntimeException(e);
    }
    return -1;
  }
  
  public static byte checkLength(long x)
  {
    long x_ = x;long b = 0L;
    x_ += 4L;
    x_ <<= 3;
    x_ += 16L;
    x_ -= 7L;
    b = x_ - 80849L;
    if (b == 0L) {
      return 0;
    }
    return 1;
  }
  
  public void MessageBox(String s)
  {
    JOptionPane.showMessageDialog(null, s);
  }
  
  public static void main(String[] args)
  {
    try
    {
      for (UIManager.LookAndFeelInfo info : ) {
        if ("Nimbus".equals(info.getName()))
        {
          UIManager.setLookAndFeel(info.getClassName());
          break;
        }
      }
    }
    catch (ClassNotFoundException ex)
    {
      Logger.getLogger(JCrackme.class.getName()).log(Level.SEVERE, null, ex);
    }
    catch (InstantiationException ex)
    {
      Logger.getLogger(JCrackme.class.getName()).log(Level.SEVERE, null, ex);
    }
    catch (IllegalAccessException ex)
    {
      Logger.getLogger(JCrackme.class.getName()).log(Level.SEVERE, null, ex);
    }
    catch (UnsupportedLookAndFeelException ex)
    {
      Logger.getLogger(JCrackme.class.getName()).log(Level.SEVERE, null, ex);
    }
    EventQueue.invokeLater(new Runnable()
    {
      public void run()
      {
        new JCrackme().setVisible(true);
      }
    });
  }
}
