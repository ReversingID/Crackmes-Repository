﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.IO;

namespace rbs_keygen
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Text.ASCIIEncoding ascenc = new System.Text.ASCIIEncoding();
            RijndaelManaged rm = new RijndaelManaged();
            rm.BlockSize = 128;
            rm.KeySize = 256;
            ICryptoTransform ict = rm.CreateEncryptor(ascenc.GetBytes("09887778"), ascenc.GetBytes("redbeansredbeans"));

            string name = (0 == args.Length) ? "ReWolf" : args[0].Replace(" ", "");

            byte[] result;
            using (MemoryStream msEncrypt = new MemoryStream())
            {
                using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, ict, CryptoStreamMode.Write))
                {
                    using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                    {
                        swEncrypt.Write(name);
                    }
                    result = msEncrypt.GetBuffer();
                }
            }
            string serial = Convert.ToBase64String(result).Replace("/", "").Replace("-", "").Replace("+", "").ToUpper();
            serial = serial.Substring(0, 4) + "-" + serial.Substring(4, 4) + "-" + serial.Substring(8, 4) + "-" + serial.Substring(12, 4);
            System.Console.WriteLine("Name: " + name + "\nKey: " + serial);
        }
    }
}
