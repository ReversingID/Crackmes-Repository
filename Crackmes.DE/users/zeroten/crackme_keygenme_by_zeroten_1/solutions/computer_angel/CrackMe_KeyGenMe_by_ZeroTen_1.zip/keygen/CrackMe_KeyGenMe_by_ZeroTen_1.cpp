// CrackMe_KeyGenMe_by_ZeroTen_1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>
#include <stdio.h>
#include <conio.h>


int _tmain(int argc, _TCHAR* argv[])
{
	CHAR buffer[100];
	size_t count;
	DWORD hash=0;

	printf("Input username:");
	_cgets_s((PCHAR)buffer,100,&count);
	int slength=strlen(buffer);
	
//	.text:00401A5E lea     edi, [ecx+ecx*4]                ; begin calc
//.text:00401A5E                                         ; edi=length+length*4
//.text:00401A61 lea     eax, [ebp+username]             ; result
//.text:00401A64 mov     edx, 2                          ; a2
//.text:00401A69 lea     edi, [ecx+edi*4]                ; edi=ecx+edi*4
//.text:00401A6C shl     edi, 3                          ; edi=edi shl 3
//.text:00401A6F sub     edi, ecx                        ; edi=edi-ecx
//.text:00401A71 lea     edi, [ecx+edi*8]                ; edi=edi*8+ecx
//.text:00401A74 add     edi, 7331
	__asm {
		pushad
		pushfd
		mov ecx,slength
		lea edi, [ecx+ecx*4]
		mov     edx, 2
		lea     edi, [ecx+edi*4]
		shl     edi, 3
		sub     edi, ecx
		lea     edi, [ecx+edi*8]
		add     edi, 7331
		mov		hash,edi
		popfd
		popad
	};

	//hash=1337+strlen(buffer)+7331;

	printf("Password = %i\n",(hash + 7331));
	printf("Serial = %i\n",(hash - 7331));

	getchar();

	return 0;
}

