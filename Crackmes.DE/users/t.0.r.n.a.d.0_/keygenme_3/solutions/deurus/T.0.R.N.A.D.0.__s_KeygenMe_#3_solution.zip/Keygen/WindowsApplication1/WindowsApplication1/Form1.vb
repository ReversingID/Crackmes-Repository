﻿Public Class Form1
    Dim var1 As Long
    Dim var2 As Long
    Dim var3 As Long
    Dim var4 As Long
    Dim temp1 As Long
    Dim temp2 As Long
    Dim pass As Long
    Dim namecalc As Object

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        If Len(TextBox1.Text) < 8 Then
            TextBox2.Text = "min 8 chars"
        Else
            var1 = 3134320653 'BAD1F00D
            var2 = 283028737  '10DEAD01
            var3 = 269532911  '1010BEEF
            var4 = 268548816  '1001BAD0
            'calc with the last name char
            pass = Asc(Mid(TextBox1.Text, 1, Len(TextBox1.Text)))
            temp1 = Asc(Mid(TextBox1.Text, Len(TextBox1.Text), Len(TextBox1.Text))) * 123 '123 = &H7B
            temp1 = temp1 Xor var1
            temp1 = temp1 Xor (Len(TextBox1.Text) * 321) '321 = &H141
            temp1 = temp1 Xor var4
            'calc with the first name char
            temp2 = Asc(Mid(TextBox1.Text, 1, 1)) * 123
            temp2 = temp2 Xor var3
            temp2 = temp2 Xor (Len(TextBox1.Text) * 321)
            temp2 = temp2 Xor var2
            temp2 = temp2 Xor 16843009
            'For take the name
            namecalc = Len(TextBox1.Text)
            namecalc = (namecalc - 6) / 2
            namecalc = CInt(Fix(namecalc))
            pass = temp1 + temp2 + Asc(Mid(TextBox1.Text, Len(TextBox1.Text), Len(TextBox1.Text)))
            TextBox2.Text = "L-" & Len(TextBox1.Text) & "-" & Mid(TextBox1.Text, namecalc, 6) & "-" & StrReverse(Hex(pass))
        End If
    End Sub
End Class
