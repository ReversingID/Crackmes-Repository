
>>>>    READ-ME FOR T.0.R.N.A.D.0.'s KeyGenMe #6
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

PLATFORM     ::   WINDOWS

LANGUAGE     ::   .NET  

DIFFICULTY   ::   4        [ Needs Special Knowledge ]

------------------==============-------------

SUBMITTED BY  ::   T.0.R.N.A.D.0.

------------------==============-------------

The Rules:
==========---

    (*) NO PATCHING

    (*) NO BRUTE-FORCING



The Tasks:
==========---

    1. Find the algorithm for the computations involved.


    2. Try to get Status as ":-)".


    3. Make keygen to generate VALID Keys for ANY name.
       Please note that VALID KEYS EXIST FOR ALL NAMES.

       **  Keygens, able to generate multiple keys for each name will be preferred.  **


    4. Write a descent tutorial. ;)



Hint:
==========---

Well, no hints ;) This is .NET ! I'm giving my source code.


~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_

	printf("T.0.R.N.A.D.0. - born 2 %X\n",49374);

_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~