
>>>>    READ-ME FOR T.0.R.N.A.D.0.'s KeyGenMe #1
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

PLATFORM     ::   WINDOWS

LANGUAGE     ::   VB 6.0  [ No protection  ]

DIFFICULTY   ::   3       [ Getting Harder ]

------------------==============-------------

SUBMITTED BY  ::   T.0.R.N.A.D.0.

------------------==============-------------

The Rules:
==========---

    (*) NO PATCHING

    (*) NO BRUTE-FORCING



The Tasks:
==========---

    1. Find algorithm for key and color calculations.


    2. Make keygen to generate key and color code for a given user-name.
       [  The program accepts a particular color out of 9 colors for each user.
          The 9 colors are : RED, GREEN, BLUE, YELLOW, CYAN, MAGENTA, BLACK, WHITE, GREY.
          So, either your keygen can show the color or it can just name it.
	  Particularly for C/C++ programmers, you can just display the color name.          ]


    3. Write a tutorial. ;)



~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_

	printf("T.0.R.N.A.D.0. - born 2 %X\n",49374);

_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~