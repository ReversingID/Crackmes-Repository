
>>>>    READ-ME FOR T.0.R.N.A.D.0.'s KeyGenMe #1
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

PLATFORM     ::   WINDOWS

LANGUAGE     ::   C / C++  [ No protection  ]

DIFFICULTY   ::   3        [ Getting Harder ]

------------------==============-------------

SUBMITTED BY  ::   T.0.R.N.A.D.0.

------------------==============-------------

The Rules:
==========---

    (*) NO PATCHING

    (*) NO BRUTE-FORCING



The Tasks:
==========---

    1. Try to get Validation Status as "OK".


    2. Find the algorithm for the computations involved.


    3. Make keygen to generate RefID and Key.


    4. Write a descent tutorial. ;)



Hints:
==========---

    1. The serial can consists of the entire array of visible chracters, but
       only 4 different characters would also be enough.

    2. THE 4 different characters are ( 2 * Alphabets ) + ( 2 * Numbers )

    3. ANY set of 4 different [ even though they too may be ( 2 * Alphabets )
       + ( 2 * Numbers ) ]  characters won't work.
       There exists ONLY 1 such set.

    4. Most important HINT : Idea of this is inspired by bRaInF**k.



~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_

	printf("T.0.R.N.A.D.0. - born 2 %X\n",49374);

_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~