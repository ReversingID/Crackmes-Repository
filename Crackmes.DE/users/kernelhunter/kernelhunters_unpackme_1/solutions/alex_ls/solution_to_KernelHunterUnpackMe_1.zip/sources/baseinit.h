//baseinit.h

#ifndef BASEINIT_H
#define BASEINIT_H

// includes
#define WINDOWS_LEAN
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>

#include "resource.h"

// defines
#define NAME_INFO		"Keygen for crackme KernelHunter's UnpackMe_1"

#define MAX_NAME   256
#define MAX_SERIAL 256
// errors
#define NAMELENGTH_ERROR		"Name must be 1 - 256 chars long!"

#endif