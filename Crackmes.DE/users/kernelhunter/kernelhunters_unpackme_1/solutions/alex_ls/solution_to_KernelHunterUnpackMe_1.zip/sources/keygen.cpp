// keygen to BarbecueMe_1
// coded by alex_ls

// includes
#include "baseinit.h"

// global wnd variables
static HINSTANCE hInstance;
HICON hIcon;

void StartProcess(char* sz_name)
{
	DWORD dw_hash=0;
	DWORD dw_pos=0;
	while(sz_name[dw_pos])
		dw_hash+=sz_name[dw_pos++]*0xF423F;
	sprintf(sz_name,"COMP-%x-313",dw_hash);
	return;
};

// generate serial
DWORD WINAPI GenerateSerial(HWND hwnd)
{
	char    sz_name[0x100]={0};
	DWORD   dw_namelen=0x100;
	dw_namelen = GetDlgItemTextA(hwnd, IDC_NAME, (char*)sz_name, dw_namelen);
	
	// get username from dialog
	if ((dw_namelen > 1 )&& (dw_namelen<256))
	{
		StartProcess(sz_name);
		SetDlgItemText(hwnd, IDC_SERIAL, sz_name);
	}
	else
		SetDlgItemText(hwnd, IDC_NAME, NAMELENGTH_ERROR);
	return 0;
}
// wndproc function
INT_PTR CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam)
{
	switch (Message)
	{
		// init dialogbox
		case WM_INITDIALOG:
			
			SetWindowText(hwnd, NAME_INFO);
			SetDlgItemText(hwnd, IDC_NAME, "alex_ls");
			SetDlgItemText(hwnd, IDC_SERIAL, "COMP-2c588718-313");
			SendDlgItemMessage(hwnd, IDC_NAME, EM_LIMITTEXT, MAX_NAME,0);
			SetFocus(GetDlgItem(hwnd,IDC_NAME));
			
			// Icon
			hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDD_DIALOG1));
			return true;
		break;

		// commands
		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
				// push generate button
				case IDC_CREATESERIAL:
					GenerateSerial(hwnd);
					break;
				// push exit button
				case IDC_EXIT:
					EndDialog(hwnd, 0);
					break;
			}
		break;
		
		// exit prog
		case WM_CLOSE:
			EndDialog(hwnd, 0);
		break;
		
		default:
			return FALSE;
	}
	return TRUE;
}

// main func
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInst, LPSTR lpCmd, int nShow)
{
	hInstance = GetModuleHandle(NULL);
	hInst =		hInstance;
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, (DLGPROC)WndProc, (LPARAM)NULL);
	return 0;
}