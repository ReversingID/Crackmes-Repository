This one is trivial KeygenMe, protected with my packer.
Anti-debug/Anti-Re tricks are used.

Your task is to:

1.Obtain clean dump of protected exe (get rid of protective layer)
2.Do keygen
3.Make Auto-Unpacker (if you feel good enough :)
4.Write good solution for others to learn.

regards 
kernelhunter@yahoo.com 
