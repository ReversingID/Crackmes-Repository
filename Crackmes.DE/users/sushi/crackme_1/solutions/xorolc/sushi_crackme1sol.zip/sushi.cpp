#include <stdio.h>
#include <windows.h>


int main(){  

unsigned long DataType;
unsigned char DataBuffer[25]={0};
unsigned int i,x,x1,x2,y,y1,y2;

HKEY hKey;
DWORD KeySize = 25;

RegOpenKeyEx(HKEY_LOCAL_MACHINE,"Software\\Microsoft\\Windows\\CurrentVersion", 0, KEY_READ, &hKey);
RegQueryValueEx(hKey, "RegisteredOwner", 0, &DataType, DataBuffer, &KeySize);
RegCloseKey(hKey);

i = lstrlen(DataBuffer);

if(i < 6){
printf("The Registered Owner Of This Machine Must Be At Least 6 Characters");
}

else{
 
x = DataBuffer[0];
y = DataBuffer[1];
x1 = DataBuffer[2];
y1 = DataBuffer[3];
x2 = DataBuffer[4];
y2 = DataBuffer[5];

SetCursorPos(x, y);
printf("Press Enter"); // I had to put this in, it wouldn't work without it??
getchar();
SetCursorPos(x1, y1);
printf("Press Enter Again");
getchar();
SetCursorPos(x2, y2);
}

return 0;
}