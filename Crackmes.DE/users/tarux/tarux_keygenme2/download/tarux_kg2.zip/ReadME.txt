
                                       TARUX! KeygenME#2

---------------------------------------

 Coder     : TaRuX! [17 Years old]
 Email      : kallida@caramail.com
 Country : Morocco
 Date      : �27-�09-�2002 ��18:05 GMT
 Level     : YOU DECIDE !! (I estimate 4-7/10)

-----------------------------------------

 Hello everyBody !! this is my second KeyGenME !!
 Try to write a KeyGen (ASM,C++ would be welcome)
 and let me know about your nice success via email
 : kallida@caramail.com

 TASK            : Make a KeyGen ..

 PROTECTION :  NO INFO !!!!!
                        (mail me if you want some useful notes)

 GREETZ          :
                       - All members of arab's-gate forum ...
                       - IDE the cracker - Zdaroviz - HACKERGY ... 

-----------------------------------------------
