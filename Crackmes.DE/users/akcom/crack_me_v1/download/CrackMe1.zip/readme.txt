here it is, try to write a working keygen
for it and post it on www.crackmes.de,
no patching.

-akcom (akcom@akcom.org)