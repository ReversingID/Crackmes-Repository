Crackme #1 by Swiftdamnation...

The game is to find the serial routine, and write a keygen and tutorial.

RULES: No patching...

Have fun!
-Swift