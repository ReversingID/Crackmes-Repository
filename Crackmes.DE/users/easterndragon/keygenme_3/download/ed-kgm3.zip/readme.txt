This keygenme uses simple math. You do need to know a little math and have basic knowledge of FPU operations.

Only acceptable solution is a keygen.

Example key
Name: BOZOSLIVEHERE
Key : BD2AAAAB-3D2AAAAB-3D426E2D-BD0E9510
