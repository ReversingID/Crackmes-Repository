// MatrixKeyGen.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "time.h"
#include "stdlib.h"

int a,b,c,d,e,f,g,h,i;
int determinant;
void Randomize();

void main()
{
	printf("************************************************\n");
	printf(" CuTedEvil's Solution for Math-Crackme By Ap0x  \n");
	printf("************************************************\n");
	printf("\nFinding a valid serial:");
	
	while (determinant != 0x54)
	{
		Randomize();
		determinant =  (a * e * i);
		determinant += (b * f * g);
		determinant += (c * d * h);
		determinant -= (a * f * h);
		determinant -= (b * d * i);
		determinant -= (c * e * g);
	}

	printf("\nValid Serial Found:: \t");
	
	printf("%c%c%c%c%c%c%c%c%c",0x30+a,0x30+b,
		0x30+c,0x30+d,0x30+e,0x30+f,0x30+g,0x30+h,0x30+i);

	printf("\n\n\n\n\nPress CTRL+C to exit");
	for(;;) {}

}

void Randomize()
{	
	srand((unsigned) time(NULL));

do {

	do {
		a = (rand()%9)+1;
		b = (rand()%9)+1;
		c = (rand()%9)+1;		
	} while((13*a - 8*b + c) != 84);

		do {
			d = (rand()%9)+1;
			e = (rand()%9)+1;
			f = (rand()%9)+1;		
		} while((-d + 20*e - 13*f) != 84);

		do {
			g = (rand()%9)+1;
			h = (rand()%9)+1;
			i = (rand()%9)+1;		
		} while((-30*g + 12*h + 30*i)!= 84);

	} while(((e*i - h*f) != 13) ||
		((c*h - b*i) != -1) || 
		((b*f - e*c) != -30) ||
		(((g*f - d*i) != -8)));

	return;
}