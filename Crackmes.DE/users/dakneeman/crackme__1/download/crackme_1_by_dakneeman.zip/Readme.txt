===================================================
Program name: CrackMe #1 by DaKneeMan.exe
Author      : DaKneeMan
CrackMe date: 3 December 2003
Type        : Name - Serial
URL         : http://www.crackmes.de
===================================================


This is my FIRST CRACKME!!!


I don't think it's very easy; anyway you rate it.


First you have to enable the Name TextBox, the Serial TextBox and the Verify Button.


Rules: NO patch.
       NO sniff.
       ONLY KEYGEN!!!



Greets,
DaKneeMan