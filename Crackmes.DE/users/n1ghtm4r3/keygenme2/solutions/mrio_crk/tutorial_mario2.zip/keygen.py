from ctypes import *
import sys
libc = cdll.msvcrt
mydll = windll.md5_mod
md5_mod = mydll.md5_mod
md5_mod.restype = c_char_p

# --- Shmoocon 2011 Cryptography Challenge Pack ownership ;) ---
# --------------------------------------------------------------
def xgcd(x,y):
	a0=1; b0=0
	a1=0; b1=1

	if x<0: 
		x *= -1
		a0 = -1
	if y<0: 
		y *= -1
		b1 = -1
	
	if x<y:
		x,y,a0,b0,a1,b1 = y,x,a1,b1,a0,b0

	while 1:
		times = x/y
		x -= times*y
		a0 -= times*a1
		b0 -= times*b1
		if x==0:
			break
		x,y,a0,b0,a1,b1 = y,x,a1,b1,a0,b0

	# x is 0 -> y is gcd
	return [y,a1,b1]
			
def invmod(x,p):
	[gcd,a,b] = xgcd(x,p)

	if gcd != 1:
		raise ValueError
	
	if a<0:
		a += p;

	return a

# -----------------------------------------------------------

x = 0x5EC64239885A452A98BFD338F2B0CA08
q = 0xD7D3494B
p = 0xA769C4FFF2FEB4EC02CA3AEDE7B39A0D
g = 0x4A7B73F9612092541F585B7C1E26674B
y = 0x151C09B4064B0ED6F22EFCA1AAB08F98
k = 0xB00B5
# s = s2
# r = s1
# H(m) = MD5_mod(name)

if len(sys.argv) == 1:
    print "Input name!";
    quit()
	
result = md5_mod(sys.argv[1])
M = int(result.encode('hex'), 16)
s3 = pow(M, q, 0x8E66A4F24DB95843)

r = pow(g, k, p) % q
s = (invmod(k, q) * (M + (x*r))) % q

print '{0:8X}{1:8X}-{2:16X}'.format(r, s, s3)