﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace keygen
{

    class Valume
    {
        [DllImport("kernel32.dll")]
        private static extern long GetVolumeInformation(string PathName, StringBuilder VolumeNameBuffer, UInt32 VolumeNameSize, ref UInt32 VolumeSerialNumber, ref UInt32 MaximumComponentLength, ref UInt32 FileSystemFlags, StringBuilder FileSystemNameBuffer, UInt32 FileSystemNameSize);

        public long GetVolumeSerial(string strDriveLetter)
        {
            uint serNum = 0;
            uint maxCompLen = 0;
            StringBuilder VolLabel = new StringBuilder(256); // Label
            UInt32 VolFlags = new UInt32();
            StringBuilder FSName = new StringBuilder(256); // File System Name
            strDriveLetter += ":\\"; // fix up the passed-in drive letter for the API call
            long Ret = GetVolumeInformation(strDriveLetter, VolLabel, (UInt32)VolLabel.Capacity, ref serNum, ref maxCompLen, ref VolFlags, FSName, (UInt32)FSName.Capacity);
            return serNum;
            //return Convert.ToString(serNum);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {

            System.Console.WriteLine("Keygen for: [N1ghtm4r3 - KeygenMe1]");
            System.Console.WriteLine("Done by: mario");
            System.Console.WriteLine("Protection: Elgamal-8bit, DLP problem");
            System.Console.WriteLine();

            Valume val = new Valume();

            long x = val.GetVolumeSerial(Environment.SystemDirectory.Substring(0, 1));
            x = x & 0xFF;
            var y = (x - 0x68) % 0x82;
            string str = EncodeTo64("3B" + y.ToString("x"));
            System.Console.WriteLine("Serial is: " + str);

            System.Console.Read();
        }

        static public string EncodeTo64(string toEncode)
        {

            byte[] toEncodeAsBytes

                  = System.Text.ASCIIEncoding.ASCII.GetBytes(toEncode);

            string returnValue

                  = System.Convert.ToBase64String(toEncodeAsBytes);

            return returnValue;

        }
    }
}
