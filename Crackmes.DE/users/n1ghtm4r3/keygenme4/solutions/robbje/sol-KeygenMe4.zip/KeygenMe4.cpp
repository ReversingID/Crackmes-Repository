#include <iostream>
#include <cstdlib>
#include <cmath>
#include <ctime>

using namespace std;

int position(char c);
char positionT(int i);

int main(int argc, char* argv[])
{
	char key[14];

	// Get 5 random chars
	srand(time(NULL));
	for(int i = 0; i < 6; i++)
	{
		int num = rand() % 24;
		key[i] = positionT(num);
	}
	key[6] = '\0';
	cout << "Random First part of the key: " << key << endl;
	key[6] = '-';

	// Calculate the first sum
	int accu = 0;
	for(int i = 0; i < 6; i++)
		accu += position(key[i]) * (int) key[i];
  accu = accu * 78 + 105407849; // Hardcoded modification
	int fpcheck = accu;
	cout << "Decimal number we search in base 24 system: " << fpcheck << endl;

	// Calculate the sum in base 24 system
	int f[6];
	memset(f, 0, 6* sizeof(int));
	for(int i = 0; i < 6; i++)
	{
		f[i] = (int) (accu / pow(24, 5.0-i));
		accu -= (int) (f[i] * pow(24, 5.0-i));
		key[7+i] = positionT(f[i]);
	}
	key[13] = '\0';
	cout << "Full key: " << key << endl;

	// Check if the key is valid (optional)
	int a = position(key[7]);
	accu = 0;
	for(int j=0; j < 5; j++)
	{
		accu = (int) a * 24;
		int tmp = position(key[j+8]);
		accu += tmp;
		a = accu;
	}
	cout << "=== VALIDITY CHECK ===" << endl;
	cout << "First part checksum: " << fpcheck << endl;
	cout << "Second part checksum: " << accu << endl;

	if(accu == fpcheck)
		cout << "Good Boy!" << endl;
	else
		cout << "Bad Boy!" << endl;
	return 0;
}

int position(char c)
{
	char chrs[] = "BCWHSENF91JTLDYMOP2KR4A5";
	int i = 0;
	while(chrs[i] != c)
	{
		i++;
		if(i == 24)
			return -1;
	}
	return i;
}

char positionT(int i)
{
	char chrs[] =  "BCWHSENF91JTLDYMOP2KR4A5";
	return chrs[i];
}
