1. launch crack
2. enter your name, it must be one word without spaces
3. press "enter"
4. Name and Password will be saved in serial.txt