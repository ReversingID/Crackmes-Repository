Hi once again
 
If you did try me first crackme must have realised its same as last one.
Only difference is now you can write a keygen for your id or everybody else.

Again its packed to reduce size. No sice tricks no crypto plain and simple 
algo that can be easily keygenned.


Hi elfz and of course kao.

You can write me at oorjahalt@fastmail.fm