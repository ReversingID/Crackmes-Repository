3 crackme..
real simple!

1. DONT PATCH
2. get urself a serial
3. keygenme

Send solution to: evil_nwo@hotmail.com and of coruse www.crackmes.de

[CrackZ]Yoda aka TyR4eL