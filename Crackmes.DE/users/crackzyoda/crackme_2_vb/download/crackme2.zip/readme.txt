Hey Guys wassup?

Ok this is my second crackme.
the first was really easy and this shouldn't be much harder ;)

so here are your missions:

1. get yourself a working serial
2. try to keygen it

a little trick:
the serial depends on your system, i think you will see it when you look at code!


Send solution to: evil_nwo@hotmail.com and of coruse www.crackmes.de

[CrackZ]Yoda aka TyR4eL