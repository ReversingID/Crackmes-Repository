Hello reversers,

This is an edit to the 4th reversing level used in the DefCamp.ro contest

It uses an extremely weak encryption algorithm and you have to find the key to 
decrypt the goodboy message.
No anti-debugging, packing or protection. Pure crypto :)
(this is meant to be solved within a short time)

Enjoy

-ksydfius