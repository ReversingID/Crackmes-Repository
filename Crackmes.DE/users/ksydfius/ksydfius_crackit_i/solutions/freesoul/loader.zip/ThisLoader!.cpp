#include "stdafx.h"
#include <Windows.h>

#define EXENAME "ksydfius_1.exe"

bool error()
{	
	char errormsg[50];
	sscanf(errormsg, "Error: 0x%08X", GetLastError());
	return 0;
}	

unsigned int rol(unsigned int number, unsigned int n_bits = 1)
{
	return (unsigned int) ((number << n_bits) | (number >> (32-n_bits)));
}

unsigned int ror(unsigned int number, unsigned int n_bits = 1)
{
	return (unsigned int) ((number >> n_bits) | (number << (32-n_bits)));
}

int reverseBits(int number)			
{
	int retv=0;
	int temp = number;
	for(char i=0; i<32; i++) 
	{
		retv = retv << 1;
		retv = retv | (temp & 1);
		temp = temp >> 1;
	}
	return retv;
}


int decode(unsigned int cipher) {
unsigned int data=0;
unsigned int something = rol(0xC0DEC0DE, 7); // Start from end.

	for(char i=0; i<8; i++)
	{
		data ^= something; 
		data = reverseBits(rol(data)); 
		something = ror(something); 
	}


return data^cipher;
}

int indian(int number) {
	return (number >> 24) | ((number>>8) & 0x0000FF00) | ((number << 8) & 0x00FF0000) | (number << 24);
}

bool load(char* data)
{
	STARTUPINFOA si;
	PROCESS_INFORMATION pi;
	DWORD oldProtect;
	DWORD written;

	ZeroMemory( &si, sizeof(si) ); 
    si.cb = sizeof(si); 
    ZeroMemory( &pi, sizeof(pi) ); 

	if(!CreateProcess(EXENAME,"",0,0,0, CREATE_SUSPENDED,0,0,&si,&pi))
		return error();
	if(!VirtualProtectEx(pi.hProcess, (LPVOID) 0x00403000, 20, 0x40, &oldProtect))
		return error();
	if(!WriteProcessMemory(pi.hProcess, (LPVOID) 0x403000, data, 12, &written))
		return error();
	if(!ResumeThread(pi.hThread))
		return error();

	CloseHandle(pi.hProcess);
	CloseHandle(pi.hThread);
}

int switchz(int something, bool left=0, bool right=0)
{
	int _left = 0x40000000^0x20000000;
	int _right = 3;

	if(left)
	{
		if(right)
			return something^_left^_right;
		else
			return something^_left;
	} else {
		if(right)
			return something^_right;
		else
			return something;
	}
	
}

int _tmain(int argc, _TCHAR* argv[])
{

	int* bytes = new int[3];

	bytes[0] =switchz(decode(0x19496E48),1,0);
	bytes[1] =switchz( decode(0x394A0F4E),1,0);
	bytes[2] = switchz(decode(0x320D4F6E),0,0);

	printf("Password ready to paste: %08X%08X%08X\n\n", indian(bytes[0]), indian(bytes[1]), indian(bytes[2]));

	if(!load((char*)bytes))
		error();
	
	system("PAUSE");
	return 0;
}