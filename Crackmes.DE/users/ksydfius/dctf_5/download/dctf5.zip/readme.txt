Hello reversers,

This is one of the crackmes used in the DefCamp.ro CTF.
It is the 5th and final reversing level. If you look inside you should be able
to figure out why :)

It uses anti-debugging but no other protection as far as I am aware of.

There's no crypto this time, but it would have been more interesting if there 
was.

Enjoy

-ksydfius