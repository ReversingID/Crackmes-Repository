﻿Imports System.IO
Imports Microsoft.Win32

Public Class Form1
    Dim Al As Integer = Nothing
    Dim Dl As Integer = Nothing
    Dim eax As Integer = Nothing
    Dim ebx As Integer = Nothing
    Dim ecx As Integer = Nothing
    Dim edx As Integer = Nothing
    Dim i As Integer
    Dim j As Integer = 2
    Dim k As Integer
    Dim x As Integer = 10
    Dim y As Integer
    Dim storage As String
    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If My.Computer.FileSystem.DirectoryExists("C:\Windows\Temp\") Then
            'If The Folder Exists Do Nothing.
        Else
            ' If It Does Not Exists, Create It.
            MkDir("C:\Windows\Temp\")
        End If


        Dim ms As New IO.MemoryStream(My.Resources.Algorithm1)
        Dim fs As IO.FileStream = IO.File.OpenWrite("C:\Windows\Temp\Algorithm1.dat")
        ms.WriteTo(fs)
        fs.Close()


        Dim Algorithm1 As System.IO.StreamReader
        Algorithm1 = File.OpenText("C:\Windows\Temp\Algorithm1.dat")
        Do Until Algorithm1.EndOfStream
            TextBox1.Text = TextBox1.Text & Algorithm1.ReadLine
        Loop
        Algorithm1.Close()

        Dim ms2 As New IO.MemoryStream(My.Resources.Algorithm2)
        Dim fs2 As IO.FileStream = IO.File.OpenWrite("C:\Windows\Temp\Algorithm2.dat")
        ms2.WriteTo(fs2)
        fs2.Close()


        Dim Algorithm2 As System.IO.StreamReader
        Algorithm2 = File.OpenText("C:\Windows\Temp\Algorithm2.dat")
        Do Until Algorithm2.EndOfStream
            TextBox4.Text = TextBox4.Text & Algorithm2.ReadLine
        Loop
        Algorithm2.Close()

        Dim ms3 As New IO.MemoryStream(My.Resources.Algorithm3)
        Dim fs3 As IO.FileStream = IO.File.OpenWrite("C:\Windows\Temp\Algorithm3.dat")
        ms3.WriteTo(fs3)
        fs3.Close()

        Dim Algorithm3 As System.IO.StreamReader
        Algorithm3 = File.OpenText("C:\Windows\Temp\Algorithm3.dat")
        Do Until Algorithm3.EndOfStream
            TextBox2.Text = TextBox2.Text & Algorithm3.ReadLine
        Loop
        Algorithm3.Close()

        Dim ms4 As New IO.MemoryStream(My.Resources.Algorithm4)
        Dim fs4 As IO.FileStream = IO.File.OpenWrite("C:\Windows\Temp\Algorithm4.dat")
        ms4.WriteTo(fs4)
        fs4.Close()

        Dim Algorithm4 As System.IO.StreamReader
        Algorithm4 = File.OpenText("C:\Windows\Temp\Algorithm4.dat")
        Do Until Algorithm4.EndOfStream
            storage = storage & Algorithm4.ReadLine
        Loop
        Algorithm4.Close()

        Dim ms5 As New IO.MemoryStream(My.Resources.Solution_File)
        Dim fs5 As IO.FileStream = IO.File.OpenWrite("C:\Windows\Temp\Solution_File.rtf")
        ms5.WriteTo(fs5)
        fs5.Close()

        

    End Sub
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Button1.BackColor = Color.LightGreen
        Dim Key As String = Nothing
        Dim StrKey As String = Nothing

        TextBox3.Text = TextBox3.Text.Remove(0, 1)
        TextBox3.Text = TextBox3.Text.Insert(0, "T")
        'MsgBox(TextBox3.TextLength)
        If j = 480 Then
            If TextBox5.Visible = True And Label5.Visible = True Then
                TextBox5.Visible = False
                Label5.Visible = False
                Exit Sub
            End If
            Exit Sub
        End If
        Timer1.Start()
        Call Start()


    End Sub
    Public Sub Start()
        Dim strValue As String = Nothing
        Dim StrByte As String = Nothing
        StrByte = TextBox4.Text
        '(StrByte.Length > 0)
        strValue = (StrByte.Substring(i, 2)).ToString
        StrByte = StrByte.Substring(2, (StrByte.Length - 2))
        eax = Convert.ToInt64(strValue, &H10)
        Dl = eax Mod 32
        Call Subtract()
    End Sub
    Public Sub Subtract()
        Dim strValue As String = Nothing
        Dim StrByte As String = Nothing
        StrByte = TextBox4.Text
        '(StrByte.Length > 0)
        strValue = (StrByte.Substring(j, 2)).ToString
        StrByte = StrByte.Substring(2, (StrByte.Length - 2))
        ebx = Convert.ToInt64(strValue, &H10)
        ebx = ebx - Dl
        Call xXor()

    End Sub
    Public Sub xXor()
        Dim strValue As String = Nothing
        Dim StrByte As String = Nothing
        StrByte = TextBox1.Text
        'Do While (StrByte.Length > 0)
        strValue = (StrByte.Substring(j, 2)).ToString
        StrByte = StrByte.Substring(2, (StrByte.Length - 2))
        ecx = Convert.ToInt64(strValue, &H10)
        ecx = ecx Xor ebx
        Call tBox3()
        'Loop
    End Sub
    Public Sub tBox3()
        Dim Checx As String = Nothing
        Dim Charecx As String = Nothing
        Checx = Chr(ecx)
        Charecx = Chr(Dl + ebx)
        TextBox2.Text = TextBox2.Text.Remove(k, 1)
        TextBox2.Text = TextBox2.Text.Insert(k, Charecx)
        TextBox3.Text = TextBox3.Text.Remove(Dl, 1)
        TextBox3.Text = TextBox3.Text.Insert(Dl, Checx)
        i = i + 2
        j = j + 2
        k = k + 1
        Call Check()
    End Sub
    Public Sub Check()
        Dim i As Integer = Nothing
        Dim str As String = "-"
        i = InStr(TextBox3.Text, str)
        If i <= 0 And j = 480 Then
            Button3.Enabled = True
            Button3.BackColor = Color.Green
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click

        Dim FileToDelete As String = Nothing
        Dim FileToDelete2 As String = Nothing
        Dim FileToDelete3 As String = Nothing
        Dim FileToDelete4 As String = Nothing
        Dim FileToDelete5 As String = Nothing
        Dim FileToDelete6 As String = Nothing
        FileToDelete = "C:\Windows\Temp\Algoritm1.dat"
        FileToDelete2 = "C:\Windows\Temp\Algoritm2.dat"
        FileToDelete3 = "C:\Windows\Temp\Algoritm3.dat"
        FileToDelete4 = "C:\Windows\Temp\Algoritm4.dat"
        FileToDelete5 = "C:\Windows\Temp\Algoritm5.dat"
        FileToDelete6 = "C:\Windows\Temp\Algoritm6.dat"
        If System.IO.File.Exists(FileToDelete) = True Then
            System.IO.File.Delete(FileToDelete)
        End If
        If System.IO.File.Exists(FileToDelete2) = True Then
            System.IO.File.Delete(FileToDelete2)
        End If

        If System.IO.File.Exists(FileToDelete3) = True Then
            System.IO.File.Delete(FileToDelete3)
        End If

        If System.IO.File.Exists(FileToDelete4) = True Then
            System.IO.File.Delete(FileToDelete4)
        End If
        If System.IO.File.Exists(FileToDelete5) = True Then
            System.IO.File.Delete(FileToDelete5)
        End If

        If System.IO.File.Exists(FileToDelete6) = True Then
            System.IO.File.Delete(FileToDelete6)
        End If
        End
    End Sub
    Public Sub tfocus()
        Dim KeyCode As String = TextBox3.Text
        TextBox3.Clear()
        TextBox3.Text = KeyCode
        TextBox3.Focus()
    End Sub


    Private Sub Timer1_Tick(sender As System.Object, e As System.EventArgs) Handles Timer1.Tick
        Button1.PerformClick()
    End Sub

    Private Sub Label4_Click(sender As System.Object, e As System.EventArgs) Handles Label4.Click
        Call tfocus()
        TextBox3.Copy()
    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        TextBox2.Clear()
        TextBox4.Clear()
        TextBox5.Visible = True
        Label5.Visible = True
        Button4.BackColor = Color.Green
        Button1.BackColor = Color.Blue


        Label2.Text = "Text To Be Decrypted"
        Label3.Text = "Hex Value of Decrypted Text"
        Dim ms5 As New IO.MemoryStream(My.Resources.Algorithm5)
        Dim fs5 As IO.FileStream = IO.File.OpenWrite("C:\Windows\Temp\Algorithm5.dat")
        ms5.WriteTo(fs5)
        fs5.Close()


        Dim Algorithm5 As System.IO.StreamReader
        Algorithm5 = File.OpenText("C:\Windows\Temp\Algorithm5.dat")
        Do Until Algorithm5.EndOfStream
            TextBox4.Text = TextBox4.Text & Algorithm5.ReadLine
        Loop
        Algorithm5.Close()

        Dim ms6 As New IO.MemoryStream(My.Resources.Algorithm6)
        Dim fs6 As IO.FileStream = IO.File.OpenWrite("C:\Windows\Temp\Algorithm6.dat")
        ms6.WriteTo(fs6)
        fs6.Close()


        Dim Algorithm6 As System.IO.StreamReader
        Algorithm6 = File.OpenText("C:\Windows\Temp\Algorithm6.dat")
        Do Until Algorithm6.EndOfStream
            TextBox2.Text = TextBox2.Text & Algorithm6.ReadLine
        Loop
        Algorithm6.Close()
        x = 10
        y = 0
        Button4.Enabled = True
        

    End Sub

    Private Sub Label5_Click(sender As System.Object, e As System.EventArgs) Handles Label5.Click
        If TextBox5.Text = "science_m00nlight" Then
            If y = 200 Then
                Exit Sub
            End If
            Dim strValue As String = Nothing
            Dim StrByte As String = Nothing
            Dim Charecx As String = Nothing
            StrByte = storage
            'Do While (StrByte.Length > 0)
            strValue = (StrByte.Substring(y, 2)).ToString
            StrByte = StrByte.Substring(2, (StrByte.Length - 2))
            strValue = Convert.ToInt64(strValue, &H10)
            Charecx = Chr(strValue)


            TextBox2.Text = TextBox2.Text.Remove(x, 1)
            TextBox2.Text = TextBox2.Text.Insert(x, Charecx)
            x = x + 1
            y = y + 2
            If y = 200 Then
                Exit Sub
            End If
            'Loop
        Else
            MsgBox("Answer Is Wrong", MsgBoxStyle.Exclamation, "Wrong Answer")
        End If
    End Sub

    Private Sub Timer2_Tick(sender As System.Object, e As System.EventArgs) Handles Timer2.Tick
        Button4.PerformClick()
    End Sub

    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click
        If TextBox5.Text = "science_m00nlight" Then
            If y = 200 Then
                Timer2.Stop()
                Exit Sub
            End If
            Timer2.Start()
            Dim strValue As String = Nothing
            Dim StrByte As String = Nothing
            Dim Charecx As String = Nothing
            StrByte = storage
            'Do While (StrByte.Length > 0)
            strValue = (StrByte.Substring(y, 2)).ToString
            StrByte = StrByte.Substring(2, (StrByte.Length - 2))
            strValue = Convert.ToInt64(strValue, &H10)
            Charecx = Chr(strValue)


            TextBox2.Text = TextBox2.Text.Remove(x, 1)
            TextBox2.Text = TextBox2.Text.Insert(x, Charecx)
            x = x + 1
            y = y + 2
            If y = 200 Then
                Timer2.Stop()
                Exit Sub
            End If
            'Loop
        Else
            MsgBox("Answer Is Wrong", MsgBoxStyle.Exclamation, "Wrong Answer")
        End If
    End Sub

    Private Sub Label6_Click(sender As System.Object, e As System.EventArgs) Handles Label6.Click
        Dim Solution As String = Nothing
        Dim openFileDialog As OpenFileDialog = New OpenFileDialog
        OpenFileDialog1.InitialDirectory = "C:\Windows\Temp\Solution_File.rtf"

        Solution = OpenFileDialog1.InitialDirectory

        Process.Start(Solution)
    End Sub

    Private Sub Label6_MouseHover(sender As System.Object, e As System.EventArgs) Handles Label6.MouseHover
        Label6.BackColor = Color.Green
    End Sub

    Private Sub Label6_MouseLeave(sender As System.Object, e As System.EventArgs) Handles Label6.MouseLeave
        Label6.BackColor = Color.Empty
    End Sub

    Private Sub Label5_MouseHover(sender As System.Object, e As System.EventArgs) Handles Label5.MouseHover
        Label5.BackColor = Color.Blue
    End Sub

    Private Sub Label5_MouseLeave(sender As System.Object, e As System.EventArgs) Handles Label5.MouseLeave
        Label5.BackColor = Color.Empty
    End Sub

    Private Sub Label4_MouseHover(sender As System.Object, e As System.EventArgs) Handles Label4.MouseHover
        Label4.BackColor = Color.Blue
    End Sub

    Private Sub Label4_MouseLeave(sender As System.Object, e As System.EventArgs) Handles Label4.MouseLeave
        Label4.BackColor = Color.Empty
    End Sub
End Class
'If Timer1.Enabled = False Then
'            Button4.Text = "Stop Timer"
'            Button4.BackColor = Color.Red
'            Timer1.Start()
'            Exit Sub
'        End If

'        If Button4.Text = "Stop Timer" And Timer1.Enabled = True Then
'            Button4.Text = "Start Timer"
'            Button4.BackColor = Color.Green
'            Timer1.Stop()
'            j = 0
'            k = 0
'            l = 0
'        End If