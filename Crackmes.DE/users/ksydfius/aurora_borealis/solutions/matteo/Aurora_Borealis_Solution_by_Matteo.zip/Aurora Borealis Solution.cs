﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;
using System.Security.Cryptography;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private byte[] hash(byte[] data)
        {
            return System.Security.Cryptography.RIPEMD160.Create().ComputeHash(data);
        }

        private byte[] decrypt(byte[] data, byte[] key1, byte[] key2)
        {
            int num;
            byte[] buffer = new byte[key1.Length];
            for (num = 0; num < key1.Length; num++)
            {
                buffer[num] = (byte)(key1[num] * key2[num]);
            }
            for (num = 0; num < data.Length; num++)
            {
                data[num] = (byte)(data[num] ^ ((byte)(buffer[num % buffer.Length] + num)));
            }
            return data;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            char[] chArray = "Bvspsb`Cpsfbmjt`Mpbefs/Gpsn2".ToCharArray();
            for (int i = 0; i < chArray.Length; i++)
            {
                chArray[i] = (char)(chArray[i] - '\x0001');
            }
            string aaa = new string(chArray);//"Aurora_Borealis_Loader.Form1"

            System.IO.FileStream f = new System.IO.FileStream("Aurora_Borealis_Loader", System.IO.FileMode.Open, System.IO.FileAccess.Read);
            System.IO.BinaryReader r = new System.IO.BinaryReader(f);

            byte[] data = r.ReadBytes((int)f.Length);
            r.Close();
            f.Close();


            byte[] buffer2 = this.hash(Encoding.Default.GetBytes(".NET Protector" + "ksydfius"));
            byte[] buffer3 = this.hash(Encoding.Default.GetBytes(".NET Protector" + " " + "Version 1.0"));
            for (int i = 0; i < 50; i++)
            {
                buffer2 = this.hash(buffer2);
                buffer3 = this.hash(buffer3);
            }
            data = this.decrypt(data, buffer2, buffer3);

            System.IO.FileStream f2 = new System.IO.FileStream("Aurora_Borealis_Loader.exe", System.IO.FileMode.CreateNew, System.IO.FileAccess.Write);
            System.IO.BinaryWriter w2 = new System.IO.BinaryWriter(f2);
            w2.Write(data);
            w2.Close();

        }

        private string md5Part2(string str)
        {
            System.Security.Cryptography.MD5 md = System.Security.Cryptography.MD5.Create();
            byte[] bytes = Encoding.ASCII.GetBytes(str);
            byte[] buffer2 = md.ComputeHash(bytes);
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < buffer2.Length; i++)
            {
                builder.Append(buffer2[i].ToString("X2"));
            }
            return builder.ToString();
        }

        private byte[] sha256(string str)
        {
            return SHA256.Create().ComputeHash(Encoding.UTF8.GetBytes(str));
        }

        private byte[] md5asBytes(string str)
        {
            MD5 md = MD5.Create();
            byte[] bytes = Encoding.ASCII.GetBytes(str);
            return md.ComputeHash(bytes);
        }


        private byte[] decrypt2(byte[] data, byte[] key)
        {
            for (int i = 0; i < data.Length; i++)
            {
                data[i] = (byte)(data[i] ^ key[i % key.Length]);//key len = 16
            }
            return data; //riutilizza lo xor più volte, OTP, cifrario di V coso
        }

        private byte[] GetKey()
        {
            //"Aurora_Borealis_Loader.Form1"
            //Aurora_Borealis_Crackme.Form1 <--decrypt probabile
            byte[] chArr = Encoding.Default.GetBytes("Aurora_Borealis_Crackme.Form1");
            byte[] data = Encoding.Default.GetBytes("\x00e9\"3\x00c2\x000e\x00b8\x00f1\x00c6\x00ff\x00e5\x0005\x00be\x00de\x001f'\x00e9\x00eb% \x00ce\x0017\x00b4\x00cb\x00aa\x00d6\x00f8\x0012\x00b2ƒ");
            byte[] key = new byte[16];//data len = 29
            for (int i = 0; i < data.Length; i++)
            {
                //data[i] = (byte)(data[i] ^ key[i % key.Length]);//key len = 16
                if (i >= 16)
                {
                    if (key[i % key.Length] != (byte)(data[i] ^ chArr[i]))
                        MessageBox.Show("DOH");
                }
                key[i % key.Length] = (byte)(data[i] ^ chArr[i]);

            }
            return key;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string text = "crypto_analyser";
            string str2 = this.md5Part2(this.md5Part2(text));
            if (this.md5Part2(this.md5Part2(text)) == "200FA8DEDF693586BA939BD5E3DF8845")
            {
                byte[] key = this.md5asBytes(text);
                byte[] buffer2 = this.sha256(text);


                System.IO.FileStream f = new System.IO.FileStream("Aurora_Borealis_Crackme", System.IO.FileMode.Open, System.IO.FileAccess.Read);
                System.IO.BinaryReader r = new System.IO.BinaryReader(f);

                byte[] data = r.ReadBytes((int)f.Length);
                r.Close();
                f.Close();


                data = this.decrypt2(data, buffer2);
                byte[] bytes = Encoding.Default.GetBytes("\x00e9\"3\x00c2\x000e\x00b8\x00f1\x00c6\x00ff\x00e5\x0005\x00be\x00de\x001f'\x00e9\x00eb% \x00ce\x0017\x00b4\x00cb\x00aa\x00d6\x00f8\x0012\x00b2ƒ");
                bytes = this.decrypt2(bytes, key);
                try
                {
                    System.IO.FileStream f2 = new System.IO.FileStream("Aurora_Borealis_Crackme.exe", System.IO.FileMode.CreateNew, System.IO.FileAccess.Write);
                    System.IO.BinaryWriter w2 = new System.IO.BinaryWriter(f2);
                    w2.Write(data);
                    w2.Close();
                    //Form ownedForm = (Form)Assembly.Load(data).CreateInstance(Encoding.Default.GetString(bytes), true);
                    //base.AddOwnedForm(ownedForm);
                    //base.Hide();
                    //ownedForm.ShowDialog();
                    //Application.Exit();
                }
                catch (Exception)
                {
                    MessageBox.Show("This is not supposed to happen...", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            else
            {
                MessageBox.Show("Invalid password!", "Wrong!", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                Application.Exit();
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //http://hashkiller.co.uk/md5-decrypter.aspx

            //char[] chArray = "\x00e9\"3\x00c2\x000e\x00b8\x00f1\x00c6\x00ff\x00e5\x0005\x00be\x00de\x001f'\x00e9\x00eb% \x00ce\x0017\x00b4\x00cb\x00aa\x00d6\x00f8\x0012\x00b2ƒ".ToCharArray();
            //for (int i = 0; i < chArray.Length; i++)
            //{
            //    chArray[i] = (char)(chArray[i]);
            //}
            //string aaa = new string(chArray);

            //"é\"3Â¸ñÆÿå¾Þ'éë% Î´ËªÖø²ƒ"

            //"Aurora_Borealis_Loader.Form1"
            //Aurora_Borealis_Crackme.Form1 <--decrypt probabile
            byte[] chArr = Encoding.Default.GetBytes("Aurora_Borealis_Crackme.Form1");
            byte[] data = Encoding.Default.GetBytes("\x00e9\"3\x00c2\x000e\x00b8\x00f1\x00c6\x00ff\x00e5\x0005\x00be\x00de\x001f'\x00e9\x00eb% \x00ce\x0017\x00b4\x00cb\x00aa\x00d6\x00f8\x0012\x00b2ƒ");
            byte[] key = new byte[16];//data len = 29
            for (int i = 0; i < data.Length; i++)
            {
                //data[i] = (byte)(data[i] ^ key[i % key.Length]);//key len = 16
                if (i >= 16)
                {
                    if (key[i % key.Length] != (byte)(data[i] ^ chArr[i]))
                        MessageBox.Show("DOH");
                }
                key[i % key.Length] = (byte)(data[i] ^ chArr[i]);

            }


            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < key.Length; i++)
            {
                builder.Append(key[i].ToString("X2"));
            }
            Clipboard.SetText(builder.ToString());
            MessageBox.Show(builder.ToString(), "MD5(password)");


            //


            //riutilizza lo xor più volte, OTP, cifrario di Vigenère
        }

        //-----------------------------------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------------------------------
        //PART 3        PART 3        PART 3        PART 3        PART 3        PART 3        PART 3        PART 3        PART 3       
        //-----------------------------------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------------------------------
        private char[] shift(char[] str, int n)
        {
            char[] chArray = str;
            for (int i = 0; i < chArray.Length; i++)
            {
                chArray[i] = (char)(chArray[i] + ((char)n));
            }
            return chArray;
        }

        private byte[] md5(string str)
        {
            MD5 md = MD5.Create();
            byte[] bytes = Encoding.ASCII.GetBytes(str);
            return md.ComputeHash(bytes);
        }

        private byte[] condense(byte[] b)
        {
            byte[] buffer = new byte[b.Length - 1];
            for (int i = 0; i < (b.Length - 1); i++)
            {
                buffer[i] = (byte)(b[i] ^ b[i + 1]);
            }
            return buffer;
        }

        private byte[] sha512(string str)
        {
            return SHA512.Create().ComputeHash(Encoding.UTF8.GetBytes(str));
        }

        const int keySizeInBits = 0x80, blockSizeInBits = 0x80, Nb = 4, Nr = 10;

        byte[] BBox = new byte[] { 
        0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 1, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76, 
        0xca, 130, 0xc9, 0x7d, 250, 0x59, 0x47, 240, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0, 
        0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15, 
        4, 0xc7, 0x23, 0xc3, 0x18, 150, 5, 0x9a, 7, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75, 
        9, 0x83, 0x2c, 0x1a, 0x1b, 110, 90, 160, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84, 
        0x53, 0xd1, 0, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 190, 0x39, 0x4a, 0x4c, 0x58, 0xcf, 
        0xd0, 0xef, 170, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 2, 0x7f, 80, 60, 0x9f, 0xa8, 
        0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 210, 
        0xcd, 12, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 100, 0x5d, 0x19, 0x73, 
        0x60, 0x81, 0x4f, 220, 0x22, 0x2a, 0x90, 0x88, 70, 0xee, 0xb8, 20, 0xde, 0x5e, 11, 0xdb, 
        0xe0, 50, 0x3a, 10, 0x49, 6, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79, 
        0xe7, 200, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 8, 
        0xba, 120, 0x25, 0x2e, 0x1c, 0xa6, 180, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a, 
        0x70, 0x3e, 0xb5, 0x66, 0x48, 3, 0xf6, 14, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e, 
        0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 30, 0x87, 0xe9, 0xce, 0x55, 40, 0xdf, 
        140, 0xa1, 0x89, 13, 0xbf, 230, 0x42, 0x68, 0x41, 0x99, 0x2d, 15, 0xb0, 0x54, 0xbb, 0x16
     };
        private int[] UnzipTheKey(byte[] key)
        {
            int num5;
            int[] numArray = new int[0];
            int[] numArray2 = new int[] { 0, 0, 0, 0, 10, 0, 12, 0, 14 };
            int[] numArray3 = new int[] { 0, 0, 0, 0, 12, 0, 12, 0, 14 };
            int[] numArray4 = new int[] { 0, 0, 0, 0, 14, 0, 14, 0, 14 };
            int[][] numArray5 = new int[][] { numArray, numArray, numArray, numArray, numArray2, numArray, numArray3, numArray, numArray4 };
            byte[] buffer = new byte[] { 
        1, 2, 4, 8, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36, 0x6c, 0xd8, 0xab, 0x4d, 0x9a, 0x2f, 
        0x5e, 0xbc, 0x63, 0xc6, 0x97, 0x35, 0x6a, 0xd4, 0xb3, 0x7d, 250, 0xef, 0xc5, 0x91
     };
            int[] numArray6 = new int[0x2c];
            int index = keySizeInBits / 0x20;
            int num3 = blockSizeInBits / 0x20;
            int num4 = numArray5[index][num3];
            for (num5 = 0; num5 < index; num5++)
            {
                numArray6[num5] = ((key[4 * num5] | (key[(4 * num5) + 1] << 8)) | (key[(4 * num5) + 2] << 0x10)) | (key[(4 * num5) + 3] << 0x18);
            }
            for (num5 = index; num5 < (num3 * (num4 + 1)); num5++)
            {
                int num = numArray6[num5 - 1];
                if ((num5 % index) == 0)
                {
                    num = (((BBox[(num >> 8) & 0xff] | (BBox[(num >> 0x10) & 0xff] << 8)) | (BBox[(num >> 0x18) & 0xff] << 0x10)) | (BBox[num & 0xff] << 0x18)) ^ buffer[(int)(Math.Floor((double)(((double)num5) / ((double)index))) - 1.0)];
                }
                else if ((index > 6) && ((num5 % index) == 4))
                {
                    num = (((BBox[(num >> 0x18) & 0xff] << 0x18) | (BBox[(num >> 0x10) & 0xff] << 0x10)) | (BBox[(num >> 8) & 0xff] << 8)) | BBox[num & 0xff];
                }
                numArray6[num5] = numArray6[num5 - index] ^ num;
            }
            return numArray6;
        }

        private string l337Encrypt(string str, byte[] key)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(str);
            TripleDESCryptoServiceProvider provider = new TripleDESCryptoServiceProvider
            {
                Key = key,
                Mode = CipherMode.ECB,
                Padding = PaddingMode.PKCS7
            };
            byte[] inArray = provider.CreateEncryptor().TransformFinalBlock(bytes, 0, bytes.Length);
            provider.Clear();
            return Convert.ToBase64String(inArray, 0, inArray.Length);
        }

        private string encrypta(string plain, byte[] key)
        {
            char[] chArray = plain.ToCharArray();
            char[] chArray2 = new char[plain.Length];
            for (int i = 0; i < plain.Length; i++)
            {
                chArray2[i] = (char)(chArray[i] + key[i % key.Length]);
            }
            return new string(chArray2);
        }

        private string EncryptB(string plain, byte[] key)
        {
            int num2;
            char[] chArray = plain.ToCharArray();
            char[] chArray2 = new char[plain.Length];
            int num = 0;
            for (num2 = 0; num2 < key.Length; num2++)
            {
                num += key[num2];
            }
            for (num2 = 0; num2 < plain.Length; num2++)
            {
                num ^= plain[num2];
            }
            for (int i = 0; i < chArray.Length; i++)
            {
                byte num4 = key[num % key.Length];
                byte num5 = (byte)chArray[i];
                chArray2[i] = (char)(num5 ^ (((num4 * 3) / 2) & 0xff));
                chArray2[i] = (char)((chArray2[i] << 3) | (chArray2[i] >> 5));
                if ((chArray2[i] % '\x0002') == 0)
                {
                    chArray2[i] = (char)(chArray2[i] - '\x0001');
                }
                else
                {
                    chArray2[i] = (char)(chArray2[i] + '\x0001');
                }
                num = (num ^ num5) + key.Length;
            }
            return new string(chArray2);
        }

        private string toHex(string str)
        {
            int num;
            byte[] buffer = new byte[str.Length];
            for (num = 0; num < str.Length; num++)
            {
                buffer[num] = (byte)str[num];
            }
            StringBuilder builder = new StringBuilder();
            for (num = 0; num < str.Length; num++)
            {
                builder.Append(buffer[num].ToString("X2"));
            }
            return builder.ToString();
        }

        private static string byteToString(byte[] b)
        {
            string str = "";
            for (int i = 0; i < b.Length; i++)
            {
                str = str + ((char)b[i]);
            }
            return str;
        }

        private void AddTheKeyOfTheRound(byte[][] state, int[] expandedKey)
        {
            for (int i = 0; i < Nb; i++)
            {
                state[0][i] = (byte)(state[0][i] ^ ((byte)(expandedKey[i] & 0xff)));
                state[1][i] = (byte)(state[1][i] ^ ((byte)((expandedKey[i] >> 8) & 0xff)));
                state[2][i] = (byte)(state[2][i] ^ ((byte)((expandedKey[i] >> 0x10) & 0xff)));
                state[3][i] = (byte)(state[3][i] ^ ((byte)((expandedKey[i] >> 0x18) & 0xff)));
            }
        }

        private void BytesSubstract(byte[][] state)
        {
            byte[] bBox = BBox;
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < Nb; j++)
                {
                    state[i][j] = bBox[state[i][j]];
                }
            }
        }

        private void ShiftRows(byte[][] state)
        {
            int[] numArray = new int[0];
            int[] numArray2 = new int[] { 0, 1, 2, 3 };
            int[] numArray3 = new int[] { 0, 1, 3, 4 };
            int[][] numArray4 = new int[][] { numArray, numArray, numArray, numArray, numArray2, numArray, numArray2, numArray, numArray3 };
            for (int i = 1; i < 4; i++)
            {
                state[i] = cyclicShiftLeft(state[i], numArray4[Nb][i]);
            }
        }

        private static byte[] cyclicShiftLeft(byte[] theArray, int positions)
        {
            byte[] a = copyOfRange(theArray, 0, positions);
            byte[] buffer2 = copyOfRange(theArray, positions, theArray.Length);
            byte[] c = new byte[buffer2.Length + a.Length];
            arraycopy(buffer2, 0, c, 0, buffer2.Length);
            arraycopy(a, 0, c, buffer2.Length, a.Length);
            return c;
        }

        private static void arraycopy(byte[] a, int b, byte[] c, int d, int len)
        {
            int index = b;
            for (int i = d; (i - d) < len; i++)
            {
                c[i] = a[index];
                index++;
            }
        }
        
        private static int[] copyOfRange(int[] a, int b, int c)
        {
            int[] numArray = new int[c - b];
            for (int i = b; i < c; i++)
            {
                numArray[i - b] = a[i];
            }
            return numArray;
        }

        private static byte[] copyOfRange(byte[] a, int b, int c)
        {
            byte[] buffer = new byte[c - b];
            for (int i = b; i < c; i++)
            {
                buffer[i - b] = a[i];
            }
            return buffer;
        }

        private static byte[][] ZipTheBytes(byte[] octets)
        {
            byte[][] bufferArray = new byte[4][];
            if ((octets == null) || ((octets.Length % 4) > 0))
            {
                return null;
            }
            bufferArray[0] = new byte[4];
            bufferArray[1] = new byte[4];
            bufferArray[2] = new byte[4];
            bufferArray[3] = new byte[4];
            for (int i = 0; i < octets.Length; i += 4)
            {
                bufferArray[0][i / 4] = octets[i];
                bufferArray[1][i / 4] = octets[i + 1];
                bufferArray[2][i / 4] = octets[i + 2];
                bufferArray[3][i / 4] = octets[i + 3];
            }
            return bufferArray;
        }

        private void RumbleInTheColumn(byte[][] state)
        {
            byte[] buffer = new byte[4];
            for (int i = 0; i < Nb; i++) //Nb=4
            {
                int index = 0;
                while (index < 4)
                {
                    buffer[index] = (byte)(((MultiplySomething(state[index][i], 2) ^ MultiplySomething(state[(index + 1) % 4][i], 3)) ^ state[(index + 2) % 4][i]) ^ state[(index + 3) % 4][i]);
                    index++;
                }
                for (index = 0; index < 4; index++)
                {
                    state[index][i] = buffer[index];
                }
            }
        }

        private byte[] crunch(byte[] block_, int[] expandedKey)
        {
            if ((block_ == null) || ((block_.Length * 8) != blockSizeInBits))
            {
                return null;
            }
            if (expandedKey == null)
            {
                return null;
            }
            byte[][] state = ZipTheBytes(block_);//invertibile
            AddTheKeyOfTheRound(state, expandedKey);//invertibile - richiama che funziona
            for (int i = 1; i < Nr; i++)
            {
                BytesSubstract(state);//invertibile, cerco il valore nella box, il dato di partenza è i
                ShiftRows(state);//rol sui gruppi 1,2,3 con rol di 1,2,3 (niente su 0)
                RumbleInTheColumn(state);//da vedere
                AddTheKeyOfTheRound(state, copyOfRange(expandedKey, Nb * i, Nb * (i + 1)));//rifai che funziona, copyOfRange è un pezzo di array
            }
            BytesSubstract(state);//inv
            ShiftRows(state);//lungo
            AddTheKeyOfTheRound(state, copyOfRange(expandedKey, Nb * Nr, expandedKey.Length));//come prima
            return unZipTheBytes(state);//invertibile (già fatto)
        }

        private static byte[] unZipTheBytes(byte[][] packed)
        {
            byte[] buffer = new byte[packed[0].Length * 4];
            int index = 0;
            for (int i = 0; i < packed[0].Length; i++)
            {
                buffer[index] = packed[0][i];
                buffer[index + 1] = packed[1][i];
                buffer[index + 2] = packed[2][i];
                buffer[index + 3] = packed[3][i];
                index += 4;
            }
            return buffer;
        }

        private static int MultiplySomething(int x, int y)
        {
            int num2 = 0;
            int num = 1;
            while (num < 0x100)
            {
                if ((x & num) > 0)
                {
                    num2 ^= y;
                }
                num *= 2;
                y = xtime(y);
            }
            return num2;
        }
        
        private static int xtime(int poly)
        {
            poly = poly << 1;
            return (((poly & 0x100) > 0) ? (poly ^ 0x11b) : poly);
        }

        private static byte[] toByteArray(string str)
        {
            byte[] buffer = new byte[0x10];
            for (int i = 0; i < buffer.Length; i++)
            {
                buffer[i] = (byte)str[i % str.Length];
            }
            return buffer;
        }

        private string reverse(string str)
        {
            string str2 = "";
            for (int i = str.Length - 1; i >= 0; i--)
            {
                str2 = str2 + str[i];
            }
            return str2;
        }

        private string shift(string str, int n)
        {
            char[] chArray = str.ToCharArray();
            for (int i = 0; i < chArray.Length; i++)
            {
                chArray[i] = (char)(chArray[i] + ((char)n));
            }
            return new string(chArray);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string pass = "Aurora Borealis";

            char[] str = "Zpv!bsf!po!uif!xspoh!usbdl/".ToCharArray();
            str = this.shift(str, -1);
            byte[] key = new byte[0x18];
            for (int i = 0; i < key.Length; i++)
            {
                key[i] = (byte)str[i % str.Length];
            }
            byte[] buffer2 = this.md5("the northern lights");
            byte[] buffer3 = this.md5("Don't even try to break this encryption :)");
            byte[] buffer4 = this.sha512("This is where you should be looking... or is it?");
            byte[] buffer5 = this.sha512("ksydfius");
            byte[] b = this.sha512("Q29uZ3JhdHVsYXRpb25zIHlvdSBjYW4gZGVjb2RlIGJhc2U2NCE=");
            byte[] buffer7 = this.sha512("VG9vIGJhZCB0aGF0IHdvbid0IGhlbHAgeW91IG9uIHRoaXMgb25lIDoo");
            byte[] buffer8 = this.sha512("Stop looking at my code please...");//non è usato
            byte[] buffer9 = this.md5("WW91IGFyZSBpbiB0aGUgd3JvbmcgZGlyZWN0aW9uLi4u");
            while (b.Length > 0x18)
            {
                b = this.condense(b);
            }
            while (buffer7.Length > 0x18)
            {
                buffer7 = this.condense(buffer7);
            }
            int[] expandedKey = UnzipTheKey(buffer9);

            string correctKey = "8oWXqE0djEXY2tnILLMcoqEHIgFXAFZvw73p2Aua+u1W/wENwj4hEkOyqWVFsrgdykxPdwKYeo/jUpxMB/gQ93S+wQlAVT8ss68czW3MZVGufJW7Mn85pwxP/UXh3YZYTnfomm3LFNhdwEo1+qa1i0o+7g8yszSxBNk/oQbHnedIsrjNVrgo3gwKQTYqiOyAI7bkmqbFnP2lNTqa7/xt2OeEQltMy3m2Cbhz0MnywOsru4Z7r+/mhQXE/qaYFNRb6mvT8/ZGHXCyLYGFnDaKeBWDVu/y3pUar/OlI7OvX5Tu8Crf021EyQ5zEO/gzwJdnJde4tWQIFVC1yNjl3wlmxl/fsLAclA4iNnKdZHbwqU3S8gYZ46699aXdSNf2AhligRc/iLn/kfS13BrmCvcCv1UpIKXa6y1INTcA9xvB7htAghDQPJMphgpWXc0iad1CSjUwjBDTZxZOVvRONsvRw==";
            int numPw = 0;
            string[] diz = new string[0];

            System.IO.FileStream f = new System.IO.FileStream("dictest.txt", System.IO.FileMode.Open, System.IO.FileAccess.Read);
            System.IO.StreamReader r = new System.IO.StreamReader(f);
            while (!r.EndOfStream)
            {
                Array.Resize(ref diz, numPw + 1);
                diz[numPw] = r.ReadLine();
                numPw++;
            }
            r.Close();
            f.Close();
            //System.Threading.Tasks.Parallel.For(0, numPw, i =>
            //{
            //    pass = diz[i];
            //    string ret = (l337Encrypt(l337Encrypt(shift(encrypt(encrypt(Encrypt(toHex(Encrypt(reverse(l337Encrypt(toHex(byteToString(crunch(toByteArray(pass), expandedKey))), key)), buffer2)), buffer3), buffer4), buffer5), 3), b), buffer7));
            //    if (ret == correctKey)
            //        MessageBox.Show(i.ToString());
            //});

            MessageBox.Show("pausa");

            System.Threading.Tasks.Parallel.For(0, numPw, i =>
            {
                for (int j = 0; j < numPw; j++)
                {
                    for (int k = 0; k < numPw; k++)
                    {
                        pass = diz[i] + diz[j] + diz[k];
                        string ret = (l337Encrypt(l337Encrypt(shift(encrypta(encrypta(EncryptB(toHex(EncryptB(reverse(l337Encrypt(toHex(byteToString(crunch(toByteArray(pass), expandedKey))), key)), buffer2)), buffer3), buffer4), buffer5), 3), b), buffer7));
                        if (ret == correctKey)
                            MessageBox.Show(i.ToString());
                    }
                }
            });



            System.Threading.Tasks.Parallel.For(0, numPw, i =>
            {
                for (int j = 0; j < numPw; j++)
                {
                    for (int k = 0; k < numPw; k++)
                    {
                        pass = diz[i] + " " + diz[j] + " " + diz[k];
                        string ret = (l337Encrypt(l337Encrypt(shift(encrypta(encrypta(EncryptB(toHex(EncryptB(reverse(l337Encrypt(toHex(byteToString(crunch(toByteArray(pass), expandedKey))), key)), buffer2)), buffer3), buffer4), buffer5), 3), b), buffer7));
                        if (ret == correctKey)
                            MessageBox.Show(i.ToString());
                    }
                }
            });

            System.Threading.Tasks.Parallel.For(0, numPw, i =>
            {
                for (int j = 0; j < numPw; j++)
                {
                    for (int k = 0; k < numPw; k++)
                    {
                        pass = diz[i] + "_" + diz[j] + "_" + diz[k];
                        string ret = (l337Encrypt(l337Encrypt(shift(encrypta(encrypta(EncryptB(toHex(EncryptB(reverse(l337Encrypt(toHex(byteToString(crunch(toByteArray(pass), expandedKey))), key)), buffer2)), buffer3), buffer4), buffer5), 3), b), buffer7));
                        if (ret == correctKey)
                            MessageBox.Show(i.ToString());
                    }
                }
            });
            MessageBox.Show("fail");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MakeTable();//IMPORTANTISSIMO
            string pass = "Aurora Borealis";

            char[] str = "Zpv!bsf!po!uif!xspoh!usbdl/".ToCharArray();
            str = this.shift(str, -1);
            byte[] key = new byte[0x18];
            for (int i = 0; i < key.Length; i++)
            {
                key[i] = (byte)str[i % str.Length];
            }
            byte[] buffer2 = this.md5("the northern lights");
            byte[] buffer3 = this.md5("Don't even try to break this encryption :)");
            byte[] buffer4 = this.sha512("This is where you should be looking... or is it?");
            byte[] buffer5 = this.sha512("ksydfius");
            byte[] b = this.sha512("Q29uZ3JhdHVsYXRpb25zIHlvdSBjYW4gZGVjb2RlIGJhc2U2NCE=");
            byte[] buffer7 = this.sha512("VG9vIGJhZCB0aGF0IHdvbid0IGhlbHAgeW91IG9uIHRoaXMgb25lIDoo");
            byte[] buffer8 = this.sha512("Stop looking at my code please...");//non è usato
            byte[] buffer9 = this.md5("WW91IGFyZSBpbiB0aGUgd3JvbmcgZGlyZWN0aW9uLi4u");
            while (b.Length > 0x18)
            {
                b = this.condense(b);
            }
            while (buffer7.Length > 0x18)
            {
                buffer7 = this.condense(buffer7);
            }
            int[] expandedKey = UnzipTheKey(buffer9);

            string correctKey = "8oWXqE0djEXY2tnILLMcoqEHIgFXAFZvw73p2Aua+u1W/wENwj4hEkOyqWVFsrgdykxPdwKYeo/jUpxMB/gQ93S+wQlAVT8ss68czW3MZVGufJW7Mn85pwxP/UXh3YZYTnfomm3LFNhdwEo1+qa1i0o+7g8yszSxBNk/oQbHnedIsrjNVrgo3gwKQTYqiOyAI7bkmqbFnP2lNTqa7/xt2OeEQltMy3m2Cbhz0MnywOsru4Z7r+/mhQXE/qaYFNRb6mvT8/ZGHXCyLYGFnDaKeBWDVu/y3pUar/OlI7OvX5Tu8Crf021EyQ5zEO/gzwJdnJde4tWQIFVC1yNjl3wlmxl/fsLAclA4iNnKdZHbwqU3S8gYZ46699aXdSNf2AhligRc/iLn/kfS13BrmCvcCv1UpIKXa6y1INTcA9xvB7htAghDQPJMphgpWXc0iad1CSjUwjBDTZxZOVvRONsvRw==";


            byte[] inBytes = toByteArray(pass);
            byte[] crunched = crunch(inBytes, expandedKey);
            string crunchedToStr = byteToString(crunched);
            string theHexStr = toHex(crunchedToStr);
            string encrypted1 = l337Encrypt(theHexStr, key);
            string reversed = reverse(encrypted1);
            string encrypted2 = EncryptB(reversed, buffer2);
            string toHex2 = toHex(encrypted2);
            string encrypted3 = EncryptB(toHex2, buffer3);
            string encrypted4 = encrypta(encrypted3, buffer4);
            string encrypted5 = encrypta(encrypted4, buffer5);
            string shifted = shift(encrypted5, 3);
            string encrypted6 = l337Encrypt(shifted, b);
            string FINAL = l337Encrypt(encrypted6, buffer7);

            //---------

            //string encrypted6b = DesDecrypt(FINAL, buffer7);      //decrypt my password to check if every step works
            string encrypted6b = DesDecrypt(correctKey, buffer7);   //decript his password to solve the crackme
            //if (encrypted6 != encrypted6b)
            //    MessageBox.Show("DOH");
            string shiftedb = DesDecrypt(encrypted6b, b);
            //if (shifted != shiftedb)
            //    MessageBox.Show("DOH");
            string encrypted5b = UnShift(shiftedb, 3);
            //if (encrypted5 != encrypted5b)
            //    MessageBox.Show("DOH");
            string encrypted4b = DecryptA(encrypted5b, buffer5);
            //if (encrypted4 != encrypted4b)
            //    MessageBox.Show("DOH");
            string encrypted3b = DecryptA(encrypted4b, buffer4);
            //if (encrypted3 != encrypted3b)
            //    MessageBox.Show("DOH");
            string toHex2b = DecryptB2(encrypted3b, buffer3);
            //if (toHex2 != toHex2b)
            //    MessageBox.Show("DOH");
            byte[] encrypted2b = UnHex(toHex2b);
            //for (int i = 0; i < encrypted2b.Length; i++)
            //{
            //    if (encrypted2b[i] != (byte)encrypted2[i])
            //        MessageBox.Show("DOH");
            //}
            string reversedb = DecryptB1(encrypted2b, buffer2);     //little trick inside here to skip a wrong value
            //if (reversed != reversedb)
            //    MessageBox.Show("DOH");
            string encrypted1b = UnReverse(reversedb);
            //if (encrypted1 != encrypted1b)
            //    MessageBox.Show("DOH");
            string theHexStrb = DesDecrypt(encrypted1b, key);
            //if (theHexStr != theHexStrb)
            //    MessageBox.Show("DOH");
            byte[] crunchedToStrb = UnHex(theHexStrb);//ok
            byte[] crunchedb = crunchedToStrb;//StringToBytes(crunchedToStrb);
            //for (int i = 0; i < crunched.Length; i++)
            //{
            //    if (crunchedb[i] != crunched[i])
            //        MessageBox.Show("DOH");
            //}
            byte[] inBytesb = UnCrunch(crunchedb, expandedKey);
            string passb = ByteArrayToStr(inBytesb);
            Clipboard.SetText(passb);
            MessageBox.Show(passb);
        }

        private string DesDecrypt(string enc, byte[] key)
        {
            byte[] bytes = Convert.FromBase64String(enc);
            TripleDESCryptoServiceProvider provider = new TripleDESCryptoServiceProvider
            {
                Key = key,
                Mode = CipherMode.ECB,
                Padding = PaddingMode.PKCS7
            };
            byte[] inArray = provider.CreateDecryptor().TransformFinalBlock(bytes, 0, bytes.Length);
            provider.Clear();
            string ret="";
            ret=Encoding.UTF8.GetString(inArray);
            return ret;
        }
        private string UnShift(string str, int n)
        {
            char[] chArray = str.ToCharArray();
            for (int i = 0; i < chArray.Length; i++)
            {
                chArray[i] = (char)(chArray[i] - ((char)n));
            }
            return new string(chArray);
        }
        private string DecryptA(string enc, byte[] key)
        {
            char[] chArray = enc.ToCharArray();
            char[] chArray2 = new char[enc.Length];
            for (int i = 0; i < enc.Length; i++)
            {
                chArray2[i] = (char)(chArray[i] - key[i % key.Length]);
            }
            return new string(chArray2);
        }
        private string DecryptB1(byte[] enc, byte[] key)//base64 num
        {
            byte[] encoded = new byte[enc.Length];
            Array.Copy(enc, encoded, enc.Length);
            //int num2;
            char[] chArray = new char[enc.Length];
            char[] chArray2 = new char[enc.Length];
            int num = 2048;//min  //2171=giusto; // 2303 = max
            int buNum = num;
            int numOk = num;
            //for (num2 = 0; num2 < key.Length; num2++)
            //{
            //    num += key[num2];
            //}
            //for (num2 = 0; num2 < plain.Length; num2++)
            //{
            //    num ^= plain[num2];
            //}
            for (numOk = 2048; numOk <= 2303; numOk++)
            {
                //IMPORTANT!!!!   IMPORTANT!!!!   IMPORTANT!!!!   IMPORTANT!!!!   IMPORTANT!!!!
                numOk = 2061;//with the correct password it return wrong value (base64 can't end with "=r"), if we skip it (numOk++) it will stop here, so we do this little trick to skip the wrong value
                //IMPORTANT!!!!   IMPORTANT!!!!   IMPORTANT!!!!   IMPORTANT!!!!   IMPORTANT!!!!
                num = numOk;
                buNum = numOk;
                for (int i = 0; i < enc.Length; i++)
                {
                    byte num4 = key[num % key.Length];
                    byte num5 = (byte)chArray[i];
                    chArray2[i] = (char)(num5 ^ (((num4 * 3) / 2) & 0xff));
                    chArray2[i] = (char)((chArray2[i] << 3) | (chArray2[i] >> 5));
                    if ((chArray2[i] % '\x0002') == 0)
                    {
                        chArray2[i] = (char)(chArray2[i] - '\x0001');
                    }
                    else
                    {
                        chArray2[i] = (char)(chArray2[i] + '\x0001');
                    }
                    num = (num ^ num5) + key.Length;
                    if ((byte)chArray2[i] != encoded[i])
                    {
                        if (chArray[i] != 255)
                            chArray[i]++;
                        else
                        {
                            //chArray[i] = (char)0;
                            Array.Clear(chArray, 0, chArray.Length);
                            i = 1;//in realtà 0 (rifai tutto)
                            buNum++;
                            numOk = buNum;
                        }
                        num = buNum;
                        i--;//do again
                    }
                    buNum = num;
                }
                //controllo
                bool solutionFound;
                int maxI = 0;
                for (int i = 0; i < chArray.Length; i++)
                {
                    solutionFound = false;
                    if (chArray[i] >= 'A' && chArray[i] <= 'Z')
                        solutionFound = true;
                    if (chArray[i] >= 'a' && chArray[i] <= 'z')
                        solutionFound = true;
                    if (chArray[i] >= '0' && chArray[i] <= '9')
                        solutionFound = true;
                    if (chArray[i] == '+' || chArray[i] == '/' || chArray[i] == '=')
                        solutionFound = true;
                    if (solutionFound == false)
                    {
                        Array.Clear(chArray, 0, chArray.Length);
                        break;
                    }
                    maxI = i;
                }
                if (maxI == chArray.Length - 1)
                    break;//sono arrivato in fondo all'array ed è tutto alphanum (hex)
            }
            return new string(chArray);
        }
        private string DecryptB2(string enc, byte[] key)//hex nums
        {
            char[] encoded = enc.ToCharArray();
            //int num2;
            char[] chArray =  new char[enc.Length];
            char[] chArray2 = new char[enc.Length];
            int num = 2304;//min  //2385=giusto; // 2559 = max
            int buNum = num;
            int numOk = num;
            //for (num2 = 0; num2 < key.Length; num2++)
            //{
            //    num += key[num2];
            //}
            //for (num2 = 0; num2 < plain.Length; num2++)
            //{
            //    num ^= plain[num2];
            //}
            for (numOk = 2304; numOk <= 2559; numOk++)
            {
                num = numOk;
                buNum = numOk;
                for (int i = 0; i < enc.Length; i++)
                {
                    byte num4 = key[num % key.Length];
                    byte num5 = (byte)chArray[i];
                    chArray2[i] = (char)(num5 ^ (((num4 * 3) / 2) & 0xff));
                    chArray2[i] = (char)((chArray2[i] << 3) | (chArray2[i] >> 5));
                    if ((chArray2[i] % '\x0002') == 0)
                    {
                        chArray2[i] = (char)(chArray2[i] - '\x0001');
                    }
                    else
                    {
                        chArray2[i] = (char)(chArray2[i] + '\x0001');
                    }
                    num = (num ^ num5) + key.Length;
                    if (chArray2[i] != encoded[i])
                    {
                        if (chArray[i]!=255)
                            chArray[i]++;
                        else
                        {
                            //chArray[i] = (char)0;
                            Array.Clear(chArray, 0, chArray.Length);
                            i = 1;//in realtà 0 (rifai tutto)
                            buNum++;
                            numOk = buNum;
                        }
                        num = buNum;
                        i--;//do again
                    }
                    buNum = num;
                }
                //controllo
                bool solutionFound;
                int maxI = 0;
                for (int i = 0; i < chArray.Length; i++)
                {
                    solutionFound = false;
                    if (chArray[i] >= 'A' && chArray[i] <= 'F')
                        solutionFound = true;
                    if (chArray[i] >= '0' && chArray[i] <= '9')
                        solutionFound = true;
                    if (solutionFound == false)
                    {
                        Array.Clear(chArray, 0, chArray.Length);
                        break;
                    }
                    maxI = i;
                }
                if (maxI == chArray.Length - 1)
                    break;//sono arrivato in fondo all'array ed è tutto alphanum (hex)
            }
            return new string(chArray);
        }
        private byte[] UnHex(string str)//da vedere...
        {
            byte[] unHexed= Enumerable.Range(0, str.Length)
                .Where(x => x % 2 == 0)
                .Select(x => Convert.ToByte(str.Substring(x, 2), 16))
                .ToArray();
            return unHexed;
        }
        private string UnReverse(string str)
        {
            string str2 = "";
            for (int i = str.Length - 1; i >= 0; i--)
            {
                str2 = str2 + str[i];
            }
            return str2;
        }
        private byte[] StringToBytes(string enc)
        {
            return Encoding.Default.GetBytes(enc);
        }
        private string ByteArrayToStr(byte[] arr)
        {
            return Encoding.Default.GetString(arr);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            MakeTable();
            byte[] crunchedCorrect = { 125, 187, 26, 221, 19, 246, 82, 151, 83, 125, 30, 143, 204, 57, 80, 240 };

            string pass = "Aurora Borealis";

            char[] str = "Zpv!bsf!po!uif!xspoh!usbdl/".ToCharArray();
            str = this.shift(str, -1);
            byte[] key = new byte[0x18];
            for (int i = 0; i < key.Length; i++)
            {
                key[i] = (byte)str[i % str.Length];
            }
            byte[] buffer2 = this.md5("the northern lights");
            byte[] buffer3 = this.md5("Don't even try to break this encryption :)");
            byte[] buffer4 = this.sha512("This is where you should be looking... or is it?");
            byte[] buffer5 = this.sha512("ksydfius");
            byte[] b = this.sha512("Q29uZ3JhdHVsYXRpb25zIHlvdSBjYW4gZGVjb2RlIGJhc2U2NCE=");
            byte[] buffer7 = this.sha512("VG9vIGJhZCB0aGF0IHdvbid0IGhlbHAgeW91IG9uIHRoaXMgb25lIDoo");
            byte[] buffer8 = this.sha512("Stop looking at my code please...");//non è usato
            byte[] buffer9 = this.md5("WW91IGFyZSBpbiB0aGUgd3JvbmcgZGlyZWN0aW9uLi4u");
            while (b.Length > 0x18)
            {
                b = this.condense(b);
            }
            while (buffer7.Length > 0x18)
            {
                buffer7 = this.condense(buffer7);
            }
            int[] expandedKey = UnzipTheKey(buffer9);

            string correctKey = "8oWXqE0djEXY2tnILLMcoqEHIgFXAFZvw73p2Aua+u1W/wENwj4hEkOyqWVFsrgdykxPdwKYeo/jUpxMB/gQ93S+wQlAVT8ss68czW3MZVGufJW7Mn85pwxP/UXh3YZYTnfomm3LFNhdwEo1+qa1i0o+7g8yszSxBNk/oQbHnedIsrjNVrgo3gwKQTYqiOyAI7bkmqbFnP2lNTqa7/xt2OeEQltMy3m2Cbhz0MnywOsru4Z7r+/mhQXE/qaYFNRb6mvT8/ZGHXCyLYGFnDaKeBWDVu/y3pUar/OlI7OvX5Tu8Crf021EyQ5zEO/gzwJdnJde4tWQIFVC1yNjl3wlmxl/fsLAclA4iNnKdZHbwqU3S8gYZ46699aXdSNf2AhligRc/iLn/kfS13BrmCvcCv1UpIKXa6y1INTcA9xvB7htAghDQPJMphgpWXc0iad1CSjUwjBDTZxZOVvRONsvRw==";


            byte[] inBytes = toByteArray(pass);
            byte[] crunched = crunch(inBytes, expandedKey);

            byte[] inBytesb = UnCrunch(crunched, expandedKey);
            for (int i = 0; i < inBytes.Length; i++)
            {
                if (inBytesb[i] != inBytes[i])
                    MessageBox.Show("DOH");
            }
            string passb = ByteArrayToStr(inBytesb);
            Clipboard.SetText(passb);
            MessageBox.Show(passb);

        }

        private byte[] UnCrunch(byte[] crunched, int[] expandedKey)//DOH
        {
            byte[][] state = ZipTheBytes(crunched);
            AddTheKeyOfTheRound(state, copyOfRange(expandedKey, Nb * Nr, expandedKey.Length));
            UndoShiftRows(state);
            UndoBytesSubstract(state);
            for (int i = 1; i < Nr; i++)
            {
                AddTheKeyOfTheRound(state, copyOfRange(expandedKey, Nb * (Nr-i), Nb * ((Nr-i) + 1)));
                state=UndoRumbleInTheColumn(state);//??? da testare se funziona saltando questo step (con pw nota)
                UndoShiftRows(state);
                UndoBytesSubstract(state);               
            }
            AddTheKeyOfTheRound(state, expandedKey);
            byte[] unzipped=unZipTheBytes(state);
            return unzipped;
        }
        private void UndoBytesSubstract(byte[][] state)
        {
            byte[] bBox = BBox;
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < Nb; j++)
                {
                    for (int k = 0; k < bBox.Length; k++)
                    {
                        if (bBox[k] == state[i][j])
                        {
                            state[i][j] = (byte)k;
                            break;
                        }
                    }
                }
            }
        }
        private void UndoShiftRows(byte[][] state)
        {
            int[] numArray = new int[0];
            int[] numArray2 = new int[] { 0, 1, 2, 3 };
            int[] numArray3 = new int[] { 0, 1, 3, 4 };
            int[][] numArray4 = new int[][] { numArray, numArray, numArray, numArray, numArray2, numArray, numArray2, numArray, numArray3 };
            for (int i = 1; i < 4; i++)
            {
                state[i] = cyclicShiftRight(state[i], numArray4[Nb][i]);
            }
        }
        private static byte[] cyclicShiftRight(byte[] theArray, int positions)//da fixare, è ancora left
        {
            byte[] part1 = copyOfRange(theArray, 0, theArray.Length-positions);
            byte[] other = copyOfRange(theArray, theArray.Length - positions, theArray.Length);
            byte[] c = new byte[other.Length + part1.Length];
            arraycopy(other, 0, c, 0, other.Length);
            arraycopy(part1, 0, c, other.Length, part1.Length);
            return c;
        }

        private byte[][] UndoRumbleInTheColumn(byte[][] state)
        {
            for (int i = 0; i < 4; i++)
			{
                byte[] s = new byte[] { state[0][i], state[1][i], state[2][i], state[3][i] };
                byte[] s2=UndoRumbleInTheColumnPart(s);
                state[0][i] = s2[0];
                state[1][i] = s2[1];
                state[2][i] = s2[2];
                state[3][i] = s2[3];
            }
            return state;
        }
        private static int UndoMultiplySomething(int enc, int y)
        {
            int num2 = 0;
            int num = 1;
            int yCopy = y;
            for (int i = 0; i <= 255; i++)
            {
                y = yCopy;
                num = 1;
                num2 = 0;
                while (num < 0x100)
                {
                    if ((i & num) > 0)//x decide se xora o no   129 correctto!
                    {
                        num2 ^= y; //y decide il num finale
                    }
                    num *= 2;
                    y = xtime(y);//so che y è 2 scelgo x successivi!!!
                }
                if (num2 == enc)
                    return i;
            }
            return 0;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            MakeTable();
            byte[][] state =new byte[4][];
            state[0] = new byte[] { 75, 251, 120, 186 };
            state[1] = new byte[] { 161, 148, 23, 212 };
            state[2] = new byte[] { 14, 1, 113, 172 };
            state[3] = new byte[] { 89, 144, 68, 242 };
            RumbleInTheColumn(state);
            state=UndoRumbleInTheColumn(state);
            

            int ret1 = MultiplySomething(129, 2);
            int ret2 = MultiplySomething(144, 3);
            int u1, u2;
            u1 = UndoMultiplySomething(ret1, 2);
            u2 = UndoMultiplySomething(ret2, 3);
        }

        private void RumbleInTheColumnTest(byte[] state)
        {
            byte[] buffer = new byte[4];

            int index = 0;
            while (index < 4)
            {
                buffer[index] = (byte)(((MultiplySomething(state[index], 2) ^ MultiplySomething(state[(index + 1) % 4], 3)) ^ state[(index + 2) % 4]) ^ state[(index + 3) % 4]);
                index++;
            }
            for (index = 0; index < 4; index++)
            {
                state[index] = buffer[index];
            } 
        }

        static private byte[] UndoRumbleInTheColumnPart(byte[] state)
        {
            byte ok1 = state[0];
            byte ok2 = state[1];
            byte ok3 = state[2];
            byte ok4 = state[3];
            byte[] done = new byte[4];    
            System.Threading.Tasks.Parallel.For(0, 255, (i,loopState) =>
            {        
            //for (int i = 0; i <= 255; i++)
            //{
                for (int j = 0; j <= 255; j++)
                {
                    for (int k = 0; k <= 255; k++)
                    {
                        for (int l = 0; l <= 255; l++)
                        {
                            byte ret=(byte)(mulTable2[i] ^ mulTable3[j] ^ k ^ l);
                            if (ok1 == ret)
                            {
                                byte ret2 = (byte)(mulTable2[j] ^ mulTable3[k] ^ l ^ i);
                                if (ok2 == ret2)
                                {
                                    byte ret3 = (byte)(mulTable2[k] ^ mulTable3[l] ^ i ^ j);
                                    if (ok3 == ret3)
                                    {
                                        byte ret4 = (byte)(mulTable2[l] ^ mulTable3[i] ^ j ^ k);
                                        if (ok4 == ret4)
                                        {
                                            done[0]=(byte)i;
                                            done[1]=(byte)j;
                                            done[2]=(byte)k;
                                            done[3] = (byte)l;
                                            //return done;
                                            loopState.Stop();
                                            i = j = k = l = 256;
                                        }
                                    }
                                }
                            }
                        }   
                    }   
                }   
            //}     
            });
            return done;
        }

        private static byte[] mulTable2 = new byte[256];
        private byte[] undoMulTable2 = new byte[256];
        private static byte[] mulTable3 = new byte[256];
        private byte[] undoMulTable3 = new byte[256];
        private void MakeTable()
        {
            for (int i = 0; i <= 255; i++)
            {
                mulTable2[i] = (byte)MultiplySomething((byte)i, 2);

                if (undoMulTable2[mulTable2[i]] == 0)
                    undoMulTable2[mulTable2[i]] = (byte)i;
                else
                    MessageBox.Show("DOH");

                mulTable3[i] = (byte)MultiplySomething((byte)i, 3);
                if (undoMulTable3[mulTable3[i]] == 0)
                    undoMulTable3[mulTable3[i]] = (byte)i;
                else
                    MessageBox.Show("DOH");
            }
        }

    }
}