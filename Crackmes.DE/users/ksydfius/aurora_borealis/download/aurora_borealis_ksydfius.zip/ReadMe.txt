===================
= Aurora Borealis =
=   by ksydfius   =
===================

Hi reversers,

Welcome to a .NET crackme which hopefully should be quite a test for you.
It is, in my opinion, much harder than the other crackmes I have created.

I have put alot of effort into creating this challenge, as alot of others
on crackmes.de have put into theirs. Please, if you get past one part, don't
post what you did on the page and ruin it for others. Instead, send me a PM :)

However, if you do manage to solve this one, please write a solution so we can
all see how you managed to do it.

Good luck

-ksydfius

=======
= FAQ =
=======

Q: What is my goal?
A: Your goal is to unpack the EXE (remove .NET Protector) and find its password.

Q: WTF is .NET Protector?
A: .NET Protector is a stupid program ( made by me of course :D ) that protects
   a .NET executable using a password and crypto routines.

Q: Are the algorithms reversible?
A: Some are, and some aren't.

Q: Can I BF the passwords?
A: Yeah, just go ahead and try it ... :P

Q: Do I have to write any code?
A: Yes

Q: First part is so hard... any hints?
A: No hints, 1st part is very straightforward. If you think thats hard, then you dont
   want to see the 2nd part... I dont even want to talk about part 3 :)

Q: Part 3 is a nightmare! Any hints?
A. Just relax and think about it, and don't get too perplexed :)


