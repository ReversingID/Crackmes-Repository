﻿


Imports System.IO
Imports Microsoft.Win32
Public Class Form1
    Dim Al As Integer = Nothing
    Dim Dl As Integer = Nothing
    Dim Bl As Integer = Nothing
    Dim eax As Integer = Nothing
    Dim ebx As Integer = Nothing
    Dim ecx As Integer = Nothing
    Dim edx As Integer = Nothing
    Dim i As Integer
    Dim j As Integer
    Dim k As Integer
    Dim x As Integer = 8
    Dim y As Integer
    Dim storage1, storage2, storage3 As String
    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If My.Computer.FileSystem.DirectoryExists("C:\Windows\Temp\") Then
            'If The Folder Exists Do Nothing.
        Else
            ' If It Does Not Exists, Create It.
            MkDir("C:\Windows\Temp\")
        End If
        'file1
        Dim ms As New IO.MemoryStream(My.Resources.Algorithm1)
        Dim fs As IO.FileStream = IO.File.OpenWrite("C:\Windows\Temp\Algorithm1.dat")
        ms.WriteTo(fs)
        fs.Close()

        Dim Algorithm1 As System.IO.StreamReader
        Algorithm1 = File.OpenText("C:\Windows\Temp\Algorithm1.dat")
        Do Until Algorithm1.EndOfStream
            storage1 = storage1 & Algorithm1.ReadLine
        Loop
        Algorithm1.Close()
        'file2
        Dim ms3 As New IO.MemoryStream(My.Resources.Algorithm3)
        Dim fs3 As IO.FileStream = IO.File.OpenWrite("C:\Windows\Temp\Algorithm3.dat")
        ms3.WriteTo(fs3)
        fs3.Close()

        Dim Algorithm3 As System.IO.StreamReader
        Algorithm3 = File.OpenText("C:\Windows\Temp\Algorithm3.dat")
        Do Until Algorithm3.EndOfStream
            TextBox2.Text = TextBox2.Text & Algorithm3.ReadLine
        Loop
        Algorithm3.Close()
        'file3
        Dim ms4 As New IO.MemoryStream(My.Resources.Ksydfius_Xor_Algoritm_Byte_II)
        Dim fs4 As IO.FileStream = IO.File.OpenWrite("C:\Windows\Temp\Ksydfius_Xor_Algoritm_Byte_II.dat")
        ms4.WriteTo(fs4)
        fs4.Close()

        Dim Ksydfius_Xor_Algoritm_Byte_II As System.IO.StreamReader
        Ksydfius_Xor_Algoritm_Byte_II = File.OpenText("C:\Windows\Temp\Ksydfius_Xor_Algoritm_Byte_II.dat")
        Do Until Ksydfius_Xor_Algoritm_Byte_II.EndOfStream
            storage3 = storage3 & Ksydfius_Xor_Algoritm_Byte_II.ReadLine
        Loop
        Ksydfius_Xor_Algoritm_Byte_II.Close()

        'file4()
        Dim ms5 As New IO.MemoryStream(My.Resources.Ksydfius_Xor_Algorithm_II_Solution)
        Dim fs5 As IO.FileStream = IO.File.OpenWrite("C:\Windows\Temp\Ksydfius_Xor_Algorithm_II_Solution.rtf")
        ms5.WriteTo(fs5)
        fs5.Close()


        

    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click


        Timer1.Start()


        'Call ByteLength()
        Call Start()
    End Sub
    Public Sub ByteLength()
        'Dim str As String = TextBox4.Text
        'Dim StrLength As Integer = str.Length
        'Dim xChar As Char = Nothing
        'Dim iChar As Integer = Nothing
        'Dim sChar As Integer = Nothing
        'Dim StrHex As String = Nothing

        'For m = 0 To StrLength - 1
        '    xChar = str.Chars(m)
        '    iChar = Asc(xChar)
        '    sChar = sChar + iChar
        '    If sChar >= 255 Then
        '        sChar = sChar - 256
        '    End If
        'Next
        'StrHex = Hex(sChar)
        'MsgBox(StrHex)
        'x = sChar
        'Call Start()
    End Sub

    Public Sub Start()
        Dim strValue As String = Nothing
        Dim StrByte As String = Nothing
        StrByte = storage3
        If j = 480 Then
            Exit Sub
        End If
        strValue = (StrByte.Substring(i, 2)).ToString
        StrByte = StrByte.Substring(2, (StrByte.Length - 2))
        'TextBox3.Text = strValue
        eax = Convert.ToInt64(strValue, &H10)
        Dl = x
        Al = eax
        eax = eax - Dl

        Call xXor()
    End Sub
    Public Sub xXor()
        Dim strValue As String = Nothing
        Dim StrByte As String = Nothing
        StrByte = storage1
        'Do While (StrByte.Length > 0)
        strValue = (StrByte.Substring(j, 2)).ToString
        StrByte = StrByte.Substring(2, (StrByte.Length - 2))

        ecx = Convert.ToInt64(strValue, &H10)
        ecx = ecx Xor eax
        TextBox1.Text = Hex(ecx)
        Call tBox4()
        'Loop
    End Sub


    Public Sub tBox4()
        Dim Checx As String = Nothing
        Dim Charecx As String = Nothing
        Checx = Chr(ecx)
        Charecx = Chr(Dl + eax)
        TextBox2.Text = TextBox2.Text.Remove(k, 1)
        TextBox2.Text = TextBox2.Text.Insert(k, Charecx)
        TextBox4.Text = TextBox4.Text.Remove(Dl, 1)
        TextBox4.Text = TextBox4.Text.Insert(Dl, Checx)
        i = i + 2
        j = j + 2
        k = k + 1

        Call Addition()
    End Sub
    Public Sub Addition()
        ebx = Al + Dl
        Bl = ebx Mod 32
        x = Bl
        TextBox3.Text = Hex(Bl)
        Call Check()

    End Sub

    Public Sub Check()
        Dim i As Integer = Nothing
        Dim str As String = "?"
        i = InStr(TextBox4.Text, str)
        If i <= 0 And j = 480 Then
            'Button3.Enabled = True
            'Button3.BackColor = Color.Green
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Dim FileToDelete As String = Nothing
        Dim FileToDelete2 As String = Nothing
        Dim FileToDelete3 As String = Nothing
        Dim FileToDelete4 As String = Nothing
        Dim FileToDelete5 As String = Nothing
        Dim FileToDelete6 As String = Nothing
        FileToDelete = "C:\Windows\Temp\Algoritm1.dat"
        FileToDelete3 = "C:\Windows\Temp\Algoritm3.dat"
        FileToDelete4 = "C:\Windows\Temp\Ksydfius_Xor_Algorithm_II_Solution.rtf"
        FileToDelete6 = "C:\Windows\Temp\Ksydfius_Xor_Algoritm_Byte_II.dat"

        If System.IO.File.Exists(FileToDelete) = True Then
            System.IO.File.Delete(FileToDelete)
        End If
        If System.IO.File.Exists(FileToDelete3) = True Then
            System.IO.File.Delete(FileToDelete3)
        End If

        If System.IO.File.Exists(FileToDelete4) = True Then
            System.IO.File.Delete(FileToDelete4)
        End If
        If System.IO.File.Exists(FileToDelete6) = True Then
            System.IO.File.Delete(FileToDelete6)
        End If


        End
    End Sub

    Private Sub Timer1_Tick(sender As System.Object, e As System.EventArgs) Handles Timer1.Tick
        Button1.PerformClick()
    End Sub

    Private Sub Label4_MouseHover(sender As System.Object, e As System.EventArgs) Handles Label4.MouseHover
        Label4.BackColor = Color.Blue
    End Sub

    Private Sub Label4_MouseLeave(sender As System.Object, e As System.EventArgs) Handles Label4.MouseLeave
        Label4.BackColor = Color.Empty
    End Sub

    Private Sub Label4_Click(sender As System.Object, e As System.EventArgs) Handles Label4.Click
        Call tfocus()
        TextBox4.Copy()
    End Sub
    Public Sub tfocus()
        Dim KeyCode As String = TextBox4.Text
        TextBox4.Clear()
        TextBox4.Text = KeyCode
        TextBox4.Focus()
    End Sub

   Private Sub Label5_MouseHover(sender As System.Object, e As System.EventArgs) Handles Label5.MouseHover
        Label5.BackColor = Color.DarkRed
    End Sub

    Private Sub Label5_MouseLeave(sender As Object, e As System.EventArgs) Handles Label5.MouseLeave
        Label5.BackColor = Color.Empty
    End Sub

    Private Sub Label5_Click(sender As System.Object, e As System.EventArgs) Handles Label5.Click
        Dim Solution As String = Nothing
        Dim openFileDialog As OpenFileDialog = New OpenFileDialog
        OpenFileDialog1.InitialDirectory = "C:\Windows\Temp\Ksydfius_Xor_Algorithm_II_Solution.rtf"

        Solution = OpenFileDialog1.InitialDirectory

        Process.Start(Solution)
    End Sub
End Class
