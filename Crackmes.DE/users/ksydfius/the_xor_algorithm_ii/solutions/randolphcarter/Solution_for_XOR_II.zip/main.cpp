#include <cstdlib>
#include <iostream>
using namespace std;


// function declarations
int main(int argc, char *argv[]);
void encrypt(const char* szKey, char* szCodePhrase);
unsigned char sum(const char* szKey);
bool getKey(char* szKey, const char* szCodePhrase, const char* szEncrypted);
bool getKey_sum(char* szKey, unsigned uKeyLen, unsigned char cSum, char* szCodePhrase, const char* szEncrypted);

// --- start of program --- 
int main(int argc, char *argv[])
{
	// definition of variables / data
	char szCodePhrase[] = "We go about our daily lives understanding almost nothing of the world. Few of us spend much time wondering why nature is the way it is; where the cosmos came from;... why we remember the past and not the future; and why there is a universe.";
	char szCodePhrase2[] = "We go about our daily lives understanding almost nothing of the world. Few of us spend much time wondering why nature is the way it is; where the cosmos came from;... why we remember the past and not the future; and why there is a universe.";
	char szKey[] = "0123456789abcdef0123456789abcdef";
	char szEncrypted[] = {
		0x087, 0x02B, 0x073, 0x05A, 0x030, 0x020, 0x05F, 0x05F, 0x027, 0x039, 0x01E, 0x073, 0x02E, 0x064, 0x05D, 0x072,
		0x029, 0x068, 0x076, 0x067, 0x019, 0x023, 0x042, 0x03C, 0x01E, 0x05C, 0x03D, 0x06D, 0x048, 0x078, 0x037, 0x037,
		0x05B, 0x037, 0x047, 0x032, 0x052, 0x03A, 0x076, 0x069, 0x065, 0x064, 0x020, 0x02D, 0x054, 0x048, 0x03D, 0x039,
		0x060, 0x02E, 0x052, 0x034, 0x03B, 0x06A, 0x071, 0x029, 0x08D, 0x02D, 0x05A, 0x06D, 0x047, 0x02B, 0x041, 0x06D,
		0x04A, 0x038, 0x024, 0x06D, 0x029, 0x066, 0x072, 0x007, 0x05E, 0x06B, 0x020, 0x05D, 0x057, 0x024, 0x01B, 0x045,
		0x068, 0x071, 0x060, 0x055, 0x037, 0x055, 0x070, 0x06E, 0x03A, 0x04C, 0x04F, 0x064, 0x035, 0x029, 0x033, 0x049,
		0x073, 0x06A, 0x05D, 0x05F, 0x037, 0x037, 0x05B, 0x01D, 0x06F, 0x057, 0x060, 0x035, 0x061, 0x019, 0x023, 0x044,
		0x031, 0x039, 0x033, 0x03B, 0x05C, 0x070, 0x06A, 0x05C, 0x060, 0x034, 0x03B, 0x05E, 0x014, 0x036, 0x060, 0x068,
		0x076, 0x060, 0x065, 0x031, 0x02B, 0x023, 0x024, 0x064, 0x036, 0x059, 0x02B, 0x025, 0x023, 0x077, 0x065, 0x02E,
		0x059, 0x07E, 0x04C, 0x025, 0x06A, 0x033, 0x043, 0x06A, 0x076, 0x05A, 0x062, 0x064, 0x054, 0x010, 0x069, 0x05B,
		0x023, 0x02B, 0x07D, 0x06F, 0x01B, 0x084, 0x072, 0x038, 0x028, 0x046, 0x017, 0x028, 0x059, 0x07E, 0x05B, 0x03B,
		0x06E, 0x02A, 0x041, 0x04B, 0x02E, 0x056, 0x009, 0x046, 0x061, 0x049, 0x073, 0x067, 0x058, 0x067, 0x047, 0x073,
		0x058, 0x03C, 0x04D, 0x023, 0x044, 0x027, 0x038, 0x019, 0x06B, 0x077, 0x02B, 0x073, 0x059, 0x038, 0x02A, 0x065,
		0x065, 0x050, 0x070, 0x08D, 0x01F, 0x034, 0x051, 0x00D, 0x05E, 0x06B, 0x05A, 0x073, 0x039, 0x028, 0x02A, 0x040,
		0x049, 0x073, 0x050, 0x024, 0x009, 0x033, 0x071, 0x04E, 0x022, 0x02F, 0x069, 0x064, 0x025, 0x031, 0x06C, 0x062,
		0x000 };	
	
	// if you want to, check if encryption routine has been understood correctly
	if (0)		
	{
		encrypt(szKey, szCodePhrase);
		cout << "Set a breakpoint on the previous function call and compare the encrypted codephrase with the one in the crackme" << endl;
		cout << "They should be identical" << endl << endl;		
	}

	// get the proper key
	if (getKey(szKey, szCodePhrase2, szEncrypted))
		cout << "Key:" << endl << szKey << endl << endl;
	else
		cout << "Key retrieval not possible" << endl;
	
	//system("PAUSE");
    return EXIT_SUCCESS;
}

// encrypt codephrase with given key
void encrypt(const char* szKey, char* szCodePhrase)
{
	unsigned char cRemainder = sum(szKey) % 0x20;
	while (*szCodePhrase != 0)
	{
		*szCodePhrase = (*szCodePhrase ^ szKey[cRemainder]) + cRemainder;
		cRemainder = ((unsigned char)(cRemainder + *szCodePhrase)) % 0x20;
		szCodePhrase++;
	}
}

// add together all chars of the string
unsigned char sum(const char* szKey)
{
	unsigned sum = 0;
	unsigned nLen = strlen(szKey);
	
	for (unsigned u = 0; u < nLen; u++)
		sum += szKey[u];
	
	return (unsigned char) sum;
}

// retrieve the proper key
bool getKey(char* szKey, const char* szCodePhrase, const char* szEncrypted)
{
	// with the proper key, the codephrase will be encrypted identical to szEncrypted
	// so the encryption has to be inverted
	
	// problem: key is unknown, but the sum of its chars determines the initial value for remainder.
	// easy solution here. since the remainder is taken modulo 0x20 = 32d, a simple loop will
	// do the job, if it is combined with a check if the calculated szKey values have changed
	// while doing the encryption
	
	unsigned uKeyLen = strlen(szKey);
	
	// test every possible starting value for the remainder	
	for (unsigned uSum = 0; uSum < 0x20; uSum++)
	{
		// copy the codephrase because it will be changed
		char* szCodePhraseBuffer = (char*) malloc(strlen(szCodePhrase)+1);
		memcpy(szCodePhraseBuffer, szCodePhrase, strlen(szCodePhrase)+1);
		
		// try to get the key with this remainder initialization
		bool bSuccess = getKey_sum(szKey, uKeyLen, uSum, szCodePhraseBuffer, szEncrypted);
		free(szCodePhraseBuffer);
		
		// check if the key has the proper length and is consistent with the assumption for the initial remainder
		if (bSuccess && (strlen(szKey) == 0x020) && (sum(szKey) % 0x020 == uSum))
			return true;
	}
		
	return false;
}

// try to retrieve the key with the specified starting value for the remainder
// returns false if the starting value for sum is incorrect
bool getKey_sum(char* szKey, unsigned uKeyLen, unsigned char cSum, char* szCodePhrase, const char* szEncrypted)
{
	// initialize the key with 0	
	memset(szKey, 0, uKeyLen);
	
	unsigned char cRemainder = cSum;
	while (*szCodePhrase != 0)
	{
		// extract the proper key char
		unsigned char cKeyChar = (*szEncrypted - cRemainder) ^ *szCodePhrase; 
		
		// check if the char has already been calculated. if yes, is it different now?
		if ((szKey[cRemainder] != 0) && (szKey[cRemainder] != cKeyChar))
			return false;
		szKey[cRemainder] = cKeyChar;
		
		// use it to encrypt the codephrase again (necessary to get the correct remainder value)
		*szCodePhrase = (*szCodePhrase ^ szKey[cRemainder]) + cRemainder;
		cRemainder = ((unsigned char)(cRemainder + *szCodePhrase)) % 0x20;
		
		// next iteration
		szCodePhrase++; szEncrypted++;
	}
	
	return true;
}
