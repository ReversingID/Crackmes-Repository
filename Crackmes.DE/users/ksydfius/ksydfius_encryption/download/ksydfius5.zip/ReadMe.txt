=======================
- Ksydfius Encryption -
-  Coded by Ksydfius  -
=======================

I have created yet another encryption algorithm ;)
This time you have the algorithm and the encrypted text. All you need to do
is to simply decrypt the encrypted text.

So here's a summary of what you need to know:

1. You only have the algorithm and the encrypted text.
2. The algorithm uses a key.
3. You do NOT have a pair of plaintext and ciphertext to use to find the key.
4. You WILL need some guesswork
5. The plaintext consists of chars 0x20 to 0x7A (inclusive)
6. The key cannot be brute-forced
7. The key is not in a dictionary
8. The key is consists of chars 0x20 to 0x7A (inclusive)

This one will require you to do some more advanced cryptanalysis.
I must say this one is much harder than "The XOR Algorithm" series, and coding
knowledge is strongly recommended.
The algorithm is not too complex, and you have a nice encrypted text, so it should
be doable.

Anyway, to save you some time and work I put the encrypted text here as hex bytes
(I opened the encrypted text up in Reflector, and got some nasty stuff :P)

72 e0 8d 90 9e d1 d0 50 9a 80 75 b1 4f fa 9e 34 aa a2 78 cf fa 9d fd 5b 5e d1 d0 96 bb 45 f5 b1 cb 9f 24 02 cf 25 10 f4 b0 02 d4 bd 00 09 30 9b 5e e0 4d 10 97 35 e8 26 1d fe e1 4a 62 5b 45 4e 14 bf fe e9 80 b2 ba 6c bc 16 84 3e f6 d2 9b 48 100 fe d4 bc 11 a8 fe d9 9b 5e d1 4f 38 cf 41 87 2c bc 14 67 bf 34 a7 d1 9b 45 4e 14 bf fe e9 80 36 4f 78 37 d5 a8 2c cd 10 50 9a 80 75 b1 4f fa 9e 34 aa 7c 3f 34 91 d0 f4 100 0c dd 3b 5e fe ed c0 83 02 24 fd 0d 14 be d5 01 cc 90 9e ed 08 2a 60 86 a8 22 47 bf 34 c0 fc c5 13 d0 83 84 be 34 0d 16 09 10 68 14 be d1 d0 96 bb 42 c6 21 90 f4 b0 f8 06 d1 4f 45 be 34 e1 5b 48 100 fe d4 b8 0c 10 9e d9 9b 100 0c bc 14 67 bf 26 8f 41 07 32 d8 29 10 96 bb c3 15 02 f5 71 4c dd 16 00 b2 05 9f 26 8f fa 9e 26 bf 34 a7 d1 9b 41 07 32 d8 29 60 45 13 b0 82 44 0e 04 5f 2c dd 19 f4 d0 35 be f9 9b de 2e 44 44 12 90 ae fa 9b 5e d1 a8 fe e1 a8 00 65 12 20 0c 06 f4 e0 fa 9e f8 07 26 1d fe e1 47 b1 c8 dc 100 06 b1 c8 20 75 b1 4f fa 5f fe e0 35 e8 32 d8 29 60 b2 84 91 4c 06 97 d4 bf 00 5d 16 00 b2 c4 13 0d 90 9e d1 d0 50 9a 80 75 b1 4f fa 9d fa 74 e1 5b c2 90 54 28 2e 04 fd 16 4f 83 99 cf fa df 0c 1e f6 d2 9b 44 89 dc 45 0e 04 fd 73 b8 23 d4 3e 2e c1 85 f4 b0 83 f9 ce 04 c2 f5 be fe f8 05 9b 5e f6 50 02 31 9e d4 bf fa 9d 10 58 29 b8 10 58 ce 0c 10 58 53 c6 d1 4f fa 9e 2e fa 100 00 3d b4 b0 81 48 28 2a 70 9e f8 0b 16 bb 48 100 fe e9 80 3d 4b a3 15 02 80 b2 2a 90 9e d4 d0 02 f5 29 f9 50 96 bb c1 88 84 b9 52 cc 91 9b 46 1f fa 64 12 05 26 42 15 02 cf 0d 10 f4 bf 00 3d 11 e0 b2 85 23 d9 09 10 68 f9 9b 100 fa 9e e1 4a 62 93 aa 28 87 d1 d0 f4 bf 00 65 3e dd f8 94 bf 00 3d b4 c8 28 1a 9a f4 bc 0d 14 aa 99 cf c1 06 bf 34 a7 d1 9b 45 ed fd 0f b1 9b 48 100 fe d4 e0 fe fe f8 0c 8d 14 aa 60 06 28 d8 29 10 54 a7 69 00 6d 1e d9 74 be ed 06 bf 24 e9 20 86 2a f7 2f 100 04 4e 14 d0 35 be f8 05 9f 26 f4 b8 23 d4 3e 28 1e f6 bb 48 100 0a 7c 17 08 100 b8 29 a1 3d b4 bc 11 4f 48 0c 11 d0 ae 44 89 dc 41 07 32 d8 29 60 45 13 b0 82 44 4e cc bc 0d 04 ed 90 9e e1 90 5c b4 bf 08 d8 d0 02 f4 3f fe d1 4f c2 90 5c b4 b8 37 d5 a8 2c 06 20 07 1a 9c 18 d0 f8 94 b8 0c fd 53 7a 58 39 60 87 32 cb bc 57 54 3e 28 22 90 5c b4 3c 57 35 d1 9b 48 100 fe d4 be 26 8f f3 84 12 3a e9 a2 c6 93 05 97 4f 1d 0f 83 99 52 a8 14 be ed 06 bf 34 a7 d1 9b 38 ce 14 bf b8 29 60 b2 ba 98 07 d8 d1 50 9e f8 07 26 1d fe e1 47 b1 c8 82 cc bc 0d 04 14 71 d0 54 91 a8 dc 41 65 1e fc c5 93 c0 0a 70 a1 3d 3b 5e f5 4d 8e c1 5d 0f 35 be ed 06 bf 34 a7 d1 9b 38 21 c7 42 15 68 2c 00 b2 02 15 29 100 08 1c 16 4f 00 65 13 aa 99 21 c7 b1 4d ed 10 5c b4 e0 08 1c 0f 03 c9 dc 41 07 32 d8 29 60 75 32 c6 2a 10 68 14 be ed 06 2a 10 9b 5e e1 90 9f 30 81 b0 58 db 45 26 8b a3 55 68 20 b8 19 9d 14 e6 8b 68 08 14 be e1 90 f4 be 36 01 c7 bf 2e 02 a8 100 fe e9 f7 3b 9e 24 c3 bf e0 75 12 c4 90 f4 b0 35 be e1 90 9e d9 5c 0f 03 5f 26 b1 4b a2 4a e2 c8 32 84 93 d0 25 12 80 b8 54 bc 11 4b 9c fa 9e 34 aa a2 78 cf fa de 26 29 b8 3b 5f b8 a0 f8 75 f3 aa 8c 06 93 05 7f 36 e8 82 cc bc 5b a0 02 4b f8 05 8b 6c 06 97 d4 bf 00 5d b4 05 ed 16 f0 dd fe d4 b0 35 be f8 05 97 83 5f 34 e1 5b 00 07 1e d1 4d bc 0d 14 aa 91 34 70 fb 5e e5 3e fe d4 bc 0f 4d bf b8 d0 00 b2 81 5b 08 0c 10 9e d4 c8 22 b0 58 db c6 24 3e d4 c0 06 22 16 4e 08 dc 48 f9 a0 0c bc 19 6c 1e d4 be 32 46 e7 b1 a0 85 29 b8 10 60 85 8b f8 23 d4 00 3d b4 b0 ae 28 0c 91 9b c3 b5 e8 1e d4 bf 0a 7c 17 17 04 fd b4 bf 08 d8 f0 60 06 28 d8 29 a1 3d b4 d8 07 32 9b 48 0c bc 3b 1e 24 e9 20 86 2a 7a f4 50 ae 18 ce 16 94 aa 60 85 26 22 cf 83 e9 00 3d 3b 5e e9 b0 f4 3b c1 75 29 dc 48 0c bc 37 94 aa 60 75 be dd fd 0d 0e 0e 02 a8 00 35 71 c8 82 cc bc 0e 44 e9 85 fd 0e 48 dc 100 0c bc 01 5b 41 2d 10 f4 bf 08 d8 d1 50 64 fd b4 bf 00 3d b4 3d ed 02 cf f0 ae 00 4d 91 9b c1 2d 16 ce 06 97 4f 00 65 13 aa 90 6c 1e db 5e ee 08 f1 e8 dc 46 1d 00 b2 87 28 2e c0 83 43 c9 7d fe d4 bc 0d 16 94 aa a2 4a b8 10 6c 11 e0 8d bc 0d 02 b5 12 ba f4 bf 12 d8 52 cb 84 81 5b 45 92 05 8b 9e e1 90 5c cc bc 0f 83 c1 93 aa 20 06 72 47 1a 80 b5 bb 41 65 12 45 97 54 bf 0e 0c cd 91 cc 06 8f 45 81 5b c2 70 f4 0d 06 27 d8 4f 100 06 bf 32 05 1d f6 bb 48 100 02 4b f8 0b dd 16 75 71 4c dd b4 0d 06 27 d8 f8 ce 16 94 aa 9a 6c 10 58 db 100 b8 50 03 02 d4 bf b8 01 4a 100 b8 e0 07 1e d1 4d ed 10 5c b4 bf 00 4d 16 bb 100 04 06 24 13 d0 83 99 d1 fa f4 be 2c dd 0d 14 c0 b8 54 3f 02 a8 f9 f4 b0 ae 48 18 29 60 07 22 c6 8b f8 05 8f 08 dc 45 3e f5 d1 cc 91 9b c2 a8 dc 48 0c bc 0e 40 2d d5 c1 c9 f9 74 80 fc 0f ae f0

=======
- FAQ -
=======

Q: Is this algorithm reversible?
A: Of course it is.

Q: Do I need to code to decrypt this one?
A: Yes, unless you want to spend the next few years decrypting by hand :P

Q: How do I decrypt? I only have the encrypted text, there's no plaintext and
   ciphertext example to use to calculate the key...
A: That's the whole point of this challenge. You need some way to get the key, think
   a little bit.

========

PS: I have been nice and removed some typoes for you... ;)

Enjoy

-ksydfius

