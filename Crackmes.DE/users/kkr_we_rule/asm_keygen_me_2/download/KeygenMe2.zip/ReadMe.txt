This is my second ASM challenge :)

I think, its better than my 1st asm challenge :)

This is very much easy & if you use your brain a lil bit, every one can solve it :D

Waiting for lots of solns :)

Rules :
Keygen is the only soln as always :D

Regards
KKR