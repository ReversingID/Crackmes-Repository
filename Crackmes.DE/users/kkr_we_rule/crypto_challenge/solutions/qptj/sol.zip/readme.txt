Files:

CrYpTo_deob.exe      -    deobfuscated keygenme
keygen.rar           -    my keygen and source code in asm
solution             -    an explaination about how to solve this keygenme
FGInt.sig            -    IDA's signature for recognising FGInt functions
readme.txt           -    You are reading it