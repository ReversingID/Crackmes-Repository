
#define _CRT_SECURE_NO_WARNINGS

#undef UNICODE
#undef _UNICODE
#include <windows.h>
#include <CommCtrl.h>
#include "resource.h"

#define	APP_NAME		"RED CReW KGM#1 By KKR - Keygen"
#define	NAME_MAX		30

// return greatest common divisor
//----------------------------------------
DWORD func_00475018_GDC (DWORD dwArg1, DWORD dwArg2)
{
	if (dwArg2 == 0) return dwArg1;

	while (dwArg1)
		if (dwArg1 >= dwArg2)
			dwArg1 -= dwArg2;
		else
			dwArg2 -= dwArg1;
	
	return dwArg2;
}
// TODO: WARN: crackme uses LONGLONG
//----------------------------------------
DWORD func_00475098 (char *szString)
{
	DWORD i, dwLen, dwReturn=0, dw1=0, dw2=0, dw3=0, dw4=0;

	if (szString == NULL) return 0;
	dwLen = strlen (szString);
	if (dwLen == 0) return 0;

	for (i=0; i<dwLen; i++)
	{
		dw1 += szString[i];
		dw2 = (dw1 * i) ^ dw1;
		dw3 = (dw2 * i) ^ dw2;
		dw4 = (dw1 + dw2) ^ (dw3 + dw4);

		dwReturn += func_00475018_GDC (dw1, dw4);		// greatest common divisor
		dw1 = dwReturn;
	}
	return dwReturn;
}
//----------------------------------------
bool DoBrute (HWND hDlg)
{
	DWORD i1, i2, i3, i4, i5, i6;
	DWORD dwVal1, dwVal2, dwVal3;
	char szBuf[128]={0}, szSerial1[20]="1111111111111111111";

	SetDlgItemText (hDlg, IDC_EDIT_SERIAL, "");
	if (!GetDlgItemText (hDlg, IDC_EDIT_NAME, szBuf, sizeof(szBuf)))
		return false;
	dwVal1 = func_00475098 (szBuf); // registration Name
	dwVal3 = func_00475098 ("11111111111111111111"); // Serial part2
	dwVal3 = dwVal3 * dwVal3;

	for (i1='1'; szSerial1[14]=i1, i1<='9'; i1++)
		for (i2='1'; szSerial1[14]=i2, i2<='9'; i2++)
			for (i3='1'; szSerial1[15]=i3, i3<='9'; i3++)
				for (i4='1'; szSerial1[16]=i4, i4<='9'; i4++)
					for (i5='1'; szSerial1[17]=i5, i5<='9'; i5++)
						for (i6='1'; szSerial1[18]=i6, i6<='9'; i6++)
						{
							dwVal2 = func_00475098 (szSerial1);
							if ((dwVal3 % dwVal1) == (dwVal2 % dwVal1))
							{
								wsprintf (szBuf, "%s+11111111111111111111", szSerial1);
								SetDlgItemText (hDlg, IDC_EDIT_SERIAL, szBuf);
								return true;
							}
						}
	MessageBox (hDlg, "Sorry, can't find the serial", APP_NAME, 0);
	return false;
}
//----------------------------------------
BOOL CALLBACK DialogProc(HWND  hwndDlg, UINT  uMsg, WPARAM  wParam, LPARAM  lParam )
{
	switch (uMsg)
	{
#ifdef NAME_MAX
	case WM_INITDIALOG:
		SendDlgItemMessage (hwndDlg, IDC_EDIT_NAME, EM_SETLIMITTEXT, NAME_MAX, 0);
		return TRUE;
#endif

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDC_BUTTON_GENERATE:
			DoBrute (hwndDlg); return TRUE;
		case IDCANCEL:
			EndDialog (hwndDlg, 0); return TRUE;
		}
		break;
	}
	return FALSE;
}
//----------------------------------------
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	InitCommonControls ();
	DialogBoxParam (hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, DialogProc, 0);
	return (0);
}
