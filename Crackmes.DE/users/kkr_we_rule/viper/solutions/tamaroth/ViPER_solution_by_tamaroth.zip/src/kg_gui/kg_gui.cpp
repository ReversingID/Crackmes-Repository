#pragma comment(lib, "miracl.lib")
#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>
// Windows Header Files:
#include <windows.h>

#include "resource.h"
#include "crc32.h"
extern "C"{
	#include "md5.h"
	#include "miracl.h"
}

typedef struct Names{
	char *p1;
	char *p2;
} Names;

HINSTANCE hInst;

INT_PTR CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
const char *tab = "AZQXSWECDVFRTGBNHYJUMkkr_we_ruleKKR_WE_RULEreDREdPOKMLNUADUYQWESAGDSA";

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	_CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
	hInst = hInstance;
	_CrtDumpMemoryLeaks();
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DIALOG), NULL, (DLGPROC)WndProc, NULL);
	_CrtDumpMemoryLeaks();
	_CrtMemDumpAllObjectsSince(NULL);
	return 0;
}

char mixChar(char character){
	int rEBX = 1;
	__int64 VarV=0, VarB=character;

	for(int i=1; i<0x45; i++){
		VarV = (tab[rEBX-1] + VarV) ^ VarB;
		rEBX++;
	}
	VarV = VarV^VarB;

	return tab[VarV%0x45-1];
}

char *hexToStr(unsigned char input[], int length){
	char *output = new char[length*2+1];
	memset(output, 0, length*2+1);
	int tmp;
	int c = 0;
	for(int i=0;i<length;i++){
		tmp = (input[i] & 0xF0) >> 4;
		output[c++] = tmp + (tmp > 0x9 ? 0x37 : 0x30);
		tmp = (input[i] & 0x0F);
		output[c++] = tmp + (tmp > 0x9 ? 0x37 : 0x30);
	}
	return output;
}

Names hashName(char *name){

	char *a1 = new char[50];
	char *a2 = new char[50];
	char *md5in;
	unsigned char md5out[20];
	char *md5text;
	unsigned int crc=0;
	char crcT[10];

	int nameLen = strlen(name);
	char *crcName = new char[nameLen*8+1];
	md5in = new char[nameLen*2];
	memset(crcName, 0, nameLen*8+1);
	MD5_CTX ctx;
	memset(md5in, 0, nameLen*2);
	for (int i=0; i<nameLen;i++){
		md5in[i] = mixChar(name[i]);
		MD5Init(&ctx);
		MD5Update(&ctx,(unsigned char*)md5in, i+1);
		MD5Final(md5out, &ctx);
		md5text = hexToStr(md5out, 16);
		crc = crc32b((unsigned char *)md5text, strlen(md5text));
		sprintf(crcT,"%08X",crc);
		crc = crc32((unsigned char *)crcT, 8);
		sprintf(crcT,"%08X",crc);
		strcat(crcName, crcT);
		delete [] md5text;
	}
	delete [] md5in;
	crc = crc32b((unsigned char *)crcName, strlen(crcName));
	delete [] crcName;
	
	sprintf(crcT,"%08X",crc);

	sprintf(a1, "%d", crcT[1]+crcT[2]+crcT[3]+crcT[4]+crcT[5]);
	sprintf(a2, "%d", crcT[0]+crcT[1]+crcT[2]+crcT[3]+crcT[4]);
	Names nm;
	nm.p1 = a1;
	nm.p2 = a2;
	return nm;
}

char *generateSerial(char *name){
	big n, g, r, n2;
	big c,m,m2;
	miracl *mip;

	mip=mirsys(100,10);
	mip->IOBASE = 10;
	n=mirvar(0);
	g=mirvar(0);
	c=mirvar(0);
	m=mirvar(0);
	r=mirvar(0);
	n2=mirvar(0);
	m2=mirvar(0);
	char ser[255];
 	char *serial = new char[255];
	Names nm = hashName(name);

	cinstr(m,nm.p1);
	cinstr(m2, nm.p2);
	delete [] nm.p1;
	delete [] nm.p2;
	cinstr(n,"30762939629028809");
	cinstr(g,"30762939629028810");
	cinstr(r, "2");

	multiply(n,n,n2);
	powmod2(g,m,r,n,n2,c);
	cotstr(c, ser);

	memset(serial, 0, 255);
	memcpy(serial, ser, strlen(ser));
	serial[strlen(serial)] = '-';

	powmod2(g,m2,r,n,n2,c);
	cotstr(c, ser);

	strcat(serial, ser);
	mirkill(n);
	mirkill(g);
	mirkill(c);
	mirkill(m);
	mirkill(r);
	mirkill(n2);
	mirkill(m2);
	mirexit();
	return serial; 
}

void DrawBorder(HWND hWnd, int IDENT, PAINTSTRUCT ps){
	POINT pt;
	RECT rc;

	GetWindowRect(GetDlgItem(hWnd, IDENT), &rc);
	pt.x = rc.left;
	pt.y = rc.top;
	ScreenToClient(hWnd, &pt);
	rc.left = pt.x;
	rc.top = pt.y;
	pt.x = rc.right;
	pt.y = rc.bottom;
	ScreenToClient(hWnd, &pt);
	rc.right = pt.x;
	rc.bottom = pt.y;
	Rectangle(ps.hdc, rc.left-1,rc.top-1,rc.right+1,rc.bottom+1);

	return;
}

INT_PTR CALLBACK WndProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam){
	UNREFERENCED_PARAMETER(lParam);
	PAINTSTRUCT ps;
	HFONT hFont;
	char UserName[255];
	char *serial;
	DWORD lpnSize = 255;

	switch (message){
	case WM_INITDIALOG:
		{
			GetUserName(UserName, &lpnSize);
			SetDlgItemText(hDlg, IDC_NAME, UserName);
			serial = generateSerial(UserName);
			SetDlgItemText(hDlg, IDC_SERIAL, serial);
			delete [] serial;
			hFont = CreateFont(12,0,0,0,FW_BOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY, FF_DONTCARE,TEXT("Verdana"));
			SendDlgItemMessage(hDlg, IDC_NAME, WM_SETFONT, (WPARAM)hFont, TRUE);
			SendDlgItemMessage(hDlg, IDC_SERIAL, WM_SETFONT, (WPARAM)hFont, TRUE);
			return (INT_PTR)TRUE;
		}

	case WM_NCPAINT:
		BeginPaint(hDlg, &ps);
		DrawBorder(hDlg, IDC_NAME, ps);
		DrawBorder(hDlg, IDC_SERIAL, ps);
		EndPaint(hDlg, &ps);
		return (INT_PTR)0;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL){
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		if (HIWORD(wParam) == EN_UPDATE && LOWORD(wParam) == IDC_NAME){
			GetDlgItemText(hDlg, IDC_NAME, UserName, 255);
			_CrtDumpMemoryLeaks();
			serial = generateSerial(UserName);
			SetDlgItemText(hDlg, IDC_SERIAL, serial);
			delete [] serial;
			_CrtDumpMemoryLeaks();
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}
