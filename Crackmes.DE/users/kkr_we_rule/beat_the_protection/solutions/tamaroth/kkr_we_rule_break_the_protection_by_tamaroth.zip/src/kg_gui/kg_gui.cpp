#pragma comment(lib, "miracl.lib")
// Windows Header Files:
#include <windows.h>

// C RunTime Header Files
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>
#include "crc32.h"
#include "resource.h"
extern "C"{
	#include "miracl.h"
}


HINSTANCE hInst;
INT_PTR CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	hInst = hInstance;
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DIALOG), NULL, (DLGPROC)WndProc, NULL);
	return 0;
}

char *UInt2HexStr(unsigned int val){
	char *ps = new char[15];
	_ltoa(val, ps, 16);
	return ps;
}

char *generateSerial(char *name)
{
	big c,n,d,m;
	miracl *mip;
	char ts[255];
	char *serial = new char[255];
	unsigned int crc;

	mip=mirsys(100,10);
	mip->IOBASE = 16;
	c=mirvar(0);
	n=mirvar(0);
	d=mirvar(0);
	m=mirvar(0);

	crc = crc32b((unsigned char *)name, strlen(name));
	char *crcs = UInt2HexStr(crc);

	//convert(crc, m);
	cinstr(m, crcs);
	delete [] crcs;

	convert(0x15A5A, n);
	divide(m, n, n);

	cinstr(n, "835951C76BBFA7926329FB0DE0B30849");
	cinstr(d, "1294B51BE7E331DA2FB8F131C33E265D");

	powmod(m, d, n, c);

	cotstr(c, ts);

	wsprintf(serial, "40ABDB3B6D3FB3E3EB57C9B3647F2BD2-%s", ts);

	mirkill(m);
	mirkill(d);
	mirkill(n);
	mirkill(c);
	mr_free(mip);
	return serial;
}

void DrawBorder(HWND hWnd, int IDENT, PAINTSTRUCT ps)
{
	POINT pt;
	RECT rc;

	GetWindowRect(GetDlgItem(hWnd, IDENT), &rc);
	pt.x = rc.left;
	pt.y = rc.top;
	ScreenToClient(hWnd, &pt);
	rc.left = pt.x;
	rc.top = pt.y;
	pt.x = rc.right;
	pt.y = rc.bottom;
	ScreenToClient(hWnd, &pt);
	rc.right = pt.x;
	rc.bottom = pt.y;
	Rectangle(ps.hdc, rc.left-1,rc.top-1,rc.right+1,rc.bottom+1);

	return;
}

INT_PTR CALLBACK WndProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	PAINTSTRUCT ps;
	HFONT hFont;
	char UserName[255];
	char *serial;
	DWORD lpnSize = 255;

	switch (message)
	{
	case WM_INITDIALOG:
		{
			GetUserName(UserName, &lpnSize);
			SetDlgItemText(hDlg, IDC_NAME, UserName);
			serial = generateSerial(UserName);
			SetDlgItemText(hDlg, IDC_SERIAL, serial);
			SetDlgItemText(hDlg, IDC_SERIAL2, "1234567890-1234567890");
			delete [] serial;
			hFont = CreateFont(12,0,0,0,FW_BOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY, FF_DONTCARE,TEXT("Verdana"));
			SendDlgItemMessage(hDlg, IDC_NAME, WM_SETFONT, (WPARAM)hFont, TRUE);
			SendDlgItemMessage(hDlg, IDC_SERIAL, WM_SETFONT, (WPARAM)hFont, TRUE);
			SendDlgItemMessage(hDlg, IDC_SERIAL2, WM_SETFONT, (WPARAM)hFont, TRUE);
			return (INT_PTR)TRUE;
		}



	case WM_NCPAINT:
		BeginPaint(hDlg, &ps);
		DrawBorder(hDlg, IDC_NAME, ps);
		DrawBorder(hDlg, IDC_SERIAL, ps);
		DrawBorder(hDlg, IDC_SERIAL2, ps);
		DrawBorder(hDlg, IDC_SERIAL3, ps);
		EndPaint(hDlg, &ps);
		return (INT_PTR)0;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		if (HIWORD(wParam) == EN_UPDATE && LOWORD(wParam) == IDC_NAME)
		{
			int nlen = GetDlgItemText(hDlg, IDC_NAME, UserName, 255);
			if(nlen < 4 || nlen > 0x20)
			{
				SetDlgItemText(hDlg, IDC_SERIAL, "Name must be at least 4 and at most 32 characters");
				return (INT_PTR)TRUE;
			}
			serial = generateSerial(UserName);
			SetDlgItemText(hDlg, IDC_SERIAL, serial);
			delete [] serial;
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}
