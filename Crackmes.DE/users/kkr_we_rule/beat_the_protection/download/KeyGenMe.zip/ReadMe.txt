This one is a level 5 challenge :D
Beat the protection :D

Required Soln : Keygen
Patching, Bruteforcing is forbidden as always :D

Note :
The algo is completely reversible :)

Have a great day :) & Happy reversing :)

Regards
KKR