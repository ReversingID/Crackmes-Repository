/* keygen for voltage keygenme, numerni - crackmes.de*/
#include <iostream.h>
#include <windows.h>
#include <stdio.h>
#include "bigint.h"
#include "SHA1.h"
	           
extern "C"
{
#include "md5.h"
};

unsigned __int64 int64_exp(unsigned __int64 a, unsigned __int64 b)
{
	if (b == 0) { return 1; }
	__int64 r = 1;
	while (b)
	{
		r *= a;
		b--;
	}
	return r;
}

unsigned __int64 shl_mod(unsigned __int64 a, unsigned __int64 b)
{
	unsigned long a_x = a & 0xFFFFFFFF, a_y = a >> 32, a_z = b & 0xFF;
	__asm
	{
		  pushad
		  mov	  eax, a_x
		  mov	  edx, a_y
		  mov	  ecx, a_z
		  and	  ecx, 255
		  cmp     cl, 0x20
		  jl L011
		  cmp     cl, 0x40
		  jl L007
		  xor     edx, edx
		  xor     eax, eax
		  jmp _out
		L007:
		  mov     edx, eax
		  shl     edx, cl
		  xor     eax, eax
		  jmp _out
		L011:
		  shld    edx, eax, cl
		  shl     eax, cl
		  jmp _out
		_out:
		  mov dword ptr ds:[a_x], eax
		  mov dword ptr ds:[a_y], edx
		  popad
	}
	unsigned __int64 r;
	r = a_y;
	r <<= 32;
	r += a_x;
	return r;
}

unsigned __int64 shr_mod(unsigned __int64 a, unsigned __int64 b)
{
	unsigned long a_x = a & 0xFFFFFFFF, a_y = a >> 32, a_z = b & 0xFF;
	__asm
	{
		  pushad
		  mov	  eax, a_x
		  mov	  edx, a_y
		  mov	  ecx, a_z
		  and	  ecx, 255
		  cmp     cl, 20
		  jl L011
		  cmp     cl, 40
		  jl L007
		  xor     edx, edx
		  xor     eax, eax
		  jmp _out
		L007:
		  mov     eax, edx
		  xor     edx, edx
		  shr     eax, cl
		  jmp _out
		L011:
		  shrd    eax, edx, cl
		  shr     edx, cl
		  jmp _out
		_out:
		  mov dword ptr ds:[a_x], eax
		  mov dword ptr ds:[a_y], edx
		  popad
	}
	unsigned __int64 r;
	r = a_y;
	r <<= 32;
	r += a_x;
	return r;
}

void  __declspec(naked) asmmul()
{
	__asm
	{
		  push    edx
		  push    eax
		  mov     eax, dword ptr ss:[esp+10h]
		  mul     dword ptr ss:[esp]
		  mov     ecx, eax
		  mov     eax, dword ptr ss:[esp+4]
		  mul     dword ptr ss:[esp+0Ch]
		  add     ecx, eax
		  mov     eax, dword ptr ss:[esp]
		  mul     dword ptr ss:[esp+0Ch]
		  add     edx, ecx
		  pop     ecx
		  pop     ecx
		  retn    8
	}
}

void  __declspec(naked) asmpow()
{
	static unsigned long var1,var2,var3;
	__asm
	{
		  push    ebp
		  mov     ebp, esp
		  add     esp, -18h
		  push    ebx
		  cmp     dword ptr ss:[ebp+0Ch], 0
		  jnz L011
		  cmp     dword ptr ss:[ebp+8], 0
		  jnz L011
		  mov     dword ptr ss:[var2], 1
		  mov     dword ptr ss:[var3], 0
		  jmp L043
		L011:
		  cmp     dword ptr ss:[ebp+14h], 0
		  jnz L018
		  cmp     dword ptr ss:[ebp+10h], 0
		  jnz L018
		  mov     dword ptr ss:[var2], 0
		  mov     dword ptr ss:[var3], 0
		  jmp L043
		L018:
		  mov     ebx, dword ptr ss:[ebp+8]
		  mov     eax, dword ptr ss:[ebp+10h]
		  mov     dword ptr ss:[var1], eax
		  mov     eax, dword ptr ss:[ebp+14h]
		  mov     dword ptr ss:[ebp-14h], eax
		  mov     eax, dword ptr ss:[ebp+10h]
		  mov     dword ptr ss:[ebp-10h], eax
		  mov     eax, dword ptr ss:[ebp+14h]
		  mov     dword ptr ss:[ebp-0Ch], eax
		  cmp     ebx, 1
		  je L039
		L029:
		  push    dword ptr ss:[ebp-0Ch]
		  push    dword ptr ss:[ebp-10h]
		  mov     eax, dword ptr ss:[var1]
		  mov     edx, dword ptr ss:[ebp-14h]
		  call    asmmul
		  mov     dword ptr ss:[var1], eax
		  mov     dword ptr ss:[ebp-14h], edx
		  dec     ebx
		  cmp     ebx, 1
		  jnz L029
		L039:
		  mov     eax, dword ptr ss:[var1]
		  mov     dword ptr ss:[var2], eax
		  mov     eax, dword ptr ss:[ebp-14h]
		  mov     dword ptr ss:[var3], eax
		L043:
		  mov     eax, dword ptr ss:[var2]
		  mov     edx, dword ptr ss:[var3]
		  pop     ebx
		  mov     esp, ebp
		  pop     ebp
		  retn    10h
	}
}

void  __declspec(naked) shl_asm()
{
	__asm
	{
		  cmp     cl, 20h
		  jl L011
		  cmp     cl, 40h
		  jl L007
		  xor     edx, edx
		  xor     eax, eax
		  retn
		L007:
		  mov     edx, eax
		  shl     edx, cl
		  xor     eax, eax
		  retn
		L011:
		  shld    edx, eax, cl
		  shl     eax, cl
		  retn
	}
}

void  __declspec(naked) shr_asm()
{
	__asm
	{
		  cmp     cl, 20h
		  jl L011
		  cmp     cl, 40h
		  jl L007
		  xor     edx, edx
		  xor     eax, eax
		  retn
		L007:
		  mov     eax, edx
		  xor     edx, edx
		  shr     eax, cl
		  retn
		L011:
		  shrd    eax, edx, cl
		  shr     edx, cl
		  retn
	}
}


unsigned long __declspec(naked) bug_hash(char *ptrX, int rounds)
{
	static unsigned long var1x,var1y,var2x,var2y,var3x,var3y,var4x,var4y,var5x,var5y,var6x,var6y;
	__asm
	{
		
		  push    ebp
		  mov     ebp, esp
		  add     esp, -40h
		  push    ebx
		  push    esi

		  mov     dword ptr ss:[var1x], 0
		  mov     dword ptr ss:[var1y], 0
		  mov     dword ptr ss:[var2x], 0
		  mov     dword ptr ss:[var2y], 0
		  mov     dword ptr ss:[var3x], 0
		  mov     dword ptr ss:[var3y], 0
		  mov     dword ptr ss:[var4x], 0
		  mov     dword ptr ss:[var4y], 0
		  mov     dword ptr ss:[var5x], 0
		  mov     dword ptr ss:[var5y], 0
		  mov     dword ptr ss:[var6x], 0
		  mov     dword ptr ss:[var6y], 0
		 
		  mov     esi, eax
		  test    esi, esi
		  mov	  esi, dword ptr ds:[rounds]
		  jle L113
		  mov     ebx, 1
		L018:
		  push    dword ptr ss:[var1y]
		  push    dword ptr ss:[var1x]
		  mov     eax, ebx
		  cdq
		  push    edx
		  push    eax
		  call    asmpow
		  push    edx
		  push    eax
		  mov     eax, ptrX
		  mov     al, byte ptr ds:[eax+ebx-1]
		  and     eax, 0x0FF
		  xor     edx, edx
		  add     eax, dword ptr ss:[esp]
		  adc     edx, dword ptr ss:[esp+4]
		  add     esp, 8
		  mov     dword ptr ss:[var1x], eax
		  mov     dword ptr ss:[var1y], edx
		  mov     eax, dword ptr ss:[var1x]
		  mov     edx, dword ptr ss:[var1y]
		  xor     eax, dword ptr ss:[var2x]
		  xor     edx, dword ptr ss:[var2y]
		  mov     ecx, ebx
		  call    shl_asm
		  add     eax, dword ptr ss:[var2x]
		  adc     edx, dword ptr ss:[var2y]
		  add     eax, dword ptr ss:[var1x]
		  adc     edx, dword ptr ss:[var1y]
		  mov     dword ptr ss:[var2x], eax
		  mov     dword ptr ss:[var2y], edx
		  mov     eax, ebx
		  cdq
		  push    edx
		  push    eax
		  mov     eax, ebx
		  cdq
		  push    edx
		  push    eax
		  call    asmpow
		  mov     ecx, eax
		  mov     eax, dword ptr ss:[var2x]
		  mov     edx, dword ptr ss:[var2y]
		  xor     eax, dword ptr ss:[var3x]
		  xor     edx, dword ptr ss:[var3y]
		  call    shl_asm
		  add     eax, dword ptr ss:[var3x]
		  adc     edx, dword ptr ss:[var3y]
		  add     eax, dword ptr ss:[var2x]
		  adc     edx, dword ptr ss:[var2y]
		  mov     dword ptr ss:[var3x], eax
		  mov     dword ptr ss:[var3y], edx
		  mov     eax, dword ptr ss:[var3x]
		  mov     edx, dword ptr ss:[var3y]
		  xor     eax, dword ptr ss:[var4x]
		  xor     edx, dword ptr ss:[var4y]
		  mov     ecx, ebx
		  call    shr_asm
		  add     eax, dword ptr ss:[var4x]
		  adc     edx, dword ptr ss:[var4y]
		  add     eax, dword ptr ss:[var3x]
		  adc     edx, dword ptr ss:[var3y]
		  mov     dword ptr ss:[var4x], eax
		  mov     dword ptr ss:[var4y], edx
		  mov     eax, dword ptr ss:[var1x]
		  mov     edx, dword ptr ss:[var1y]
		  xor     eax, dword ptr ss:[var3x]
		  xor     edx, dword ptr ss:[var3y]
		  add     eax, dword ptr ss:[var2x]
		  adc     edx, dword ptr ss:[var2y]
		  xor     eax, dword ptr ss:[var4x]
		  xor     edx, dword ptr ss:[var4y]
		  add     eax, dword ptr ss:[var5x]
		  adc     edx, dword ptr ss:[var5y]
		  mov     dword ptr ss:[var5x], eax
		  mov     dword ptr ss:[var5y], edx
		  push    dword ptr ss:[var5y]
		  push    dword ptr ss:[var5x]
		  mov     eax, ebx
		  cdq
		  push    edx
		  push    eax
		  call    asmpow
		  add     eax, dword ptr ss:[var6x]
		  adc     edx, dword ptr ss:[var6y]
		  mov     dword ptr ss:[var6x], eax
		  mov     dword ptr ss:[var6y], edx
		  mov     eax, dword ptr ss:[var6x]
		  mov     edx, dword ptr ss:[var6y]
		  xor     eax, 0xDEADBEEF
		  xor     edx, 0
		  mov     dword ptr ss:[var1x], eax
		  mov     dword ptr ss:[var1y], edx
		  inc     ebx
		  dec     esi
		  jnz L018
		L113:
		  mov     eax, dword ptr ss:[var6x]
		  mov     edx, dword ptr ss:[var6y]
		  test    edx, edx
		  jge     __out
		  neg     eax
__out:

		  pop     edx
		  pop     ecx
		  pop     ecx

		  pop     esi
		  pop     ebx
		  mov     esp, ebp
		  pop     ebp
		 
		  retn

	}
}

void asciistr(char *p, char *o)
{
	int len = strlen(p);
	for (int i = 0; i < len; i++)
		wsprintf(o+(i<<1),"%X",p[i]);
}

int main()
{

	cout << "Keygenerator for KKR's VoLtAgE Keygenme - (numernia 2010 / crackmes.de) " << endl;
	cout << "----------------------------------------------------------------------------" << endl;

	char name[50], strhash1[100], strhash2[100], buf[50], hash_str[50];
	char serial1[100]={0},serial2[100]={0};
	unsigned char digest[200];
	SHA1Context sha;
	md5_context ctx;

	cout << "Name: ";
	cin >> name;

	int len = strlen(name);

	md5_starts(&ctx);

	md5_update(&ctx, (unsigned char *)name, len);
	md5_finish(&ctx, digest);

	char tmp[50];

	for (int k_i = 0; k_i < 16; k_i++)
	{
		wsprintf(tmp,"%X",digest[k_i]);
		if(k_i){ strcat(strhash1, tmp); }
		else {strcpy(strhash1,tmp);}
	
	}

	SHA1Reset(&sha);
	SHA1Input(&sha, (unsigned char*)name, len);
	SHA1Result(&sha , digest);

	for (int k_j = 0; k_j < 20; k_j++){
		wsprintf(strhash2 + k_j*2,"%02X",digest[k_j]);}

	static unsigned long var_temp;

	len = strlen(strhash1);

	__asm
	{
		
		lea eax, strhash1
		mov edx, [len]
		push edx
		push eax
		call bug_hash
		mov dword ptr ds:[var_temp], eax
	
		lea eax, strhash2
		push 40
		push eax
		call bug_hash
		xor dword ptr ds:[var_temp], eax
	}

	cout << "----------------------------------------------------------------------------" << endl;

	sprintf(buf,"%X",var_temp);
	len = strlen(buf);
	for (int k_l = 0; k_l < len; k_l++)
	{
		sprintf(hash_str + k_l*2,"%x",buf[k_l]);
	}
	cout << "HASH(m): " << hash_str << endl;

	EN_ECPoint P,Q,G,V;
	
	char sn[500];
	EN_BigInt a,b,p,k, e, r, s, k_random, t, n;

	t = EN_BigNew(0);

	r = EN_BigNew(0);
	s = EN_BigNew(0);


	e = EN_BigNew(0);
	k = EN_BigNew(0);

	p= EN_BigNew(0);
	s = EN_BigNew(0);
	n = EN_BigNew(0);

	a = EN_BigNew(1);
	b = EN_BigNew(0);


	k_random = EN_BigNew(0);
	
	EN_BigIn("2D313830383333303030D5",p);
	EN_BigIn("A8DAEE5055DC964069",n);
	EN_BigIn("A8DAEE48AB6631567A", k);

	EN_BigIn(hash_str, e);

	EN_ECurveInit(a,b,p);

	G = EN_ECPointNew(0,0);

	P = EN_ECPointNew(0,0);
	V = EN_ECPointNew(0,0);
	Q = EN_ECPointNew(0,0);
	EN_ECPointSet("25D927338ACA0DE2CA0B5B","15AE221680A466741CBAF5",G);

new_sign:
	EN_Rand(64,k_random);

	EN_ECPointMul(G,k_random,Q);
	EN_Mod(Q->x,n,r);

	EN_BigOut(r, sn);

	EN_Mul(r,k,t);
	EN_Add(t,e,t);

	EN_Inverse(k_random,n,k_random);
	EN_Mul(k_random,t,t);
	EN_Mod(t,n,s);


	ZeroMemory(buf,50);

	EN_BigOut10(r,buf);
	asciistr(buf,strhash1);
	
	if (strlen(strhash1) < 44){ goto new_sign; }
	strcat(strhash1,"0");

	ZeroMemory(buf,50);

	EN_BigOut10(s,buf);
	
	asciistr(buf,strhash2);
	if (strlen(strhash2) < 44){ goto new_sign; }
	strcat(strhash2,"0");

	EN_BigOut(r,buf);
	cout << "Signature: " ;
	cout << "r: " << buf;
	EN_BigOut(s,buf);
	cout << " s: " << buf << endl;


	EN_BigIn(strhash1,r);
	EN_BigIn(strhash2,s);


	cout << "----------------------------------------------------------------------------" << endl;
	cout << "Serial:" << endl;
	cout << "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - " << endl;

	EN_BigOut32(r,serial1);
	cout << serial1;
	EN_BigOut32(s,serial2);
	cout << "+" << serial2 << endl;
	cout << "----------------------------------------------------------------------------" << endl;


	EN_ECPointKill(P);
	EN_ECPointKill(Q);
	EN_ECPointKill(V);
	EN_ECPointKill(G);
	EN_ECurveKill();


	EN_BigKill(t);

	EN_BigKill(r);
	EN_BigKill(s);
	EN_BigKill(e);
	EN_BigKill(k);

	EN_BigKill(p);
	EN_BigKill(s);

	EN_BigKill(a);
	EN_BigKill(b);
	EN_BigKill(n);

	EN_BigKill(k_random);


	getch();
	return 0;
}
