Ok.
Another crypto keygenme from me.(I am loving cryptos :p)
Ya need some skill to get past this :)

I'll rate it at 4, coz 5 was a bit overrated for the other one I posted :)

Rules:
Keygen is the only soln to it.
 
GoalS :
Write a keygen & a well explained tut :)