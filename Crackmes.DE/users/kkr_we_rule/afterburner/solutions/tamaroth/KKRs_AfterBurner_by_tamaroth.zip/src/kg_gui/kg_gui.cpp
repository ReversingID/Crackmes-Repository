#pragma comment(lib, "miracl.lib")
// Windows Header Files:
#include <windows.h>

// windows internal
#include <winternl.h>

// C RunTime Header Files
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>
#include <time.h>
#include "crc32.h"
#include "resource.h"
#include "base32.h"
extern "C"{
	#include "md5.h"
	#include "miracl.h"
}

char charset[] = "QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890";
int base;
#define TAB_SIZE 1<<20
DWORD tab[TAB_SIZE];

INT_PTR CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	newSnProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK	newFeatProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK	newExpProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
HINSTANCE hInst;

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	hInst = hInstance;
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DIALOG), NULL, (DLGPROC)WndProc, NULL);
	return 0;
}

char *UInt2HexStr(unsigned int val){
	char *ps = new char[15];
	_ltoa(val, ps, 16);
	return ps;
}

unsigned char conv(unsigned char ch){
	unsigned char outt = ch + 0x30;
	if(outt > 0x39)
		outt += 7;
	return outt;
}

char *hexstr2ascii(unsigned char *instr, unsigned int inlen)
{
	char *outstr = new char[inlen*2+1];
	unsigned int c = 0;
	for(unsigned int i=0; i<inlen; i++){
		outstr[c++] = conv((instr[i]&0xF0)>>4);
		outstr[c++] = conv(instr[i]&0xF);
		outstr[c] = 0;
	}
	return outstr;
}

char *Hash(char *name)
{
	char tab1[] = "OFFiCE JESUSKenTheFurryEncryptoDysfunctionHackMutantChOoKiMA1201RaptorGrindStoneSaduff";
	char tab2[] = "XylitolXSP!D3RDONGKEYKKR_WE_RULE";
	char tab3[] = "AndrewlNumerniatCm!CyclopstamarothjBqpt^J";

	char *hash = new char[255];
	char numb[20];
	memset(hash, 0, 255);

	unsigned __int64 A,B,C,S1,S2,S3,v;
	unsigned int len = strlen(name);
	int c,a;

	a = 0;
	A = 0;
	B = 0;
	C = 0;
	unsigned __int64 tmp;

	while (len--)
	{
		tmp = ((name[a]%86) == 0	? 0 : tab1[name[a]%86-1]);
		A = A + tab1[a] + tmp;
		tmp = ((name[a]&0x1F) == 0	? 0 : tab2[(name[a]&0x1F)-1]);
		B = B + tab2[a] + tmp;
		tmp = ((name[a]%41) == 0	? 0 : tab3[name[a]%41-1]);
		C = C + tab3[a] + tmp;
		S1 = A+B+C;
		S2 = A^B^C;
		S3 = S1^S2;
		c = 0;
		for (int i=a; i>=0;i--)
		{
			A = ((tab3[c]&0x1F) == 0 ? 0 : tab2[(tab3[c]&0x1F)-1]);
			B = ((tab3[c]%86) == 0 ? 0 : tab1[tab3[c]%86-1]);
			tmp = ((tab1[c]&0x1F) == 0 ? 0 : tab2[(tab1[c]&0x1F)-1]);
			C = tmp == 0 ? 0 : tab3[tmp%41-1];
			c++;
		}
		v = A+B+C+S1+S2+S3;
		_ltoa((long)v,numb,10);
		strcat(hash,numb);
		a++;
	}
	char *p = hash;
	char tmpA[8];
	char ToHash[255];
	memset(ToHash, 0, 255);
	memset(tmpA, 0, 8);

	while(strlen(p))
	{
		A = 0;
		c = strlen(p);
		for(int i=0;i<4;i++)
		{
			A = A << 8;
			if(p-hash<255)
			{
				A |= *p++;
			}
		}
		switch(c)
		{
			default:
				tmpA[4] = A%0x55 + 0x21;
			case 3:
				tmpA[3] = (A/0x55)%0x55 + 0x21;
			case 2:
				tmpA[2] = (A/0x1C39)%0x55 + 0x21;
			case 1:
				tmpA[1] = (A/0x95EED)%0x55 + 0x21;
				tmpA[0] = (A/0x31C84B1)%0x55 + 0x21;
				break;				
		}
		strcat(ToHash, tmpA);
	}
	char tmpHash[255];
	sprintf(tmpHash, "%s%s%s%s", hash, "<~", ToHash, "~>");
	MD5_CTX ctx;
	unsigned char md5[16];
	MD5Init(&ctx);
	MD5Update(&ctx, (unsigned char *)tmpHash, strlen(tmpHash));
	MD5Final(md5, &ctx);
	char *md5s = hexstr2ascii(md5, 16);
	sprintf(tmpHash, "%s%s", hash, md5s);
	unsigned int crc = crc32b((unsigned char *)tmpHash, strlen(tmpHash));
	sprintf(tmpHash, "%s%08X", hash, crc);
	crc = crc32((unsigned char *)tmpHash, strlen(tmpHash));
	sprintf(hash, "%lu", crc);
	return hash;
}

char *GenerateSerial(char *namehash)
{
	char *alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567=";
	char *mapa = "0123456789";
	char rR[21];
	char *s1,*s2;
	big T, r, v, n, d, B, D, rr, z;
	miracl *mip;

	mip = mirsys(500, 10);
	T = mirvar(0);
	r = mirvar(0);
	v = mirvar(0);
	n = mirvar(0);
	d = mirvar(0);
	D = mirvar(0);
	B = mirvar(0);
	rr = mirvar(0);
	z = mirvar(0);
	mip->IOBASE = 10;

	cinstr(n,"586834795307410007");
	cinstr(v,"1724252705");
	cinstr(B,"174531982038655556");
	
	// generate r
	memset(rR, 0, 21);
	for(int i=0; i<20;i++)
	{
		rR[i] = mapa[i*rand()%10];
	}
	cinstr(r, rR);
	divide(r,n,n); // r must be smaller than n but greater than 0, chance of r mod n being equal 0, are very low, we're skipping it for the time being
	powmod(r,v,n,T);
	s2 = new char[255];
	memset(s2, 0, 255);
	cotstr(T, s2);
	strcat(s2, namehash);
	cinstr(d, s2);
	powmod(B, d, n, rr);
	mad(r,rr,z,n,n,D);
	s1 = new char[255];
	cotstr(D, s1);
	strcat(s1, "-");
	strcat(s1, s2);

	delete [] s2;

	char *serial = new char[strlen(s1)*2];
	memset(serial, 0, strlen(s1)*2);
	B32Encode(s1, strlen(s1),serial);

	return serial;
}

void DrawBorder(HWND hWnd, int IDENT, PAINTSTRUCT ps)
{
	POINT pt;
	RECT rc;

	GetWindowRect(GetDlgItem(hWnd, IDENT), &rc);
	pt.x = rc.left;
	pt.y = rc.top;
	ScreenToClient(hWnd, &pt);
	rc.left = pt.x;
	rc.top = pt.y;
	pt.x = rc.right;
	pt.y = rc.bottom;
	ScreenToClient(hWnd, &pt);
	rc.right = pt.x;
	rc.bottom = pt.y;
	Rectangle(ps.hdc, rc.left-1,rc.top-1,rc.right+1,rc.bottom+1);

	return;
}

INT_PTR CALLBACK WndProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	PAINTSTRUCT ps;
	HFONT hFont;
	DWORD lpnSize = 255;

	switch (message)
	{
	case WM_INITDIALOG:
		{
			srand((unsigned int)time(NULL));
			// set fonts
			hFont = CreateFont(12,0,0,0,FW_BOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY, FF_DONTCARE,TEXT("Verdana"));
			SendDlgItemMessage(hDlg, IDC_NAME, WM_SETFONT, (WPARAM)hFont, TRUE);
			SendDlgItemMessage(hDlg, IDC_SERIAL, WM_SETFONT, (WPARAM)hFont, TRUE);

			char *s1, *hash;
			hash = Hash("tamaroth");
			s1 = GenerateSerial(hash);
			SetDlgItemText(hDlg, IDC_NAME, "tamaroth");
			SetDlgItemText(hDlg, IDC_SERIAL, s1);
			delete [] s1;
			delete [] hash;

			return (INT_PTR)TRUE;
		}



	case WM_NCPAINT:
		BeginPaint(hDlg, &ps);
		DrawBorder(hDlg, IDC_NAME, ps);
		DrawBorder(hDlg, IDC_SERIAL, ps);
		EndPaint(hDlg, &ps);
		return (INT_PTR)0;

	case WM_COMMAND:
		if ((LOWORD(wParam) == IDC_BUTTON1) || (LOWORD(wParam) == IDOK))
		{
			char name[255];
			GetDlgItemText(hDlg, IDC_NAME, name, 255);
			char *hash, *serial;
			hash	= Hash(name);
			serial	= GenerateSerial(hash);
			SetDlgItemText(hDlg, IDC_SERIAL, serial);
			delete [] hash;
			delete [] serial;
			return (INT_PTR)TRUE;
		}
		if (LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}
