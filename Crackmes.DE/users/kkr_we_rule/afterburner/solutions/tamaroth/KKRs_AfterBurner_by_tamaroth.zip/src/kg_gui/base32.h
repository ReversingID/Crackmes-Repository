#ifndef _BASE32_H_
#define _BASE32_H_

#include <stdio.h>

bool B32Encode(char* inBuf, int inLen, char* outBuf);

#endif
