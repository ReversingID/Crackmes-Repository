///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	HEADERS & LIBRARYS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#define 			WIN32_LEAN_&_MEAN
#include 		<stdio.h>
#include 		<stdlib.h>
#include 		<math.h>
#include 		<time.h>
#include 		<windows.h>
#include 		<commctrl.h>
#include 		<commdlg.h>
#include			<windowsx.h>
#include 		<wincrypt.h>
#include			<objbase.h>


#include 		"Keygen.h"
#include 		"base32.h"

#define MUSIC

#ifdef MUSIC	
	#include <ufmod.h>
	#include "Tune.h"
	#pragma comment (lib,"Winmm.lib")
	#pragma comment (lib,"ufmod.lib")
#endif

#include <cryptohash.h>
#pragma comment (lib,"cryptohash.lib")


#include <miracl.h>
#pragma comment (lib,"miracl.lib")

#define VCRT
#ifdef VCRT
	#pragma comment (lib,"libcmt.lib")
#else
	#pragma comment (lib,"wcrt.lib")
#endif

#pragma comment(linker, "/NODEFAULTLIB")

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	DEFINITIONS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#define BP __asm{db 0xcc}
#pragma warn(disable: 2145)


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	FUNCTION PROTOTYPES
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int CALLBACK WinMain(HINSTANCE hInst,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nCmdShow);
INT_PTR CALLBACK MainDialogProc(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam);
void CreateKey(HWND hWnd);
LPSTR HashName(LPSTR lpszName);
LPSTR CreateHashString(LPSTR szIn);
LPSTR LeftStringCopy(LPSTR szIn,int len);
long ConvetBase2StringToInt(LPSTR lpszBase2String);
LPSTR ConvertBase256StringToBase2(LPSTR lpszBase256);
LPSTR strcat_dyn(char * s1,char*s2);
void IntToStr64(long long val,char* dest);
LPSTR Md5String(LPSTR lpszIn);
LPSTR CRC32String(LPSTR lpszIn);
LPSTR CRC32bString(LPSTR lpszIn);
DWORD CRC32b(int len,char* pData);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	GLOBAL VARIABLES
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
HINSTANCE hInstance;
HICON hIcon;
DWORD _iob;
LPSTR lpszProtection = 		"[ KKR_WE_RULE's AfterBurner - Keygen ]\n\n"
							"Protection:\n"
							"--------------------------------------------------\n"
							"Guillou-Quisquater Signature\n"
							"Custom Algos\n"
							"MD5 Hash\n"
							"CRC32 & CRC32b\n"
							"--------------------------------------------------\n";


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	CODE
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


int CALLBACK WinMain(HINSTANCE hInst,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nCmdShow)
{
	hInstance = hInst;
	srand(GetTickCount());
	DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_MAIN),NULL,MainDialogProc,0);
	ExitProcess(0);
	return FALSE;
}

INT_PTR CALLBACK MainDialogProc(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	char szUserName[200] 		= "";
	MSGBOXPARAMS mbp  		={0};
	DWORD nSize 				= sizeof(szUserName);

	switch(uMsg)
	{
		case WM_INITDIALOG:
		{
			#ifdef MUSIC
			uFMOD_PlaySong(Tune,hInstance,XM_MEMORY);
			#endif
			
			hIcon = LoadIcon(hInstance,MAKEINTRESOURCE(ID_ICON_MAIN));
			SendMessage(hWnd,WM_SETICON,0,(LPARAM)hIcon);
			GetUserName(szUserName,&nSize);
			SetDlgItemText(hWnd,IDC_EDIT_NAME,szUserName);
			CreateKey(hWnd);
			break;
		}

		case WM_CLOSE:
		{
			EndDialog(hWnd,0);
			break;
		}

		case WM_COMMAND:
		{
			switch(LOWORD(wParam))
			{
				case IDC_BUTTON_GENERATE:
				{
					CreateKey(hWnd);
					break;
				}

				case IDC_EDIT_NAME:
				{
					if (HIWORD(wParam) == EN_CHANGE)
						CreateKey(hWnd);
					break;
				}

				case IDC_BUTTON_ABOUT:
				{

					mbp.cbSize 			= sizeof(MSGBOXPARAMS);
					mbp.hwndOwner 	= hWnd;
					mbp.hInstance 		= hInstance;
					mbp.lpszText 		= lpszProtection;
					mbp.lpszCaption 	= "[ About ]";
					mbp.lpszIcon 		= MAKEINTRESOURCE(ID_ICON_MAIN);
					mbp.dwStyle 		= MB_USERICON;
					MessageBoxIndirect(&mbp);
					break;
				}
			
			}
			break;
		}
	
	}

	return FALSE;
}

void CreateKey(HWND hWnd)
{
	static char szName[50] = "";
	LPSTR szSerial;
	char szRl[500] = "";
	char szSL[500] = "";
	LPSTR szHashName;
	miracl* mip;
	big n,e,JA,a,k,r,l,s;

	int len;

	if (GetWindowTextLength(GetDlgItem(hWnd,IDC_EDIT_NAME)) > 32)
	{
		SetDlgItemText(hWnd,IDC_EDIT_SERIAL,"Name Too Long");
		return;
	}
	len = GetDlgItemText(hWnd,IDC_EDIT_NAME,szName,sizeof(szName));
	if (!len)
	{
		SetDlgItemText(hWnd,IDC_EDIT_SERIAL,"Enter name");
		return;
	}

	szHashName = HashName(szName);
	mip = mirsys(5000,10);

	n 	= mirvar(0);
	e	= mirvar(0);
	a 	= mirvar(0);
	JA 	= mirvar(0);
	k 	= mirvar(0);
	r 	= mirvar(0);
	s 	= mirvar(0);
	l 	= mirvar(0);

	mip->IOBASE = 10;

	cinstr(n,"586834795307410007");
	cinstr(e,"1724252705");
	cinstr(a,"174531982038655556");
	cinstr(JA,"2038805098");
	lgconv(rand(),k);

	powmod(k,e,n,r);	//r = k^e mod n
	cotstr(r,szRl);
	strcat(szRl,szHashName);
	cinstr(l,szRl);
	powmod(a,l,n,s);
	mad(k,s,s,n,n,s);

	cotstr(s,szSL);
	strcat(szSL,"-");
	cotstr(l,&szSL[strlen(szSL)]);

	szSerial = base32_encode(szSL,strlen(szSL));
	SetDlgItemText(hWnd,IDC_EDIT_SERIAL,szSerial);
	free(szSerial);
	free(szHashName);
	mirkill(n);
	mirkill(e);
	mirkill(a);
	mirkill(JA);
	mirkill(k);
	mirkill(r);
	mirkill(s);
	mirkill(l);
	mirexit();
	return;
}

LPSTR HashName(LPSTR lpszName)
{
	
	static LPSTR szOfficeJesus 	= "OFFiCE JESUSKenTheFurryEncryptoDysfunctionHackMutantChOoKiMA1201RaptorGrindStoneSaduff";
	static LPSTR szXylitol 		= "XylitolXSP!D3RDONGKEYKKR_WE_RULE";
	static LPSTR szAndrewl		= "AndrewlNumerniatCm!CyclopstamarothjBqpt^J";
	static char szTemp[50];
	static char szHashNum[1024];
	int i,h,j,len;
	long long var_3_4, var_5_6, var_7_8, var_9_10;
	long long var_11_12, var_13_14;
	LPSTR szHashString,szTmp,szMD5,szCRC32b,szCRC32;


	memset(&szTemp,0,sizeof(szTemp));
	memset(&szHashNum,0,sizeof(szHashNum));

	var_3_4 = 0;
	var_5_6 = 0;
	var_7_8 = 0;

	len = strlen(lpszName);
	
	for( i = 0; i < len; i++)
	{
	
	
		var_3_4 += szOfficeJesus[ (lpszName[i] % 0x56) -1 ] + szOfficeJesus[i];	

		var_5_6 += szXylitol[ (lpszName[i] & 0x1F) -1 ] + szXylitol[i];

		var_7_8 += szAndrewl[ (lpszName[i] % 0x29) -1 ] + szAndrewl[i];

		var_9_10 = var_3_4 + var_5_6 + var_7_8;

		var_11_12 = ((var_3_4 ^ var_5_6) ^ var_7_8);

		var_13_14 = var_9_10 ^ var_11_12;

		j = 0;
		h = i;

		do
		{
			var_3_4 = szXylitol[ ((szAndrewl[j] & 0x1F) - 1) ];
			var_5_6 = szOfficeJesus[ ( ( (szAndrewl[j]) % 0x56) -1 )];
			var_7_8 = szAndrewl[  ((szXylitol[ ( (szOfficeJesus[j] & 0x1F) - 1) ] % 0x29) - 1) ];
			j++;
	
		}while(h != j-1);
	
		IntToStr64(	var_3_4 + var_5_6 + var_7_8 + var_9_10 +var_11_12 + var_13_14,
					szTemp);
		
		strcat(szHashNum,szTemp);

	}
	
	szHashString = CreateHashString(szHashNum);
	szTmp = strcat_dyn(szHashNum,szHashString);
	szMD5 = Md5String(szTmp);
	free(szTmp);

	szTmp = strcat_dyn(szHashNum,szMD5);
	szCRC32b = CRC32bString(szTmp);
	free(szTmp);

	szTmp = strcat_dyn(szHashNum,szCRC32b);
	szCRC32 = CRC32String(szTmp);

	free(szHashString);
	free(szMD5);
	free(szTmp);

	return szCRC32;

}

LPSTR CreateHashString(LPSTR szIn)
{
	LPSTR lpszTmp = 0,lpszBinary = 0,lpszSubString = 0,lpszOut;

	int i,len,esi,alloc_len;
	long long var_7_8;

	len = strlen(szIn);
	if(len == 0) return 0;

	alloc_len 		= ((len / 4) * 20);
	lpszSubString 	= malloc(alloc_len);
	lpszOut 			= malloc(alloc_len);
	memset(lpszSubString,0,alloc_len);
	memset(lpszOut,0,alloc_len);

	if (len <=3) esi = len+1;
		
	if (len >= 4) esi = 5;

	for (i = 0; strlen(&szIn[i])  > 0; i+=4)
	{
		switch(len)
		{
			case 1:
			{
				lpszBinary = ConvertBase256StringToBase2(&szIn[i]);
				strcat(lpszBinary,"000000000000000000000000");
				var_7_8 = ConvetBase2StringToInt(lpszBinary);
				break;
			}

			case 2:
			{
				lpszBinary = ConvertBase256StringToBase2(&szIn[i]);
				strcat(lpszBinary,"0000000000000000");
				var_7_8 = ConvetBase2StringToInt(lpszBinary);
				break;
			}

			case 3:
			{
				lpszBinary = ConvertBase256StringToBase2(&szIn[i]);
				strcat(lpszBinary,"00000000");
				var_7_8 = ConvetBase2StringToInt(lpszBinary);
				break;	
			}
		}
		
		lpszTmp = LeftStringCopy(&szIn[i],4);
		lpszBinary = ConvertBase256StringToBase2(lpszTmp);
		var_7_8 = ConvetBase2StringToInt(lpszBinary);

		if(lpszBinary) free(lpszBinary);
		if(lpszTmp) free(lpszTmp);

		lpszTmp = malloc(sizeof(long long));

		*(long long*) lpszTmp = 0;

		lpszTmp[0] = ((var_7_8 % 0x55) + 0x21);
		lpszTmp[1] = (((var_7_8 / 0x55) % 0x55) + 0x21);
		lpszTmp[2] = (((var_7_8 / 0x1C39) % 0x55)+ 0x21);
		lpszTmp[3] = (((var_7_8 / 0x95EED) % 0x55)+ 0x21);
		lpszTmp[4] = (((var_7_8 / 0x31C84B1) % 0x55)+ 0x21);
		_strrev(lpszTmp);
		strcat(lpszSubString,lpszTmp);
		free(lpszTmp);
		
	}
	if(esi < 5)
	{
		lpszSubString[5] = 0;
	}

	sprintf(lpszOut,"<~%s~>",lpszSubString);
	free(lpszSubString);
	return lpszOut;

}

LPSTR LeftStringCopy(LPSTR szIn,int len)
{
	LPSTR szOut = malloc(len *4);
	memcpy(szOut,szIn,len);
	szOut[len] = 0;
	return szOut;
}

long ConvetBase2StringToInt(LPSTR lpszBase2String)
{
	miracl* mip = mirsys(5000,16);
	char buff[50]  = "";
	big x = mirvar(0);

	mip->IOBASE = 2;
	cinstr(x,lpszBase2String);

	mip->IOBASE = 256;
	cotstr(x,buff);
	mirkill(x);
	mirexit();

	return _bswap(*(long *)buff);
}

LPSTR ConvertBase256StringToBase2(LPSTR lpszBase256)
{
	miracl* mip = mirsys(5000,16);
	LPSTR szOut;
	big x;
	x  = mirvar(0);

	bytes_to_big(strlen(lpszBase256),lpszBase256,x);
	mip->IOBASE = 2;
	szOut = malloc((x->len * 32) *50);
	cotstr(x,szOut);
	mirkill(x);
	mirexit();
	return szOut;

}

LPSTR strcat_dyn(char * s1,char*s2)
{
	int len = strlen(s1) + strlen(s2) + 10;
	LPSTR szOut = malloc(len);
	memset(szOut,0,len);
	strcat(szOut,s1);
	strcat(szOut,s2);

	return szOut;
}

void IntToStr64(long long val,char* dest)
{
	sprintf(dest,"%.llu",val);
	return;
}

LPSTR Md5String(LPSTR lpszIn)
{
	static char szMd5[((MD5_DIGESTSIZE * 2)+1)];
	int len = strlen(lpszIn);

	MD5Init();
	MD5Update(lpszIn,len);
	HexEncode(MD5Final(),MD5_DIGESTSIZE,szMd5);
	return szMd5;
}

LPSTR CRC32String(LPSTR lpszIn)
{
	static char szCRC32[9];

	_ultoa(CRC32(lpszIn,strlen(lpszIn),0),szCRC32,10);

	return _strupr(szCRC32);
}

LPSTR CRC32bString(LPSTR lpszIn)
{
	static char szCRC32b[9];

	_itoa(CRC32b(strlen(lpszIn),lpszIn),szCRC32b,16);

	return _strupr(szCRC32b);
}




