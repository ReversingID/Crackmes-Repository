#ifndef _b32_h_
#define _b32_h_

int base32_encode_length(int rawLength);
int base32_decode_length(int base32Length);
void base32_encode_into(const void *_buffer, unsigned int bufLen, char *base32Buffer);
char *base32_encode(const void *buf, unsigned int len);

#endif

