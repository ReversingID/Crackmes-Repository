/* (PD) 2001 The Bitzi Corporation
 * Please see file COPYING or http://bitzi.com/publicdomain 
 * for more info.
 *
 * $Id: base32.c,v 1.5 2006/03/18 16:28:50 mhe Exp $
 *
 * Modified by Martin Hedenfalk 2005 for use in ShakesPeer.
 */

#include <assert.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>

#define BASE32_LOOKUP_MAX 43
static char *base32Chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";


int base32_encode_length(int rawLength)
{
    return ((rawLength * 8) / 5) + ((rawLength % 5) != 0) + 1;
}



void base32_encode_into(const void *_buffer, unsigned int bufLen, char *base32Buffer)
{
    unsigned int i, index;
    unsigned char word;
    const unsigned char *buffer = _buffer;

    for(i = 0, index = 0; i < bufLen;)
    {
        /* Is the current word going to span a byte boundary? */
        if (index > 3)
        {
            word = (buffer[i] & (0xFF >> index));
            index = (index + 5) % 8;
            word <<= index;
            if (i < bufLen - 1)
                word |= buffer[i + 1] >> (8 - index);

            i++;
        }
        else
        {
            word = (buffer[i] >> (8 - (index + 5))) & 0x1F;
            index = (index + 5) % 8;
            if (index == 0)
                i++;
        }

   //     assert(word < 32);
        *(base32Buffer++) = (char)base32Chars[word];
    }

    *base32Buffer = 0;
}

char *base32_encode(const void *buf, unsigned int len)
{
    char *tmp = malloc(base32_encode_length(len));
    base32_encode_into(buf, len, tmp);
    return tmp;
}


