Time for my AfterBurner ..YEAH!!

Okie.. Rules asways : Keygen is the only soln.
No Patching, bruting etc :)
Level : 4.

This one will make you think .. I hope :p

Anyway.. Have a gr8 time reversing :)

Regards
KKR