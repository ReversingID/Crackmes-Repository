Solution to KKR_WE_RULE's 'Kgm#1'
=========
----------

##<i class="icon-info"></i>About this crackme

URL | http://crackmes.de/users/kkr_we_rule/kgm1/
-------- | ---
Author | KKR_WE_RULE
Published    | 20\. Jan, 2016
Platform | Windows
Language     | Assembler
Difficulty | 2 - Needs a little brain (or luck)
Protection | Modular Arithmetic


----------

##<i class="icon-wrench"></i>Tools used
- OllyDbg v2.01
-  Visual Studio 2015
- stackedit.io (for writing this tutorial)
- brain.exe

----------

##<i class="icon-search"></i>First analysis
We open up the program and it looks like an usual Keygenme: We have to enter a username and a serial. And if we enter some random data we most likely get the badboy, so let's start debugging ;)

----------

##<i class="icon-bug"></i>Debugging

>**Since this is a Level 2 crackme I won't explain everything 100% in detail, I'll point out important parts, but leave the rest for you as a homework ;)**

We open up the program in Olly and since it was written in ASM the code is pretty understandable. Right at the beginning we see a call to *DialogBoxParamA*. We step over the *PUSH 00401028* at 0040100E and then right-click on that value on the stack and select *'Follow in Disassembler'*. We are now in the *DialogProc* callback function. Look a bit around and you'll find some interesting CALLs some lines below:

```
0040109C PUSH 101 ; /MaxCount = 257.
004010A1 PUSH OFFSET 00403000 ; |String
004010A6 PUSH 3E9 ; |ItemID = 1001.
004010AB PUSH DWORD PTR SS:[Arg1] ; |hDialog => [Arg1]
004010AE CALL <JMP.&user32.GetDlgItemTextA> ; \USER32.GetDlgItemTextA, get username
004010B3 CMP EAX, 0
004010B6 JLE SHORT 00401115
004010B8 LEA EDX, [403200]
004010BE MOV DWORD PTR DS:[EDX], EAX
004010C0 PUSH 101 ; /MaxCount = 257.
004010C5 PUSH OFFSET 00403100 ; |String
004010CA PUSH 3EA ; |ItemID = 1002.
004010CF PUSH DWORD PTR SS:[Arg1] ; |hDialog => [Arg1]
004010D2 CALL <JMP.&user32.GetDlgItemTextA> ; \USER32.GetDlgItemTextA, serial
004010D7 CMP EAX, 0
004010DA JLE SHORT 0040112D
004010DC LEA EDX, [strlen(serial)]
004010E2 MOV DWORD PTR DS:[EDX], EAX
004010E4 CALL 0040115D ; [Keygenme#1.0040115D
004010E9 CALL 004011BA ; [Keygenme#1.004011BA
004010EE CALL 0040124C ; [Keygenme#1.0040124C
004010F3 CALL 004012FD ; [Keygenme#1.004012FD
004010F8 CMP EAX, 1
004010FB JNE SHORT 00401145
004010FD PUSH 0 ; /Type = MB_OK|MB_DEFBUTTON1|MB_APPLMODAL
004010FF PUSH OFFSET 00403458 ; |Caption = "Excellent Work!"
00401104 PUSH OFFSET 00403444 ; |Text = "Serial is accepted!"
00401109 PUSH DWORD PTR SS:[Arg1] ; |hOwner => [Arg1]
0040110C CALL <JMP.&user32.MessageBoxA> ; \USER32.MessageBoxA
```
We can see seven CALLs here. The first two get the username and the serial. Then there are 4 (yet unknown) CALLs which seem to set EAX and if it is set to 1 we get to the Goodboy. So let's dig deeper and analyze that calls.
The first one is pretty easy to understand and so I won't go into details here. It just calculates three values. The first value is the sum of all chars of the username, or mathematically spoken:

$$
uName\_sum = \sum_{\substack{0\le i\lt len(username)}}u_i
$$

The second value is the sum of all chars, each multiplied with their position (1-based) and XORed with the position:

$$
uName\_hash = \sum_{\substack{0\le i\lt len(username)}}(u_i * (i+1))\oplus(i+1)
$$

The third value is simply the sum of those two values:

$$
uName\_sh = uName\_sum + uName\_hash
$$

Now let's step through the second call at 004010E9. It's very easy to see, that this function takes the serial and tries to convert it to a hexadecimal value. Whenever it finds a hyphen, it stores the value and the process is repeated for the remaining chars. Note that the values are stored using a 32Bit register, but since the pointer to the memory location is only incremented by 2, the upper 16Bit are overwritten with the lower 16Bit of the next value, but that does not have to bother us as we find out if we go on reversing. Also we need exactly three values, but we'll also see this later.

Time to dive into the third CALL at 004010EE. The code is pretty straightforward and you should find out, that what the program does is that it takes the first value calculated in the last CALL, multiplies it by 15 and then calculates that value modulus 499. Then it takes the second value, multiplies it by 18 and then calculates that value modulus 499. Finally it takes the third value, multiplies it by 21 and again it calculates that value modulus 499. The three resulting values are added and once again modulus 499 of that sum is calculated. There are two more of these calculations,  so we end up with three new values:

$$
mod1 = ((value1 * 15) \% 499 + (value2 * 18) \% 499 + (value3 * 21) \% 499) \% 499\\
mod2 = ((value1 * 14) \% 499 + (value2 * 17) \% 499 + (value3 * 20) \% 499) \% 499\\
mod3 = ((value1 * 16) \% 499 + (value2 * 18) \% 499 + (value3 * 19) \% 499) \% 499
$$

So, let's analyse the last CALL at 004010F3. Again, this is pretty easy, the program just calculates the following value:

$$
test\_value = (uName\_sum) \% 499 \oplus mod1 + (uName\_hash) \% 499 \oplus mod2 + (uName\_sh) \% 499 \oplus mod3
$$

And if that value is zero, EAX is set to 1 and therefore our serial is accepted. That means that uName_sum has to be equal to mod1, uName_hash has to be equal to mod2 and uName_sh has to be equal to mod3. But how do we get there?
First let's see what we have so far. We have three equations that look like the following:

$$
(uName\_sum) \% 499 = ((value1 * 15) \% 499 + (value2 * 18) \% 499 + (value3 * 21) \% 499) \% 499\\
(uName\_hash) \% 499 = ((value1 * 14) \% 499 + (value2 * 17) \% 499 + (value3 * 20) \% 499) \% 499\\
(uName\_sh) \% 499 = ((value1 * 16) \% 499 + (value2 * 18) \% 499 + (value3 * 19) \% 499) \% 499
$$

First we can simplify this a bit by removing the inner modulus operations and then we beautify it a bit:

$$
uName\_sum \equiv value1 * 15  + value2 * 18  + value3 * 21 \mod 499\\
uName\_hash \equiv value1 * 14  + value2 * 17  + value3 * 20 \mod 499\\
uName\_sh \equiv value1 * 16  + value2 * 18  + value3 * 19 \mod 499
$$

But how do we calculate that? Well, we know the following rules:

$$
\text{If } a \equiv b \mod m\\
\text{then } a+c \equiv b+c \mod m\\
\text{and } a-c \equiv b-c \mod m\\
\text{and } a*c \equiv b*c \mod m\\
\text{and } -a \equiv m-a \mod m\\
$$
But watch out, the following rule is wrong (in general):
$$
\text{If } a*c \equiv b*c \mod m\\
\text{then } a \equiv b \mod m
$$

With that knowledge we can solve the three equations like any other equation. Remember that uName_sh is the same as uName_sum + uName_hash.

$$
39*uName\_hash + 465*uName\_sum \equiv 496*value1 \mod 499\\
356*uName\_hash + 278*uName\_sum \equiv 45*value2 \mod 499\\
21*uName\_hash + 482*uName\_sum \equiv 496*value3 \mod 499
$$

Now we only have to check the values 0 to 498 for value1, value2 and value3 and we have a valid serial ;)
Last question is: Is there always a solution and thus a valid serial?
The answer is simple: yes, there is always a solution ;) Why is that so? $$a*x \equiv b \mod m$$ has a solution if b is dividable by gcd(a, m)[^gcd] and since 499 is a prime number, gcd(a, 499) is always 1.

[^gcd]: [Greatest common divisor](https://en.wikipedia.org/wiki/Greatest_common_divisor)

----------

##<i class="icon-edit"></i>Sample serials

Username  | Serial
---------| ------
iSSoGoo | 087-151-1AF
KKR_WE_RULE    | 112-04C-0E9
crackmes.de | 09E-1B2-0A1
anonymous | 169-0A5-181


----------

##<i class="icon-thumbs-up"></i>Summary

That was a fun Keygenme! Hadn't worked with modular arithmetic for a while, but luckily the internet could answer all my questions :D

(c) iSSoGoo, 2016


### Footnotes

