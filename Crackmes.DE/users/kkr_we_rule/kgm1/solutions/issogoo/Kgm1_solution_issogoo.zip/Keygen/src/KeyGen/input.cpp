// includes
#include <Windows.h>
#include "resource.h"
#include "input.h"
#include "serial.h"


// This functions dispatches all the messages sent to the window
BOOL CALLBACK DialogProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam){
	switch (message) {

		case WM_INITDIALOG: {

			SendMessage(GetDlgItem(hWnd, IDC_EDIT_USERNAME), EM_SETLIMITTEXT, 100, 0);

			SetFocus(GetDlgItem(hWnd, IDC_EDIT_USERNAME));

			HICON hIcon = LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON));

			if (hIcon) {
				SendMessage(hWnd, WM_SETICON, ICON_BIG, (LPARAM)hIcon);
				SendMessage(hWnd, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
				DestroyIcon(hIcon);
			}
						
			break;
		}

		case WM_COMMAND: {
			switch (HIWORD(wParam)) {
				case EN_CHANGE: {
					switch (LOWORD(wParam)) {
						case IDC_EDIT_USERNAME: {
							int bufferSize = 100;
							LPSTR username = new TCHAR[bufferSize+2];
							GetDlgItemText(hWnd, IDC_EDIT_USERNAME, username, bufferSize);
							SetDlgItemText( hWnd, IDC_EDIT_SERIAL, getSerial(username).c_str() );
							break;
						}

						default: {
							return DefWindowProc(hWnd, message, wParam, lParam);
						}
					}

					break;
				}

				default: {
					return DefWindowProc(hWnd, message, wParam, lParam);
				}
			}

			break;
		}

		case WM_LBUTTONDOWN:{
			SendMessage(hWnd, WM_NCLBUTTONDOWN, HTCAPTION, lParam);
			break;
		}

		default:{
			return DefWindowProc(hWnd, message, wParam, lParam);
		}
	}

	return FALSE;
}