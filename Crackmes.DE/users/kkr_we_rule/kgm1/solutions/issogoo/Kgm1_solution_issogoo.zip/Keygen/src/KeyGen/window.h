#pragma once

// prototypes
ATOM WINAPI registerMainWindowClass(HINSTANCE hInstance);