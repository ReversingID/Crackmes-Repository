#pragma once

// includes
#include <string>
#include <cstdint>

// prototypes
std::string getSerial(LPSTR username);