// includes
#include <Windows.h>
#include <sstream>
#include <iomanip>
#include "serial.h"

std::string getSerial(const LPSTR username) {

	std::stringstream stream;
	std::string serialString = "";
	uint32_t uName_sum = 0;
	uint32_t uName_hash = 0;
	uint32_t part1 = 0;
	uint32_t part2 = 0;
	uint32_t part3 = 0;
	uint32_t reminder1 = 0;
	uint32_t reminder2 = 0;
	uint32_t reminder3 = 0;

	// Calculate uName_sum and uName_hash
	for (int c = 0, len = strlen(username); c < len; c++) {
		uName_sum += username[c];
		uName_hash += (username[c] * (c + 1)) ^ (c + 1);
	}

	reminder1 = ((39 * uName_hash) % 499 + (465 * uName_sum) % 499) % 499;
	reminder2 = ((356 * uName_hash) % 499 + (278 * uName_sum) % 499) % 499;
	reminder3 = ((21 * uName_hash) % 499 + (482 * uName_sum) % 499) % 499;

	// Calculate part1, part2 and part3
	for (int t = 0; t < 499; t++) {
		if ( (496 * t) % 499 == reminder1) {
			part1 = t;
		}
		if ((45 * t) % 499 == reminder2) {
			part2 = t;
		}
		if ((496 * t) % 499 == reminder3) {
			part3 = t;
		}
	}

	stream	<< std::uppercase << std::hex << std::setw(3) << std::setfill('0') << part1 << '-'
			<< std::uppercase << std::hex << std::setw(3) << std::setfill('0') << part2 << '-'
			<< std::uppercase << std::hex << std::setw(3) << std::setfill('0') << part3;
	serialString = stream.str();

	return serialString;
}