Hello guys.. I had 45 mins to kill, and I was going down memory lane visiting this website.
I decided to write something, again! :D

But due to shortage of time, dont expect much from the challenge, as it's simple, no crypto in this! 

Big guys won't even like the kgm, but yeah, the little guys starting reversing will have fun I think :)

Goal is to write a keygen. Patching is forbidden as always!

Merry Christmas and a Happy New Year to all who mane this site :)

have Fun!

KKR//2015