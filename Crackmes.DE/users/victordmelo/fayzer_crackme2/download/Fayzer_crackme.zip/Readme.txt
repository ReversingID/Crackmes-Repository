A little keygenme writen in C. Compiled with dev-c++.

crack and Write a keygen.

Don't forget the source!!