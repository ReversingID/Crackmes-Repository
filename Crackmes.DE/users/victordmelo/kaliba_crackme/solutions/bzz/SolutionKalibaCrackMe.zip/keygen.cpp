#include <windows.h>
#include <stdio.h>
#include <ctime>

int random_int()
{
	int res = rand() % 10;
	return res;
}

char random_char()
{
	char* ch = "abcdefghijklmnopqrstuvwxyz"; // This is MY Range you can edit it ( NO NUMERICS ALLOWED ) 
	int res = rand() % (strlen(ch)+1);
	char c = ch[res];
	return c;
}
void make_key()
{
	DWORD		c_1		= random_int();
	char		c_2		= random_char();
	DWORD		c_3		= random_int();
	char		c_4		= random_char();
	DWORD		c_5		= random_int();
	c_3 = 2*(0xA*c_1+0x7D)-0x14+0x58;
	c_5 = c_3+2*(2*c_1+0xFD)+3;
	printf("%d%c%d%c%d\n",c_1,c_2,c_3,c_4,c_5);
}

int main(char* args[])
{
	SetConsoleTitleA("KeyGen by B@zz!");
	srand(time(0));
	make_key();
	getchar();
}
