#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>

typedef unsigned long DWORD;

int main()
{
	DWORD	input0, input2, input4;
	DWORD	tmp0, tmp1;

	srand((unsigned int)time(NULL));
		
	// Ranmly generate input0
	input0 = (DWORD)rand();
	
	// Input2 and input4 can be generated from input0
	tmp0 = (input0 * 10 + 0x7D) * 2 + 1 - 0x15 + 0x58;
	tmp1 = (input0 * 2 + 0xFD) * 2 + 1 + tmp0 + 2;

	input2 = tmp0;
	input4 = tmp1;

	printf("Serial: %d-%d-%d\n", input0, input2, input4);

	return 0;
}