﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication80
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            genSerial();
                    
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            genSerial();
        }

        private int j = 0;
        private void genSerial()
        {
            j++;
                int num = j;
                int num4 = num * 2 + 50;
                num4 += 22;
                num4++;
                num4 -= 12;
                num4 *= 3;
                int num5 = num4 + 22;
                num5 += 45;
                num5 *= 3;
                num5--;

                int num2 = num4;
                int num3 = num5;

                if (num2 == num4 && num3 == num5)
                {
                    string serial = string.Format("{0}-{1}-{2}", num, num2, num3);
                    textBox1.Text = serial;
                }
                else if(num >= int.MaxValue)
                {
                    j = 0;
                }
                else
                {
                    genSerial();
                }
            }
        }
    }
