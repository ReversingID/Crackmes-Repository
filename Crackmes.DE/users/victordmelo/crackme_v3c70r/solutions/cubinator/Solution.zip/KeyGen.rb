def printNext
	n1 = rand(1000)
	n2 = 6 * n1 + 183
	n3 = 18 * n1 + 749
	puts [n1, n2, n3].join("-")
end

while true
	system "cls"
	printNext
	gets
end
