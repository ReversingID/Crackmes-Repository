#include <windows.h>
#include <stdio.h>

/* GLOBAL VARIABLES */
HANDLE hMainThread = NULL;
HANDLE hStdOut = NULL;

HMODULE hMSVCRT = NULL;
DWORD dwItoaAddr = NULL;

DWORD dwOldProtect = NULL;
DWORD dwCb = NULL;

BYTE HookBytes[6];
BYTE OriginalBytes[6];
char ConsoleBuf[128];

DWORD dwAddrOfSerial = NULL; // For storing the address of the serial (duh)

void PrintDbg(char * Text)
{
    hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    sprintf(ConsoleBuf, "%s", Text);
    WriteConsoleA(hStdOut, ConsoleBuf, strlen(ConsoleBuf), &dwCb, NULL);
}

DWORD WINAPI GrabSerialProc ( LPVOID lpParam )
{
    hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    Sleep(30);
    sprintf(ConsoleBuf, "The serial is %s ", (char*)dwAddrOfSerial);
    WriteConsoleA(hStdOut, ConsoleBuf, strlen(ConsoleBuf), &dwCb, NULL);
    return 0;
}

void PlaceHook()
{
    memcpy((LPVOID)dwItoaAddr, (LPVOID)HookBytes, 6);
}

void RestoreHook()
{
    memcpy((LPVOID)dwItoaAddr, (LPVOID)OriginalBytes, 6);
}

char * hkItoa( int value, char *string, int radix )
{
    RestoreHook();
    char * Ret = itoa(value, string, radix );
    PlaceHook();

    PrintDbg("Itoa was called!\n");

    dwAddrOfSerial = (DWORD)string;
    CreateThread(NULL, NULL, GrabSerialProc, NULL, NULL, NULL);
    return Ret;
}

bool HookItoa()
{
    hMSVCRT = GetModuleHandleA("MSVCRT.DLL");
    if(hMSVCRT == NULL)
    {
        PrintDbg("Could not get handle for MSVCRT.DLL!\n");
        return false;
    }

    dwItoaAddr = (DWORD)GetProcAddress(hMSVCRT, "_itoa");
    if(dwItoaAddr == NULL)
    {
        PrintDbg("Could not find _itoa!\n");
        return false;
    }


    if(!VirtualProtect((LPVOID)dwItoaAddr, 6, PAGE_EXECUTE_READWRITE, &dwOldProtect))
    {
        PrintDbg("VP failed!\n");
        return false;
    }

    memcpy((LPVOID)OriginalBytes, (LPVOID)dwItoaAddr, 6);   // Copy the original 5 bytes of itoa
    HookBytes[0] = 0x68;	// PUSH 
    HookBytes[5] = 0xC3;
    *(DWORD*)&HookBytes[1] = (DWORD)hkItoa;

    PlaceHook();
    PrintDbg("Hook placed!\n");

    return true;
}

DWORD WINAPI SerialRipperProc( LPVOID lpParam )
{
    PrintDbg("KEYGEN INJECTED!\n");
    HookItoa();
    return 0;
}


BOOL APIENTRY DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
    switch (fdwReason)
    {
        case DLL_PROCESS_ATTACH:
            hMainThread = CreateThread(NULL, NULL, SerialRipperProc, NULL, NULL, NULL);
            break;

        case DLL_PROCESS_DETACH:
            TerminateThread(hMainThread, 0);
            break;
    }
    return TRUE; // succesful
}
