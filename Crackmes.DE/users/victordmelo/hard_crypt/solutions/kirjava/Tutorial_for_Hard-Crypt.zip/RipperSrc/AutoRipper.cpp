#include <windows.h>
#include <stdio.h>

typedef LONG (NTAPI *NtSuspendProcess)(IN HANDLE ProcessHandle);
typedef LONG (NTAPI *NtResumeProcess)(IN HANDLE ProcessHandle);

// Global vars
char DllName[] = "SerialRipper.dll";

HANDLE hHCProcess;

PROCESS_INFORMATION pi;
STARTUPINFO si;

LPVOID RemoteMem = NULL;

int main(int argc, char * argv[])
{
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_GREEN | FOREGROUND_RED | FOREGROUND_INTENSITY);
    printf("AutoRipper for Hard-Crypt\nBy Kirjava\n");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_GREEN | FOREGROUND_RED | FOREGROUND_BLUE | FOREGROUND_INTENSITY);

    NtSuspendProcess pfnNtSuspendProcess = (NtSuspendProcess)GetProcAddress(
        GetModuleHandle("ntdll.dll"), "NtSuspendProcess");

    NtResumeProcess pfnNtResumeProcess = (NtResumeProcess)GetProcAddress(
        GetModuleHandle("ntdll.dll"), "NtResumeProcess");

    if(pfnNtSuspendProcess == NULL)
    {
        printf("Could not get NtSuspendProcess!\n");
        return -1;
    }

    ZeroMemory(&pi, sizeof(PROCESS_INFORMATION));
    ZeroMemory(&si, sizeof(STARTUPINFO));
    si.cb = sizeof(STARTUPINFO);
    si.dwFlags = STARTF_USESTDHANDLES;
    si.hStdInput = GetStdHandle(STD_INPUT_HANDLE);
    si.hStdOutput = GetStdHandle(STD_OUTPUT_HANDLE);

    CreateProcess(NULL, "Hard-Crypt.exe", NULL, NULL, TRUE, 0, NULL, NULL, &si, &pi);

    if(pi.hProcess == NULL)
    {
        printf("Could not start crackme!\n");
        return -1;
    }

    pfnNtSuspendProcess(pi.hProcess);

    LPVOID LoadLibAddr = (LPVOID)GetProcAddress(GetModuleHandleA("kernel32.dll"), "LoadLibraryA");
    RemoteMem = VirtualAllocEx(pi.hProcess, NULL, strlen(DllName), MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    WriteProcessMemory(pi.hProcess, RemoteMem, DllName, strlen(DllName), NULL);
    if(CreateRemoteThread(pi.hProcess, NULL, NULL, (LPTHREAD_START_ROUTINE)LoadLibAddr, RemoteMem, 0, NULL)!=NULL)
        printf("Started crackme and created remote thread, resuming process.\n");

    pfnNtResumeProcess(pi.hProcess);
    return 0;
}
