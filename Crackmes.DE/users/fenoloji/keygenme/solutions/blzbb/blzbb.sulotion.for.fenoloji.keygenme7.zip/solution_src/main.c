#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cryptohash.h"

#pragma comment(lib, "cryptohash.lib")

#define MD5_SIZE    16

int main(int argc, char **argv)
{
	char md5[MD5_SIZE*2+2] = {0};
	char *cipher = "84F2FED8ABC55EB4029976C0B9096BB7";
	char txt[200] = "\x7A\x6F\x72\x75\x20\x79\x61\x70\x61\x72\xFD" \
	            "\x6D\x20\x69\x6D\x6B\x61\x6E\x73\xFD\x7A\x20" \
	            "\x62\x69\x72\x61\x7A\x20\x7A\x61\x6D\x61\x6E" \
	            "\x20\x61\x6C\xFD\x72\x20\xF0\xF1\xF2\xF3\xF4" \
	            "\xF5\xF6\xF7";
	
	
	for ( unsigned i = 1000000; i <= 9999999; i++ )
	{
		_itoa(i, (txt + 47), 10);
		MD5Init();
        MD5Update( (BYTE *) txt, 54 );
        HexEncode(MD5Final(), MD5_SIZE, (BYTE *) md5);
		if ( strcmp(md5, cipher) == 0 )
		{
			printf("%s\n", (txt + 47));
			break;
		}
	}

	return 0;
}
