
#undef UNICODE
#undef _UNICODE
#include <windows.h>
#include <stdio.h>
#include "resource.h"
#include "main.h"

#define NEW_THREAD
#define APP_NAME	"Fenoloji4 bruteforcer"

// prototypes
void Init();
BOOL CALLBACK DialogProc (HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
void StartForcing (HWND hDlg);
DWORD WINAPI ManagerThread (PVOID pParam);
DWORD WINAPI ComputingThread (PVOID pParam);
void ShowResults (HWND hDlg);

// variables
APP_STATE	g_AppState = APP_STATE_INIT;
bool	g_bCancel;
BRUTE_RESULT	g_Results[8];
DWORD g_dwButtonIDs[8][33];
const DWORD g_dwRequestedHash[8] = {0x71B2256A, 0xF96F6916, 0x5F414E56, 0xC90E0F92, 0x571C4956, 0x8460FC6A, 0x3B82492, 0xD9264FEE};



//--------------------------------
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	Init();
	DialogBox (hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, DialogProc);
	return (0);
}

//--------------------------------
void Init()
{
	HANDLE hProcess = GetCurrentProcess();
	if (hProcess)
		SetPriorityClass (hProcess, IDLE_PRIORITY_CLASS);

	DWORD i, j;
	for (i=0; i<8; i++)
	{
		switch (i)
		{
		case 0:							// Group1: buttonID = 10 - 41 (32)
			for (j=0; j<32; j++)
				g_dwButtonIDs[0][j] = 10 + j;
			g_dwButtonIDs[0][32] = 0xF5;
			break;
		case 1:							// Group2: buttonID = 42 - 73 (32)
			for (j=0; j<32; j++)
				g_dwButtonIDs[1][j] = 42 + j;
			g_dwButtonIDs[1][32] = 0xF5;
			break;
		case 2:							// Group3: buttonID = 74 - 89 (16)... first 16 values are used
			for (j=0; j<32; j++)
				g_dwButtonIDs[2][j] = 74 + j;
			g_dwButtonIDs[2][32] = 0xF5;
			break;
		case 3:							// Group4: buttonID = 1065 - 1034 (32)
			for (j=0; j<32; j++)
				g_dwButtonIDs[3][j] = 1065 - j;
			g_dwButtonIDs[3][32] = 0xF5;
			break;
		case 4:							// Group5: buttonID = 1097 - 1066 (32)
			for (j=0; j<32; j++)
				g_dwButtonIDs[4][j] = 1097 - j;
			g_dwButtonIDs[4][32] = 0xF5;
			break;
		case 5:							// Group6: buttonID = 1129 - 1098 (32)
			for (j=0; j<32; j++)
				g_dwButtonIDs[5][j] = 1129 - j;
			g_dwButtonIDs[5][32] = 0xF5;
			break;
		case 6:							// Group7: buttonID = 1161 - 1130 (32)
			for (j=0; j<32; j++)
				g_dwButtonIDs[6][j] = 1161 - j;
			g_dwButtonIDs[6][32] = 0xF5;
			break;
		case 7:							// Group8: buttonID = 1193 - 1162 (32)
			for (j=0; j<32; j++)
				g_dwButtonIDs[7][j] = 1193 - j;
			g_dwButtonIDs[7][32] = 0xF5;
			break;
		}
	}
}

//--------------------------------
BOOL CALLBACK DialogProc (HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_INITDIALOG:
		return TRUE;

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDC_BUTTON_START:			// button Click
			switch (g_AppState)
			{
			case APP_STATE_INIT: StartForcing (hwndDlg); break;
			case APP_STATE_COMPUTING: g_bCancel = true; break;
			case APP_STATE_DONE: ShowResults (hwndDlg); break;
			}
			return TRUE;

		case IDCANCEL:
			g_bCancel = true;
			EndDialog (hwndDlg, 0);
			return TRUE;
		}
		break;
	}
	return FALSE;
}

//--------------------------------
void StartForcing (HWND hDlg)
{
	g_bCancel = false;

	SetDlgItemText (hDlg, IDC_BUTTON_START, "Stop");
	g_AppState = APP_STATE_COMPUTING;

#ifdef NEW_THREAD
	DWORD dwThreadID;
	HANDLE hThread = CreateThread (NULL, 0, ComputingThread, hDlg, 0, &dwThreadID);
	if (hThread == NULL)
	{
		MessageBox (hDlg, "CreateThread function error", APP_NAME, 0);
		SetDlgItemText (hDlg, IDC_BUTTON_START, "Start");
		g_AppState = APP_STATE_INIT;
		return;
	}
#else
	ComputingThread (hDlg);
#endif

}

//--------------------------------
DWORD WINAPI ComputingThread (PVOID pParam)
{
#ifndef _DEBUG
	__try{
#endif

	HANDLE hThread = GetCurrentThread();
	if (hThread)
		SetThreadPriority (hThread, THREAD_PRIORITY_BELOW_NORMAL);

	HWND hDlg = (HWND)pParam;

	DWORD dwSum, dwResult, dwPattern, dwBuf, i;

	//////////////////////////////////////////////////////////////////////////
	for (DWORD dwGroup=0; dwGroup<8; dwGroup++)	// through all 8 groups
	{
		if (g_Results[dwGroup].bCracked)		// if already cracked then move to next one
			continue;

		for (dwPattern=0; ; dwPattern++)		// through all 32-bit combinations
		{
			dwSum = 0;

			for (i=0; i<32; i++)
				if (dwPattern & (1 << i))				// if (button(i).checked)
				{
					if (dwGroup == 7)
						dwResult = g_dwButtonIDs[dwGroup][i] + 1;		// last group algo is slightly different
					else
						dwResult = (g_dwButtonIDs[dwGroup][i] * 2) + 1;
					dwBuf = g_dwButtonIDs[dwGroup][i+1] ^ 0xAF;
					dwResult += dwBuf + 0xDEEDEED;
					dwResult *= (i+1) * 4;
					dwResult *= dwBuf;
					dwResult -= 0x14;
					dwSum += dwResult;
				}
				dwSum *= 3;
				dwSum += 0x0E0E;

				if (dwSum == g_dwRequestedHash[dwGroup])	// founded right combination
				{
					g_Results[dwGroup].dwCombination = dwPattern;
					g_Results[dwGroup].bCracked = TRUE;
					char szBuf[32] = {0};
					sprintf_s (szBuf, sizeof(szBuf), "cracked group %u/8", dwGroup+1);
					SetDlgItemText (hDlg, IDC_STATIC_INFO, szBuf);
					break;
				}

				if (dwGroup == 2 && dwPattern == 0x00010000)
					break;	// combination was not found
				else if (dwPattern == 0xFFFFFFFF)
					break;	// combination was not found

				if (g_bCancel)		// Cancel button clicked
				{
					g_bCancel = false;
					g_AppState = APP_STATE_INIT;
					SetDlgItemText (hDlg, IDC_BUTTON_START, "Start");
					return (0);
				}
		}
	}

	// computing is done
	g_AppState = APP_STATE_DONE;
	SetDlgItemText (hDlg, IDC_BUTTON_START, "Show results");
	SetForegroundWindow (hDlg);
	MessageBox (hDlg, "Computing done", APP_NAME, 0);

	return (0);

#ifndef _DEBUG
	}__except(EXCEPTION_EXECUTE_HANDLER){
		MessageBox (NULL, "Unspecified error occured", APP_NAME, 0);
	}
#endif

	return (0);
}

//--------------------------------
void ShowResults (HWND hDlg)
{
	DWORD i, j;
	HWND hWnd = FindWindow (NULL, "fenoloji crackme 4 ");
	if (hWnd == NULL)
	{
		MessageBox (hDlg, "Please start fenoloji_crackme.exe first", APP_NAME, 0);
		return;
	}

	// uncheck all checkboxes
	for (i=0; i<8; i++)
		for (j=0; j<32; j++)
			CheckDlgButton (hWnd, g_dwButtonIDs[i][j], 0);

	// check proper checkboxes
	for (i=0; i<8; i++)
		for (j=0; j<32; j++)
			if (g_Results[i].dwCombination & (1 << j))
				CheckDlgButton (hWnd, g_dwButtonIDs[i][j], 1);
}
