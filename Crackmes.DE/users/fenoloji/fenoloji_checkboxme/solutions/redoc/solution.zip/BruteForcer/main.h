

typedef enum _APP_STATE {
	APP_STATE_INIT = 0,
	APP_STATE_COMPUTING = 1,
	APP_STATE_DONE = 2
}APP_STATE;

struct BRUTE_RESULT {
	BOOL	bCracked;			// true if done
	DWORD dwCombination;		// as 32-bit pattern
};