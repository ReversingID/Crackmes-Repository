-------------------------------------------------------------------
Compiler and OS notes
-------------------------------------------------------------------

The keygen is written in g++, so you can compile it in linux/unix
(if you installed the library referred to below).
Get a compiled version of the keygen for window here, if you want:
http://www25.brinkster.com/nukezore/keygen.rar
It was compiled with g++ under the MinGW32 environment
(http://www.mingw.org/). I couldn't include it into the package due
the file size limit of 100k on crackmes.de.


-------------------------------------------------------------------
Libraries
-------------------------------------------------------------------
The keygen makes use of NTL (Number Theory Library)
(http://www.shoup.net/ntl/). Btw, it's a very useful lib.


-------------------------------------------------------------------
Program syntax
-------------------------------------------------------------------
Start the keygen this way:
keygen <11-digit-decimal-number>
Example: keygen 12345678901

<11-digit-decimal-number> stands for the first part of the serial.
The rest of the serial will be calculated from this input value and
will be displayed.


-------------------------------------------------------------------
Notes
-------------------------------------------------------------------
Haldir came up with a really interesting crackme.
It shows that math can be fun.. well math is always fun, but this
crackme is a nice application of some theoretical knowledge.
And it wasn't that hard to solve it after studying the documents
Haldir publicated on [RET] (http://www.reteam.org).

I'm looking forward to more, Haldir..

--nucleon