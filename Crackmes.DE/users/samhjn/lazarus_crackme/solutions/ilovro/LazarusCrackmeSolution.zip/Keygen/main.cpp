﻿/*
    Made by [TPoDT]iLovro
    You're free to use anything you like!
    I hope you'll learn some useful stuff!
    Don't forget to link with minifmod.lib and winmm.lib
*/

#include <windows.h> //WIN32 definitions, etc.
#include <commctrl.h> //Common controls
#include <cstdlib> //Rand, srand
#include <ctime> //clock()
#include <string> //string
#include "resource.h" //Resource file
#include "serialRoutine.h" //Our key generation routine
#include "music.h" //Our music and FMOD functions

FMUSIC_MODULE *song = NULL; //Module for our song

BOOL CALLBACK DialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch(uMsg)
    {
        case WM_INITDIALOG:
        {
            SetDlgItemTextA(hwndDlg, IDC_EDIT_SERIAL, "...press generate...");
			SendMessage(hwndDlg, WM_SETICON, ICON_BIG, (LPARAM)LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON)));
            song = FMUSIC_LoadSong(NULL, NULL);
            FMUSIC_PlaySong(song);
        }
        return TRUE;

        case WM_CLOSE:
        {
            EndDialog(hwndDlg, 0);
        }
        return TRUE;

        case WM_COMMAND:
        {
            switch (LOWORD(wParam))
            {
                case ID_GENERATE:
                {
                    SetDlgItemTextA(hwndDlg, IDC_EDIT_SERIAL, generateKey().c_str());
                }
                return TRUE;
            }
        }
        return TRUE;
    }
    return FALSE;
}

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
    InitCommonControls();
    FSOUND_File_SetCallbacks(memopen, memclose, memread, memseek, memtell);
	DialogBoxParam(hInstance, MAKEINTRESOURCE(DLG_MAIN), NULL, DialogProc, NULL);
	MessageBox(NULL, "Thanks for checking me out!\n\nMade by [TPoDT]iLovro for all good people.", "Thanks", MB_ICONINFORMATION);
	FMUSIC_FreeSong(song);
    return 0;
}
