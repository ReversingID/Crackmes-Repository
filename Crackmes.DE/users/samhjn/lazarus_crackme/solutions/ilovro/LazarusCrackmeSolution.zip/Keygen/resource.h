#include <windows.h>

// ID of Main Dialog
#define DLG_MAIN 101

// ID of Icon
#define IDI_ICON 102

// ID of Button Controls
#define IDC_EDIT_SERIAL 1001
#define ID_GENERATE 1002
