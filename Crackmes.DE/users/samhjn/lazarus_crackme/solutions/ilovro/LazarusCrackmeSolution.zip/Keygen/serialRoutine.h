struct PAIR
{
    int x, y;
};

struct COMMAND
{
    PAIR src, dest;
};

int matrix[3][3] =
{{2, 0, 2},
 {0, 0, 0},
 {1, 0, 1}};

void resetMatrix()
{
    matrix[0][0] = 2;
    matrix[0][1] = 0;
    matrix[0][2] = 2;
    matrix[1][0] = 0;
    matrix[1][1] = 0;
    matrix[1][2] = 0;
    matrix[2][0] = 1;
    matrix[2][1] = 0;
    matrix[2][2] = 1;
}

PAIR generateSrcPair()
{
    PAIR result = {rand()%3, rand()%3};

    while (true)
    {
        if (matrix[result.x][result.y] > 0)
            break;
        else
        {
            result.x = rand()%3;
            result.y = rand()%3;
        }
    }

    return result;
}

PAIR generateDestPair()
{
    PAIR result = {rand()%3, rand()%3};

    while (true)
    {
        if (matrix[result.x][result.y] == 0)
            break;
        else
        {
            result.x = rand()%3;
            result.y = rand()%3;
        }
    }

    return result;
}

COMMAND generateCommand()
{
    COMMAND result;

    result.src = generateSrcPair();
    result.dest = generateDestPair();

    return result;
}

std::string convertCommand(COMMAND c)
{
    std::string result = "";

    result += c.src.x + '1';
    result += c.src.y + 'A';
    result += c.dest.x + '1';
    result += c.dest.y + 'A';

    return result;
}

void executeCommand(COMMAND c)
{
    matrix[c.dest.x][c.dest.y] = matrix[c.src.x][c.src.y];
    matrix[c.src.x][c.src.y] = 0;
}

bool solved()
{
    if (matrix[0][0] == 1 && matrix[0][1] == 0 && matrix[0][2] == 1 && matrix[2][0] == 2 && matrix[2][1] == 0 && matrix[2][2] == 2)
        return true;
    else
        return false;
}

std::string generateKey()
{
    srand(clock());

    std::string key = "";
    COMMAND cs[16];

    while (true)
    {
        for (int i = 0; i < 16; i++)
        {
            COMMAND c = generateCommand();
            cs[i] = c;
            executeCommand(c);
        }

        if (solved())
            break;
        else
            resetMatrix();
    }

    for (int i = 0; i < 16; i++)
    {
        key += convertCommand(cs[i]);
    }

    return key;
}
