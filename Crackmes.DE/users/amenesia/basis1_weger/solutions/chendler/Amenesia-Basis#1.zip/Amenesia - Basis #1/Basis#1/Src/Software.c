#include <string.h>
#include <windows.h>
#include "Software.h"
#include "protection.c"           

HINSTANCE g_hInst;
HWND g_hwnd;

char lpName[80];
char license[257];

BOOL CALLBACK DialogProc( HWND hwndDlg, UINT uMsg, WPARAM wParam,LPARAM lParam)
{
        g_hwnd=hwndDlg;
	switch(uMsg){
	
	 case WM_INITDIALOG:
		{
			return TRUE;
			break;
		}

	case WM_DESTROY:
		{
			PostQuitMessage(0);
			break;
		}

	case WM_CLOSE:
		{
			EndDialog(hwndDlg, 0);
			return TRUE;
		}
	
	case WM_COMMAND:
		{
			switch(LOWORD(wParam)) {
				case ID_FERMER: 
				{
					EndDialog(hwndDlg, 0);
					return TRUE;
					break;
				}

				case IDKEY:
				{
					GetDlgItemText(hwndDlg,IDC_NAME,lpName,80);
					GetDlgItemText(hwndDlg,IDC_LICENSE,license,257);
					if (CheckLicense(lpName, license) == 0)
					     MessageBox(g_hwnd, " Your key is valid. "," .: Registration :. ", 0); 
					else
					     MessageBox(g_hwnd, " Your key isn't valid. "," .: Registration :. ", 0); 
					return TRUE;
					break;
				}
				

			}
		}
  
	default: 
	break;

	}

  return FALSE; 
} 

  


int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd )
{
	
	g_hInst = hInstance;
	
	DialogBox(hInstance,MAKEINTRESOURCE(IDD_KEYGEN),NULL,DialogProc);				
	return(0);
}



