#include <windows.h>
#include "resource.h"
#include "miracl.h"

HINSTANCE hInst;
int len;
unsigned char Name[0x50],Serial_1_char[0x50],Serial_2_char[0x50];
unsigned char Serial_sign[0x50]="1";
unsigned char  hash_Name[21]={0};
big name_big,Serial_2,p2;
big const_3,const_1;
big Serial_1,Serial_1_part,Serail_1_part1,Serail_1_part2,M1y1,M2y2,M;



BOOL CALLBACK DlgProc (HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
miracl *mip=mirsys(300,16);
sha sh;
int i;
switch (uMsg){
   case WM_CLOSE:
		EndDialog(hWnd,0);
		break;

   case WM_COMMAND:
		switch (LOWORD(wParam))
		{

		case IDC_Generate:
		mip->IOBASE=16;
		len=GetDlgItemText(hWnd, IDC_Name, Name, 0x50);
//hash(Name)=hash_Name
		shs_init(&sh);
		for (i=0;Name[i]!=0;i++) shs_process(&sh,Name[i]);
		shs_hash(&sh,hash_Name);

//Serial_2=F(Name)
		name_big=mirvar(0);
		const_3=mirvar(3);
		bytes_to_big(20,hash_Name,name_big);
		Serial_2=mirvar(0);
		copy(name_big,Serial_2);
		p2=mirvar(0);
		cinstr(p2,"FFFFFFFE000000006FAFED9C3353F08D");
		powmod(Serial_2,const_3,p2,Serial_2);
		otstr(Serial_2,Serial_2_char);  
		SetDlgItemText(hWnd,IDC_Serial_2,Serial_2_char);

//Calculate Serial_1 based on Chinese Remainder Theorem	
		Serial_1=mirvar(0);
		Serial_1_part=mirvar(0);
		M1y1=mirvar(0);
		M2y2=mirvar(0);
		M=mirvar(0);
		Serail_1_part1=mirvar(0);
		Serail_1_part2=mirvar(0);
		instr(Serial_1_part,"651A925155D44B8E2E6A519091E783CA");
		instr(M1y1,"4AD208A64C18C4E4D683008A81C1CD7A49B7A8A51E4329CD660353104A44D8A7");
		instr(M2y2,"B52DF755B3E73B1F992CED10D23247F34FA0760EE1BCD6322A4CBF53826736B3");
		instr(M,"FFFFFFFC000000046FAFED9B53F4156D99581EB3FFFFFFFF90501263CCAC0F59");
		multiply(M1y1,Serial_1_part,Serail_1_part1);
		multiply(M2y2,Serial_2,Serail_1_part2);
		add(Serail_1_part1,Serail_1_part2,Serial_1);
		const_1=mirvar(1);
		powmod(Serial_1,const_1,M,Serial_1);
		otstr(Serial_1,Serial_1_char);
		lstrcat(Serial_sign,Serial_1_char);
		SetDlgItemText(hWnd,IDC_Serial_1,Serial_sign);
		Serial_sign[1]=0;

		mirkill(name_big);
		mirkill(Serial_2);
		mirkill(p2);
		mirkill(Serial_1);
		mirkill(Serial_1_part);
		mirkill(M1y1);
		mirkill(M2y2);
		mirkill(M);
		mirkill(Serail_1_part1);
		mirkill(Serail_1_part2);
		mirkill(const_1);
		mirkill(const_3);
		mirexit();

		break;


		case IDC_Exit:
        EndDialog(hWnd,0);
		break;
		}
		break;
	case WM_INITDIALOG:
//		SendMessage(hWnd,WM_SETICON,ICON_BIG,(LPARAM) LoadIcon(hInst,MAKEINTRESOURCE(ICO_MAIN)));
        SetDlgItemText(hWnd,IDC_Name,"UserName should >= 4!");
		break;
}
return 0;
}

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,PSTR szCmdLine, int iCmdShow)
{

	hInst=hInstance;
	DialogBoxParam(hInstance,MAKEINTRESOURCE(DLG_MAIN),0,(DLGPROC)DlgProc,0);
	return 0;
}