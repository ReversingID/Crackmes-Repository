                          ==== KeygenME #3 ====

Hello again. I haven't put anything out in a while, so I decided to make
this little thing. Unlike #2, I tried to make this one as succint as 
possible, so you won't have much to reverse.

The goal is to produce a key generator for arbitrary names, and a write-up.

Have fun,
Dcoder