KeygenME #2 by Dcoder
---------------------

In this crackme, your mission will be to produce a working key generator 
that will make the crackme go "Good!".

Only keygen is a valid solution!