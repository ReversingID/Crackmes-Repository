
import sys
from mathExt import *
from serpent import *
from snefru import *
import random

def genKey(name):
	h=snefru(name)
	snefruRes=h.finalize()
	
	paillierDec=(snefruRes[3])|(snefruRes[2]<<(32*1))|(snefruRes[1]<<(32*2))|(snefruRes[0]<<(32*3))
	p=0xA7A519EED3D56F9A1663AA807CA84D5152379B5AF31BE5CED5BF09C72A283B19
	n=p**2
	paillierEnc=(pow(p+1,paillierDec,n)*pow(random.randrange(n),p,n))%n
	
	serpentEnc=bytearray(0x40)
	serpentDec=bytearray(0x40)
	for i in reversed(range(0x40)):
		serpentEnc[i]=paillierEnc&0xFF
		paillierEnc>>=8
	c=serpent(b'\xD5\xA8\x23\x18\x6C\xE3\xA6\x19\xFF\x35\x72\xFB\x7A\x78\x43\x23')
	c.blockEncrypt(serpentEnc,0,serpentDec,0)
	c.blockEncrypt(serpentEnc,0x10,serpentDec,0x10)
	c.blockEncrypt(serpentEnc,0x20,serpentDec,0x20)
	c.blockEncrypt(serpentEnc,0x30,serpentDec,0x30)
	
	rsaEnc=0
	for i in range(0x40):
		rsaEnc<<=8
		rsaEnc|=serpentDec[i]
	if rsaEnc>=n:
		return genKey(name)
	
	d=0x33bad48c12e689c0498df34b9c3b0e407a2b54ff2c5a3e686880b738cd4c3da8b6da6075de038f8da58514975a74d78a4c4c837a6102dd1e15bc69432dad6003
	n=0xa50ae80cb59d8e7b29302af422250b87db8a48f96b0bc10e4069bce73a5e68bfe242e6642a40541d7399eb4dfc98cd91810209b505776cb283110b1728eefaf3
	rsaDec=pow(rsaEnc,d,n)
	return '{:x}'.format(rsaDec)

def paillierDecrypt(bignum_A7_19,bignum_A7_24,bignum_6D,key):
	a=modInvEuclid(bignum_A7_19,bignum_A7_24)
	b=pow((pow(key,a,bignum_A7_19)),bignum_A7_19,bignum_6D)
	ret=((((key%bignum_6D)*(modInvEuclid(b,bignum_6D)))%bignum_6D)-1)//bignum_A7_19
	return ret


class test():
	def paillierDecrypt():
		encRes=0x3A2269A4378AC99F7C68EB2071421731C3A7670F21B52B49C4C8284DE8AC9D642A999431F70CC0E0777ED1259F526B465C80A251222D96B04B70362067B7FCF6
		bignum_A7_19=0xA7A519EED3D56F9A1663AA807CA84D5152379B5AF31BE5CED5BF09C72A283B19
		bignum_A7_24=0xA7A519EED3D56F9A1663AA807CA84D4FAAD3F6892CE9A27DAF1F825DE7A92E24
		bignum_6D=0x6DC8D25008DE0CEB25C807B96CDAEE275328E3F2B2E8ABA75AB0BC9D760B236C7F912DD36E19A6186BA4DA610647D46E680C9B0AC3774C852EF2DC94B9748871
		encRes=(pow(bignum_A7_19+1,0x12345,bignum_6D)*pow(random.randrange(bignum_6D),bignum_A7_19,bignum_6D))%bignum_6D
		print(hex(paillierDecrypt(bignum_A7_19,bignum_A7_24,bignum_6D,encRes)))
	
	def paillierDecryptInner():
		key=0x3A2269A4378AC99F7C68EB2071421731C3A7670F21B52B49C4C8284DE8AC9D642A999431F70CC0E0777ED1259F526B465C80A251222D96B04B70362067B7FCF6
		bignum_A7_19=0xA7A519EED3D56F9A1663AA807CA84D5152379B5AF31BE5CED5BF09C72A283B19
		bignum_A7_24=0xA7A519EED3D56F9A1663AA807CA84D4FAAD3F6892CE9A27DAF1F825DE7A92E24
		bignum_6D=0x6DC8D25008DE0CEB25C807B96CDAEE275328E3F2B2E8ABA75AB0BC9D760B236C7F912DD36E19A6186BA4DA610647D46E680C9B0AC3774C852EF2DC94B9748871
		
		a=modInvEuclid(bignum_A7_19,bignum_A7_24)
		b=pow((pow(key,a,bignum_A7_19)),bignum_A7_19,bignum_6D)
		
		#the left part actually divides bignum_A7_19
		
		p,q,m=bignum_A7_19,bignum_A7_24,bignum_6D
		print(((((key%m)*(modInvEuclid(b,m)))%m)-1)%p)
		print(((((key%p)*(modInvEuclid(pow((pow(key,a,p)),p,p),p)))%p)-1)%p)
		print(pow(key,a*p-1,p))
		
		ret=((((key%bignum_6D)*(modInvEuclid(b,bignum_6D)))%bignum_6D)-1)//bignum_A7_19
		print(hex(ret))
	
	def serpent():
		c=serpent(b'\xD5\xA8\x23\x18\x6C\xE3\xA6\x19\xFF\x35\x72\xFB\x7A\x78\x43\x23')
		res=bytearray(b'\x8A\x0F\x9F\x17\x76\xEB\x71\x93\x37\x06\x74\x03\xF7\xA3\x03\x89')
		c.blockDecrypt(res,0,res,0)
		print(res)
	
	def snefru():
		h=snefru(b'simonzack')
		#E9 E1 31 F5 E5 F7 A0 6D C7 05 DD E0 F1 55 F6 AA
		print(hex(h.finalize()[0]))

def main():
	name=input('name: ').encode()
	print(genKey(name))

if __name__=='__main__':
	main()
