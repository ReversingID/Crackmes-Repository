#include <windows.h>
#include "resource.h"

//Crypto++ stuff
#include <CryptoPP/modes.h>
#include <CryptoPP/serpent.h>
#pragma comment(lib, "cryptlib.lib")
using namespace CryptoPP;

#define MAX_NAME_LEN	0x32
#define MAX_SERIAL_LEN	0x32

char cName[MAX_NAME_LEN];
char cSerial[MAX_SERIAL_LEN];

const char cAlphabet[] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 
							'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T',
							'U', 'V', 'W', 'X', 'Y', 'Z', '2', '3', '4', 
							'5', '6', '7', '8', '9'};

int B256ToB32(BYTE *bData, int nLen, char *cRes)
{
	int nResLen, i, bPos, bTaken, bPrev;
	char bByte;

	nResLen = i = bPos = 0;
	while(nLen > i)
	{
		bByte = bTaken = bPrev = 0;
		while(bTaken != 5)
		{
			bByte |= ((bData[i] >> bPos) << bTaken) & 0x1F;
			bTaken += 8 - bPos;
			if(bTaken > 5)
				bTaken = 5;
			bPos += bTaken - bPrev;
			if(bPos >= 8)
			{
				i++;
				bPos = 0;
			}
			bPrev = bTaken;
		}

		cRes[nResLen] = cAlphabet[bByte];
		nResLen++;
	}
	
	//padd result to be aligned
	while(nResLen % 8 != 0)
	{
		cRes[nResLen] = cAlphabet[0];	
		nResLen++;
	}

	cRes[nResLen] = 0;
	return nResLen;
}


void FormatSerial(BYTE *bPart1, BYTE *bPart2, char *cRes)
{
	int nLen = B256ToB32(bPart1, 2, cRes);	//first part is always 2 bytes long
	cRes[nLen] = '-';
	B256ToB32(bPart2, 16, cRes + nLen + 1);	//need to convert whole block here
}

void Gen(HWND hDlg)
{
	BYTE bSeed = 0x11;
	BYTE p1[16], p2[16], cCypherText[16];
	int i;
	int nNLen = GetDlgItemText(hDlg, IDC_NAME, cName, MAX_NAME_LEN);

	if(nNLen <= 2)	//no/too short name entered :(
	{
		SetDlgItemText(hDlg, IDC_SERIAL, "Please enter you name!");
		return;
	}

	memset(p1, 0, sizeof(p1));
	memset(p2, 0, sizeof(p2));
	memset(cCypherText, 0, sizeof(cCypherText));

	//hardcoded constant
	p1[0] = 0x12; p1[1] = 0x34;

	//second part is name encrypted some custom algo and serpent
	for(i = 0; i < 16; i++, bSeed += 0x11)
		cCypherText[i] = cName[i % nNLen] ^ bSeed;

	ECB_Mode<Serpent>::Decryption SDec(p1, sizeof(p1));	//first part is our key
	SDec.ProcessData(p2, cCypherText, sizeof(cCypherText));

	//first part is 0x12 0x34 xored with first two name chars in base 32
	p1[0] ^= cName[0];
	p1[1] ^= cName[1];

	//convert results to base 32
	FormatSerial(p1, p2, cSerial);
	SetDlgItemText(hDlg, IDC_SERIAL, cSerial);
}

int CALLBACK DlgFunc(HWND hDlg, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	switch(Msg)
	{
		case WM_INITDIALOG:
			break;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case IDC_BEXIT:
					EndDialog(hDlg, 0);
					break;
				case IDC_BABOUT:
					MessageBox(hDlg, "HAZE KeygenMe v2.0 Keygen by Knight\n"
						"Greets to all my friends\n\n"
						"2006 - 07 - 17", "tuobA", MB_ICONINFORMATION);
					break;
				case IDC_BGEN:
					Gen(hDlg);
					break;
			}
			break;
		case WM_CLOSE:
			EndDialog(hDlg, 0);
			break;
		default:
			return FALSE;
	}
	return TRUE;
}

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrev, LPSTR cCmd, int nShow)
{
	
	DialogBox(hInst, MAKEINTRESOURCE(IDD_DIALOG1), NULL, DlgFunc);
	return 0;
}