
MultiCrackMe v1.2 by basdog22
Coded in: Borland C++ Builder 5
Level:Easy-Medium
AntiSICE tricks: Nothing
Packed with: Not packed

Description:
`````````````````
Hello,
Well this is my first C++ crackme and i can say it is very good.
What you have to do is to find 4 serials and enter them in the correct order.If you do this right the #2 Serial
textbox will become active and it will ask you for the last serial.
I had a couple of more tricks in my mind but i didn't want my first C++ crackme so difficult.I will include them 
in my next one ;=)

Rules:
`````````
Well i would suggest that if you are able to find the serials there is no reason to patch,but if you want you can patch it.


Sollutions:
```````````````
Send me your sollutions and a copy of the exe to:    basdog22@yahoo.com

Have fun...