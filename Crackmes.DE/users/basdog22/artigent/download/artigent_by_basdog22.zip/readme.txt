Hello again,
Make a keygen for this one
and submit it to crackmes.de

Info:
~~~~~~
Language: VB6
Native code
Size:20 kb


Contact:
basdog22@yahoo.com
http://kickme.to/reversers
http://www.geocities.com/krypticl
