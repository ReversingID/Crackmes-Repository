Hello

This is my effort of creating something in Assembly.
Your aim is to code a keygen for Pako and a short tutorial
explaining what this app does with your inputs.

SeeYa
basdog22