solution.txt           solution explanation

disassembly.txt        disassembly of key verification routine (with helpful stuff renamed)

KeyVal2.map            IDA map file (has some identified CryptoPP stuff)

keygen.cpp             keygen source
keygen.exe             keygen executable

scripts.rar            igorsk's IDA scripts

readme.txt             this file

