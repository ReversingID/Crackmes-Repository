This is my first crackme (Keygenme), written in C++.

- find the solution
- make a keygen
- and submit a tutorial

tested on WinXP SP1 but should also work on other windows os.

Regards,

mucki