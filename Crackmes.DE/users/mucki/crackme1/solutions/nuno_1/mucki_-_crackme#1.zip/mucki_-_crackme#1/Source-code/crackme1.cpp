//////////////////////////////////////////
// Crackme : mucki_-_crackme#1
// reversed by : Nuno_1
// Skills : 2 (from a scale of 1 to 10)
// Used applications : IDA / ollydbg
//////////////////////////////////////////

#include "stdio.h"
#include "stdlib.h"
#include "math.h"
#include "string.h"

int returnPowNumber(unsigned int serialNumber)
{
    double digitNumber;
    unsigned int secondNumber = 1;
    double tempNumber = 0;
    unsigned int total = 0;
    for ( double i=10;i>0;i-- )
    {
        digitNumber = pow( (double) 10.0f ,i );

        tempNumber = serialNumber / digitNumber;

        if ( (int)tempNumber != 0 )
        {
            unsigned int tempNumber2 = 7;
            if ( secondNumber == 7 )
            {
                tempNumber2 = 3;

            }
            if ( secondNumber == 3 )
            {
                tempNumber2 = 1;
            }

            secondNumber = tempNumber2;
        }

        total += (unsigned int) tempNumber *secondNumber;

    }

    return total % 10;
}   
int main(int argc,char *argv[])
{
    char nameStr[1024];
    int finalResult     = 0;
    unsigned int tempSum = 0;
    unsigned int i;


    printf("Please enter the name of to generate a key for :");

    scanf("%s",&nameStr);

    for ( i=0;i<strlen(nameStr);i++ )
    {
        nameStr[i] = toupper(nameStr[i]);
    }

    for ( i=0;i<strlen(nameStr);i++ )
    {
        if ( nameStr[i] == 0x20 ) //SPACE
            continue;

        tempSum = nameStr[i];
        tempSum *= 0x157a;
        tempSum --;
        finalResult += tempSum;
    }

    finalResult *= 10;

    finalResult += returnPowNumber( finalResult );

    printf ("The Serial is %d\n",finalResult);

    return 0;
}