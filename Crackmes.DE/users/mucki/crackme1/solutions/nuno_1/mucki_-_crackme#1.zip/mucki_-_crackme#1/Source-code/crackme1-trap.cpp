//////////////////////////////////////////
// Crackme : mucki_-_crackme#1 trap
// reversed by : Nuno_1
// Skills : 2 (from a scale of 1 to 10)
// Used applications : w32dasm / ollydbg
//////////////////////////////////////////

#include "stdio.h"
#include "stdlib.h"
#include "math.h"
#include "string.h"

int main(int argc,char *argv[])
{
    char nameStr[1024];
    int currentSumPart1 = -8;
    unsigned int currentSumPart2 = 0x3c6;
    unsigned int currentSumPart3 = 0;
    int finalResult     = 0;
    unsigned int tempSum = 0;
    unsigned int i;


    printf("Please enter the name of the user to generate a key for :");
    
    scanf("%s",&nameStr);

        //key generation phase I
    for ( i=0;i<strlen( nameStr );i++ )
    {
    currentSumPart1 += nameStr[i];
    }

    //key generation phase II
    for ( i=0;i<strlen( nameStr );i++ )
    {
    tempSum = currentSumPart2;
    tempSum >>= 0x8;
    tempSum <<= 0x18;
    tempSum >>= 0x18;

    nameStr[i] ^= ( unsigned char ) tempSum;

    currentSumPart2+= ( unsigned char )nameStr[i];

    currentSumPart2 *= 0x6bad;
    currentSumPart2 += 0xc0de;
    }

    //key generation phase III
    for ( i=0;i<strlen( nameStr );i++ )
    {
    currentSumPart3 += ( unsigned char )nameStr[i];
    }
    finalResult = (currentSumPart3 * 0x3e8) + currentSumPart1;

    printf ("The Serial is %d\n",finalResult);
    return 0;
}