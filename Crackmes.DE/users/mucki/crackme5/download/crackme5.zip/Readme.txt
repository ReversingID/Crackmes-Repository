This is my fifth crackme (webservercrackme), written in MASM.

- write a keygen
- and submit a tutorial

hints:
- to enter serial use a browser and insert address "http://localhost/"

Tested with OS: WinXP 
Tested with browsers: Mozilla Firefox / Lynx

Regards,

mucki