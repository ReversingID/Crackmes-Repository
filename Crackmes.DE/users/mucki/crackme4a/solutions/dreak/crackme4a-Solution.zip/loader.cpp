#include <windows.h>

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	PROCESS_INFORMATION pi;
	ZeroMemory(&pi, sizeof(pi));
	STARTUPINFO si;
	ZeroMemory(&si, sizeof(si));
	si.cb = sizeof(si);

	if (!CreateProcess(L"crackme4a.original.exe", NULL, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi))
	{
		MessageBoxA(NULL, "Unable to Create Process!", "Error!", 0);
		return 0;
	}

	if (pi.hProcess) 
	{ 
		//Patch the nag screen (MessageBox, and all the 4 pushes before it)
		UINT64 qwordbytes = 0x9090909090;
		long bytes = 0x9090;
		WriteProcessMemory(pi.hProcess, (LPVOID)0x004014B1, &bytes, 2, NULL);
		WriteProcessMemory(pi.hProcess, (LPVOID)0x004014B3, &qwordbytes, 5, NULL);
		WriteProcessMemory(pi.hProcess, (LPVOID)0x004014B8, &qwordbytes, 5, NULL);
		WriteProcessMemory(pi.hProcess, (LPVOID)0x004014BD, &bytes, 2, NULL);
		WriteProcessMemory(pi.hProcess, (LPVOID)0x004014BF, &qwordbytes, 5, NULL);
	}

	CloseHandle(pi.hProcess);
	CloseHandle(pi.hThread);
	return 0;
}
