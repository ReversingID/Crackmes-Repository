In my opinion the 4th crackme was the best one of my crackmes yet, but it was written in
java which was the reason why not many of you tried it. That's why I decided to write it
again in MASM, but of course it has other protections now. It's a Server-Crackme again,
so you can also write a client bruter to get the valid serial.

- get the serial
- and submit a tutorial

hints:
- serial is short, only lowercase characters
- to enter serial use a telnetclient at standard-port 23 (command: "telnet localhost")

Tested on WinXP SP1 but should also work on other Windows os.

Regards,

mucki