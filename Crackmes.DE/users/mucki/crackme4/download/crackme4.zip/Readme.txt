This is my fourth crackme (keyfileme + bruteforceme server), now written in Java.

- create a valid keyfile
- write a bruter
- get the serial
- and submit a tutorial

hints:
- serial is short, case insesitive
- to enter serial use a telnetclient at standard-port 23 (command: "telnet localhost")


Tested on WinXP SP1 but should also work on other os.

Regards,

mucki