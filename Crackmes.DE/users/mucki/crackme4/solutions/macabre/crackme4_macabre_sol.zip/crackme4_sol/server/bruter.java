package server;

public class bruter
{
   public bruter()
   {
   }

   public static void main (String args[])
   {
   	String mySerial = args[0];
	char hash[]=MD5.getHashString(mySerial).substring(5,15).toUpperCase().toCharArray();
	char charbuf[] = new char[hash.length];
	for(int t = 0; t < hash.length; t++)
		charbuf[t] = (char)(hash[t] ^ 10 + t);

	String serial = new String(charbuf);
	if(serial.equals("IJM>=>TWS!") )
		System.out.println("Got it! Serial: " + mySerial);
   }
}
