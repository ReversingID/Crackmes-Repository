#!/usr/bin/perl

my $cmd="./bruter -m 8 -l 9 -k abcdefghijklmnopqrstuvwxyz1234567890";
if (-r "state") {
	my $state=`cat state`;
	chomp($state);
	$cmd.=" -r $state";
}
$cmd.="|";
print "DEBUG: $cmd\n";
open BRUTE, $cmd or die "Couldn't open bruter: $!\n";
while(<BRUTE>) {
   my $line=$_;
   chomp($line);
   system("echo $line > state");
   $ATTEMPT=`java server.bruter $line`;
   if($ATTEMPT) {
	print $ATTEMPT;
	exit(1);
   }
}
close BRUTE;
