#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
   FILE *fd,*new;
   int len;
   struct stat buf;
   char *filedata;
   int cnt;

   if(argc != 2) {
	printf("Usage: %s <java.class>\n",argv[0]);
	exit(1);
   }

   fd=fopen(argv[1],"r");
   new=fopen("decrypted","w");
   
   fstat(fileno(fd),&buf);

   len = buf.st_size;

   filedata=malloc(len);

   fread(filedata,len,1,fd);

   for(cnt = 8; cnt < len; cnt++) {
               filedata[cnt] ^= 0x63;
   }

   fwrite(filedata,len,1,new);

   free(filedata);
   fclose(new);
   fclose(fd);
}
