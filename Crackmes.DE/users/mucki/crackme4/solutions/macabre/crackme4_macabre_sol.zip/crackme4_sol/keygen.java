import java.util.zip.CRC32;

public class keygen
{
   public keygen()
   {
   }

   public static void main(String args[])
   {
   	if(args.length != 1) {
		System.out.println("Usage: keygen <username>\n");
		return;
	}
   	int counter=0;
	CRC32 crc32 = new CRC32();
   	char name[] = args[0].toLowerCase().toCharArray();
	for(int i = 0; i < name.length; i++)
		counter += name[i] * ((i >> 1) + 4) * (i ^ 3);
	crc32.update(counter);
	System.out.println(Long.toHexString(crc32.getValue()));
   }
}
