/*
 *
 *  Brute Force Value Generator
 *
 *  (c) 2006 macabre - AU Crew
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define VERSION "0.2"
#define LVL1 "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
#define LVL2 "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
#define LVL4 "0123456789"
#define LVL5 "0123456789ABCDEF"

void Usage(char *me) {
	printf("Brute Force Value Generator v%s\n",VERSION);
	printf("Usage: %s -m <maxsize> -l <level>\n",me);
	printf("\n\t[Options]\n");
	printf("\t-m\tMax Attempt Size\n");
	printf("\t-l\tLevel of keyset (see below)\n");
	printf("\t-k\tCustom Keyset (Only used for Level 9)\n");
	printf("\t-s\tStart at -s attempt length\n");
	printf("\t-r\tRestores attempt key to specified value\n");
	printf("\n\t[levels]\n");
	printf("\t1 = a-Z\n");
	printf("\t2 = a-Z0-9\n");
	printf("\t3 = all printable chars\n");
	printf("\t4 = 0-9 (Digits)\n");
	printf("\t5 = 0-9A-F (Hex)\n");
	printf("\t9 = <provided keyset -k Option>\n");
	printf("\n");
	printf("(c) 2006 - macabre [AU Crew]\n\n");
	exit(1);
}

int getpos(char findme, char *keyset) {
   int len=strlen(keyset);
   int cnt;

   for(cnt=0;cnt<len;cnt++) {
	if(keyset[cnt] == findme) {
		return cnt;
	}
   }
   return 0;
}

void nextattempt(char *attempt, char *keyset) {
	int rptr=strlen(attempt)-1;
	char didinc=0;

	while(!didinc) {
		if(attempt[rptr] != keyset[strlen(keyset)-1]) {
			attempt[rptr]=keyset[getpos(attempt[rptr],keyset)+1];
			didinc++;
		} else {
			attempt[rptr] = keyset[0];
			rptr--;
		}
		if(rptr < 0) {
			attempt[strlen(attempt)]=keyset[0];
			didinc++;
		}
	}
}

int main(int argc, char *argv[]) {
  int pos,cnt,len;
  char *keyset,*attempt;
  extern char *optarg;
  extern int optind;
  int c;
  long numkey;
  int keylen=0;
  int skiplen=0;
  int level=0;
  char *restorekey=NULL;
  
  while((c = getopt(argc, argv, "l:s:m:k:r:h?")) != -1) {
	switch(c) {
		case 'm':	// MAX
			keylen=atoi(optarg);
			break;
		case 's':	// Starting at length
			skiplen=atoi(optarg);
			break;
		case 'l':	// keyset level
			level=atoi(optarg);
			break;
		case 'k':	// Custom keyset
			keyset=optarg;
			break;
		case 'r':	// Restore attempt to this
			restorekey=optarg;
			break;
		default:
			Usage(argv[0]);
			break;

	}
  }

  if(!keylen) {
	printf("MAX size (-m) is a mandatory switch\n");
	Usage(argv[0]);
  }
  if(!level) {
  	printf("Level is required (-l)\n");
	Usage(argv[0]);
  }

  if(skiplen > keylen) {
  	printf("Error: Start size must be less that max size... dumbass\n");
	exit(1);
  }

  numkey=0;
  attempt=malloc(keylen+1);
  memset(attempt,0,keylen+1);

  if(restorekey != NULL) {
  	if(skiplen) {
		printf("WARNING: the -r option implies skiplen...overwriting skiplen.\n");
	}
	skiplen=strlen(restorekey);
	memcpy(attempt,restorekey,keylen);
	if(level == 4 || level == 5) { // digit based
		numkey=atoi(restorekey);
	}
  }

  switch(level) {
	case 1:
		keyset=strdup(LVL1);
		break;
	case 2:
		keyset=strdup(LVL2);
		break;
	case 3:
		len='~'-'!';
		keyset=malloc(len+1);
		memset(keyset,0,len+1);
		cnt='!';
		for(pos=0;pos<=len;pos++) {
			keyset[pos]=cnt;
			cnt++;
		}
		break;
	case 4:
		keyset=strdup(LVL4);
		break;
	case 5:
		keyset=strdup(LVL5);
		break;
	case 9:
		keyset=strdup(keyset);
		break;
	default:
		printf("Unknown keyset level\n");
		Usage(argv[0]);
		break;
  }

  if(attempt[0]==0) {
     if(skiplen) {
	for(cnt=0;cnt<skiplen;cnt++) {
       		if(level == 4 || level == 5) {
			attempt[cnt]='1';
		} else {
			attempt[cnt]=keyset[0];
		}
	}
	if(level == 4 || level == 5) {
		numkey=atoi(attempt);
	}
     } else {
        attempt[0]=keyset[0];
     }
  }

  while(strlen(attempt) <= keylen) {
	printf("%s\n",attempt);
	if(level == 4) {
		numkey++;		
		snprintf(attempt,keylen,"%d",numkey);
	} else if (level == 5) {
		numkey++;
		snprintf(attempt,keylen,"%x",numkey);
	} else {
		nextattempt(attempt,keyset);
	}
  }

 free(attempt);
 return 0;
}
