This is my 7th crackme (keygenme), written in MASM.

- create a valid cd-image
- make a keygen
- and submit a tutorial
- patching of exe file not neccesary (it's ok if you are not able to create a cd-image)

hint:
- it's possible to manipulate a cd-image with an hex-editor
- close other programs before you start my crackme, it's possible that there will be problems

tested on WinXP SP1 but should also work on other windows os.

Regards,

mucki