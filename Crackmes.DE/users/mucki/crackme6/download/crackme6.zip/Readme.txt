This is my sixth crackme, written in MASM, TASM and... find it out yourself!

- get the serial
- and submit a tutorial
- no bruteforce

Tested with OS: DOS 6.2

Regards,

mucki