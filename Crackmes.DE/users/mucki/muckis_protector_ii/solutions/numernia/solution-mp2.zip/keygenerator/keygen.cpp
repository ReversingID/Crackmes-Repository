//mucki's protector II keygenerator

unsigned long bsw(unsigned long in)
{
	return (((in & 0x000000FF) << 24)
	+ ((in & 0x0000FF00) << 8)
	+ ((in & 0x00FF0000) >> 8)
	+ ((in & 0xFF000000) >> 24));
}
unsigned long powmod32(unsigned long a,unsigned long n,unsigned long p)
{
    unsigned __int64 t=0;
	int i;
    for(t = 1, i = 32; i >= 0; i--)
    {
        t = (t * t) % p;
        if(n & ((unsigned __int64)1 << i)){ t=(a * t) % p;}
    }
    return (t & 0xFFFFFFFF);
}
void Generate(HWND hWnd)
{
	char buf[50]={0};
	unsigned long n = 0x90186421, tal = 0x12345678;
	GetDlgItemText(hWnd,IDC_EDIT2,buf,50);
	unsigned long c = (*(DWORD*)(buf + 0));
	do{c += tal;
	}while (!(c & 0x80000000));
	c = bsw(c ^ tal);
	if(c<n)
	{
		c = powmod32(c,0x1234567,0x90186421);
		wsprintf(buf,"%08X#!",c);
		SetDlgItemText(hWnd,IDC_EDIT1,buf);
	}
	else
	{
		SetDlgItemText(hWnd,IDC_EDIT1,"Not a valid name, M > N");
	}
}