#include<stdio.h>
#include<conio.h>
#include<string.h>

main()
{
char name[255], serial[255];
printf("muckis crackme #2 by mucky keygen\nby evo - evobboy@yahoo.it\n\n") ;
printf("Name:") ;
gets(name) ;

int length = strlen(name);
if((length>=1)&&(length<0x32))
{
   unsigned long var_1, var_2, var_3=0;
   int i;
   for(i=0;i<length;i++)
   {
     var_1 = name[i];
     var_2 = var_1;
     var_1 = var_1 << 4;
     var_2 = var_2 >> 5;
     var_1 ^= var_2;
     var_1 += 0x26;
     var_1 ^= var_3;
     var_3 += var_1;
   }
   var_1 = 0x0C0DEF;
   var_1 -= var_3;
   var_1 *= var_1;
   sprintf(serial,"CM2-%lX-%lX",var_3,var_1);
   printf("\n%s",serial);
}
else printf("\nName must be min of 1 character, max of 50");
printf("\n\nbye :)");
getch();
return (0) ;
}
