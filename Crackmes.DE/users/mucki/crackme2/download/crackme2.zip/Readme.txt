This is my second crackme (keygenme), now written in Assembler.

- find the solution
- make a keygen
- and submit a tutorial

tested on WinXP SP1 but should also work on other windows os.

Regards,

mucki