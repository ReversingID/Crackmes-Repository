Crackme 12 by ThrawN
--------------------

Introduction:
 Here is a strange twist. There has been latly, a surge of license systems/protectors for software authors. E.G Softwrap, Geeworks.TrialMaster etc... They all suck (this is no better). This crackme is designed to be pratice for the ever increasing license systems coming out. This is a very basic license system thats scaled down and packs a bitch inside. Its still rather easy, but the idea is to not only unpack/fix notepad.exe - also to write a detailed tutorial explainin the tricks and tech's used here (otherwise notepad.exe wouldnt be lying around afterwards). Have fun ;)

Instructions:
 Unpack/fix notepad.exe
 Write a detailed tutorial explaining the tricks and how to unpack/fix

Rules:
 Strictly NO PATCHING JUMPS (or creating your own). Work your own way around the tricks (or debug them like a smart cracker would:)).
 

Final Notes:
 I too, am working on a license engine that i hope will be available FREE OF CHARGE to authors. Its nothing like this so dont freak ;). I would like some people who are also interested to work with me as a TEAM. Email me if you are interested - thrawnc@hotmail.com

Special GREETZ:  MADMAX, NtSC & trapflag

Usall greetz out to those who know me ;)

ThrawN/C./iNSTiNCT/DiSTiNCT/EViDENCE/CGG
www.thrawn.da.ru  thrawnc@hotmail.com