CrackMe By: DerangedMind


RULES
****************************************************************
*There is none. Just make it display the goodboy message ;)
****************************************************************



This is my first crackme ever. I didn't rate it as for begginers because I am a begginer at cracking and if I didn't know the source
of the program I would not have known where to start. If you get a solution please upload a tutorial and rate.

I hade fun writing this crackme and making it somewhat hard to crack. I tried to be as random and as un-ordinary as possible.
Tell me if I did a good job and if you would like to see more (Hopefully I will be better and they will be a bunch harder).


It was written in 100% C++ with Dev-C++ compiler.