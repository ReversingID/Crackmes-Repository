This is my first CrackMe written in C++

Rules:
*No patching
*Make a KeyGen
*Upload a solution + tutorial

I hope it's not too easy.
Have fun.
