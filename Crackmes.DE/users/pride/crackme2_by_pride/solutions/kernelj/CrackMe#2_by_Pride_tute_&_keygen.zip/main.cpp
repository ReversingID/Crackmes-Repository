#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    string input;
    cout << "Name: ";
    cin >> input;
    int name = (input.length() + 0xCA) ^ 0x3D8D40F;
    int masterserial = name + 0xEFC89;
    if (name < 0x186A0)
        name += 0x8C9666F8;
    if (name > 0x186A0)
        name += 0xB61B9688;
    cout << "Serial: " << name << endl << "Masterserial: " << masterserial << endl;
    system("PAUSE");
    return EXIT_SUCCESS;
}
