#include "stdafx.h"
#include <windows.h>
#include <stdlib.h>


int serialTable[] =
{
0x13,  
0x16,
0x99,
0x11,
0x63,
0x15,
0x54,
0x52,
0x88,
0x1 ,
0x31,
0x56,
0x68,
0x55,
0x37,
0x41,
0x74,
0x46,
0x75,
0x57,
0x76,
0x6C,
0x77,
0x6A,
0x78,
0x44,
0x79,
0x58,
0x48,
0x59,
0x6F,
0x5A,
0x77,
0x73,
0x64,
0x52
};


struct SerialSupport
{
	int member0;
	int member1;
	int member2;
	int member3;

	char username[0x101];
	char serial[0x1000];

	SerialSupport();
	bool generateSerial(char * name);
};


SerialSupport::SerialSupport()
{
	member0 = 0;
	member1 = 0;
	member2 = 0;
	member3 = 0;

	DWORD usernameLength = 0x101;
	GetUserNameA(username,&usernameLength);
}


bool  SerialSupport::generateSerial(char * name)
{
	if(strlen(name) > 9)
		return false;

	if(strlen(username) == 0)
		return false;
	

	if(strlen(name) != 0)
	{
		for(int i = 0; i < strlen(name); i++)
		{
			member0 += name[i] * serialTable[i];
			member1 = username[1] * serialTable[i] + member1;
			member2 = member1 - serialTable[i];
		}
	}


	if(strlen(username) != 0)
	{
		for(int i=0; i < strlen(username); i++)
		{
			member1 += serialTable[i];
			member0 += username[i] * serialTable[i];
			member3 = member0 - member1;
		}
	}


	wsprintfA(serial,"%X-%X-%X-%X-%X-%X",username[0],0x99,member2,0x52,member3,username[2]);
	return true;
}


int _tmain(int argc, _TCHAR* argv[])
{
	char name[100];

	printf("Name: ");
	while(scanf_s("%s",&name,100) != -1)
	{
		SerialSupport serialSupport;

		if(serialSupport.generateSerial(name))
		{
			printf("Serial: %s",serialSupport.serial);
		}
		else
		{
			printf("Failed to generate serial");
		}

		printf("\n\nName: ");
	}
}

