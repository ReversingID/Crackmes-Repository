Crack me developed by a firend of mine (CT) that was supposed to be used in a crackme contest at a spanish security con called NoConName.

The program encrypts the text provided, therefore you have to decrypt the following text:

"0J3N2rElwSr1KrOPiJW0Th6ZjxQ06poPnwCfybk3ZtARCXWEId8YuBiyMr9JkCZl"