#!/usr/bin/python

minStr = "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
baseEncrypted = "0Jm5OrATwFY1Kd6PiBUnGZsLexQj2Vo7atCfyHk3Mp8RuDWzIb4Ng9SlEXqJcvOh"
toDecrypt = "0J3N2rElwSr1KrOPiJW0Th6ZjxQ06poPnwCfybk3ZtARCXWEId8YuBiyMr9JkCZl"
order = (4, 7, 10, 13, 16, 19, 22, 25, 28, 31, 34, 37, 40, 43, 46, 49, 52, 55, 58, 61, 0, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36, 39, 42, 45, 48, 51, 54, 57, 60, 63, 2, 5, 8, 11, 14, 17, 20, 23, 26, 29, 32, 35, 38, 41, 44, 47, 50, 53, 56, 59, 62)
SEED = 45

result = []
for x in order:
        index = 0
        encryptedIndex = minStr.index(baseEncrypted[x])
        while minStr[encryptedIndex % len(minStr)] != toDecrypt[x]:
            index += 1
            encryptedIndex += 1
        result.append(minStr[index])

print ''.join(result)
