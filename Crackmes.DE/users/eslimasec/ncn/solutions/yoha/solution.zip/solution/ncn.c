// solution for eslimasec's ncn
// http://www.crackmes.de/users/eslimasec/ncn/

// Compile with
// gcc -Wall -Wextra -Werror -pedantic -ansi -std=c99 -O3 keygen.c
// the only requisite flag is -std=c99

// This program implements the encoding function in ncn
// As well as a decoding function compatible with it.

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <assert.h>

typedef signed long reg; // a register is a signed 32 bit long memory

#define MULCONST 0x84210843
#define SALTO  ((reg)3)

// these are put as globals for convenience
char ALNUM[] = "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
char CIFRED[81]; 
char CLEAR [81];
reg LEN;

// picks the next cell to be written
static reg vacia(reg param8, reg paramLen)
{
	if (param8 > paramLen)
		param8 -= paramLen + 1;
	if (CIFRED[param8] == '0')
		return param8;
	return vacia(param8+1, paramLen);
}
// this does the same as the previous one
// but avoid using CIFRED
char VISIT[81];
static reg inv_vacia(reg param8, reg paramLen)
{
	if (param8 > paramLen)
		param8 -= paramLen + 1;
	reg ret = VISIT[param8] == '0' ? param8 : inv_vacia(param8+1, paramLen);
	VISIT[ret] = '1';
	return ret;
}

// PRNG using two input registers
static reg RANDOM(reg ecx, reg eax)
{
	reg edx;
	edx = ( (long long)ecx * eax ) >> 32;
	edx = edx + ecx;
	edx = (edx >> 5) - (ecx >> 31);
	eax = 2 * ((edx << 5) - edx);
	eax = ecx - eax;
	return eax;
}
// brute-forces the previous PRNG assuming
// the initial value is between 0 and 61
// (dependent on the way RANDOM() is called)
static reg inv_RANDOM(reg rnd, reg ecx, reg eax)
{
	for (reg i = 0; i < 62; i++)
		if (RANDOM(ecx+i, eax) == rnd)
			return i;
	assert(0);
}

// proceeds to encode CLEAR into CIPHER
static void encode()
{
	reg res_rand = rand();

	memset(CIFRED, '0', 80);
	CIFRED[LEN] = '0';
	CIFRED[LEN+1] = 0;

	reg SEMILLA = RANDOM(res_rand, MULCONST);
	CIFRED[1] = ALNUM[SEMILLA];

	reg NEWPOS = 1;
	for (reg I = 0, INCREASE = 5; I < LEN; I++, INCREASE += 5)
	{
		NEWPOS = vacia(NEWPOS + SALTO, LEN);
		reg J = strchr(ALNUM, CLEAR[I]) - ALNUM;
		CIFRED[NEWPOS] = ALNUM[RANDOM(SEMILLA + J + INCREASE, MULCONST)];
	}
}

// proceeds to decode CIPHER to CLEAR
static void decode()
{
	memset(VISIT, '0', 80);
	memset(CLEAR, '0', 80);
	LEN--;
	CLEAR[LEN] = 0;
	reg SEMILLA = strchr(ALNUM, CIFRED[1]) - ALNUM;

	reg NEWPOS = 1;
	for (reg I = 0, INCREASE = 5; I < LEN; I++, INCREASE += 5)
	{
		NEWPOS = inv_vacia(NEWPOS + SALTO, LEN);
		reg J = strchr(ALNUM, CIFRED[NEWPOS]) - ALNUM;
		CLEAR[I] = ALNUM[inv_RANDOM(J, SEMILLA + INCREASE, MULCONST)];
	}
}

// administrative stuff
static void usage(int argc, char** argv)
{
	(void) argc;
	fprintf(stderr,
		"Usage: %s --encode MSG\n"
		"          --decode MSG\n"
		"Encode or decode a MSG\n"
		,
		argv[0]
	);
}
int main(int argc, char** argv)
{
	if (argc < 3)
	{
		usage(argc, argv);
		exit(0);
	}

	char mode = strcmp(argv[1], "--encode") == 0;

	srand(time(NULL));

	LEN = strlen(argv[2]);
	if (LEN > 80) LEN = 80;

	strncpy(mode ? CLEAR : CIFRED, argv[2], LEN);
	if (mode)
		encode();
	else
		decode();

	printf("%s\n", mode ? CIFRED : CLEAR);
	return 0;
}

