#!/bin/bash

nping --send-eth -S 192.168.0.1 --dest-ip 127.0.0.1 --udp -g 17352 -p 34807 --data-string a3b5a9184bd596f3135f69d5439b0251 -e eth0

