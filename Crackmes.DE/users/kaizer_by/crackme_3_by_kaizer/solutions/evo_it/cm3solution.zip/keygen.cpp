#include<stdio.h>
#include<conio.h>
#include<string.h>

main()
{
char name[255], code[255], YN;
printf("KeiZer Cm3 Keygen by evo\n") ;
printf("Name:") ;
gets(name) ;

signed int length = strlen(name);
signed int result;
if((length>1)&&(length<0x63))
{
   result = length*0x75+((signed int)0x153E)-((signed int)0x1574);
   result = (length-0x22)*0x11F0+result+0xE524C;
   sprintf(code,"668r9\\5233%d-k329[43}%X$",result,name[0]);
   printf("\n%s",code)
   for(int i=1;i<length;i++)
   {
     printf("\n\nwould you like to find another code y/n?  ");
     YN = getchar();
     if((YN=='y')||(YN=='Y'))
     {
       sprintf(code,"%s%X$",code,name[i]);
       printf("\n%s",code);
       YN = getchar();
     }
     else break;
   }
}
else printf("\nName must be min of 1 character, max of 99");
printf("\n\nbye :)");
getch();
return (0) ;
}

