CrackMe #3 by kaiZer / 24.09.2006

It's my third crackme. Not an easy. But you must solve it!

kaiZer