Scarabee Crackme #1

Easy little crackme, just for you to find the serial (very basic) and perhaps to code a keygen, as the algo is not difficult at all.  
Coded for the real beginner, just a nice relaxing crackme for education sake.

Scarabee
scarabee_5@hotmail.com
