The Button Crackme by Scarabee

Well, seems like it has been ages since i was here.. ohwell.. i managed to produce this little crackme for you all once again.

And i know, a lot of you seem to be irritated by VB crackmes, but just go ahead and have a go.  You might just even like it :)

Anyhow, the rules:

1. You may only patch the needed button.
2. Find a valid serial for your name.
3. Code a keygen (as usual, the algo is not too hard).
4. Write a decent tutorial.

I added my source code to this pack. The serial for my name 'Scarabee' is the password for the zipfile!

For questions, or what so ever:

scarabee_5@hotmail.com