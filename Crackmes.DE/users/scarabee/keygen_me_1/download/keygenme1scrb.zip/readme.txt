Keygen Me #1

Well, after some time finally i got myself into coding a small crackme once again :))  Yet again coded in VB6, but not packed. As mostly, this is not a very difficult one, but i think it has a nice unexpected twist to it.  Hope you have some fun on it!!

As usual, some rules:

- NO patching!
- Code a keygen!
- Enjoy!

Greets to all who spend their time on this crackme and put their efford into cracking it!

Scarabee '03
(scarabee_5@hotmail.com)