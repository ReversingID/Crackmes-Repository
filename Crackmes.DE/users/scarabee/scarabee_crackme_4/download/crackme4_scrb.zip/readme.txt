Scarabee Crackme #4

Coded in Delphi 6. Rather nice Name/Company/Serial crackme i personally think. 
You figure it out. Once you notice the idea it is not that hard.

Rules:

- NO patching, except for enabling the check button.
- Find a valid name/company/serial combination.
- Explain what the crackme does. It is not hard, but explain how it is done.
- Keygen is optional, but not neccecary.



Now, a small summary at present date (21-03) of the previous crackme's that i have uploaded...

Crackme #1 -> Cracked successfully by _pusher_ and _RiPTiDE_!  WELL DONE!

Crackme #2 -> Still UNCRACKED. Probably a bit more difficult than expected due to the fact that                  it's packed. With this crackme (#4) i include an UNPACKED version of crackme #2. 
              Hope helps a bit...

Crackme #3 -> Still UNCRACKED. Dissapoints me a little, as this crackme really is NOT hard!
              All you need is Smartcheck. No other tool is required. But make sure you look at the
              RIGHT place!!  Things are not what they appear to be in this crackme!
     
So far with that.. notice the hints i gave up here.. could help you find your way to glory ;-))


Finally, greetings to all that put efford in cracking my crackmes. Keep it up!!
For questions, help or info concerning the crackme's, or whatever:

scarabee_5@hotmail.com
