// KeyGen to servitute's Euler - KeyGenMe by cosmos
// Compiled in Dev C++ 4.9.9.2

#include <iostream>
#include <math.h>
using namespace std;

int main()
{
    cout << "   *******************************************************************\n";
    cout << "   *         KeyGen for servitute's Euler - KeyGenMe by cosmos       *\n";
    cout << "   *******************************************************************\n\n\n";
    
    //Store the entered name
    char cName[30], cNewName[30];
    cout << " Enter Your Name (Only Alphabets & more than 5 chars) >> ";
    cin >> cName;
    
    short sLen = strlen(cName);                // finds the length of the name
    for(int i = 4 ; i < sLen+4; i++)           // Make a modified name array sothat its first 4
    {                                          // members can be anything
            cNewName[i] = cName[i-4];
    }                         
    double x = (double) cNewName[sLen] , y;    // Take the char whose exponential is to be finded out
    
    y = exp(x);                                // Finds the exponential of the char
      
    int     nDecimal,   nSign;
    char    *cFirstSerial, cSecondSerial[5], cThirdSerial[10];
    int     nPrecision = 5;
   // Convert the exponetiated result to string having a length of 5 
   cFirstSerial = ecvt(y, nPrecision, &nDecimal, &nSign );
   
   // Finds the hash of the charcters of first serial
   int nSum  = 0;
   for(short i = 0; i < 5; i++)
   {
             nSum += cFirstSerial[i];
   }
   nSum  = nSum  * 180;    
   itoa( nSum , cSecondSerial, 10 );     // Convert 2nd serial into string
   
   nSum  = nSum  * 3;
   nSum  = nSum  << 2;
   nSum  = nSum  + 268;
   
   itoa( nSum , cThirdSerial, 10 );       // Convert third serial to string
   
   cout << "\n" << " Your Serial >> " << cFirstSerial << cSecondSerial <<cThirdSerial << "\n\n\n\a";
   
   
   system("pause");
   return 0;
}
    
