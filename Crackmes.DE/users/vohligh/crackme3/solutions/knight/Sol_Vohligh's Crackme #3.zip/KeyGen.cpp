#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "resource.h"

HBITMAP logo;

char abc[] = "1AULWJZI92BCDEFG86K4NPQRST3V5XY7";

char magic_bits[13][3] = {"16", "AJ", "AT", "UL", "LA", "L7", "WX", "6J", "6T", "KL", "4A", "47", "NX"};

int index_table[7] = {0x11, 0x25, 0x39, 0x43, 0x61, 0x7F, 0x9D};

int local_10[7] = {0x0D, 0x02, 0x18, 0x10, 0x0A, 0x13, 0x05};
int vienetai[7][16] = {
0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18,
0x04, 0x03, 0x06, 0x05, 0x07, 0x08, 0x0A, 0x09, 0x12, 0x11, 0x14, 0x13, 0x16, 0x15, 0x18, 0x17,
0x0D, 0x00, 0x17, 0x01, 0x16, 0x02, 0x15, 0x03, 0x14, 0x04, 0x13, 0x05, 0x12, 0x06, 0x11, 0x07,
0x0A, 0x15, 0x00, 0x07, 0x0E, 0x12, 0x03, 0x04, 0x05, 0x0F, 0x13, 0x16, 0x11, 0x01, 0x18, 0x06,
0x04, 0x17, 0x09, 0x10, 0x02, 0x08, 0x14, 0x0D, 0x05, 0x16, 0x06, 0x18, 0x07, 0x12, 0x01, 0x15,
0x01, 0x10, 0x0D, 0x18, 0x03, 0x0A, 0x16, 0x05, 0x17, 0x14, 0x07, 0x11, 0x02, 0x12, 0x08, 0x04,
0x09, 0x04, 0x0A, 0x14, 0x10, 0x00, 0x0E, 0x01, 0x16, 0x13, 0x11, 0x15, 0x0F, 0x03, 0x07, 0x06
};
int local_4[7][2] = {
0x00, 0x01,
0x01, 0x00,
0x08, 0x09,
0x09, 0x08,
0x0E, 0x0F,
0x0F, 0x0E,
0x18, 0x17
};
int local_9[7][4] = {
0x0A, 0x0E, 0x0F, 0x10,
0x0D, 0x0E, 0x0F, 0x10,
0x0A, 0x0E, 0x0F, 0x10,
0x02, 0x0D, 0x14, 0x17,
0x00, 0x03, 0x11, 0x13,
0x00, 0x06, 0x09, 0x15,
0x02, 0x08, 0x0D, 0x12
};
int GetCodeFromTable(char raide)
{
    int i;
    for(i = 0; i < 31; i++)
        if(abc[i] == raide)
            break;
    if(i == 30)
        i = -1;
    return i;
}

void L00403DD0(int& Arg1, int& Arg2, int Arg3, int Arg4)	//ripped function
{
	bool a = 0;
    if(Arg2 < 0)
	{
		a = true;
        Arg2 = ~Arg2;
        Arg1 = ~Arg1;
    }
    Arg2 = Arg2 / Arg3;
    Arg1 = Arg1 / Arg3;
    if(a)
	{
        Arg2 = ~Arg2;
        Arg1 = ~Arg1;
    }
}

int GetHash(char *string)								//ripped function
{
	int length, i;
	int var1 = 160, var2 = 0, var3 = 0;
	char *buff2;

    length = strlen(string);
    buff2 = new char [length + 1];
    for(i = 0; i < length; i = i + 1)
	{
        buff2[i] = string[i] & 255 ^ (var1 & 65535) >> 8;
        var2 = var2 + buff2[i];
        var1 = (((string[i] & 255) + (var1 & 65535)) * 66 + 6) & 0xFFFF;
    }
    while(var3 == 0)
	{
        if(var2 <= 100)
            break;
        L00403DD0(var2, var3, 10, 0);
    }
    delete [] buff2;
    return var2;
}

void Generate(HWND hWnd)
{
	char serial[26], name[32], company[32];
    int index, a, b, name_h, company_h, i, chksum = 0;
    int h1, h2;
	time_t t;
    GetDlgItemText(hWnd, IDC_NAME, name, 32);
	GetDlgItemText(hWnd, IDC_COMPANY, company, 32);
    if(strlen(name) < 5 || strlen(company) < 5)
        return;
    serial[25] = 0;
    srand((unsigned) time(&t));
    a = rand() % 13;
    serial[0x0B] = magic_bits[a][0];
    serial[0x0C] = magic_bits[a][1];
    a = GetCodeFromTable(serial[0x0B]);
    index = GetCodeFromTable(serial[0x0C]);
    index += (a << 5);
    index &= 0xFF;
    for(i = 0; i < 7; i++)
    {
        if(index_table[i] == index)
        {
            index = i;
            break;
        }
    }
	
    serial[local_10[index]] = abc[16]; //this char must be 16
    for(i = 0; i < 8; i++)
    {
        a = rand() % 32;
        serial[vienetai[index][i * 2]] = abc[a];
        b = rand() % 32;
        serial[vienetai[index][(i * 2) + 1]] = abc[b];
        a = b + (a << 5);
        chksum += (a & 0xFF);
    }
    chksum = chksum % 0xFF;
    a = (chksum / 0x10) / 2;
    serial[local_4[index][0]] = abc[a];
    a = chksum - (a * 0x20);
    serial[local_4[index][1]] = abc[a];

    name_h = GetHash(name);
    company_h = GetHash(company);

    chksum = (name_h * 0xB3) + (company_h * 0x1F) + 0xFE57;
    h1 = (chksum >> 8) & 0xFF;
    h2 = chksum & 0xFF;
    a = (h1 / 0x10) / 2;
    serial[local_9[index][0]] = abc[a];
    a = h1 - a * 0x20;
    serial[local_9[index][1]] = abc[a];
    a = (h2 / 0x10) / 2;
    serial[local_9[index][2]] = abc[a];
    a = h2 - a * 0x20;
    serial[local_9[index][3]] = abc[a];
	SetDlgItemText(hWnd, IDC_SERIAL, serial);
}

static BOOL CALLBACK DlgAbout(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
		case WM_INITDIALOG:
			SetDlgItemText(hwnd, IDC_EDIT1, "2005-04-26");
			SetDlgItemText(hwnd, IDC_EDIT2, "Knight");
			SetDlgItemText(hwnd, IDC_EDIT3, "Vohligh's Crackme #3(Crackme3.exe)");
			break;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case IDOK:
					EndDialog(hwnd, 0);
					break;
			}
			break;
		default:
			return FALSE;
	}
	return true;
}

static BOOL CALLBACK DlgFunc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	BITMAP bm;
	PAINTSTRUCT ps;
	HDC hdc,hdcMem;
	HBITMAP hbmOld;

	switch(msg)
	{
		case WM_INITDIALOG:
			SendMessage(hwnd, WM_SETICON, ICON_SMALL, (LPARAM)LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1)));
			SendMessage(hwnd, WM_SETICON, ICON_BIG, (LPARAM)LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1)));
			logo = LoadBitmap(GetModuleHandle(NULL), MAKEINTRESOURCE(IDB_BITMAP1));
			return TRUE;
		case WM_PAINT:
			hdc = BeginPaint(hwnd, &ps);
			hdcMem = CreateCompatibleDC(hdc);
			hbmOld = (HBITMAP)SelectObject(hdcMem, logo);
			GetObject(logo, sizeof(bm), &bm);
			BitBlt(hdc, 6, 5, bm.bmWidth, bm.bmHeight, hdcMem, 0, 0, SRCCOPY);
			SelectObject(hdcMem, hbmOld);
			DeleteDC(hdcMem);
			EndPaint(hwnd, &ps);
			break;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case IDC_BEXIT:
					EndDialog(hwnd, 0);
					break;
				case IDC_BABOUT:
					DialogBox(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_ABOUT), hwnd, DlgAbout);
					break;
				case IDC_BGEN:
					Generate(hwnd);
					break;
			}
			break;
		case WM_CLOSE:
			EndDialog(hwnd, 0);
		default:
			return FALSE;
	}
	return TRUE;
}

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	return DialogBox(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, DlgFunc);
}