
Vohligh's crackme#3
-------------------

Find the algo and make a keygen.
No patching allowed.


copyright (c) 2005 Vohligh (vohligh@hotmail.com)
