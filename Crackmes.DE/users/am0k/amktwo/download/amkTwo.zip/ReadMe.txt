//================================================================================================
// Project : amkTwo
// Version : 1.0
// Coder   : amk
// Website : http://users.skynet.be/amk/ (Under Construction)
//================================================================================================

Objectives : - Make a valid KeyFile for your name
             - Make a KeyFile Generator

Just one thing : No Patching ;D

Note : Sources are included in a passworded zip file. The password is the Key for "amkTwo" (without the quotes)