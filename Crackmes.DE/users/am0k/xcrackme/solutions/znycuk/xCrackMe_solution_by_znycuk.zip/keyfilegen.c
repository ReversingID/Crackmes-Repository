/******************************************************************************
* keyfilegen.c
*
* Keyfile Generator source file for the am0k's xCrackme
* By Znycuk
*
* 20/03/2006
*
* Fast and Badly Coded  :D
*******************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <ctype.h>
#include <time.h>




/********************************
*Pseudo random char
*
*********************************/
int pseudorandomchar() {
	int c;
	
	c = rand() % 41 + 41;
	return c;
}



/********************************
*Crypto 
*
*********************************/
void crypto(char *src, char *dst)
{
		int a = 0x3F;
		int i,b,c,d;

		for(i=0x0; *src != 0; src++)
		{
			
			b = a - i;
			c = b & 0x8000001F;
			if (c > 0)
			{
				d = c ^ *src;
				dst[i++] = d;
			}	
			else
			{
				c = c - 1;
				c = c | 0xFFFFFFE0;
				c = c + 1;
				d = c ^ *src;
				dst[i++] = d;
			}
			
			a = a + 0x3F;
		}

}

/**************************************
* Subkey1 Generation
*
***************************************/

void generate_subkey1(char *src)
{
	int i;
	
	srand((unsigned)time(0));
	for (i=0x0; i<0x1F;i++) 
	{
		sprintf(src + i,"%c",pseudorandomchar());
			
	}
	//src[0x1F] = '\0';
}

/**************************************
* Subkey2 Generation
*
***************************************/
void generate_subkey2(char *p_source,char *p_subkey,int checksum)
{
	int a=1;
	int i,j,b,c;
	div_t r,s;
	char *hexavals="0123456789ABCDEF";
	
	for(i=0X0;i<0x7F;i++)
	{
		j=0;
		while(*p_source != 0 && (i<0x7F))
		{
		
			r = div(((a * *p_source) - j),0xFF);
			s = div((*p_source * checksum), 0xFF);
			b = r.rem ^ s.rem;
			b = b & 0x8000000F;
			c = *(hexavals+b);
			*(p_subkey+i) = c;
			p_source++;
			i++;
			j++;
			a++;
		}
		i--;
		p_source = p_source - j;
	}
}	

/********************************
** checksum
*********************************/ 
int Calc_Checksum(char *key)
{
	int a = 0x6;
	int d = 0x0;
	int i;
	
	for (i=0x0; *key != 0; key++)
	{
		d = d + ((a & 0x8000001F) ^ *key);
		a = a + 0x5;
		i++;
	}
	d = (d & 0x8000001F) + 1;
	
	printf(" Checksum: 0x%.8x\n", d);
	return d;
}


/**************************************
* MAIN
*
***************************************/

int main (int argc, char **argv)
{
	int checksum = 0;
	char subkey1[32];
	char esb1[32];
	char *sb2 = malloc(164);
	char *e_subkey2 = malloc(164);
	
	int fd;
	char *keyfilename = "xCrackMe.key";
	printf("===================================\n");
	printf("Keyfile Generator for Am0k'xCrackMe\n");
	printf("By Znycuk\n");
	printf("===================================\n\n\n");
	generate_subkey1(subkey1);
	subkey1[0x1F] = '\0';
	
	
	printf(" SB1 : %s\n", subkey1);
		
	crypto(subkey1,esb1);
	esb1[0x1F] = '\0';
	printf(" ESB1: %s\n", esb1);
	
	checksum = Calc_Checksum(esb1);

	generate_subkey2(esb1,sb2,checksum);
	sb2[0x7F] = '\0';
	printf( "SB2: %s\n", sb2);
	crypto(sb2,e_subkey2);
	e_subkey2[0x7F] = '\0';
	printf( "ESB2: %s\n", e_subkey2);
	printf("Generating file...\n");
	fd = open(keyfilename, O_RDWR|O_CREAT, 0666);
	write(fd,subkey1,0x20);
	write(fd,&checksum,0x4);
	write(fd,e_subkey2,0x7F);
	close(fd);

return 0;
}

