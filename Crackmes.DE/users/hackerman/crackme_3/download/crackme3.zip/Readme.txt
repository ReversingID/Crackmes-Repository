Hi Cracker, 


Comments:
This is an easy c program , so you dont have any problems......

Rules:
every thing as allowed 


Contact:
HackeRMaN
hackarman@hotmail.com