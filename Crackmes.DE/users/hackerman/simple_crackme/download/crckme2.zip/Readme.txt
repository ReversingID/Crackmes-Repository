hi Cracker

this crackme was coded in full masm,
---------------------------------------

Rules:
any tools, any thing...
just crack it 

===================================================

                 HackeRMaN 