+-------------------------------+
| Crackme_by_GBM                |
+-------------------------------+
| By Igor1201                   |
| igorborges12 at gmail dot com |
+-------------------------------+

Open the file "Crackme.exe" in reflector.
Go to the Button1_Click method.
You'll see this:

private void Button1_Click(object sender, EventArgs e)
{
    string str = "";
    string str2 = "450";
    str = Conversions.ToString((double) ((Conversions.ToDouble(Conversions.ToString((double) (Conversions.ToDouble(Conversions.ToString((double) (this.TextBox1.TextLength * Conversions.ToDouble(str2)))) * 6.0))) / ((double) this.Height)) + this.Width));
    str = Conversions.ToString((double) (Conversions.ToDouble(Conversions.ToString((double) ((Conversions.ToDouble(str2) - Conversions.ToDouble(str)) + (this.Height * Conversions.ToDouble(str2))))) * 2.0));
    if (this.TextBox2.Text == str)
    {
        Interaction.MsgBox("Nice!", MsgBoxStyle.OkOnly, "Succes!");
    }
    else
    {
        Interaction.MsgBox("FAIL =(", MsgBoxStyle.OkOnly, "Try again!");
    }
}

Copy the "str" part to Visual Studio and make some changes (in Height and Width (and to fit in C#)):

str = Convert.ToString((double)((Convert.ToDouble(Convert.ToString((double)(Convert.ToDouble(Convert.ToString((double)((double)txtUsuario.Text.Length * Convert.ToDouble(str2)))) * 6.0))) / ((double) 100)) + 207));
str = Convert.ToString((double)(Convert.ToDouble(Convert.ToString((double)((Convert.ToDouble(str2) - Convert.ToDouble(str)) + (100 * Convert.ToDouble(str2))))) * 2.0));

Now is the point: if you run this code on your Vista or Seven, you'll get the password 90270 for a 4-digit username.
If you run this on your Windows XP (or in a non-original theme) you'll get the same password, BUT it won't work.
So, you'll have to do this:

double he = (this.Size.Height - this.ClientSize.Height) + 76;
double wi = (this.Size.Width - this.ClientSize.Width) + 201;

str = Convert.ToString((double)((Convert.ToDouble(Convert.ToString((double)(Convert.ToDouble(Convert.ToString((double)((double)txtUsuario.Text.Length * Convert.ToDouble(str2)))) * 6.0))) / ((double)he)) + wi));
str = Convert.ToString((double)(Convert.ToDouble(Convert.ToString((double)((Convert.ToDouble(str2) - Convert.ToDouble(str)) + (he * Convert.ToDouble(str2))))) * 2.0));

This code calculates the difference between the Size and ClientSize of the form in the current theme then, the password for a 4-digit username will be 88465,5918367346.

+----------+
| Igor1201 |
+----------+
|  Brazil  |
+----------+