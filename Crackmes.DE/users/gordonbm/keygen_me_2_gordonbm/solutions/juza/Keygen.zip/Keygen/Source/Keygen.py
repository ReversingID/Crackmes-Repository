def gen1(username, company):
    szStr = []
    szStr.append(str(int(len(company) * 4)))
    szStr.append(str((len(username) * 10)/2) + 'H')
    szStr.append(str(len(username) * pow(10, 6)) + "C")
    szStr.append(str(len(username) + (len(username) * pow(10, 6))) + "XZ")
    szStr.append("Z3F" + str(len(username) + 10) + "GT")
    szStr.append(str((len(username) * 2) + 10) + "QAADA")
    return szStr

def gen2(username, company):
    szStr = []
    szStr.append(str(int(len(company) * 5)))
    szStr.append(str((len(username) * 10)/5) + 'Z')
    szStr.append(str(len(username) * pow(10, 5)) + "9")
    szStr.append(str(len(username) + (len(username) * pow(10, 5))) + "DRM")
    szStr.append("ID66R" + str(len(username) + 10) + "GT")
    szStr.append(str((len(username) * 2) + 10) + "FFQE")
    return szStr

def gen3(username, company):
    szStr = []
    szStr.append(str(int(len(company) * 2)))
    szStr.append(str((len(username) * 10)/2) + 'GBM')
    szStr.append(str(len(username) * pow(10, 2)) + "RLZ")
    szStr.append(str(len(username) + (len(username) * pow(10, 2))) + "FAShL")
    szStr.append("0M" + str(len(username) + 10) + "G")
    szStr.append(str((len(username) * 2) + 10) + "FzZ")
    return szStr


def gen4(username, company):
    szStr = []
    szStr.append(str(int(len(company) * 1)))
    szStr.append(str((len(username) * 10)/2) + 'O')
    szStr.append(str(len(username) * pow(10, 3)) + "CRZ")
    szStr.append(str(len(username) + (len(username) * pow(10, 3))) + "RUS")
    szStr.append("BE" + str(len(username) + 10) + "NED")
    szStr.append(str((len(username) * 2) + 10) + "EnG")
    return szStr

def gen5(username, company):
    szStr = []
    szStr.append(str(int(len(company) * 5)))
    szStr.append(str((len(username) * 10)/10) + 'NI')
    szStr.append(str(len(username) * pow(10, 15)) + "CE")
    szStr.append(str(len(username) + (len(username) * pow(10, 15))) + "CW")
    szStr.append("OrK" + str(len(username) + 10) + "GAeT")
    szStr.append(str((len(username) * 2) + 10) + "QfaE")
    return szStr

def printSerial(szStr):
    serial = ""
    i = 0
    for sz in szStr:
        if not i == 5:
            serial += sz + '-'
        else:
            serial += sz
        i += 1
    print serial
    

print "Keygen for (KeygenMe 2 by GordonBM) by Juza"
username = raw_input("Username: ")
company  = raw_input("Company : ")
print "Serial:\n"
printSerial(gen1(username, company))
printSerial(gen2(username, company))
printSerial(gen3(username, company))
printSerial(gen4(username, company))
printSerial(gen5(username, company))
raw_input()
