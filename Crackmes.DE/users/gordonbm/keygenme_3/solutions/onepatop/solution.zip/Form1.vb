﻿'Create a new VB Windows Form Project, add 2 textboxes, place this in your Form1.vb and
'add System.Management reference to your project
Imports System.Management
Imports Microsoft.VisualBasic.CompilerServices

Public Class Form1


    Private Sub TextBox1_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged


        Dim str As String = String.Empty
        Dim instances As ManagementObjectCollection = New ManagementClass("win32_processor").GetInstances
        Dim obj2 As ManagementObject
        For Each obj2 In instances
            If (str = "") Then
                str = obj2.Properties.Item("processorID").Value.ToString
                Exit For
            End If
        Next

        TextBox2.Text = Conversions.ToString(CInt((((TextBox1.TextLength + &H4851) + Screen.PrimaryScreen.Bounds.Width) + (Screen.PrimaryScreen.Bounds.Height * str.Length))))
        TextBox2.Text = (TextBox2.Text & "-" & str & "-GBM")

    End Sub
End Class
