﻿using System;
using System.Management;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace Keygen
{
    public partial class Form1 : Form
    {
        public string hwid;
        public Form1()
        {
            InitializeComponent();
        }

        private void generate_serialClick(object sender, EventArgs e)
        {
            string hwid="";
            string sol;
            ManagementObjectCollection instances = new ManagementClass("win32_processor").GetInstances();
            foreach (ManagementObject obj in instances)
            {
                hwid = obj.Properties["processorID"].Value.ToString();
                break;
            }

            sol = Convert.ToString((int)(((name.TextLength + 0x4851) + Screen.PrimaryScreen.Bounds.Width) + (Screen.PrimaryScreen.Bounds.Height * hwid.Length)));
            this.serial.Text = sol + "-" + hwid + "-GBM";
        }
   }
}
