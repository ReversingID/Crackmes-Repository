RULES:
-Reflector NOT allowed!
-Include your how-to readme!

You are given a keygen.

There are 2 modes.
The first one is the easiest as someone with a little computer knowledge should easily figure it out.

The second one is a little trickier. But the alghorithm is fairly easy if you can find it.

The purpose is that you make the opposite of this. So I put in the generated key from the original file and your program returns the string.

For example.
GordonBM gives (hardcore mode):
9247109931023928283286380308924708453882326686447837

Engineer it so that when I put in
9247109931023928283286380308924708453882326686447837, its gives me GordonBM

However, the key you get is different every time.


----------------
Sidenote (as info)
----------------
Keys for GordonBM are:
641116731023928251668612737064112073853163603287
86124425640802186481678388198864787591109282536486124161
86096429673488338794267623048609382386448140860967186380579
9285574192828325673488631012925014873852928645101286450729
864816353818647876286127346385317925017329282828092856017
860935139282516364109648612418438504730269285892292828291
etc....



