<<This is my first crack me>>.

find the correct serial.
make a keygen.
have fun :)