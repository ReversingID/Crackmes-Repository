import Tkinter
import sys
import os

class myFrame(Tkinter.Frame):
    
    def __init__(self, master=None):
        Tkinter.Frame.__init__(self, master)   
        self.grid()                    
        self.createWidgets()
    
    #this is the relevant funciton
    def KeyGen(self):
        self.keyEntry.delete(0,len(self.keyEntry.get())+1)
        
        #dictionary for the login encoding
        dicLogin = {'a':'QMD','b':'W6','c':'J8','d':'D2','e':'S4','f':'B5','g':'GM2','h':'QW','i':'N0','j':'HJ','k':'RC',
                    'l':'DU','m':'T8L','n':'JK','o':'D7','p':'E4','q':'8D8','r':'BP','s':'UQ7','t':'ER','u':'FJ6','v':'LZ',
                    'w':'DS1','x':'T7','y':'X0','z':'KJ0','1':'OP','2':'L0','3':'PQ','4':'DJ','5':'VC','6':'7B','7':'SY',
                    '8':'LQ','9':'21','-':'6T','0':'ND','.':'KI',' ':'09','A':'RT','B':'ER','C':'FJ6','D':'LZ','E':'DS1',
                    'F':'T7','G':'X0','H':'KJ0','I':'OP','J':'L0','K':'PQ','L':'QMD','M':'W6','N':'J8','O':'D2','P':'S4',
                    'Q':'B5','R':'GM2','S':'QW','T':'N0','U':'HJ','V':'RC','W':'SY1','X':'LQ3','Y':'21','Z':'6T','!':'ND','^':'KI'}    
    
        #dictionary for the computername encoding
        dicPCName = {'a':'TY','b':'KJ','c':'3I','d':'DA','e':'87','f':'45','g':'ML','h':'QW','i':'4R','j':'0E','k':'F7',
                     'l':'5H','m':'MT','n':'PO','o':'JH','p':'2B','q':'MQ','r':'LL','s':'00','t':'ER','u':'38','v':'M4',
                     'w':'7A','x':'XZ','y':'VD','z':'K0','1':'EN','2':'GR','3':'UJ','4':'FG','5':'3N','6':'W2','7':'M0',
                     '8':'83','9':'RT','-':'9X','0':'F2','.':'U4',' ':'GM','A':'M56','B':'TY','C':'KJ','D':'2B','E':'MQ',
                     'F':'LL','G':'00','H':'ER','I':'38','J':'M4','K':'7A','L':'XZ','M':'VD','N':'K0','O':'EN','P':'GR',
                     'Q':'3I','R':'DA','S':'87','T':'45','U':'ML','V':'QW','W':'4R','X':'0E','Y':'F7','Z':'5H','!':'MT','^':''}
        '''
        Please note that we may encode only chars defined in the dictionaries, i.e.:
        char from 'a' to 'z' lower and upper case, nombers form '0' to '9', '-','.',' '(space) and '^'.
        Every other char wolud be ignored (if you enter "a&b" as login name is the same as entering "ab"
        '''
        key = ""
        
        #get login name
        login = self.nameEntry.get()
        
        #encode login
        for ch in login:
            try: 
                key = key +dicLogin[ch]
            except:
                pass
                
        #get computer name    
        pcname = os.getenv('COMPUTERNAME')
        
        #encode computer name
        tmp = ""
        for c in pcname:
            try: 
                tmp = tmp + dicPCName[c]
                key = key + tmp
            except:
                pass
        
        #return the generated key  in the textbox.   
        self.keyEntry.insert(0,key)    
            
    #create the widgets
    def createWidgets(self):
        self.nameLabel = Tkinter.Label(self,text="name:")
        self.nameLabel.grid(column=0,row=0)
        
        self.nameEntry = Tkinter.Entry(self)
        self.nameEntry.grid(column=1,row=0)
        
        self.keyLabel = Tkinter.Label(self,text="Serial:")
        self.keyLabel.grid(column=0,row=1)

        self.keyEntry = Tkinter.Entry(self)
        self.keyEntry.grid(column=1,row=1)
        
        self.quitButton = Tkinter.Button ( self, text='Quit',command=self.quit )
        self.quitButton.grid(column=1,row=3) 
        
        self.genButton = Tkinter.Button (self,text="Generate",command = self.KeyGen)
        self.genButton.grid(column=0,row=3)
        
if __name__ == "__main__":         
    app = myFrame()                    
    app.master.title("Keygen") 
    app.mainloop() 
