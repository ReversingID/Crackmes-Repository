import os

username = raw_input('Username: ')
compname = os.environ['COMPUTERNAME']

string = 'abcdefghijklmnopqrstuvwxyz123456789-0. ABCDEFGHIJKLMNOPQRSTUVWXYZ!^'
serial = ''
user_strings = 'QMD W6  J8  D2  S4  B5  GM2 QW  N0  HJ  RC  DU  T8L JK  D7  E4  8D8 BP  UQ7 ER  FJ6 LZ  DS1 T7  X0  KJ0 OP  L0  PQ  DJ  VC  7B  SY  LQ  21  6T  ND  KI  09  RT  ER  FJ6 LZ  DS1 T7  X0  KJ0 OP  L0  PQ  QMD W6  J8  D2  S4  B5  GM2 QW  N0  HJ  RC  SY1 LQ3 21  6T  ND  KI'	# from original app
comp_strings = 'TY  KJ  3I  DA  87  45  ML  QW  4R  0E  F7  5H  MT  PO  JH  2B  MQ  LL  00  ER  38  M4  7A  XZ  VD  K0  EN  GR  UJ  FG  3N  W2  M0  83  RT  9X  F2  U4  GM  M56 TY  KJ  2B  MQ  LL  00  ER  38  M4  7A  XZ  VD  K0  EN  GR  3I  DA  87  45  ML  QW  4R  0E  F7  5H  MT'		# from original app

for letter in username:
	for char in string:
		if letter==char:
			idx = string.index(char)*4
			new_string = ''
			for l in user_strings[idx:]:
				if l == ' ':
					break
				new_string += l
			serial += new_string
			break

new_string = ''			
for letter in compname:
	for char in string:
		if letter==char:
			idx = string.index(char)*4
			for l in comp_strings[idx:]:
				if l == ' ':
					break
				new_string += l
			serial += new_string
			break
			
print serial
a = raw_input() # just so that it doesn't close right away.