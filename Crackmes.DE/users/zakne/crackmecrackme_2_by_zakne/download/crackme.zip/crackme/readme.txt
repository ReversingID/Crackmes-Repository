Crackme by ZaKne
crackit

find a serial
make a keygen.