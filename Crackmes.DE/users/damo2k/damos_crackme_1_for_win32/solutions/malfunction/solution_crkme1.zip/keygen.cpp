/*
keygen for crackme#1 by Damo2k, written by malfunction (c) 2008
*/

#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

void generateSerial(char *buffer)
{
	char *alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	
	buffer[4] = alphabet[ rand() % 23 ];
	buffer[5] = alphabet[ rand() % 23 ];
	buffer[0] = char( (int(buffer[4]) + int(buffer[5])) / 2 );
	buffer[9] = buffer[0] + 3;
	buffer[8] = alphabet[ rand() % 12 ];
	buffer[1] = buffer[8] + 14;
	buffer[2] = alphabet[ rand() % 6 ];
	buffer[7] = buffer[2] + 20;
	buffer[6] = alphabet[ rand() % 20 ];
	buffer[3] = buffer[6] + 6;	
	buffer[10] = 0;
}

void printCopyright()
{
	cout << "keygen for: crackme#1 by Damo2k\n";
	cout << "written by malfunction (c) 2008\n" << endl;
}

int main(int argc, char *argv[])
{
	srand( time(0) );
	printCopyright();
	
	char serialBuffer[11];
	
	do
	{
		for(int i=0; i<10; i++)
		{
			generateSerial(serialBuffer);
			cout << serialBuffer << "\n";
		}
		cout << "\n(enter n for another 10 serial numbers or q to quit)" << flush;
	} while( getchar() != 'q' );

	return 0;
}
