// Damo's crackme no1 for Win32.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <string.h>
#include "windows.h"
#include <time.h>


char serial[10];

int getnum(int min,int max) 
{
	int u = (double)rand() / (RAND_MAX + 1) * (max - min)
            + min;
	return u;
}

void Keygen() {

	int min=0x20;
	int max=0x60;
	
	srand((unsigned)time(NULL));
	//srand(0);
	serial[4]=getnum(min,max-3);
	serial[5]=getnum(min,max-3);
	serial[0]=(serial[4]+serial[5])/2;
	serial[1]=getnum(min+14,max);
	serial[2]=getnum(min,max-20);
	serial[3]=getnum(min+6,max);
	serial[9]=serial[0]+3;
	serial[8]=serial[1]-14;
	serial[7]=serial[2]+20;
	serial[6]=serial[3]-6;
	//serial[10]=getnum(min,max);
	
}

int _tmain(int argc, _TCHAR* argv[])
{
	Keygen();
	printf("Your key=[%s]",serial);
	return 0;
//	int index; // esi@1
//  LPSTR strSerial; // edx@2
//  LPSTR v5; // ebx@2
//  int result; // eax@3
//  char cTmp; // al@5
//  LPSTR realserial; // ecx@9
//
//  index = 0;
//  if ( argc <= 1 )
//  {
//    printf("Usage: %s <serial>\n", *argv);
//    result = 0;
//  }
//  else
//  {
//    v5 = (LPSTR)argv;
//    strSerial = (LPSTR)*(argv + 1);
//	//strSerial=(LPSTR)serial;
//    if ( strlen(*(argv + 1)) != 10 )
//      goto LABEL_18;
//	
//	strSerial=strupr(strSerial);
//    realserial = (LPSTR)*((DWORD *)v5 + 1);
//    if ( *realserial != *(realserial + 9) - 3
//      || *(realserial + 1) != *(realserial + 8) + 14
//      || *(realserial + 2) != *(realserial + 7) - 20
//      || *(realserial + 3) != *(realserial + 6) + 6
//      || (*(realserial + 4) + *(realserial + 5)) / 2 != *realserial )
//    {
//LABEL_18:
//      printf("%s\n", "Bad Serial!");
//      result = 0;
//    }
//    else
//    {
//      printf("%s\n", "Good Serial!");
//      result = 0;
//    }
//  }
//  return result;
}

