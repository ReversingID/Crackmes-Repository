import random

def genPassword():
	c = []
	c.append(int(round(random.uniform(65,80))))
	c.append(int(round(random.uniform(65,90))))
	c.append(int(round(random.uniform(65,74))))
	c.append(int(round(random.uniform(65,90))))
	c.append(int(round(random.uniform(65,90))))
	c.append(c[0] * 2 - c[4])
	c.append(c[3] - 0x6)
	c.append(c[2] + 0x14)
	c.append(c[1] - 0xe)
	c.append(c[0] + 0x3)
	
	string = ""
	for elem in c:
		string += chr(elem)
	return string


print "=== KeyGen for DAMO's Crackme1 ==="
print "== Written by San_SS! from the Cert Team =="
print "\nPassword is: " + genPassword()
print "\nRemember escape the needed characters to make the password work!"


