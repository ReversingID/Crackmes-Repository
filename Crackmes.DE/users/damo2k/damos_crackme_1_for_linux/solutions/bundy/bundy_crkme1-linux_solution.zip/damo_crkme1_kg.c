/*
bundy's keygen for DaMo's crkme1-linux
- default serial will contain only uppercase letters
- it's possible to enhance the output character set via editing START_CHAR

Copyright (C) 2008, bundy
*/

#include <stdio.h>
#include <stdlib.h>

#define START_CHAR 'A'
#define NUMBER_OF_CHARS ('Z' - START_CHAR + 1)
#define DIFFERENCE1 3
#define DIFFERENCE2 0xe
#define DIFFERENCE3 0x14
#define DIFFERENCE4 6
#define SERIAL_LEN 10

int main(void)
{
    char serial[SERIAL_LEN];
    char c1, c;
    int i;

    srand(time(0));
    c1 = rand() % (NUMBER_OF_CHARS - DIFFERENCE1);
    // first char & tenth
    serial[0] = c1;
    serial[9] = c1 + DIFFERENCE1;

    c = rand() % (NUMBER_OF_CHARS - DIFFERENCE2);
    // second & nineth
    serial[1] = c + DIFFERENCE2;
    serial[8] = c;

    c = rand() % (NUMBER_OF_CHARS - DIFFERENCE3);
    // third & eighth
    serial[2] = c;
    serial[7] = c + DIFFERENCE3;

    c = rand() % (NUMBER_OF_CHARS - DIFFERENCE4);
    // fourth & seveth
    serial[3] = c + DIFFERENCE4;
    serial[6] = c;

    c = rand() % (c1 < (NUMBER_OF_CHARS - c1) ? c1 : NUMBER_OF_CHARS - c1 );
    // fifth & sixth serial and their divided sum by 2 have to match 1st char
    // so let's substract a random number from fifth and add the same number to sixth
    // the random number is the smaller difference to edges from <0, NUMBER_OF_CHARS)
    // so we don't have a char outside of 'START_CHAR'-Z array
    serial[4] = c1 - c;
    serial[5] = c1 + c;

    for (i = 0; i < SERIAL_LEN; i++)
    {
        serial[i] += START_CHAR;
    }
    printf("Serial: %s\n", serial);

    return 0;
}
