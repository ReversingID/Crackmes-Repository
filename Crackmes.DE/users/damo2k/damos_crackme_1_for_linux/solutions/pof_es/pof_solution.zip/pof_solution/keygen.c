/* Key generator for Damo2k's crackme #1 for linux @ crackmes.de  */
/* http://www.crackmes.de/users/damo2k/damos_crackme_1_for_linux/ */
/*      solution by pof<eslack.org> - (c) pof January 2008        */

#include <sys/times.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

/* returns random number seed, run like this: srandom(RandomSeed()); */
int RandomSeed()
{
	struct tms timeinfo;
	return times(&timeinfo);
}

/* verify char is between A-Z a-z */
int IsPrintableChar(unsigned char value)
{

	if (( value < 0x41 || value > 0x5a ) && 
	    ( value < 0x61 || value > 0x7a )) return 0;

	else return 1;
}

/* returns a random char between a-z A-Z */
int RandomChar()
{
	int j;
	do j = 1 + (int) ((double)(0x7a)*(rand() / (RAND_MAX + 1.0)));
	while (!IsPrintableChar(j));
	return j;
}

/* given a char, return its uppercase equivalent */
int MakeUpperCase(unsigned char value)
{
	if (( value < 0x61 )) return value;
	else return value-0x20;
}


/* Check if both values are printable chars and the operation with the number is correct */
int check(unsigned char val1, unsigned char val2, int num)
{
	if (IsPrintableChar(val1) && IsPrintableChar(val2))
		if (MakeUpperCase(val1)+num == MakeUpperCase(val2)) return 1;

	return 0;
}


int main()
{

	int i;
	unsigned char key[10];
	unsigned char eax, edx;


	printf ("Damo crkme1 Key generator by pof\n");
	srandom(RandomSeed());

	do {
		key[0] = RandomChar(); 
		key[9] = MakeUpperCase(key[0])+0x3;
	} while (!check(key[0],key[9],0x3));


	do {
		key[1] = RandomChar();
		key[8] = MakeUpperCase(key[1])-0xe;
	} while (!check(key[1],key[8],-0xe));


	do {
		key[2] = RandomChar();
		key[7] = key[2]+0x14;
	} while (!check(key[2],key[7],0x14));


	do {
		key[3] = RandomChar();
		key[6] = MakeUpperCase(key[3])-0x6; 
	} while (!check(key[3],key[6],-0x6));


	do {
		key[4]=RandomChar();
		key[5]=RandomChar();

		edx = MakeUpperCase(key[4]);
		eax = MakeUpperCase(key[5]);
		edx += eax;
		edx = edx >> 0x1;
		eax = MakeUpperCase(key[0]);

	} while ( eax != edx );


	printf ("Key: ");
	for (i=0;i<10;i++)
	{
		printf("%c",key[i]);
	}
	printf ("\n");

	return 0;
}
