Hi there

This is my fourth keygenme, but actually it's the first 'real' one.
I wrote this little thingie after having studied some commercial
protections. It uses a different approach than most programs. I'm
a nice guy though and I didn't make it that hard. Maybe the next
one will be a little tougher!

The goal is to code a keygen, patches are not allowed. I'm no fan
of patching anyway. But be warned: It's not that easy! I hope you
have some fun with my little challenge.

Cheers

figugegl
figugegl@bigfoot.com