#include <windows.h>
#include "resource.h"
#include "md5c.c"

HINSTANCE hInst;
MD5_CTX context;

unsigned char szName[0x21]={0},szSerial[0x18]={0},szHash[0x11]={0};
unsigned char szTemp[0x11]={0};
unsigned char * lpSubKey="Software\\Microsoft\\Windows\\CurrentVersion";
unsigned char * lpValueName1="ProductId";
unsigned char * lpValueName2="RegisteredOwner";

BYTE dwOrder[0x80][0x10]={0};

void cal_order()
{//get order 0 form your hardware information
	HKEY hKey ;
	int j=0x40;
	int i,k;
	unsigned char lpData[0x41]={0};
	unsigned char lpTemp1[0x41]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'D','A','T','A'	};
	unsigned char lpTemp2[0x41]={0};
	DWORD temp1,temp2,temp3,temp4;
	BYTE  temp_1,temp_2,temp_3;
if(RegOpenKeyEx(HKEY_LOCAL_MACHINE,lpSubKey,0,1,&hKey)==0)
{	
		RegQueryValueEx(hKey,lpValueName1,0,0,lpData,&j);
		lpTemp1[0xA]=lstrlen(lpData);
		if(lpTemp1[0xA]==0)
		{
			wsprintf(lpTemp1,"%X",0x12345678);
		}
		if(lpTemp1[0xA]!=0)
		{
			lstrcpy(lpTemp1,lpData);
			if(lpTemp1[0xA]<8)  
				{
					i=lpTemp1[0xA];
					k=lpTemp1[0xA];
					for(;i<8;i++)
						lpTemp1[i]=lpTemp1[i-k];
				}
			if(lpTemp1[0xA]>=8) lpTemp1[8]=0;
		}
		lpData[0]=0;
		RegQueryValueEx(hKey,lpValueName2,0,0,lpData,&j);
		lpTemp1[0xA]=lstrlen(lpData);
			if(lpTemp1[0xA]==0)
		{
			wsprintf(lpTemp2,"%X",0x1B3A0C14);
		}
		if(lpTemp1[0xA]!=0)
		{
			lstrcpy(lpTemp2,lpData);
			if(lpTemp1[0xA]<8)  
				{
					i=lpTemp1[0xA];
					k=lpTemp1[0xA];
					for(;i<8;i++)
						lpTemp2[i]=lpTemp2[i-k];
				}
			if(lpTemp1[0xA]>=8) lpTemp2[8]=0;
		}

		RegCloseKey(hKey);
}
		__asm
		{
                xor     ebx, ebx

loc_4024A8:                  
                mov     eax, ebx
                xor     edx, edx
                test    eax, eax
                setl    dl
                add     eax, edx
                sar     eax, 1
                mov     edi, eax
                mov     esi, offset dwOrder
                movsx   edx, [edi+lpTemp2]
                mov     temp1, edx
                mov     eax, ebx
                inc     eax
                mov     temp2, eax
                cdq
                xor     eax, edx
                sub     eax, edx
                and     eax, 1
                xor     eax, edx
                sub     eax, edx
                mov     ecx, eax
                shl     ecx, 2
                mov     edx, temp1
                sar     edx, cl
                and     edx, 0Fh
                mov     temp3, edx
                mov     ecx, 7
                sub     ecx, edi
                movsx   edi, [ecx+lpTemp1]
                mov     eax, ebx
                mov     temp4, eax
                cdq
                xor     eax, edx
                sub     eax, edx
                and     eax, 1
                xor     eax, edx
                sub     eax, edx
                mov     ecx, eax
                shl     ecx, 2
                shl     edi, cl
                and     edi, 0F0h
                mov     edx, temp3
                or      edx, edi
                movsx   edi, [ebx+lpTemp1+10h]
                xor     edx, edi
                mov     [esi+ebx], dl
                inc     ebx
                cmp     ebx, 10h
                jl      loc_4024A8

			}
//reconstruct
		for(i=0;i<0x80;i++)
		{
			temp_2=dwOrder[i][0xF];
			for(j=0xF;j>=0;j--)
			{
				if(j==0) temp_1=temp_2;
				else	 temp_1=dwOrder[i][j-1];
				temp_1=temp_1&1;
				temp_1=temp_1<<7;
				temp_3=dwOrder[i][j];
				temp_3=temp_3>>1;
				temp_1=temp_1|temp_3;
				dwOrder[i+1][j]=temp_1;
			}
		}


}

BOOL CALLBACK DlgProc (HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
int lenName,i,j;
BYTE temp,temp1,temp2,temp3;
switch (uMsg)
{

   case WM_CLOSE:
		EndDialog(hWnd,0);
		break;

   case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDC_Exit:
        EndDialog(hWnd,0);
		break;
		case IDC_Generate:
			lenName=GetDlgItemText(hWnd,IDC_Name, szName, 0x20);
			if (lenName<=4) 
			{
				MessageBox(hWnd,"Tooooooooooooo short UserName!",":-(",MB_ICONINFORMATION);
		        break;	
			}
//Calculate the order for swap data
			cal_order(); 

//MD5 Hash function			
			MD5Init(&context);
			MD5Update(&context, szName, lenName);
			MD5Final(szHash, &context);
			for(i=0;i<0x10;i++)
				{
					temp=szHash[i];
					temp=temp&0xF;
					if(temp<=9)		temp+=0x30;
					else        	temp+=0x37;
					szTemp[i]=temp;
				}
//Swap data following the order defined in dwOrder
			for(i=0x7F;i>=0;i--)
				{
					for(j=0xF;j>=0;j--)
					{
						temp1=dwOrder[i][j];
						temp2=temp1&0xF;
						temp3=temp1>>4;
						temp3=temp3&0xF;
						temp=szTemp[temp2];
						szTemp[temp2]=szTemp[temp3];
						szTemp[temp3]=temp;
					}
				}

//Final tranformation with logical arithmatic
			for(i=0;i<4;i++)
			{
				szSerial[6*i+0]=szTemp[4*i+0];
				szSerial[6*i+1]=szTemp[4*i+1];
				szSerial[6*i+2]=szTemp[4*i+2];
				szSerial[6*i+3]=szTemp[4*i+3];
				szSerial[6*i+4]=(((szTemp[4*i+0]&szTemp[4*i+1])|szTemp[4*i+2])^szTemp[4*i+3])%26+0x41;
				szSerial[6*i+5]=0x2D;
			}
			szSerial[0x17]=0;
//Output
			SetDlgItemText(hWnd,IDC_Serial,szSerial);
			break;
		}
		break;
	case WM_INITDIALOG:
		SendMessage(hWnd,WM_SETICON,ICON_SMALL,(LPARAM) LoadIcon(hInst,MAKEINTRESOURCE(ICO_MAIN)));
        break;
}

return 0;
}

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,PSTR szCmdLine, int iCmdShow)
{

	hInst=hInstance;
	DialogBoxParam(hInstance,MAKEINTRESOURCE(DLG_MAIN),0,(DLGPROC)DlgProc,0);
	return 0;
}