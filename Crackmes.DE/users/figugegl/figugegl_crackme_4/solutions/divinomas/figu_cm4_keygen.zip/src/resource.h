//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Dialog.rc
//
#define ICO_MAIN                        101
#define DLG_MAIN                        101
#define IDC_Name                        1001
#define IDC_Serial                      1003
#define IDC_Generate                    1004
#define IDC_Exit                        1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
