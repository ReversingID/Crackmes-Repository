﻿using SmartAssembly.Zip;
using System;
using System.Collections;
using System.IO;
using System.Reflection;
using System.Text;

// Just Copy & Paste from ILSpy
namespace SmartAssembly.StringsEncoding
{
    public sealed class Strings
    {
        private static string MustUseCache;
        private static string OffsetValue;
        private static byte[] bytes;
        private static Hashtable hashtable;
        private static bool cacheStrings;
        private static int offset;
        public static string Get(int stringID)
        {
            stringID -= Strings.offset;
            if (Strings.cacheStrings)
            {
                string text = (string)Strings.hashtable[stringID];
                if (text != null)
                {
                    return text;
                }
            }
            int num = 0;
            int index = stringID;
            int num2 = (int)Strings.bytes[index++];
            if ((num2 & 128) == 0)
            {
                num = num2;
                if (num == 0)
                {
                    return string.Empty;
                }
            }
            else
            {
                if ((num2 & 64) == 0)
                {
                    num = ((num2 & 63) << 8) + (int)Strings.bytes[index++];
                }
                else
                {
                    num = ((num2 & 31) << 24) + (int)((int)Strings.bytes[index++] << 16) + (int)((int)Strings.bytes[index++] << 8) + (int)Strings.bytes[index++];
                }
            }
            string result;
            try
            {
                byte[] array = Convert.FromBase64String(Encoding.UTF8.GetString(Strings.bytes, index, num));
                string text2 = string.Intern(Encoding.UTF8.GetString(array, 0, array.Length));
                if (Strings.cacheStrings)
                {
                    try
                    {
                        Strings.hashtable.Add(stringID, text2);
                    }
                    catch
                    {
                    }
                }
                result = text2;
            }
            catch
            {
                result = null;
            }
            return result;
        }

        // Changed to load Resource fom external Assembly
        public static void Init(Assembly assembly)
        {
            Strings.MustUseCache = "1";
            Strings.OffsetValue = "93";
            Strings.bytes = null;
            Strings.hashtable = null;
            Strings.cacheStrings = false;
            Strings.offset = 0;
            if (Strings.MustUseCache == "1")
            {
                Strings.cacheStrings = true;
                Strings.hashtable = new Hashtable();
            }
            Strings.offset = Convert.ToInt32(Strings.OffsetValue);
            using (Stream manifestResourceStream = assembly.GetManifestResourceStream("{d7ec8fbf-21b7-4950-a936-122b664a514c}"))
            {
                int num = Convert.ToInt32(manifestResourceStream.Length);
                byte[] buffer = new byte[(int)checked((uint)num)];
                manifestResourceStream.Read(buffer, 0, num);
                Strings.bytes = SimpleZip.Unzip(buffer);
                manifestResourceStream.Close();
            }
        }
    }
}
