﻿namespace SmartAssembly.Zip
{
    using System;
    using System.Security.Cryptography;
    using System.Reflection;

    public sealed class DESCryptoIndirector : IDisposable
    {
        private readonly Type m_DcspType = Assembly.Load("mscorlib").GetType("System.Security.Cryptography.DESCryptoServiceProvider");
        private readonly object m_DESCryptoServiceProvider;

        public DESCryptoIndirector()
        {
            this.m_DESCryptoServiceProvider = Activator.CreateInstance(this.m_DcspType);
        }

        public void Clear()
        {
            this.m_DcspType.GetMethod("Clear").Invoke(this.m_DESCryptoServiceProvider, new object[0]);
        }

        public void Dispose()
        {
            this.Clear();
        }

        public ICryptoTransform GetDESCryptoTransform(byte[] key, byte[] iv, bool decrypt)
        {
            this.m_DcspType.GetProperty("Key").GetSetMethod().Invoke(this.m_DESCryptoServiceProvider, new object[] { key });
            this.m_DcspType.GetProperty("IV").GetSetMethod().Invoke(this.m_DESCryptoServiceProvider, new object[] { iv });
            return (ICryptoTransform) this.m_DcspType.GetMethod(decrypt ? "CreateDecryptor" : "CreateEncryptor", new Type[0]).Invoke(this.m_DESCryptoServiceProvider, new object[0]);
        }
    }
}

