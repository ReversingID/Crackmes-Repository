﻿namespace SmartAssembly.Zip
{
    using System;
    using System.IO;
    using System.Reflection;
    using System.Security.Cryptography;

    public sealed class AESCryptoIndirector : IDisposable
    {
        private readonly Type m_AcspType;
        private readonly object m_AESCryptoServiceProvider;

        public AESCryptoIndirector()
        {
            try
            {
                this.m_AcspType = Assembly.Load("System.Core, Version=2.0.5.0, Culture=neutral, PublicKeyToken=7cec85d7bea7798e").GetType("System.Security.Cryptography.AesManaged");
            }
            catch (FileNotFoundException)
            {
                this.m_AcspType = Assembly.Load("mscorlib").GetType("System.Security.Cryptography.RijndaelManaged");
            }
            this.m_AESCryptoServiceProvider = Activator.CreateInstance(this.m_AcspType);
        }

        public void Clear()
        {
            this.m_AcspType.GetMethod("Clear").Invoke(this.m_AESCryptoServiceProvider, new object[0]);
        }

        public void Dispose()
        {
            this.Clear();
        }

        public ICryptoTransform GetAESCryptoTransform(byte[] key, byte[] iv, bool decrypt)
        {
            this.m_AcspType.GetProperty("Key").GetSetMethod().Invoke(this.m_AESCryptoServiceProvider, new object[] { key });
            this.m_AcspType.GetProperty("IV").GetSetMethod().Invoke(this.m_AESCryptoServiceProvider, new object[] { iv });
            return (ICryptoTransform) this.m_AcspType.GetMethod(decrypt ? "CreateDecryptor" : "CreateEncryptor", new Type[0]).Invoke(this.m_AESCryptoServiceProvider, new object[0]);
        }
    }
}

