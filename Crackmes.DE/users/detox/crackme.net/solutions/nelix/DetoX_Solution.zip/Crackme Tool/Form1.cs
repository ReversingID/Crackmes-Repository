﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.IO;


// Extracted with .net Reflector, ILSpy's exported Code don't work 
using SmartAssembly.Zip;

using SmartAssembly.StringsEncoding;


using System.Diagnostics;


namespace DeToXs_Crackme_Tool
{
    public partial class MainForm : Form
    {
        Assembly crackmeAssembly;
        String assemblyPath;

        public MainForm()
        {
            InitializeComponent();

        }

        /// <summary>
        /// Decode Strings using SmartAssembly.StringsEncoding from the crackme
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_GetString_Click(object sender, EventArgs e)
        {
            if (crackmeAssembly == null)
            {
                MessageBox.Show("Please load crackme Assembly");
                return;
            }

            int stringID;
            if (String.IsNullOrWhiteSpace(textBox_StringID.Text) || !int.TryParse(textBox_StringID.Text, out stringID))
            {
                MessageBox.Show("Please enter a StringID.");
                return;
            }

            textBox_String.Text = Strings.Get(stringID);
        }

        /// <summary>
        /// Load the Assembly
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_Load_Click(object sender, EventArgs e)
        {
            OpenFileDialog fileDialog = new OpenFileDialog();
            fileDialog.Multiselect = false;
            fileDialog.FileName = "Crackme.exe";

            if (fileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                try
                {
                    crackmeAssembly = Assembly.LoadFrom(fileDialog.FileName);

                    if (crackmeAssembly.FullName != "Anti-Tampering, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null")
                        throw new Exception();

                    // Init Strings Class, changed to load external resources
                    Strings.Init(crackmeAssembly);
                    // Standard Password
                    textBox_Password.Text = Strings.Get(516);

                    textBox_Path.Text = fileDialog.FileName;
                    assemblyPath = fileDialog.FileName;
                }
                catch
                {
                    MessageBox.Show("Please load DeToX crackme!");
                }
            }
        }

        /// <summary>
        /// Unzip Resources from Crackme
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_Unzip_Click(object sender, EventArgs e)
        {
            if (crackmeAssembly == null)
            {
                MessageBox.Show("Please load crackme Assembly");
                return;
            }

            FolderBrowserDialog folderDialog = new FolderBrowserDialog();
            folderDialog.Description = "Select folder to save extracted resource files";

            if (folderDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                foreach (string resourceName in crackmeAssembly.GetManifestResourceNames())
                {
                    using (Stream stream = crackmeAssembly.GetManifestResourceStream(resourceName))
                    {
                        byte[] buffer = new byte[stream.Length];
                        stream.Read(buffer, 0, (int)stream.Length);

                        byte[] unziped = SimpleZip.Unzip(buffer);

                        using (FileStream fileStream = new FileStream(assemblyPath, FileMode.Create))
                        {
                            fileStream.Write(unziped, 0, unziped.Length);
                            fileStream.Close();
                        }

                    }
                }
            }
        }

        // En-/Decrypt Strings with RC4
        private void button1_Click(object sender, EventArgs e)
        {
            if (crackmeAssembly == null)
            {
                MessageBox.Show("Please load crackme Assembly");
                return;
            }
 
            textBox_String.Text = Crypt.RC4(textBox_String.Text, textBox_Password.Text);
        }

        // Calculate MD5sum for the Assembly
        private void button3_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrWhiteSpace(assemblyPath))
            {
                MessageBox.Show("Please load crackme Assembly");
                return;
            }

            textBox_Password.Text = textBox_String.Text = Crypt.MD5Calc(assemblyPath);
             
        }
        
    }
}
