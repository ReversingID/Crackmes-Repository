﻿namespace DeToXs_Crackme_Tool
{
    partial class MainForm
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxStringEncoding = new System.Windows.Forms.GroupBox();
            this.button_GetString = new System.Windows.Forms.Button();
            this.textBox_String = new System.Windows.Forms.TextBox();
            this.textBox_StringID = new System.Windows.Forms.TextBox();
            this.label_String = new System.Windows.Forms.Label();
            this.label_StringID = new System.Windows.Forms.Label();
            this.groupBox_LoadCrackme = new System.Windows.Forms.GroupBox();
            this.textBox_Path = new System.Windows.Forms.TextBox();
            this.button_Load = new System.Windows.Forms.Button();
            this.label_Path = new System.Windows.Forms.Label();
            this.button_Unzip = new System.Windows.Forms.Button();
            this.button_RC4_Encrypt = new System.Windows.Forms.Button();
            this.button_MD5 = new System.Windows.Forms.Button();
            this.textBox_Password = new System.Windows.Forms.TextBox();
            this.label_Password = new System.Windows.Forms.Label();
            this.groupBoxStringEncoding.SuspendLayout();
            this.groupBox_LoadCrackme.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxStringEncoding
            // 
            this.groupBoxStringEncoding.Controls.Add(this.label_Password);
            this.groupBoxStringEncoding.Controls.Add(this.textBox_Password);
            this.groupBoxStringEncoding.Controls.Add(this.button_MD5);
            this.groupBoxStringEncoding.Controls.Add(this.button_RC4_Encrypt);
            this.groupBoxStringEncoding.Controls.Add(this.button_GetString);
            this.groupBoxStringEncoding.Controls.Add(this.textBox_String);
            this.groupBoxStringEncoding.Controls.Add(this.textBox_StringID);
            this.groupBoxStringEncoding.Controls.Add(this.label_String);
            this.groupBoxStringEncoding.Controls.Add(this.label_StringID);
            this.groupBoxStringEncoding.Location = new System.Drawing.Point(12, 88);
            this.groupBoxStringEncoding.Name = "groupBoxStringEncoding";
            this.groupBoxStringEncoding.Size = new System.Drawing.Size(445, 131);
            this.groupBoxStringEncoding.TabIndex = 0;
            this.groupBoxStringEncoding.TabStop = false;
            this.groupBoxStringEncoding.Text = "Strings";
            // 
            // button_GetString
            // 
            this.button_GetString.Location = new System.Drawing.Point(142, 32);
            this.button_GetString.Name = "button_GetString";
            this.button_GetString.Size = new System.Drawing.Size(75, 26);
            this.button_GetString.TabIndex = 4;
            this.button_GetString.Text = "Get String";
            this.button_GetString.UseVisualStyleBackColor = true;
            this.button_GetString.Click += new System.EventHandler(this.button_GetString_Click);
            // 
            // textBox_String
            // 
            this.textBox_String.Location = new System.Drawing.Point(6, 71);
            this.textBox_String.Name = "textBox_String";
            this.textBox_String.Size = new System.Drawing.Size(433, 20);
            this.textBox_String.TabIndex = 3;
            // 
            // textBox_StringID
            // 
            this.textBox_StringID.Location = new System.Drawing.Point(6, 32);
            this.textBox_StringID.Name = "textBox_StringID";
            this.textBox_StringID.Size = new System.Drawing.Size(128, 20);
            this.textBox_StringID.TabIndex = 2;
            // 
            // label_String
            // 
            this.label_String.AutoSize = true;
            this.label_String.Location = new System.Drawing.Point(6, 55);
            this.label_String.Name = "label_String";
            this.label_String.Size = new System.Drawing.Size(37, 13);
            this.label_String.TabIndex = 1;
            this.label_String.Text = "String:";
            // 
            // label_StringID
            // 
            this.label_StringID.AutoSize = true;
            this.label_StringID.Location = new System.Drawing.Point(6, 16);
            this.label_StringID.Name = "label_StringID";
            this.label_StringID.Size = new System.Drawing.Size(51, 13);
            this.label_StringID.TabIndex = 0;
            this.label_StringID.Text = "String ID:";
            // 
            // groupBox_LoadCrackme
            // 
            this.groupBox_LoadCrackme.Controls.Add(this.label_Path);
            this.groupBox_LoadCrackme.Controls.Add(this.button_Load);
            this.groupBox_LoadCrackme.Controls.Add(this.textBox_Path);
            this.groupBox_LoadCrackme.Location = new System.Drawing.Point(12, 12);
            this.groupBox_LoadCrackme.Name = "groupBox_LoadCrackme";
            this.groupBox_LoadCrackme.Size = new System.Drawing.Size(445, 70);
            this.groupBox_LoadCrackme.TabIndex = 1;
            this.groupBox_LoadCrackme.TabStop = false;
            this.groupBox_LoadCrackme.Text = "Load Crackme";
            // 
            // textBox_Path
            // 
            this.textBox_Path.Location = new System.Drawing.Point(6, 33);
            this.textBox_Path.Name = "textBox_Path";
            this.textBox_Path.Size = new System.Drawing.Size(393, 20);
            this.textBox_Path.TabIndex = 0;
            // 
            // button_Load
            // 
            this.button_Load.Location = new System.Drawing.Point(405, 33);
            this.button_Load.Name = "button_Load";
            this.button_Load.Size = new System.Drawing.Size(34, 20);
            this.button_Load.TabIndex = 1;
            this.button_Load.Text = "...";
            this.button_Load.UseVisualStyleBackColor = true;
            this.button_Load.Click += new System.EventHandler(this.button_Load_Click);
            // 
            // label_Path
            // 
            this.label_Path.AutoSize = true;
            this.label_Path.Location = new System.Drawing.Point(6, 16);
            this.label_Path.Name = "label_Path";
            this.label_Path.Size = new System.Drawing.Size(86, 13);
            this.label_Path.TabIndex = 2;
            this.label_Path.Text = "Path to Crackme";
            // 
            // button_Unzip
            // 
            this.button_Unzip.Location = new System.Drawing.Point(154, 236);
            this.button_Unzip.Name = "button_Unzip";
            this.button_Unzip.Size = new System.Drawing.Size(158, 36);
            this.button_Unzip.TabIndex = 2;
            this.button_Unzip.Text = "Unzip Resource Files";
            this.button_Unzip.UseVisualStyleBackColor = true;
            this.button_Unzip.Click += new System.EventHandler(this.button_Unzip_Click);
            // 
            // button_RC4_Encrypt
            // 
            this.button_RC4_Encrypt.Location = new System.Drawing.Point(55, 96);
            this.button_RC4_Encrypt.Name = "button_RC4_Encrypt";
            this.button_RC4_Encrypt.Size = new System.Drawing.Size(133, 26);
            this.button_RC4_Encrypt.TabIndex = 5;
            this.button_RC4_Encrypt.Text = "RC4 En/Decryption";
            this.button_RC4_Encrypt.UseVisualStyleBackColor = true;
            this.button_RC4_Encrypt.Click += new System.EventHandler(this.button1_Click);
            // 
            // button_MD5
            // 
            this.button_MD5.Location = new System.Drawing.Point(242, 97);
            this.button_MD5.Name = "button_MD5";
            this.button_MD5.Size = new System.Drawing.Size(118, 28);
            this.button_MD5.TabIndex = 7;
            this.button_MD5.Text = "MD5 for Crackme";
            this.button_MD5.UseVisualStyleBackColor = true;
            this.button_MD5.Click += new System.EventHandler(this.button3_Click);
            // 
            // textBox_Password
            // 
            this.textBox_Password.Location = new System.Drawing.Point(223, 36);
            this.textBox_Password.Name = "textBox_Password";
            this.textBox_Password.Size = new System.Drawing.Size(199, 20);
            this.textBox_Password.TabIndex = 8;
            // 
            // label_Password
            // 
            this.label_Password.AutoSize = true;
            this.label_Password.Location = new System.Drawing.Point(223, 20);
            this.label_Password.Name = "label_Password";
            this.label_Password.Size = new System.Drawing.Size(101, 13);
            this.label_Password.TabIndex = 9;
            this.label_Password.Text = "Password (for RC4):";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(468, 295);
            this.Controls.Add(this.button_Unzip);
            this.Controls.Add(this.groupBox_LoadCrackme);
            this.Controls.Add(this.groupBoxStringEncoding);
            this.Name = "MainForm";
            this.Text = "Nelix Tool for DeToX\'s Crackme";
            this.groupBoxStringEncoding.ResumeLayout(false);
            this.groupBoxStringEncoding.PerformLayout();
            this.groupBox_LoadCrackme.ResumeLayout(false);
            this.groupBox_LoadCrackme.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxStringEncoding;
        private System.Windows.Forms.Button button_GetString;
        private System.Windows.Forms.TextBox textBox_String;
        private System.Windows.Forms.TextBox textBox_StringID;
        private System.Windows.Forms.Label label_String;
        private System.Windows.Forms.Label label_StringID;
        private System.Windows.Forms.GroupBox groupBox_LoadCrackme;
        private System.Windows.Forms.Label label_Path;
        private System.Windows.Forms.Button button_Load;
        private System.Windows.Forms.TextBox textBox_Path;
        private System.Windows.Forms.Button button_Unzip;
        private System.Windows.Forms.Button button_MD5;
        private System.Windows.Forms.Button button_RC4_Encrypt;
        private System.Windows.Forms.Label label_Password;
        private System.Windows.Forms.TextBox textBox_Password;
    }
}

