﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualBasic;
using System.Threading;
using System.Reflection;
using System.IO;
using System.Security.Cryptography;

namespace DeToXs_Crackme_Tool
{
    static class Crypt
    {
        // Anti_Tamp.Security.Encryptions
        public static string RC4(string message, string password)
        {
            checked
            {
                int num = 0;
                int num2 = 0;
                StringBuilder stringBuilder = new StringBuilder();
                string result = string.Empty;
                int[] array = new int[257];
                int[] array2 = new int[257];
                int length = password.Length;
                int i = 0;
                while (i <= 255)
                {
                    char @string = password.Substring(i % length, 1).ToCharArray()[0];
                    array2[i] = Strings.Asc(@string);
                    array[i] = i;
                    Math.Max(Interlocked.Increment(ref i), i - 1);
                }
                int num3 = 0;
                int j = 0;
                while (j <= 255)
                {
                    num3 = (num3 + array[j] + array2[j]) % 256;
                    int num4 = array[j];
                    array[j] = array[num3];
                    array[num3] = num4;
                    Math.Max(Interlocked.Increment(ref j), j - 1);
                }
                i = 1;
                while (i <= message.Length)
                {
                    num = (num + 1) % 256;
                    num2 = (num2 + array[num]) % 256;
                    int num5 = array[num];
                    array[num] = array[num2];
                    array[num2] = num5;
                    int num6 = array[(array[num] + array[num2]) % 256];
                    char string2 = message.Substring(i - 1, 1).ToCharArray()[0];
                    num5 = Strings.Asc(string2);
                    int charCode = num5 ^ num6;
                    stringBuilder.Append(Strings.Chr(charCode));
                    Math.Max(Interlocked.Increment(ref i), i - 1);
                }
                result = stringBuilder.ToString();
                stringBuilder.Length = 0;
                return result;
            }
        }

        public static string MD5Calc(string filepath)
        {
            string result;

            using (FileStream fileStream = new FileStream(filepath, FileMode.Open, FileAccess.Read))
            {
                using (MD5CryptoServiceProvider mD5CryptoServiceProvider = new MD5CryptoServiceProvider())
                {
                    byte[] arrInput = mD5CryptoServiceProvider.ComputeHash(fileStream);
                    result = ByteToHex(arrInput);
                }
            }

            return result;
        }

        // For MD5
        private static string ByteToHex(byte[] bytes)
        {
            StringBuilder hexBuilder = new StringBuilder();

            foreach (byte b in bytes)
            {
                hexBuilder.Append(b.ToString("X2"));
            }

            return hexBuilder.ToString().ToLower();
        }
    }
}
