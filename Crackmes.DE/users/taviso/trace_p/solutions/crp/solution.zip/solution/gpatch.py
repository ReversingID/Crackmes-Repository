#!/usr/bin/python
# -*- mode: python coding: latin-1 -*-
# $Id: $

import sys, re

d = {}

def print_byte(a,b):
    print hex(a)[2:-1] + " " + hex(b)[2:-1]
    
def print_long(a,b):
    print hex(a)[2:-1], hex(b & 0xFF)[2:-1]
    print hex(a+1)[2:-1], hex((b >> 8) & 0xFF)[2:-1]
    print hex(a+2)[2:-1], hex((b >> 16) & 0xFF)[2:-1]
    print hex(a+3)[2:-1], hex((b >> 24) & 0xFF)[2:-1]
           

for line in sys.stdin.readlines():

    rex = re.compile(r'^ptrace\(PTRACE_POKETEXT.*(0x[0-9a-fA-F]{1,8}).*(0x[0-9a-fA-F]{1,8}).*');
    m = rex.search(line);
    if m:
        a = long(m.group(1), 16)
        b = long(m.group(2), 16)
        if d.has_key(a):
            pass
        else:
            d[a] = b

k = d.keys()
k.sort()
for a in k:
    print_long(a,d[a])

    
