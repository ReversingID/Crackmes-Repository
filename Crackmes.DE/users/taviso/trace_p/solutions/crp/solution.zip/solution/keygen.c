/* -*- mode: c -*-
 * $Id: $
 */

#include <buffer.h> /* libowfat */
#include <stralloc.h>

#include <unistd.h>
#include <elf.h>

extern char **environ;

/* func1 */
void calc_env_thing(unsigned long buff[]) {
	size_t n = 0;
	unsigned long esi, ecx, edx, eax;
	Elf32_auxv_t  *auxp;

	while(environ[n] != NULL) {
		n++;
	}
	n++;
	
	auxp = (Elf32_auxv_t*)&environ[n];

	esi = ecx = edx = eax = 0;

	while(auxp->a_type != AT_NULL) {
		switch(auxp->a_type) {
			
		case AT_PHDR: {
			edx = esi & 3;
			esi++;
			ecx = esi & 3;
			eax = buff[edx];
			eax ^= auxp->a_un.a_val;
			buff[ecx] = eax;
			eax = buff[(esi%3)+1];
			eax <<= 0x10;
			eax = ~eax;
			eax ^= buff[ecx];
			eax *= esi;
			buff[ecx] = eax;
		} break;

		case AT_EUID: {
			if(auxp->a_un.a_val == 0) {
				buffer_puts(buffer_2,
					    "crackme will not run as root");
				buffer_putnlflush(buffer_2);
				_exit(0);
			}
		} break;
			
		}
		auxp++;
	}
}

/* func2 */
void calc_name_hash(unsigned long buff[], unsigned long name[]) {

	int i;

	buff[0] = name[0];
	buff[1] = name[1];
	buff[2] = name[2];
	buff[3] = name[3];

	for(i = 0; i <= 3; i++) {
		unsigned long eax;

		eax = (getuid() | getgid()) & 0xFFFF;
		eax <<= i;
		buff[i] ^= eax;
	}
	
}

/* func3 */
void calc_foo(unsigned long b1[], unsigned long b2[], unsigned long b3[]) {
	
	int i, j;
	unsigned char *p1 = (unsigned char*)b1, *p3=(unsigned char*)b3;
	b3[0] = b2[0];
	b3[1] = b2[1];
	b3[2] = b2[2];
	b3[3] = b2[3];

	for(i = 0; i <= 0xF; i++) {
		unsigned char x;
		x = p1[i];
		for(j = 0; j <= 0xF; j++) {
			p3[j] ^= x;
		}
	}

	
}

void calc_keys(unsigned long b3[], unsigned long keys[]) {
	keys[0] = b3[0] ^ b3[2];
	keys[1] = b3[1] ^ b3[3];
}

int main() {
	stralloc saname;
	unsigned long b1[4];
	unsigned long b2[4];
	unsigned long b3[4];
	unsigned long name[4];
	unsigned long keys[2];

	buffer_puts(buffer_1, 
		    "--[ keygen for taviso's trace-p ]---------------\n");
	buffer_puts(buffer_1, "name: ");
	buffer_getline_sa(buffer_0, &saname);
	if(saname.len <= 5 || saname.len > 16) {
		buffer_puts(buffer_1, "name too short/long (5-14 char.)");
		buffer_putnlflush(buffer_1);
		return 0;
	}

	memset(name, 0, sizeof(name));
	memcpy(name, saname.s, saname.len);

	calc_env_thing(b1);
	calc_name_hash(b2, name);
	calc_foo(b1, b2, b3);
	calc_keys(b3, keys);

	buffer_puts(buffer_1, "key1: ");
	buffer_putxlong(buffer_1, keys[0]);
	buffer_puts(buffer_1, "\nkey2: ");
	buffer_putxlong(buffer_1, keys[1]);
	buffer_putnlflush(buffer_1);

	return 0;
	
}




