/* -*- mode: c -*-
 * $Id: $
 */
#include <stdio.h>
#include <string.h>
#include <errno.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <elf.h>

#include <buffer.h> /* libowfat */
#include <array.h>
#include <stralloc.h>
#include <scan.h>
#include <open.h>

struct xelf {
	array a;
	Elf32_Ehdr *ehdr;
	Elf32_Shdr *shdr;
	Elf32_Phdr *phdr;
};

void syserr(const char* s) {
	buffer_putm(buffer_2, s, strerror(errno));
	buffer_putnlflush(buffer_2);
	_exit(-1);
}

void xelf_free(struct xelf* xe) {
	array_reset(&xe->a);
	free(xe);
}

struct xelf* xelf_load(const char* fname) {
	
	struct xelf *xe;
	char buff[4096*4];
	int e, fd;
	unsigned long phsize;
	unsigned long shsize;
	
	xe = malloc(sizeof(struct xelf));
	if(xe == NULL) {
		syserr("malloc");
	}
	memset(xe, 0, sizeof(struct xelf));

	fd = open(fname, O_RDONLY);
	if(fd == -1)
		syserr("open");
	while((e = read(fd, buff, sizeof(buff))) > 0) {
		array_catb(&xe->a, buff, e);
		if(array_failed(&xe->a)) {
			syserr("realloc");
		}
	}
	close(fd);

	if(e == -1) {
		syserr("read");
	}

	if(memcmp(xe->a.p, ELFMAG, SELFMAG) != 0) {
		buffer_putm(buffer_2, fname, " is not an ELF file\n");
		xelf_free(xe);
		return NULL;
	}

	xe->ehdr = (Elf32_Ehdr*) xe->a.p;
	phsize = xe->ehdr->e_phnum * xe->ehdr->e_phentsize;
	shsize = xe->ehdr->e_shnum * xe->ehdr->e_shentsize;

	if((xe->ehdr->e_phoff + phsize) > array_bytes(&xe->a)) {
		buffer_puts(buffer_2, "phdr overlapping/beyond EOF\n");
		xe->phdr = NULL;
	} else {
		xe->phdr = (Elf32_Phdr*)(xe->a.p + xe->ehdr->e_phoff);
	}

	if((xe->ehdr->e_shoff + shsize) > array_bytes(&xe->a)) {
		buffer_puts(buffer_2, "shdr overlapping/beyond EOF\n");
		xe->shdr = NULL;
	} else {
		xe->shdr = (Elf32_Shdr*)(xe->a.p + xe->ehdr->e_shoff);
	}	


	return xe;
}

int xelf_find_phindex(struct xelf* xe, unsigned long vaddr) {
	
	int i;
	for(i = 0; i < xe->ehdr->e_phnum; i++) {
		unsigned long start, end;
		start = xe->phdr[i].p_vaddr;
		end  = start + xe->phdr[i].p_memsz;

		if(vaddr >= start && vaddr < end) {
			return i;
		}
	}
	return -1;
}

int  xelf_patch(struct xelf* xe, unsigned long vaddr, unsigned char b){

	int phindex = xelf_find_phindex(xe, vaddr);

	buffer_puts(buffer_2, "vaddr ");
	buffer_putxlong(buffer_2, vaddr);

	if(phindex >= 0) {
		
		int off = vaddr - xe->phdr[phindex].p_vaddr;

		if(off >= xe->phdr[phindex].p_filesz)
		{
			buffer_puts(buffer_2, " not in file image\n");
			return 0;
		} else {
			/* patch */
			xe->a.p[xe->phdr[phindex].p_offset+off] = b;
			buffer_puts(buffer_2, " patched\n");
			return 1;
		}

	} else {
		buffer_puts(buffer_2, " not in mem image\n");
		return 0;
	}
}

int  xelf_write(struct xelf* xe, const char* fname) {
	
	int fd;
	fd = open_write(fname);
	if(fd == -1) {
		syserr("open");
	}
	if(write(fd, xe->a.p, array_bytes(&xe->a)) == -1) {
		syserr("write");
	}
	fsync(fd);
	close(fd);
	return array_bytes(&xe->a);
}



int main(int argc, char *argv[]) {
	
	stralloc fn, pfn;
	struct xelf* xe;

	if(argc != 2) {
		buffer_putm(buffer_2, 
			    "SYNTAX: ", argv[0], " elf < patchdata");
		buffer_putnlflush(buffer_2);
		return 0;
	}

	stralloc_copys(&fn, argv[1]);
	stralloc_copy(&pfn, &fn);
	stralloc_cats(&pfn, ".patched");

	if((xe = xelf_load(fn.s)) != NULL) {
		stralloc line;

		while(buffer_getline_sa(buffer_0, &line) > 0) {
			unsigned long vaddr, d, pos;

			stralloc_chomp(&line);
			stralloc_0(&line);
			pos = scan_xlong(line.s, &vaddr);
			if((pos == 0) || (pos+1 > line.len) ||
			   (scan_xlong(line.s+pos+1, &d) == 0)) 
			{
				buffer_putm(buffer_1,
					    "skipping line: ", line.s, "\n");
			} else {
				xelf_patch(xe, vaddr, d);
			}

			stralloc_zero(&line);
		}
		xelf_write(xe, pfn.s);
	}

	stralloc_free(&fn);
	stralloc_free(&pfn);

	buffer_flush(buffer_1);
	buffer_flush(buffer_2);

	return 0;
}





