NANDY CRACKME
~~~~~~~~~~~~~~

This crackme is made in assembly, compiled with TASM 5.2. It is simple and easy.
I think that it is "good" for beginners. Some notes.. The serial is in the crackme,
but it is not in plain text. It is not exactly crypted. I just choosed two characters,
then I did a NAND to them, and then I noted down the result (that it is checked).

Easy enough for everyone, I think ;D

Now, something I want (although I know most of you are going to crack this one with
ease). I do not want published solutions for this one. If you crack it, you can send
an e-mail to me, with your solution or tutorial (if you want). But you should not
publish the solution. 

My e-mail address is keyboard58@hotmail.com - thanks for your time.


-Gulhadore