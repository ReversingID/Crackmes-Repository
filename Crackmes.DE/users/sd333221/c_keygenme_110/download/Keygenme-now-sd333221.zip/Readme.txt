This is a Keygenme by me (sd333221),
written in c++

Some people could know me from the gRn community!

Your Mission:
Getting a valid serial (difficulty: 0.1/10)
Making a keygen (difficulty: 1/10)

I hope you'll have fun with this!