[A]dvanced Keygenme by  sd333221
 ^ Date of Release: 2-24-2007 ^
 Greetings go to all the hackerboard.de Members
 and all i know :P
 
 I hope you enjoy this Keygenme;
 
 Rules:
 -No Patching
 -Get a valid serial (Level 2/10)
 -Make a keygen (Level 3.5/10)
 -Enjoy!
 
 I hope this keygenme has some nasty tricks 4 you ;-)