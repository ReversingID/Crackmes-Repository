//use this file for other purposes if you want to, but just don't use it for anything that's even barely related to commercial software

var bitArithmeticLoaded=true;
var to32bit=function(a){a=a%0x100000000; if(a<0) return a+0x100000000; return a};
var bit32={
	to32bit: to32bit,
	reverseEndian: function(a) (a&0xFF)*0x1000000+((a&0xFF00)<<8)+((a&0xFF0000)>>8)+((a&0xFF000000)>>24),
	not: function(a) 0xFFFFFFFF-a,
	xor: function(a,b) to32bit(a^b),
	and: function(a,b) to32bit(a&b),
	or: function(a,b) to32bit(a|b),
	add: function(a,b) to32bit(a+b),
	sub: function(a,b) to32bit(a-b),
	shl: function(a,b) b>31?0:to32bit(a<<b),
	shr: function(a,b) a>>>b,
	rol: function(a,b) b%32==0?a:to32bit(a<<(b%32))+to32bit(a>>>(32-(b%32))),
	ror: function(a,b) b%32==0?a:to32bit(a>>>(b%32))+to32bit(a<<(32-(b%32))),
	mul: function(a,b) [Math.floor(a*b/0x100000000),
			((a*b)>>>16)*0x10000+((a%0x10000)*(b%0x10000))%0x10000],
};
var to16bit=function(a){a=a%0x10000; if(a<0) return a+0x10000; return a};
var bit16={
	fromNumber: to16bit,
	rol: function(a,b) ((a<<(b%16))+(a>>>(16-(b%16))))&0xFFFF,
	ror: function(a,b) ((a>>>(b%16))+(a<<(16-(b%16))))&0xFFFF,
};
var to8bit=function(a){while(a<0) a+=0x10000; return a&0xFFFF;};
var bit8={
	fromNumber: to8bit,
	not: function(a) 0xFF-(a&0xFF),
	rol: function(a,b) ((a<<(b%8))+(a>>>(8-(b%8))))&0xFF,
	ror: function(a,b) ((a>>>(b%8))+(a<<(8-(b%8))))&0xFF,
};
