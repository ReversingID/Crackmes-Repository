﻿Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

  
    End Sub


    Public Function var7() As Object
        Dim vr As String = Text_name.Text.ToUpper
        If (vr = "") Then
            Return 0
        End If
        Return (Module2.var10(Module2.var6(Module1.var2(Module1.var1(Module1.var(vr).ToString).ToString).ToString).ToString).ToString)
    End Function


    Private Sub Text_name_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Text_name.TextChanged
        If Text_name.Text = "" Then
            Text_serial.Text = "Please Enter a Name :)"
        Else
            Dim num As Long = Module2.var5
            Dim num2 As Long = var7()
            Dim num4 As Long = CLng(Math.Round(Conversion.Val((num * 6))))
            Dim num5 As Long = CLng(Math.Round(Conversion.Val((CDbl(num2) / 3))))
            Text_serial.Text = (num4 + num5).ToString()
        End If
    End Sub
End Class
