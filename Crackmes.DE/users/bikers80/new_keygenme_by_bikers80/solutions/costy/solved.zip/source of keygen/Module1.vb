﻿Module Module1
    Public Function var(ByVal vr As String) As Object
        Dim obj2 As Object
        Dim str As String = ""
        Try
            Dim num2 As Integer = Strings.Len(vr)
            Dim i As Integer = 1
            Do While (i <= num2)
                str = (str & (Strings.Chr((Strings.Asc(Strings.Mid(vr, i, 1)) + i)))).ToString
                i += 1
            Loop
        Catch exception1 As Exception
            str = ChrW(239) & ChrW(249) & ChrW(252) & ChrW(241) & ChrW(239)
        Finally
            obj2 = str
        End Try
        Return obj2
    End Function

    Public Function var1(ByVal vr1 As String) As Object
        vr1 = Strings.StrReverse(vr1)
        Return vr1
    End Function

    Public Function var2(ByVal vr2 As String) As Object
        Dim str As String = ""
        Dim num2 As Integer = Strings.Len(vr2)
        Dim i As Integer = 1
        Do While (i <= num2)
            str = (str & "" & Conversion.Hex(Strings.Asc(Strings.Mid(vr2, i, 1))))
            i += 1
        Loop
        Return str
    End Function








End Module
