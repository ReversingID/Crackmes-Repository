﻿Module Module2
    Public Function var10(ByVal vr10 As String) As Object
        If (Len(vr10.ToString) > 10) Then
            Return Strings.Mid(vr10, 1, 10)
        End If
        Return vr10
    End Function

    Public Function var4() As Object
        Return Interaction.Environ("UserName")
    End Function
 


    Public Function var6(ByVal vr6 As String) As Object
        If vr6.Contains("A") Then
            vr6 = vr6.Replace("A", "")
        End If
        If vr6.Contains("B") Then
            vr6 = vr6.Replace("B", "")
        End If
        If vr6.Contains("C") Then
            vr6 = vr6.Replace("C", "")
        End If
        If vr6.Contains("D") Then
            vr6 = vr6.Replace("D", "")
        End If
        If vr6.Contains("E") Then
            vr6 = vr6.Replace("E", "")
        End If
        If vr6.Contains("F") Then
            vr6 = vr6.Replace("F", "")
        End If
        Return vr6
    End Function

    Public Function var5() As Object
        Return (Module2.var10(Module2.var6(Module1.var2(Module1.var1((Module1.var((Module2.var4.ToString).ToString).ToString).ToString).ToString).ToString).ToString).ToString).ToString
    End Function












End Module
