Video Solution to Keygenme by bikers80
Solved by MACH4

Tools:
PEID
Reflector
Visual Studio


If you have problems with the flash video screen size, Google for "SWF Opener" by UnH Solutions, I wouldn't be without it!

Greetz to bikers80, Crackmes.de and all crackers!

MACH4.