Solution to bikers80 KeygenMe CrackMe
Solved by MACH4

Tools:
reflector
Visual studio

Greetz to bikers80, Crackmes.de and all members!

MACH4.