﻿' Original Crackme Link : http://www.crackmes.de/users/bikers80/keygenme3_by_bikers80/
' Solution to biker80's Keygenme3 by born2c0de
Public Class Form1
    Public Function decrypt(ByVal var1b As String) As String 'var1()
        Dim strx As String = ""
        Dim num2 As Integer = Strings.Len(var1b)
        Dim i As Integer = 1
        Do While (i <= num2)
            strx = (strx & CStr(Strings.Chr((Strings.Asc(Strings.Mid(var1b, i, 1)) + 6))))
            i = (i + 1)
        Loop
        Return strx
    End Function

    Public Function encrypt(ByVal var1b As String) As String ' my own encrypt function
        Dim strx As String = ""


        Dim num2 As Integer = Strings.Len(var1b)
        Dim i As Integer = 1
        Do While (i <= num2)
            strx = (strx & CStr(Strings.Chr((Strings.Asc(Strings.Mid(var1b, i, 1)) - 6))))
            i = (i + 1)
        Loop
        Return strx
    End Function

    Public Function userhexINTOtime() As String 'var11()
        Return Strings.Mid(CLng((hexUsernameToLong() * hourMinConcat())).ToString, 1, 11)
    End Function


    Public Function hexUsernameToLong() As Long 'var10()
        Return CLng(Math.Round(Conversion.Val((removeHexChars4Username()))))
    End Function

    Public Function IsPass1LikePassAlgo1() As Boolean 'var12()
        Return CBool(getpass1() Like userhexINTOtime())
    End Function

    Public Function getcomputername() As String 'var13()
        Dim str As String = Interaction.Environ("computerName")

        If (str = "") Then
            str = "]igjon_ol" ' compueter
        End If
        Return str
    End Function

    Public Function computernameToHex() As String 'var14()
        Dim expression As String = ""
        Dim num2 As Integer = Strings.Len(getcomputername())
        Dim i As Integer = 1
        Do While (i <= num2)
            expression = (expression & "" & Conversion.Hex(Strings.Asc(Strings.Mid(CStr(getcomputername()), i, 1))))
            Dim str As String = Strings.StrReverse(expression)
            i += 1
        Loop
        Return expression
    End Function

    Public Function removeHexChars4CompName() As String 'var15()
        Dim strx As String = computernameToHex()
        If strx.Contains("A") Then
            strx = strx.Replace("A", "")
        End If
        If strx.Contains("B") Then
            strx = strx.Replace("B", "")
        End If
        If strx.Contains("C") Then
            strx = strx.Replace("C", "")
        End If
        If strx.Contains("D") Then
            strx = strx.Replace("D", "")
        End If
        If strx.Contains("E") Then
            strx = strx.Replace("E", "")
        End If
        If strx.Contains("F") Then
            strx = strx.Replace("F", "")
        End If
        Return strx
    End Function

    Public Function hexcompPLUShexuserPLUStime() As String 'var16()
        Dim left As Long = CLng(Math.Round(Conversion.Val(removeHexChars4CompName())))
        Dim str As String = Strings.StrReverse(CLng(left + hexUsernameToLong() + hourMinConcat()).ToString)
        Dim str3 As String = Strings.Mid(str, 2, 12)
        Return str
    End Function

    Public Function IsPass2LikePassAlgo2() As Boolean 'var17()
        Return CBool(getpass2() Like hexcompPLUShexuserPLUStime())
    End Function

    Public Function AreBothPasswordsCorrect() As Boolean 'var18()
        If IsPass1LikePassAlgo1() = True And IsPass2LikePassAlgo2() = True Then
            Return 1
        End If
        Return 0
    End Function

    Public Function setRegStatusToLabel() As Boolean 'var19()
        'Dim str As String = CStr(decrypt("L?ACMN?L?>")) 'registered
        'Dim str2 As String = CStr(decrypt("OHL?ACMN?L?>")) 'unregistered
        Dim str As String = decrypt(encrypt("Registered"))
        Dim str2 As String = decrypt(encrypt("Unregistered"))
        If AreBothPasswordsCorrect() = True Then
            Label5.Text = str
            Return 0
        End If
        Label5.Text = str2
        Return 0
    End Function

    Public Function getusername() As String 'var2()
        Return TextBox1.Text
    End Function

    Public Function IsTextBox1Null() As Boolean 'var20()
        If getusername() = "" Then
            'Interaction.MsgBox("Please enter something", MsgBoxStyle.OkOnly, Nothing)
            Label5.Text = "Please enter something"
        End If
        Return 0
    End Function

    Public Function getpass1() As String 'var3()
        Return TextBox2.Text
    End Function

    Public Function getpass2() As String 'var4()
        Return TextBox3.Text
    End Function

    Public Function usernameToHex() As String 'var5()
        Dim str2 As String = ""
        If getusername() = "" Then
            Return 0
        End If
        Dim expression As String = Strings.Mid(CStr(getusername()), 1, 6)
        Dim num2 As Integer = Strings.Len(expression)
        Dim i As Integer = 1
        Do While (i <= num2)
            str2 = (str2 & "" & Conversion.Hex(Strings.Asc(Strings.Mid(expression, i, 1))))
            i += 1
        Loop
        Return str2
    End Function

    Public Function removeHexChars4Username() As String 'var6()
        Dim str As String = CStr(usernameToHex())

        If str.Contains("A") Then
            str = str.Replace("A", "")
        End If
        If str.Contains("B") Then
            str = str.Replace("B", "")
        End If
        If str.Contains("C") Then
            str = str.Replace("C", "")
        End If
        If str.Contains("D") Then
            str = str.Replace("D", "")
        End If
        If str.Contains("E") Then
            str = str.Replace("E", "")
        End If
        If str.Contains("F") Then
            str = str.Replace("F", "")
        End If
        Return str
    End Function

    Public Function get_time() As Date 'var7()
        Return DateAndTime.TimeOfDay
    End Function

    Public Function extract_hour_minute() As String 'var8()
        Return Strings.Mid(CStr(get_time()), 1, 5)
    End Function

    Public Function hourMinConcat() As String 'var9()
        Dim inputStr As String = CStr(extract_hour_minute()).Replace(":", "")
        Dim num As Integer = CInt(Math.Round(Conversion.Val(inputStr)))
        Return inputStr
    End Function


    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        tmrGenerateSerial.Interval = 1000
        tmrGenerateSerial.Start()
        TextBox4.Text = IIf(Len(Interaction.Environ("computerName")) = 0, "computeur", Interaction.Environ("computerName"))
    End Sub

    Private Sub CreateSerialsAndConfirm()
        IsTextBox1Null()
        setRegStatusToLabel()
        TextBox2.Text = userhexINTOtime()
        TextBox3.Text = hexcompPLUShexuserPLUStime()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Click
        MsgBox(decrypt("]igjon_ol"))
        MsgBox(decrypt("L?ACMN?L?>"))
        MsgBox("var13 = " & decrypt("]igjon_lH[g_"))
        MsgBox("var14 = " & computernameToHex())
        MsgBox(CStr(get_time()))
        MsgBox(decrypt("L_`f_]nil"))
        MsgBox(decrypt("L_`f_]nil(_r_"))
    End Sub

    Private Sub TmrGenerateSerial_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrGenerateSerial.Tick
        CreateSerialsAndConfirm()
        setRegStatusToLabel()
        Label1.Text = DateAndTime.TimeOfDay.ToLongTimeString
    End Sub

    Private Sub Label7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label7.Click

    End Sub

    Private Sub Label6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label6.Click

    End Sub
End Class
