#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define  MAX  256

int main(void)
{
    char name[MAX], key[MAX];
    int i, len;

    printf("KeyGen for [KeyGenMe#1 By Rayko] by @steri][\n");

    printf("\nName: ");
    gets(name);

    if ((len = strlen(name)) == 0) {
	fprintf(stderr, "\nERROR: The name has zero length\n");
	return 1;
    }

    for (i = 0; i < len; i++)
	key[i] = (2 * name[i] >> 2) + (i >> 2) - 0xC8;

    key[i] = '\0';

    printf("\nName: %s", name);
    printf("\nKey:  %s\n", key);

    system("pause");
 
    return 0;
}