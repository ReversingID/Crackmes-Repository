#include <stdio.h>
#include <string>

#define MAX_STRING_LENTH (20 + 1)

int main()
{
	char name[MAX_STRING_LENTH];
	int nameLenth;
	int start, finish;
	int serial = 0;
	char buf1[100];
	char buf2[100];

	printf("Name: ");
	gets_s(name, MAX_STRING_LENTH);

	nameLenth = strlen(name);

	start = 0;
	while (' ' == name[start])
	{
		++ start;
	}
	finish = strlen(name) - 1;
	while (finish >= start && ' ' == name[finish])
	{
		-- finish;
	}
	if (start > finish)
	{
		printf("Error - empty name\n");
		return 0;
	}

	for (int i = start; i <= finish; ++ i)
	{
		_itoa_s(serial, buf1, 10);
		_itoa_s(buf1[0], buf1, 8);
		_itoa_s(name[i], buf2, 8);
		strcat_s(buf1, buf2);
		serial = atoi(buf1);
		serial += 666;
	}
	printf("Serial: %d\n", serial);

	return 0;
}
