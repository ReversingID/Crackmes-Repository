﻿Public Class Form1

    Function Encrypt(ByVal key As String) As Integer
        Dim saved As Integer
        Dim tmpstr As String
        saved = 0
        For i = 0 To key.Length - 1
            tmpstr = Oct(Asc(saved.ToString))
            tmpstr = tmpstr + Oct(Asc(key.Substring(i)))
            saved = Convert.ToDouble(tmpstr) + 666
        Next
        Return saved
    End Function

    Function EncryptAlt(ByVal key As String) As Integer
        Dim retval As Integer
        Dim tmpstr As String
        If key.Length > 1 Then
            If key.Length > 2 And Asc(key.Substring(key.Length - 2, 1)) < 64 Then
                tmpstr = Oct(Asc("7"))
            Else
                tmpstr = Oct(Asc("6"))
            End If
        Else
            tmpstr = Oct(Asc("0"))
        End If
        retval = Int(tmpstr + Oct(Asc(key.Substring(key.Length - 1, 1)))) + 666
        Return retval
    End Function

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        tbVal.Text = Encrypt(tbKey.Text)
        tbVal2.Text = EncryptAlt(tbKey.Text)
    End Sub

End Class
