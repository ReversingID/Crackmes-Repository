********************************
*     KeyGenMe#2 By Rayko      *
********************************

Okay, my second (actually third if you count my first crappy one) keygenme

this one is getting a little harder, not protectiont-wise since i have not learnt any anti-debugger protection yet...

HOWEVER I HAVE put a LOT more thought into the algo!

let's see some of you crack and make a tutorial out of this one!

!not for the complete newbie!

rules apply as to all others

-No patching
-No bruteforcing
-Write keygen
-Write a tutorial
-Upload solution
-HAVE FUN!