#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define NAMELEN	80

int main()
{
	char Name[NAMELEN];
	char NewName[21], Key[21];
	int currentIndex, doneCount, remainderCount;
	char tempChar;
	int i, KeyNumber;

	printf("Name: ");
	scanf("%s", Name);

	if(strlen(Name) > 20)
	{
		printf("The legnth of your name should be less than 20 characters.\n");
		exit(0);
	}
	else
	{
		strcpy(NewName, Name);
	
		/* Handle Name */

		while(strlen(NewName) < 20)
		{
			doneCount = 0;
			remainderCount = 20 - strlen(NewName);

			while(doneCount < remainderCount)
			{
				tempChar = NewName[doneCount];

				currentIndex = strlen(NewName);
				NewName[currentIndex] = tempChar;
				NewName[currentIndex + 1] = '\0';

				remainderCount--;
				doneCount++;
			}
		}
/*
		printf("%s\n", NewName);
*/
		/* Caculate Key */
		
		Key[0] = '\0';
		for(i = 0; i < 20; i++)
		{
			KeyNumber = ((NewName[i] * NewName[i]) >> 1) ^ (i << 2);
/*			
			while(!((KeyNumber >= 'A' && KeyNumber <= 'Z') || (KeyNumber >= '0' && KeyNumber <= '9')))
			{
				if(KeyNumber > 'Z')
				{
					
					KeyNumber -= i * 2 + 9;
					continue;
				}
				
				if(KeyNumber < '0')
				{
					KeyNumber += i * 2 + 9;
					continue;
				}

				if((KeyNumber < 'A') && (KeyNumber > '9') )
				{
					KeyNumber -= i * 2 + 10;
					continue;
				}

			}
*/
			while(KeyNumber > 'Z')
			{
				KeyNumber -= i * 2 + 9;

				if((KeyNumber > '9') && (KeyNumber < 'A'))
				{
					KeyNumber -= i * 2 + 10;
				}
			}

			while(KeyNumber < '0')
			{
				KeyNumber += i * 2 + 9;

				if((KeyNumber > '9') && (KeyNumber < 'A'))
				{
					KeyNumber -= i * 2 + 10;
				}
			}

			Key[i] = KeyNumber;
		}
		Key[i] = '\0';
	}

	printf("Key: %s\n", Key);

	getchar();
	getchar();

	return 0;
}