#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define   BUF_SIZE   256
#define   MAX        20

int main(void)
{
    char buf[BUF_SIZE], name[BUF_SIZE], key[MAX+1], sc[2];
    int i, len, d;

    printf("KeyGen for [KeyGenME #2 by Rayko] by @steri][\n");

    printf("\nEnter name: ");
    gets(name);

    if (strlen(name) > MAX) {
	fprintf(stderr, "\nERROR: The name needs 20 or less characters.\n");
	return 1;
    }
	
    strcpy(buf, name);
    while (strlen(buf) <= MAX-1) {
	for (i = 0; i < MAX - (len = strlen(buf)); i++) {
	    sprintf(sc, "%c", buf[i % len]);
	    strcat(buf, sc);
	}
    }
    
    for (i = 0; i < MAX; i++) {

	d = (buf[i] * buf[i] >> 1) ^ (i << 2);

	while (d > 0x5A) {
	   d -= i + i;
	   d -= 9;
	   if (d > 0x40 || d <= 0x39)
	       continue;
	   d -= i + i;
	   d -= 0xA;
	}

	while (d <= 0x2F) {
	   d += i + i;
 	   d += 9;
           if (d > 0x40 || d <= 0x39)
	       continue;
	   d -= i + i;
	   d -= 0xA;
	}

	key[i] = d;
    }

    key[i] = '\0';

    printf("\n================================");
    printf("\nName: %s", name);
    printf("\nKey:  %s", key);
    printf("\n================================\n\n");

    system("pause");

    return 0;
}