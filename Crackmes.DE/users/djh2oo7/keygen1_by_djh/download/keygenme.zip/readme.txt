DjH's KeygenMe#1
----------------
The one and only solution is a keygen!