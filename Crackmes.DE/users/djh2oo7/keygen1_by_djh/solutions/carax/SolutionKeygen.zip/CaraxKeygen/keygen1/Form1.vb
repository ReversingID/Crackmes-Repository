﻿Public Class Form1

    Private Function randomChar() As Char
        Dim randomValue As Integer
        Dim upperbound As Integer
        Dim lowerbound As Integer

        'Set de upperbound and lowerbound of the characters value (in ASCII)
        lowerbound = 33
        upperbound = 96

        ' Initialize the random-number generator.
        Randomize()
        ' Generate random value between 1 and 6.
        randomValue = CInt(Int((upperbound - lowerbound + 1) * Rnd() + lowerbound))
        Return Chr(randomValue)

    End Function

    Private Sub btnKeygen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnKeygen.Click
        Dim keygenChar(23) As Char
        Dim ichar As Integer

        'Create the four first characters. 965 = CHAR1 + 2*CHAR2 + 4*CHAR3 + 8*CHAR4
        Do
            keygenChar(1) = randomChar()
            keygenChar(2) = randomChar()
            keygenChar(3) = randomChar()
            ichar = 965 - Asc(keygenChar(1)) * 2 - Asc(keygenChar(2)) * 4 - Asc(keygenChar(3)) * 8 '&3C5 = 965
            If ((ichar > 33) And (ichar < 96)) Then
                keygenChar(0) = Chr(ichar)
                Exit Do
            End If
        Loop
        keygenChar(4) = "-"

        'Create the characters 6th to 8th and 16th to 19th
        'VAR2 = (CHAR6 + CHAR7 + CHAR8) * 2 + 6
        'VAR3 = (CHAR16 -1)/ 2 + (CHAR17 - 1)  + (CHAR18 - 1) * 3 / 2 + (CHAR19 - 1) * 2
        'VAR2 == VAR3
        Do
            keygenChar(5) = randomChar()
            keygenChar(6) = randomChar()
            keygenChar(7) = randomChar()
            keygenChar(15) = randomChar()
            keygenChar(17) = randomChar()
            keygenChar(18) = randomChar()
            ichar = (Asc(keygenChar(5)) + Asc(keygenChar(6)) + Asc(keygenChar(7))) * 2 + 6 - (Asc(keygenChar(15)) - 1) \ 2 - ((Asc(keygenChar(17)) - 1) * 3) \ 2 - (Asc(keygenChar(18)) - 1) * 2 + 1
            If ((ichar > 33) And (ichar < 96)) Then
                keygenChar(16) = Chr(ichar)
                Exit Do
            End If
        Loop


        'Create the others characters
        keygenChar(8) = randomChar()
        keygenChar(9) = "-"
        keygenChar(10) = randomChar()
        keygenChar(11) = randomChar()
        keygenChar(12) = randomChar()
        keygenChar(13) = randomChar()
        keygenChar(14) = "-"
        keygenChar(19) = "-"
        keygenChar(20) = randomChar()
        keygenChar(21) = randomChar()
        keygenChar(22) = randomChar()
        keygenChar(23) = keygenChar(11)

        txtKeygen.Text = keygenChar
    End Sub

End Class
