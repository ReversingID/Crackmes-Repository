#include <iostream>
#include <string>

using namespace std;

int main(int argc, char* argv[])
{
	// initialize
	int i, current_length, tmp, temp;
	string name;
	char serial[10], out[2];

	temp = tmp = 0;

	cout << "DjH2oo7's DjH's CMe no#1 (VCL)" << endl << "Coded by zart" << endl;
	cout << "Enter a username (min 3 - max 8 chars): ";

	std::cin >> name;

	serial[0] = 48 + name.length(); // Badboy 3

	serial[2] = '3';  // Badboy 4
	serial[4] = '5';

	serial[6] = '-'; // Badboy 5

	//Badboy 6
	if(name.length()%2)
		serial[9] = name[(name.length()/2)];
	else
		serial[9] = name[(name.length()/2)-1];

	//Badboy 7
	serial[1] = '2';
	tmp = ((((name.length()-1)^serial[1])^((name.length()-1)*68))^serial[1])^68;
	sprintf(out, "%d", tmp);

	switch(name.length())
	{
		case 3:
		case 4:
			serial[3] = out[1];
			serial[5] = '1';
			serial[8] = '1';
			break;
		case 5:
		case 6:
			serial[5] = out[1];
			serial[3] = '1';
			serial[8] = '1';
			break;
		case 7:
		case 8:
			serial[8] = out[1];
			serial[3] = '1';
			serial[5] = '1';
			break;
		default:
			cout << "Error in length of username." << endl;
			break;
	}

	//Badboy 8
	switch(name.length())
	{
		case 3:
			tmp = (0x000000FE - (serial[9] - name.length())+3);
			break;
		case 4:
			tmp = (0x000000FE - (serial[9] - name.length())+2);
			break;
		case 5:
			tmp = (0x000000FE - (serial[9] - name.length())+3);
			break;
		case 6:
			tmp = (0x000000FE - (serial[9] - name.length())+2);
			break;
		case 7:
			tmp = (0x000000FE - (serial[9] - name.length())+4);
			break;
		case 8:
			tmp = (0x000000FE - (serial[9] - name.length())-3);
			break;
		default:
			cout << "Error in length of username." << endl;
			break;
	}
	
	sprintf(out, "%d", tmp);
	serial[7] = out[2];

	for(i=0; i<10; i++)
		cout << serial[i];

	cout << endl;

	return 0;
}