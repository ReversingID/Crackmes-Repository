Solution Levels:
===========
EXCELLENT: create a working keygen for serial number and activation code.

PERFECT:  create a working keygen for serial number
and use self-keygenning for activation code.

GOOD: Give a working serial number and use self-keygenning for activation code.

Good luck and happy!
http://crackmes.de
hackholmes