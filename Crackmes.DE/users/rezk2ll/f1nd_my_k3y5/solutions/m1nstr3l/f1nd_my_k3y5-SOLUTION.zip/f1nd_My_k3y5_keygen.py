#!/usr/bin/python

import operator
import binascii
import sys
import random
import binascii


# There are 13 functions in this crackme that take a character and perform
# an arithmetic operation on the hex value of that character to produce
# a numeric output (add a value and the xor a value)
# The outputs of each function are summed up and the end result has to be
# 0x41A
# The final function will only take a '!' character as input.  The output of 
# this final function will be 0x2B
# Therefore the sum of the first 12 functions must be 0x3EF

Sum_11 = 0x3EF


# The 13 functions each perform an add and an xor on a value.
# This function generalized that capability.

def addXor(input, add, xor):
    return operator.xor(input + add, xor)



# Each function takes a certain character from the key and performs a
# comparison against one of the following characters [flagiP0OEN]
# If the input matches the character that function is checking for then
# the function alters it's behaviour (skips to another character in the key
# and/or uses a different add,xor algorithm)
# For the purpose of this key generator these characters will not be used
# in those positions to simplify the calculations. A more advanced keygen 
# could be written to account for these calculations and expand the key size

# We'll assume printable ascii character set for key from 0x20 - 0x7E
# This key generator will create valid 13 character keys.
# Note: The key is still valid is additional characters are appended to the
# end of the given 13 characters

# This function takes in a character to avoid using, and two values to add
# and xor.  It then calls the addXor function with the randomly generated 
# value.

def func_cX(avoid,add,xor):
    avoid = int(binascii.hexlify(avoid),16)
    cX = avoid
    while cX == avoid:
        cX = random.randint(0x20,0x7E)
    cX_out = addXor(cX,add,xor)
    return cX, cX_out



def main():
    sum = 0
    
    # c0 uses '+9 xor 7' and can't be 'l'
    c0, c0_out = func_cX('l',9,7)
    sum += c0_out
    c0 = binascii.unhexlify(hex(c0)[2:])
    
    # c1 uses '+0x11 xor 7' and can't be 'S'
    while True:
        c1, c1_out = func_cX('S',0x11,7)
        sum += c1_out
        if 75 < sum < 200:
            c1 = binascii.unhexlify(hex(c1)[2:])
            break
        sum -= c1_out
    
    # c2 uses '+7 xor 3' and can't be 'a'
    while True:
        c2, c2_out = func_cX('a',7,3)
        sum += c2_out
        if 125 < sum < 275:
            c2 = binascii.unhexlify(hex(c2)[2:])
            break
        sum -= c2_out
    
    # c3 uses '+4 xor 2' and can't be 'N'
    while True:
        c3, c3_out = func_cX('N',4,2)
        sum += c3_out
        if 175 < sum < 325:
            c3 = binascii.unhexlify(hex(c3)[2:])
            break
        sum -= c3_out
    
    
    # c4 uses '+6 xor 5' and can't be 'f'
    while True:
        c4, c4_out = func_cX('f',6,5)
        sum += c4_out
        if 250 < sum < 400:
            c4 = binascii.unhexlify(hex(c4)[2:])
            break
        sum -= c4_out
    
    
    # c5 uses '+0x10 xor 0x45' and can't be 'i'
    while True:
        c5, c5_out = func_cX('i',0x10,0x45)
        sum += c5_out
        if 400 < sum < 575:
            c5 = binascii.unhexlify(hex(c5)[2:])
            break
        sum -= c5_out
    
    
    # c6 uses '+5 xor 8' and can't be 'g'
    while True:
        c6, c6_out = func_cX('g',5,8)
        sum += c6_out
        if 500 < sum < 675:
            c6 = binascii.unhexlify(hex(c6)[2:])
            break
        sum -= c6_out
    
    
    # c7 uses '+7 xor 3' and can't be 'P'
    while True:
        c7, c7_out = func_cX('P',7,3)
        sum += c7_out
        if 600 < sum < 775:
            c7 = binascii.unhexlify(hex(c7)[2:])
            break
        sum -= c7_out
    
    
    # c8 uses '+7 xor 3' and can't be '0'
    while True:
        c8, c8_out = func_cX('0',7,3)
        sum += c8_out
        if 700 < sum < 825:
           c8 = binascii.unhexlify(hex(c8)[2:])
           break
        sum -= c8_out
    
    
    # c9 uses '+1 xor 8' and can't be 'O'
    while True:
        c9, c9_out = func_cX('O',1,8)
        sum += c9_out
        if 800 < sum < 900:
            c9 = binascii.unhexlify(hex(c9)[2:])
            break
        sum -= c9_out
    
    
    # c10 uses '+7 xor 3' and can't be a 'P'
    while True:
        c10, c10_out = func_cX('P',7,3)
        sum += c10_out
        if 900 < sum < 975:
            c10 = binascii.unhexlify(hex(c10)[2:])
            break
        sum -= c10_out
    
    # c11 uses '+7 xor 3' and can't be an 'E'
    # The sum at the end of this has to be 0x3EF = 1007
    Target = Sum_11 - sum
    for c11 in range(0x20,0x7E):
        if c11 == 45: continue
        c11_out = addXor(c11,7,3)
        if c11_out == Target:
            c11 = binascii.unhexlify(hex(c11)[2:])
            break
    
    key = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + '!'
    print 'Try this one: ' + key

if __name__ == '__main__':
    main()
