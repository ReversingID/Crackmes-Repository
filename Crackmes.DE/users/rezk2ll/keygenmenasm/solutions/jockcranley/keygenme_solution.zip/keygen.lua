username = ''
password = ''
OR = 5
user_int = 0
old = 0

io.write("Enter a username (3-14 characters): ")
username = io.read()

if string.len(username) < 3 or string.len(username) > 14 then
	io.write("Username ~= 3 - 14 characters\n")
else
	for i = 1, string.len(username) do
		--[[ This turns the i-th element of the username string into an int, to OR it ]]--
		user_int = string.byte(username, i)
		old = user_int
		
		--[[ Lua doesn't have built in bitwise operators like C e.g:
				user_int |= OR;
			so we have to use a function (shipped by default with Lua mind you) to replicate it ]]--
		user_int = bit32.bor(user_int, OR)
		OR = old

		-- Add the OR'd value to the end of the Password
		password = password .. string.char(user_int)
	end
	io.write("Password: ", password, "\n")
end

