﻿using System;
using System.Text;
using System.Windows.Forms;

namespace WindowsTestApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            textBox2.Text = findpass(textBox1.Text);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text = "draww";
        }

        private string findpass(string name)
        {
            StringBuilder sb = new StringBuilder();
            byte[] nb = Encoding.ASCII.GetBytes(name);
            int al = 5, bl = 0;

            for (int i=0;i<name.Length;i++)
            {
                bl = nb[i] | al; //logical OR operation
                sb.Append(Convert.ToChar(bl));
                al = nb[i];
            }

            return sb.ToString();
        }

        /* ASM CODE BLOCK
         * 
        mov	esi, offset user
		mov	al, 5

cipher:					; CODE XREF: _start+A9j
		mov	bl, [esi+ecx]
		mov	bh, bl
		or	bl, al
		mov	al, bh
		mov	[esi+ecx], bl
		inc	ecx
		cmp	ecx, edx
		jl	short cipher
		xor	ebx, ebx
		mov	ebx, offset pass
		xor	eax, eax
         * 
         */

    }
}
