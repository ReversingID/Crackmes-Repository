// 
// Challange: http://www.crackmes.de/users/rezk2ll/keygenmenasm/
// Author: x3ae12@gmail.com
// 2015.02.22 22:11
// 

#include <iostream>
#include <string>
#include <cstring>

int main(int argc, char *argv[])
{
    if (argc != 2)
    {
        std::cerr << "Error! Usage: " << argv[0] << " username" << std::endl;
        std::cerr << "The length of the username should be 3-13 character." << std::endl;
        return 1;
    }
    
    if (std::strlen(argv[1]) < 3 || std::strlen(argv[1]) >= 14)
    {
        std::cerr << "Error! The length of the username should be 3-13 character." << std::endl;
        return 1;
    }
        
    std::string user_name =  argv[1];
    
    unsigned char magic_number = 5;
    
    for (size_t i = 0; i < user_name.length(); i++)
    {
        size_t current_byte = user_name[i];
        user_name[i] |= magic_number;
        magic_number = current_byte;
    }
    
    std::cout << user_name << std::endl;
    
    return 0;
}
