import os, sys

def pass4user( user = ''):
	al = 5
	bl = 0
	bh = 0
	
	passw = ''
	
	for i in range(len(user)):
		bl = ord(user[i])
		bh = bl
		bl = bl | al
		al = bh 
		passw += chr(bl)
	return passw

print pass4user( sys.argv[1] )
	