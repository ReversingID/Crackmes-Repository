Hello!
This is my first KeyGenMe. It's very simple.

In Name please write Latinic symbol ("A".."Z", "a".."z") and (or) numbers ("0".."9").

Coded in Delphi
File is off course not packed :)

Good luck!

06/09/2005 