#include <iostream.h>
#include <fstream.h>
#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <stdlib.h>

fstream f;

#define FIRST 397
#define SECOND 396
#define THIRD 400
#define QUART 392
#define QUINT 390

char name[50];
char serial1[6], serial2[6], serial3[6], serial4[6], serial5[6];
char serial[50];

char value[] = { 0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39,
                 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A,
                 0x4B, 0x4C, 0x4D, 0x4E, 0x4F, 0x50, 0x51, 0x52, 0x53, 0x54,
                 0x55, 0x56, 0x57, 0x58, 0x59, 0x5A, 0x61, 0x62, 0x63, 0x64,
                 0x65, 0x66, 0x67, 0x68, 0x69, 0x6A, 0x6B, 0x6C, 0x6D, 0x6E,
                 0x6F, 0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78,
                 0x79, 0x7A, 0x00 };

int lung=0, sum=0, val=0;

void main()
{
   randomize();

   cout<<"Salazan's Salazan's KeyGenMe! #0001 - Keygen by Ox87k\n\n";

//PART1
   do
   {
      sum=0;
		for (int i=0;i<3;i++)
   	{
			serial1[i]=value[random(62)];
      	sum+=serial1[i];
   	}
   val=FIRST-sum-0x4F;                        //O
   }while(val<0x30 || val>0x7A);
   serial1[3]=val;
   serial1[4]=0x4F;
   serial1[5]='\0';

//PART2
   do
   {
      sum=0;
		for (int i=0;i<3;i++)
   	{
			serial2[i]=value[random(62)];
      	sum+=serial2[i];
   	}
   val=SECOND-sum-0x78;                        //x
   }while(val<0x30 || val>0x7A);
   serial2[3]=val;
   serial2[4]=0x78;
   serial2[5]='\0';

//PART3
   do
   {
      sum=0;
		for (int i=0;i<3;i++)
   	{
			serial3[i]=value[random(62)];
      	sum+=serial3[i];
   	}
   val=THIRD-sum-0x38;                          //8
   }while(val<0x30 || val>0x7A);
   serial3[3]=val;
   serial3[4]=0x38;
   serial3[5]='\0';

//PART4
   do
   {
      sum=0;
		for (int i=0;i<3;i++)
   	{
			serial4[i]=value[random(62)];
      	sum+=serial4[i];
   	}
   val=QUART-sum-0x37;                           //7
   }while(val<0x30 || val>0x7A);
   serial4[3]=val;
   serial4[4]=0x37;
   serial4[5]='\0';

//PART5
   do
   {
      sum=0;
		for (int i=0;i<3;i++)
   	{
			serial5[i]=value[random(62)];
      	sum+=serial5[i];
   	}
   val=QUINT-sum-0x6B;                            //k
   }while(val<0x30 || val>0x7A);
   serial5[3]=val;
   serial5[4]=0x6B;
   serial5[5]='\0';

   sprintf(serial,"%s%c%s%c%s%c%s%c%s",serial1,0x2D,serial2,0x2D,serial3,0x2D,serial4,0x2D,serial5);
   serial[30]='\0';
   cout<<"\nSerial: "<<serial;
   f.open("serial.txt",ios::out);
   f<<serial;
   f.close();
	cout<<"\n\nPress any key to exit...";
	getchar();
}
