#include "md5.h"
#include<conio.h>
#include<stdlib.h>
#include<stdio.h>
#include<string.h>

char buffer[255],name[255],serial[255],flag[9]="00000000";
int i=0,j=0,count=1;
long int test=1;
FILE *fp;


int main(void)
{
  printf("********************************************************\n");
  printf("**** Bruter for Salazan's  Light keygenme by br0ken ****\n");
  printf("********************************************************\n");
  printf("\n\nInfo\n\n");
  printf("1. Some user names have blank serial.\n");
  printf("2. Due to my limited coding skills, only numerical serials are generated\n");
  printf("   but serials can consist of characters (and special chars) too.\n");
  printf("3. This bruter generates 250 valid (numerical) serials.\n");
  printf("4. If you want more, then modify the source accordingly.\n\n");
  printf("Enter your name : ");
  gets(name);
  fp = fopen("status.log","w");
  
  if(fp==NULL)
	{ 
	printf("Unable to create log file...\n\n");
    	getch();
	return 0;
	}
  fprintf(fp,"Here you can check the full status report of the bruteforcing\n\n");
  fprintf(fp,"\nUsername  =  %s\n\n",name);
  printf("\nValid  serials are : \n\n");
  strcpy(serial,MD5String(name));
  for(i=0;i<=7;i++)
	{
	  if(serial[i] >= '0' && serial[i] <= '9')
      flag[i]='1';
	}
  if(strcmp(flag,"11111111")==0)
  printf("\n\nFor this username, blank serial is valid too :P\n\n");
  strcpy(flag,"00000000");
  do
		{
	sprintf(buffer,"%s%d",name,test);
	strcpy(serial,MD5String(buffer));
	fprintf(fp,"Checking hash.. %s",serial);
	for(i=0;i<=7;i++)
				{
			if(serial[i] >= '0' && serial[i] <= '9')
			flag[i]='1';
				}
		if(strcmp(flag,"11111111")==0)
					{
				fprintf(fp," ======>   VALID!\n");
				fprintf(fp,"Serial = %d\n\n",test);
				printf("%d.  %d\n",count,test);
				count++;
					}
			else
					{
				fprintf(fp," ==> INVALID\n");
					}
  if(count>250)
  goto end;
  strcpy(flag,"00000000");
  test++;
	}
  while(test <= 4294967296);
  end:
  fclose(fp);
  printf("\n\nFor the full status report, please check\n");
  printf("status.log located in the same directory as this exe\n");
  printf("\n\nPress any key to quit\n");
  getch();
  return 0;
}