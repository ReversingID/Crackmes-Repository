Date:			July 25th 2007

Target:			CryptoKeygenMe #1 by TiGa
			on www.crackmes.de
			sebastech(at)sympatico.ca

Language:		Visual C++ 6.0

Work to do:		Make a keygen
			Write a solution
			Be sure you're able to explain it clearly