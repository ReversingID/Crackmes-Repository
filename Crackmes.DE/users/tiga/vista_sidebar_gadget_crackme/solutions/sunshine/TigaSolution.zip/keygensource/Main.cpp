/*
 * Keygen for TiGa's Vista Sidebar Gadget Crackme.
 *
 * Author: Sunshine
 * WEB: www.sunshine2k.de
 */

#include <windows.h>
#include <stdio.h>
#include "resource.h"

/*
 * Calculate serial
 */
void GetInfo(HWND hwnd, LPSTR varName)
{
	// temporary buffer
	char dest[256];
	ZeroMemory(&dest, 256);

	TIME_ZONE_INFORMATION timeinfo;
	GetTimeZoneInformation(&timeinfo);

	// get timezone displayname
	WideCharToMultiByte( CP_ACP, 0, timeinfo.StandardName, -1,
        dest, 256, NULL, NULL );
	// length of displayname
	int varMint = lstrlen(dest);

	// get timezone daylight displayname
	ZeroMemory(&dest, 256);
	WideCharToMultiByte( CP_ACP, 0, timeinfo.DaylightName, -1,
        dest, 256, NULL, NULL );
	int varvarvar = lstrlen(dest);

	int variableSerial2 = lstrlen(varName) * lstrlen(varName);
	variableSerial2 = varMint * varvarvar * lstrlen(varName);
	variableSerial2 *= lstrlen(varName);

	// get number of processors
	SYSTEM_INFO sysInfo;
	ZeroMemory(&sysInfo, sizeof(SYSTEM_INFO));
	GetSystemInfo(&sysInfo);
	__int64 varasoie = sysInfo.dwNumberOfProcessors;

	// get info about recycle bin
	SHQUERYRBINFO binInfo;
	ZeroMemory(&binInfo, sizeof(SHQUERYRBINFO));
	binInfo.cbSize = sizeof(SHQUERYRBINFO);
	SHQueryRecycleBin(NULL, &binInfo);

	// now build complete serial
	char serialPart1[MAX_PATH], serialPart2[MAX_PATH], serialPart3[MAX_PATH];
	ZeroMemory(&serialPart1, MAX_PATH);
	ZeroMemory(&serialPart2, MAX_PATH);
	ZeroMemory(&serialPart3, MAX_PATH);

	wsprintf(serialPart1, "%d", varasoie);
	wsprintf(dest, "%I64d", binInfo.i64Size);
	lstrcat(dest, "1");
	wsprintf(serialPart2, "%s", dest);
	wsprintf(serialPart3, "%I64d", (__int64)variableSerial2 * ((__int64)binInfo.i64NumItems + (__int64)10));
	lstrcat(serialPart1, serialPart2);
	lstrcat(serialPart1, serialPart3);
	wsprintf(dest, "%s", serialPart1);
	SetDlgItemText(hwnd, ID_EDITKEY, dest);
	return;
}

/*
 * Window procedure
 */
BOOL DlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
	case WM_CLOSE:
		{
			EndDialog(hwnd, 0);
		}
		break;

	case WM_COMMAND:
		{
			if ( (LOWORD(wParam) == ID_EDITNAME) && (HIWORD(wParam) == EN_CHANGE))
			{
				char tmpbuf[MAX_PATH];
				ZeroMemory(&tmpbuf, MAX_PATH);
				GetDlgItemText(hwnd, ID_EDITNAME, (LPSTR)&tmpbuf, MAX_PATH);
				GetInfo(hwnd, tmpbuf);
			}
		}
		break;

	default:break;
	}

	return FALSE;
}

/*
 * Entrypoint
 */
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine, int       nCmdShow )
{
	DialogBox(hInstance, MAKEINTRESOURCE(100), NULL, (DLGPROC)&DlgProc);
	return 0;
}