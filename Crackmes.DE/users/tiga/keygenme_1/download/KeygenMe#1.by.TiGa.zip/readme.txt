Date:			June 18th 2007

Target:			KeygenMe #1 by TiGa
			on www.crackmes.de
			sebastech(at)sympatico.ca

Language:		Visual C++ 6.0

Work to do:		Patch one byte to get rid of Time Trial
			Make a keygen
			Write a solution
			Do a little victory dance