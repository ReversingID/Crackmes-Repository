void Generate(HWND hWnd)
{
	char name[50], serial[50];
	unsigned char a[32] = {0};
	unsigned char p[32] = {0x20, 0x4E, 0x61, 0x6D, 0x65, 0x20, 0x3D, 0x20, 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}; // " Name = ";
	
	int len = GetDlgItemText(hWnd,IDC_NAME,name,50);
	if( len == 0 || len > 7 ){
		SetDlgItemText(hWnd,IDC_SERIAL,"Invalid name");
	}
	else
	{
	len += 9;
	for (int f = 8, fx = 0; f < len ; f++, fx++){
		p[f] = name[fx];}
		
	
	a[0] = rand() % 0xFF; // randomize first one
	for (int i = 0; i < len; i++){ // go through rest of the serial
		a[i+1] = a[i] ^ p[i];}


	for (int j = 0; j < 32-len; j++){
		a[j+len + 1] = rand() % 0xFF;} // randomize rest serial

	for (int k = 0; k < 16; k++)
	{
		wsprintf(serial + k*2, "%02X", a[k]);
	}
	SetDlgItemText(hWnd,IDC_SERIAL,serial);
	}

}
