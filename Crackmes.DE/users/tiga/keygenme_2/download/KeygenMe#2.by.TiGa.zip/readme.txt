Date:			June 30th 2007

Target:			KeygenMe #2 by TiGa
			on www.crackmes.de
			sebastech(at)sympatico.ca

Language:		Visual C++ 6.0

Work to do:		Make a keygen
			Write a solution
			Pat yourself on the back