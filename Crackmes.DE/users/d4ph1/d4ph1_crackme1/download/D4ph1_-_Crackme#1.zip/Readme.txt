- File : D4ph1 - Crackme#1.exe

- Type : Name/Serial and some easy crypto stuff

- Difficulty : 1/10 [For newbies]

- Rules : Patching or Touching any byte of the program is not allowed and will be punished by The Law! :p 

- Target : Make a keygenerator and find the secret message hiding inside the crackme.

- Not packed or protected by any program.

Hi!
This is my very first crackme ever! Its coded in pure assembly and compiled with MASM.
There are two parts you have to solve:

1.Make the keygenerator.
2.Find the secret message.

When you solve them both you can write a tutorial.
I hope that everyone who solves this will enjoy it - hopefully this is the target of the crackme! :)


Tip : You have to "travel" inside the crackme... ;)


PS : If you want send me your solution to fistiks16(at)hotmail(dot)com and tell me your opinion about it or suggest something...or anything :)


D4ph1
									EOF