Crackme #1 by citylights

You need a secret code to escape from the vice city.
Find the correct numbers to calculate the code.

have fun