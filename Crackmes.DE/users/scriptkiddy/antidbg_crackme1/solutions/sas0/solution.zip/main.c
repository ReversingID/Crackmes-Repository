#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
  int i = 0;
  char inputBuffer[15];
  char userName[15];
  char anyKeyPress;

  printf("Keygen for ScriptKiddy's AntiDBG Crackme#1\n\nValid chars are between '1' and '5' and there must be 10 chars\n\nEnter username: ");
  
  if(!fgets(inputBuffer,11,stdin)){
    printf("\n\nInput error\n");
    return 1;
  }

  memcpy(userName,inputBuffer,sizeof(inputBuffer));

  for(i = 0; i < 10; i++){
    if ((inputBuffer[i] < '1') || (inputBuffer[i] > '5') ){
      printf("\n\nInvalid input\n");
      return 1;
    }
    inputBuffer[i]++;
  }

  printf("\n\nPassword for username %s is %s\n",userName,inputBuffer);
}