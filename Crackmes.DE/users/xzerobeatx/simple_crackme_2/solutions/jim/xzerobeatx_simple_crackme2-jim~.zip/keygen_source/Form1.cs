﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace keygen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            txtMachineName.Text = Environment.MachineName;
            txtUserName.Text = Environment.UserName;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtName.Text == "")
            {
                txtName.Text = "You must enter a name.";
                return;
            }
            String signature = "r" + (txtName.Text.GetHashCode() * 45) + "*d" +
                               (txtMachineName.Text.GetHashCode() * 25) + "*t" +
                               ((txtUserName.Text.GetHashCode() * 32) / 10) + "*";
            if (this.saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                FileStream file = new FileStream(saveFileDialog1.FileName, FileMode.Create);
                StreamWriter writer = new StreamWriter(file);
                writer.Write(signature);
                writer.Flush();
                writer.Close();
                file.Close();
            }
        }
    }
}
