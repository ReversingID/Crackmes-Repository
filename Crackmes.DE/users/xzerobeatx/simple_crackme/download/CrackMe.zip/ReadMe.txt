
  ::: AIO:Security - CrackMe :::::::::::::::::::::::::::::::::::::::::::::::
  :: 									  ::
  :: Security.AIOStudio.dk/crackme					  ::
  :: Copyright (c) 2008 by AIO:Studio and AIO:Security			  ::
  ::									  ::
  ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


  ::: DETAILS ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
  ::				:::					  ::
  :: Difficulty			::: Very Easy				  ::
  :: Language 			::: .NET				  ::
  :: Creator 			::: xZeroBeatx				  ::
  :: Contact			::: MortenOlsen@Live.com		  ::
  ::				:::					  ::
  ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


  ::: GOALS ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
  ::									  ::
  :: There are to goals to this CrackMe					  ::
  ::									  ::
  ::..:: GOAL 1 ::........................................................::
  ::									  ::
  :: When you open the file you will get a screen saying your trial	  ::
  :: has ended. Therefore you are not even allowed to enter a serial	  ::
  :: Therefore the first you will have to do is to remove this screen	  ::
  ::									  ::
  ::..:: GOAL 2 ::........................................................::
  ::									  ::
  :: Well now you just need to type in a serial... but what is it?	  ::
  :: The serial is calculated by your "Name".				  ::
  :: Make a working key generator, where you enter in a name and get	  ::
  :: a working serial							  ::
  ::									  ::
  ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


  ::: BOTTOM LINE ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
  ::									  ::
  :: When you complete this CrackMe you will be transfered to a webpage	  ::
  :: where you can enter your name and e-mail (e-mail adresses are	  ::
  :: hidden) to get on the "Wall of Fame".				  ::
  ::									  ::
  :: - Have fun, xZeroBeatx :D						  ::
  ::									  ::
  ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::