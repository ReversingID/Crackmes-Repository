﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            txtName.Text = "JiM~2008";
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            if (txtName.Text.Length < 6)
            {
                txtSerial.Text = "Name must be at least 6 characters";
                return;
            }
            int hashCode = this.txtName.Text.GetHashCode();
            int num2 = 3 * this.txtName.Text.GetHashCode();
            int num3 = this.txtName.Text.Substring(2, 4).GetHashCode() * num2;
            int num4 = 0;
            for (int i = 0; i < hashCode.ToString().Length; i++)
            {
                int num6 = this.txtName.Text.GetHashCode() * i;
                num4 += num6;
            }
            num4 = num4.GetHashCode();
            string str = hashCode.GetHashCode().ToString() + "-" + num2.GetHashCode().ToString() + "-" + num3.GetHashCode().ToString() + "-" + num4.GetHashCode().ToString();
            str = str + "-" + str.Length;
            txtSerial.Text = str;
        }
    }
}
