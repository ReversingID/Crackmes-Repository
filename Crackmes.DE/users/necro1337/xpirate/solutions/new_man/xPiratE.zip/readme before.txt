it took me 1 min to solve this program i open the program in olly and in the first time i search for all strings
 i saw a lot of strings and before i search in those strings i analyzed the program and then search for strings and
 i saw about 7 strings and there i saw the string of bad message i got there and see that there is a function for check
 the code and JE after that i open the function to try to understand what she doing and see the code in EDX


btw the code is 77789977283