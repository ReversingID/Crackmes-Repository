
#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include <conio.h>

void main()
{
	int namevalue=0;
	int tmpint;
	int namelen=0;
	int regcodevalue=0;
	char name[256];
	char * pname=&name[0];
	int tmpi;
	short key[8]={0x0c,0x0a,0x13,0x09,0x0c,0x0b,0x0a,0x08};

	printf("name:");
	do
	{
		if(scanf("%s",pname)==0)
			printf("\nPlz input name!\n");
		namelen=strlen(pname);
		if(namelen<5)
			printf("length of name should great than 4!\n");
	}while(namelen<5||namelen>255);
	for(tmpi=3;tmpi<namelen;tmpi++)
	{
		tmpint=name[tmpi];
		tmpint*=key[(tmpi-3)%8];
		namevalue+=tmpint;
	}
	regcodevalue=namevalue-100;
	printf("serial number:%d\n",regcodevalue);
	getch();
}