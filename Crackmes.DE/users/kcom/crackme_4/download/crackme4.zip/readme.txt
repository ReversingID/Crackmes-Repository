Crackme 4 (keygen) by akcom (akcom@att.net)
this is my 4th attempt at a crackme, a bit more confusing
this time, and in my opinion, more interesting :)
have fun, and remember, no patching!