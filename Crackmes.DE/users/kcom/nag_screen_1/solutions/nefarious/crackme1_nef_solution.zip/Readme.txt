thx to thigo :)

//******************** Program Entry Point ********
:0040101B 55                      push ebp
:0040101C 8BEC                    mov ebp, esp
:0040101E 6A00                    push 00000000<--- jmp to :00401032

* Possible StringData Ref from Data Obj ->"GET RID OF ME!"
                                  |
:00401020 6800304000              push 00403000

* Possible StringData Ref from Data Obj ->"Get Rid OF ME!!!!"
                                  |
:00401025 6810304000              push 00403010
:0040102A 6A00                    push 00000000

* Reference To: USER32.MessageBoxA, Ord:01BEh
                                  |
:0040102C FF150C204000            Call dword ptr [0040200C]
:00401032 6A00                    push 00000000
:00401034 6800104000              push 00401000
:00401039 6A00                    push 00000000

...snip

unconditional jump from :0040101E to :00401032 . thats it.
it is my first submission :D


nef