BoR0's 1st decryptme
--------------------

Here's my first decryptme. Try to decrypt the string
and find the algorithm that's doing the encryption..

If you write a tutorial include some encrypted and
decrypted strings, a table of characters and also
some code snippets.

This crackme is made to be easy, hope you'll have fun.

see you.

BoR0 (c) August, 2004
