    BoR0's 2nd crackme (15/09/2003)

Inside the program, there is hidden sentence which is encrypted by _unknown_ program.
The program is also packed by _unknown_ packer.

Once you get the encrypted message, send e-mail to * * BoR0@lockless.com * *
and follow these steps to include in mail:


     1. Decrypt it, send the encrypted AND decrypted message,
     2. Tell us what was it encrypted with,
     3. Tell us what packer was it used to the application.


In message subject please type 'BORO CRACKME2 SOLUTION'
while the other messages will be blocked coming from without this subject.

If your message has the correct answers for all three options, you will get an e-mail back
for permission to write a tutorial on how you cracked the application.


Greets go out to all BiW and Lockless members:
Detten, Lord Anshar, X-Lock, icekiller, Zephyrous(YOU!), Coder, parabytes and all the others

http://biw.rult.at (c) 2003