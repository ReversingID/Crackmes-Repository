BoR0's 5th crackme
------------------

Requires luck or intelligence! :-)
You will deal with modified algorithms, hell!

Hehe, not that hard in my opinion,
but it could get rated at least 4.

Have fun and good luck!



28.08.2005 (happy birthday sis)