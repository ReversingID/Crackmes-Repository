#include <stdio.h>
main() {

    char username[20];
    int i;
    unsigned long long total=0;
    int serial;
    char finalSerial[13];
    char serialHex[9];
    unsigned long long constant = 949149370;
    unsigned long long temp, temp2;
    int a,b,c,d;
    unsigned long long aggregate, aggregate2;
    printf("Coded by eraghant\n");
    printf("eraghant@gmail.com\n");
    printf("What's your username?\n");
    scanf("%s", username);

    for(i=0; i<strlen(username); i++) {
        temp = (unsigned long long)username[i]*constant;
        temp = temp & 4042322160;       //F0F0F0F0h... works..

        temp /=16;

         //Now the aggregation function.... a number like 0a0b0c0d -> 0000abcd
        a= temp/16777216;       //1000000h
        temp %= 16777216;
        b= temp/65536;          //10000h
        temp %= 65536;
        c= temp/256;            //100h
        temp %= 256;
        d= temp;

        aggregate = a*4096;
        aggregate += b*256;
        aggregate += c*16;
        aggregate += d;
        aggregate = aggregate*65536;  //SHL 10h


        temp = (unsigned long long)username[i]*constant;
        temp = temp & 252645135;        //0F0F0F0Fh;
        a= temp/16777216;       //1000000h
        temp %= 16777216;
        b= temp/65536;          //10000h
        temp %= 65536;
        c= temp/256;            //100h
        temp %= 256;
        d= temp;

        aggregate2 = a*4096;
        aggregate2 += b*256;
        aggregate2 += c*16;
        aggregate2 += d;

        aggregate += aggregate2;
        total=total+aggregate;           //004014CC: ADD DWORD PTR DS:[EAX],EDX

        constant += 322376503;      //13371337h
        constant %= 4294967296;     //FFFFFFFFh
        total %= 4294967296;       //FFFFFFFFh
    }


    sprintf(serialHex,"%08X", total);
    finalSerial[0]='x';
    finalSerial[1]='D';
    finalSerial[2]='-';
    finalSerial[3]=serialHex[0];
    finalSerial[4]=serialHex[1];
    finalSerial[5]=serialHex[2];
    finalSerial[6]=serialHex[3];
    finalSerial[7]='-';
    finalSerial[8]=serialHex[4];
    finalSerial[9]=serialHex[5];
    finalSerial[10]=serialHex[6];
    finalSerial[11]=serialHex[7];
    finalSerial[12]='\0';
    printf("Serial: %s\n", finalSerial);
}

