#include <iostream.h>
#include <stdlib.h>
#include <windows.h>
#include <math.h>
#include <stdio.h>
#define ROR(a, b, width) (((a) >> (b)) | ((a) << ((width) - (b))))
#define ROL(a, b, width) (((a) << (b)) | ((a) >> ((width) - (b))))
int main()
{
      char name1[51];
      int  codearray[8]={0x43275,0xAED2384,0xD377AE7,0xD54837D,0xFE53743,0x3472389,0x23488};
      unsigned int solution;
      unsigned int sideregister;
      unsigned int tempval;
      unsigned int eedeex;
      int counter=0;
      int l;
      char combined[150];
      char acUserName[150];
      DWORD nUserName = sizeof(acUserName);
      GetUserName(acUserName, &nUserName);
      combined=acUserName;
      cout << "*********************" << endl;
      cout << "*Enter Your Name Plz*" << endl;
      cout << "*********************" << endl;
      cout << "Name:";
      //use getline so we can handle names with spaces in them standard cin << can't do this
      cin.getline(name1, 51);
      strncat(combined,name1,strlen(name1));
      int length=strlen(name1);
      //encode our name field first
      cout << endl << "length is " << length << endl;
      while (counter<length)
      {
       solution=name1[counter]*name1[counter];                    //imul eax
       sideregister=solution+solution*2;              //lea     ecx, [eax+eax*2]
       sideregister=(sideregister << 3);             //shl ecx, 3
       sideregister=sideregister-solution;             //sub     ecx, eax
       solution=sideregister;                         //mov     eax, ecx
       solution=~sideregister;                        //not     eax
       solution=solution * sideregister;              //imul    eax, ecx
       solution= (solution << 2);                     //shl     eax, 2
       tempval= codearray[(counter%7)] + sideregister;          //mov     edx, ds:Array_Size_8[edx*4]
                                                       //add     edx, ecx
       sideregister= sideregister | 0xFFFFFFFF;       //or      ecx, 0FFFFFFFFh
       tempval= tempval ^ solution;                   //xor     edx, eax
       solution=solution ^ solution;                  //xor     eax, eax
       if (counter==0)
            tempval=tempval ^ 0x62387DEA;                  //xor     edx, ebx (ebx=62387DEAh)
       else
          tempval=tempval ^ eedeex;
       tempval=tempval ^ counter;                     //xor     edx, esi
       eedeex=tempval;
       counter++;
      }
      std::cout << "tempval is " << std::hex << tempval << " after kgname manipulation" << endl;
      counter =0;
      int secondval;
      int flipval;
      int poop;
      //reiterate for the length of our username
      while (counter <nUserName-1)
      {
      secondval=(pow(name1[counter],4))*8;
      flipval=secondval;
      flipval=~flipval;
      flipval=secondval*flipval;
      poop=codearray[counter%7]+secondval;
      flipval=flipval*4;
      poop=poop ^ flipval;
      poop=poop ^ (counter+0x42);
      tempval=tempval ^ poop;
      counter++;
      }

      counter =(strlen(name1) + strlen(acUserName));
      int lmb;
      int rmb;
      //reverse operations on the generated assembly code
      while (counter>0)
      {
      counter--;
      rmb=combined[counter]&0xF;
      lmb=(combined[counter]-rmb) / 0x10;
      switch(rmb)
      {
             case 0:
                  tempval=tempval ^ 0x327928;
                  //std::cout << rmb << std::hex << "r " << tempval << "tempval=tempval ^ 0x327928; " << endl;
                  break;
                  //xor with 0x327928
             case 1:
                  tempval=tempval-0xD743D;
                  //std::cout << rmb << std::hex << "r " << tempval << "tempval=tempval-0xD743D; " << endl;
                  //add 0xD743Dh
                  break;
             case 2:
                  tempval=tempval ^ 0xC0DEFFFF;
                  // std::cout << rmb << std::hex << "r " << tempval << "tempval=tempval ^ 0xC0DEFFFF; " << endl;
                  //xor serial with 0xC0DEFFFFh
                  break;
             case 3:
                  tempval = ROR(tempval, 0x13, 32);
                  // std::cout << rmb << std::hex << "r " << tempval << "tempval = ROR(tempval, 0x13, 32); " << endl;
                  //rol 13h
                  break;
             case 4:
                  tempval=~tempval;
                  //std::cout << rmb << std::hex << "r " << tempval << " tempval=~tempval; " << endl;
                  //not serial
                  break;
             case 5:
                  tempval= tempval- 0x2347834;
                  // std::cout << rmb << std::hex << "r " << tempval << "tempval= tempval- 0x2347834; " << endl;
	              //add 0x2347834h to serial
                  break;
             case 6:
                  tempval=tempval ^ 0x855454;
                 // std::cout << rmb << std::hex << "r " << tempval << "tempval=tempval ^ 0x855454; " << endl;
	              //xor serial with 0x855454h
                  break;
             case 7:
                  tempval= tempval ^ 0xDEDDF;
                  // std::cout << rmb << std::hex << "r " << tempval << "tempval= tempval ^ 0xDEDDF; " << endl;
	              //xor with 0xDEDDFh
                  break;
             case 8:
                  tempval=tempval-0x347235;
                  //std::cout << rmb << std::hex << "r " << tempval << "tempval=tempval-0x347235; " << endl;
	              //add 0x347235
                  break;
             case 9:
                  tempval= ROL(tempval,0x23,32);
                  //std::cout << rmb << std::hex << "r " << tempval << " tempval= ROL(tempval,0x23,32); " << endl;
             	  //ror 23h
                  break;
             case 10:
                  tempval=tempval+0x3834FF53;
                  //std::cout << rmb << std::hex << "r " << tempval << "tempval=tempval+0x3834FF53; " << endl;
             	  //sub 0x3834FF53h
                  break;
             case 11:
                  tempval=tempval ^ 0xDEAD;
                  //std::cout << rmb << std::hex << "r " << tempval << "tempval=tempval ^ 0xDEAD; " << endl;
             	  //xor 0xDEDDh
                  break;
             case 12:
                  tempval=tempval + 0x23743;
                 // std::cout << rmb << std::hex << "r " << tempval << " tempval=tempval + 0x23743; " << endl;
             	  //sub 0x23743h
                  break;
             case 13:
                  tempval=tempval-0xDEFE34;
                  //std::cout << rmb << std::hex << "r " << tempval << "tempval=tempval-0xDEFE34; " << endl;
             	  //add DEFE34h
                  break;
             case 14:
                  tempval=tempval ^ 0x485FD;
                  // std::cout << rmb << std::hex << "r " << tempval << "tempval=tempval ^ 0x485FD; " << endl;
             	  //xor serial with 0x485FD
                  break;
             case 15:
                  tempval=tempval + 0x236FFA;
                //std::cout << rmb << std::hex << "r " << tempval << "tempval=tempval + 0x236FFA; " << endl;
             	  //sub 0x236FFAh
                  break;
      }
            switch(lmb)
      {
             case 0:
                  tempval=tempval ^ 0x327928;
                //std::cout << lmb << std::hex << "l " << tempval << "tempval=tempval ^ 0x327928; " << endl;
                         break;
                  //xor with 0x327928
             case 1:
                  tempval=tempval-0xD743D;
                 //  std::cout << lmb << std::hex << "l " << tempval << "tempval=tempval-0xD743D; " << endl;
                  //add 0xD743Dh
                  break;
             case 2:
                  tempval=tempval ^ 0xC0DEFFFF;
                  // std::cout << lmb << std::hex << "l " << tempval << "tempval=tempval ^ 0xC0DEFFFF; " << endl;
                  //xor serial with 0xC0DEFFFFh
                  break;
             case 3:
                  tempval = ROR(tempval, 0x13, 32);
                  // std::cout << lmb << std::hex << "l " << tempval << " tempval = ROR(tempval, 0x13, 32); " << endl;
                  //rol 13h
                  break;
             case 4:
                  tempval=~tempval;
                  // std::cout << lmb << std::hex << "l " << tempval << "tempval=~tempval; " << endl;
                  //not serial
                  break;
             case 5:
                  tempval=tempval-0x2347834;
               //std::cout << lmb << std::hex << "l " << tempval << "tempval=tempval-0x2347834; " << endl;
	              //add 0x2347834h to serial
                  break;
             case 6:
                  tempval=tempval ^ 0x855454;
                   //std::cout << lmb << std::hex << "l " << tempval << " tempval=tempval ^ 0x855454; " << endl;
	              //xor serial with 0x855454h
                  break;
             case 7:
                  tempval= tempval ^ 0xDEDDF;
                  // std::cout << lmb << std::hex << "l " << tempval << "tempval= tempval ^ 0xDEDDF; " << endl;
	              //xor with 0xDEDDFh
                  break;
             case 8:
                  tempval=tempval-0x347235;
                  ///  std::cout << lmb << std::hex << "l " << tempval << "tempval=tempval-0x347235; " << endl;
	              //add 0x347235
                  break;
             case 9:
                  tempval= ROL(tempval,0x23,32);
                  //std::cout << lmb << std::hex << "l " << tempval << "tempval= ROL(tempval,0x23,32); " << endl;
             	  //ror 23h
                  break;
             case 10:
                  tempval=tempval+0x3834FF53;
                  //  std::cout << lmb << std::hex << "l " << tempval << "tempval=tempval+0x3834FF53; " << endl;
             	  //sub 0x3834FF53h
                  break;
             case 11:
                  tempval=tempval ^ 0xDEAD;
                  // std::cout << lmb << std::hex << "l " << tempval << "tempval=tempval ^ 0xDEAD; " << endl;
             	  //xor 0xDEADh
                  break;
             case 12:
                  tempval=tempval + 0x23743;
                   // std::cout << lmb << std::hex << "l " << tempval << " tempval=tempval + 0x23743; " << endl;
             	  //sub 0x23743h
                  break;
             case 13:
                  tempval=tempval-0xDEFE34;
                   // std::cout << lmb << std::hex << "l " << tempval << " tempval=tempval-0xDEFE34;" << endl;
             	  //add DEFE34h
                  break;
             case 14:
                  tempval=tempval ^ 0x485FD;
                   //std::cout << lmb << std::hex << "l " << tempval << " tempval=tempval ^ 0x485FD;" << endl;
             	  //xor serial with 0x485FD
                  break;
             case 15:
                  tempval=tempval + 0x236FFA;
                  // std::cout << lmb << std::hex << "l " << tempval << "tempval=tempval + 0x236FFA; " << endl;
             	  //sub 0x236FFAh
                  break;
      }


      }
      cout << "Your serial is " << endl;
      std::cout << std::hex << tempval <<  endl;
      system("PAUSE");
      return 0;
}
