#!/usr/bin/perl
##-- kbp - 20080929 --##

use strict;


##-- vars --##
my ($name, $serial);


##-- subs --##
sub stringToHex {

  my $result = "";
  foreach my $d (split(//, shift())) {
    $d = sprintf("%X", (ord($d)));
    $result = $result . "$d";
  }
  return $result;
  
}

sub generateSerial {

  $serial = stringToHex($name);
  ##--Round 1 character replacement
  $serial =~ tr/0/I/;
  $serial =~ tr/1/Q/;
  $serial =~ tr/2/P/;
  $serial =~ tr/3/T/;
  $serial =~ tr/4/J/;
  $serial =~ tr/5/K/;
  $serial =~ tr/6/L/;
  $serial =~ tr/7/M/;
  $serial =~ tr/8/S/;
  $serial =~ tr/9/B/;
  $serial =~ tr/A/R/;
  $serial =~ tr/B/Z/;
  $serial =~ tr/C/X/;
  $serial =~ tr/D/G/;
  $serial =~ tr/E/H/;
  $serial =~ tr/F/U/;
  ##--Round 2 character replacement
  $serial =~ s/I/107292/g;
  $serial =~ s/Q/238553/g;
  $serial =~ s/P/366231/g;
  $serial =~ s/T/412893/g;
  $serial =~ s/J/539818/g;
  $serial =~ s/K/671095/g;
  $serial =~ s/L/734212/g;
  $serial =~ s/M/891034/g;
  $serial =~ s/S/990126/g;
  $serial =~ s/B/018374/g;
  $serial =~ s/R/023986/g;
  $serial =~ s/Z/037849/g;
  $serial =~ s/X/047858/g;
  $serial =~ s/G/057861/g;
  $serial =~ s/H/069912/g;
  $serial =~ s/U/072983/g;
  ##--Round 3 character replacement
  $serial =~ s/107292/J/g;
  $serial =~ s/238553/D/g;
  $serial =~ s/366231/T/g;
  $serial =~ s/412893/I/g;
  $serial =~ s/539818/N/g;
  $serial =~ s/671095/W/g;
  $serial =~ s/734212/K/g;
  $serial =~ s/891034/Y/g;
  $serial =~ s/990126/B/g;
  $serial =~ s/018374/X/g;
  $serial =~ s/023986/A/g;
  $serial =~ s/037849/L/g;
  $serial =~ s/047858/P/g;
  $serial =~ s/057861/V/g;
  $serial =~ s/069912/R/g;
  $serial =~ s/072983/E/g;
  
}


##-- main --##
print "-= This is a keygen for fisser's keygenme from www.crackmes.de =-\n";
print "Please enter your name: ";
$name = <STDIN>;
chomp $name;
&generateSerial;
print "Your serial is: $serial\n";
