Solution by MACH4 for "KeygenMe by Fisser"

Get name
Convert ascii bytes to sequence of hex numbers
Find and replace as shown in separate list
remove original name length from resulting hash

Done!

Greetz!
MACH4