======================================
CrackMe4rd by Aenox
======================================

1. Remove donation nag
2. Remove button activation timer
3. Find valid details for your name
	or Make keygen
	or Crack as a last resort
4. Have fun

- Aenox