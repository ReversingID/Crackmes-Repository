/***************************************************************************
* YASPATCH.C
*
* (C) Copyright 2009 BY EXEVF All rights reserved.
*
*****************************************************************************/
#include <windows.h>               /* for all Window apps                  */
#include <stdio.h>                 /* for sscanf()                         */
//#include <string.h>                /* for strcpy()                         */
//#include <ctype.h>                 /* for isxdigit() isascii() */

#include <psapi.h>
#include <Winbase.h>
#include <Winnt.h>

             
#include "yaspatch.h"
#include  "resource.h"              /* resource defines                     */

#if (defined(WIN32) || defined(_WIN32) || defined(_WIN32_))
#undef _WIN32_
#define _WIN32_
#endif

#if     defined(_MSC_VER)          /* Microsoft C/C++ compiler             */
#ifdef _WIN32_
#define EXPORT
#else                              /* for WIN16                            */
#define EXPORT _export             /* for exported callback routines       */
#endif
#elif  defined(__BORLANDC__)       /* Borland C/C++ Compiler               */
#define EXPORT _export             /* for exported callback routines       */
#endif

#if    defined(__cplusplus)
#define EXPORT_PROC    extern "C"
#else
#define EXPORT_PROC    extern
#endif
#define LOCAL_PROC     static

#define START_YAS_PATCH      0x1234     /* Message to start eval program        */
#define PPROC           FARPROC    /* for MakeProcInstance()               */

#ifdef _WIN32_
#define MESSAGE         UINT
#define GET_LOWORD(param) LOWORD(param)
#define GET_HIWORD(param)  HIWORD(param)
#else                              /* Windows 16 bit                       */
#define MESSAGE         WORD
#define WPARAM          WORD
#define GET_LOWORD(param)  param
#define GET_HIWORD(param)   param
#endif

#define STR_BUF_SIZE     255

#ifdef _WIN32_
#define xFreeProcInstance( param )
#else
#define xFreeProcInstance( param )   FreeProcInstance( param )
#endif

// Constant Defination for input validation

UINT ExitCodeYAS;
STARTUPINFO si;
PROCESS_INFORMATION pi;
HANDLE hProcess;
DWORD dw;
char szProcessName[MAX_PATH] = "unknown";
int yas_counter;
unsigned long yas_id,yas_new_id[5],yas_data_address;
unsigned char patch_code[2];
unsigned char patch_code_app[2];
HANDLE  ghInst;											     /* Current instance handle              */
HANDLE  ghHourGlassCursor;								     /* Handle to the hour glass cursor      */
HWND    ghWndMain;										     /* Main Window Handle                   */
HWND    ghMainDlg							= NULL;          /* Main Dialog window                   */
HWND    ghCurrentDlg						= NULL;			 /* The current modeless dialog          */
char    gAppName[]							= "YASPATCH";    /* Application name                     */
char    gString[STR_BUF_SIZE]				= "";			 /* generic string                       */
char    gMsg[STR_BUF_SIZE]					= ""; 
char    tempstr[STR_BUF_SIZE]				= "";			 /* Another generic string				 */
char    gStatus[STR_BUF_SIZE]				= "";			 /* Status string						 */
char    gResult[STR_BUF_SIZE]				= "";			 /* Result string						 */
char    gFullStatus[STR_BUF_SIZE]			= "";			 /* Extended Status string				 */
char    gViewText[STR_BUF_SIZE]				= "";			 /* String for View dialog box			 */
unsigned char yas_content[0x104000l],yas_data_code[0x8000l],yas_code[256],yas_app[0x83000l];
int yas_code_size;
unsigned long  yas_app_address,yas_app_size,yas_app_loc;
int app_exe_create;
/* function prototypes */

LOCAL_PROC
void ToggleButton( HWND hWnd, WORD theButton );
LOCAL_PROC
BOOL InitApplication( HANDLE hInstance );
LOCAL_PROC
BOOL InitInstance( HANDLE hInstance, int nCmdShow );
LOCAL_PROC
void CenterWindow( HWND hWnd, int  top );

void FindProcessNameAndID( DWORD processID )
{
	
       HANDLE hProcess = OpenProcess( PROCESS_QUERY_INFORMATION |
                                   PROCESS_VM_READ,
                                   FALSE, processID );

    if (NULL != hProcess )
    {
        HMODULE hMod;
        DWORD cbNeeded;

        if ( EnumProcessModules( hProcess, &hMod, sizeof(hMod), 
             &cbNeeded) )
        {
            GetModuleBaseName( hProcess, hMod, szProcessName, 
                               sizeof(szProcessName) );
        }
        else return;
    }
    else return;
_tolower( *szProcessName );
  
  if(!lstrcmpi( szProcessName,   "yas.exe"))
  {
yas_new_id[yas_counter]=processID;
yas_counter++;
  }
 
    CloseHandle( hProcess );
}

void find_process_exevf()
{
int j;

   
  DWORD aProcesses[1024], cbNeeded, cProcesses;
    unsigned int i;
	yas_counter=0;
for (j=0;j<5;j++) yas_new_id[j]=0;

    if ( !EnumProcesses( aProcesses, sizeof(aProcesses), &cbNeeded ) )
        return;

    cProcesses = cbNeeded / sizeof(DWORD);
 
for ( i = 0; i < cProcesses; i++ )
        FindProcessNameAndID( aProcesses[i] );



	return;
}

void read_yas_app(void )
{
SIZE_T 	tttt;
FILE *out;
unsigned long  start,displacement,hedrno,calac;

MEMORY_BASIC_INFORMATION lpBuffer3;
LPCVOID lpAddress3; 
HANDLE hProcess3;
gViewText[0] = '\0';
gString[0]   = '\0';


find_process_exevf();
if((yas_new_id[0]!=0)&&(yas_new_id[1]!=0)&&(yas_new_id[2]!=0))
{




hProcess3 = OpenProcess(  PROCESS_ALL_ACCESS,FALSE, yas_new_id[2] );

start=0x0;
	lpAddress3= (LPCVOID) start;
		

	tttt=VirtualQueryEx(hProcess3,lpAddress3,&lpBuffer3,sizeof(lpBuffer3));
do{

start=start+(unsigned long )lpBuffer3.RegionSize;
	lpAddress3=(LPCVOID) start;	
		
 tttt=VirtualQueryEx(hProcess3,lpAddress3,&lpBuffer3,sizeof(lpBuffer3));


}while((lpBuffer3.AllocationProtect!=0X4l)||(lpBuffer3.Protect!=0X4l)||(lpBuffer3.RegionSize<=0X10000l)||(lpBuffer3.Type!=0X20000l)||(start>=0X400000l)); //||(start!=0X400000l)

 yas_app_address=start;



ReadProcessMemory(hProcess3,lpBuffer3.BaseAddress,yas_app,lpBuffer3.RegionSize,NULL);
start=0x0l;
do
{
if((yas_app[start]=='M')&&(yas_app[start+1]=='Z'))
{
yas_app_loc=start;
start=lpBuffer3.RegionSize-0x1;
}
start++;
}while (start!=lpBuffer3.RegionSize);


//writing app.exe file

if((yas_app[yas_app_loc]=='M')&&(yas_app[yas_app_loc+1]=='Z'))

{
displacement=yas_app[yas_app_loc+0x3c]*0x1l+yas_app[yas_app_loc+0x3d]*0x100l

             +yas_app[yas_app_loc+0x3e]*0x10000l+yas_app[yas_app_loc+0x3f]*0x1000000l;



hedrno=yas_app[yas_app_loc+displacement+6l]*0x1l+yas_app[yas_app_loc+displacement+7l]*0x100l;


calac=yas_app_loc+  displacement+0xf8l +0x28l*hedrno-0x18l;
yas_app_size=calac;

yas_app_size=yas_app[calac]*0x1l+yas_app[calac+1]*0x100l

             +yas_app[calac+2]*0x10000l+yas_app[calac+3]*0x1000000l

             +yas_app[calac+4]*0x1l+yas_app[calac+5]*0x100l

             +yas_app[calac+6]*0x10000l+yas_app[calac+7]*0x1000000l;

if((yas_app_loc!=0x0l)&&(yas_app_size!=0x0l))
{

if ((out=fopen("APP.EXE","w+b"))==NULL)
 {
	 fclose(out);
	
  }
else
{
fseek(out,0l,SEEK_SET); 
start=0x0l;
do
{
fputc(yas_app[yas_app_loc+start],out);

start++;
}while(start<yas_app_size);
app_exe_create=1;
 fclose(out);



}


}

}



CloseHandle( hProcess3 );


}


} 



void read_yas_code(void )
{
SIZE_T 	tttt;
MEMORY_BASIC_INFORMATION lpBuffer3;
HANDLE hProcess3;
LPCVOID lpAddress3; 

unsigned long  code_size,start,start_code;
int i,j;
gViewText[0] = '\0';
gString[0]   = '\0';


find_process_exevf();
if((yas_new_id[0]!=0)&&(yas_new_id[1]!=0)&&(yas_new_id[2]!=0))
{


hProcess3 = OpenProcess(  PROCESS_ALL_ACCESS,FALSE, yas_new_id[2] );

start=0x0;
	lpAddress3= (LPCVOID) start;
		

	tttt=VirtualQueryEx(hProcess3,lpAddress3,&lpBuffer3,sizeof(lpBuffer3));
do{

start=start+(unsigned long )lpBuffer3.RegionSize;
	lpAddress3=(LPCVOID) start;	
		
 tttt=VirtualQueryEx(hProcess3,lpAddress3,&lpBuffer3,sizeof(lpBuffer3));


}while((lpBuffer3.AllocationProtect!=0X4l)||(lpBuffer3.Protect!=0X4l)||(lpBuffer3.RegionSize!=0X4000l)||(lpBuffer3.Type!=0X20000l)||(start>=0X400000l)); //||(start!=0X400000l)

ReadProcessMemory(hProcess3,lpBuffer3.BaseAddress,yas_data_code,lpBuffer3.RegionSize,NULL);

for(i=0;i<0x4000-4;i++)
{
if((yas_data_code[i]==0xbd)&&(yas_data_code[i+1]==0x67)&&(yas_data_code[i+2]==0x43)&&(yas_data_code[3]==0x00))
start=(unsigned long )i;

}

i=(int)(start-8);
start_code=yas_data_code[i]*0x1l+yas_data_code[i+1]*0x100l
          +yas_data_code[i+2]*0x10000l+yas_data_code[i+3]*0x1000000l;
yas_data_address=start_code;
yas_data_address=yas_data_address&0x0ffff0000l;
tttt=VirtualQueryEx(hProcess3,(LPCVOID)yas_data_address,&lpBuffer3,sizeof(lpBuffer3));

if ((lpBuffer3.AllocationProtect!=0X4l)||(lpBuffer3.Protect!=0X4l)||(lpBuffer3.RegionSize!=0X8000l)||(lpBuffer3.Type!=0X20000l)); //||(start!=0X400000l)

{
ReadProcessMemory(hProcess3,lpBuffer3.BaseAddress,yas_data_code,0x8000l,NULL);
dw=GetLastError();
}
start=start_code-yas_data_address;
i=(int)start;

code_size=yas_data_code[i-4]+yas_data_code[i-3]*0x100l+
          +yas_data_code[i-2]*0x10000+yas_data_code[i-1]*0x1000000l;

yas_code_size=code_size&0x0ffl;
for(j=0;j<(int)yas_code_size;j++)
{
yas_code[j]=yas_data_code[i+j];

}
 


CloseHandle( hProcess3 );




}
} 





void read_write_process(void )
{
SIZE_T 	tttt;
HANDLE hProcess3;
MEMORY_BASIC_INFORMATION lpBuffer1;
gViewText[0] = '\0';
gString[0]   = '\0';



find_process_exevf();
if((yas_new_id[0]!=0)&&(yas_new_id[1]!=0)&&(yas_new_id[2]!=0))
{


hProcess3 = OpenProcess(  PROCESS_ALL_ACCESS,FALSE, yas_new_id[2] );

 
	tttt=VirtualQueryEx(hProcess3,(LPCVOID)0x400000,&lpBuffer1,sizeof(lpBuffer1));

if ((lpBuffer1.AllocationProtect!=0X4l)||(lpBuffer1.Protect!=0X4l)||(lpBuffer1.RegionSize!=0X4000l)||(lpBuffer1.Type!=0X20000l)); //||(start!=0X400000l)

{
ReadProcessMemory(hProcess3,lpBuffer1.BaseAddress,yas_content,0x104000l,NULL);
dw=GetLastError();
}



yas_data_address=yas_content[0xcf0dcl]*0x1l+yas_content[0xcf0ddl]*0x100l
                +yas_content[0xcf0del]*0x10000l+yas_content[0xcf0dfl]*0x1000000l;

yas_data_address=yas_data_address&0xffff0000l;


if((yas_content[0xcdf10l]==0x75)&&(yas_content[0xcdf11l]==0x7f))
{
yas_content[0xcdf10l]=patch_code[0];
yas_content[0xcdf11l]=patch_code[1];

yas_content[0xcddcel]=patch_code_app[0];
yas_content[0xcddcfl]=patch_code_app[1];

WriteProcessMemory(hProcess3,lpBuffer1.BaseAddress,yas_content,0xce000l,NULL);
}

else if((yas_content[0xcdf10l]==0xeb)&&(yas_content[0xcdf11l]==0xfe))
{
yas_content[0xcdf10l]=patch_code[0];
yas_content[0xcdf11l]=patch_code[1];
yas_content[0xcddcel]=patch_code_app[0];
yas_content[0xcddcfl]=patch_code_app[1];
WriteProcessMemory(hProcess3,lpBuffer1.BaseAddress,yas_content,0xce000l,NULL);
}

else if((yas_content[0xcdf10l]==0x90)&&(yas_content[0xcdf11l]==0x90))
{
yas_content[0xcdf10l]=patch_code[0];
yas_content[0xcdf11l]=patch_code[1];
yas_content[0xcddcel]=patch_code_app[0];
yas_content[0xcddcfl]=patch_code_app[1];
WriteProcessMemory(hProcess3,lpBuffer1.BaseAddress,yas_content,0xce000l,NULL);
}



CloseHandle( hProcess3 );


}


} 



EXPORT_PROC
BOOL WINAPI MAINMsgProc( HWND    hWndDlg,
                             MESSAGE Message,
                             WPARAM  wParam,
                             LPARAM  lParam );
EXPORT_PROC
LRESULT WINAPI WndProc( HWND    hWnd,
                         MESSAGE Message,
                         WPARAM  wParam,
                         LPARAM  lParam );
int PASCAL WinMain( HINSTANCE hInstance,
                    HINSTANCE hPrevInstance,
                    LPSTR  lpszCmdLine,
                    int    nCmdShow );


void ToggleButton( HWND hWnd, WORD theButton )
{
   register DWORD x = 100000;
   SetFocus( GetDlgItem( hWnd, theButton ) );
   SendDlgItemMessage( hWnd, theButton, (MESSAGE)BM_SETSTATE, (WPARAM)TRUE, (LPARAM)NULL );
   while( x-- ); 
   SendDlgItemMessage( hWnd, theButton, (MESSAGE)BM_SETSTATE, (WPARAM)FALSE, (LPARAM)NULL );
} 


LOCAL_PROC
BOOL InitInstance( HANDLE hInstance, int nCmdShow )
{
   /* to avoid warnings */
   #ifndef __BORLANDC__
   nCmdShow = nCmdShow;
   #endif

   ghHourGlassCursor = LoadCursor( NULL, IDC_WAIT );
   if ( !ghHourGlassCursor ) return( FALSE );

   /* create application's Main window  */
   
	
	ghWndMain = CreateWindow( gAppName,         /* Window class name				 */
                             "YAS PATCH",   /* Window's title					 */
                              WS_CLIPCHILDREN | /* Don't draw in child windows areas */
                              WS_MAXIMIZE |
                              WS_OVERLAPPED,
                              CW_USEDEFAULT, 0, /* Use default X, Y					 */
                              CW_USEDEFAULT, 0, /* Use default X, Y					 */
                              NULL,             /* Parent window's handle			 */
                              NULL,             /* Default to Class Menu			 */
                              hInstance,        /* Instance of window				 */
                              NULL );           /* Create struct for WM_CREATE		 */

   if ( !ghWndMain ) return( FALSE );
     return( TRUE );
} 


LOCAL_PROC
BOOL InitApplication( HANDLE hInstance )
{
   HANDLE      hMem;
   PWNDCLASS   pWndClass;
   BOOL        bSuccess;

   hMem = LocalAlloc( LMEM_FIXED | LMEM_ZEROINIT, sizeof(WNDCLASS) );
   if ( !hMem ) return( FALSE );
   pWndClass = (PWNDCLASS)LocalLock( hMem );

   if ( !pWndClass )
   {
       LocalUnlock( hMem );
       LocalFree( hMem );
       return( FALSE );
   }

   
   pWndClass->style       = CS_BYTEALIGNWINDOW;
#if defined(__BORLANDC__)
   ((PPROC)pWndClass->lpfnWndProc) = (PPROC)WndProc;
#else
   pWndClass->lpfnWndProc = (WNDPROC)WndProc;
#endif

   
   pWndClass->cbClsExtra = 0;
   pWndClass->cbWndExtra = 0;
   pWndClass->hInstance  = hInstance;
   pWndClass->hIcon      = LoadIcon(ghInst, "SFNT");
   pWndClass->hCursor    = LoadCursor(NULL, IDC_ARROW);

   pWndClass->hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
   pWndClass->lpszMenuName  = (LPSTR)NULL;         
   pWndClass->lpszClassName = gAppName;             

   
   bSuccess = RegisterClass( pWndClass );

   LocalUnlock( hMem );
   LocalFree( hMem );
   return( bSuccess );
}

LOCAL_PROC
void CenterWindow( HWND hWnd,
                   int  top )
{
   POINT pt;
   RECT  swp;
   RECT  rParent;
   int   iwidth;
   int   iheight;

   
   GetWindowRect( hWnd, &swp );
   GetClientRect( ghWndMain, &rParent );

   
  iwidth = swp.right - swp.left;

   iheight = swp.bottom - swp.top;

   
   pt.x = (rParent.right - rParent.left) / 2;
   pt.y = (rParent.bottom - rParent.top) / 2;
   ClientToScreen(ghWndMain, &pt);

   
   pt.x = 0; //pt.x - (iwidth / 2);
   pt.y =pt.y - (iheight / 2);

  
  if ( top ) pt.y = pt.y + top;


   MoveWindow( hWnd, pt.x, pt.y, iwidth, iheight, FALSE );
} 


EXPORT_PROC
BOOL WINAPI MAINMsgProc( HWND    hWndDlg,
                         MESSAGE Message,
                         WPARAM  wParam,
                         LPARAM  lParam )
{
   PPROC       lpfnVIEWMsgProc = NULL;
   
   int k;
   static UINT cmAdvProt = BST_CHECKED;
  
  
   /* to avoid warnings */
   #ifndef __BORLANDC__
   lParam = lParam;
   #endif

   switch( Message )
   {
       case WM_ACTIVATE:
           ghCurrentDlg = ( GET_LOWORD(wParam) ? hWndDlg : NULL );
           break;

       case WM_INITDIALOG:
		    CenterWindow(hWndDlg, 0);
	   break;

       case WM_CLOSE:
           PostMessage( hWndDlg, (MESSAGE)WM_COMMAND, IDCANCEL, (LPARAM)NULL );
           break;

       case WM_COMMAND:
           switch( GET_LOWORD(wParam) )
           {
			
		   case IDC_RUN_YAS :
	{
  
                  
                   find_process_exevf();
                   hProcess = OpenProcess(  PROCESS_ALL_ACCESS,FALSE, yas_new_id[2] );
				   TerminateProcess(  hProcess, ExitCodeYAS);

				   find_process_exevf();
                   hProcess = OpenProcess(  PROCESS_ALL_ACCESS,FALSE, yas_new_id[0] );
				   TerminateProcess(  hProcess, ExitCodeYAS);
CreateProcess( NULL,  "yas.exe",  NULL, NULL, FALSE, 0, NULL, NULL, &si,  &pi ) ;
yas_id=pi.dwProcessId;
hProcess = OpenProcess(  PROCESS_ALL_ACCESS,FALSE, yas_id );
ToggleButton( hWndDlg, IDC_YAS_ID );
gViewText[0] = '\0';
gString[0]   = '\0';
if (yas_id!=0)
wsprintf( gString,  "%d",yas_id );
else
wsprintf( gString,  "YAS.EXE NOT FOUND" );
lstrcat( gViewText, gString );
SetDlgItemText (hWndDlg, IDC_YAS_ID_FIRST, gViewText);

SetDlgItemText (hWndDlg, IDC_YAS_ALL_ID, NULL);
SetDlgItemText (hWndDlg, IDC_YAS_PATCHL_ID, NULL);
SetDlgItemText (hWndDlg, IDC_YAS_PATCHL_ID_CODE, NULL);
SetDlgItemText (hWndDlg, IDC_YAS_CODE_EDIT, NULL);
SetDlgItemText (hWndDlg, IDC_YAS_PATCH_ID_APP, NULL);
SetDlgItemText (hWndDlg, IDC_YAS_WIRTE_ID_APP, NULL);



		}

               break;

		   case  IDC_GET_YAS_ID:
                	find_process_exevf();

gViewText[0] = '\0';
gString[0]   = '\0';
if((yas_new_id[0]!=0)&&(yas_new_id[1]!=0)&&(yas_new_id[2]!=0))
wsprintf( gString,  "%d-%d-%d",yas_new_id[0],yas_new_id[1],yas_new_id[2],yas_new_id[3] );
else
wsprintf( gString,  "YAS NOT EXECUTED");

lstrcat( gViewText, gString );
SetDlgItemText (hWndDlg, IDC_YAS_ALL_ID, gViewText);
		   
			   break;
case  IDC_PATCH_TO_YAS:
                          patch_code[0]=0x90;
                          patch_code[1]=0x90;
                          patch_code_app[0]=0x75;
                          patch_code_app[1]=0xad;
                          find_process_exevf();
                          read_write_process();
                          gViewText[0] = '\0';
                          gString[0]   = '\0';
                          if((yas_new_id[0]!=0)&&(yas_new_id[1]!=0)&&(yas_new_id[2]!=0))
                            wsprintf( gString,  "YAS PATCHED FOR Exe." );
                          else
                            wsprintf( gString,  "YAS NOT EXECUTED");
                          lstrcat( gViewText, gString );
                           SetDlgItemText (hWndDlg, IDC_YAS_PATCHL_ID, gViewText);
 break;
               case IDOK:
                   ToggleButton( hWndDlg, IDOK );
                   PostMessage( hWndDlg,
                                (MESSAGE)WM_COMMAND,
                                (WPARAM)IDCANCEL,
                                (LPARAM)NULL );
                   break;                  
 case IDC_PATCH_TO_YAS_CODE:
                          patch_code[0]=0xeb;
                          patch_code[1]=0xfe;
                          patch_code_app[0]=0x75;
                          patch_code_app[1]=0xad;
                          find_process_exevf();
                          read_write_process();
                          gViewText[0] = '\0';
                          gString[0]   = '\0';
                          if((yas_new_id[0]!=0)&&(yas_new_id[1]!=0)&&(yas_new_id[2]!=0))
                            wsprintf( gString,  "YAS PATCHED FOR code" );
                          else
                            wsprintf( gString,  "YAS NOT EXECUTED");

                          lstrcat( gViewText, gString );
                          SetDlgItemText (hWndDlg, IDC_YAS_PATCHL_ID_CODE, gViewText);
               break;
case IDC_WHAT_YAS_CODE:
find_process_exevf();
read_yas_code();
gViewText[0] = '\0';
gString[0]   = '\0';

for(k=0;k<yas_code_size;k++)
{
wsprintf( gString,"%c",yas_code[k]);
lstrcat( gViewText, gString );
}



SetDlgItemText (hWndDlg, IDC_YAS_CODE_EDIT, gViewText);
patch_code[0]=0x75  ;0x90;
patch_code[1]=0x7f  ;0x90;
patch_code_app[0]=0x75;
patch_code_app[1]=0xad;
find_process_exevf();
read_write_process();
//colse_all_yas();

 break; 



case  IDC_PATCH_TO_YAS_APP: 
                          patch_code[0]=0x90;
                          patch_code[1]=0x90;
                          patch_code_app[0]=0xeb;
                          patch_code_app[1]=0xfe;
                          find_process_exevf();
                          read_write_process();
                          gViewText[0] = '\0';
                          gString[0]   = '\0';
                        if((yas_new_id[0]!=0)&&(yas_new_id[1]!=0)&&(yas_new_id[2]!=0))
                           wsprintf( gString,  "Y. P. FOR CREATE APP.exe" );


                        else

                         wsprintf( gString,  "YAS NOT EXECUTED");

                         lstrcat( gViewText, gString );
                         SetDlgItemText (hWndDlg, IDC_YAS_PATCH_ID_APP, gViewText);

break; 

case  IDC_WRITE_YAS_APP:
                       app_exe_create=0;
					   find_process_exevf();
                       read_yas_app();
                       gViewText[0] = '\0';
                       gString[0]   = '\0';
                       if(app_exe_create==1)
                       wsprintf( gString,"APP.EXE created");
                       else
                       wsprintf( gString,"APP.EXE not created");
                       lstrcat( gViewText, gString );
                       SetDlgItemText (hWndDlg, IDC_YAS_WIRTE_ID_APP, gViewText);

                       patch_code[0]=0x90;
                       patch_code[1]=0x90;
                       patch_code_app[0]=0x75;
                       patch_code_app[1]=0xad;
                       find_process_exevf();
                       read_write_process();

                       //colse_all_yas();
break;

            case IDCANCEL:
				       find_process_exevf();
                       hProcess = OpenProcess(  PROCESS_ALL_ACCESS,FALSE, yas_new_id[2] );
				       TerminateProcess(  hProcess, ExitCodeYAS);

                  
                        find_process_exevf();
                        hProcess = OpenProcess(  PROCESS_ALL_ACCESS,FALSE, yas_new_id[0] );
				        TerminateProcess(  hProcess, ExitCodeYAS);
				  
                        DestroyWindow( hWndDlg );
                        ghCurrentDlg = NULL;
                       ghMainDlg    = NULL;
                      if ( lpfnVIEWMsgProc )
                      {
                       xFreeProcInstance( lpfnVIEWMsgProc );
                       }
                        PostMessage( ghWndMain,
                                (MESSAGE)WM_CLOSE,
                                (WPARAM)0,
                                (LPARAM)0 );
                   break;


			   


        

           }
           break;
		   


       default:
           return( FALSE );
   }
   return( TRUE );
} 

#ifdef __BORLANDC__
#pragma argsused
#endif
EXPORT_PROC
LRESULT WINAPI WndProc( HWND    hWnd,
                     MESSAGE Message,
                     WPARAM  wParam,
                     LPARAM  lParam )
{
   PPROC lpfnMAINMsgProc;

   /* to avoid warnings */
   #ifndef __BORLANDC__
   lParam = lParam;
   #endif

   switch ( Message )
   {
       case WM_COMMAND:
           switch( GET_LOWORD(wParam) )
           {
               case START_YAS_PATCH:
                   lpfnMAINMsgProc = MakeProcInstance( (PPROC)MAINMsgProc,
                                                       ghInst );
                   if ( lpfnMAINMsgProc )
                   {
                       ghMainDlg = CreateDialog( ghInst,
                                                 MAIN_DLG,
                                                 NULL,//hWnd,
                                                 (DLGPROC) lpfnMAINMsgProc );
                       if ( ghMainDlg )
                           ShowWindow( ghMainDlg, SW_SHOW );
                   }
                   break;

               default:
                   return( DefWindowProc(hWnd, Message, wParam, lParam) );
           }
           break;

       case WM_CREATE:
           PostMessage( hWnd,
                        (MESSAGE)WM_COMMAND,
                        (WPARAM)START_YAS_PATCH,
                        (LPARAM)NULL );
           break;

       case WM_CLOSE:

      	   
           if ( ghMainDlg )
               PostMessage( ghMainDlg,
                            (MESSAGE)WM_CLOSE,
                            (WPARAM)0,
                            (LPARAM)0 );
           xFreeProcInstance( lpfnMAINMsgProc );
           DestroyWindow( hWnd );
           if ( hWnd == ghWndMain ) PostQuitMessage(0); /* Quit */
           break;

       default:
           return( DefWindowProc(hWnd, Message, wParam, lParam) );
   }
   return( 0L );
} 
#ifdef __BORLANDC__
#pragma argsused
#endif
EXPORT_PROC
int PASCAL WinMain( HINSTANCE hInstance,
                    HINSTANCE hPrevInstance,
                    LPSTR  lpszCmdLine,
                    int    nCmdShow )
{
   MSG       msg;
  
   app_exe_create=0;

   /* to avoid warnings */
   #ifndef __BORLANDC__
   lpszCmdLine = lpszCmdLine;
   nCmdShow    = nCmdShow;
   #endif

  
   strcpy( gAppName, "YASPATCH" );
   patch_code[0]=0x90;
patch_code[1]=0x90;
   ghInst = hInstance;
   if( !hPrevInstance )
       if ( !InitApplication( hInstance ) ) return( FALSE );

   if ( !InitInstance( hInstance, SW_HIDE ) ) return( FALSE );

  
   while( GetMessage( &msg, NULL, 0, 0 ) ) /* Until WM_QUIT message        */
   {
       if ( ghCurrentDlg == 0 || !IsDialogMessage( ghCurrentDlg, &msg ) )
       {
           TranslateMessage( &msg );
           DispatchMessage( &msg );
       }
   }
   return( (int)msg.wParam );
} 


