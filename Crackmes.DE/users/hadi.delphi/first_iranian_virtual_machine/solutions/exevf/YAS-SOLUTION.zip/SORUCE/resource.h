//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by yaspatch.rc
//
#define IDS_STRING2                     1
#define IDI_ICON1                       101
#define IDC_YAS_ALL_ID                  1000
#define IDC_YAS_PATCHL_ID               1001
#define IDC_YAS_PATCHL_ID_CODE          1002
#define IDC_YAS_EXIT                    1003
#define IDC_YAS_ID_FIRST                1004
#define IDC_YAS_PATCH_ID_APP            1005
#define IDC_YAS_WIRTE_ID_APP2           1006
#define IDC_YAS_WIRTE_ID_APP            1006
#define IDC_EDIT1                       1010
#define IDC_YAS_CODE_EDIT               1010
#define IDC_RUN_YAS                     1046
#define IDC_GET_YAS_ID                  1047
#define IDC_PATCH_TO_YAS                1048
#define IDC_PATCH_TO_YAS_CODE           1049
#define IDC_WHAT_YAS_CODE               1050
#define IDC_PATCH_TO_YAS_APP            1051
#define IDC_WRITE_YAS_APP               1052
#define IDC_YAS_ID                      -1

// Next default values for new objects
// 
/*
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
*/