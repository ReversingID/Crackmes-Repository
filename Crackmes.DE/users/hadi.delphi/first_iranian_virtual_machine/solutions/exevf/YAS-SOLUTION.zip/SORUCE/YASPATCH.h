/**************************************************************************
*  Filename:    YASPATCH.H
*
*  (C) Copyright 2007 EXEVF, Inc.All Rights Reserved
*
**************************************************************************/
#ifndef _YASPATCH_H
#define _YASPATCH_H

#ifndef VERSION
#define VER    "NT-1.0"
#else
#include "ver.h"
#endif



#define MAIN_DLG					(LPSTR)"MAIN_DIALOG"





#endif                                 

/* _YASPATCH_H                      */
