
from ctypes import *

set_conversion_mode('ascii','strict')

NEGLIMIT=(-16384)        # Limit to display constans as signed
PSEUDOOP=128             # Base for pseudooperands
TEXTLEN=256              # Maximal length of text string

# Special command features.
WW=0x01            # Bit W (size of operand)
SS=0x02            # Bit S (sign extention of immediate)
WS=0x03            # Bits W and S
W3=0x08            # Bit W at position 3
CC=0x10            # Conditional jump
FF=0x20            # Forced 16-bit size
LL=0x40            # Conditional loop
PR=0x80            # Protected command
WP=0x81            # I/O command with bit W

# All possible types of operands in 80x86. A bit more than you expected, he?
NNN=0               # No operand
REG=1               # Integer register in Reg field
RCM=2               # Integer register in command byte
RG4=3               # Integer 4-byte register in Reg field
RAC=4               # Accumulator (AL/AX/EAX, implicit)
RAX=5               # AX (2-byte, implicit)
RDX=6               # DX (16-bit implicit port address)
RCL=7               # Implicit CL register (for shifts)
RS0=8               # Top of FPU stack (ST(0), implicit)
RST=9               # FPU register (ST(i)) in command byte
RMX=10              # MMX register MMx
R3D=11              # 3DNow! register MMx
MRG=12              # Memory/register in ModRM byte
MR1=13              # 1-byte memory/register in ModRM byte
MR2=14              # 2-byte memory/register in ModRM byte
MR4=15              # 4-byte memory/register in ModRM byte
RR4=16              # 4-byte memory/register (register only)
MR8=17              # 8-byte memory/MMX register in ModRM
RR8=18              # 8-byte MMX register only in ModRM
MRD=19              # 8-byte memory/3DNow! register in ModRM
RRD=20              # 8-byte memory/3DNow! (register only)
MRJ=21              # Memory/reg in ModRM as JUMP target
MMA=22              # Memory address in ModRM byte for LEA
MML=23              # Memory in ModRM byte (for LES)
MMS=24              # Memory in ModRM byte (as SEG:OFFS)
MM6=25              # Memory in ModRm (6-byte descriptor)
MMB=26              # Two adjacent memory locations (BOUND)
MD2=27              # Memory in ModRM (16-bit integer)
MB2=28              # Memory in ModRM (16-bit binary)
MD4=29              # Memory in ModRM byte (32-bit integer)
MD8=30              # Memory in ModRM byte (64-bit integer)
MDA=31              # Memory in ModRM byte (80-bit BCD)
MF4=32              # Memory in ModRM byte (32-bit float)
MF8=33              # Memory in ModRM byte (64-bit float)
MFA=34              # Memory in ModRM byte (80-bit float)
MFE=35              # Memory in ModRM byte (FPU environment)
MFS=36              # Memory in ModRM byte (FPU state)
MFX=37              # Memory in ModRM byte (ext. FPU state)
MSO=38              # Source in string op's ([ESI])
MDE=39              # Destination in string op's ([EDI])
MXL=40              # XLAT operand ([EBX+AL])
IMM=41              # Immediate data (8 or 16/32)
IMU=42              # Immediate unsigned data (8 or 16/32)
VXD=43              # VxD service
IMX=44              # Immediate sign-extendable byte
C01=45              # Implicit constant 1 (for shifts)
IMS=46              # Immediate byte (for shifts)
IM1=47              # Immediate byte
IM2=48              # Immediate word (ENTER/RET)
IMA=49              # Immediate absolute near data address
JOB=50              # Immediate byte offset (for jumps)
JOW=51              # Immediate full offset (for jumps)
JMF=52              # Immediate absolute far jump/call addr
SGM=53              # Segment register in ModRM byte
SCM=54              # Segment register in command byte
CRX=55              # Control register CRx
DRX=56              # Debug register DRx
# Pseudooperands (implicit operands, never appear in assembler commands). Must
# have index equal to or exceeding PSEUDOOP.
PRN=(PSEUDOOP+0)    # Near return address
PRF=(PSEUDOOP+1)    # Far return address
PAC=(PSEUDOOP+2)    # Accumulator (AL/AX/EAX)
PAH=(PSEUDOOP+3)    # AH (in LAHF/SAHF commands)
PFL=(PSEUDOOP+4)    # Lower byte of flags (in LAHF/SAHF)
PS0=(PSEUDOOP+5)    # Top of FPU stack (ST(0))
PS1=(PSEUDOOP+6)    # ST(1)
PCX=(PSEUDOOP+7)    # CX/ECX
PDI=(PSEUDOOP+8)    # EDI (in MMX extentions)

# Errors detected during command disassembling.
DAE_NOERR=0                # No error
DAE_BADCMD=1               # Unrecognized command
DAE_CROSS=2                # Command crosses end of memory block
DAE_BADSEG=3               # Undefined segment register
DAE_MEMORY=4               # Register where only memory allowed
DAE_REGISTER=5             # Memory where only register allowed
DAE_INTERN=6               # Internal error

class t_addrdec(Structure):
   _fields_=[('defseg',c_int),
			('descr',c_char_p)]

class t_cmddata(Structure):
   _fields_=[('mask',c_ulong),  # Mask for first 4 bytes of the command
			('code',c_ulong),   # Compare masked bytes with this
			('len',c_char),     # Length of the main command code
			('bits',c_char),    # Special bits within the command
			('arg1',c_char),    # Types of possible arguments
			('arg2',c_char),
			('arg3',c_char),
			('type',c_char),    # C_xxx + additional information
			('name',c_char_p)]  # Symbolic name for this command


'''
########## ASSEMBLER, DISASSEMBLER AND EXPRESSIONS #########
'''

MAXCMDSIZE=16              # Maximal length of 80x86 command
MAXCALSIZE=8               # Max length of CALL without prefixes
NMODELS=8                  # Number of assembler search models

INT3=0xCC                  # Code of 1-byte breakpoint
NOP=0x90                   # Code of 1-byte NOP command
TRAPFLAG=0x00000100        # Trap flag in CPU flag register

REG_EAX=0                  # Indexes of general-purpose registers
REG_ECX=1                  # in t_reg.
REG_EDX=2
REG_EBX=3
REG_ESP=4
REG_EBP=5
REG_ESI=6
REG_EDI=7

SEG_UNDEF=-1
SEG_ES=0                   # Indexes of segment/selector registers
SEG_CS=1
SEG_SS=2
SEG_DS=3
SEG_FS=4
SEG_GS=5

C_TYPEMASK=0xF0            # Mask for command type
C_CMD=0x00                 # Ordinary instruction
C_PSH=0x10                 # 1-word PUSH instruction
C_POP=0x20                 # 1-word POP instruction
C_MMX=0x30                 # MMX instruction
C_FLT=0x40                 # FPU instruction
C_JMP=0x50                 # JUMP instruction
C_JMC=0x60                 # Conditional JUMP instruction
C_CAL=0x70                 # CALL instruction
C_RET=0x80                 # RET instruction
C_FLG=0x90                 # Changes system flags
C_RTF=0xA0                 # C_JMP and C_FLG simultaneously
C_REP=0xB0                 # Instruction with REPxx prefix
C_PRI=0xC0                 # Privileged instruction
C_DAT=0xD0                 # Data (address) doubleword
C_NOW=0xE0                 # 3DNow! instruction
C_BAD=0xF0                 # Unrecognized command
C_RARE=0x08                # Rare command, seldom used in programs
C_SIZEMASK=0x07            # MMX data size or special flag
C_EXPL=0x01                # (non-MMX) Specify explicit memory size
                           
C_DANGER95=0x01            # Command is dangerous under Win95/98
C_DANGER=0x03              # Command is dangerous everywhere
C_DANGERLOCK=0x07          # Dangerous with LOCK prefix
                           
DEC_TYPEMASK=0x1F          # Type of memory byte
DEC_UNKNOWN=0x00           # Unknown type
DEC_BYTE=0x01              # Accessed as byte
DEC_WORD=0x02              # Accessed as short
DEC_NEXTDATA=0x03          # Subsequent byte of code or data
DEC_DWORD=0x04             # Accessed as long
DEC_FLOAT4=0x05            # Accessed as float
DEC_FWORD=0x06             # Accessed as descriptor/long pointer
DEC_FLOAT8=0x07            # Accessed as double
DEC_QWORD=0x08             # Accessed as 8-byte integer
DEC_FLOAT10=0x09           # Accessed as long double
DEC_TBYTE=0x0A             # Accessed as 10-byte integer
DEC_STRING=0x0B            # Zero-terminated ASCII string
DEC_UNICODE=0x0C           # Zero-terminated UNICODE string
DEC_3DNOW=0x0D             # Accessed as 3Dnow operand
DEC_BYTESW=0x11            # Accessed as byte index to switch
DEC_NEXTCODE=0x13          # Subsequent byte of command
DEC_COMMAND=0x1D           # First byte of command
DEC_JMPDEST=0x1E           # Jump destination
DEC_CALLDEST=0x1F          # Call (and maybe jump) destination
DEC_PROCMASK=0x60          # Procedure analysis
DEC_PROC=0x20              # Start of procedure
DEC_PBODY=0x40             # Body of procedure
DEC_PEND=0x60              # End of procedure
DEC_CHECKED=0x80           # Byte was analysed

DECR_TYPEMASK=0x3F         # Type of register or memory
DECR_BYTE=0x21             # Byte register
DECR_WORD=0x22             # Short integer register
DECR_DWORD=0x24            # Long integer register
DECR_QWORD=0x28            # MMX register
DECR_FLOAT10=0x29          # Floating-point register
DECR_SEG=0x2A              # Segment register
DECR_3DNOW=0x2D            # 3Dnow! register
DECR_ISREG=0x20            # Mask to check that operand is register

DISASM_SIZE=0              # Determine command size only
DISASM_DATA=1              # Determine size and analysis data
DISASM_FILE=3              # Disassembly, no symbols
DISASM_CODE=4              # Full disassembly

# Warnings issued by Disasm():
DAW_FARADDR=0x0001         # Command is a far jump, call or return
DAW_SEGMENT=0x0002         # Command loads segment register
DAW_PRIV=0x0004            # Privileged command
DAW_IO=0x0008              # I/O command
DAW_SHIFT=0x0010           # Shift constant out of range 1..31
DAW_PREFIX=0x0020          # Superfluous prefix
DAW_LOCK=0x0040            # Command has LOCK prefix
DAW_STACK=0x0080           # Unaligned stack operation
DAW_DANGER95=0x1000        # May mess up Win95 if executed
DAW_DANGEROUS=0x3000       # May mess up any OS if executed

class t_disasm(Structure):                    # Results of disassembling
   _fields_=[('ip',c_ulong),                  # Instrucion pointer
			('dump',c_ubyte*TEXTLEN),         # Hexadecimal dump of the command
			('result',c_ubyte*TEXTLEN),       # Disassembled command
			('comment',c_ubyte*TEXTLEN),      # Brief comment
			('cmdtype',c_int),                # One of C_xxx
			('memtype',c_int),                # Type of addressed variable in memory
			('nprefix',c_int),                # Number of prefixes
			('indexed',c_int),                # Address contains register(s)
			('jmpconst',c_ulong),             # Constant jump address
			('jmptable',c_ulong),             # Possible address of switch table
			('adrconst',c_ulong),             # Constant part of address
			('immconst',c_ulong),             # Immediate constant
			('zeroconst',c_int),              # Whether contains zero constant
			('fixupoffset',c_int),            # Possible offset of 32-bit fixups
			('fixupsize',c_int),              # Possible total size of fixups or 0
			('error',c_int),                  # Error while disassembling command
			('warnings',c_int)]               # Combination of DAW_xxx

class t_asmmodel(Structure):
	_fields_=[('code',c_ubyte*MAXCMDSIZE),
			('mask',c_ubyte*MAXCMDSIZE),
			('length',c_int),
			('jmpsize',c_int),
			('jmpoffset',c_int),
			('jmppos',c_int)]


Assemble=cdll.odbgDisasm.Assemble
Checkcondition=cdll.odbgDisasm.Checkcondition
Decodeaddress=cdll.odbgDisasm.Decodeaddress
#remove Disasm, as a function of the same name is used by BeaEngine
#Disasm=cdll.odbgDisasm.Disasm
Disassembleback=cdll.odbgDisasm.Disassembleback
Disassembleforward=cdll.odbgDisasm.Disassembleforward
Isfilling=cdll.odbgDisasm.Isfilling
Print3dnow=cdll.odbgDisasm.Print3dnow
Printfloat10=cdll.odbgDisasm.Printfloat10
Printfloat4=cdll.odbgDisasm.Printfloat4
Printfloat8=cdll.odbgDisasm.Printfloat8
