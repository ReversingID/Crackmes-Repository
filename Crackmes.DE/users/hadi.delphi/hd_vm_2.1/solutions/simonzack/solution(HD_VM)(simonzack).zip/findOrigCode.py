
import re
import base64

def dasmBeutify():
	contents=open('dasm.txt','rb').read().splitlines()
	addr=[]
	dasm=[]
	for line in contents:
		addr.append(int(line[:8],16))
		dasm.append(line[33:])
	#find toInt > base64 > compare's in dasm, and replace them with cmpInt(int,edx)
	"""
	PUSH EDX
	PUSH EAX
	LEA EAX,DWORD PTR SS:[EBP-150]
	CALL <HD_VM_2_.@Sysutils@IntToStr$qqrj>
	MOV EAX,DWORD PTR SS:[EBP-150]
	LEA EDX,DWORD PTR SS:[EBP-14C]
	CALL <HD_VM_2_.toBase64>
	MOV EAX,DWORD PTR SS:[EBP-14C]
	MOV EDX,HD_VM_2_.004D41E8                                     ; ASCII "NDgzNjE5Mg=="
	CALL <HD_VM_2_.@System@@LStrCmp$qqrv>
	"""
	base64cmt=b'; ASCII "'
	cmpInt=0
	try:
		for i in range(len(dasm)):
			if not dasm[i]==b'PUSH EDX': continue
			if not dasm[i+1]==b'PUSH EAX': continue
			if not dasm[i+2].startswith(b'LEA EAX,DWORD PTR SS:[EBP-'): continue
			if not dasm[i+3]==b'CALL <HD_VM_2_.@Sysutils@IntToStr$qqrj>': continue
			if not dasm[i+4].startswith(b'MOV EAX,DWORD PTR SS:[EBP-'): continue
			if not dasm[i+5].startswith(b'LEA EDX,DWORD PTR SS:[EBP-'): continue
			if not dasm[i+6]==b'CALL <HD_VM_2_.toBase64>': continue
			if not dasm[i+7].startswith(b'MOV EAX,DWORD PTR SS:[EBP-'): continue
			base64str=dasm[i+8][dasm[i+8].index(base64cmt)+len(base64cmt):]
			cmpInt=int(base64.b64decode(base64str),10)
			#remove i~(i+7)
			for j in range(9):
				addr.pop(i+1)
				dasm.pop(i)
			dasm[i]=b'cmpInt('+('%x'%(cmpInt)).encode()+b',edx)'
	except IndexError: pass
	#remove comments
	for i in range(len(dasm)):
		dasm[i]=re.sub(br'\s+;.+$',b'',dasm[i])
	#find WriteProcessMemory locations, and replace them with writeMem(child.addr)
	"""
	LEA EAX,DWORD PTR SS:[EBP-4]
	PUSH EAX
	PUSH 4
	PUSH ESI
	MOV EAX,DWORD PTR DS:[EBX+C4]
	PUSH EAX
	MOV EAX,DWORD PTR SS:[EBP-148]
	PUSH EAX
	CALL <HD_VM_2_.WriteProcessMemory>
	"""
	locStr=b'MOV EAX,DWORD PTR DS:['
	try:
		for i in range(len(dasm)):
			if not dasm[i]==b'LEA EAX,DWORD PTR SS:[EBP-4]': continue
			if not dasm[i+1]==b'PUSH EAX': continue
			if not dasm[i+2]==b'PUSH 4': continue
			if not dasm[i+3]==b'PUSH ESI': continue
			if not dasm[i+4].startswith(locStr): continue
			if not dasm[i+5]==b'PUSH EAX': continue
			if not dasm[i+6].startswith(b'MOV EAX,DWORD PTR SS:[EBP-'): continue
			if not dasm[i+7]==b'PUSH EAX': continue
			if not dasm[i+8]==b'CALL <HD_VM_2_.WriteProcessMemory>': continue
			memLoc=dasm[i+4][len(locStr):-1]
			for j in range(8):
				addr.pop(i+1)
				dasm.pop(i)
			dasm[i]=b'writeMem('+memLoc+b')'
	except IndexError: pass
	#find ReadProcessMemory locations, and replace them with readMem(child.addr)
	"""
	LEA EAX,DWORD PTR SS:[EBP-4]
	PUSH EAX                                                      ; /pBytesRead = 00000124
	PUSH 4                                                        ; |BytesToRead = 4
	PUSH ESI                                                      ; |Buffer = 0012F624
	MOV EAX,DWORD PTR DS:[EBX+C4]                                 ; |
	PUSH EAX                                                      ; |pBaseAddress = 124
	MOV EAX,DWORD PTR SS:[EBP-148]                                ; |
	PUSH EAX                                                      ; |hProcess = 00000124 (window)
	CALL <HD_VM_2_.ReadProcessMemory>                             ; \ReadProcessMemory
	"""
	locStr=b'MOV EAX,DWORD PTR DS:['
	try:
		for i in range(len(dasm)):
			if not dasm[i]==b'LEA EAX,DWORD PTR SS:[EBP-4]': continue
			if not dasm[i+1]==b'PUSH EAX': continue
			if not dasm[i+2]==b'PUSH 4': continue
			if not dasm[i+3]==b'PUSH ESI': continue
			if not dasm[i+4].startswith(locStr): continue
			if not dasm[i+5]==b'PUSH EAX': continue
			if not dasm[i+6].startswith(b'MOV EAX,DWORD PTR SS:[EBP-'): continue
			if not dasm[i+7]==b'PUSH EAX': continue
			if not dasm[i+8]==b'CALL <HD_VM_2_.ReadProcessMemory>': continue
			memLoc=dasm[i+4][len(locStr):-1]
			for j in range(8):
				addr.pop(i+1)
				dasm.pop(i)
			dasm[i]=b'readMem('+memLoc+b')'
	except IndexError: pass

	#check if there are any 'jnz's that are not directly after cmpInt
	"""
	for i in range(len(dasm)):
		if dasm[i].startswith(b'JNZ') and (not dasm[i-1].startswith(b'cmpInt')):
			print('At addr: '+'%X'%addr[i]+', a JNZ is found not to be directly after cmpInt')
		pass
	"""
	#find and replace context.jz and context.jnz
	"""
	LEA ECX,DWORD PTR SS:[EBP-C]
	MOV EDX,9
	MOV EAX,DWORD PTR DS:[EBX+C0]
	CALL HD_VM_2_.004BEA64
	MOV EAX,DWORD PTR SS:[EBP-C]
	CMP BYTE PTR DS:[EAX+3],31
	JNZ SHORT HD_VM_2_.004CBCAA
	MOV DWORD PTR DS:[EBX+B8],HD_VM_2_.0049C6B2
	"""
	stackjnzcmpStr=b'CMP BYTE PTR DS:[EAX+3],'
	jnzStr=b'JNZ SHORT HD_VM_2_.'
	stackjmptoStr=b'MOV DWORD PTR DS:[EBX+B8],HD_VM_2_.'
	try:
		for i in range(len(dasm)):
			if not dasm[i]==b'LEA ECX,DWORD PTR SS:[EBP-C]': continue
			if not dasm[i+1]==b'MOV EDX,9': continue
			if not dasm[i+2]==b'MOV EAX,DWORD PTR DS:[EBX+C0]': continue
			if not dasm[i+3]==b'CALL HD_VM_2_.004BEA64': continue
			if not dasm[i+4]==b'MOV EAX,DWORD PTR SS:[EBP-C]': continue
			if not dasm[i+5].startswith(stackjnzcmpStr): continue
			if not dasm[i+6].startswith(jnzStr): continue
			if not dasm[i+7].startswith(stackjmptoStr): continue
			jnzLoc=dasm[i+6][len(jnzStr):]
			stackjnzLoc=dasm[i+7][len(stackjmptoStr):]
			zFlag=(dasm[i+5][len(stackjnzcmpStr):]==b'31')
			if not ('%08X'%(addr[i+8])).encode()==jnzLoc: continue
			for j in range(7):
				addr.pop(i+1)
				dasm.pop(i)
			if zFlag: dasm[i]=b'context.jz '+stackjnzLoc
			else: dasm[i]=b'context.jnz '+stackjnzLoc
	except IndexError: pass
	
	#replace cmpInt(int,edx) with context.eip: int
	try:
		for i in range(len(dasm)):
			if not dasm[i]==b'MOV EAX,DWORD PTR DS:[EBX+B8]': continue
			if not dasm[i+1]==b'DEC EAX': continue
			if not dasm[i+2]==b'XOR EDX,EDX': continue
			if not dasm[i+3].startswith(b'cmpInt('): continue
			if not dasm[i+4].startswith(b'JNZ'): continue
			memLoc=dasm[i+3][7:dasm[i+3].index(b',')]
			for j in range(4):
				addr.pop(i+1)
				dasm.pop(i)
			dasm[i]=b'context.eip: '+('%08X'%int(memLoc,16)).encode()
	except IndexError: pass
	
	contextRegOffset={
		b'9C': b'context.EDI',
		b'A0': b'context.ESI',
		b'A4': b'context.EBX',
		b'A8': b'context.EDX',
		b'AC': b'context.ECX',
		b'B0': b'context.EAX',
		b'B4': b'context.EBP',
		b'B8': b'context.EIP',
		b'C4': b'context.ESP'
	}
	#find emulated context.push
	"""
	SUB DWORD PTR DS:[EBX+C4],4
	MOV EAX,DWORD PTR DS:[EBX+B4]
	MOV DWORD PTR DS:[ESI],EAX
	writeMem(EBX+C4)
	"""
	stackmovStr=b'MOV EAX,DWORD PTR DS:[EBX+'
	stackmovtoStr=b'MOV DWORD PTR DS:[EBX+'
	try:
		for i in range(len(dasm)):
			if not dasm[i]==b'SUB DWORD PTR DS:[EBX+C4],4': continue
			if not dasm[i+1].startswith(stackmovStr): continue
			if not dasm[i+2]==b'MOV DWORD PTR DS:[ESI],EAX': continue
			if not dasm[i+3]==b'writeMem(EBX+C4)': continue
			pushReg=contextRegOffset[dasm[i+1][len(stackmovStr):-1]]
			for j in range(3):
				addr.pop(i+1)
				dasm.pop(i)
			dasm[i]=b'context.push '+pushReg
	except IndexError: pass
	#find emulated context.pop
	"""
	readMem(EBX+C4)
	ADD DWORD PTR DS:[EBX+C4],4
	MOV EAX,DWORD PTR DS:[ESI]
	MOV DWORD PTR DS:[EBX+B0],EAX
	"""
	try:
		for i in range(len(dasm)):
			if not dasm[i]==b'readMem(EBX+C4)': continue
			if not dasm[i+1]==b'ADD DWORD PTR DS:[EBX+C4],4': continue
			if not dasm[i+2]==b'MOV EAX,DWORD PTR DS:[ESI]': continue
			if not dasm[i+3].startswith(stackmovtoStr): continue
			pushReg=contextRegOffset[dasm[i+3][len(stackmovtoStr):dasm[i+3].index(b']')]]
			for j in range(3):
				addr.pop(i+1)
				dasm.pop(i)
			dasm[i]=b'context.pop '+pushReg
	except IndexError: pass
	#find emulated context.mov
	"""
	MOV EAX,DWORD PTR DS:[EBX+C4]
	MOV DWORD PTR DS:[EBX+B4],EAX
	"""
	try:
		for i in range(len(dasm)):
			if not dasm[i].startswith(stackmovStr): continue
			if not dasm[i+1].startswith(stackmovtoStr): continue
			movReg=contextRegOffset[dasm[i][len(stackmovStr):-1]]
			movToReg=contextRegOffset[dasm[i+1][len(stackmovtoStr):dasm[i+1].index(b']')]]
			for j in range(1):
				addr.pop(i+1)
				dasm.pop(i)
			dasm[i]=b'context.mov '+movToReg+b','+movReg
	except IndexError: pass
	#find emulated context.call
	"""
	MOV DWORD PTR DS:[EBX+B8],HD_VM_2_.0049D30C
	SUB DWORD PTR DS:[EBX+C4],4
	MOV DWORD PTR DS:[ESI],HD_VM_2_.0049D307
	writeMem(EBX+C4)
	"""
	stackcallStr=b'MOV DWORD PTR DS:[EBX+B8],HD_VM_2_.'
	stackretStr=b'MOV DWORD PTR DS:[ESI],HD_VM_2_.'
	try:
		for i in range(len(dasm)):
			if not dasm[i].startswith(stackcallStr): continue
			if not dasm[i+1]==b'SUB DWORD PTR DS:[EBX+C4],4': continue
			if not dasm[i+2].startswith(stackretStr): continue
			if not dasm[i+3]==b'writeMem(EBX+C4)': continue
			callPos=dasm[i][len(stackcallStr):]
			retPos=dasm[i+2][len(stackretStr):]
			#callDist varies from 1 to 4, this means that the calls are obfuscated
			callDist=int(retPos,16)-int(dasm[i-1][13:],16)
			for j in range(3):
				addr.pop(i+1)
				dasm.pop(i)
			dasm[i]=b'context.call '+callPos+b','+str(callDist).encode()
	except IndexError: pass
	#find emulated context.xchg
	"""
	MOV EDI,DWORD PTR DS:[EBX+B4]
	context.mov context.EBP,context.EBX
	MOV DWORD PTR DS:[EBX+A4],EDI
	"""
	stackxchgStr=b'MOV EDI,DWORD PTR DS:[EBX+'
	contextMovStr=b'context.mov '
	try:
		for i in range(len(dasm)):
			if not dasm[i].startswith(stackxchgStr): continue
			if not dasm[i+1].startswith(contextMovStr): continue
			if not dasm[i+2].startswith(stackmovtoStr): continue
			reg1=dasm[i+1][len(contextMovStr):dasm[i+1].index(b',')]
			reg2=dasm[i+1][dasm[i+1].index(b',')+1:]
			if contextRegOffset[dasm[i][len(stackxchgStr):-1]]!=reg1: continue
			if contextRegOffset[dasm[i+2][len(stackmovtoStr):dasm[i+2].index(b',')-1]]!=reg2: continue
			for j in range(2):
				addr.pop(i+1)
				dasm.pop(i)
			dasm[i]=b'context.xchg '+reg1+b','+reg2
	except IndexError: pass
	#find emulated context.xor
	"""
	XOR EAX,EAX
	MOV DWORD PTR DS:[EBX+A8],EAX
	"""
	try:
		for i in range(len(dasm)):
			if not dasm[i]==b'XOR EAX,EAX': continue
			if not dasm[i+1].startswith(stackmovtoStr): continue
			if not dasm[i+1].endswith(b',EAX'): continue
			reg=contextRegOffset[dasm[i+1][len(stackmovtoStr):dasm[i+1].index(b']')]]
			for j in range(1):
				addr.pop(i+1)
				dasm.pop(i)
			dasm[i]=b'context.xor '+reg+b','+reg
	except IndexError: pass
	#find emulated context.ret
	"""
	readMem(EBX+C4)
	MOV EAX,DWORD PTR DS:[ESI]
	MOV DWORD PTR DS:[EBX+B8],EAX
	ADD DWORD PTR DS:[EBX+C4],4
	"""
	try:
		for i in range(len(dasm)):
			if not dasm[i]==b'readMem(EBX+C4)': continue
			if not dasm[i+1]==b'MOV EAX,DWORD PTR DS:[ESI]': continue
			if not dasm[i+2]==b'MOV DWORD PTR DS:[EBX+B8],EAX': continue
			if not dasm[i+3]==b'ADD DWORD PTR DS:[EBX+C4],4': continue
			for j in range(3):
				addr.pop(i+1)
				dasm.pop(i)
			dasm[i]=b'context.ret'
	except IndexError: pass
	#find emulated context.ret DWORD
	"""
	readMem(EBX+C4)
	MOV EAX,DWORD PTR DS:[ESI]
	MOV DWORD PTR DS:[EBX+B8],EAX
	MOV EAX,DWORD PTR DS:[EBX+C4]
	ADD EAX,4
	ADD EAX,8
	MOV DWORD PTR DS:[EBX+C4],EAX
	"""
	try:
		for i in range(len(dasm)):
			if not dasm[i]==b'readMem(EBX+C4)': continue
			if not dasm[i+1]==b'MOV EAX,DWORD PTR DS:[ESI]': continue
			if not dasm[i+2]==b'MOV DWORD PTR DS:[EBX+B8],EAX': continue
			if not dasm[i+3]==b'MOV EAX,DWORD PTR DS:[EBX+C4]': continue
			if not dasm[i+4]==b'ADD EAX,4': continue
			if not dasm[i+6]==b'MOV DWORD PTR DS:[EBX+C4],EAX': continue
			retStack=dasm[i+5][8:]
			for j in range(6):
				addr.pop(i+1)
				dasm.pop(i)
			dasm[i]=b'context.ret '+retStack
	except IndexError: pass
	
	#find emulated context.jmp
	"""
	MOV DWORD PTR DS:[EBX+B8],HD_VM_2_.00409B12
	"""
	try:
		for i in range(len(dasm)):
			if not dasm[i].startswith(stackjmptoStr): continue
			for j in range(0):
				addr.pop(i+1)
				dasm.pop(i)
			dasm[i]=b'context.jmp '+dasm[i][len(stackjmptoStr):]
	except IndexError: pass
	
	contents=b''
	for i in range(len(addr)):
		if dasm[i].startswith(b'context.eip'): contents+=b'\r\n'
		contents+=('%08X'%(addr[i])).encode()+b'\t\t'+dasm[i]
		contents+=b'\r\n'
	open('dasm(opcodes).txt','wb').write(contents)
	


def main():
	dasmBeutify()


if __name__=='__main__':
	main()
