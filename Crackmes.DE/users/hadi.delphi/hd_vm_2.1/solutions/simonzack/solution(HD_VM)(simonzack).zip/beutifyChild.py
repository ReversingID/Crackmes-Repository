
import re
import copy
import sys
import shutil
from BeaEnginePython import *
from odbgDisasmPython import *

def sign(num):
	if num>0: return 1
	elif num==0: return 0
	return -1

def min(num1,num2):
	if num1<=num2: return num1
	return num2

def max(num1,num2):
	if num1>=num2: return num1
	return num2

def opcode2child():
	contents=open('dasm(opcodes).txt','rb').read()
	#remove first chunk, as is not needed
	tmp=contents[:contents.index(b'context.')]
	chunkIndex=len(tmp)-tmp[::-1].index(b'\r\n')
	contents=contents[chunkIndex+1:]
	#remove last chunk, as is not needed
	tmp=len(contents)-contents[::-1].index(b'context.'[::-1])
	contents=contents[:tmp+contents[tmp:].index(b'\r\n')]
	contents=re.sub(br'(^|\r\n).+?context\.eip\:\s+',br'\1',contents)
	contents=re.sub(br'(^|\r\n).+?context',b'\t\tcontext',contents)
	contents=re.sub(br'(\r\n){2,}',b'\r\n',contents)
	contents=contents.splitlines()
	for i in range(len(contents)):
		try:
			tmp=contents[i].index(b'\t\t')+1
			contents[i]=contents[i][:tmp]+contents[i][tmp:].replace(b'\t\t',b', ')
		except IndexError: pass
	contents.sort()
	contents=b'\r\n'.join(contents)
	contents=contents.replace(b'context.',b'')
	open('dasm(child).txt','wb').write(contents)

def childBeutify():
	contents=open('dasm(child).txt','rb').read().splitlines()
	addr=[]
	dasm=[]
	for line in contents:
		if line==b'': continue
		addr.append(int(line[:8],16))
		dasm.append(line[10:])
	#replace push EDX, xor EDX,EDX, pop EDX
	try:
		for i in range(len(dasm)):
			matched=re.search(br'push (E..), xor \1,\1',dasm[i])
			if matched==None: continue
			if addr[i]+1!=addr[i+1]: continue
			if not dasm[i+1]==b'pop '+matched.group(1): continue
			for j in range(2):
				addr.pop(i)
				dasm.pop(i)
	except IndexError: pass
	#replace xchg ECX,EBX, xchg ECX,EBX
	try:
		i=-1
		while i<len(dasm):
			i+=1
			matched=re.search(br'xchg (E..),(E..)',dasm[i])
			if matched==None: continue
			if addr[i]+1!=addr[i+1]: continue
			if dasm[i]!=dasm[i+1]: continue
			for j in range(2):
				addr.pop(i)
				dasm.pop(i)
			i-=2
	except IndexError: pass
	#replace push EAX, pop EAX
	try:
		i=-1
		while i<len(dasm):
			i+=1
			matched=re.search(br'push (E..)',dasm[i])
			if matched==None: continue
			if addr[i]+1!=addr[i+1]: continue
			if dasm[i+1]!=b'pop '+matched.group(1): continue
			for j in range(2):
				addr.pop(i)
				dasm.pop(i)
			i-=2
	except IndexError: pass
	#replace ret with retn
	for i in range(len(dasm)):
		dasm[i]=dasm[i].replace(b'ret',b'retn')
	
	contents=b''
	for i in range(len(addr)):
		if dasm[i].startswith(b'context.eip'): contents+=b'\r\n'
		contents+=('%08X'%(addr[i])).encode()+b'\t\t'+dasm[i]
		contents+=b'\r\n'
	open('dasm(child)(beutified).txt','wb').write(contents)
	return {'addr': addr, 'dasm': dasm}

def getJmpTypeSize(jType,jSize):
	'''
	gets the prefix bytes of the jmp type's size
	"jmp" returns 1
	other jmp types returns 2
	'''
	if jType.lower()==b'call': return 5
	if jSize==1: return 2
	if jType[1]^0x20==b'M'[0]: return 5
	return 6

def getJmpDist(jLocs,i,jmpSizes,origAddr,newInstr):
	'''
	gets the distance of the jmp instruction to origAddr
	'''
	(jLoc,jmpTo,jmpType)=jLocs[i]
	zipped=list(zip(*jLocs))
	jmpToDist=0
	if jmpTo<origAddr[0]:
		#jmp outside of code section
		jmpToDist=origAddr[0]-jmpTo
		j=0
	elif jmpTo>origAddr[-1]:
		#jmp outside of code section
		jmpToDist=jmpTo-origAddr[-1]
		j=len(origAddr)-1
	else:
		#find addr of instruction just before jmp
		for j in range(len(origAddr)):
			if origAddr[j]>=jmpTo:
				break
		jmpToDist=0
	_j=j
	if j==jLoc:
		if jmpTo<origAddr[0]: return -jmpToDist
		else: return jmpToDist
	for j in range(min(jLoc,j),max(jLoc,j)):
		if newInstr[j][0]==0xE9:
			k=zipped[0].index(j)
			jmpToDist+=getJmpTypeSize(jLocs[k][2],jmpSizes[k])
		else:
			jmpToDist+=len(newInstr[j])
	if _j>jLoc:
		return jmpToDist
	elif _j<jLoc:
		return -jmpToDist

def patchDec(_addr,_dasm):
	'''
	patch decrypted_.exe
	'''
	shutil.copyfile('decrypted.exe','decrypted_.exe')
	patchCont=open('decrypted_.exe','rb').read()
	i=0
	instr=DISASM()
	instr.Options=NasmSyntax+SuffixedNumeral+ShowSegmentRegs
	buf=create_string_buffer(patchCont,len(patchCont))
	codeAddr=addressof(buf)+0x400
	codeBase=0x401000
	err=b'\0'*TEXTLEN
	asmmodel=t_asmmodel()
	newInstr=[]
	addr=copy.copy(_addr)
	dasm=copy.copy(_dasm)
	
	#debug_start
	for i in range(0,0):
		addr.pop(0)
		dasm.pop(0)
	#debug_end
	
	while True:
		if len(addr)==0: break
		curr=addr[0]
		instr.EIP=codeAddr+addr[0]-codeBase
		instr.VirtualAddr=addr[0]
		#wait until int3offset==0
		InstrLength=Disasm(addressof(instr))
		int3offset=0
		if instr.CompleteInstr!='int3 ':
			print('Error: start address does not contain int3')
			return
		#check if there are any previous 'int3's (this uses quite a simple method, and might not work in more complicated cases)
		startAddr=addr[0]-codeBase+0x400
		while instr.CompleteInstr=='int3 ':
			InstrLength=Disasm(addressof(instr))
			instr.EIP-=1
			startAddr-=1
			instr.VirtualAddr-=1
		instr.EIP+=2
		startAddr+=2
		rawAddr=startAddr
		instr.VirtualAddr+=2
		#assemble all dasm instructions from addr[i] until ret is encountered
		#maintain a list of addresses of original opcodes for jmp fixing, as opcode-positions change; calls are treated as jmps
		origAddr=[]
		#jLocs is in format: (instrLoc,jmpType,jmpOrigOffset)
		jLocs=[]
		while True:
			InstrLength=Disasm(addressof(instr))
			if instr.CompleteInstr=='int3 ':
				#check if there are any addr matches, assemble if there are
				try:
					while addr[0]<instr.VirtualAddr:
						addr.pop(0)
						dasm.pop(0)
				except IndexError: break
				if addr[0]==instr.VirtualAddr:
					#check if next instr is a call, if it is, need to jmp to ret address accordining
					if dasm[0].startswith(b'call'):
						(dasm[0],tmp)=dasm[0].split(b',')
						InstrLength=int(tmp)
					#if instruction is jmp, use marker 0xE9 for current instr bytes: -1
					if dasm[0].startswith(b'j') or dasm[0].startswith(b'call 0'):
						tmp=dasm[0].split(b' ')
						jLocs.append((len(newInstr),int(tmp[1],16),tmp[0]))
						newInstr.append(bytearray(b'\xE9'))
					else:
						Assemble(c_char_p(dasm[0]),addr[0],byref(asmmodel),0,0,c_char_p(err))
						newInstr.append(bytearray(asmmodel.code)[:asmmodel.length])
					origAddr.append(instr.VirtualAddr)
					if dasm[0].startswith(b'ret'):
						addr.pop(0)
						dasm.pop(0)
						break
					addr.pop(0)
					dasm.pop(0)
			else:
				if instr.Instruction.BranchType!=0 and instr.Instruction.AddrValue!=0:
					jLocs.append((len(newInstr),instr.Instruction.AddrValue,instr.Instruction.Mnemonic.encode()))
					newInstr.append(bytearray(b'\xE9'))
				else:
					newInstr.append(patchCont[rawAddr:rawAddr+InstrLength])
				origAddr.append(instr.VirtualAddr)
				if instr.CompleteInstr.startswith('ret'):
					break
			if InstrLength==-1:
				#unkown instruction, which symbolizes end of chunk
				break
			instr.EIP+=InstrLength
			instr.VirtualAddr+=InstrLength
			rawAddr+=InstrLength
		
		#fix jmps, first identify jmps that must be 4 bytes long, then all other jmps are 2 bytes long
		jmpSizes=[1]*len(jLocs)
		#change all calls to size 4
		for i in range(len(jLocs)):
			(jLoc,jmpTo,jmpType)=jLocs[i]
			if jmpType==b'call':
				jmpSizes[i]=4
		i=0
		while i<len(jLocs)-1:
			i+=1
			if jmpSizes[i]==4: continue
			jmpDist=getJmpDist(jLocs,i,jmpSizes,origAddr,newInstr)
			jmpDist-=getJmpTypeSize(jmpType,jmpSizes[i])
			if jmpDist<-0x7E:
				jmpSizes[i]=4
				i=-1
			elif jmpDist>0x81:
				jmpSizes[i]=4
				i=-1
		
		print(jmpSizes)
		for i in range(len(jLocs)):
			(jLoc,jmpTo,jmpType)=jLocs[i]
			jmpDist=getJmpDist(jLocs,i,jmpSizes,origAddr,newInstr)
			#jmpDist=getJmpTypeSize(jmpType,jmpSizes[i])
			Assemble(c_char_p(jmpType+(' 0%x'%(origAddr[i]+jmpDist)).encode()),origAddr[i],byref(asmmodel),0,0,c_char_p(err))
			newInstr[jLoc]=asmmodel.code[:asmmodel.length]
		
		#flush current instructions to exe
		j=startAddr
		for currInstr in newInstr:
			for byte in currInstr:
				#assign to buf using ctypes, as direct assignment is not allowed, and using byetarray will not reflect changes in BeaEngine
				buf[j]=byte
				j+=1
		startVaddr=instr.VirtualAddr-rawAddr+startAddr
		print('assembled opcode num: '+'%d'%len(newInstr)+
			' from '+hex(startVaddr)+' to '+hex(startVaddr+j-startAddr-1)+', a total of '+hex(j-startAddr) +' bytes')
		print('originally opcode length was '+hex(rawAddr-startAddr)+' bytes')
		newInstr=[]
		
		#break
	open('decrypted_.exe','wb').write(buf)


def main():
	opcode2child()
	ret=childBeutify()
	patchDec(ret['addr'],ret['dasm'])

if __name__=='__main__':
	main()
