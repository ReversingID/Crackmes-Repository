/**
 * Lame bruteforcer for bOne's KeyMe#1 --- by Sunshine
 *
 * Mail: webmaster@sunshine2k.de
 * Website: www.sunshine2k.de
 */

#define  WIN32_LEAN_AND_MEAN
#include <windows.h>

LPSTR APP_DESCRIPTION = "Bruteforce Keyserach for bOne's KeyMe#1.\n\n"
						"* Mail: webmaster@sunshine2k.de\n"
						"* Website: www.sunshine2k.de\n\n"
						"Press Strg-C to stop the key-search...\n"
						"Press now Return to start calculating...";
LPSTR solfound = "Solution found: ";
int	solfoundlen;

char serial[11];	// only 11 characters cause " roxx" is fixed

/*
 * Helper function to write something to console
 */
void WriteToConsole(void* buffer, int len)
{
	DWORD charswritten;
	WriteConsole(GetStdHandle(STD_OUTPUT_HANDLE), buffer, len, &charswritten, NULL);
}

/*
 * Helper function to get input from console
 */
void ReadFromConsole(LPVOID buffer, int maxlen)
{
	DWORD charsread;
	ReadConsole(GetStdHandle(STD_INPUT_HANDLE), buffer, maxlen * sizeof(TCHAR), 
				&charsread, NULL);
}

/*
 * Print found solution to console
 */
void PrintSolution()
{
	char tempbuf[50];
	RtlZeroMemory(&tempbuf, sizeof(char)*50);

	WriteToConsole(solfound, solfoundlen);
	wsprintf(tempbuf, "%cr%c%c%c%c%c%c.%c%c roxx\n", serial[0], serial[2], serial[3], serial[4], serial[5], 
											  serial[6], serial[7], serial[9], serial[10]);
	WriteToConsole(tempbuf, lstrlen(tempbuf));
}

/*
 * Main function which searches for keys (these are a lot!!!)
 * Note that I set the two characters after the dot in the key fixed to "de". This is not a must!
 * But it makes the solution space smaller -> this also means that this function does NOT find ALL possible keys.
 */
void FindKeys()
{
	RtlZeroMemory(&serial, sizeof(char)*11);

	char pos0, pos2, pos3, pos4, pos5, pos6, pos7;
	serial[1] = 'r';
	serial[8] = '.';
	serial[9] = 'd';
	serial[10] = 'e';

	int restsum = 0x3F3 - serial[1] - serial[8] - serial[9] - serial[10];

	for (pos0 = 65; pos0 < 91; pos0++)
	{
		serial[0] = pos0;
		
		for (pos2 = 48; pos2 < 58; pos2++)
		{
			serial[2] = pos2;

			for (pos3 = 33; pos3 < 127; pos3++)
			{
				serial[3] = pos3;

				for (pos4 = 33; pos4 < 127; pos4++)
				{
					serial[4] = pos4;

					for (pos5 = 33; pos5 < 127; pos5++)
					{
						serial[5] = pos5;

						for (pos6 = 33; pos6 < 127; pos6++)
						{
							serial[6] = pos6;

							for (pos7 = 33; pos7 < 127; pos7++)
							{
								serial[7] = pos7;

								if (serial[0] + serial[2] + serial[3] + serial[4] + 
									serial[5] + serial[6] + serial[7]  == restsum)
									PrintSolution();
							}
						}
					}
				}
			}
		}
	}
	
	


}

int main()
{
	solfoundlen = lstrlen(solfound);
	WriteToConsole(APP_DESCRIPTION, lstrlen(APP_DESCRIPTION));

	char inputbuf[MAX_PATH];
	ZeroMemory(inputbuf, MAX_PATH);
	ReadFromConsole(&inputbuf, MAX_PATH);
	
	FindKeys();
	return 0;
}

/*
 * That's the real entrypoint. I excluded the default library to minimize filesize.
 */
int  __cdecl mainCRTStartup()
{
	main();
	return 0;
}

