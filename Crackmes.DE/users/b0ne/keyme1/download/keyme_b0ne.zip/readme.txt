hey folks

wanna have some fun finding a key ?
check out this keyme ;)


difficulty: it's not that hard. you just need  a bit patience.


there's more than one key but you probably will recognize the right one
after testing the routine a little bit.


have fun

april 29th 2007

B0ne (PM at crackmes.de)


special greetz to all Abiturensoehne of 2007 and everyone on crackmes.de