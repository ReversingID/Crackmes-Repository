#define WIN32_LEAN_AND_MEAN
#define _CRT_SECURE_NO_DEPRECATE
#undef UNICODE

#include <windows.h>
#include <stdlib.h>
#include "md5.h"

#define ERROR_NAME "-"
#define MD5_LEN	32

void make_serial(unsigned char *name, char *serial)
{
	int i, nlen;
	char md5hash[MD5_LEN + 1];
	char block1[7];
	char block2[4];
	char block3[11];
	char *p;
	MD5_CTX mdContext;

	nlen = lstrlen(name);
	if(!nlen) {
		lstrcpy(serial, ERROR_NAME);
		return;
	}

	MD5Init(&mdContext);
	MD5Update(&mdContext, name, nlen);
	MD5Final(&mdContext);

	p = md5hash;
	for(i = 0; i < MD5_LEN / 2; i++)
	{
		wsprintf(p, "%.2x", mdContext.digest[i]);
		p += 2;
	}

	// Block 1 - Lowercase
	strncpy(block1, md5hash + 4, 6);
	block1[6] = 0;

	// Block 2 - Uppercase
	strncpy(block2, md5hash + 1, 4);
	block2[3] = 0;
	for(i = 0; i < 3; i++) {
		if(block2[i] >= 'a' && block2[i] <= 'z') {
			block2[i] -= 0x20;
		}
	}

	// Block 3 - Lowercase
	strncpy(block3, md5hash + 6, 10);
	block3[10] = 0;

	wsprintf(serial, "%s%s%s", block1, block2, block3);
}
