
#include <windows.h>
#include <string.h>
#include "resource.h"
#include "base64.c"

unsigned char buf1[300],buf2[300];
char tmp[128] = {0};


void SerialGenerate(char *n,char *serial)
{
	unsigned int i,l;

	memset(buf1,0,sizeof(buf1));						//Clear Buffer
	memset(buf2,0,sizeof(buf2));						//Clear Buffer

	l=sprintf(buf1,"%s%s%s%s%s",n,"RJ",n,"RJ",n);		//name & RJ & name & RJ & name	

	base64_encode(buf1, tmp, l, 0);

	for(i=0;i<strlen(tmp);i++)
	{
		if(tmp[i] != '=')
			buf2[i]=tmp[i];								//Copy all chars except '='
	}

	sprintf(serial,"%s%c%c",buf2,0x10,0x10);			//Fix the last 2 chars

	return;
}



HINSTANCE	hInst;

BOOL CALLBACK DialogProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	unsigned char name[50]={0},serial[300]={0};
	unsigned int l;
				
	switch (message)
	{    
	case WM_CLOSE:
		EndDialog(hWnd,0);
		break;

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{ 
		case IDC_GENERATE:

			
			l=GetDlgItemText(hWnd, IDC_1, &name[0], 49);

			if(l<5)
			{
				SetDlgItemText(hWnd, IDC_2, "Length must be greater than 4!!");
				break;
			}

			SerialGenerate(&name[0],&serial[0]);

			SetDlgItemText(hWnd, IDC_2, &serial[0]);
			
			break;

		case IDC_ABOUT:
			MessageBox(hWnd, "PersianFox KeyGenMe_1.4 Solution By ORacLE_nJ\nProtection: Base 64", "About", MB_OK);
			break;
		}
		break;

	case WM_INITDIALOG:
		SendMessageA(hWnd,WM_SETICON,(WPARAM) 1,(LPARAM) LoadIconA(hInst,MAKEINTRESOURCE(IDI_ICON)));
		break;
	}
     return 0;
}



int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{
	hInst=hInstance;
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, (DLGPROC)DialogProc,0);
	return 0;
}