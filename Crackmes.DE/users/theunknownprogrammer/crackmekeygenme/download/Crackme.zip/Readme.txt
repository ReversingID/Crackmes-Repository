This is a crackme/keygenme written in a .net language. Don't think immediately, .net is bad and easy. This crackme might actually take a little bit more knowledge than you'd expect. 

No serial fishing is allowed. Patching is ok, but creating the keygen is the perfect solution.

Good luck !

Regards
TheUnknownProgrammer