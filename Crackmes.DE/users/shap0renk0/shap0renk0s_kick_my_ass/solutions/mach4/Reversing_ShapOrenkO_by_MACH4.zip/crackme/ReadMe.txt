Beware!
This crackme is really hard!


Author: Shap0renk0
OS: Windows XP only
Difficulty: 6/10
Language: Microsoft Visual Basic 6.0

Tools&Methods: Do not use special VB tools (SmartCheck,vbde etc).

Well, your task is:
1: To enable buttons (ow, believe me, it'll be difficult=))
2: To create a keyfile (easy)
3: To enable textbox
4: To find a valid key
5: To write keygen and tutoral=)
6: To send your tutoral and keygen to shap0renk0@mail.ru


ATTENTION!!!

THIS CRACKME IS PROTECTED WITH Shap0renk0'z executable protector XP!
It's written by me, so i'm allowed to use it=)))))

(c) Shap0renk0,2006.