EXE Compiled using Visual Studio 2005 but the source code can be
used with previous versions