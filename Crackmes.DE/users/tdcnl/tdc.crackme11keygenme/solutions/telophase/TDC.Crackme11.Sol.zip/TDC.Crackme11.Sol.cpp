// TDC.Crackme11.Sol.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <string.h>
#include <windows.h>
#include <conio.h>
#include <iostream>
char name[51]={0};
unsigned long serial = 0;
using namespace std;
char k = ' ';
void getSerial(void);

int _tmain(int argc, _TCHAR* argv[])
{
	cout << "Solution to TDC Crackme #10 By TELOPHASE/TEAM ICU" <<endl ;
	cout << "\t\t\twww.teamicu.org" << endl;
	cout << "Enter Name(6 - 15 chars): ";
	int i = 0;
	while(k != '\r')
	{
		k = getche();
		name[i] = k;
		i++;
	}
	cout << endl;
	name[i-1]=0;
	cout << endl;
	if(strlen(name) < 6 || strlen(name) > 51)
	{
		cout << "Name Can Only Be Between 5 to 51 chars";
		getch();
		exit(0);
	}
	getSerial();
	cout << "Your Serial: " << serial;
	getch();
	return 0;
	return 0;
}
void getSerial(void)
{
	SYSTEMTIME st;
	GetSystemTime(&st);
	unsigned short y = st.wMonth;
	__asm
	{
				 xor     eax, eax
				 xor     ecx, ecx
				 xor     edx, edx
		         mov     edx, OFFSET name

loc_4012C6:                             ; CODE XREF: unpacked:004012D2j
                 mov     al, [edx]
                 test    al, al
                 jz      short loc_4012D4
                 add     ecx, eax
                 rol     ecx, 8
                 xor     ecx, 0Ch
                 mov     al, 30h
                 xor     ecx, 2
                 sub     ecx, 803h
                 add     cl, al
                 inc     edx
                 jmp     short loc_4012C6
loc_4012D4:                             ; CODE XREF: unpacked:004012CAj
                                         ; DATA XREF: unpacked:004012B8r
                 xor     ecx, 2
                 sub     ecx, 50h
                 xor     ecx, 1337h
                 push    esi
                 mov     si, y
                 xor     si, 408Ah
                 add     si, 1Eh
                 add     cx, si
                 pop     esi
                 mov     serial,ecx

	}

}
