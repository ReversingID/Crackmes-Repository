#include <iostream.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <conio.h>
#include <windows.h>
#include <fstream.h>

fstream file;

void main()
{
	char name[16];
   char serial[16];
	int len;
   DWORD sum=0;

   strset(name,0x00);
   strset(serial,0x00);

   cout<<"KeyFile Me by TDC - Keygen by Ox87k"<<"\n\n";
   //name:
   cout<<"Name: ";
   gets(name);
   //len name
   len=strlen(name);

   if(len>16)
   {
    	cout<<"\nLen name < 16 char please...";
      cout<<"\nPress any key for exit..";
		getch();
      exit(0);
   }

   //check len and add 0x00 if len<16
   if(len<16)
   {
   	for(int x=len;x<16;x++)
      	name[x]=0x00;
   }
   
   for (int i=0;i<len;i++)
   {
   	sum+=((name[i]+0xF)^0x20);
   }
   sum*=0x7A69;
   sprintf(serial,"%X",sum);

   //check len and add 0x00 if len<16
   if(strlen(serial)<16)
   {
   	for(int x=strlen(serial);x<16;x++)
      	serial[x]=0x00;
   }

   //write in file :D
   file.open("keyfile.dat",ios::out);
   file.write((char*)&name,sizeof(name));
   file.write((char*)&serial,sizeof(serial));
   file.close();

   cout<<"Serial: "<<serial;
   cout<<"\n\nKeyfile created successfully!";
	cout<<"\nPress any key for exit..";
	getch();
}
