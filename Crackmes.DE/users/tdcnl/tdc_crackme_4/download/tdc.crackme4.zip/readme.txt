CrackME [#4] v1.0 � 2005 by TDC
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

Readme:
-=-=-=-

Coded by	: TDC
Protection	: Encrypted Password
Release date	: 27-08-2005

Rules:
-=-=-=

1) Absolutely no patching allowed.
2) Bruteforcing is allowed, but I wouldn't recommend ;-)
3) You have to reverse it!

Good luck with it and have phun!

Contact info:
-=-=-=-=-=-=-

1) Visit http://www.reversing.be/ or http://www.reversing.be/forum/memberlist.php
2) Go to the forum, search for TDC (username)
3) Go to profile
4) Send an email or PM (Personal Message)