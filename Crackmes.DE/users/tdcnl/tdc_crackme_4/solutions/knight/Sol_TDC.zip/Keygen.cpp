#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <stdio.h>
#include <time.h>
#include "resource.h"

#pragma comment(lib, "ComCtl32.lib")

char p1[] = {'1', 'A', 'a', 'Q', 'q', '0', 'P', 'p'};
char p2[] = {'J', 'j', 'Z', 'z', 'K', 'k'};

void Generate(HWND hWnd)
{
	char serial[12];
	char ch1, ch2;
	ch1 = p1[rand() % 8];
	ch2 = p2[rand() % 6];
	sprintf(serial, "%cI8s%cF41rt", ch1, ch2);
	SetDlgItemText(hWnd, IDC_SERIAL, serial);
}

static BOOL CALLBACK DlgAbout(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
	case WM_INITDIALOG:
		SetDlgItemText(hwnd, IDC_EDIT1, "2005 - 08 - 28");
		SetDlgItemText(hwnd, IDC_EDIT2, "Knight/ICT");
		SetDlgItemText(hwnd, IDC_EDIT3, "TDC Encrypted Password Crackme #4 (password.exe)");
		break;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDOK:
			EndDialog(hwnd, 0);
			break;
		}
		break;
	default:
		return FALSE;
	}
	return true;
}

static BOOL CALLBACK DlgFunc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
	case WM_INITDIALOG:
		SendMessage(hwnd, WM_SETICON, ICON_SMALL, (LPARAM)LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1)));
		SendMessage(hwnd, WM_SETICON, ICON_BIG, (LPARAM)LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1)));
		srand(time(NULL));
		return TRUE;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDC_BEXIT:
			EndDialog(hwnd, 0);
			break;
		case IDC_BABOUT:
			DialogBox(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_ABOUT), hwnd, DlgAbout);
			break;
		case IDC_BGEN:
			Generate(hwnd);
			break;
		}
		break;
	case WM_CLOSE:
		EndDialog(hwnd, 0);
	default:
		return FALSE;
	}
	return TRUE;
}

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	InitCommonControls();
	return DialogBox(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, DlgFunc);
}
