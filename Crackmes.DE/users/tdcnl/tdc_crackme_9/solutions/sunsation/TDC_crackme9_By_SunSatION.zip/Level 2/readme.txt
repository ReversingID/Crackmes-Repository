Written by: TDC
Date written: Thursday 10 November 2005

Rules:
=-=-=-=

No patching, make a correct keyfile for at least level 1 hehe, max level is level 2.

Description:
=-=-=-=-=-=-=

Ok, this is a not so hard one (level 1) but the level 2 part can be a bit more tricky or confuse new reversers. Greetz, TDC