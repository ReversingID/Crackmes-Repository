X-Convertor v1.0 � 2005 by TDC and BoR0
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

Readme:
-=-=-=-

Coded by	: TDC and BoR0
Version		: 1.0
Release date	: 20-08-2005

X-Convertor converts up to 4KB each convert.
(Note: Unregistered version only 4 bytes)

Contact info & Registering:
-=-=-=-=-=-=-=-=-=-=-=-=-=-

1) Visit http://www.reversing.be/ or http://www.reversing.be/forum/memberlist.php
2) Go to the forum, search for either TDC or BoR0 (usernames)
3) Go to one of our profiles
4) Send us an email or PM (Personal Message)

How to use:
-=-=-=-=-=-

The mode button will switch between Hex, Decimal and Binary modes.
Insert some input like: "TDC and BoR0" the output will be for
example "54 44 43 20 61 6E 64 20 42 6F 52 30" as output in Hex mode.
This is usefull for debugging programs or when programming. You could
also use it for other purposes of course.