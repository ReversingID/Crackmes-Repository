#include <iostream.h>
#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <windows.h>
#include <fstream.h>

fstream file;

char name[13], part1[13], part2[13], part3[13];
char serial[100];
DWORD par1=0, par2=0, par3=0;
unsigned int lung=0;

void main()
{
   cout<<"X-Convertor by TDC and BoR0 - Keygen by Ox87k"<<"\n\n";
	cout<<"\nName: ";
	gets(name);
   lung=strlen(name);

   //check len
   if(lung==11)
   {
   	sprintf(name,"%c%c%c",name[0],name[1],name[2]);
      for (int i=3;i<12;i++)
   		strcat(name," ");
   }
   else if(lung<13)
   {
   	for (int i=lung;i<12;i++)
   		strcat(name," ");
   }
   else
   {
    	cout<<"\n\n PLEASE INSERT LESS THAN 12 CHARS IN NAME!";
      cout<<"\n\nPress any key to exit...";
      getch();
      exit(0);
   }
   //load the 3 part... i use a very long method lol!
   sprintf(part1,"%c%c%c%c",name[0],name[1],name[2],name[3]);
   sprintf(part2,"%c%c%c%c",name[4],name[5],name[6],name[7]);
   sprintf(part3,"%c%c%c%c",name[8],name[9],name[10],name[11]);

   //string to hex number
   DWORD pt1=0, pt2=0, pt3=0;
   pt1+=part1[3]*0x1000000;
   pt1+=part1[2]*0x10000;
   pt1+=part1[1]*0x100;
   pt1+=part1[0];

   pt2+=part2[3]*0x1000000;
   pt2+=part2[2]*0x10000;
   pt2+=part2[1]*0x100;
   pt2+=part2[0];

   pt3+=part3[3]*0x1000000;
   pt3+=part3[2]*0x10000;
   pt3+=part3[1]*0x100;
   pt3+=part3[0];

   //xored part
   pt1^=0xFFFFFFF;
   pt2^=0x2987363;
   pt3^=0x7A69;

   //final serial
   sprintf(serial,"%X%c%X%c%X",pt1,0x2D,pt2,0x2D,pt3);
   cout<<serial;

   file.open("reginfo.dat",ios::out);
   //encrypt name
   for (int i=0;i<12;i++)
   	name[i]^=0x2D;
   file<<name;
   file<<serial;
   file.close();

   cout<<"\n\nKeyFile created succesfully!";
	cout<<"\nPress any key to exit...";
   getch();
}
