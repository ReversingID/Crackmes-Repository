// keygen for prout's The thing
// http://www.crackmes.de/users/prout/the_thing/

// Compile with
// gcc -Wall -Wextra -Werror -pedantic -ansi -std=c99 -O3 keygen.c
// No flag is requisite

// The serial is a simple integer computed from the four first
// characters of the name.

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
int main(int argc, char** argv)
{
	if (argc < 2)
	{
		printf("Usage: %s name\n", argv[0]);
		exit(0);
	}

	char* name = argv[1];
	if (strlen(name) < 4)
	{
		printf("The name must be at least four character long.\n");
		exit(0);
	}

	name[3] = (name[3] << 4) | (name[3] >> 4);
	printf("Serial: %d\n", * (int*) name);
	return 0;
}
