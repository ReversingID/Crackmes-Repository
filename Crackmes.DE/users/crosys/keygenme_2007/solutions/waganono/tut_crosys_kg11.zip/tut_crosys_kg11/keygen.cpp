// kiki.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>
#include <stdlib.h>
#include "big.h"
#include "3way.h"
#include "tiger.c"

DWORD way3_key[3]={0x73657250,0x6C707574,0x65696E65};
char base20[21]="XMA9K31VNYZC4LWD7PHE";
char tmp[0x64];

/* En base 20 :) */
void enbase20(DWORD data,char *to){
	DWORD tmp=data;
	char *p=to;

	memset(p,base20[0],8);
	while(tmp){
		*p++=base20[tmp%20];
		tmp=tmp/20;
	}
}


/* The summer is magic hohoho! */
DWORD get_magic_aux(char *chaine){
	DWORD len=lstrlen(chaine);
	__asm{
			MOV EBX,len
			OR EAX,0xFFFFFFFF
			XOR EDX,EDX
			TEST EBX,EBX
			JLE xoring
			MOV EDI,chaine
	looping:
			MOVSX ECX,BYTE PTR DS:[EDX+EDI]
			MOV ESI,EAX
			AND ESI,0xFF
			XOR ECX,ESI
			MOV ESI,8
	mini_loop:
			TEST CL,1
			JE laba
			SHR ECX,1
			XOR ECX,0xEDB88320
			JMP ici
	laba:
			SHR ECX,1
	ici:
			DEC ESI
			JNZ mini_loop
			SHR EAX,8
			XOR EAX,ECX
			INC EDX
			CMP EDX,EBX
			JL looping
	xoring:
			NOT EAX
	}
}

DWORD get_magic(DWORD *data){
	DWORD tmp[2];
	char ch1[18];

	__asm{
			PUSH EBP
			MOV ECX,data
			MOV EDX,0x1990CBDE
			MOV EBX,0xA
			MOV ESI,0x13
			LEA EDI,tmp
	looping:
			MOV EAX,DWORD PTR DS:[ECX+4]
			MOV EBP,DWORD PTR DS:[ECX]
			SUB EDX,2
			XOR EAX,EDX
			XOR EBP,EDX
			SUB EAX,ESI
			SUB EBP,ESI
			MOV DWORD PTR DS:[ECX+4],EAX
			MOV DWORD PTR DS:[ECX],EBP
			MOV DWORD PTR DS:[EDI],EAX
			MOV EAX,DWORD PTR DS:[ECX]
			DEC EBX
			MOV DWORD PTR DS:[EDI+4],EAX
			JNZ looping
			POP EBP
			mov eax,tmp+4
			XOR EDX,EDX
			OR EAX,0x194016
			MOV ECX,EAX
			NOT ECX
			ADD ECX,8
			DIV ECX
			MOV EAX,EDX
			ADD EAX,EAX
			MOV ESI,EAX
			IMUL ESI,ECX
			MOV ECX,EAX
			MOV EDX,ESI
			SHL ECX,8
			SHR EDX,8
			ADD ECX,EDX
			MOV EDX,ECX
			OR ECX,ESI
			OR EDX,EAX
			MOV ESI,EAX
			XOR EDX,ECX
			MOV ECX,EDX
			SHR ECX,0x10
			SHL ESI,0x10
			ADD ESI,ECX
			MOV ECX,ESI
			OR ESI,EDX
			OR ECX,EAX
			XOR EDX,EDX
			XOR ECX,ESI
			XOR EAX,ECX
			ADD ECX,EAX
			OR EAX,0x194017
			DIV ECX
			MOV EAX,EDX
			XOR EDX,EDX
			ADD EAX,EAX
			DIV ECX
			MOV ESI,EDX
			MOV EAX,EDX
			IMUL ESI,ECX
			XOR ESI,EDX
			IMUL EAX,ESI
			OR EDX,EAX
			MOV ESI,EAX
			MOV ECX,EDX
			SHL ECX,8
			SHR ESI,8
			ADD ESI,ECX
			MOV ECX,ESI
			OR ESI,EAX
			OR ECX,EDX
			XOR ECX,ESI
			MOV ESI,EDX
			MOV EAX,ECX
			SHR EAX,0x10
			SHL ESI,0x10
			ADD EAX,ESI
			MOV ESI,EAX
			OR EAX,ECX
			OR ESI,EDX
			XOR ESI,EAX
			ADD ESI,EDX
			mov tmp,esi
	}
	wsprintf(ch1,"%X",tmp[0]);
	get_magic_aux(ch1);
	__asm{
		ADD EAX,0x1990
		XOR ESI,EAX
		MOV tmp,ESI
	}
	return tmp[0];
}

void BSWAP(DWORD *k){
	__asm{
		mov ebx,k
		mov ecx,6
	looping:
		cmp ecx,0
		je yeah
		dec ecx
		mov eax,dword ptr ds:[ebx+ecx*4]
		bswap eax
		mov dword ptr ds:[ebx+ecx*4],eax
		jmp looping
	yeah:
	}
}

DWORD get_hardID(){
	__asm{
		mov eax,1
		cpuid
		add eax,edx
	}
}

void KeyGen(char serial[3][128]){
	miracl *mir;
	big g,y,p,p_min_one,h,x,gcd,k;
	DWORD vect[3],ind=3,HARD_ID;
	DWORD KEY[6];

	/**********/
	/* CD KEY */
	/**********/
	memset(serial,0,64);
	// Some GEN
	while(ind--)
		KEY[ind]=vect[ind]=rand()*rand();
	KEY[4]=rand()*rand();

	// Decrypt with 3-Way block cipher
	ind=0;
	while(ind++<0x64)
		decrypt(vect,way3_key);
	KEY[3]=vect[0];
	
	// Some magic
	vect[0]=KEY[3];
	vect[1]=KEY[4];
	KEY[5]=get_magic(vect);

	// To base 20
	ind=0;
	while(ind!=6){
		enbase20(KEY[ind],serial[0]+9*ind);
		ind++;
	}

	// Make it real :)
	serial[0][8]=serial[0][17]=serial[0][26]=serial[0][35]=serial[0][44]='-';


	/****************/
	/* REQUEST CODE */
	/****************/
	memset(tmp,0,0x64);
	ind=0x64;
	GetUserName(tmp,&ind);
	tiger((word32 *)tmp,lstrlen(tmp),(word32 *)KEY);
	BSWAP(KEY);
	HARD_ID = get_hardID();
	wsprintf(serial[1],"%08X%08X%08X%08X%08X%08X-%08X",KEY[0],KEY[1],KEY[2],KEY[3],KEY[4],KEY[5],HARD_ID);
	lstrcpyn(tmp,serial[1],10);

	/*******************/
	/* ACTIVATION CODE */
	/*******************/
	mir = mirsys(300,16); 
	mir->IOBASE=16;

	g = mirvar(0);			
	y = mirvar(0);			
	p = mirvar(0);			 
	x = mirvar(0);
	gcd = mirvar(0);
	p_min_one = mirvar(0);
	h = mirvar(0);
	k = mirvar(0);

	cinstr(g,"2695F35E39"); 
	cinstr(y,"25668581E8"); /* Public key  */
	cinstr(p,"5376DD85E9"); 
	decr(p,1,p_min_one);

	cinstr(x,"5CD393A79");  /* Private key */

	cinstr(h,tmp);			/* To decrypt */

	/* Get k such gcd(k,p-1) = 1 */
	irand(GetTickCount());
	do{
		bigrand(p_min_one,k);
	}while(egcd(k,p_min_one,gcd)!=1);
	//cinstr(k,"3");

	/* Decrypt it */


	/*powmod(g,k,p,g);     SOLUTION 1 using private key
	subtract(p_min_one,x,x);
	powmod(g,x,p,g);
	multiply(g,h,h);
	divide(h,p,p);*/

                          // SOLUTION 2 
	powmod(y,k,p,y);    // y = y ^ k mod p 
	xgcd(y,p,y,y,y);	  // y = (y^k)^(-1) mod n
	mad(h,y,y,p,p,h);	  // h = h * (y^k)^(-1) mod n

	/* Make it */
	cotstr(k,serial[2]);
	cotstr(h,tmp);
	lstrcat(serial[2],"-");
	lstrcat(serial[2],tmp);
	lstrcat(serial[2],"-");
	enbase20(HARD_ID,serial[2]+lstrlen(serial[2]));

	mirkill(g);
	mirkill(y);
	mirkill(p);
	mirkill(x);
	mirkill(k);
	mirkill(gcd);
	mirkill(p_min_one);
	mirkill(h);
}

