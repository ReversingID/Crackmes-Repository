/*
	Source for a key-generator for a DSA(MD5) scheme.
	Sorry but I'm too lazy to comment the rest of the file.
	Any doubts, reach me on #cracking on EFnet or leave a post
	on the Keygenme's details page on crackmes.de
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "miracl.h"
#include "md5.c"

int main (void)
{
	miracl *mip;

	big s1, r, s, p, q, g, x, k, hash;
	unsigned long int p1, p2;

	md5_state_t state;
	md5_byte_t digest[16];

	char m[10], *_r[20], *_s[20], *serial_1[10], *serial_2[10];

	srand(time(NULL));

	puts("\nKeygen for Crosys' Keygenme v1.0 2008\nby fuss - 12/07/2008\n");

	mip = mirsys(64, 0);

	s1 = mirvar(0);

	do	
	{
		p1 = rand() % 100000000;
		sprintf(serial_1, "%u", p1);
		cinstr(s1, serial_1);	
	} while (!isprime(s1));

	p2 = rand() % p1;
		
	printf("Part 1: %04u-%04u-%04u-%04u-2008-0711\n", p1/10000, p1%10000, p2/10000, p2%10000);

	mirkill(s1);

	sprintf(&m, "%08X", ((rand()<<16)+rand())*rand());

	md5_init(&state);
	md5_append(&state, m, strlen(m));
	md5_finish(&state, digest);

	mip->IOBASE = 24;

	r = mirvar(0);
	s = mirvar(0);
	p = mirvar(0);
	q = mirvar(0);
	g = mirvar(0);
	x = mirvar(0);
	k = mirvar(0);
	hash = mirvar(0);

	cinstr(k, "1");
	cinstr(p, "F34IJ4CD05F6GI28959G7");
	cinstr(q, "BFC6J1I21N5GF5");
	cinstr(g, "15F7N00F9HMA25D7EEA60");
	cinstr(x, "140AMEH18E3");
	bytes_to_big(8, &digest, hash);

	powmod(g, k, p, r);
	powmod(r, k, q, r);

	xgcd(k, q, k, k, k);

	multiply(x, r, x);
	add(x, hash, x);
	multiply(x, k, x);
	cinstr(k, "1");
	powmod(x, k, q, s);

	cotstr(r, _r);
	cotstr(s, _s);

	printf("Part 2: %s-%s-%s\n", m, _r, _s);
	
	mirkill(hash);
	mirkill(k);
	mirkill(x);
	mirkill(g);
	mirkill(q);
	mirkill(p);
	mirkill(s);
	mirkill(r);

	getchar();
	return 0;
}