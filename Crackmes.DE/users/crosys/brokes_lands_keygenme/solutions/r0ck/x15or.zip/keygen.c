#define WIN32_LEAN_AND_MEAN
#define _CRT_SECURE_NO_DEPRECATE
#undef UNICODE

#include <windows.h>
#include <stdlib.h>
#include "md5.h"
#include "xtea.h"
#include "crc32.h"
#include "miracl.h"

#define ERROR_SERIAL "Name must be at least 2 and at most 20 characters!"
#define MD5_LEN	32

#define RSA_D "621AC3B1C7E782897C1B94A657A6BCE9BE9338991366B710C4B21"
#define RSA_N "7CB2EE4EA00A89C1A1BA69BEFFFCDFC0F5C6475A9694FD61309B1"
#define RSA_E "10001"

void mangle_hash(const char *hash, char *output)
{
	int i;
	for(i = 0; i < MD5_LEN; i++)
	{
		if(hash[i] >= '0' && hash[i] <= '9')
		{
			*output++ = hash[i];
		}
	}

	*output = 0;
}

void make_serial(unsigned char *name, char *serial)
{
	char *p;
	int i, nlen;
	unsigned int *cust;
	unsigned char xkey;
	unsigned char hash[MD5_LEN + 1];
	unsigned int eax, ebx, ecx, edx, edi, esi;	// Lazy variable names
	MD5_CTX mdContext;

	// X-TEA
	unsigned int v[2];
	unsigned int k[4] = { 0x4B4F5242, 0x4C2D4E45, 0x53444E41 };

	// CRC32
	unsigned int crcname;

	// RSA
	big C;
	big E;
	big N;
	big D;
	big S;
	miracl *mip = mirsys(300, 16);
	mip->IOBASE = 16;
	C = mirvar(0);
	E = mirvar(0);
	N = mirvar(0);
	D = mirvar(0);
	S = mirvar(0);

	nlen = lstrlen(name);
	if(nlen < 2 || nlen > 20) {
		lstrcpy(serial, ERROR_SERIAL);
		return;
	}

	// Lazy translation of routine to C.
	cust = name + 2;
	ecx = *cust;
	eax = (ecx * 8) - ecx;
	ebx = (eax * 3) ^ 0x4C;
	(unsigned char)xkey = ebx & 0xFF;

	MD5Init(&mdContext);
	MD5Update(&mdContext, name, nlen);
	MD5Final(&mdContext);

	p = hash;
	for(i = 0; i < MD5_LEN / 2; i++)
	{
		wsprintf(p, "%.2x", xkey ^ mdContext.digest[i]);
		p += 2;
	}

	// Work through the first half of the MD5 hash (as text), doing some arithmetic.
	esi = edi = 0;
	for(i = 0; i < 8; i++)
	{
		eax = hash[i] + 0x26260;
		eax *= nlen;
		edx = eax * 5;

		eax = hash[i + 8] + 0x5050;
		eax *= nlen * 5;
		esi += edx * 8;

		edx = eax + edi;
		edi = edx + eax * 4;
	}

	// X-TEA on these values gives us the first 16 bytes of the serial.
	v[0] = esi;
	v[1] = edi;
	encipher(0x1E, v, k);
	wsprintf(serial, "%08X%08X", v[0], v[1]);

	// CRC32
	crcname = crc32buf(name, nlen);
	wsprintf(hash, "%08X", crcname);

	// RSA-211
	cinstr(D, RSA_D);
	cinstr(N, RSA_N);
	cinstr(E, RSA_E);
	cinstr(C, hash);
	powmod(C, D, N, S);
	serial[16] = '-';

	cotstr(S, serial + 17);

	// Static end part.
	lstrcat(serial, "-BROKEN-LANDS");

	// Fin
	return;
}
