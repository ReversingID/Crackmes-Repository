Solution to SerialMe2_Crackme_by_toma6868 by MACH4

If you have problems with the flash video size, Google for "SWF Opener" by UnH Solutions, I wouldn't be without it!

Greetz to toma6868, Crackmes.de and all crackers!