SerialMe_2 By Toma6868

This is my 2nd CrackMe... I hop it will delight some of you :)

Rulez :
-> Enable the "V" Button which is to validate your serial...
-> Find the serial
-> write a tuto

enjoy ;-)