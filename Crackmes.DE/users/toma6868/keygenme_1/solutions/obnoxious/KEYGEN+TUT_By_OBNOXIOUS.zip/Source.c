/****My First Keygen Ever****/
#include<stdio.h>
#include<string.h>
void main()
{
int nlen,i,j,c=0,t=0;
char name[10],key[20];
printf("\t\t\t::::OBNOXIOUS'S KEYGEN::::\n");
printf("Name: ");
scanf("%s",name); //getting name
nlen=strlen(name); //getting length of name
for(j=0;j<nlen;j++)
for(i=c;name[j]>=1;i++) //converting to hex
{
key[i]=name[j]%16;
name[j]=name[j]/16;
c++;
}
for(i=0;i<c;i=i+2) //sorting out the elements in right order
{
t=key[i];
key[i]=key[i+1];
key[i+1]=t;
}
printf("\nKey: ");
for(i=c-1;i>=0;i--) //printing the key ;)
{
if(key[i]>=10)
printf("%c",key[i]+55);
else
printf("%d",key[i]);
}
}
//Thank You!!!!//