#include<stdio.h>
#include<conio.h>
#include<string.h>
int main()
 {
          // I know this is not the best way to code, but it works  :)
          char name[255];
          int i,len,temp;
          printf("***********************************************\n");
          printf("** Keygen for Toma6868's KeyGenMe_1 by br0ken**\n");
          printf("***********************************************\n");
          printf("\nName (4 or more chars) : ");
          scanf("%s",name);
          len=strlen(name);
          printf("\nSerial : ");
          for(i=len-1;i>=0;i--)
          {
          
          temp = name[i] % 0x10 ;
          if(temp>=10 && temp <=16) // Take care of lower case :)
           {
                      printf("%c",temp+0x37);
                      goto skip;
           }
          printf("%x",temp);
          skip: temp = name[i]/ 0x10;
         
          printf("%x",temp); 
          }
          printf("\n\n\nPress any key to quit...");
          getch();
          return 0;
 }
          
