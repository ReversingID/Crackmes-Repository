
 Welcome :)

 This is my old crackme, which I wrote long time
 ago for my friends from HTBTeam. It's quite easy
 but you will have to think a bit to solve it :)
 Have fun and when you make a keygen please send
 it at:

 tymon_crk@wp.pl

 Rules:
 - don't use any brute-force to solve this crackme (!!!!!!!!!)
 - don't patch !
 - do keygen

 regards,
 Tymon