_______________________________________________________________________________
  re-trace@crudd - README                                          2004.07.28
�������������������������������������������������������������������������������
hell_master (hellismykingdom@yahoo.com)

  Although this crackme is not really difficult to solve, I found its validation
  routine very funny.

  The serial is composed of 3 parts:

  +------------+ +---+ +------------+ +-----+
  |  serial_1  |+|   |+|  serial_2  |+|     |
  +------------+ +-+-+ +------------+ +--+--+
                   |                     |
                   +---> special byte    +----> "hidden" bytes

  To succeed the validation, several conditions must be fulfilled:

  1. the name length must be greater or equal than four (4) characters
  2. the 'special byte' is augmented by the length of the group

  3. if no group is specified, serial_2 must be equal (after a specific XOR) to
     the value located at the address defined by serial_1 (after some treatment).
     if a group is specified, serial_2 must be equal (after a specific XOR) to
     the value located at the address defined by serial_1 augmented by 15h units
     (after some treatment).

     --> serial_2 XOR seed == function([serial_1]) XOR seed     (if no group)
     --> serial_2 XOR seed == function([serial_1+15h]) XOR seed (if group exists)

  TRICK: the trick is:
         - point serial_1 to the two (2) last bytes of the serial_string (004030FB)
         - to precalculate the return of the function for a given string (i.e '01')
         - set serial_2 to this value.

             +------------+ +---+ +------------+ +----+
        -->  |  BF030400  |+| G |+|  03900000  |+| 01 | if group does not exist
             +------------+ +---+ +------------+ +----+
             +------------+ +---+ +------------+ +----+
        -->  |  6E030400  |+| H |+|  03900000  |+| 01 | if group_len = 1
             +------------+ +---+ +------------+ +----+

             NOTE: the 'special byte' must be calculated according the group length.

-- hell_master --
             