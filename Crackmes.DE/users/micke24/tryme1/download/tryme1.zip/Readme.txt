Hi Coders. This is my first KeygenMe, its coded in VB6.
Its a level 1/10 KeygenMe so this is for you newbies out there.
First of all you have to enable the OK button, after that find 
the serial for your name and make a keygen..
NO PATCHING..!!
ONLY KEYGENNING..!!

Send your solution to me at michael.eriksson@bredband.net

Good Luck..!!