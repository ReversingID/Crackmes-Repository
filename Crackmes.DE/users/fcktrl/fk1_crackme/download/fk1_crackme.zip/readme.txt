Alowed solutions with path, keygen.

Try to register with license file.