SignMe by PnUic

emuletor AVD details
target: Android 3.1 (API 12)
Min Skin: 240x320
