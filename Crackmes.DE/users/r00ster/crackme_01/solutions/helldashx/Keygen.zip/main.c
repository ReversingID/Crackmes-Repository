#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

char Buffer[260];
DWORD pcbBuffer = 260;

int __cdecl sub_4012F8() 
{ 
  DWORD v0; 
  v0 = 0;
  int v1; 
  do 
  { v1 = ((*(DWORD *)&Buffer[v0] + 3) | 2) - 1; 
  if ( ((*(DWORD *)&Buffer[v0] + 3) | 2u) - 1 < 0x20 ) 
   break; 
   *(DWORD *)&Buffer[v0++] = v1; 
   if ( (unsigned int)v1 < 0x20 ) break; 
   } while ( v0 != pcbBuffer ); 
  Buffer[3] = 45;  
}

int main(int argc, char *argv[])
{
  int result = GetUserNameA(Buffer,&pcbBuffer);
  if(result == ERROR_INSUFFICIENT_BUFFER)
  {
            printf("Error, not enough buffer for it...\n");
            goto __exit;
  }
  else
  {
      sub_4012F8();
      printf("Serial: %s\n",Buffer);
  }
  
__exit:
  system("PAUSE");	
  return 0;
}
