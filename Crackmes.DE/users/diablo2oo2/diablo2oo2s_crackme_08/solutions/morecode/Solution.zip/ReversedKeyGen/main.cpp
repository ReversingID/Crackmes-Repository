
#include"d2k2,CrackMe,KeyGen.hpp"


/*
*  Implemented tow applications in one. Firstly it tries to 
*  use given serial an user name to verify if everything matches.
*  In the hypotetical case that you magic number (serial number) 
*  is not right, it does automatically execute keygenerator.
*/
using namespace std;
int main (void) {

  unsigned char aubUserLogIn[256];
  unsigned char aubUserName[256];
  unsigned char aubUserSerial[256];

     memset(aubUserLogIn ,0x00,sizeof(aubUserLogIn));
     memset(aubUserName  ,0x00,sizeof(aubUserName));
     memset(aubUserSerial,0x00,sizeof(aubUserSerial));
    
     memcpy(aubUserLogIn ,"Administrator",0x0d);
     memcpy(aubUserName  ,"Alejandra",0x09);
     memcpy(aubUserSerial,"22EDA431B22F428BF7AC9AE92633A294",32);
     memcpy(aubUserSerial,"22EDA431B22F428BF7AC9AE92633A291",32);

     cout << "ID    : " << aubUserLogIn  << endl;
     cout << "Name  : " << aubUserName   << endl;
     cout << "Serial: " << aubUserSerial << endl;

     d2k2CrackMe cCrackMe(aubUserLogIn,aubUserName,aubUserSerial); 
     if (cCrackMe.bCrakcMe() == VALUEOK)
     {
        cout << "\t\t\t+-----------------------------------+" << endl;
        cout << "\t\t\t|                                   |" << endl;
        cout << "\t\t\t|  Serial is correct!               |"  << endl;
        cout << "\t\t\t|  ...but is it from a keygen?      |" << endl;
        cout << "\t\t\t|                                   |" << endl;
        cout << "\t\t\t+-----------------------------------+" << endl;
     } 
     else
     { 
        cout << "\t\t\t+-----------------------------------+" << endl;
        cout << "\t\t\t|                                   |" << endl;
        cout << "\t\t\t|  Wrong Serial!                    |" << endl;
        cout << "\t\t\t|  You know what to do...try again! |" << endl;
        cout << "\t\t\t|                                   |" << endl;
        cout << "\t\t\t+-----------------------------------+" << endl;

        cCrackMe.vKeyGen();
        cout << "\t\t\t|"  << endl;
        cout << "\t\t\t|"  << endl;
        cout << "\t\t\t+-------------------------------------------------------+" << endl;
        cout << "\t\t\t|                                                       |" << endl;
        cout << "\t\t\t|  Serial did not match I suggest you use generated one |" <<  endl;     
        cout << "\t\t\t|  Serial: " << cCrackMe.abGetSerial() << "             |"<<endl; 
        cout << "\t\t\t|                                                       |" << endl;
        cout << "\t\t\t+-------------------------------------------------------+\n\n" << endl;
    
     }
  return 0;
}

