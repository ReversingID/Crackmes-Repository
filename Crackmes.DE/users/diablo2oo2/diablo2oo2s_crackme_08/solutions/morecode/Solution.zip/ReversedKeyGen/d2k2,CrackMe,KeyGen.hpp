
#ifndef MAIN_D2K2_H_
#define MAIN_D2K2_H_

#include<iostream>
#include<string.h>
#include<stdio.h>
#include<gmp.h>
#include"haval.h"

#define VALUEOK  0x01
#define VALUEBAD 0x00

typedef unsigned long ULONG;
typedef unsigned char UBYTE;
typedef          char  BYTE;


class d2k2CrackMe {
  UBYTE aubUserLogIn[256]; 
  UBYTE ubUserLogInLen;
  UBYTE aubUserLogInFrame[256];
  UBYTE aubUserLogInHash[256];
  UBYTE aubUserLogInID[256];
  UBYTE aubUserName[256];
  ULONG ulTransName[4]; 
  UBYTE aubUserSerial[256];
  UBYTE crc[2];
  int adwGenID[4];
  ULONG ulOffset01,ulOffset02;
  
  mpz_t mpzP,mpzQ,mpzN,mpzE,mpzD,mpzR,enc,dec;
  mpz_t mpzTransName;


public:
  d2k2CrackMe ();
  ~d2k2CrackMe ();
  d2k2CrackMe (UBYTE *aubEUserLogIn,UBYTE *aubEUserName,UBYTE *aubEUserSerial);
  BYTE bCrakcMe(void);
  void vKeyGen(void);
  UBYTE* abGetSerial(void);

private:
  void vGenerateEnv(void);
  void vGenerateHavalHash();
  void vHavalHash2ID();
  void vOffsetCalculation();
  void vNameTransformation();
    void vLoadMpzParams();
  UBYTE ubStrLen(UBYTE *str,UBYTE maxlen);
};

#endif

