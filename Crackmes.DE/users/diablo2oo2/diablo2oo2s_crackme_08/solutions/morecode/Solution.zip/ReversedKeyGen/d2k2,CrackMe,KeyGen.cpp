
#include"d2k2,CrackMe,KeyGen.hpp"


UBYTE _gbRor;
UBYTE _gbRol;
ULONG _gulTmp1,_gulTmp2,_gulTmp3,_guldwOffset01,_guldwOffset02;

using namespace std;

extern "C" void _havalFinal(UBYTE *HashValue,int *dwGenID);
extern "C" void _havalString(UBYTE *aubUserLogIn, int iUserLogInLen, UBYTE *aubUserLogInFrame);
extern "C" void _lSwapTab(void);
extern "C" BYTE byte_40521A[1024];

/**
 * 
 */
UBYTE d2k2CrackMe::ubStrLen(UBYTE *str,UBYTE maxlen)
{
  UBYTE ii;
  
    ii = 0;
    while ((ii<maxlen) && (str[ii]!=0))
    {
      ii++;
    } 
    if (maxlen == ii) 
    {
     ii = 0;
    }
    return((UBYTE)ii);
}


/**
 * Load class with some default values 
 */
d2k2CrackMe::d2k2CrackMe () 
{ 
  UBYTE aubUserLogIn[256];
  UBYTE aubUserName[256];
  UBYTE aubUserSerial[256];

    memcpy(aubUserLogIn ,"Administrador",0x0d);
    memcpy(aubUserName  ,"Alejandra"    ,0x09);
    memcpy(aubUserSerial,"22EDA431B22F428BF7AC9AE92633A294",32);

    d2k2CrackMe(aubUserLogIn,aubUserName,aubUserSerial); 
}

/**
 * 
 */
d2k2CrackMe::d2k2CrackMe (UBYTE *aubEUserLogIn,unsigned  char *aubEUserName,unsigned  char *aubEUserSerial) 
{ 
  int iUserLogInLen;

    memset(aubUserLogIn,0x00,sizeof(aubUserLogIn));
    memcpy((char*)aubUserLogIn,(char*)aubEUserLogIn,ubStrLen(aubEUserLogIn,255));

    ubUserLogInLen = ubStrLen(aubUserLogIn,255);

    memset(aubUserLogInFrame,0x00,sizeof(aubUserLogInFrame));

    iUserLogInLen = (int)ubStrLen(aubEUserLogIn,255);

    _havalString(aubUserLogIn, iUserLogInLen, aubUserLogInFrame);

    memset(aubUserName,0x00,sizeof(aubUserName));
    memcpy(aubUserName,aubEUserName,ubStrLen(aubEUserName,255));

    memset(aubUserSerial,0x00,sizeof(aubUserSerial));
    memcpy(aubUserSerial,aubEUserSerial,ubStrLen(aubEUserSerial,255));

    mpz_init (enc );
    mpz_init (dec );
    mpz_init (mpzP );
    mpz_init (mpzQ );
    mpz_init (mpzN );
    mpz_init (mpzE );
    mpz_init (mpzD );
    mpz_init (mpzR );
    mpz_init (mpzTransName);

    /**
     * Table was swapt in the original application to be able to 
     * load values from table. Since we are using GMP library,  
     * its reading function can read backguard or forward. we do 
     * not realy need this function. I am keeping it anyways.  
     */

  _lSwapTab();

}



/**
 * class destructor. Clearing internal variables
 */
d2k2CrackMe::~d2k2CrackMe () 
{ 
  mpz_clear (enc );
  mpz_clear (dec );
  mpz_clear (mpzP );
  mpz_clear (mpzQ );
  mpz_clear (mpzN );
  mpz_clear (mpzE );
  mpz_clear (mpzD );
  mpz_clear (mpzR );
  mpz_clear (mpzTransName);
}


/**
 * Read serial number from private.
 */
UBYTE* d2k2CrackMe:: abGetSerial(void) 
{
  return(aubUserSerial);
}

/**
 * Preparation, calling and reading back from "haval_hash_block"
 * function provided in the implementation of Yuliang Zheng
 */
void d2k2CrackMe::vGenerateHavalHash(void) 
{
  haval_state   state;
  int i,j;

  haval_start (&state); 

  j =0;
  for (i = 0;i<32;i++) {
    memcpy ((UBYTE *)(&(state.block[i])), &aubUserLogInFrame[j], 4);
   j = j + 4; 
  }

  haval_hash_block (&state);
  state.fingerprint[0] = state.fingerprint[0]+ 0x10101010; 

  j=0;
  for (i=0;i<8;i++) {
     memcpy((&aubUserLogInHash[j]),((&state.fingerprint[i])),4);
     j = j + 4; 
  }
  
  //printf("Haval block hash result = \n");
  //for (i=0;i<32;i++){
  //  printf("%02x ",(UBYTE )aubUserLogInHash[i]);
  //}
  //printf("\n");
}

/*
* Get finger print values. process it and generate a 2 words as ID.
* ID is in capitals. 
*/
void d2k2CrackMe::vHavalHash2ID() 
{
  int i,j;

    _havalFinal((UBYTE*)aubUserLogInHash,adwGenID);
    j=0;
    for (i=0;i<2;i++) {
      memcpy((&aubUserLogInID[j]),((&adwGenID[i])),4);
      j = j + 4; 
    }
}

/*
*
*
*/
void d2k2CrackMe::vOffsetCalculation(void) 
{
  int i;
   
    _gulTmp1 = adwGenID[0];
    _gulTmp2 = adwGenID[1];
    _gbRor = 8;
    _gbRol = 0x10;

    for (i=0;i<ubUserLogInLen;i++)
    {
     asm("mov eax,_gulTmp1;"
         "ror eax,8;"
         "mov ebx,_gulTmp2;"
         "rol eax,4;"
         "xor eax, ebx;"
         "xor edx, edx;"
         "mov ecx, 0x80;"
         "div ecx;"
         "mov _guldwOffset01,edx;"
         "xor edx, edx;"
         "div ecx;"
         "mov _guldwOffset02,edx;"
         "add _gbRor,dl;"
         "sub _gbRol,al;"    
        );
    }
    ulOffset01 = _guldwOffset01;
    ulOffset02 = _guldwOffset02;
 } 

/*
* 
*/
void d2k2CrackMe::vNameTransformation(void) 
{
  ULONG ubMem[100];
  UBYTE ubii;
  ULONG *ip;

    ubii = 0;
    ip = (ULONG*) &aubUserName;
    _gulTmp2 = *ip;
    _gulTmp3 = ubStrLen(aubUserName,255);
    for (ubii=0;ubii<4;ubii++)
    {
      memset(ubMem,0x00,100);
      memcpy(ubMem,((BYTE*)(adwGenID)+ubii),4);

      _gulTmp1 = ubMem[0]/aubUserName[ubii];
      asm(  "mov     eax, _gulTmp1;"
            "mov     ecx, _gbRol;"
	    "rol     eax, cl;" 
            "xor     eax, 0xEDB88320;"
            "mov     ebx, _gulTmp2;"
            "xor     eax, ebx;"
            "mov     ecx , _gbRor;"
	    "ror     eax, cl;" 
            "sub     eax, _gulTmp3;"
	    "mov     _gulTmp1,eax;"
	  );
	 ulTransName[ubii] = _gulTmp1;
    }
    //printf("Transformed name:");
    //for (ubii=0;ubii<4;ubii++) {
    //    printf("0x%X ",ulTransName[ubii]);
    //}    
    //printf("\n");
}

/**
 * Load large values to be used with the large number library
 */
void d2k2CrackMe::vLoadMpzParams(void) 
{
    // load from table with primes, values pointed by 
    // ulOffset01 and ulOffset02 
    mpz_import  ( mpzP, 8,1,1,0,0,(&byte_40521A[(ulOffset01*8)]));
    mpz_import  ( mpzQ, 8,1,1,0,0,(&byte_40521A[(ulOffset02*8)]));

    // Load exponents
    mpz_set_str ( mpzE, "10001", 0x10 );
 
    //load user's serial number
    mpz_set_str ( mpzD  , (char*)aubUserSerial,0x10);
   
    // load transformed name
    mpz_import  ( mpzTransName, 8,1,1,0,0,(&ulTransName[0]));
    mpz_mul(mpzN,mpzP,mpzQ);
}

/**
 * 
 */
void d2k2CrackMe::vGenerateEnv(void) 
{
  vGenerateHavalHash();
  vHavalHash2ID();
  vOffsetCalculation(); 
  vNameTransformation();
  vLoadMpzParams();
}

/**
 * 
 */
void d2k2CrackMe::vKeyGen(void) 
{
  mpz_t mpzP1,mpzQ1,mpzN1,mpzAux;
  
    vGenerateEnv();
    mpz_init(mpzP1);
    mpz_init(mpzQ1);
    mpz_init(mpzN1);
    mpz_init(mpzAux);

    mpz_set_str ( mpzAux,  "1", 0x10 ); 
    mpz_sub(mpzP1,mpzP,mpzAux);        // P1 = P - 1 
    mpz_sub(mpzQ1,mpzQ,mpzAux);        // Q1 = Q - 1
    
    mpz_mul(mpzN1,mpzP1,mpzQ1);        // N1 = P1 * Q1 
    mpz_invert(mpzR,mpzE,mpzN1);
    mpz_powm(dec,mpzTransName,mpzR,mpzN);
    
    // Printing hex values BASE = 16=0x10, but this is lower case,
    // to get values upper case, -0x10.
    mpz_get_str ( (char*)aubUserSerial, -0x10, dec );   

    mpz_clear(mpzP1);
    mpz_clear(mpzQ1);
    mpz_clear(mpzN1);
    mpz_clear(mpzAux);
}

/**
 *  This rotine implements the functionality of the original crackme
 */
char d2k2CrackMe::bCrakcMe(void) 
{ 
  BYTE bRetVal;

    vGenerateEnv();
    mpz_powm(enc,mpzD,mpzE,mpzN);
    mpz_import ( mpzTransName, 8,1,1,0,0,(&ulTransName[0]));

    if (mpz_cmp(enc,mpzTransName) == 0) // if equal
    {
      bRetVal = (BYTE)VALUEOK;
    } else {
      bRetVal = (BYTE)VALUEBAD;
    }    
  return(bRetVal); 
}


