#include<iostream>
#include<string.h>
#include<cstring>
using namespace std;
void main()

{
	char str[]=("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");
	char str1[63]={0};
	char str2[63]={0};
	char inter[128]={0};
	char name[128]={0};
	int t={0};
	char ch;
	char serial[128]={0};
	int slen,split1,i,j,k,l;
	cout << "Serial Generator For d2k2.crkme.09 by diablo2oo2.\n";
	cout << "Cracker -- Kalippan\n\n";
	cout << "Enter Name : ";
	cin >> name;
	slen=strlen(name);
	
	split1=slen*4;
	if (split1>60){split1=30;}

	for(i=split1, j=0;i<62;i++,j++) //making a second string based on len(name)
	{
		str1[j]=(str[i]);
	}
	for(i=0,j=strlen(str1);i<split1;i++,j++)
	{
		str1[j]=str[i];
	}

	k=name[0];
	k=k<<3;
	while(k>255)
	{
		k=k-255;
	}
	j=strlen(name);

	for(i=0;i<j;i++)    // the intermediate string made from name..
	{
		t=name[i]^name[i+1];
		t=t+k;
		k=k+t;
		if(k>255){k=k-256;}
		if(t>255){t=t-256;}
		t%=62;
		t=str1[t];
		inter[i]=t;
	}

	
	for(i=0;i<strlen(inter);i++)  //finding the serial corresponding to name.
	{
		ch=inter[i];

		for(j=0;j<strlen(str1);j++)
		{
			if (str1[j]==ch)
			{
				for(k=j,l=0;k<strlen(str1);k++,l++) //making a 3rd string starting with the
				{									//char corresponding to intermediate string.
					str2[l]=str1[k];
				}
				for(k=0;k<j;k++)
				{
					str2[k+l]=str1[k];
				}
				ch=name[i];
				for(k=0;k<strlen(str);k++)      //find the position of the name in str.
				{								//the corresponding position in 3rd string gives the serial
					if (ch==str1[k])
					{
						serial[i]=str2[k];
						break;
					}
				}
				
				break;
		
						
								
			}
			
		}

	
		
	}
	cout << "\n\nSerial : ";

	cout << serial << "\n";
	cin >> serial;


}//--Kalippan 11/12/08 11.30PM