
#define  AND &&
#define  OR  ||
#define  MOD %
#define  DIV /
#define  XOR ^
#define  NOT !

#include "iostream.h"
#include "fstream.h"
#include "stdio.h"
#include "stdlib.h"
#include "conio.h"
#include "math.h"
#include "string.h"
#include "windows.h"

void swapstring( char*, const char*, int );
char* stripname( char* );
bool contained_in_base( char );
void changename( char*, char*, const char* );
int findoffset( char, const char* );
BYTE ROL( BYTE input, BYTE number_of_times );

char base[63] = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";


void main() {

  const int SIZE = 80;
  char *name = new char[SIZE];
  char *name2 = new char[SIZE];
  char *swapped1 = new char[SIZE];
  char *swapped2 = new char[SIZE];
  char serial[SIZE];

  cout << "Input name: "; gets( name ); cout << endl;
  name = stripname( name );
  int namelen = strlen( name );
  int offset = ( 4*namelen ) & 0xFF;
  swapstring( swapped1, base, offset );
  changename( name2, name, swapped1 );  //name2 = the changed version ( t.ex Bg7rqL )

  cout << "Serial: ";
  for ( int i = 0; i < namelen; i++ ) {
    int offset2 = findoffset( name[i], swapped1 );
    swapstring( swapped2, swapped1, offset2 );
    int offset3 = findoffset( name2[i], swapped1 );
    cout << swapped2[offset3];
  }

  gotoxy( 4, 16 );
  cout << "Press any key to continue...";
  getch();

}

//------------------------------------------------------------------------------

int findoffset( char ch, const char *str ) {
  int i = 0;
  while ( str[i] != ch ) i++;
  return i;
}

//------------------------------------------------------------------------------

bool contained_in_base( char ch ) {
  for ( int i = 0; i < strlen( base ); i++ ) {
    if ( ch == base[i] ) return true;
  }
  return false;
}

//------------------------------------------------------------------------------

char* stripname( char *nam ) {
  int j = 0;
  char *temp = new char[80];
  for ( int i = 0; i < strlen( nam ); i++ ) {
    if ( contained_in_base( nam[i] )) { temp[j] = nam[i]; j++; }
  }
  temp[j] = 0;
  return temp;
}

//------------------------------------------------------------------------------

void changename( char *nam2, char *nam, const char *swap ) {
  int baselen, dl, al, offs;
  baselen = strlen( base );
  dl = nam[0];
  dl = ROL( dl, 3 );
  int i = 0;
  while ( nam[i] != 0 ) {
    al = nam[i];
    al = al XOR nam[i+1];
    al = ( al + dl ) & 0xFF;
    dl = ( dl + al ) & 0xFF;
    offs = al MOD baselen;
    nam2[i] = swap[offs];

    i++;
  }
  nam2[i] = 0;
}

//------------------------------------------------------------------------------

void swapstring( char *dest, const char *src, int n ) {

  string part1, part2, all = src;
  part1 = all.substr( n, strlen( src ) - n );
  part2 = all.substr( 0, n );
  part1.append( part2 );
  strcpy( dest, part1.c_str());

}

//------------------------------------------------------------------------------

BYTE ROL( BYTE input, BYTE number_of_times )
{

  BYTE result = input;
  int highbit;

  for ( int i = 0; i < number_of_times; i++ ) {

    highbit = result & 0x80;
    if ( highbit != 0 ) highbit = 1; else highbit = 0;
    result = ( result & 0x7F )*2 + highbit;

  }

  return result;
}

//------------------------------------------------------------------------------


