#include "sudoku.h"

unsigned char board[SIZE][SIZE];
unsigned int  found = 0;
unsigned char diagonal[SIZE];
                                                          

void print_board( void )
{
    int i, j;
    for ( i = 0; i < SIZE; i++ )
    {
        for ( j = 0; j < SIZE; j++ )
        {
            fprintf( stdout, " %02X", board[i][j] );
            if ( ( j + 1 ) % DIM == 0 ) fprintf( stdout, "  " );
        }
        fprintf( stdout, "\n" );
        if ( ( i + 1 ) % DIM == 0 ) fprintf( stdout, "\n" );
    }
}

/**********************************************
 * check if its allowed to set the number z   *
 * into the board on position x, y            *
 *                                            *
 * return 1 if allowed, or                    *
 *        0 if not allowed                    *          
 **********************************************/
int allowed( int x, int y, unsigned char z )
{
    int i, j, bi, bj;

    // number is already in this cell
    if ( board[x][y] == z ) return 1;

    // cell is empty
    if ( board[x][y] != EMPTY ) return 0;

    // check row and col
    for ( i = 0; i < SIZE; i++ )
    {
        if ( board[i][y] == z ) return 0;
        if ( board[x][i] == z ) return 0;
    }

    // check the box
    bi = x / DIM;
    bj = y / DIM;
    for ( i = bi * DIM; i < ( bi + 1 ) * DIM; i++ )
        for ( j = bj * DIM; j < ( bj + 1 ) * DIM; j++ )
            if ( board[i][j] == z ) return 0;

    // all checks successful passed
    return 1;
}

void solve( int x, int y, int *f )
{
    int n, t;
 
    if ( *f == 1) return;                 // if finished -> go out
    if ( x == SIZE ) *f = 1;              // if board filled -> set finish
    else
        for ( n = 0; n < SIZE; n++ )
            if ( allowed( x, y, n ) ) 
            {
                /* Try n at row, col */
                t = board[x][y];
                board[x][y] = n;
                
                /* Move on to next square */
                if ( y == SIZE - 1 ) 
                {
                    solve( x + 1, 0, f );
                    if ( *f == 1 ) return;
                }
                else 
                {
                    solve(x, y + 1, f);
                    if ( *f == 1 ) return;
                }
                /* Undo n at row, col (backtrack) */
                board[x][y] = t;
            }
}

void fill_board( unsigned char *diagonal )
{
    int i, j;

    // clear board
    for ( i = 0; i < SIZE; i++ )
        for ( j = 0; j < SIZE; j++ )
            board[i][j] = EMPTY;

    // fill diagonal
    for ( i = 0; i < SIZE; i++ )
        board[i][i] = diagonal[i];
}

void get_board( unsigned char *out )
{
    int i;
    for ( i = 0; i < ( SIZE * SIZE ); i++ )
        out[i] = board[i/SIZE][i%SIZE];
}
