#include <windows.h>
#include <stdio.h>
#include "resource.h"
#include "keygen.h"
#include "md5.h"
#include "base64.h"
#include "sudoku.h"

HINSTANCE hInst;

static char szAboutCapt[] = "diablo2oo2 Keygenme#10";
static char szAboutText[] = "Cracker:\tScareByte\n"
                            "Protection:\tMD5, Base64, Sudoku (16x16)\n\n"
                            "Greets:\nall diablo2oo2 (for crackme), "
                            "Chendler, EOD, Hasher, fatcap, figugegl, "
                            "MackT, nARC, Statman, ZigD\n"
                            "and all i've forgot .. sry ;)";
static char szKGCapt[]    = "diablo2oo2 Keygenme#10 - Keygen by sb^uCF";

LRESULT CALLBACK DlgKg   ( HWND, UINT, WPARAM, LPARAM );
LRESULT CALLBACK DlgAbout( HWND, UINT, WPARAM, LPARAM );
void             Generate( HWND );


/***************************************************
* Mix md5_dig and generate buff_1 with length 16  *
*                                                 *
***************************************************/
void sub_40151D( unsigned char* md5_dig, unsigned char* buff )
{
    unsigned char a, b, c, i, j;

    // fill buffer with numbers 0, 1, ..., 14, 15
    for ( i = 0; i < 16; i++ ) buff[i] = i;

    // outside loop
    for ( j = 0;  j < 16; j ++ )
    {
        // inside loop
        for ( i = 0; i < 16; i++ )
        {
            a = md5_dig[i] & 0x0F;
            b = md5_dig[i] >> 4;
            c = buff[a];
            buff[a] = buff[b];
            buff[b] = c;
            md5_dig[i] = ( md5_dig[i] + c ) ^ 0x17;
        }
    }
}

/***************************************************
* take [in] and generate [out]                    *
* e.g.  in[ 03 05 0A 03 08 04 .. ]                *
*      out[ 35 A3 84 .. ]                         *
*                                                 *
***************************************************/
void sub_4014C7( unsigned char* out, const unsigned char* in, int len )
{
    int i;
    for ( i = 0; i < len; i++ )
        out[i] = ( in[2*i] << 4 ) + ( in[2*i+1] & 0x0F );
}

/***************************************************
* take b64_dec and xor it with buff_2             *
*                                                 *
***************************************************/
void sub_4014F5( unsigned char* b64, const unsigned char* buff_2, int len_out, int len_in )
{
    int i;
    for ( i = 0; i < len_out; i++ )
        b64[i] ^= buff_2[i%len_in];
}

void Generate( HWND hDlg )
{
    MD5_CTX       ctx;
    char          szName[256];
    char          szSerial[256];
    int           i;
    unsigned char b64dec[128];
    unsigned char digest[ 16];
    unsigned char buff_1[ 16];
    unsigned char buff_2[  8];
    unsigned char buff_3[256];

    if ( GetDlgItemTextA( hDlg, ED_NAME, szName, 128 ) == 0 )
    {
        SetDlgItemTextA( hDlg, ED_SERIAL, "pls enter your name ..." );
        return;
    }

    strncat( szName, "-diablo2oo2", 12 );

    // get MD5 digest of name+"diablo2oo2";
    MD5Init  ( &ctx );
    MD5Update( &ctx, (const unsigned char *)&szName, ( unsigned int )strlen( szName ) );
    MD5Final ( digest, &ctx );

    // some routines on digest and buffer
    sub_40151D( digest, buff_1 );
    sub_4014C7( buff_2, buff_1, sizeof( buff_2 ) );

    // solve sudoku 16x16
    fill_board( buff_1 );    
    i = 0;
    solve( 0, 0, &i );
    get_board( buff_3 );

    // final routines and base64
    sub_4014C7  ( b64dec, buff_3, sizeof( b64dec ) );
    sub_4014F5  ( b64dec, buff_2, sizeof( b64dec ), sizeof( buff_2 ) );
    to64frombits( szSerial, b64dec, sizeof( b64dec ) );

    SetDlgItemTextA( hDlg, ED_SERIAL, szSerial );
    SetFocus( GetDlgItem( hDlg, ED_SERIAL ) );
    SendMessageA( GetDlgItem( hDlg, ED_SERIAL ), EM_SETSEL, 0, strlen( szSerial ) );
}

LRESULT CALLBACK DlgKg ( HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam )
{                                     
    int nSize = 255; 
    char szUser[255];
    switch ( message )                                                                                   
    {                                                                                                  
    case WM_INITDIALOG :
        GetUserNameA( szUser, &nSize );
        SendDlgItemMessageA( hDlg, ED_NAME, EM_SETLIMITTEXT, ( WPARAM ) 255, 0 );
        SetWindowTextA( hDlg, szKGCapt );
        SetDlgItemTextA( hDlg, ED_NAME, szUser );
        SetDlgItemTextA( hDlg, ED_SERIAL, "pls enter your name ..." );        
        return TRUE;                 
                                                                    
    case WM_COMMAND:                                                                                 
        switch ( LOWORD ( wParam ) )                                                                         
        {                                                                                                
        case BT_GENERATE :                                                                              
            Generate( hDlg );			                                                                                     
            break;                                

        case BT_ABOUT :
            DialogBoxA( hInst, MAKEINTRESOURCE( DLG_ABOUT ), hDlg, DlgAbout );
            break;
                                                         
        case BT_EXIT :                                                                                 
            EndDialog( hDlg, 0 );                                                                           
            break;       

        case ED_NAME :
            // if ( HIWORD( wParam ) == EN_CHANGE ) Generate( hDlg );
            break;
        }                                                                                                
        break;          
    case WM_CLOSE :
        EndDialog( hDlg, 0 );
        break;
    }                                                                                              
    return FALSE;                                                                                  
}

LRESULT CALLBACK DlgAbout( HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam )
{
    switch ( message )
    {
    case WM_INITDIALOG :
        SetDlgItemTextA( hDlg, STATIC_ABOUT, szAboutText );
        SetDlgItemTextA( hDlg, STATIC_ABOUT_CAPTION, szAboutCapt );
        return TRUE;

    case WM_COMMAND:
        if ( LOWORD( wParam ) == IDOK ) 
        {
            EndDialog( hDlg, LOWORD( wParam ) );
            return TRUE;
        }
        break;

    case WM_CLOSE :
        EndDialog( hDlg, 0 );
        break;
    }
    return FALSE;
}

int WINAPI WinMain ( HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow )
{                                                                                              
    hInst = hInstance;
    DialogBoxA( hInstance, MAKEINTRESOURCE( DLG_KEYGEN ), 0, DlgKg );                                    
    return 0;                                                                                     
}                                                                                              
