//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by keygen.rc
//
#define BT_GENERATE                     3
#define DLG_ABOUT                       103
#define DLG_KEYGEN                      129
#define IDI_KGICON                      132
#define IDB_LOGO                        133
#define ED_NAME                         1000
#define ED_SERIAL                       1001
#define BT_ABOUT                        1002
#define BT_EXIT                         1003
#define STATIC_ABOUT                    1004
#define STATIC_ABOUT_CAPTION            1005
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
