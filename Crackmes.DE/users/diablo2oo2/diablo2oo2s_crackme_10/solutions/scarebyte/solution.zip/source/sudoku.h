#ifndef SUDOKU_H
#define SUDOKU_H

#include <stdio.h>

#define DIM   4
#define SIZE  (DIM*DIM)
#define EMPTY 0x10

// solve a sudoku with the dimension DIM
// stop backtracking if first solution found
void solve( int x, int y, int *f );

// clear board and fill diagonal
// sizeof( diagonal ) must be SIZE
void fill_board( unsigned char *diagonal );

// print the board
void print_board( void );

// write board back to buffer
// sizeof( out ) must be SIZE*SIZE
void get_board( unsigned char *out );




#endif
