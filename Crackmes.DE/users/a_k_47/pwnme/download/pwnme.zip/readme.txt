Generate a valid keyfile
