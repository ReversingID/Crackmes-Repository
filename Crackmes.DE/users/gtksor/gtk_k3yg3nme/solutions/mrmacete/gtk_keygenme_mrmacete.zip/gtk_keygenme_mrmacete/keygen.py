def keygen(username):
	serial = 0

	for i in xrange(len(username)):
		counter = 0 
		mul_accum = 1
		a = ord(username[i])

		for j in xrange(i+2):
			c = a * counter
			b = a * mul_accum

			mul_accum = b & 0xffffffff
			counter = c + ((b & 0xffffffff00000000) >> 32)


		serial += mul_accum
		serial += counter << 32

	print "Username: " + username
	print "Password: " + str(serial)


if __name__ == "__main__":
	keygen("porcodio")
