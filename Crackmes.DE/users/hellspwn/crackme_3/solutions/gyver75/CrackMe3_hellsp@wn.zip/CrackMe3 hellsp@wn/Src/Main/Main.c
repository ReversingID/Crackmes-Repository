#define WIN32_LEAN_AND_MEAN
#define MaxNameLengh 20
#define RegCodeLengh 18

#include <windows.h>
#include <commctrl.h>
#include "resource.h"

static HINSTANCE hInst;

static char NameBuffer[MaxNameLengh], RegCodeBuffer[RegCodeLengh];
static  UINT NameLengh;

void GenSerial(void){

      DWORD Result = 0, Init = (NameBuffer[0]%2)?NameBuffer[0]:NameBuffer[0]+1;
		     
      for ( int i=0; i<NameLengh; i++)
     		Result = Result+(((NameBuffer[i]*(i+1))^(i +1))+((NameBuffer[NameLengh-i-2]*(i+1))^(NameLengh-i-1))+
			       ((0x4C4F4C*NameLengh)^(i+1)^(NameLengh-i-1)^NameBuffer[i])+(4*Init))*NameBuffer[i]*Init;    
      Result = Result^0x1357912;
	wsprintf(RegCodeBuffer, "%8X", Result);

      RegCodeBuffer[8] = '-'; RegCodeBuffer[13] = '-'; RegCodeBuffer[9] = '7';
	RegCodeBuffer[10] = '7'; RegCodeBuffer[11] ='0'; RegCodeBuffer[12] = 'D';

	Result = (((NameBuffer[NameLengh-1]*NameBuffer[NameLengh-3])/0x13))*2+(NameBuffer[NameLengh-2]*NameBuffer[NameLengh-2])/0x13;
	wsprintf((RegCodeBuffer+14), "%3X",Result);

}

BOOL CALLBACK DlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam){

      HICON Icon;
	HWND HandleName;
      				
	switch(uMsg){
		case WM_INITDIALOG:
			Icon = LoadIcon(hInst, MAKEINTRESOURCE(ICO));
                  SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM) Icon);
			HandleName = GetDlgItem(hDlg, IDEDITNAME);
		      PostMessage(hDlg, WM_COMMAND, ((EN_SETFOCUS<<16)+IDEDITNAME), (long int) HandleName);
			return TRUE;

		case WM_COMMAND:
			if (wParam == (EN_CHANGE<<16)+IDEDITNAME){
				NameLengh = GetDlgItemText(hDlg, IDEDITNAME, NameBuffer, MaxNameLengh);
	                   if (NameLengh<3)
					SetDlgItemText(hDlg, IDEDITREGCODE,  "Name too short... at least 3 chars!");
				 else if (NameLengh>16)
     					SetDlgItemText(hDlg, IDEDITREGCODE,  "Name too long... almost 15 chars!");
       	            else{
     					GenSerial();
			       	SetDlgItemText(hDlg, IDEDITREGCODE, RegCodeBuffer);
		                  }
			       }
			return TRUE;
		
				
		case WM_CLOSE:
                         EndDialog(hDlg,0);
				 return TRUE;
			
						
           default:
			return FALSE;
		
     }
}

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInst, LPSTR lpCmdLine, int nCmdShow){
	
     	hInst = hInstance;
	InitCommonControls();
	DialogBox(hInst, MAKEINTRESOURCE(IDD_DIALOG),NULL,DlgProc);
	return 0; 
}


     





                                          
      

		
	
