#include <stdio.h>
#include <stdlib.h>

int main(void){

	unsigned int Vect1[] = {0x454E08, 0X454C24, 0X454E4C, 0X454C6C, 0X454EE0, 0X454E94};
	unsigned int Temp;
	for(int i=0;i<6;i++)
		for(int j=1;j<16;j++){
			Temp = ( j*j*j )^Vect1[i];
			if ((Temp<0x4548DB) && (Temp>0x454875))
				printf(" New Offset is:%X, from Array[%X] and index %X\n",Temp, i, j);
		}
      system("PAUSE");
	return 0;
}
