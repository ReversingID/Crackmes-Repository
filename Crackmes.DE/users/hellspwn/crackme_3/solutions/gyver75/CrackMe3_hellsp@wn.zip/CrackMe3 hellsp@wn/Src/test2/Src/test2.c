#define WIN32_LEAN_AND_MEAN

#include <windows.h>

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInst, LPSTR lpCmdLine, int nCmdShow){

	HANDLE hFileRead, hMapFile;
	LPVOID BasePointer;
	DWORD NewOffset, FirstDword2Decrypt;
	char Buffer[0x100];

	hFileRead = CreateFile("CrackMe3.exe", GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	 hMapFile = CreateFileMapping(hFileRead, NULL, PAGE_READONLY, 0, 0, NULL);
	BasePointer = MapViewOfFile(hMapFile, FILE_MAP_READ, 0, 0, 0);
		for (int i=1; i<0x100; i++){
       		NewOffset = i* i* i ^ 0x5CFEDF;
                  // 1� condition...
	      	if ((NewOffset>0x450000) && (NewOffset<0x460000)){
                         //Raw displacement = Offset - BaseImage - VirtualAddress + Raw Address;
                        NewOffset = NewOffset - 0x400C00;
                        //New Raw Offset = NewBaseImage + Raw displacement; then deferencing the pointer,
                        //i obtain the Dword encrypted... 
                        FirstDword2Decrypt = * (LPDWORD)((DWORD) BasePointer + NewOffset);
                        // 2� condition...
                        if (((i* i* i)^0X57A9357^FirstDword2Decrypt) == 0x458C20A1) {
      			wsprintf(Buffer,"%1X",i);  
       			MessageBox(NULL, Buffer, "Number found",MB_OK);
			      }
		      }
	      }
      UnmapViewOfFile((LPCVOID) BasePointer);
	CloseHandle(hMapFile);
	CloseHandle(hFileRead);
	return 0;
}


