
The crackme.exe checks the passphrase string (It is a random sequence of characters from www.random.com and it is fully stored, i.e. no one way hashes).
If the input is correct it outputs 'correct' otherwise it outputs 'incorrect' :-)

The goal is to recover the passphrase.

Rules:
bruteforce - sure :-)
patching - sure :-)


As a proof here is the sha256 of the passphrase:
b0639646fea2fc8006e92c48a7657c0481bbc1977f331953dc4ac3150137230a


(The sha256 has been generated and validated by :
http://jssha.sourceforge.net/
http://www.bichlmeier.info/sha256.html 
)


