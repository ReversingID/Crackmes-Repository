////////////////////////////////////////////////////////////
// KeygenMe2 by Reverend // HTB
// Keygen by jB
// Feb. 12, 2007
//
// Expansions of commmon functions in a virtual machine
//
// http://jardinezchezjb.free.fr / resrever@gmail.com
////////////////////////////////////////////////////////////

#include "all.h"
#define _USE_MATH_DEFINES
#include <math.h>
#include <stdio.h>

int getNbOnes(unsigned char *str)
{
	int nbOnes = 0;
	int i, j;
	for(i = 0; i < 4; i++)
	{
		DWORD c = *((DWORD *)str + i);
		for(j = 0; j < 32; j++)
		{
			if(c & 1) nbOnes++;
			c >>= 1;
		}
	}
	return nbOnes;
}

DWORD WINAPI GenererSerial(HWND hwnd)
{
	TCHAR name[MAX_NAME];
	TCHAR name2[16];
	TCHAR serial1[MAX_SERIAL1];
	TCHAR serial2[MAX_SERIAL2];
	DWORD s1_hex[4];
	DWORD n;
	int i;
	float name_sin, name_exp;
	float s2[8];
	DWORD *s2_hex;
	int len;
	
	len = GetDlgItemText(hwnd, IDC_NAME, name, MAX_NAME);
	if(len < MIN_NAME)
	{
		SetDlgItemText(hwnd, IDC_SERIAL,"Please enter a longer name...");
		return FALSE;
	}
	// Pad name until it has 16 chars
	for(i = 0; i < 16; i++)
		name2[i] = name[i % len];

	// Compute s1
	n = *(DWORD *)name2;
	n = ((n << 20) >> 21 ) << 1;
	s1_hex[0] = 2 * n;

	n = *((DWORD *)name2 + 1);
	n = ((n << 20) >> 21 ) << 1;
	s1_hex[1] = 4 * n + 8;

	n = *((DWORD *)name2 + 2);
	n = ((n << 21) >> 22) << 1;
	s1_hex[2] = 6 * n + 26;

	n = *((DWORD *)name2 + 3);
	n = ((n << 22) >> 23) << 1;
	s1_hex[3] = 8 * n + 52;

	// Compute name_exp and name_sin
	name_exp = (float)floor(exp(getNbOnes(name2) % 10 + 1));
	n = *(DWORD *)name2 % 360;
	name_sin = (float)floor(1000 * sin(n * M_PI / 180.));

	// Compute s2. 6 values are random
	for(i  = 0; i < 8; i++)
		s2[i] = rand() + (float)rand() / RAND_MAX;

	if(name_sin < 0) name_sin += 0.01f;
	if(name_exp < 0) name_exp += 0.01f;	// Floating point precision correction
										// for integer conversion
	s2[0] = name_sin * s2[2] * s2[3] / s2[1];
	s2[4] = name_exp * s2[6] * s2[7] / s2[5];
	s2_hex = (DWORD *)s2;

	for(i = 0; i < 8; i++)
		sprintf(serial1 + i * 5, "%04X-", s1_hex[i]);
	serial1[5 * 4 - 1] = 0;
	for(i = 0; i < 8; i++)
		sprintf(serial2 + i * 9, "%08X-", s2_hex[i]);
	serial2[9 * 8 - 1] = 0;

	SetDlgItemText(hwnd, IDC_SERIAL1, serial1);
	SetDlgItemText(hwnd, IDC_SERIAL2, serial2);
	return TRUE;
}
