#include "all.h"

DWORD WINAPI GenererSerial(HWND hWnd);
HINSTANCE hInst;

INT_PTR CALLBACK DlgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_CLOSE:
		EndDialog(hWnd, 0);
		break;

	case WM_INITDIALOG:
		srand(GetTickCount());
		SetWindowText(hWnd, PROGNAME " - Keygen");
		SetDlgItemText(hWnd, IDC_NAME, "jB");
		SendDlgItemMessage(hWnd, IDC_NAME, EM_LIMITTEXT, MAX_NAME, 0);
		SetFocus(GetDlgItem(hWnd, IDC_NAME));
		return FALSE;

	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDC_NAME:
			if(HIWORD(wParam) == EN_CHANGE)
				GenererSerial(hWnd);
			break;
		case IDC_GENERATE:
			GenererSerial(hWnd);
			break;

		case IDC_EXIT:
			EndDialog(hWnd, 0);
			break;
		}
	default:
		return FALSE;
	}
	return TRUE;
}


int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{
	hInstance = GetModuleHandle(NULL);
	hInst = hInstance;
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_KEYGEN), NULL, (DLGPROC)DlgProc, (LPARAM)NULL);
 	return 0;
}
