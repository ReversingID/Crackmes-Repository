#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <stdlib.h>
#include "rsrc/resource.h"

#define PROGNAME "KeygenMe2 by Reverend // HTB"
#define MIN_NAME 1
#define MAX_NAME 100
#define MAX_SERIAL1 100
#define MAX_SERIAL2 100

