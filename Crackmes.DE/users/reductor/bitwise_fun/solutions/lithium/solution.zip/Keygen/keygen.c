#include <windows.h>
#include <strsafe.h>
#include "resource.h"

#define MAX_NAME 80
#define MAX_SERIAL 7

BOOL CALLBACK genProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam);
BOOL isValidSerial(LPSTR sName, LPSTR sSerial);
LPSTR numToString(int num);
LPSTR numToStringDisp(int num);

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	DialogBox(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_DLG1), NULL, genProc);
	return 0;
}

BOOL CALLBACK genProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam)
{
	LPSTR name;	
	UINT bytesRead, i = 0;

	name = GlobalAlloc(GPTR, MAX_NAME);

	switch(Message)
	{
		case WM_INITDIALOG:
			return TRUE;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case IDC_BTN1:
					if ((bytesRead = GetDlgItemText(hwnd, IDC_EDT1, name, MAX_NAME-1)) == 0)
					{
						MessageBox(hwnd, "Enter a fucking name!", "Moron", MB_OK | MB_ICONEXCLAMATION);
						return TRUE;
					}
					name[bytesRead] = 0xA;

					while (!isValidSerial(name, numToString(i))) {
						i++;
						if (i > 100000) {
							SetDlgItemText(hwnd, IDC_EDT2, "Sorry, not found!");
							return FALSE;
						}
					}

					SetDlgItemText(hwnd, IDC_EDT2, numToStringDisp(i));
					break;
				default:
					break;
			}
			break;

		case WM_CLOSE:
			EndDialog(hwnd, 0);
			return TRUE;

		default:
			return FALSE;
	}
	return TRUE;
}


LPSTR numToString(int num) {
	LPSTR serial = GlobalAlloc(GPTR, MAX_SERIAL);
	StringCchPrintf(serial, MAX_SERIAL-1, "%d%c", num, 0xA);
	return serial;
}

LPSTR numToStringDisp(int num) {
	LPSTR serial = GlobalAlloc(GPTR, MAX_SERIAL);
	StringCchPrintf(serial, MAX_SERIAL-1, "%d", num);
	return serial;
}

BOOL isValidSerial(LPSTR sName, LPSTR sSerial) {
	int dword_4077F0; // weak
	int dword_4077F4; // weak
	int dword_4077F8; // weak

  	int result; // eax@9
  	char v1; // al@2
  	char v2; // al@5
  	int v3; // [sp+6Ch] [bp-Ch]@1
  	int v4; // [sp+70h] [bp-8h]@1
  	int v5; // [sp+68h] [bp-10h]@1
  	char v6; // [sp+74h] [bp-4h]@2
  	int v7; // [sp+64h] [bp-14h]@16
  	unsigned int v8; // [sp+60h] [bp-18h]@16
  	unsigned int v9; // [sp+5Ch] [bp-1Ch]@19
  	int v10; // [sp+58h] [bp-20h]@19
  	signed int v11; // [sp+4Ch] [bp-2Ch]@33
  	signed int v12; // [sp+40h] [bp-38h]@33
  	signed int v13; // [sp+3Ch] [bp-3Ch]@33
  	int v14; // [sp+50h] [bp-28h]@35
  	int v15; // [sp+48h] [bp-30h]@35
  	int v16; // [sp+54h] [bp-24h]@39
  	unsigned int v17; // [sp+44h] [bp-34h]@39
  	unsigned int v18; // [sp+38h] [bp-40h]@51
  	unsigned int v19; // [sp+34h] [bp-44h]@51
  	int v20; // [sp+30h] [bp-48h]@51
  	int v21; // [sp+24h] [bp-54h]@54
  	unsigned int v22; // [sp+2Ch] [bp-4Ch]@54
  	int v23; // [sp+28h] [bp-50h]@54
  	unsigned int v24; // [sp+20h] [bp-58h]@69
  	unsigned int v25; // [sp+1Ch] [bp-5Ch]@69
  	unsigned int v26; // [sp+18h] [bp-60h]@75
  	unsigned int v27; // [sp+14h] [bp-64h]@75
  	int v28; // [sp+10h] [bp-68h]@75
  	unsigned int v29; // [sp+Ch] [bp-6Ch]@84
  	unsigned int v30; // [sp+8h] [bp-70h]@84
  	int v31; // [sp+4h] [bp-74h]@89
  	unsigned int v32; // [sp+0h] [bp-78h]@89

	int index0 = 0;
	int index1 = 0;

  	//puts("Please enter your username:");
  	v3 = 0;
  	v4 = 0;
  	v5 = 0;
  	do
  	{
    		v1 = sName[index0];
    		v6 = v1;
    		v3 += v1;
		index0++;
  	} while ( v1 != 10 && v6 );

  	//puts("Please enter your serial(only numbers):");
  	do
  	{
 		v2 = sSerial[index1];
    		v6 = v2;
    		if ( (v2 < 48 || v6 > 57) && v6 && v6 != 10 )
			return FALSE;
      			//return puts("Invalid Serial, it can only contain numbers");
    		if ( v6 != 10 )
    		{
      			if ( v6 )
      			{
        			v4 = v4 + v6 - 48;
        			v4 *= 10;
      			}
    		}

		index1++;
  	} while ( v6 != 10 && v6 && (unsigned int)v4 < 0xFFFF );

  	v5 = v4;
  	dword_4077F8 = 3;
  	dword_4077F8 *= 51;
  	dword_4077F8 += 102;
  	dword_4077F0 = dword_4077F8;
  	dword_4077F8 = 255 * dword_4077F0;
  	dword_4077F8 += 127;
  	dword_4077F4 = dword_4077F8;
  	dword_4077F8 = dword_4077F4 + 384;
  	++dword_4077F0;
  	dword_4077F0 <<= 7;
  	dword_4077F4 += 375;
  	dword_4077F4 += 10;
  	v7 = 0;
  	v8 = v4;

  	while ( v8 >= 0xA )
  	{
    		v8 -= 10;
    		++v7;
  	}

  	v4 = v7;
  	v9 = 0;
  	v10 = 1;

  	while ( v10 < (unsigned int)dword_4077F8 )
  	{
    		if ( (v10 & v4) != v10 || (v10 & 0x3B1) != v10 )
    		{
      			if ( (v10 & v4) != v10 && (v10 & 0x3B1) != v10 || (v10 & v9) != v10 )
      			{
        			if ( (v10 & v4) == v10 || (v10 & 0x3B1) == v10 )
          			v9 |= v10;
      			}
      			else
        			v9 ^= v10 | 2 * v10;
    		}
    		else
      			v9 |= 2 * v10;
		v10 *= 2;
  	}

  	v4 = v9;

  	if ( v9 >= 0x36F )
  	{
    		v11 = 879;
    		v12 = v4;
    		v13 = 0;
  	}

  	else
  	{
    		v11 = v4;
    		v12 = 879;
    		v13 = 1;
  	}

  	v14 = v12;
  	v15 = 1;

  	while ( v15 < (unsigned int)dword_4077F8 )
  	{
    		if ( (v15 & v11) != v15 || (v15 & v14) == v15 )
    		{
      			if ( (v15 & v11) == v15 )
      			{
        			if ( (v15 & v14) == v15 )
          				v14 ^= v15;
      			}
    		}
    		else
    		{
      			v16 = 0;
      			v17 = v15;
      			while ( v17 < dword_4077F8 )
      			{
        			v16 |= v17;
        			if ( v14 & v17 )
        			{
          				v14 ^= v16;
          				break;
        			}
        			v17 *= 2;
      			}
    		}
    		v15 *= 2;
  	}

  	if ( v13 )
    		v14 = -v14;

  	v4 = v14;
  	dword_4077F8 -= 32768;
  	dword_4077F0 = dword_4077F8;
  	dword_4077F4 = dword_4077F8;
  	dword_4077F4 += 32768;
  	++dword_4077F4;
  	dword_4077F8 = dword_4077F4 - 1;
  	v18 = 0;
  	v19 = 1;
  	v20 = 0;

  	while ( v19 < dword_4077F8 )
  	{
    		if ( v19 & 4 )
    		{
      			v21 = v4 << v20;
      			v22 = 0;
      			v23 = 1;
      			while ( v23 < (unsigned int)dword_4077F8 )
      			{
        			if ( (v23 & v18) != v23 || (v23 & v21) != v23 )
        			{
          				if ( (v23 & v18) != v23 && (v23 & v21) != v23 || (v23 & v22) != v23 )
          				{
            					if ( (v23 & v18) == v23 || (v23 & v21) == v23 )
              					v22 |= v23;
          				}
          				else
            					v22 ^= v23 | 2 * v23;
        			}
        			else
          				v22 |= 2 * v23;
        			v23 *= 2;
      			}
      			v18 = v22;
    		}
    		v19 *= 2;
    		++v20;
  	}

  	v24 = v18;
  	v25 = 0;

  	while ( v25 < 2 )
  	{
    		if ( v24 & 1 )
    		{
      			v24 >>= 1;
      			v24 |= dword_4077F0;
    		}
    		else
      			v24 >>= 1;
    		++v25;
  	}

  	v4 = v24;
  	dword_4077F8 *= 4;
  	dword_4077F8 = (unsigned int)dword_4077F8 >> 2;
  	dword_4077F8 -= 32768;
  	dword_4077F0 = dword_4077F8;
  	dword_4077F4 = dword_4077F8;
  	dword_4077F4 += 32768;
  	++dword_4077F4;
  	dword_4077F8 = dword_4077F4 - 1;
  	v26 = 0;
  	v27 = 1;
  	v28 = 0;

  	while ( v27 < dword_4077F8 )
  	{
    		if ( !(v27 & 0x2A) || !(v27 & v4) )
    		{
      			if ( v27 & 0x2A || v27 & v4 )
        			v26 |= v27;
    		}
    		v27 *= 2;
    		++v28;
  	}

  	v29 = v26;
  	v30 = 0;

  	while ( v30 < 1 )
  	{
    		v29 *= 2;
    		if ( dword_4077F8 & v29 )
      			v29 ^= dword_4077F4;
    		++v30;
  	}

  	dword_4077F8 = 3;
  	dword_4077F8 *= 51;
  	dword_4077F8 += 102;
  	dword_4077F0 = dword_4077F8;
  	dword_4077F8 = 255 * dword_4077F0;
  	dword_4077F8 += 127;
  	dword_4077F4 = dword_4077F8;
  	dword_4077F8 = dword_4077F4 + 384;
  	++dword_4077F0;
  	dword_4077F0 <<= 7;
  	dword_4077F4 += 375;
  	dword_4077F4 += 10;
  	v31 = 0;
  	v32 = v29;

  	while ( v32 >= 2 )
  	{
    		v32 -= 2;
    		++v31;
  	}

  	v4 = v31;
  	if ( v31 == v3 )
		return TRUE;
    		//result = puts("Well done your serial is correct\n");
  	else
		return FALSE;
    		//result = puts("Invalid Serial");
}
