=== FILE INFO ===

   PatchMe.exe

Size : 5.50 KB (5,632 bytes)
CRC32 : CB138C41

=== RULES ===

ok heres what you can do

patch it
make a loader for it
hex edit whatever!

Just change the message to www.crackme.de
this is really easy so if ya do it dont think your good or anything :) j/k