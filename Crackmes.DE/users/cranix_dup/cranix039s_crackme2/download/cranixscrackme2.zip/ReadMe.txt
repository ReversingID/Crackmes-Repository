Ok this is what u need to do!

1:Make a keygen! "cause the serial is different for every computer"

2:tell how you did it!

3:tell what kind of protection is in it! or try to :)

4:and have fun cracking!


---------File Info------------

exe name = CrackMe.exe
exe size = 40.0 KB / 40,960 Bytes
exe version = 9.1.0.12 / 9.01.0012
exe crc32 = 68164A18

		    -CRANIX-