﻿using System;
using System.Windows.Forms;

namespace CraniXcc14_keygen
{
    public partial class frmKeygen : Form
    {
        public frmKeygen()
        {
            InitializeComponent();
        }

        private void pbExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void pbGenerate_Click(object sender, EventArgs e)
        {
            dfSerial.Text = ((1337 * Convert.ToInt32(dfTime.Text)) - 7273099).ToString();
        }
    }
}
