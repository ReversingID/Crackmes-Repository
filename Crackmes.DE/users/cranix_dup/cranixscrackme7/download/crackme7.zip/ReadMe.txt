Cranix's CrackMe7

CrackMe7.exe -> Loads technics.dat witch has a 6 digit encrypted (xor) date in it like

march 1932 would be 031932 try to decrypt technics.dat and find out the date i put in it

then when you have done that set your system date and year to the one that is in technics.dat

the one that i encrypted and put there!

good luck trying to crack this one and have fun!

-CraniX-