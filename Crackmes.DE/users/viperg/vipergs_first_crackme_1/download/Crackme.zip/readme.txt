The Rules!

There are no rules. Hackers are governed under no rules, so this training exercise has no rules. 

You can hack this any way you like. 

However, extra kudos if you make a portable hack OR if you just figure out what the pass is to get through (super simple pass)

This exe was compiled in release mode in visual studio 6.

it's a command console application, but requires windows functions. 

There is no crypto, no packing or compression. The asm is open to whatever disam you can get to work/partial to.

ViperG
www.crackme.des