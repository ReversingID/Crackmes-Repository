Hallo everybody,

 This is a nice crack me for newbeys. 
 There is not much protection in it, but 
 there are few small tricks.
 It would be very interesting to know your 
 solutions and foughts about it.
 Progy is in Lithuanian :), so you will not be
 able to  understant everything. BUT when 
 you will enter  "the right" name and serial 
 you will see  "Nulauzei !". 
 Good luck newbeys!
 
 Please send keygen or any tutorial to:
 zeronetus@yahoo.com 
 www.BigBugGroup.cjb.net