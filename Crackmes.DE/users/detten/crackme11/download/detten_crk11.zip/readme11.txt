GOAL : SAVE HUMANITY (start firewall) without patching.
	That's all :)

DIF  : 5/10

NOTE : This crackme is half crackme, half reversme :) 
Just cracking some passwords won't be enough.

Enjoy

Detten

mail answers, questions, comments to

Detn@hotmail.com

Find more crackmes @
www.biw-reversing.cjb.net