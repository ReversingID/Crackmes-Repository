Another crackme release by BiW Reversing.

A graphical linux binary using GTKmm.
Beware of the snakes in the tunnels though ;)

Solution : Write a valid keygen.

Have fun :)


www.reversing.be
