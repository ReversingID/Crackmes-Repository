

ReWrit's Crackme #4
--------------------
This is my first C# crackme. its extremly simple
so everyone should be able to crack it.

Serial should only be numbers, otherwise you might
get an error.


+--Goals------------------------------------------------+
| 							|
| For Gold:   Remove the NAG and Create a keygen. 	|
| For Silver: Remove the NAG and Create a self-keygen.	|
| For Bronze: Remove the NAG and Just give me a 	|
|             Username and a Serial.			|
+-------------------------------------------------------+


Name:		ReWrit's Crackme #4
Difficulty:	1 - Very easy, for newbies
Platform:	Windows
Language:	.NET