#include "iostream.h"

int key(int n)
{
	n=n*23/3+66333;
	n=n*431*203;
	return n*n;
}

int main()
{
	int n;
	for (n=0;n<10;n++)
	{
		cout << n << " " << key(n) << "\n";
	}
}
