#include <stdio.h>

int main()
{
    int num = 0;
    char name[11];
    
    printf("Enter username: ");
    
    scanf("%10s", name);

    num = (strlen(name) * 0x17 / 3) + 0x1031d;
    num = (num * 0x155c5 * num * 0x155c5);

    printf("Serial: %d", num);
    getch();

    return 0;    
}
