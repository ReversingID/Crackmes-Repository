Ok this is my first crackme.
and its not that hard so its perfect for newbies :)


Rules:
i dont care how you do it, just create a 
keygen or selfkeygen. 