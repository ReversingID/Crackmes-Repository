
ReWrit's Crackme #5
...

feels like .NET crackmes aint that fun
so im gonna stick to C++.

tho im not that good programer so if
someone wanna help me a little to write a
crackme, or we could write one together.
just send me a msg :)



-------------------------------------------
  Rules:
* Gold:   Make a keygen
* Silver: Make a Self-Keygen
* Bronze: Patch it so it allways display
          Good Boy message.
* Upload a solution.
-------------------------------------------

Name:		ReWrit's Crackme #5
Difficulty:	1 - Very easy, for newbies
Platform:	Windows
Language:	C/C++