void MakeSerial(char *name, char *serial)
{
	unsigned long pass;

	pass = strlen(name);
	pass *= 3;
	pass <<= 2;
	pass = (unsigned long)pow(pass, 3);
	pass += 23;
	pass += pass * 708224;

	ultoa(pass, serial, 10);
}