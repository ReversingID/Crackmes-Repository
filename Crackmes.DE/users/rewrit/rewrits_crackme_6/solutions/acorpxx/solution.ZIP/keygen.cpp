//---------------------------------------------------------------------------

#pragma hdrstop
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//---------------------------------------------------------------------------

#pragma argsused

char keychrs[37]="-+xX0123456789abcdef0123456789ABCDEF";

int calcKey(char * str, int a, int b) {
 int val = 0;
 int reg = b;
  for(int i = 0; str[i]; i++) {
    val  = (val*reg)+str[i];
    reg *= a;
  }
  val &= 0x7fffffff;
 return val;
}

char * calcPart(int key) {
 int i = 0;
 int edx = 1;
 int act = key;
 char * val;
   val = (char *) malloc(20);
   while (edx) {
     edx = (long long) act * 0xcccccccd >> 32;
     edx >>= 3;
     act -= (edx*5)*2;
     val[i++] = keychrs[act+4];
     act = edx;
   }
   val[i++] = 0;
 return val;
}

void printRev(char * str) {
 int len = strlen(str);
   for (int i = len-1; i >= 0; i--)
     printf("%c", str[i]);
}

int main(int argc, char* argv[])
{
int key1;
int key2;
char * user;
char * str1;
char * str2;
  //Getting Username
  user = (char *) malloc(50);
  printf("Username: ");
  gets(user);
  //Calculating Keys
  key1 = calcKey(user, 0x17A, 0x289);
  key2 = calcKey(user, 0x2B9, 0x155);
  str1 = calcPart(key1);
  str2 = calcPart(key2);
  //Printing Result
  printf("Password: ");
  printf("ReWrit-");
  printRev(str1);
  printRev(str2);
  printf("-Swe");

getch();
return 0;
}
//---------------------------------------------------------------------------
