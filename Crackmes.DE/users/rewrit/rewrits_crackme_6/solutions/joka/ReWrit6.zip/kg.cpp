#include "stdio.h"

int gen(char *str, int len, int a1, int a2)
{
	int a3, a4, ebx, at;
	a3=0;
	a4=0;
	while (a4 < len)
	{
		ebx=a3*a2;
		at=str[a4];
		a3=ebx+at;
		a2=a2*a1;
		a4++;
	}
	return a3 & 0x7fffffff;
}

int main()
{
	int i, l;
	char buf[101];
	printf("Enter username (100 chars max.):");
	gets(buf);
	buf[100]=0;
	for (i=0;i<=100;i++)
		if (buf[i]==0)
		{
			l=i;
			i=100;
		};
	printf("ReWrit-%d%d-Swe",gen(buf,l,0x17a,0x289),gen(buf,l,0x2b9,0x155));
}
