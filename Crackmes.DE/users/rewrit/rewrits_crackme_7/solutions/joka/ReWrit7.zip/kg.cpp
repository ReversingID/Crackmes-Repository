#include "stdio.h"
#include "stdlib.h"

char *str1[10];
char *str2[10];

void initstr1str2()
{
	str1[0]="JQ";
	str1[1]="ZA";
	str1[2]="YB";
	str1[3]="XC";
	str1[4]="WD";
	str1[5]="VE";
	str1[6]="UF";
	str1[7]="TG";
	str1[8]="SH";
	str1[9]="UFRI";
	str2[0]="GAJ";
	str2[1]="QJA";
	str2[2]="IRUF";
	str2[3]="HSC";
	str2[4]="GTD";
	str2[5]="FUE";
	str2[6]="VEU";
	str2[7]="WDT";
	str2[8]="XCS";
	str2[9]="KBFU";
}

int leng(unsigned char *str)
{
	int i=0;
	while (str[i]!=0)
	{
		i++;
	}
	return i;
}

unsigned int ser2(unsigned char *name)
{
	unsigned int c=0, d=0;
	while (name[c]!=0)
	{
		d=d+name[c];
		c++;
	}
	return 40000000+(((d + 353580822) % 1024)*4194304 + 119 ) % 9995599;
}

void strcp(char *s1, char*s2)
{
	int i=0;
	while (s2[i]!=0)
	{
		s1[i]=s2[i];
		i++;
	}
	s1[i]=0;
}

void ser3(unsigned char *name, unsigned char* ser)
{
	//2d8
	//name
	//     33c,340,290, 2e0,2dc,344,348,34c
	int a, b, c, d, e, f, g, h;
	int i, j;
	char *k;
	unsigned char buf[20];
	//                             2e4
	unsigned int l;
	//     45c,460
	int m, n;
	a=leng(name);
	b=0;
	c=0;
	d=0;
	e=0;
	while(b<=1)
	{
		f=0;
		while(f<a)
		{
			c=c+name[f];
			d=d+c*c;
			g=0;
			while (g<a)
			{
				//d=(e/5)*c-a+d+55;
				d=d-a+55; // e==0 here
				h=0;
				while (a+3>h)
				{
					d=d ^ (d*d+c);
					h++;
				}
				g++;
			}
			d=4*d;
			f++;
		}
		b++;
	}
	sprintf((char *)buf,"%u",d);
	initstr1str2();
	i=leng(buf);
	ser[0]=0;
	for (j=0;j<i;j++)
	{
		k=(char *) &(ser[leng(ser)]);
		strcp(k,str1[buf[j]-48]);
	}

	g=leng(ser);
	f=0;
	l=0;
	e=0;
	while (f<=1)
	{
		b=0;
		while(b<g)
		{
			e=e+ser[b];
			l=l+c*c;
			m=0;
			while(m<g)
			{
				l=(e/5)*c-a+l+55;
				n=0;
				while (g+3 > n)
				{
					l=l ^ (d*d+c);
					n++;
				}
				m++;
			}
			l=l+3*d;
			b++;
		}
		f++;
	}
	if (l > 1111111111) //l must be unsigned int, because of comparison by JBE
	{
		l=l-39;
	}
	sprintf((char *)buf,"%u",l);
	i=leng(buf);
	ser[0]=0;
	for (j=0;j<i;j++)
	{
		k=(char *) &(ser[leng(ser)]);
		strcp(k,str2[buf[j]-48]);
	}
	i=leng(ser);
	for (j=0;j<i;j++)
	{
		ser[j]=ser[j]+2;
	}
}

int main()
{
	unsigned char name[11];
	unsigned char ser[40];
	printf("Part I serial is 3951278819\n");
	printf("Enter name for part II (10 chars max.): ");
	gets((char *)name);
	printf("Part II serial for your name is %d\n",ser2(name));
	printf("Enter name for part III (10 chars max.): ");
	gets((char *)name);
	ser3(name,ser);
	printf("Part III serial for your name is %s\n",ser);
	system("pause");
}
