
ReWrit's Crackme #8

Kinda easy crackme...
you just have to patch it so it shows
the correct password in the (gray)textbox
and remove the nag... so the goals are:

Goals:
--------------------------------------------
+ Remove the nag.
+ Patch it so it shows the correct password.
--------------------------------------------

Name:		ReWrit's Crackme #8
Difficulty:     2 - Needs a little brain (or luck)
Platform:	Windows
Language:	.NET