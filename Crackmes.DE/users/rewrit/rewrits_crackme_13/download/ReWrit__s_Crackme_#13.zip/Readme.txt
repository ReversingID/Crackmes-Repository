
ReWrit's Crackme #13
--------------------
This crackme feelt a little different from
my other ones... i dont know why but it
would be nice if your solution tells me what
this crackme does =)
Its really easy to fish a password but that
not the goal here.

Rules / Goals:
--------------------------------------
* Create a keygen and write solution
* No Patching(includes self-keygen)
--------------------------------------

Name:		ReWrit's Crackme #13
Difficulty:	1 - Very easy, for newbies
Platform:	Windows
Language:	C/C++