I just wanted to say that I did�nt show the solution for 
all names because it would take a bit too long to show. 

But I think it�s all clear enough to follow.

Thanks to all reversers at crackmes.de!

/* main */