/*************************************************************************

 Filename:		keygen.c
 Purpose:		Keygen for S\ashZer0 RSA-Crackme
 Author:		figugegl
 Version:		1.0
 Date:			26.1.2003

*************************************************************************/


/*------------------------------------------------------------------------
	Include files
------------------------------------------------------------------------*/
#include <windows.h>
#include "keygen.h"


/*------------------------------------------------------------------------
	Prototypes
------------------------------------------------------------------------*/
LRESULT CALLBACK MainDlgProc	(HWND, UINT, WPARAM, LPARAM) ;


/*------------------------------------------------------------------------
	Type definitions
------------------------------------------------------------------------*/


/*------------------------------------------------------------------------
	Global variables
------------------------------------------------------------------------*/


/*------------------------------------------------------------------------
 Procedure:     WinMain
 Purpose:       Application entry point. Registers a class of the same
                type than the dialog class,calls DialogBox and then exits
 Input:         Standard
 Output:        None
 Errors:        None
------------------------------------------------------------------------*/
int WINAPI WinMain (HINSTANCE hInst, HINSTANCE hPrevInst, PSTR szCmdLine, int CmdShow)
{
	static TCHAR	szAppName[] = TEXT ("keygen") ;
	WNDCLASS		wc ;

	memset (&wc, 0, sizeof (wc));				// empty structure wc

	wc.lpfnWndProc		= MainDlgProc ;			// callback procedure
	wc.cbWndExtra		= DLGWINDOWEXTRA ;
	wc.hInstance		= hInst ;
	wc.hIcon			= LoadIcon (hInst, MAKEINTRESOURCE (ICO_FIGU)) ;
	wc.hCursor			= LoadCursor (NULL, IDC_ARROW) ;
	wc.hbrBackground	= (HBRUSH) (COLOR_BTNFACE + 1) ;
	wc.lpszClassName	= szAppName ;

	if (!RegisterClass (&wc))
		return 0;

	return DialogBoxParamA (hInst, MAKEINTRESOURCE (DLG_MAIN), NULL, (DLGPROC) MainDlgProc, 0);
}


/*------------------------------------------------------------------------
 Procedure:     MakeKeyFile
 Purpose:       Make a valid keyfile
 Input:         hWnd:	Handle of the Dialogbox
 Output:        None
 Errors:        None
------------------------------------------------------------------------*/
void MakeKeyFile (HWND hWnd)
{
	HANDLE        hFile;
	unsigned long j, ulRsaChar;
	int	          i, iStrLen, iNameLen, dwResult;
	unsigned char szName[32], szTemp[8];
	unsigned char szKeyString[0x200] = "";
	char          szFileName []      = "i.am.a.     .key";

	// get name and check length
	iNameLen = GetDlgItemTextA (hWnd, EDF_NAME, szName, 32);
	if (iNameLen == 0)
		return;

	// first part of keyfile string
	// f[0..1] = d (private exponent)
	// RSA-15: n = 64BBh -> p = 6Bh; q = F1h; d = 55C1h
	szKeyString[0] = 0x55;
	szKeyString[1] = 0xC1;

	// write name to keyfile string
	// RSA-15: n[i] = f[i] ^ d % 64BBh
	//         f[i] = n[i] ^ e % 64BBh
	//         e = 10001h
	for (iStrLen = 2, i = 0; i < iNameLen; i++)
	{
		// f[i] = n[i] ^ 10001h % 64BBh
		ulRsaChar = szName[i];
		for (j = 1; j < 65537; j++)
			ulRsaChar = (ulRsaChar * szName[i]) % 0x64BB;

		// convert to decimalstring
		wsprintfA (szTemp, "%0.6d", ulRsaChar);

		// convert to hex and append to keyfile string, i.e. "019404" --> 01h, 94h, 04h
		for (j = 0; j < 3; j++)
		{
			szKeyString[iStrLen] = ((szTemp[2*j] & 0xF) << 4) | (szTemp[2*j+1] & 0xF);
			iStrLen++;
		}
	}
	szKeyString[iStrLen] = 0xFF;

	// fill rest of keyfile with 0
	for (i = ++iStrLen; i < 0x1F; i++)
		szKeyString[i] = 0;

	// checksum: sum f[0xC7..0xD1] = 40Fh
	szKeyString[0xC7] = 0x45;
	for (i = 0xC8; i <= 0xD1; i++)
		szKeyString[i] = 0x61;

	// create and write keyfile
	hFile = CreateFileA (szFileName, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_HIDDEN, NULL);
	if (hFile == INVALID_HANDLE_VALUE)
	{
		MessageBoxA (hWnd, "Can't create keyfile!", "Error", MB_OK | MB_ICONERROR);
		return;
	}
	if (WriteFile (hFile, szKeyString, sizeof (szKeyString), &dwResult, NULL))
		MessageBoxA (hWnd, "Keyfile written!", "Success", MB_OK);
	else
		MessageBoxA (hWnd, "Can't write keyfile!", "Error", MB_OK | MB_ICONERROR);
	CloseHandle (hFile);
}


/*------------------------------------------------------------------------
 Procedure:     AboutDlgProc
 Purpose:       Handles the messages of the about dialog
 Input:         Standard
 Output:        TRUE if the message was processed
 Errors:        None
------------------------------------------------------------------------*/
LRESULT CALLBACK AboutDlgProc (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
     switch (uMsg)
     {
     case WM_INITDIALOG:
          return 0;

     case WM_COMMAND:
          if (LOWORD (wParam) == BUT_OK)
          {
               EndDialog (hWnd, 0) ;
               return 0;
          }
          break ;
     }
     return FALSE ;
}


/*------------------------------------------------------------------------
 Procedure:     MainDialogProc
 Purpose:       It handles all messages of the main dialog
 Input:         Standard
 Output:        TRUE if the message was processed
 Errors:        None
------------------------------------------------------------------------*/
LRESULT CALLBACK MainDlgProc (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_INITDIALOG:
		SendDlgItemMessageA (hWnd, EDF_NAME, EM_LIMITTEXT, 31, 0);
		SetDlgItemTextA (hWnd, EDF_NAME, "figugegl");
		return 0 ;

	case WM_COMMAND:
		switch (LOWORD (wParam))
		{
		case BUT_KEYFILE:		// Keyfile
			MakeKeyFile (hWnd);
	 		return 0;

		case BUT_ABOUT:			// About
			DialogBox (NULL, MAKEINTRESOURCE (DLG_ABOUT), hWnd, (DLGPROC) AboutDlgProc);
			return 0;
		}
		break;

	case WM_CLOSE:
		PostQuitMessage (0) ;
		return 0 ;
	}
	return DefWindowProc (hWnd, uMsg, wParam, lParam) ;
}

