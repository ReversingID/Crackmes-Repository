***************  BUGFIXED VERSION  *******************

Hi there,

this is my second KeygenMe.
I hope you'll enjoy. Don't become frustrated if it takes a bit longer. 
I know you can do it.

The rules are simple - actually there is only one:

#
No patching!
#
 
This is a KeygenMe and not made for patching. Patching would be way too easy.

If you want to ask something which you cannot post in the comments due to spoiling, 
just send me an email: darkelf2010@inbox.ru

Have fun!
yours Darkelf

edit: this is a bugfixed version.
tamaroth found a bug that made the KeygenMe half the fun.
This bug should be gone now.