// dhack18_kg.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "stdio.h"
#include "stdlib.h"

char name[100];
float value;
double big=100000000000, serial;

int main(int argc, char* argv[])
{
	printf("\tkeygen for d-hack's crackme 18 by bf_k23\n");
	printf("value : ");
	scanf("%f",&value);
	serial = ((((value*value) - big)+10))+2;
	printf("serial: %f (ignore everything behid decimal point)\n",serial);
	system("PAUSE");

	return 0;
}
