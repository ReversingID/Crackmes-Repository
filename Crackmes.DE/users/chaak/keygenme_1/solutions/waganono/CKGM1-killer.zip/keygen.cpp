#include "keygen.h"
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>



typedef int (* check_func)(int *,LPSTR ,int ,int);

static TCHAR charset1[13+1] = "ACEGIKMOQSUWY";
static TCHAR charset2[13+1] = "BDFHYLNPRTVXZ";

static TCHAR charset1_rot[13+1];
static TCHAR charset2_rot[13+1];

static int map[13*13] = {
    1,1,1,1,1,0,1,1,1,1,1,1,1,
    1,1,0,0,1,1,1,0,0,0,0,1,1,
    0,1,1,1,1,0,1,1,1,1,1,1,1,
    1,1,0,0,1,1,1,1,0,1,1,1,1,
    1,1,0,0,1,0,1,0,0,1,1,1,1,
    1,1,1,1,1,1,1,0,0,1,1,0,0,
    1,1,1,1,1,1,1,1,1,1,1,0,0,
    0,1,0,1,1,1,1,0,0,0,1,1,1,
    1,1,1,1,0,0,1,1,1,1,1,0,1,
    1,0,1,1,1,1,1,1,0,1,1,1,1,
    1,0,1,0,0,0,1,1,1,1,1,1,1,
    1,1,1,1,1,1,1,1,1,0,1,1,0,
    1,1,1,1,1,1,1,0,0,0,0,1,1
};

static int valid_first_position[11] = {0,1,3,4,5,6,8,9,10,11,12};

static int laby[13*13];

static int nb_pass=0;
static int cur_digit = 15;


int get_pos_charset(TCHAR ch,LPSTR charset){
    int i;

    for(i=0;i<13;i++){
        if(ch==charset[i])
            return i;
    }

    return 12;
}


int findLaby(int *laby,LPSTR part2,int x,int y);

int check_bottom(int *laby,LPSTR part2,int x,int y){
    if(((y+1)<13) && (laby[((y+1)*13) + x]==1)) {
        laby[((y+1)*13) + x] = 2;
        nb_pass++;
        if(findLaby(laby,part2,x,y+1)){
            part2[2*cur_digit] = charset1_rot[x];
            part2[(2*cur_digit--)+1] = charset2_rot[y];
            return 1;
        }
        else{
            laby[((y+1)*13) + x] = 1;
            nb_pass--;
        }
    }

    return 0;
}

int check_upper(int *laby,LPSTR part2,int x,int y){
    if(((y-1)>=0) && (laby[((y-1)*13) + x]==1)){
        laby[((y-1)*13)+x] = 2;
         nb_pass++;
        if(findLaby(laby,part2,x,y-1)){
            part2[2*cur_digit] = charset1_rot[x];
            part2[(2*cur_digit--)+1] = charset2_rot[y];
            return 1;
        }
        else{
            laby[((y-1)*13) + x] = 1;
            nb_pass--;
        }
    }

    return 0;
}


int check_right(int *laby,LPSTR part2,int x,int y){
    if(((x+1)<12) && (laby[(y*13)+x+1]==1)) {
        laby[(y*13)+x+1] = 2;
         nb_pass++;
        if(findLaby(laby,part2,x+1,y)){
            part2[2*cur_digit] = charset1_rot[x];
            part2[(2*cur_digit--)+1] = charset2_rot[y];
            return 1;
        }
        else{
            laby[(y*13)+x+1] = 1;
            nb_pass--;
        }
    }

    return 0;
}


int findLaby(int *laby,LPSTR part2,int x,int y){
    check_func findLabyDir[3] = {check_bottom,check_upper,check_right};
    check_func tmp;
    int i,rnd;

    /* Did we found a 16 case path? */
    if(nb_pass==16)
        return 1;

    /* Choose random labyrinth route */
    for(i=0;i<3;i++){
        rnd = rand()%3;
        tmp = findLabyDir[i];
        findLabyDir[i] = findLabyDir[rnd];
        findLabyDir[rnd] = tmp;
    }

    /* Navigate through labyrinth */
    if(findLabyDir[0](laby,part2,x,y))
        return 1;

    if(findLabyDir[1](laby,part2,x,y))
        return 1;

    if(findLabyDir[2](laby,part2,x,y))
        return 1;

    return 0;
}


/*
 * Serial generation
 */
 void serial_gen(LPSTR serial){
    TCHAR part1[2+1],part2[(4*8)+1];
    int i,a,b,decal,alea;

    /* Clean buf */
    ZeroMemory(part1,sizeof(part1));
    ZeroMemory(part2,4*(8+1));

    /* Set random key permutation */
    part1[0] = charset1[rand()%13];
    part1[1] = charset2[rand()%13];

    /* Permute charset */
    decal = get_pos_charset(part1[0],charset1);
    for(i=0;i<13;i++){
        charset1_rot[i] = charset1[(decal+i)%13];
    }

    decal = get_pos_charset(part1[1],charset2);
    for(i=0;i<13;i++){
        charset2_rot[i] = charset2[(decal+i)%13];
    }

    /* 1st stupid solution */
    /*a=0;
    b=0;
    for(i=0;i<16;i++){
        part2[2*i] = charset1_rot[a];
        part2[(2*i)+1] = charset2_rot[b];

        alea = rand()%4;

        if((a<11)&&tab[(b*13)+a+1])
            a++;
        else if((b<12)&&tab[((b+1)*13)+a])
            b++;
        else if((b>0)&&(tab[((b-1)*13)+a]))
            b--;
        else if((a>0)&&(tab[(b*13)+a--]))
            a--;
    }*/

    /* 2nd solution : the recursive way */
    MoveMemory(laby,map,13*13*4);
    alea = valid_first_position[rand()%sizeof(valid_first_position)];
    laby[13*alea] = 2;
    cur_digit = 15;
    nb_pass = 0;
    findLaby(laby,part2,0,alea);

    /* Human readable */
    sprintf(serial,"CKGM1%2s-",part1);
    MoveMemory(serial+8,part2,8);
    MoveMemory(serial+17,part2+8,8);
    MoveMemory(serial+26,part2+16,8);
    MoveMemory(serial+35,part2+24,8);
    serial[16] = serial[25] = serial[34] = '-';
    serial[43] = '\0';
 }


/*
 * Main job :)
 */
void KeyGen(TCHAR *key){
    static int first_exec=1;

    if(first_exec){
        srand(GetTickCount());
        first_exec=0;
    }

    serial_gen(key);
}


