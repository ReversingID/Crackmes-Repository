//---------------------------------------------------------------------------

#include <vcl.h>
#include <stdio.h>


#include "realTimeA10Main.h"
#include "cracker.h"
#pragma hdrstop
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
Ta10realForm *a10realForm;
//---------------------------------------------------------------------------
__fastcall Ta10realForm::Ta10realForm(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------

char last_h1;

DWORD INIT_A10(DWORD a, DWORD b, DWORD c, DWORD d, DWORD e)
{
char hash1;
char hash2;
char hash3;
char hash4;
char hash5;

int checksum;
char mod1 = (char)a ^ 2;
int i;

	hash1 = (((keyf1[16] - (BYTE)a) * (BYTE)a) + (keyf1[16] ^ (BYTE)a)) + mod1;
	hash2 = ((hash1 - (BYTE)b) * (BYTE)b) + (hash1 ^ (BYTE)b);
	hash3 = (((keyf1[16] * (BYTE)c) - hash1)*(BYTE)c) + ((BYTE)c ^ hash2);
	hash4 = (((hash2 - (BYTE)d) + hash3) * (BYTE)d) + (hash3 ^ (BYTE)d);
	hash5 = ((hash1 - hash4) * (BYTE)e) + (hash4 ^ (BYTE)e);
	last_h1 = hash1;

	checksum = ((((((int)hash1 ^ a) - ((int)hash5 * e)) - ((int)hash3 ^ c) +
		(d * (int)hash4)) + (b * (int)hash2)) ^ ((((int)hash4 * a) * b) * c)) ^
		((int)hash1 * (int)hash2 * (int)hash3);
	return checksum;
}


DWORD A10(DWORD a, DWORD b, DWORD c, DWORD d, DWORD e)
{
char hash1;
char hash2;
char hash3;
char hash4;
char hash5;

int checksum;
char mod1 = (char)a ^ 2;
int i;

	hash1 = (((keyf1[16] - (BYTE)a) * (BYTE)a) + (keyf1[16] ^ (BYTE)a)) + mod1;
	hash2 = ((hash1 - (BYTE)b) * (BYTE)b) + (hash1 ^ (BYTE)b);
	hash3 = (((keyf1[16] * (BYTE)c) - hash1)*(BYTE)c) + ((BYTE)c ^ hash2);
	hash4 = (((hash2 - (BYTE)d) + hash3) * (BYTE)d) + (hash3 ^ (BYTE)d);
	hash5 = ((hash1 - hash4) * (BYTE)e) + (hash4 ^ (BYTE)e);

	checksum = ((((((int)hash1 ^ a) - ((int)hash5 * e)) - ((int)hash3 ^ c) +
		(d * (int)hash4)) + (b * (int)hash2)) ^ ((((int)hash4 * a) * b) * c)) ^
		((int)hash1 * (int)hash2 * (int)hash3);
	return checksum;
}

DWORD a10_hash(DWORD a, DWORD b, DWORD c, DWORD d, DWORD e)
{
	int i,x;
	DWORD A,B,C,D,E;
	A = INIT_A10(a,b,c,d,e);
		 B = A10(b,c,d,e,A);
		 C = A10(c,d,e,A,B);
		 D = A10(d,e,A,B,C);
		 E = A10(e,A,B,C,D);

	x = 1;
	for(i = last_h1+1; i <= 2500; i++)
	{
		A ^= (int)keyf1[x] * C;
		B ^= (int)keyf1[x] * D;
		C ^= (int)keyf1[x] * E;
		E ^= (int)keyf1[x] * A;
		D ^= (int)keyf1[x] * B;
		x++;
	}

	return A10(A,B,C,D,E);
}

void UpdateKey()
{
	char key[200];
	char hash[100];
	DWORD a,b,c,d,e,h;
	a = strtoul(a10realForm->edta->Text.c_str(),NULL, 2);
	b = strtoul(a10realForm->edtb->Text.c_str(),NULL, 2);
	c = strtoul(a10realForm->edtc->Text.c_str(),NULL, 2);
	d = strtoul(a10realForm->edtd->Text.c_str(),NULL, 2);
	e = strtoul(a10realForm->edte->Text.c_str(),NULL, 2);
	sprintf(key,"%d-%d-%d-%d-%d",a,b,c,d,e);
	a10realForm->edts->Text = key;

	h = a10_hash(a,b,c,d,e);
	itoa((int)h, hash, 16);
	for(int i = 0; hash[i] != '\0'; i++)
		hash[i] = toupper(hash[i]);

	a10realForm->edth->Text = hash;
	if(h == 0xFC90F720)
	{
		a10realForm->victoryLbl->Caption = "Success!";
        a10realForm->victoryLbl->Color = clGreen;
	}

	h = A10(a,b,c,d,e);
	itoa((int)h, hash, 16);
	for(int i = 0; hash[i] != '\0'; i++)
		hash[i] = toupper(hash[i]);

	a10realForm->edta10->Text = hash;
}

void __fastcall Ta10realForm::edtaChange(TObject *Sender)
{
	UpdateKey();
}
//---------------------------------------------------------------------------
void __fastcall Ta10realForm::edtbChange(TObject *Sender)
{
    UpdateKey();
}
//---------------------------------------------------------------------------
void __fastcall Ta10realForm::edtcChange(TObject *Sender)
{
	UpdateKey();
}
//---------------------------------------------------------------------------
void __fastcall Ta10realForm::edtdChange(TObject *Sender)
{
	UpdateKey();
}
//---------------------------------------------------------------------------
void __fastcall Ta10realForm::edteChange(TObject *Sender)
{
	UpdateKey();
}
//---------------------------------------------------------------------------
void __fastcall Ta10realForm::FormCreate(TObject *Sender)
{
	UpdateKey();
}
//---------------------------------------------------------------------------
void __fastcall Ta10realForm::edtsChange(TObject *Sender)
{
	char b1[200];
	int a,b,c,d,e;

	sscanf(a10realForm->edts->Text.c_str(),"%d-%d-%d-%d-%d",&a,&b,&c,&d,&e);
	itoa(a,b1,2); a10realForm->edta->Text = b1;
	itoa(b,b1,2); a10realForm->edtb->Text = b1;
	itoa(c,b1,2); a10realForm->edtc->Text = b1;
	itoa(d,b1,2); a10realForm->edtd->Text = b1;
	itoa(e,b1,2); a10realForm->edte->Text = b1;
	UpdateKey();
}
//---------------------------------------------------------------------------

