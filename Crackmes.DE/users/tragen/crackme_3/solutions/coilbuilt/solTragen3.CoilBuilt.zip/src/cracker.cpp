#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <windows.h>
#include "cracker.h"

void brutef_easy()
{
	printf("Part 1: Starting Brute Force\n");
	for(DWORD i = 0; i <= 0xFFFFFFFF; i++)
	{
		if(((i * i) ^ (8 * (i * i))) == 0x30E184)
		{
			printf("Found Key Collision: %d\n\n", i);
			break;
		}
	}
}

void brutef_med()
{   
	DWORD mod1, mod2, mod3, mod4, checksum;
	char hash1,hash2,hash3,hash4,hash5;

	printf("Part 2: Starting Brute Force\n");
	for(DWORD i = 0; i <= 0xFFFFFFFF; i++)
	{
		mod1 = i * i;
		mod2 = i ^ 4;
		mod3 = i ^ 2;
        mod4 = i * 3;

		hash1 = (((keyf1[16] - (char)i) * (char)i) + (keyf1[16] ^ (char)i)) + (char)mod3;
		hash2 = ((hash1 - (char)mod3) * (char)mod3) + (hash1 ^ (char)mod3);
		hash3 = (((keyf1[16] * (char)mod1) - hash1)*(char)mod1) + ((char)mod1 ^ hash2);
		hash4 = (((hash2 - (char)mod2) + hash3) * (char)mod2) + (hash3 ^ (char)mod2);
		hash5 = ((hash1 - hash4) * (char)mod4) + (hash4 ^ (char)mod4);

		checksum = ((((((int)hash4 * mod2) - ((int)hash5 * mod4)) -
		(hash3 ^ mod1)) + (hash2 * mod3)) + ((int)hash1 ^ i));

		checksum ^= (int)hash4 * mod1 * mod3 * i;
		checksum ^= hash2 * hash3 * (int)hash1;
		
		if(checksum == 0x521E4B92)
		{
			printf("Found Key Collision: %d\n\n", i);
			break;
		}
	}
}

DWORD INIT_A10(DWORD a, DWORD b, DWORD c, DWORD d, DWORD e, char* last_h1)
{
char hash1,hash2,hash3,hash4,hash5;
int checksum;
char mod1 = (char)a ^ 2;
int i;

	hash1 = (((keyf1[16] - (char)a) * (char)a) + (keyf1[16] ^ (char)a)) + mod1;
	hash2 = ((hash1 - (char)b) * (char)b) + (hash1 ^ (char)b);
	hash3 = (((keyf1[16] * (char)c) - hash1)*(char)c) + ((char)c ^ hash2);
	hash4 = (((hash2 - (char)d) + hash3) * (char)d) + (hash3 ^ (char)d);
	hash5 = ((hash1 - hash4) * (char)e) + (hash4 ^ (char)e);
	*last_h1 = hash1;

	checksum = ((((((int)hash1 ^ a) - ((int)hash5 * e)) - ((int)hash3 ^ c) +
		(d * (int)hash4)) + (b * (int)hash2)) ^ ((((int)hash4 * a) * b) * c)) ^
		((int)hash1 * (int)hash2 * (int)hash3);
	return checksum;
}


DWORD A10(DWORD a, DWORD b, DWORD c, DWORD d, DWORD e)
{
char hash1,hash2,hash3,hash4,hash5;
int checksum;
char mod1 = (char)a ^ 2;
int i;

	hash1 = (((keyf1[16] - (char)a) * (char)a) + (keyf1[16] ^ (char)a)) + mod1;
	hash2 = ((hash1 - (char)b) * (char)b) + (hash1 ^ (char)b);
	hash3 = (((keyf1[16] * (char)c) - hash1)*(char)c) + ((char)c ^ hash2);
	hash4 = (((hash2 - (char)d) + hash3) * (char)d) + (hash3 ^ (char)d);
	hash5 = ((hash1 - hash4) * (char)e) + (hash4 ^ (char)e);

	checksum = ((((((int)hash1 ^ a) - ((int)hash5 * e)) - ((int)hash3 ^ c) +
		(d * (int)hash4)) + (b * (int)hash2)) ^ ((((int)hash4 * a) * b) * c)) ^
		((int)hash1 * (int)hash2 * (int)hash3);
	return checksum;
}

DWORD a10_hash(DWORD a, DWORD b, DWORD c, DWORD d, DWORD e)
{
	int i,x;
	char last_h1;
	DWORD A,B,C,D,E;
	
	A = INIT_A10(a,b,c,d,e,&last_h1);
		 B = A10(b,c,d,e,A);
		 C = A10(c,d,e,A,B);
		 D = A10(d,e,A,B,C);
		 E = A10(e,A,B,C,D);

	x = 1;
	for(i = last_h1+1; i <= 2500; i++)
	{
		A ^= (DWORD)keyf1[x] * C;
		B ^= (DWORD)keyf1[x] * D;
		C ^= (DWORD)keyf1[x] * E;
		E ^= (DWORD)keyf1[x] * A;
		D ^= (DWORD)keyf1[x] * B;
		x++;
	}

	return A10(A,B,C,D,E);
}

void brutef_hard()
{
	DWORD a = 0, b = 0, c = 9999999, d = 9999999, e = 9999999;
	DWORD A, B;
	printf("Part 3: Starting Brute Force\n");

	while(b < 511)
	{
		A = (a << 15) + 25603;
		B = (b << 15) + 21567;

		if(a10_hash(A,B,c,d,e) == 0xFC90F720 && A <= 9999999 && B <= 9999999)
			printf("Valid Key-> %d-%d-%d-%d-%d\n",A,B,c,d,e);
		
		a++;
		if(a == 511) {b++; a = 0;}
	}
	
	printf("Finished Finding Key Collisions.\n\nPress any key to terminate.\n");
}

int main()
{
	brutef_easy();
	brutef_med();
	brutef_hard();
    getch();
    return 0;
}
