/*
DHX keygenme 1 - keygen
coded by bundy, 2oo3

*/

#include <stdio.h>
#include <windows.h>
#include "resource.h"
#include <miracl.h>

#define USERLEN 20

HINSTANCE hInst;

static miracl *mip;
static int userLen, randVal;
static unsigned char szName[USERLEN] = {0};
static unsigned char szSerial[2*(200/8)+1] = {0};
static big d,n,x;

BOOL CALLBACK DialogProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{	
	switch (message)
	{    
	case WM_CLOSE:
		EndDialog(hWnd,0);
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{ 
		case IDGENERATE:
			userLen=GetDlgItemText(hWnd, IDC_NAME, szName, USERLEN+1);
			if (userLen<5) SetDlgItemText(hWnd, IDC_REGCODE, "Enter at least 5 chars!");
			else
			{
				// user name to big x
				bytes_to_big(userLen, szName, x);
				// x = x * 0x1337
				premult(x, 0x1337, x);
				// get a random value less than 0x1337
				randVal = GetTickCount()%0x1337;
				// x = x + randVal
				incr(x, randVal, x);
				// x = x^d mod n
				powmod(x, d, n, x);

				// convert to string and show to the user
				cotstr(x, szSerial);
				SetDlgItemText(hWnd, IDC_REGCODE, szSerial);
			}
			break;
		case IDABOUT:
			MessageBox(hWnd, "Greetz fly out to all reverse-engeneering-academy\nmembers and all at forum.anticrack.de!", "About", MB_OK);
			break;
		}
		break;
	case WM_INITDIALOG:
		SendMessageA(hWnd,WM_SETICON,(WPARAM) 1,(LPARAM) LoadIconA(hInst,MAKEINTRESOURCE(IDI_ICON1)));
		SendDlgItemMessage(hWnd, IDC_NAME, EM_SETLIMITTEXT, USERLEN, 0);
		break;
	}
     return 0;
}

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{
	hInst = hInstance;
	// init miracl
	mip=mirsys(200,16);
	mip->IOBASE = 16;

	// alloc bigs & init them
	n = mirvar(0);
	d = mirvar(0);
	x = mirvar(0);
	cinstr(n, "8ACFB4D27CBC8C2024A30C9417BBCA41AF3FC3BD9BDFF97F89");
	cinstr(d, "32593252229255151794D86C1A09C7AFCC2CCE42D440F55A2D");
	
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, (DLGPROC)DialogProc,0);

	mirkill(x);
	mirkill(n);
	mirkill(d);
	mirexit();

	return 0;
}

