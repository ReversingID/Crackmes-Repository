import java.math.BigInteger;
import java.io.Console;

class Keygen {
   public static void main(String[] args) {
      Console c = System.console();
      String name = c.readLine("Please input your name: "); 
      while (name.length() < 5) {
         name = c.readLine("Name must be at least 5 characters long.  Please input your name: ");
      }
      System.out.println("The product key is 37911-DIHUX-62119-FUNNY-L4wlz.  The last block of 5 characters can be anything alpha-numeric you choose by the way.");
      System.out.println("Activation codes:");
      BigInteger C1 = new BigInteger("CBEC5F1F97FB14C803CB",16);
      BigInteger C1m1 = C1.subtract(BigInteger.valueOf(1));
      BigInteger C3 = new BigInteger("3652B36A37B0C7ECE042",16);
      BigInteger P = new BigInteger("21FCBA8543FF2E2155F7",16);
      BigInteger exp = new BigInteger("14F9FCF8ED4883E91A61",16);
      BigInteger N = new BigInteger(name.getBytes()).multiply(exp).mod(P);
      BigInteger k1,k2;
      String code;
      int response = '\r';
      boolean found;
      int foundn = 0;
      for (int K = 0;response == '\r' || response == '\n';K++) {
         found = false;
         k2 = BigInteger.valueOf(K).multiply(P).add(N);
         if (k2.compareTo(C3) != -1) {
            k2 = k2.subtract(C3);
            code = "3652B36A37B0C7ECE042-" + k2.toString(16).toUpperCase();
            if (code.length() <= 50) {
               System.out.println(code);
               found = true;
               foundn++;
            }
         }
         for (int L = 0; L <= K; L++) {
            int M = K - L;
            k1 = BigInteger.valueOf(L).multiply(P).add(N);
            k2 = BigInteger.valueOf(M).multiply(C1m1);
            code = k1.toString(16).toUpperCase() + "-" + k2.toString(16).toUpperCase();
            if (code.length() <= 50 && code.length() >= 10) {
               System.out.println(code);
               found = true;
               foundn++;
            }
         }
         if (found == true) {
            System.out.printf("Hit Return for more activation keys (%1$s found), or type anything else to exit",foundn);
            try {
               response = System.in.read();
               System.in.skip(System.in.available());
            } catch (Exception e) {
               System.out.println(e.getMessage());
               response = 'n';
            }
         }
      }
   }
}