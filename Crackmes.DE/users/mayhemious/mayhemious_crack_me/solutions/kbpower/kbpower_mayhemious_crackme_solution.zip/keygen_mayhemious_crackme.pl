#!/usr/bin/perl
##-- kbp - 20080930 --##

use strict;


##-- vars --##
my ($name, $nameLength, $serial);
my %japaneseAlpha = (
  "a" => "ka",
  "b" => "tu",
  "c" => "mi",
  "d" => "te",
  "e" => "ku",
  "f" => "lu",
  "g" => "ji",
  "h" => "ri",
  "i" => "ki",
  "j" => "zu",
  "k" => "me",
  "l" => "ta",
  "m" => "rin",
  "n" => "to",
  "o" => "mo",
  "p" => "no",
  "q" => "ke",
  "r" => "shi",
  "s" => "ari",
  "t" => "chi",
  "u" => "do",
  "v" => "ru",
  "w" => "mei",
  "x" => "na",
  "y" => "fu",
  "z" => "zi" );


##-- subs --##
sub generateSerial {

  my $result = "";
  foreach my $char (split(//, shift())) {
    $char = $japaneseAlpha{$char};
    $result = $result . "$char";
  }
  return $result;

}


##-- main --##
print "-= This is a keygen for Mayhemious' crackme from www.crackmes.de =-\n";
print "Please enter your name: ";
$name = <STDIN>;
chomp $name;
$nameLength = length($name);
$serial = generateSerial($name);
print "Your serial is: $serial\n";
