Crackme11 by FireWorx
=====================

EEEEEEEY!!! This is my 11:th crackme and i demand a keygen on it...
Not just a serial for yer name...
To easy...
Well, when u cracked it do a keygen and send it and the source to Aveny@hotmail.com

RuLez =)))
No patching... well if u can do it maybe =))) dunno...
Well, just a keygen for me anyway...
====================================

Greetz; Many....
Especially PhoX and TeChNiCh anyway!!! And all swedes in the cracking buissness!!!
DNNUKE =))))

Well that�s it...
Bye / FireWorx


=======================
Http://surf.to/FireWorx
FireWorx@as-if.com
Aveny@hotmail.com