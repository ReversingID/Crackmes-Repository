  ____                     __      __                          
 /\  _`\   __             /\ \  __/\ \                         
 \ \ \L\_\/\_\  _ __    __\ \ \/\ \ \ \    ___   _ __   __  _  
  \ \  _\/\/\ \/\`'__\/'__`\ \ \ \ \ \ \  / __`\/\`'__\/\ \/'\ 
   \ \ \/  \ \ \ \ \//\  __/\ \ \_/ \_\ \/\ \L\ \ \ \/ \/>  </ 
    \ \_\   \ \_\ \_\\ \____\\ `\___x___/\ \____/\ \_\  /\_/\_\
     \/_/    \/_/\/_/ \/____/ '\/__//__/  \/___/  \/_/  \//\/_/
             

Hey M8�s, FireWorx�s here again with a new crackme...
This one is made in Delphi5 (Thx Nitrus-, MuTTkiD^^, sortof and Acid_Burn);

==============
What�s all this about?                                                  
::::::::::::::
The target is to get your self a valid serial and get a registered box...
And for all you leet0s to crackers, u are forced to keygen =)))
Well, for any questions, bugs(hehe not to many i hope) or shit mail: FireWorx@as-if.com

And if you got a valid serial for it please mail also: FireWorx@as-if.com

So now that you know a lil' about it. GET ON WITH IT =�
'''''''''''''''''''''''''''''''''''''''''''''''''''''''

Greets: Nitrus(can�t thank enough) MuTTkiD^^, sortof, Acid_Burn, cTT, Icecream, Zappelin, #Winprog.se and #cracking4newbies... Thanks all to you =)))