Hey there again cracker...
Here�s my 15�th crackme now... and i�m releasing the 16�th at the same time...
Made three in a row now =)))
Hope U like this one, as much i did making it..

Rulez:
Shit da same. if u wanna patch =) okey, yer lame but what da fuck =)))
Keygen it and send it to FireWorx@as-if.com
U don�t need to keygen it but that would be nice =)

Well, so long FireWorx ':-_-:' ���