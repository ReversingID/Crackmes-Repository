SMNsoft KeygenMe#4

Rules:

- No Patch
- write a keygen
- write a tut