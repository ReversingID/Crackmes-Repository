Black4 by TripleTordo
Release Date: 24th December 2010
Language: Delphi
Level: 2/10
--------------------------------

Hey! , this is my 4th crackme. I hope you enjoy it. little tricks.

******************
Rulez :
	- NO patching allowed
	- NO code ripping allowed
	- NO self-keygening, code ripping allowed

Just:	Find protection scheme , and Serial Genaretion Algorithm. Write a tuto and a working keygen.

ONLY KEYGENS ALLOWED.

******************
i Hope you enjoy it, and if you can't find a valid solution, i hope you will learn something.
Regards.


Thanx to: 

	- KKR_WE_RULE, mre521 for take time to answer me
	- draww for my 2nd crackme tut
	- you, for try this.

Suggestions, donations, free sex to :

.: tripletordo@gmail.com :.


**********************  Merrry Xmas **************************

EOF