Keygen is created in Visual Studio 2008.
.Net Framework 3.5


The main code for generate SN is in the:
\TTBlack4_keygen\TTBlack4_keygen\generateSN.cs
