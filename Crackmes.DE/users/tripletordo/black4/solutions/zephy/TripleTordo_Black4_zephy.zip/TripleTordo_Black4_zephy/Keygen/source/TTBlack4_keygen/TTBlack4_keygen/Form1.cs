﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TTBlack4_keygen
{
    public partial class frmKeygen : Form
    {
        public frmKeygen()
        {
            InitializeComponent();
        }

        private void pbExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pbGenerate_Click(object sender, EventArgs e)
        {
            generateSN gsn = new generateSN();
            tbSN.Text = gsn.GenerateSN(tbName.Text);
        }
    }
}
