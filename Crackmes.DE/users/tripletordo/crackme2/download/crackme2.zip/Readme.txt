Crackme2 by TripleTordo
Release Date: 8th July 2009
Language: vb6
Level: 1/10
--------------------------------

Hey! , this is my Second crackme. I hope you enjoy it.

******************
Rulez :
	- NO patching allowed
	- NO code ripping allowed
Just:	Find protection scheme , explain it and make a tuto.

This Crackme generates a valid serial, but how?. Find the way to crackme says "REGISTERED"

******************
i Hope you enjoy it, and if you can't find a valid solution, i hope you will learn something.
Regards.


Thanx to: you, for try this.

Suggestions, donations, free sex to :

.: tripletordo@gmail.com :.

EOF