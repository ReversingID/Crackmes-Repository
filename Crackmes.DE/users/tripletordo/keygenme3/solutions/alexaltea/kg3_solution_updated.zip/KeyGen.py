name = raw_input("Keygen by AlexAltea [alexaltea123@gmail.com]\nWrite a name:\n")
res = ""
for i in range(len(name)):
    res += str(0xC8 - ord(name[i]) - i-1)
if len(name) == 5:
    res += "T"
if len(name) == 6:
    res += "R"
if len(name) == 7:
    res += "I"
if len(name) == 8:
    res += "P"
if len(name) == 9:
    res += "L"
if len(name) == 10 or len(name) == 11 or len(name) == 12:
    res += "E"
if len(name) < 5 or len(name) > 12:
    if len(name) < 5:
        print "Error: Name is too short."
    if len(name) > 12:
        print "Error: Name is too big."
else:
    print "\nSerial is:\n"+res
