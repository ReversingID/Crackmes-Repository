# updated for the lenght check

serial = ''
username = ''
temp=0	# used here like ECX in the app

while not ( 4 <= len(username) <= 10 ):
	print '''
****************
    Username must be longer than 4 and shorter than 11
****************
			'''
	username = raw_input('Username: ')

	
for letter in username[:-1]:
	temp += ord(letter)
	if 65<=ord(letter)<=90:  # if it's uppercase
		temp += 0x2C

temp += 0x29a
temp *= 0x3039
temp -= 0x17
temp *= 0x9

while temp:
	serial += chr(temp%0xa+0x30)
	temp //= 0xa # integer division

serial = serial[::-1] # reversing string
serial += username[3:]

print 'Serial:', serial
raw_input() # just so it doesn't close right away