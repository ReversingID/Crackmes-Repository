Flatline's CrackMe #1
+++++++++++++++++++++++++++++++++++

A simple CrackMe that should only require a little thought. 

Rules

* Both Cracks & Keygens will be accepted (Preferablly one of each)
* No serial fishing
* For a crack solution an explanation of how the algorithm works and why patches were made is required

Enjoy 

flatline ;)