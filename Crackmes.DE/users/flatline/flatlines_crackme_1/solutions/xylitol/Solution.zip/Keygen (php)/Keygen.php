<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Flatline's CrackMe #1 *Keygen*</title>
<style type="text/css">
<!--
body,td,th {
	color: #FFF;
}
body {
	background-color: #000;
}
-->
</style></head>

<body>
<p><center><img src="xyli.jpg" width="572" height="150" alt="Xyl2k11" /></center></p>
<p>Syntax: keygen.php?name=Whatever</p>
<form action="Keygen.php" method="get">
  <table>
	<tr><td>Name : </td><td><input type="text" name="name" value="" /></td></tr>
    <tr><td><input type="submit" value="Gen" /></td>
    <td> <?php
	if(isset($_GET['name']))
	{
		$name = $_GET['name'];
		echo '<font color="red">' . strtoupper(sha1($name)) . '</font>';
	}
?></td></tr>
</table>
</form>
</body>
</html>
