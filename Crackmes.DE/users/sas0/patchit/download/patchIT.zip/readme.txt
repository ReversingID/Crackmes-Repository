Second crackme by |sas0|
-----------------------------
Goal: Well it's time for some patching :)
      Nothing more to say just try it out
      it's not too hard....maybe just not so "clean" code :)
      Hope you'll enoy it

Greets to evryone on crackmes.de