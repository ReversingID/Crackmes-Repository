Title:      .NET Anarchy
Language:   .NET 2.0
Difficulty: 2 or 3, I'm not sure
Rules: calculate serial or make a keygen, patching is too easy

Description: Here is a crackme written in .NET 2.0 which I hope is a little bit different
             then other .NET crackmes. It is build in two parts, first part is trivial,
             second part...well try it and you will see ;)

