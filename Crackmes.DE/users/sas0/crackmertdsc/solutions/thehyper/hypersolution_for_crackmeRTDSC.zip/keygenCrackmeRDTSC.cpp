// keygenCrackmeRDTSC.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
char serial[]="A43589734022345KSFGNRRRZ6346347457z234576782bniDF4366236888335t945635285826PASDFN6345539485810";
int main(int argc, char* argv[])
{
	int i=0;
	__asm rdtsc
	__asm mov ebx,eax
	__asm rdtsc
	__asm sub eax,ebx
	__asm mov i,eax
	printf("%.8s",serial+i);
	return 0;
}

