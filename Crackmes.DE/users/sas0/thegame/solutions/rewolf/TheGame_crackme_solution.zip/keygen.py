import sys
import base64
import hashlib
	
def list2str(lt):
	ostr = ""
	for b in lt:
		ostr += chr(b)
	return ostr
	
def printHex(str):
	for c in str:
		print "%02X " % c,
	print ""

username = "rewolf"
if len(sys.argv) == 2:
	username = sys.argv[1]
	
dig = hashlib.sha1(username).digest()
nameSHA1 = []
for b in dig:
	nameSHA1.append(ord(b))

name_p_data = []
game_p_index = []
game_p_data = [
0, 0, 9, 0, 8, 0, 0, 4, 3, 
6, 0, 0, 0, 9, 0, 0, 0, 8, 
5, 0, 0, 0, 0, 3, 6, 0, 0, 
4, 0, 0, 7, 0, 0, 9, 0, 0, 
0, 0, 7, 0, 5, 9, 8, 0, 0, 
0, 0, 5, 3, 0, 0, 0, 0, 1, 
0, 0, 3, 6, 0, 0, 0, 0, 2, 
7, 0, 0, 0, 4, 0, 0, 0, 6, 
1, 8, 0, 0, 3, 0, 4, 0, 0
]

for i in xrange(len(game_p_data)):
	if game_p_data[i] == 0:
		game_p_index.append(i)

lsh = len(nameSHA1)
for i in xrange(lsh):
	tb = ((nameSHA1[i] & 0xF0) >> 4) 
	tb |= ((nameSHA1[i] & 0xF) << 4)
	if i < lsh - 1:
		tb ^= nameSHA1[i + 1]
	name_p_data.append(tb)
	
j = 0
while j + 15 < len(game_p_index):
	for i in xrange(len(name_p_data)):
		b0 = (name_p_data[i] & 0xF0) >> 4
		b1 = name_p_data[i] & 0xF
		
		b2 = game_p_index[b0 + j]
		game_p_index[b0 + j] = game_p_index[b1 + j]
		game_p_index[b1 + j] = b2
	j += 5

output_b = [
2,	1,	9,	5,	8,	6,	7,	4,	3,
6,	3,	4,	2,	9,	7,	5,	1,	8,
5,	7,	8,	4,	1,	3,	6,	2,	9,
4,	6,	1,	7,	2,	8,	9,	3,	5,
3,	2,	7,	1,	5,	9,	8,	6,	4,
8,	9,	5,	3,	6,	4,	2,	7,	1,
9,	4,	3,	6,	7,	5,	1,	8,	2,
7,	5,	2,	8,	4,	1,	3,	9,	6,
1,	8,	6,	9,	3,	2,	4,	5,	7
]

out_serial = []
for i in xrange(len(game_p_index)/2):
	b1 = output_b[game_p_index[2*i]]
	b1 <<= 4
	b1 |= output_b[game_p_index[2*i+1]]
	out_serial.append(b1)
out_serial.append(output_b[game_p_index[len(game_p_index) - 1]] << 4)

print "Name: %s" % username
print "Serial: %s" % base64.b64encode(list2str(out_serial))
