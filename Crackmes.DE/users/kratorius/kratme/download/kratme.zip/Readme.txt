- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                        _  __          _   __  __
                       | |/ /_ __ __ _| |_|  \/  | ___
                       | ' /| '__/ _` | __| |\/| |/ _ \
                       | . \| | | (_| | |_| |  | |  __/
                       |_|\_\_|  \__,_|\__|_|  |_|\___|

                    . .. ... kratorius production ... .. .

                      . .. http://kratorius.cjb.net .. .
                   . .. kratorius (at) bitchx (dot) it .. .

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Your goal is to make appear the congratulations message box.
I think that won't be very easy, especially for newbies.
Disassembling, debugging, zen cracking, yoga and patching are
allowed, but you can to patch just ONE byte (and you have need to do).
Obviously a direct jump to the congratulations message box is not accepted :)

If you want, you can write a solution for this crackme and you can send that
at kratorius@bitchx.it. I will publish that on my site.

Many thanks goes to (in no particular order): AndreaGeddon, Ironspark, Pincopall,
_ph0b0s_, Quequero, evilcry, ZaiRoN and at all the UIC members!

You can find me over irc.azzurra.org with the nick 'kratorius'.

bye bye
