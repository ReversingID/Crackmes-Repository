:: EXCEPTIONAL :::::::::::::::::::::::::::::::::::::::

So you wanna crack this crackme?
Uhm, good idea!


:: RULES :::::::::::::::::::::::::::::::::::::::::::::

You can use all the tools of this world, but plz try
to find the correct serial, instead to invert just a
jmp...


:: CREDITS :::::::::::::::::::::::::::::::::::::::::::

This crackme has been coded by

                     -----------
                      kratorius
                     -----------

mailto :: kratorius (at) bitchx (dot) it
http   :: kratorius.cjb.net
irc    :: irc.azzurra.org @ #reversing && #crack-it

Tnx to Ironspark (for moral support :)), AndreaGeddon,
Quequero, _d31m0s_ and who I forgot...