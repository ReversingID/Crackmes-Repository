#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char **argv)
{
    char name[255];
    char last_char;
    char prefix[255];
    char hostname[255];
    char hash[255];
    char serial[255];
    int h1 = 0x13;
    int counter=0;

    puts("\nLibertyordeath1776's KeygenMe #2\nKeygen  -- Greetz fr0m Scav3ng3R 2008");
    if (argc==1) puts("USAGE <optional> : %s <hostname>");

    printf("\nName: ");
    scanf("%s",name);

    /*fetch hostname either from arg1 or hostname() */
    if (argc<2)
        gethostname(hostname,255);
    else
        strcpy(hostname,argv[1]);

    while (hostname[counter]!='\0') /* makes prefix from hostname hashing sum*/
    {
        h1+=hostname[counter];
        counter++;
    }
    sprintf(prefix,"%d",h1);
    counter = strlen(hostname);


    last_char = name[strlen(name)-1];
    sprintf(hash,"%i",(   (last_char+counter)   *   (counter+strlen(name))    ) );	/* Caesar Shift :) */

    /*piece together serial*/
    strcpy(serial,prefix);
    strncat(serial,"-",1);
    strncat(serial,hash,strlen(hash));
    strncat(serial,"-",1);
    strncat(serial,name,2);     /* 1st 2 letters from username */
    strncat(serial,hostname,2); /* 1st 2 letters from hostname */

    printf("Serial: ");
    puts(serial);
    return 0;
}
