// keygen for LibertyorDeath's LibertyorDeath's Linux Keygenme #2
// http://www.crackmes.de/users/libertyordeath/libertyordeaths_linux_keygenme_2/

// Compile with
// gcc -Wall -Wextra -Werror -pedantic -ansi -std=c99 -O3 keygen.c
// the only requisite flag is -std=c99

// The serial is a simple strings computed from the name.

#define _XOPEN_SOURCE 500 // necessary for gethostname()
#include <stdio.h>
#include <string.h>
#include <unistd.h>
typedef int reg;
int main(int argc, char** argv)
{
	if (argc < 2)
	{
		printf("Usage: %s name\n", argv[0]);
		return 0;
	}

	reg x420 = 19;
	reg x428 = 0;

	char x31d[100];
	gethostname(x31d, 100);

	char* c = x31d;
	char x16[2];
	strncpy(x16, x31d, 2);
	while (*c)
	{
		x420 += *c;
		x428++;
		c++;
	}

	char serial[255] = "";
	sprintf(serial, "%i", x420);

	c = argv[1];
	char x20[2];
	strncpy(x20, c, 2);
	reg x42c = 0;
	reg x434 = 0;
	while (*c)
	{
		x434 = *c;
		x434 += x428;
		c++;
		x42c++;
	}

	x434 *= x428 + x42c;

	memcpy (serial+strlen(serial), "-", 2);
	sprintf(serial+strlen(serial), "%i", x434);
	memcpy (serial+strlen(serial), "-", 2);
	memcpy (serial+strlen(serial), x20, 2);
	memcpy (serial+strlen(serial), x16, 2);

	printf("%s\n", serial);
	return 0;
}
