// keygen for LibertyorDeath's LibertyorDeath's Linux Keygenme #3
// http://www.crackmes.de/users/libertyordeath/libertyordeaths_linux_keygenme_3/

// Compile with
// gcc -Wall -Wextra -Werror -pedantic -ansi -std=c99 -O3 keygen.c
// the only requisite flag is -std=c99

// The serial is a simple string computed from the host and the user names.

#define _XOPEN_SOURCE 500 // necessary for gethostname()
#include <stdio.h>
#include <string.h>
#include <unistd.h>
typedef int reg;
int main(int argc, char** argv)
{
	if (argc < 2)
	{
		printf("Usage: %s name\n", argv[0]);
		return 0;
	}

	char host[256];
	gethostname(host, 255);
	reg hostlen = strlen(host);

	char serial[256];
	reg x220 = 2 * host[hostlen-1];

	reg namelen = strlen(argv[1]);
	reg I = namelen-1;
	I = I % 2 ? I-1 : I;
	reg x224 = argv[1][I] * I * hostlen;

	sprintf(serial, "%i-", x220+x224);

	reg j = strlen(serial);
	for (reg i = 0; i < hostlen; i +=2)
		serial[j++] = host[i];
	serial[j] = 0;

	printf("%s\n", serial);
	return 0;
}
