#include <stdio.h>

/*
 * gcc -Wl,--export-dynamic -Wall -shared -m32 -fPIC -o fake.so fake.c
 */

int ptrace(int request, int pid, int addr, int data)
{
	return 0;
}

int strncmp(const char *s1, const char *s2, size_t n)
{
	char str[100];
	int i;

	for (i = 0; s1[i] ; ++i)
		str[i] = s1[i] - 5;
	str[i] = s1[i];

	printf(" =preload= Try \"%s\"\n", str);
	printf(" =preload= But lets fake strncmp as well ;)\n");

	return 0;
}
