#include <stdio.h>
#include <unistd.h>
#include <string.h>

int num(const char *name, const char *host)
{
	int r = 0, a, b;
	b = strlen(host);
	if (b > 1)
		r = 2 * ((b & 1) + 1) * host[b - 1 - (b & 1)];
	a = strlen(name);
	if (a-- > 1)
		r += name[a & ~1] * (a & ~1) * b;
	return r;
}

void print_serial(const char *name, const char *host)
{
	int i;
	printf("%i-", num(name, host));
	for (i = 0; host[i]; ++i)
		if (!(i%2))
			printf("%c", host[i]);
	printf("\n");
}

int main(int argc, char *argv[])
{
	if (argc != 3) {
		printf("usage: %s <username> <hostname>\n", argv[0]);
		return 1;
	}

	printf("Serial for \"%s@%s\": ", argv[1], argv[2]);
	print_serial(argv[1], argv[2]);

	return 0;
}
