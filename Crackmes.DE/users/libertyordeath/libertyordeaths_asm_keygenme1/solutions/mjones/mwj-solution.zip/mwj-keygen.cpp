/**
 * Keygen for LibertyorDeath's ASM KeygenMe#1
 * Author: mjones
 * August 13, 2009
 *
 * Keygen creates a serial for the app,
 * then outputs the serial to STDOUT
 */

#include <string>
#include <iomanip>
#include <iostream>

using namespace std;

int main() {
    string username;
    string serial;

    unsigned int var_eax;
    unsigned int var_ecx = 0;
    unsigned int var_edx = 0xA;
    unsigned int var_edi;
    unsigned int var_esi = 0;

    do { // read in username
	    std::cout << "Name: ";
	    std::cin >> username;
    } while (username.length() == 0);

    while (var_ecx < username.length()) {
        var_eax = username[var_ecx];    // MOVSX EAX,BYTE PTR DS:[ECX+4030C0]
	    var_eax++;                      // INC EAX
	    var_eax += var_edx;             // ADD EAX, EDX
	    var_esi += var_eax;             // ADD ESI, EAX
	    var_ecx++;                      // INC ECX
	    var_edx *= var_ecx;             // IMUL EDX, ECX
	    var_edi = var_edx;              // MOV EDI, EDX
	    var_edi *= var_esi;             // IMUL EDI, ESI
    }

    std::cout << "Your serial is LOD-" << var_esi << "-" << std::hex << std::uppercase << var_edi << endl;

    std::cin.get();
    std::cin.get();
    return 0;
}
