// keygen for LibertyorDeath's LibertyorDeath's Linux Keygenme #1
// http://www.crackmes.de/users/libertyordeath/libertyordeaths_linux_keygenme_1/


// Compile with
// gcc -Wall -Wextra -Werror -pedantic -ansi -std=c99 -O3 keygen.c
// the only requisite flag is -std=c99

// The serial is a simple integer computed from the name.

#include <stdio.h>
int main(int argc, char** argv)
{
	if (argc < 2)
	{
		printf("Usage: %s name\n", argv[0]);
		return 0;
	}
	char* x114 = argv[1];
	int x110 = 0;
	int x118 = 0;
	while (*x114)
	{
		x118 = 2 * *x114;
		x118 *= x110;
		x118 *= x118;
		x110++;
		x114++;
	}
	x118 *= 50;
	printf("Serial: %i\n", x118);
	return 0;
}
