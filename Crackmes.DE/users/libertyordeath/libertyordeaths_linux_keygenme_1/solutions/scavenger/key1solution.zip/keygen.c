#include <stdio.h>


int main(void)
{
	char name[30];
	puts("\nLibertyorDeath's Linux Keygenme #1\nKeygen -- Greetz fr0m Sc4v3ng3r 2008®\n");
	printf("Input Name: ");
	scanf("%s",&name);
	int counter = 0;
	int a = (int)name[counter];
	while (1)
	{ 
	 a=a*2;
	 a*=counter;
	 a*=a; 
	 if (name[counter+1] == '\0') break;
	 counter++;
	 a=(int)name[counter]; 
	}
	a*=50;
	printf("\nSerial: %d\n\n",a);
	return 0;
}

