
def generatePass(name):
	index = 0
	for char in name:
		password = (ord(char) * 2 * index) ** 2
		index += 1
	password *= 0x32
	return password

print "=== Keygen for LibertyorDeath's KeygenMe1 ==="
print "==== Written by San_SS! of the Cert team ===="
print
print "Insert name: "
name = raw_input()
print
print "Password for " + name + " is: " + str(generatePass(name))
