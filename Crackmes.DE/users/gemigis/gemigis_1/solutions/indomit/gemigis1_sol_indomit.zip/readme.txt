You may use this part of code to find your key :)


            string a = Convert.ToString("abg".GetHashCode());
            Random rnd = new Random();
            while (true)
            {
                int q = rnd.Next(Int32.MinValue, Int32.MaxValue);                
                string b = -1 + Convert.ToString(q.ToString().GetHashCode());
                if (string.Equals(a, b))
                {
                    MessageBox.Show(q.ToString());
                }  
            }

I found 
name: "abg"
key: "-1442769130"

But it may not be work for your system, if GetHashCode() has another implementation.