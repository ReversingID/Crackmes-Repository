Hi,

Hope you like this crackme.

Feel free to do whatever you like with the exe. The goal is to finish the prime number calculation.

Make a KeyGen, patch, self key, do whatever you like ;) but please write a tut or let me know how you did it.

Good luck
