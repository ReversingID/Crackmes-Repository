It's very simple, you must find the correct serial for it!
No patches are allowed!

This is intended for newbies who wants to try out their skills
on "reversing VB". If you fail or want to ask me something
just mail me!

AttilhaZ
attilhaz@yahoo.it