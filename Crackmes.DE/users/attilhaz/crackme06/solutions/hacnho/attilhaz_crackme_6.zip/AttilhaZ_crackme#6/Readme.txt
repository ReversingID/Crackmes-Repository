It's very simple, you must change the caption of the DEMO VERSION label!
You can patch it!

When you crack it, send me the solution!!!!

If you fail or want to ask me something just mail me!

AttilhaZ
attilhaz@yahoo.it