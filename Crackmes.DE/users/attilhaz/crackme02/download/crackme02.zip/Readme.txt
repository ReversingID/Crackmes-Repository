It's very simple, you must delete the NAG Screen!
You can patch it!

This is intended for newbies who wants to try out their skills
on "patching VB". If you fail or want to ask me something
just mail me!

AttilhaZ
attilhaz@yahoo.it