//
// loader for crackme v15.0 by attilhaz :)
//
// note: why "ShellExecute"? because I'm lazy! :)
//

#include <windows.h>

void WinMainCRTStartup()
{
	HANDLE hWin;
	int i;

	if ((ShellExecute(0,"open","crackme15.exe",0,".",SW_SHOWDEFAULT)) < 32)
	{
		MessageBox(0,"ERROR: cannot find crackme executable...","ops!",MB_OK+MB_ICONERROR);
		ExitProcess(0);
	}

	i=0;

	do
	{
		hWin=FindWindow(0,"Remove me!!!");

		i++;
		if (i > 0xFFFFFF)
		{
			MessageBox(0,"ERROR: loader timeout...","ops!",MB_OK+MB_ICONERROR);
			ExitProcess(0);
		}

	} while (hWin == 0);

	SendMessage(hWin,WM_CLOSE,0,0);
	ExitProcess(0);
}