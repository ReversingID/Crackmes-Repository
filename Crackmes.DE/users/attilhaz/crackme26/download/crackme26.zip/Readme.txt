Find the correct serial. It's better if you don't patch it.

AntiDebugger protection.

When you crack it, send me the solution!!!!

If you fail or want to ask me something just mail me!

AttilhaZ
attilhaz@yahoo.it