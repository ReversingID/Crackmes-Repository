This is my first CriptoAnalize file.

You must Decrypt the "DecryptMe.txt" file and write a 
Decrypter program for this one.

For any questions you can write mr to:

attilhaz@yahoo.it