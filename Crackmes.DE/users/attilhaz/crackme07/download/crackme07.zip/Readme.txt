Enable the button and th check, then
find the serial!
You can patch it!

When you crack it, send me the solution!!!!

If you fail or want to ask me something just mail me!

AttilhaZ
attilhaz@yahoo.it