#include "stdio.h"
int main()
{
	char cenc[115], test[116], res[116];
	int testlen,i,j;
	bool k;
	FILE *fenc=fopen("encrypted.bin","rb");
	for (i=0;i<115;i++)	{ cenc[i]=fgetc(fenc); }
	fclose(fenc);
	fenc=fopen("test.bin","rb");
	i=0;
	do { test[i]=fgetc(fenc); i++; } while (!feof(fenc)); // reads part of decrypted text from file test.bin
	fclose(fenc);
	testlen=i-1;
	fenc=fopen("res.bin","wb");
	for (i=0;i<115-testlen;i++)
	{
		k=true;
		for (j=0;j<testlen;j++)
		{
			res[j]=cenc[i+j] ^ test[j];
			if (res[j]<32) k=false; //checks res[j]  is typeable
		}
		if (k)
		{
			for (j=0;j<testlen;j++) { fputc(res[j],fenc); }
			for (j=testlen;j<16;j++) { fputc(0,fenc); } // aligns at 16 chars for easy reading
		}
	}
	fclose(fenc);
}
