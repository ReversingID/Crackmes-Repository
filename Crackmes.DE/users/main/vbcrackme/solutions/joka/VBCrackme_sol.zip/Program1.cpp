#include "stdio.h"

int main()
{
	char cenc[115], test[116], res[115];
	int testlen,i,j;
	FILE *fenc=fopen("encrypted.bin","rb");
	for (i=0;i<115;i++)	{ cenc[i]=fgetc(fenc); }
	fclose(fenc);
	fenc=fopen("pass.bin","rb");
	i=0;
	do { test[i]=fgetc(fenc); i++; } while (!feof(fenc));
	fclose(fenc);
	testlen=i-1;
	j=0;
	for (i=0;i<115;i++) // decryption loop
	{
		res[i]=cenc[i] ^ test[j];
		j++;
		if (j==testlen) j=0;
	}
	fenc=fopen("decrypted.bin","wb");
	for (i=0;i<115;i++) { fputc(res[i],fenc); }
	fclose(fenc);
}
