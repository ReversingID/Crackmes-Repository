VBCrackme by main
-----------------

The reason I did this in VB is because I wanted to see if it was possible.
Function pointers in VB :)

Your mission is to find the correct password which decrypts the encrypted data.
If you crack it, you will see the goodboy.

Good luck!