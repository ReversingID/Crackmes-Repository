VBCrackme 2
-----------

[ Author ]
main

[ Objective ]
Find the password which decrypts the correct code to 
set the correct variable!

Hint:
Command$


Good luck!

/* main */