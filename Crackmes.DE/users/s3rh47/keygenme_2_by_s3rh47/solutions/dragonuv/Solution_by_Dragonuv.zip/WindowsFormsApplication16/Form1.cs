﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace KeygenMaker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //this solution generates random passwords and stops only when the password meets the requirements
            Random rnd = new Random();
            int length = textBox1.Text.Length + 20; //why 20? because length of password = 23 minus 3 times "-" (minus)
            float sum;
            string tempPassword;
            do
            {
                tempPassword = "";
                sum = length;
                for (int i = 0; i < textBox1.Text.Length; i++)
                {
                    sum += Convert.ToInt16(textBox1.Text[i] * 0x10);
                }
                for (int i = 0; i < 20; i++)
                {
                    switch(rnd.Next(36))
                    {
                        case (0):
                            tempPassword += "0";
                            break;
                        case(1):
                            tempPassword += "1";
                            break;
                        case(2):
                            tempPassword += "2";
                            break;
                        case (3):
                            tempPassword += "3";
                            break;
                        case (4):
                            tempPassword += "4";
                            break;
                        case (5):
                            tempPassword += "5";
                            break;
                        case (6):
                            tempPassword += "6";
                            break;
                        case (7):
                            tempPassword += "7";
                            break;
                        case (8):
                            tempPassword += "8";
                            break;
                        case (9):
                            tempPassword += "9";
                            break;
                        case (10):
                            tempPassword += "A";
                            break;
                        case (11):
                            tempPassword += "B";
                            break;
                        case (12):
                            tempPassword += "C";
                            break;
                        case (13):
                            tempPassword += "D";
                            break;
                        case (14):
                            tempPassword += "E";
                            break;
                        case (15):
                            tempPassword += "F";
                            break;
                        case (16):
                            tempPassword += "G";
                            break;
                        case (17):
                            tempPassword += "H";
                            break;
                        case (18):
                            tempPassword += "I";
                            break;
                        case (19):
                            tempPassword += "J";
                            break;
                        case (20):
                            tempPassword += "K";
                            break;
                        case (21):
                            tempPassword += "L";
                            break;
                        case (22):
                            tempPassword += "M";
                            break;
                        case (23):
                            tempPassword += "N";
                            break;
                        case (24):
                            tempPassword += "O";
                            break;
                        case (25):
                            tempPassword += "P";
                            break;
                        case (26):
                            tempPassword += "Q";
                            break;
                        case (27):
                            tempPassword += "R";
                            break;
                        case (28):
                            tempPassword += "S";
                            break;
                        case (29):
                            tempPassword += "T";
                            break;
                        case (30):
                            tempPassword += "U";
                            break;
                        case (31):
                            tempPassword += "V";
                            break;
                        case (32):
                            tempPassword += "W";
                            break;
                        case (33):
                            tempPassword += "X";
                            break;
                        case (34):
                            tempPassword += "Y";
                            break;
                        case (35):
                            tempPassword += "Z";
                            break;
                    }
                    sum += Convert.ToInt16(tempPassword[i] * 0x10);
                }
            } while (sum / length != (int)sum / length);
            tempPassword = tempPassword.Substring(0, 15) + "-" + tempPassword.Substring(15);
            tempPassword = tempPassword.Substring(0, 10) + "-" + tempPassword.Substring(10);
            tempPassword = tempPassword.Substring(0, 5) + "-" + tempPassword.Substring(5);
            textBox2.Text = tempPassword;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
