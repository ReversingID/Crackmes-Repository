//	Keygen for s3rh47's KeyGenMe 4
//	http://crackmes.de/user/s3rh47/keygenme_4_by_s3rh47/
//
//	Level: 2
//	Language: Assembler (RadASM)
//	Published:	August 10, 2010
//
//
//	By RiskyMethodz
//	August 11, 2010

#include <iostream>
#include <string>

using namespace std;

const string KEYCHARS = "Q1WE2RT3ZU4IO5PA6SD7FG8HJ9KL0YXCVBNMQ1WE2RT3ZU4IO5PA6SD7FG8HJ9KL0YXCVBNM";

// For calculateKey:
//	Takes the given seed (which is modified for future use) and returns a number from 0-35
unsigned short getKeyOffset(unsigned int &seed)
{
	if(seed & 0x80000000)
	{
		seed += 0x7FFFFFFF;
	}
	unsigned int div1 = seed / 0x1F31D;
	unsigned int mul1 = div1 * 0x0B14;
	seed = (seed % 0x1F31D) * 0x41A7;
	seed -= mul1;
	return (seed % 0x24);
}

// Calculate the internal key string, given the entered username
string calculateKey(string username)
{
	if(username == "")
	{
		return "";
	}

	// Calculate the initial seed for our offset calculation
	unsigned int seed = 0;
	for(int i = 0; i < username.length(); ++i)
	{
		seed += username[i] * (username.length() - i);
	}

	// Generate a 24 character string for our key
	string key("");
	for(int i = 0; i < 24; ++i)
	{
		int offset = getKeyOffset(seed);
		key += KEYCHARS[offset];
	}

	// Place our hyphens
	if(key.length() != 24)
	{
		return "";
	}
	key[4] = '-';
	key[9] = '-';
	key[14] = '-';
	key[19] = '-';

	return key;
}

// Takes the given internally created nameKey and generates
//	the final Key which will validate on the main form
string reverseKey(string nameKey)
{
	if(nameKey == "")
	{
		return "<REVERSEKEY> INVALID INPUT (NULL INPUT)";
	}

	// Strip hyphens and check useful size
	string key("");
	for(int i = 0; i < nameKey.length(); ++i)
	{
		if(nameKey[i] != '-')
		{
			key += nameKey[i];
		}
	}
	// There ought to have been 20 meaningful characters
	if(key.length() != 20)
	{
		return "<REVERSEKEY> INVALID INPUT (WRONG POST-DEHYPHENATED LENGTH)";
	}

	// Now translate the key characters by shifting left 18 places among valid KEYCHARS
	//	Because the character 'loop' in KEYCHARS appears twice, we should always be be able to
	//	search starting at the end, and always rfind a match at a position more than 18 characters 
	//	deep into the array. If we do not, then the character is not valid for our key.
	for(int i = 0; i < key.length(); ++i)
	{
		string::size_type pos = string::npos;
		pos = KEYCHARS.rfind(key[i]);
		if(pos == string::npos || pos < 18)
		{
			return "<REVERSEKEY> INVALID KEY CHARACTER FOUND: " + key[i];
		}
		else
		{
			key[i] = KEYCHARS[pos - 18];
		}
	}

	// Undo the string reversal/BSWAP/Jumble
	//	Magic numbers only safe because we checked for length 20 earlier
	string group1 = key.substr(0, 4);
	string group2 = key.substr(4, 4);
	string group3 = key.substr(8, 4);
	string group4 = key.substr(12, 4);
	string group5 = key.substr(16, 4);
	// Reorganize the pieces of the key appropriately
	key = group3 + group4 + group1 + group5 + group2;

	// Hyphenate our key
	for(int i = 0; i < key.length(); ++i)
	{
		// Every 5th place should be a hyphen. Magic number 5 used for this purpose.
		if((i + 1) % 5 == 0)
		{
			key = key.substr(0, i) + '-' + key.substr(i);
		}
	}


	return key;
}


int main(int argc, char **argv)
{
	cout << "KeyGen for s3rh47's KeygenMe4" << endl;
	cout << "\thttp://crackmes.de/user/s3rh47/keygenme_4_by_s3rh47/" << endl;
	cout << endl << "By RiskyMethodz" << endl << endl << endl;
	cout << "Name: ";
	string username;
	getline(cin, username);

	string nameKey = calculateKey(username);
	string key = reverseKey(nameKey);

	cout << "Key: " << key << endl;
	return 0;
}