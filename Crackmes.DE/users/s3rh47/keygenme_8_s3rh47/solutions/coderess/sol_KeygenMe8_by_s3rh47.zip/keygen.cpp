/********************************************************************************************/
/* keygen.cpp 
* 
*  Compile................MSVS6
*  Language...............C/C++
*  Programm...............Keygen for KeygenMe 2 by s3rh47
*  Year...................2010
* 
*********************************************************************************************/

#include <windows.h>

#include "resource.h"

#include "AggressiveOptimize.h"


HINSTANCE hInstance;
HWND hWnd;
HICON hIcon;

CHAR lpName[25];
CHAR buf[25];

#define ABOUT_TEXT	"Keygen for KeygenMe 2 by s3rh47\nWriten by Coderess"
#define ABOUT_CAPT	"About"
#define XOR			^

BOOL CALLBACK KeygenProc(HWND hWnd)
{
	ULARGE_INTEGER lpFreeBytesAvailable;
	ULARGE_INTEGER lpTotalNumberOfBytes;

	CHAR lpVolumeNameBuffer[MAX_PATH], lpFileSystemNameBuffer[MAX_PATH];
	DWORD lpVolumeSerialNumber, lpMaximumComponentLength, lpFileSystemFlags;

	// Getting HWID

	GetDiskFreeSpaceEx("C:\\", &lpFreeBytesAvailable, &lpTotalNumberOfBytes, NULL);

	CHAR buf[25];
	_itoa(lpTotalNumberOfBytes.LowPart, buf, 16);
	SetDlgItemText(hWnd, IDC_EDIT3, buf);

	
	GetVolumeInformation(NULL, lpVolumeNameBuffer, sizeof(lpVolumeNameBuffer),
						 &lpVolumeSerialNumber, &lpMaximumComponentLength, 
						 &lpFileSystemFlags, lpFileSystemNameBuffer,
						 sizeof(lpFileSystemNameBuffer));

	_itoa(lpVolumeSerialNumber, buf, 16);
	SetDlgItemText(hWnd, IDC_EDIT4, buf);

	DWORD HWID = lpTotalNumberOfBytes.LowPart XOR lpVolumeSerialNumber;

	wsprintf(buf, "%X", HWID);

	// paste delimiter '-'
	CHAR buf1[25];
	for (int x=0; x<4; x++)
	{
		buf1[x] = buf[x];
	}	
	buf1[x]='-';

	for (x=4; x<8; x++)
	{
		buf1[x+1] = buf[x];
	}	
	buf1[x+1]='\0';
	SetDlgItemText(hWnd, IDC_EDIT5, buf1);

	// Calculate key

	ULONG nLen = GetDlgItemText(hWnd, IDC_EDIT1, lpName, 25); 
	if (nLen == 0 ) {
		MessageBox(0,"Please enter name","Error",0);
			return (TRUE);
	}

	__int64 st0 = 0;
	DWORD dw1 = 0, Sum = 0, Esp = 0;
	PCHAR lpHWID = buf1, Ptr1 = lpName;
	DWORD Counter = 0x1388;

	for (int i=0; Counter; i++)
	{
metka1:
		Sum = 0;
		Sum = (BYTE)*lpHWID; 
		lpHWID++;
		if (Sum==0)
		{
			lpHWID = buf1;
			goto metka1;
		}

		if (Sum=='-')
		{
			goto metka1;
		}

		dw1 = Sum;

		{
metka3:
			Sum = (BYTE)*Ptr1; 
			Ptr1++;
			if (Sum != 0)
			{
				goto metka2;
			}

			Ptr1 = lpName;
			goto metka3;
		}
metka2:

		Sum = Sum XOR dw1;
		Sum = Sum * Counter;
		Esp = Sum;

		st0 = st0 + Esp;

		if (Counter == 0x5DC || Counter == 0x2EE || Counter == 0x145)
		{
			goto metka4;
		}

		
		if (Counter != 0x64)
		{
			goto metka5;
		}

metka4:
		dw1 = 0x1988;
		Sum = Sum * dw1;
		Esp = Sum;
		st0 = st0 + Esp;

metka5:
		Esp = Counter;
		st0 = st0 + Esp;
		Counter--;
	}

	st0 = st0 - 0x0BEC5E4;
	wsprintf(buf, "%u", st0);

	SetDlgItemText(hWnd, IDC_EDIT2, buf);

	return (TRUE);
}

BOOL CALLBACK DlgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg){
	

	case WM_CLOSE:
		EndDialog(hWnd, 0);
		break;

	case WM_COMMAND:
		switch (wParam)
		{
			// Gen. key
			case IDC_BUTTON1:
				KeygenProc(hWnd);
				break;
				
			// About
			case IDC_BUTTON3:
				MessageBox(hWnd, ABOUT_TEXT, ABOUT_CAPT, MB_ICONINFORMATION | MB_OK);
				break;

			// Exit
			case IDC_BUTTON2:
				EndDialog(hWnd, 0);
				break;
			}
		break;
		}


	return FALSE;
}


int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{		
	DialogBoxParam(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_DIALOG1), 0, (DLGPROC)DlgProc, 0);

	return (0);
}

