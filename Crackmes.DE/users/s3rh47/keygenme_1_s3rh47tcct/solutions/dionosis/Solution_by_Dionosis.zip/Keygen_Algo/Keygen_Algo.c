
/*
================================
  [ KeygenMe-1 by s3rh47/TccT ]

   Solution by Dionosis
   November  9, 2009

   Dionosis.RE@gmail.com
================================
*/


#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "md5.c"

// If method=1, random password is generated. Otherwise, basic password is generated.
int Getpassword( char *nameEntered, char password[20], int method)
{
	int i, name_s;
	char name[256], passPart[5], altEnd[4]= "DIO";
	char carsTab[37]= "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	unsigned long int sum;

	md5_state_t MD5_Context;
	md5_byte_t md5_hash[16];


	// Get nameEntered length
	name_s= strlen( nameEntered);

	// No name entered
	if( name_s<1)  {
		return -1;
	}

	// Copy the name and add "TccT"
	strcpy( name, nameEntered);
	strcat( name, "TccT");

	name_s+= 4;

	// Computing md5
	md5_init(&MD5_Context);
	md5_append(&MD5_Context, (const md5_byte_t*)name, name_s);
	md5_finish(&MD5_Context, md5_hash);

	// If alternative password
	if( method==1)	{
		for( i=0; i<2; i++)  {
			sum= *((unsigned short int*)(md5_hash+(i*8)+2)) + *((unsigned short int*)(md5_hash+(i*8)+6));

			*((unsigned short int*)(md5_hash+(i*8)+2))= (unsigned short int)(0x10000*((double)rand()/0x7FFF));
			*((unsigned short int*)(md5_hash+(i*8)+6))= (unsigned short int) sum - *((unsigned short int*)(md5_hash+(i*8)+2));
		}
	}

	// Forming ascii password asked
	password[0]= 0;

	for( i=2; i<=14; i+=4)	{
		// wsprintf is a very bad and slow shortcut solution, but in our case it's sufficient and anyway it's easily replaceable if needed
		wsprintf( passPart, "%02X%02X", md5_hash[i], md5_hash[i+1]);
		strcat( password, passPart);
	}

	// If alternative password asked
	if( method==1)	{
		for( i=0; i<3; i++)  {
		    altEnd[i]= carsTab[(int)(0x24*((double)rand()/0x7FFF))];
		}
	}

	// Adding end chars
	strcat( password, altEnd);


    return 0;
}


int main( int argc, char *argv[])
{
	char nameEntered[]= "Dionosis";
	char password[20];


	srand( time(0));

	printf("\r\n Passwords for '%s' :\r\n", nameEntered);

	// Basic password
	Getpassword( nameEntered, password, 0);
	printf( "\r\n    > Basic password :       %s\r\n", password);

	// Random password
	Getpassword( nameEntered, password, 1);
	printf( "\r\n    > Random password :      %s\r\n", password);

    printf("\r\n\n ");
	system("pause");


	return 0;
}
