#include <cstdlib>
#include <cstdio>
#include <cctype>

#include <windows.h>
#include <tchar.h>

#include <algorithm>
#include <iostream>
#include <fstream>
#include <string>

// set to 1 if you want to generate seed
#define GEN_SEED 1

std::string g_charset = "0123456789qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM";
DWORD g_seed;

#ifndef GET_DWORD
#define GET_DWORD(p) (*(DWORD *)((p)))
#endif // !GET_DWORD

inline unsigned __int32 rol(unsigned __int32 operand, unsigned __int8 width)
{
	__asm {
		mov eax, operand
			mov cl, width
			rol eax, cl
	}
}

inline unsigned __int32 ror(unsigned __int32 operand, unsigned __int8 width)
{
	__asm {
		mov eax, operand
			mov cl, width
			ror eax, cl
	}
}

void findFirstSeed()
{
	WORD tab[4] = { 0 };
	std::cout << "Started searching for first seed... " << std::endl;
	for (DWORD i = 0; i < 0xFFFFFFFF; i++)
	{
		srand(i);
		int total = 4;
		memset(tab, 0, sizeof(tab));
		for (;;)
		{
			int idx = rand() % 4;
			if (tab[idx] == 0)
			{
				tab[idx] = static_cast<WORD>(rand());
				if (--total == 0)
					break;
			}
		}
		WORD x = static_cast<WORD>(rand());
		for (int a = 0; a < 4; a++)
		{
			tab[a] ^= x;
		}
		if (tab[0] == 0x1253 && tab[1] == 0x79A9 && tab[2] == 0x6E2D && tab[3] == 0x519E)
		{
			DWORD second = g_seed ^ x;
			std::cout << "Found first seed: " << std::hex << i << ", second: " << std::hex << second << std::endl;
		}
	}
	return;
}

void findSecondSeed()
{

	WORD cv[4] = { 0 };
	std::cout << "Started searching for second seed... " << std::endl;
	for (auto x : g_charset)
	{
		for (int i = 0; i < 0x10000; i++)
		{
			DWORD seed = (x << 16) | i;
			srand(seed);
			int total = 4;
			memset(cv, 0, sizeof(cv)*sizeof(WORD));
			for (;;)
			{
				int idx = rand() % 4;
				if (cv[idx] == 0)
				{
					cv[idx] = static_cast<WORD>(rand());
					if (--total == 0)
						break;
				}
			}
			total = rand();
			total = rand();
			for (int j = 0; j < 4; j++)
				cv[j] ^= total;

			if (cv[0] == 0x3C0E &&
				cv[1] == 0x3AD1 &&
				cv[2] == 0x0B07 &&
				cv[3] == 0x3626
				)
			{
				std::cout << "Found seed: " << std::hex << seed << std::endl;
				g_seed = seed;
			}
		}
	}
}

std::string generateSecondKey(std::string name)
{
	char nBuff[0x15];
	char serial[0x15];
	memset(nBuff, 0, sizeof(nBuff));
	memset(serial, 0, sizeof(serial));
	memcpy(nBuff, name.c_str(), name.length());

	DWORD n1 = rol(GET_DWORD(&nBuff[0]) + GET_DWORD(&nBuff[4]), nBuff[8]);
	n1 = ror(n1, nBuff[0x0C]) ^ GET_DWORD(&nBuff[0x10]);
	n1 = n1 ^ 0xC1A01234; // must be our value

	srand(GetTickCount());
	serial[8] = serial[12] = g_charset[rand() % g_charset.length()];
	serial[9] = 'T';
	serial[10] = 'e';
	serial[11] = 'o';
	DWORD n2 = 0;
	BYTE *p = (BYTE*)(&n1);
	BYTE *b = (BYTE*)(&n2);
	BYTE g[4];

	for (int i = 3; i >= 0; i--)
	{
		for (auto x : g_charset)
		{
			BYTE c = g[i] = p[i] ^ x;
			if (c >= 0x60 && c <= 0xF4)
			{
				serial[16 + i] = b[i] = x;
				break;
			}
		}
	}

	serial[13] = g_charset[rand() % g_charset.length()];
	serial[14] = g_charset[rand() % g_charset.length()];
	serial[15] = g_charset[rand() % g_charset.length()];

	int cnt = 3;
	for (;;)
	{
		for (auto a : g_charset)
		{
			for (auto b : g_charset)
			{
				if ((a + b) == g[cnt])
				{
					serial[cnt] = a;
					serial[cnt + 4] = b;
					cnt--;
					break;
				}
			}
			if (cnt < 0)
				break;
		}
		if (cnt < 0)
			break;
	}
	return serial;
}

void convert(BYTE *ptrSource, int lStr)
{
	BYTE *p;
	char c;

	p = ptrSource;
	for (;;)
	{
		c = '%';
		if (!lStr)
			break;
		while ((*p > 57 || *p < 48) && (*p > 90 || *p < 65) && (*p > 122 || *p < 97))
			*p += c++;
		++p;
		--lStr;
	}
}

std::string generateFirstKey(std::string sname)
{
	char keyx[0x15];
	memset(keyx, 0, sizeof(keyx));
	memcpy(keyx, sname.c_str(), sname.length());

	keyx[0] = keyx[0] ^ 0x5C ^ static_cast<char>(sname.length());
	char *b = &keyx[1];
	char *e = &keyx[sname.length() - 1];
	while (b < e)
	{
		*b = *b ^ *e;
		b++;
		e--;
	}
	e = &keyx[sname.length()];
	BYTE cnt = 0;
	while (b < e)
	{
		*b = *b ^ (keyx[0] + cnt++);
		b++;
	}
	convert(reinterpret_cast<BYTE *>(keyx), sname.length());
	return std::string(keyx);
}

bool isAlphanumeric(const std::string &str)
{
	return find_if(str.begin(), str.end(), [](char c) { return !(isalnum(c)); }) == str.end();
}

int _tmain(int argc, _TCHAR* argv[])
{
	(void)argc;
	(void)argv;
#if GEN_SEED
	findSecondSeed();
	findFirstSeed();
#endif
	std::string username;
	std::cout << "Enter the name (between 4 and 20 characters long): ";
	std::cin >> username;
	if (username.length() < 4 || username.length() > 20)
	{
		std::cout << "Name is too short or too long!";
		return 0;
	}
	if (!isAlphanumeric(username))
	{
		std::cout << "Name must consist of only alphanumeric characters...";
		return 0;
	}
	std::ofstream keyfile("TheKey.k");
	keyfile << username << std::endl;
	keyfile << generateFirstKey(username) << std::endl;
	keyfile << generateSecondKey(username);
	return 0;
}
