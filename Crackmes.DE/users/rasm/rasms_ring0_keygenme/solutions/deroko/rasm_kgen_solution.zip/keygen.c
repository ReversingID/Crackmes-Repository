#include        <windows.h>
#include        <stdio.h>


//for mp systems routine is quite different as 1st cpu will wait for second
//cpu to calculate serial. Calculation is quite similar, eg. same algo, except
//instead of adding 0x30 to ah and al, it adds 0x32, and that's it...
unsigned  long keygen(char *argv){
        char serial_name_generated_key[20];;
        unsigned long first_4bytesofusername;
        first_4bytesofusername = *(unsigned long *)argv;
        memset(serial_name_generated_key, 0, 20);
        
        __asm{
                 xor     ecx, ecx
loc_107B6:
                 xor     eax, eax
                 cmp     ecx, 4
                 jz      short loc_107E6
                 lea     edx, first_4bytesofusername
                 mov     al, [edx+ecx]
                 lea     edx, serial_name_generated_key
                 shl     eax, 4
                 and     ah, 7
                 add     ah, 30h
                 mov     [edx+ecx*2], ah
                 shr     eax, 4
                 and     al, 7
                 add     al, 30h
                 mov     [edx+ecx*2+1], al
                 inc     ecx
                 jmp     short loc_107B6
loc_107E6:
        }
        printf("%s\n", serial_name_generated_key);
}

int main(int argc, char **argv){
        unsigned long serial;
        
        if (argc != 2){
                printf("Usage : keygen.exe <username>\n");
                return 0;
        }
        
        if (strlen(argv[1]) < 4){
                printf("Username has to be at least 4 chars\n");
                return 0;
        }
        
        keygen(argv[1]);

}
        