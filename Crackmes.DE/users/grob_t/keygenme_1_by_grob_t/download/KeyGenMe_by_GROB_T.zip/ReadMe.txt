It's my first KeyGenMe
If name and password correct, appears the message "Valid password" differently "Wrong password"