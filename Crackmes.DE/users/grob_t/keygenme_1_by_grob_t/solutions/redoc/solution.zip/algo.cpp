
#undef UNICODE
#undef _UNICODE
#include <windows.h>

void Generate ();

DWORD ebp_14_Idxs[4] = {0,3,6,9};
DWORD ebp_18_Idxs[4] = {5,8,11,2};
DWORD ebp_1c_Idxs[4] = {10,1,4,7};

//----------------------------------------
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	Generate();
	return (0);
}

//----------------------------------------
void Generate()
{
	DWORD i, eax, edx, ebp_14, ebp_18, ebp_1c;
	DWORD dwSerialHash1, dwSerialHash2, dwSerialHash3;
	char szName[13]="GROB_T";

	DWORD dwLen = lstrlen (szName);

	for (i=dwLen; i<12; i++)
		szName[i] = szName[i%dwLen];
	
	//////////////////////////////////////////////////////////////////////
	char szSerial[37] = "882882882882882882882882882882882882";

	for (DWORD Idx=0; Idx<4; Idx++)
	{
		ebp_14 = szName[ebp_14_Idxs[Idx]];	// 0,3,6,9
		ebp_18 = szName[ebp_18_Idxs[Idx]];	// 5,8,11,2
		ebp_1c = szName[ebp_1c_Idxs[Idx]];	// 10,1,4,7

		dwSerialHash1 = dwSerialHash2 = dwSerialHash3 = -0x88;

		eax = dwSerialHash1 + dwSerialHash2;
		edx = szSerial[9*Idx + 2] - '0';
		eax += (edx & 1);

		if ((ebp_14^eax) & 1)		// ...(ebp_14^eax) must be even
			szSerial[9*Idx + 2] += 1;

		eax = dwSerialHash2 + dwSerialHash3;
		edx = szSerial[9*Idx + 5] - '0';
		eax += (edx & 1);

		if ((ebp_18^eax) & 1)		// ...(ebp_18^eax) must be even
			szSerial[9*Idx + 5] += 1;

		eax = dwSerialHash1 + dwSerialHash3;
		edx = szSerial[9*Idx + 8] - '0';
		eax += (edx & 1);

		if ((ebp_1c^eax) & 1)		// ...(ebp_1c^eax) must be even
			szSerial[9*Idx + 8] += 1;
	}

	// ... szSerial now contains valid serial
}
