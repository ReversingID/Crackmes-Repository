#include <stdio.h>
#include "miracl.h"

#pragma comment(lib,"ms32.lib")

	unsigned char bytes_EP1x[2] = {0x6A, 0x42};
	unsigned char bytes_EP1y[20] = {
	0x60, 0x41, 0xAA, 0x60, 0x1D, 0x01, 0x5B, 0xD7, 
	0x54, 0xE0, 0x01, 0xC0, 0xE0, 0xA2, 0xA1, 0xCB, 
	0xAA, 0x62, 0xF2, 0xC7};
	unsigned char bytes_EP2x[20] = {
	0x7A, 0x7E, 0xDF, 0x4D, 0xF9, 0xA0, 0x60, 0x83,
	0xF2, 0x2D, 0xE6, 0x1C, 0xE3, 0x39, 0xA8, 0x68, 
	0x15, 0xE0, 0x8B, 0x2C};
	unsigned char bytes_EP2y[20] = {
	0x4A, 0x68, 0xC3, 0x52, 0x65, 0x4B, 0x41, 0x77, 
	0xD5, 0xD1, 0x8F, 0xBB, 0x74, 0x75, 0x1B, 0x77, 
	0x09, 0xD0, 0xA3, 0x6D};

	unsigned char sza[]="3A5C2EA6DBC2B8743BCC7F8E41D5C014247BC269";
	unsigned char szb[]="330B45FB89841E4FB9EFC5E1F0D1FC18A55853A4";
	unsigned char szp[]="86ED17A02A08E5EBD2B428612B10BA391C803FDF";
	unsigned char szn[]="86ED17A02A08E5EBD2B428612B10BA391C803FDF";

	unsigned char pri_key[100]={0};
void SmartASS()
{
	/*
	here I will initialize a new Elliptic Curve in miracl workspace
	E:a,b,p,n
	SmartAss steps are described in  N. Kunihiro and K. Koyama 's paper
	0. set j=0 
	1. set the lifting curve E (j) : y^2 = x^3 + (a+j*p)*x + b mod p^2
	2. set the lifting point 
			G(Gx,Gy)	lifted to  (Gx,Gy+w1*p)  
			Q(Qx,Qy)    lifted to  (Qx,Qy+w2*p) 
			where:
			w1,2=(x^3+(a+j*p)*x+b-y^2)/(2*y*p) mod p
	3. calculat ph() of lifted point
	4. if gcd(ph(G),p)==1
			private key:ph(Q)/ph(G) mod p
		else
			goto step0 and j++
	*/

	miracl *mip;
	big a,b,p,n,Gx,Gy,Qx,Qy,j,cof2,p2,w1,w2,Gx2,Gy2,Qx2,Qy2;
	big t1,t2,t3,t4,t5,tt1,tt2,tt3;
	big ph1,ph2;
	epoint * G2,* Q2;

	mip=mirsys(500,16);
	mip->IOBASE=16;

	a=mirvar(0);
	b=mirvar(0);
	p=mirvar(0);
	n=mirvar(0);
	Gx=mirvar(0);
	Gy=mirvar(0);
	Qx=mirvar(0);
	Qy=mirvar(0);
	cinstr(a,sza);
	cinstr(b,szb);
	cinstr(p,szp);
	cinstr(n,szn);
	bytes_to_big(2,bytes_EP1x,Gx);
	bytes_to_big(20,bytes_EP1y,Gy);
	bytes_to_big(20,bytes_EP2x,Qx);
	bytes_to_big(20,bytes_EP2y,Qy);
	t1=mirvar(0);
	t2=mirvar(0);
	t3=mirvar(0);
	t4=mirvar(0);
	t5=mirvar(0);
	tt1=mirvar(0);
	tt2=mirvar(0);
	tt3=mirvar(0);
	ph1=mirvar(0);
	ph2=mirvar(0);

	//Step 0.
	//j=0
	j=mirvar(0);
	cof2=mirvar(0);
	w1=mirvar(0);
	w2=mirvar(0);
	p2=mirvar(0);
	multiply(p,p,p2);
	Gx2=mirvar(0);
	Gy2=mirvar(0);
	Qx2=mirvar(0);
	Qy2=mirvar(0);


	//Step 1.
	//Set Elliptic Curve over Z/n^2Z
//====================================================================================

	copy(p,cof2);
	multiply(cof2,j,cof2);
	add(cof2,a,cof2);
	ecurve_init(cof2,b,p2,MR_PROJECTIVE);
	//Step 2.
	//lift points 
//====================================================================================
	G2=epoint_init();
	Q2=epoint_init();
	copy(Gx,Gx2);
	copy(Gy,Gy2);
	copy(Qx,Qx2);
	copy(Qy,Qy2);
	//calculate w for point G
	multiply(Gx,Gx,t1);
	multiply(t1,Gx,t1);
	copy(Gx,t2);
	multiply(cof2,t2,t2);
	copy(Gy,t3);
	multiply(t3,t3,t3);
	add(t1,t2,t2);
	add(t2,b,t2);
	subtract(t2,t3,t1);
	divide(t1,p,w1);
	premult(Gy,2,t4);
	xgcd(t4,p,t4,t4,t4);
	multiply(w1,t4,w1);
	divide(w1,p,p);
	add(w1,p,w1);
	divide(w1,p,p);
	multiply(w1,p,w1);
	add(Gy2,w1,Gy2);
	//calculate w for point Q
	multiply(Qx,Qx,t1);
	multiply(t1,Qx,t1);
	copy(Qx,t2);
	multiply(cof2,t2,t2);
	copy(Qy,t3);
	multiply(t3,t3,t3);
	add(t1,t2,t2);
	add(t2,b,t2);
	subtract(t2,t3,t1);
	divide(t1,p,w2);
	premult(Qy,2,t4);
	xgcd(t4,p,t4,t4,t4);
	multiply(w2,t4,w2);
	divide(w2,p,p);
	add(w2,p,w2);
	divide(w2,p,p);
	multiply(w2,p,w2);
	add(Qy2,w2,Qy2);
	epoint_set(Gx2,Gy2,1,G2);
	epoint_set(Qx2,Qy2,1,Q2);
	//Step 3.
	//calculate PH()
//===============================================================================
	decr(p,1,t1);
	ecurve_mult(t1,G2,G2);
	ecurve_mult(t1,Q2,Q2);
	epoint_get(G2,t2,t3);
	epoint_get(Q2,t4,t5);

	subtract(t2,Gx2,tt1);
	divide(tt1,p,tt1);
	subtract(t3,Gy2,tt2);
	xgcd(tt2,p,tt2,tt2,tt2);
	multiply(tt1,tt2,tt3);
	divide(tt3,p,p);
	add(tt3,p,tt3);
	divide(tt3,p,p);
	subtract(p,tt3,ph1);

	subtract(t4,Qx2,tt1);
	divide(tt1,p,tt1);
	subtract(t5,Qy2,tt2);
	xgcd(tt2,p,tt2,tt2,tt2);
	multiply(tt1,tt2,tt3);
	divide(tt3,p,p);
	add(tt3,p,tt3);
	divide(tt3,p,p);
	subtract(p,tt3,ph2);
	//Step 4.
//================================================================================
	copy(ph1,t1);
	xgcd(t1,p,t1,t1,t1);
	multiply(t1,ph2,t1);
	divide(t1,p,p);
	cotstr(t1,pri_key);
	printf("Private Key is %s\n",pri_key);

	mirkill(a);
	mirkill(b);
	mirkill(p);
	mirkill(n);
	mirkill(Gx);
	mirkill(Gy);
	mirkill(Qx);
	mirkill(Qy);
	mirkill(j);
	mirkill(cof2);
	mirkill(p2);
	mirkill(w1);
	mirkill(w2);
	mirkill(Gx2);
	mirkill(Gy2);
	mirkill(Qx2);
	mirkill(Qy2);
	mirkill(t1);
	mirkill(t2);
	mirkill(t3);
	mirkill(t4);
	mirkill(t5);
	mirkill(tt1);
	mirkill(tt2);
	mirkill(tt3);
	mirkill(ph1);
	mirkill(ph2);
	epoint_free(G2);
	epoint_free(Q2);
	mirexit();

}

void main()
{

	SmartASS();
}