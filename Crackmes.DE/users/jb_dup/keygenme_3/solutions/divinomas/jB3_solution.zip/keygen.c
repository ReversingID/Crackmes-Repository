#include <miracl.h>
#include <windows.h>
#include <time.h>
#include "resource.h"

HINSTANCE hInst;

	unsigned char bytes_EP1x[2] = {0x6A, 0x42};
	unsigned char bytes_EP1y[20] = {
	0x60, 0x41, 0xAA, 0x60, 0x1D, 0x01, 0x5B, 0xD7, 
	0x54, 0xE0, 0x01, 0xC0, 0xE0, 0xA2, 0xA1, 0xCB, 
	0xAA, 0x62, 0xF2, 0xC7};
	unsigned char bytes_EP2x[20] = {
	0x7A, 0x7E, 0xDF, 0x4D, 0xF9, 0xA0, 0x60, 0x83,
	0xF2, 0x2D, 0xE6, 0x1C, 0xE3, 0x39, 0xA8, 0x68, 
	0x15, 0xE0, 0x8B, 0x2C};
	unsigned char bytes_EP2y[20] = {
	0x4A, 0x68, 0xC3, 0x52, 0x65, 0x4B, 0x41, 0x77, 
	0xD5, 0xD1, 0x8F, 0xBB, 0x74, 0x75, 0x1B, 0x77, 
	0x09, 0xD0, 0xA3, 0x6D};

	unsigned char sza[]="3A5C2EA6DBC2B8743BCC7F8E41D5C014247BC269";
	unsigned char szb[]="330B45FB89841E4FB9EFC5E1F0D1FC18A55853A4";
	unsigned char szp[]="86ED17A02A08E5EBD2B428612B10BA391C803FDF";
	unsigned char szn[]="86ED17A02A08E5EBD2B428612B10BA391C803FDF";

	unsigned char pri_key[100]={0};

BOOL CALLBACK DlgProc (HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	big a,b,p,n,Gx,Gy,Qx,Qy,bt1,bt2;
	epoint * G,* Q,* T;
	big pk,r;
	big sign1,sign2;
	miracl *mip;
	sha sh;
	int lenName;
	int i;
	BYTE len_sign1=0,len_sign2=0;
	unsigned char szName[64]={0};
	unsigned char hash[20]={0},hash1[20]={0};
	unsigned char tmp1[21]={0},tmp2[43]={0};
	unsigned char szSerial[100]={0};
switch (uMsg){
   case WM_CLOSE:
		EndDialog(hWnd,0);
		break;

   case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDC_Exit:
			EndDialog(hWnd,0);
		break;

		case IDC_Generate:
	lenName=GetDlgItemText(hWnd,IDC_Name, szName, 63);
	if(lenName<4)
	{
		SetDlgItemText(hWnd,IDC_Serial,"Let me know your name!");
		break;
	}

	mip=mirsys(500,16);
	mip->IOBASE=16;

	a=mirvar(0);
	b=mirvar(0);
	p=mirvar(0);
	n=mirvar(0);
	Gx=mirvar(0);
	Gy=mirvar(0);
	Qx=mirvar(0);
	Qy=mirvar(0);
	bt1=mirvar(0);
	bt2=mirvar(0);
	cinstr(a,sza);
	cinstr(b,szb);
	cinstr(p,szp);
	cinstr(n,szn);
	bytes_to_big(2,bytes_EP1x,Gx);
	bytes_to_big(20,bytes_EP1y,Gy);
	bytes_to_big(20,bytes_EP2x,Qx);
	bytes_to_big(20,bytes_EP2y,Qy);

	ecurve_init(a,b,p,MR_PROJECTIVE);
	G=epoint_init();
	Q=epoint_init();
	T=epoint_init();
	epoint_set(Gx,Gx,1,G);
	epoint_set(Qx,Qx,1,Q);
	
	pk=mirvar(0);
	cinstr(pk,"21043BADFD4715E6F8221311B09652B4E1");

	irand(time(0));
	r=mirvar(0);
	bigrand(p,r);
	ecurve_mult(r,G,T);
	epoint_get(T,bt1,bt2);
	big_to_bytes(20,bt1,hash,1);
	shs_init(&sh);
	for(i=0;i<20;i++)
		shs_process(&sh,hash[i]);
	shs_hash(&sh,hash);
	sign1=mirvar(0);
	bytes_to_big(20,hash,sign1);

	shs_init(&sh);
	for(i=0;i<20;i++)
	{
		shs_process(&sh,bytes_EP2x[i]);
		shs_process(&sh,bytes_EP2y[i]);
	}
	for(i=0;i<lenName;i++)
		shs_process(&sh,szName[i]);
	shs_hash(&sh,hash1);

	for(i=0;i<20;i++)
		hash[i]^=hash1[i];
	bytes_to_big(20,hash,bt1);
	divide(bt1,p,p);

	subtract(r,bt1,bt2);
	xgcd(pk,n,pk,pk,pk);
	multiply(bt2,pk,bt1);
	divide(bt1,p,p);
	add(bt1,p,bt1);
	divide(bt1,p,p);
	sign2=mirvar(0);
	copy(bt1,sign2);
	
	len_sign1=(BYTE)big_to_bytes(20,sign1,tmp1,1);
	memcpy(tmp2+1,tmp1,len_sign1);
	*tmp2=len_sign1;
	ZeroMemory(tmp1,21);
	len_sign2=(BYTE)big_to_bytes(20,sign2,tmp1,1);
	memcpy(tmp2+2+len_sign1,tmp1,len_sign2);
	*(tmp2+1+len_sign1)=len_sign2;
	bytes_to_big(len_sign1+len_sign2+2,tmp2,bt1);
	mip->IOBASE=64;
	cotstr(bt1,szSerial);

	mirkill(a);
	mirkill(b);
	mirkill(p);
	mirkill(n);
	mirkill(Gx);
	mirkill(Gy);
	mirkill(Qx);
	mirkill(Qy);
	mirkill(bt1);
	mirkill(bt2);
	mirkill(pk);
	mirkill(r);
	mirkill(sign1);
	mirkill(sign2);
	epoint_free(G);
	epoint_free(Q);
	epoint_free(T);

	SetDlgItemText(hWnd,IDC_Serial,szSerial);
	mirexit();
		break;
		}
		break;
	case WM_INITDIALOG:
		SendMessage(hWnd,WM_SETICON,ICON_BIG,(LPARAM) LoadIcon(hInst,MAKEINTRESOURCE(ICO_MAIN)));
        break;
}
return 0;
}

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,PSTR szCmdLine, int iCmdShow)
{

	hInst=hInstance;
	DialogBoxParam(hInstance,MAKEINTRESOURCE(DLG_MAIN),0,(DLGPROC)DlgProc,0);
	return 0;
}