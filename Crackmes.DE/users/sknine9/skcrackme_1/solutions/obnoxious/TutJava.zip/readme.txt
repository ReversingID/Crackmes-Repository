To run the keygen you might have to edit the path of the jre in the run.bat file. Of course you might do it some other way too.
For a different name just use the commandline argument i/p :)