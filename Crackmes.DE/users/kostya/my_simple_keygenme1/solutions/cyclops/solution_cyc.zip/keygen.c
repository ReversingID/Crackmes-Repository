/*
	KeyGen For [Kotsya's KeygenMe #1] By Cyclops
 	cyclops1428@yahoo.com
 */
#include<stdio.h>
#include<windows.h>
main()
{
	char name[0x14];
	char serial[0x19],dummy;
	int len=0,cnt=0;
	int r1=0,r2=0;
	int tmp=0,tmp1=0;
	int tmp2;
	memset(name,0,0x14);
	memset(serial,0,0x19);
	printf("Enter ur name :");
	fgets(name,0x13,stdin);
	name[strlen(name)-1]=0x00;
	len=strlen(name);
	__asm{
		xor ebx,ebx
	}
	while(cnt!=len)
	{
		dummy=name[cnt];
		__asm{
			mov bl,dummy
			mov tmp1,ebx
		}
		r1=r1*0x48-tmp1-0x6f;
		__asm mov ebx,r1
		r1=r1^0xBACAF;
		cnt++;
	}
	GetUserName(name,&cnt);
	cnt=0;
	tmp1=0;
	__asm{
		xor ebx,ebx
	}
	while(cnt!=len)
	{
		dummy=name[cnt];
		__asm{
			mov bl,dummy
			mov tmp1,ebx
		}
		r2=r2*0x48-tmp1-0x6f;
		__asm mov ebx,r2
		r2=r2^0xBACAF;
		cnt++;
	}
	tmp=r1;
	tmp^=r2;
	tmp^=0x0FFAC;
	tmp1=r2^0x553;
	tmp2=r1+tmp1;
	tmp1=tmp1+tmp;
	tmp1--;
	tmp2=tmp2+tmp1;
	sprintf(serial,"%8X%8X%8X",r2,tmp2,r1);
	serial[4]='-';
	serial[14]='-';
	serial[0]='K';
	serial[1]='O';
	serial[2]='S';
	printf("Serial :%s\n",serial);
	getchar();

}

