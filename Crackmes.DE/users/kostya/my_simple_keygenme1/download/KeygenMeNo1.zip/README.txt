

Author: Kostya
Level : Very easy - 1 - for newbies
=========================================================================


Hi! There!..It's my first keygenme (crackme). Here are some tasks you should do:
-------------------------------------------------------------------------
1. To start searching a key for your name, you need to patch something to enter 
   more than 1 symbol, (Patch it to 80 symbols) (no jne, je, & etc jump patching.)

2. Find key generator solution, and write a keygen

3. Patch it, to stop closing after the registration procedure
   (not allowed to patch jne, je, & etc "jump patching". (e.g: "jne" -> "je")
-------------------------------------------------------------------------
Exe file is not protected, and it is very easy to find key & to write a 
keygen. But no built-in keygens (injections). As u can see I made it for newbies...

__________________
P.s: Don't forget what i said: "no jump patching". :) 
Have fun!!! ;) THanx to crackmes.de