#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>



#define DOIT(x)     uint8_t a##x; \
                    for(a##x = 0; a##x < charsetsz; a##x++) {
#define charsetsz   sizeof(charset)   // includes NULL too



static const uint8_t charset[] =
            "0123456789"
            "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
            "abcdefghijklmnopqrstuvwxyz";



uint32_t power(uint32_t a, uint32_t b) {
    uint32_t    c;

    for(c = a; b; b--) {
        a *= c;
    }
    return(a);
}



int main(void) {
    uint32_t    table[15][charsetsz];
    uint32_t    sum,
                i,
                j;
    static const uint32_t key[15] = {
                0x538bec90, 0x5133c033, 0xc9b93702, 0x0000b854,
                0x534f4b35, 0x45204f53, 0x35205953, 0x41355441,
                0x48543548, 0x54204935, 0x204b4e49, 0x354c4120,
                0x55354320, 0x4f53352e, 0x49fe3499 };

    fputs("\n"
        "solution for Kostya's Mini-Crypto Math SerialMe:\n"
        "  http://www.crackmes.de/users/kostya/mini_crypto_math_serialme/\n"
        "by Luigi Auriemma\n"
        "e-mail: aluigi@autistici.org\n"
        "web:    aluigi.org\n"
        "\n", stdout);

    printf("- generate a 15x%d table of precalculated values\n", charsetsz);

    for(j = 0; j < 15; j++) {
        for(i = 0; i < charsetsz; i++) {
            table[j][i] = power(charset[i], 14 - j) * key[j];
        }
    }

    printf("- start brute forcing:\n");

    DOIT(0)
    DOIT(1)
    DOIT(2)
    DOIT(3)
    DOIT(4)
    DOIT(5)
    DOIT(6)
    DOIT(7)
    DOIT(8)
    DOIT(9)
    DOIT(10)
    DOIT(11)
    DOIT(12)
    DOIT(13)
    DOIT(14)
        sum =
            table[0][a0]   +
            table[1][a1]   +
            table[2][a2]   +
            table[3][a3]   +
            table[4][a4]   +
            table[5][a5]   +
            table[6][a6]   +
            table[7][a7]   +
            table[8][a8]   +
            table[9][a9]   +
            table[10][a10] +
            table[11][a11] +
            table[12][a12] +
            table[13][a13] +
            table[14][a14];

        if(sum == 0x7297a41b) {
            printf(
                "  %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n",
                charset[a0],  charset[a1],  charset[a2],
                charset[a3],  charset[a4],  charset[a5],
                charset[a6],  charset[a7],  charset[a8],
                charset[a9],  charset[a10], charset[a11],
                charset[a12], charset[a13], charset[a14]);
        }
    }}}}}}}}}}}}}}}

    return(0);
}


