/*
	Keygen for: Kostya's KeygenM3Crypt #2 (CAFFEINE_CRACKME)
	by: ratsoul
	e-mail: ratsoul@autistici.org
*/

#define NAME_SZ 0x42
#define SERIAL_SZ 0x2A

int GetTime()
{

 int num = ((long long)time(NULL) * (long long)0xc22e4507) >> 48;
 num += (num >> 31);

 return num;
}

char* micro_rev(int eax)
{
	int
		edx = 0x17,
		ecx = 0x1B,
		esi;

	static char p[12];

	do {
		esi = edx;
		esi <<= ecx;
		esi *= ecx;
		esi ^= eax;
		esi &= 0x7fffffff;
		ecx -= 3;
		eax = esi;

	}while(ecx >= 0);

	//instead of itoa()
	sprintf(p, "%d", eax);
	return p;
}

int getSerialLen()
{
	int loop = 0x10000;
	int slen = 0x56003C;
	while(loop--)
	{
		slen -= 0x56;
		slen ^= 0x1234;
	}

	slen -= 0x12;

	return slen;
}

int get_offset(char c)
{
	static const char hdserial[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890.-_()[],&";
	char *p = (char*)hdserial;

	int loop = 0;
	while( loop++ < 0x48 )
	{
		if( *p++ == c )
			return loop;
	}

    return 0;
}

void search_index( char *input, char *output )
{
	int loop = 42;
	static const char hdstring[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890.-_()[],&";
	char *p;
	int index = 0;

	while( loop-- )
	{
		p = (char*)hdstring;
		index = 0;
		while( *p != *input ){ p++; index++; }
		*output++ = index;
		input++;
	}
}

char getSerialChar(unsigned int offset)
{
	static const char hdstring[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890.-_()[],&";
	return hdstring[offset-1];
}

int give_me_serial(char *input, char *serial)
{
	//base64 enc of: "KostyaKostyaKostyaKostyaKostyaK"
	static const char hdstr[] = "S29zdHlhS29zdHlhS29zdHlhS29zdHlhS29zdHlhS2";
	char *h = (char*)hdstr;

	unsigned int loop = 42,
	    o1,
         o2;

	while(loop--)
	{
		if ( !(o2 = get_offset(*h++)) )
			return 0;

		o1 = *input++ + o2 + 1;
		while( o1 > 0x47 ) o1 -= 0x47;
		*serial++ = getSerialChar(o1);
	}

	return 1;

}

void BlowFish_Encrypt(unsigned long* l, unsigned long* r)
{
  BLOWFISH_CTX ctx;
  static const unsigned char key[] = "You need some caffeine to solve it!";
  int keylen = sizeof(key) - 1;

  Blowfish_Init (&ctx, (char*)key, keylen);
  Blowfish_Encrypt(&ctx, l, r);
}

void process_name(char *name, unsigned long *comp_value1, unsigned long *comp_value2)
{

	int loop = strlen(name);
	
	char out1[NAME_SZ + 1];
	
	char *o = out1,
		*i = name;

	char out2[NAME_SZ + 1];

	char *it,
		*i2,
		*i3;

	int *p;

	int edx = 2;

	unsigned int p2,
			   p3;

	while(loop--)
	{
		*o++ = *i++ & 0xFF;
	}
	*o = 0x00;

	loop = strlen(name);

	o = out2;
	i = out1;

	while(loop--){
		p = (int*)i++;
		(*p)++;
		*o++ = (*p++ & 0xFF) + 3;
	}
	*o = 0x00;

	i3 = out2;
	i2 = out1;


	loop = strlen(name);

	*comp_value1 = 0,
	*comp_value2 = 0;
	
	do{
		while(loop--)
		{
			p3 = (*(int*)i3++) & 0xFF;
			p2 = (*(int*)i2++) & 0xFF;
			
			p3 += p2;
			p3 *= p2;

			p3 = ((((((p3 * 'K') * 'o') * 's') * 't') * 'y') * 'a');

			p2++;
			p3 += p2;
			p2 ^= p3;
			p3 += p2;

			if(edx == 2)
				*comp_value1 += p3;

			if(edx == 1)
				*comp_value2 += p3;		

			it = i2;
			i2 = i3;
			i3 = it;
		}

		loop = 3;
		i3 = out2;
		i2 = out1;

	}while(--edx);

}

char unmap(char c)
{
	static const char table[] = "0123456789abcdefghijklmnopqrstuvwxyz";

	return table[ c + 0x10 ];
}

char* do_unmap(unsigned long hd2, unsigned long hd3)
{

	BlowFish_Encrypt(&hd2, &hd3);

	char c;
	int i = 0;
	int j = 0;
	static char s[17];

	for( i = 32 - 4; i >= 0; i-=4 )
	{
		c = (hd2 >> i) & 0xF;
		s[j++] = unmap(c);
	}

	for( i = 32 - 4; i >= 0; i-=4 )
	{
		c = (hd3 >> i) & 0xF;
		s[j++] = unmap(c);
	}

	s[16] = 0x00;

	return s;
}

int check(char *name)
{
	char *p = name;
	while(*p)
	{
		if( !(*p >= '0' && *p <= '9') && 
		    !(*p >= 'A' && *p <= 'Z') &&
		    !(*p >= 'a' && *p <= 'z')
		) return 0;

		p++;
	}

	return 1;
}

int check_len(char *name)
{
	if( strlen(name) < 5 || strlen(name) > 64 )
		return 0;

	return 1;
}

char* generate(char *name)
{

	char *pass_1,
		*pass_2;

	static const char pass_3[] = "FAAAAA";
	static const char pass_4[] = "16";

	static char serial[SERIAL_SZ + 1];
	char rev_serial[SERIAL_SZ + 1];

	unsigned long name_hd2 = 0,
		         name_hd3 = 0;

	int ctime;

	if( !check_len(name) || !check(name))
		return NULL;

	ctime = GetTime();
	ctime = (ctime << 16) | ctime;
	pass_2 = micro_rev(ctime);

	process_name(name, &name_hd3, &name_hd2);
	pass_1 = do_unmap(name_hd2, name_hd3);

	sprintf(serial, "-X%s]X.%s-%s_%sX",
								pass_1,
								pass_2,
								pass_3,
								pass_4
								);
	search_index(serial, rev_serial);
	give_me_serial(rev_serial, serial);
	serial[SERIAL_SZ] = 0x00;

	return serial;
}
