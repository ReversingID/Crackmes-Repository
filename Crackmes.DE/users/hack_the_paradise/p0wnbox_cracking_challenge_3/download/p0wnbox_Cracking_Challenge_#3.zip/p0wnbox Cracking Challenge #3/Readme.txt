08d/09m/2009


Tested with Windows XP SP3 / NOT VISTA COMPATIBLE!!!


Here it is the 3rd challenge for the p0wnbox foroum. 


It is based on the previous 2 with some extra coding for the protection.


TASKS: 

      Make a valid crack, with a detailed explanation of the protection and how
      you defeated it.



    

�ote: NO SOLUTION WILL BE ACCEPTED IF NOT ATTACHED A DETAILED EXPLANATION WITH IT!!!


Enjoy,

Hack_ThE_PaRaDiSe



PS: Unfortunately due to design problems some protection features that I wanted to add

    will be present at the next challenge.