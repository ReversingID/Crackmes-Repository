                                                        p0wnbox Cracking Challenge #4
                                                    ....................................


Hi guyz, this a my new challenge for our members. 


Your task is to find a correct Serial for the name: pownboxforum


Finding the correct serial should not be difficult, however, there are some anti-reversing tricks that may give you some trouble.



Important:You should send a detailed report about the anti-reversing tricks you dealed with and the way you bypassed them. Just a valid serial will not be accepted as solution.


Enjoy,

H_T_P