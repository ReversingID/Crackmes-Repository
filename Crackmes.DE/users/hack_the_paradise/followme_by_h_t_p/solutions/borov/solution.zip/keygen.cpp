#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

int main()
{
    srand(GetTickCount());    
    char serial[0x0F];
    for (int i = 0; i < 0xE; i++)
        serial[i] = (rand() % 13) + 0x30;
    serial[4] = serial[0] + serial[2];
    serial[7] = serial[1] + serial[5];
    serial[10] = serial[3] + serial[6];
    serial[13] = serial[11] + serial[12];
    serial[14] = '\n';
    printf("%s", serial);
    system("pause");
    return 0;
}
