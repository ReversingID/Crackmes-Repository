Solution.Zip

ReadMe.txt - this file
keygen.exe - compiled keygen
keygen.cpp - source of keygen
deobfuscate.txt - script for deobfuscate
solution.txt - soluton
deobfuscated code.txt - deobfuscated code and parsing algorithm validation serial code