                                  FollowMe By H_T_P               12d/05m/2010
                             ..........................
 


Welcome to my new challenge. It is not supposed to be difficult, however there is a trick
that may slow you down.

Your task is to write a keygen. The algo is very simple so once you understand what it is
going on you will manage to do it.


Enjoy,

H_T_P