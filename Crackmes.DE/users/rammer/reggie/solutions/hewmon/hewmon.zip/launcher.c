/*  launcher.c
 *
 *  A possible implementation of a simple loader application for Reggie.exe
 *
 *  Link without default/runtime libraries and set EntryPoint to "EntryPoint"
 */
#define UNICODE
#include <windows.h>

typedef LONG	NTSTATUS;
typedef DWORD	ACCESS_MASK;

typedef struct _UNICODE_STRING {
	USHORT	Length;
	USHORT	MaximumLength;
	PWSTR	Buffer;
} UNICODE_STRING;

typedef UNICODE_STRING* PUNICODE_STRING;

typedef struct _OBJECT_ATTRIBUTES {
	ULONG	Length;
	HANDLE	RootDirectory;
	PUNICODE_STRING ObjectName;
	ULONG	Attributes;
	PVOID	SecurityDescriptor;
	PVOID	SecurityQualityOfService;
} OBJECT_ATTRIBUTES;

typedef OBJECT_ATTRIBUTES* POBJECT_ATTRIBUTES;

#define DELETE			(0x00010000L)
#define READ_CONTROL		(0x00020000L)
#define WRITE_DAC		(0x00040000L)
#define WRITE_OWNER		(0x00080000L)

#define OBJ_CASE_INSENSITIVE	(0x00000040L)

#define InitializeObjectAttributes(poaInitializedAttributes, pusObjectName, ulAttributes, hRootDirectory, pSecurityDescriptor) { \
	(poaInitializedAttributes)->Length = sizeof(OBJECT_ATTRIBUTES); \
	(poaInitializedAttributes)->RootDirectory = hRootDirectory; \
	(poaInitializedAttributes)->ObjectName = pusObjectName; \
	(poaInitializedAttributes)->Attributes = ulAttributes; \
	(poaInitializedAttributes)->SecurityDescriptor = pSecurityDescriptor; \
	(poaInitializedAttributes)->SecurityQualityOfService = NULL; \
}

typedef NTSTATUS (WINAPI *TNtCreateKey)(PHANDLE, ACCESS_MASK, POBJECT_ATTRIBUTES, ULONG, PUNICODE_STRING, ULONG, PULONG);
typedef NTSTATUS (WINAPI *TNtSetValueKey)(HANDLE, PUNICODE_STRING, ULONG, ULONG, PVOID, ULONG);

NTSTATUS EntryPoint() {
	TNtCreateKey NtCreateKey;
	TNtSetValueKey NtSetValueKey;
	NTSTATUS sResult;
	OBJECT_ATTRIBUTES oAttributes;
	ULONG ulDisposition;
	HANDLE hSoftware;
	HANDLE hReggie;
	HANDLE hIsRegistered;
	UNICODE_STRING usSoftware = { 52, 0, TEXT("\\Registry\\Machine\\Software") };
	UNICODE_STRING usReggie = { 12, 0, TEXT("Reggie") };
	UNICODE_STRING usIsRegistered = { 26, 0, TEXT("isRegistered\0") };
	UNICODE_STRING usNotRegistered = { 26, 0, TEXT("NOTregistered") };
	WCHAR *wRegistered = &usNotRegistered.Buffer[3]; // "registered"
	HMODULE hmNtDll = GetModuleHandle(TEXT("NTDLL"));

	NtCreateKey = (TNtCreateKey) GetProcAddress(hmNtDll, "NtCreateKey");
	NtSetValueKey = (TNtSetValueKey) GetProcAddress(hmNtDll, "NtSetValueKey");

	InitializeObjectAttributes(&oAttributes, &usSoftware, OBJ_CASE_INSENSITIVE, NULL, NULL);
	if ((sResult = NtCreateKey(&hSoftware, DELETE | READ_CONTROL | WRITE_DAC | WRITE_OWNER | (0x0000003FL), &oAttributes, 0, NULL, 0, &ulDisposition)) != 0)
		return sResult;

	InitializeObjectAttributes(&oAttributes, &usReggie, OBJ_CASE_INSENSITIVE, hSoftware, NULL);
	if ((sResult = NtCreateKey(&hReggie, DELETE | READ_CONTROL | WRITE_DAC | WRITE_OWNER | (0x0000003FL), &oAttributes, 0, NULL, 0, &ulDisposition)) != 0)
		return sResult;

	InitializeObjectAttributes(&oAttributes, &usIsRegistered, OBJ_CASE_INSENSITIVE, hReggie, NULL);
	if ((sResult = NtCreateKey(&hIsRegistered, DELETE | READ_CONTROL | WRITE_DAC | WRITE_OWNER | (0x0000003FL), &oAttributes, 0, NULL, 0, &ulDisposition)) != 0)
		return sResult;

	if ((sResult = NtSetValueKey(hIsRegistered, &usNotRegistered, 0, REG_SZ, wRegistered, 22)) != 0)
		return sResult;

	return WinExec("REGGIE.EXE", SW_SHOWNORMAL);
}
