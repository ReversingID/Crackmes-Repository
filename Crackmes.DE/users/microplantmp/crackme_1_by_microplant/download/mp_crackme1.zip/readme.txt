////////////////////////////////////////////////
// crackme #1 - ultra-easy for real beginners //
////////////////////////////////////////////////

hi and welcome to my first crackme for crackmes.de
this one is dedicated to the real beginners, and can
be solved in a few minutes by average crackers
(even with the time to code a keygen !)
i tried to make it as easy as possible to let beginners
get the "high" to finaly solve a crackme and to understand how
the serial is beeing generated.

there is just one rule:

#1 only keygens allowed !

you will see why i only accept keygens and no name/key combos :D

but now - have phun


microplant