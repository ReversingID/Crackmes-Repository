#include <stdio.h>
#include <stdlib.h>
#include <string.h>
main()
{
    unsigned char XORString[]="HyI1laskdfhachauek193847``kd/\\kasdkn";
    unsigned char Target[]="C:\\WINDOWS\\SYSTEM\\MSVB32.DLL";
    int i,n,Encrypted[20];
    FILE *fp;

    puts("\nCrackme: Now KeyGenMe by BootLoader");
    puts("==================================================\n");

    // Initialise
    for(i=0;Encrypted[i]!=0;i++)
        Encrypted[i]=0;

    // Open the Target File
    if( (fp=fopen(Target,"rb"))==NULL )
    {
        printf("Cound not open: %s\n",Target);
        exit(-1);
    }
    else
        printf("Opening the file... [%s]\n\n",Target);

    // Read the Encrypted Data
    i=0;
    do
    {
        Encrypted[i]=fgetc(fp);
    }
    while( Encrypted[i++]!=EOF );

    // Decrypt the Data
	n=i-3;
    printf("\tPassword = ");
    for(i=0;i<n;i++)
        printf("%c",Encrypted[i]^XORString[i]);
    puts("\n\n==================================================");
    puts("\t\t\t\tKeyGen by EsKiMo\n\n[Press Enter to Exit...]");
    getchar();
}
