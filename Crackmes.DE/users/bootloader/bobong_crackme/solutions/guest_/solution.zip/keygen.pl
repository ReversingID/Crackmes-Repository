# keygen for Bobong CrackMe
# by cons00m
# guest.evol@gmail.com
use Win32::kernel32;

@volumeinfo = Win32::GetVolumeInformation();

$serial = reverse(sprintf("%X", $volumeinfo[1]));

print "\n\nYour serial is $serial\n\n";

print "Press any key to continue...\n";
$junk = <>;
