﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace set_password
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string sFileName = Application.StartupPath + @"\Pross.hac"; //Get the correct path
                DSOFile.OleDocumentProperties properties = new DSOFile.OleDocumentProperties();
                properties.Open(sFileName, false, DSOFile.dsoFileOpenOptions.dsoOptionDefault);

                // Delete the custom property "U" if already inserted....
                int anz = properties.CustomProperties.Count;
                int i;
                for (i = 0; i < anz; i++)
                {
                    if (properties.CustomProperties[i].Name == "U")
                    {
                        string oldpass = properties.CustomProperties[i].get_Value();
                        DialogResult result = MessageBox.Show("The old password is : " + oldpass + "\n Overwrite it ?", "Password exists...", MessageBoxButtons.YesNo);
                        if (result == DialogResult.Yes)
                        {
                            properties.CustomProperties[i].Remove();
                            properties.CustomProperties.Add("U", pass_txt.Text);
                            MessageBox.Show("File patched !");
                        }
                        break;
                   }
                }
                if (i==anz) 
                {
                    properties.CustomProperties.Add("U", pass_txt.Text);
                    MessageBox.Show("File patched !");
                }

                properties.Close(true);
                properties = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error !");

            }
        }
    }
}
