Hello!
This is my second crackme. I dont know what is it's level of difficulty...you decide :)
ok, there is one rule: FIND R!GHT SERIAL. That's all. Send right ones to me (ximus.4f@gmail.com)

i'm waitin..8)