// 10-7-08 X!Mus.4F CrackMe #1 Keygen by hound

#include <stdio.h>
#include <string.h>

int main() {
	// declarations
	char serial_buffer[12], input_name[21];
	unsigned char a[5];	
	unsigned int i, name_sum;

	// get name
	printf("Input name (max 20 letters): ");
	scanf("%s", input_name);

	// check name is atleast 3 letters long
	if (strlen(input_name) < 3) {
		printf("Name must be atleast 3 letters long!\n");
		return -1;
	}

	// set 3rd, 4th, 5th digits of serial
	for(i=0; i<3;i++) {
		a[i+2] = input_name[i] % 0xA;
	}

	// set 2nd and 1st
	a[1] = (a[2] * a[3] * a[4])%(0xA);
	a[0] = (a[1] + a[2] + a[3])%(0xA);

	// add all the letters in the name together
	for (i=0, name_sum=0; i < strlen(input_name); i++)
		name_sum += input_name[i];

	// construct the final serial with added arithmetic on name_sum
	sprintf(serial_buffer,"%d%d%d%d%d-%X",a[0], a[1], a[2], a[3], a[4], (name_sum*0xFEAD)&(0xFFFFF));

	// output the serial
	printf("\nSerial: %s\n", serial_buffer);

	return 0;
}



