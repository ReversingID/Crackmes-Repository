================================
X[!]M.4F  CrackMe #1
o9.o7.2oo8
================================

Hi! This is my first crackme. I think it's very easy.
Write a keygen. Or just understand the 
algoritm of generation serial. Of cource you can 
patch program, but I think you will have more fun 
and satisfaction if you write a keygen!!

Good Luck! ;)

