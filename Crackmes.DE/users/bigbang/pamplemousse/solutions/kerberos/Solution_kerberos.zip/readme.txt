Files
----------------------

solution.pdf        -- basic idea how to defeat this CME
src/                -- sources codes of keygen
src/sha1.*          -- my old implementation of SHA-1 (I hope it's correct)
src/main.cpp	    -- source code of keygen (main part)
src/Makefile        -- you can use this to compile KeyGen under linux

I'm sorry to say it, but there is no "bin/" directory with binary keygen because i've written keyGen under Linux where with GNU MP library, but I wasn't able to find GMP library for Win32 + Dev-Cpp (only Windows C++ compiler I've got).
