#include <iostream>
#include <gmp.h>

#include <string>
#include <iostream>
#include <algorithm>
#include <cctype>

#include "sha1.h"

using namespace std;

int DLP_solver(mpz_t alpha,mpz_t beta,mpz_t modulus, mpz_t order,mpz_t r1);

void productString(string s,mpz_t n)
{
  for (unsigned int i=0;i<s.length();i++){
    mpz_mul_ui(n,n,s[i]);
  }
}

mpz_t order;

// We're using Pohlig-Hellman DLP solving algorith, because factors are small numbers
int solveDLP(mpz_t result, mpz_t p)
{
  mpz_t factors[8];
  mpz_t l,g_,y_,ms,a,y,g,j,fR,k;  

  mpz_init_set_str(factors[0],"2",10);
  mpz_init_set_str(factors[1],"5751247",10);
  mpz_init_set_str(factors[2],"81514567",10);
  mpz_init_set_str(factors[3],"273749507",10);
  mpz_init_set_str(factors[4],"2255442769",10);
  mpz_init_set_str(factors[5],"85717369999",10);
  mpz_init_set_str(factors[6],"254289209159",10);
  mpz_init_set_str(factors[7],"254289208463",10);

  mpz_init_set_str(y,"1248310966923498661164204883260437277137373139593887776277032788073",10);
  
  mpz_init(l);
  mpz_init(a);
  mpz_init(g_);
  mpz_init(y_);
  mpz_init(g);  
  mpz_init(j);
  mpz_init(k);

  mpz_init_set_ui(fR,0);    

  // P used in final part of Gauss algorithm
  mpz_init_set_str(ms,"3208758980294089871636889325639601519765013105042818745876534106523",10);
       
  for (int i=0;i<8;i++){
    // Pohlig-Hellman algorithm
    mpz_divexact(l,order,factors[i]);
    mpz_powm(g_,result,l,ms);
    mpz_powm(y_,y,l,ms);
    DLP_solver(y_,g_,ms,factors[i],a);    

    // gauss algorithm 
    mpz_set(g,a);
    mpz_mul(g,g,l);
    mpz_invert(j,l,factors[i]);
    mpz_mul(g,g,j);
    mpz_add(fR,fR,g);
    cout <<"#########";   
    cout.flush();       
  }  
  mpz_mod(fR,fR,order);
  mpz_set(p,fR);
}

int main()
{

  string name;

  cout <<"Zadej text : ";
  cin >>name;
  
  mpz_t nameProduct;
  mpz_init(nameProduct);
  mpz_set_ui(nameProduct,1);
  
  //computes product of all chars in nameString
  productString(name,nameProduct);
  
  mpz_t nums[3];
  //decryption exponent ... took me 10 minuts to factor N and discover it :)  
  //factors of N (num2) are 
  // 67276A21CF703D173ADF6793FBC3 and 60D79F11C11ED51CB868660103BB
  mpz_t d; 
  mpz_t c01,c02,c03; // constants used to generate password
  mpz_t t,y; // tmp variables used in algorithm 
  
  mpz_init_set_ui(y,0);
  mpz_init_set_ui(t,0);

  
  for (int i=0;i<3;i++){
    mpz_init_set_ui(nums[i],0);
  }

  cout <<"Initialization some numbers ";
  mpz_init_set_str(d,"25EB8E19A4404B5BA600B674867BD47B244CB30A06B1B91B452DCD0D",16);  
  mpz_init_set_str(c01,"1D65323247CEBABF3074F3330D0B9B61161FB0299988F33C6F7F8976",16);  
  mpz_init_set_str(c02,"10D6954AF092BE38D4AA9859378EBE75552926B4E908B08DA3087967",16);
  mpz_init_set_str(c03,"1C7CA03D1FA558DC58DC737EFA931E5210E978D751C636FA06E4870A",16);
  mpz_set_str(nums[1],"2705A9FF72897DC2CC41C4796CD95514D25ECBF75D336C8312CF3071",16);  
  mpz_set_str(nums[2],"1E780F9DA0C576701F423BAB7E95EF7F6AACA6DFF2E5D08F6729999B",16);  

  mpz_set(order,nums[2]);
  mpz_sub_ui(order,order,1);   
  
  cout <<"................................................[OK]"<<endl;

  cout <<"Computing modified SHA-1 of userName "; 
  CSHA1 sha1;
  sha1.Hash_string((const unsigned char*)name.c_str());  
  name = sha1.vypis();    
  mpz_set_str(nums[0],name.c_str(),16);
  cout <<".......................................[OK]"<<endl;  

  //  cout <<"Computing value Y "; 
  mpz_mul(t,nums[0],nums[0]); 
  mpz_mul(y,nums[0],c01);
  mpz_add(y,y,t);   
  mpz_sub(y,y,c02);  
  mpz_mul(y,y,c03);
  mpz_mod(y,y,nums[2]);

  //  cout <<"[OK]"<<endl;  

  cout <<"                          -== Solving DLP problem ==-"<<endl<<"[";
  cout.flush();  
  solveDLP(y,y);
  cout <<"]"<<endl;
  
  cout <<"Computing RSA "; 
  mpz_powm(t,y,d,nums[1]);
  cout <<"..............................................................[OK]"<<endl;
    
  gmp_printf("%Zd-",t);
  char secondPart[1024];
  mpz_get_str(secondPart,9,nameProduct);
  printf("%s\n",secondPart);
  
  return 0;
}


/// Pollard's RHO algorithm used to solve easy logarithm problems in Pohlig-Hellman algorithm
int DLP_solver(mpz_t alpha,mpz_t beta,mpz_t modulus, mpz_t orderr,mpz_t r1)
{
  mpz_t a,b,p,n;

  mpz_t xi,ai,bi,x2i,a2i,b2i;
  mpz_t temp,temp2,count;
  
  size_t size;

  mpz_init(a);
  mpz_init(b);
  mpz_init(p);
  mpz_init(n);

  mpz_init(xi);
  mpz_init(ai);
  mpz_init(bi);
  mpz_init(x2i);
  mpz_init(a2i);
  mpz_init(b2i);
  mpz_init(temp);
  mpz_init(temp2);
  mpz_init(count);

  mpz_set(a,alpha);
  mpz_set(b,beta);
  mpz_set(p,modulus);
  mpz_set(n,orderr);

  size = mpz_size(n);

  mpz_set_ui(count,0);

  mpz_set_ui(ai,0);
  mpz_set_ui(bi,0);
  
  mpz_powm(temp,a,ai,p);
  mpz_powm(xi,b,bi,p);

  mpz_mul(xi,xi,temp);
  mpz_mod(xi,xi,p);

  mpz_set(x2i,xi);
  mpz_set(a2i,ai);
  mpz_set(b2i,bi);

  do {
    mpz_add_ui(count,count,1);
    
    switch(mpz_mod_ui(temp,xi,3))
      {
      case 0 : 
	mpz_mul(xi,xi,xi);
	mpz_mul_ui(ai,ai,2);
	mpz_mul_ui(bi,bi,2);
	break;
      case 1 : 
	mpz_mul(xi,xi,b);
	mpz_add_ui(bi,bi,1);
	break;
      case 2 : 
	mpz_mul(xi,xi,a);
	mpz_add_ui(ai,ai,1);
	break;
      }
    
    mpz_mod(xi,xi,p);
    mpz_mod(ai,ai,n);
    mpz_mod(bi,bi,n);
    
    switch(mpz_mod_ui(temp,x2i,3))
      {
      case 0 :
	mpz_mul(x2i,x2i,x2i);
	mpz_mul_ui(a2i,a2i,2);
	mpz_mul_ui(b2i,b2i,2);
	break;
      case 1 :
	mpz_mul(x2i,x2i,b);
	mpz_add_ui(b2i,b2i,1);
	break;
      case 2 :
	mpz_mul(x2i,x2i,a);
	mpz_add_ui(a2i,a2i,1);
	break;
      }
    
    mpz_mod(x2i,x2i,p);
    
    switch(mpz_mod_ui(temp,x2i,3))
      {
      case 0 : mpz_mul(x2i,x2i,x2i);
	mpz_mul_ui(a2i,a2i,2);
	mpz_mul_ui(b2i,b2i,2);
	break;
      case 1 : mpz_mul(x2i,x2i,b);
	mpz_add_ui(b2i,b2i,1);
	break;
      case 2 : mpz_mul(x2i,x2i,a);
	mpz_add_ui(a2i,a2i,1);
	break;
      }
    
    mpz_mod(x2i,x2i,p);
    mpz_mod(a2i,a2i,n);
    mpz_mod(b2i,b2i,n);
  } while(mpz_cmp(xi,x2i) != 0);
  
  mpz_t r2;
  mpz_init(r2);
  
  mpz_sub(r1,bi,b2i);
  mpz_mod(r1,r1,n);
  mpz_sub(r2,a2i,ai);

  mpz_invert(r1,r1,n);  
  mpz_mod(r2,r2,n);
  mpz_mul(r1,r2,r1);
  mpz_mod(r1,r1,n);
  
  mpz_clear(a);
  mpz_clear(b);
  mpz_clear(n);
  mpz_clear(p);

  mpz_clear(xi);
  mpz_clear(x2i);
  mpz_clear(ai);
  mpz_clear(a2i);
  mpz_clear(bi);
  mpz_clear(b2i);
  mpz_clear(temp);
  mpz_clear(count);
  mpz_clear(temp2);

  if(mpz_cmp_ui(temp,0) == 0) return 1;
  else  return 0;  
}
