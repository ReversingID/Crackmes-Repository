#ifndef __SHA1_KERB__
#define __SHA1_KERB__

#include <string>
#include <fstream>
#include <sstream>
#include <iomanip>

using std::string;
using std::ifstream;
using std::ostringstream;

/** Macro for rotating 32-bit number*/
#define rol32(val, n) (((val)<<(n))|((val)>>(32-(n))))

#define ROTL64(x,n) (((x) << (int)(n)) | ((x) >> (64-(int)(n))))
#define ROTR64(x,n) (((x) << (int)(64-n)) | ((x) >> ((int)(n))))
#define word64 unsigned long long int
  
/** SHA-1 hash computing class*/
class CSHA1
{
private:
  unsigned int h0,h1,h2,h3,h4;
  unsigned char delka[8];
  void set_delka(unsigned long long i);
  void Update(const unsigned char* ,int);
  void Init();
public:
  CSHA1();

  void Hash_string(const unsigned char *);
  void Hash_buffer(const unsigned char *,unsigned long int);
  void Hash_file(const unsigned char *);

  /** Function returns final SHA-1 hash as string */
  string vypis(){ 
    char bf[8],res[40];
    
    sprintf(res,"%08X%08X%08X%08X%08X",h0,h1,h2,h3,h4);
    string r(res);
    
    return r;
  }
};
#endif
