#include "sha1.h"
#include <iostream>

using namespace std;

/** Transform 2 chars into Dword */
#define charToDword(a,b,c,d) ((a)|((b)<<8)|((c)<<16)|((d)<<24))
#define charToword64(a,b,c,d,e,f,g,h) ((a)|((b)<<8)|((c)<<16)|((d)<<24)|((e)<<32)|((f)<<40)|((g)<<48)|((h)<<56))

#define Ch(x,y,z)     (((x) & (y)) | ((~(x)) & (z)))
#define Parity(x,y,z) ((x)^(y)^(z))
#define Maj(x,y,z)    (((x) & (y)) | ((x) & (z)) | ((y) & (z)))

#define Phi0(x) ((ROTR64(x,1)) ^ (ROTR64(x,8)) ^ (x >> 7))
#define Phi1(x) ((ROTR64(x,19)) ^ (ROTR64(x,61)) ^ (x >> 6))
#define Suma0(x) ((ROTR64(x,28)) ^ (ROTR64(x,34)) ^ (ROTR64(x,39)))
#define Suma1(x) ((ROTR64(x,14)) ^ (ROTR64(x,18)) ^ (ROTR64(x,41)))

/** Sets array cells from  x to y  to zero */
#define Nuluj(x,y)    for (unsigned int __ll=(x);__ll<(y);pole[__ll++]=0);


/** Function sets length of entire procesed buffer, file or string
    \param i 64bit length of the file/string/buffer
    \returns none
 */
void CSHA1::set_delka(unsigned long long i)
{
  i*=8;
  for (unsigned long j=0;j<8;j++,i/=256)
    delka[j]= (i & 0xFF);
}

/** Function resets CSHA1 to initial state
    \param none
    \returns none
*/
void CSHA1::Init()
{

  h0=0xD76AA478;
  h1=0xE8C7B756;
  h2=0x242070DB;
  h3=0xC1BDCEEE;
  h4=0xF57C0FAF;
}

//!CSHA-1 constructor
/** Initialize main constants */
CSHA1::CSHA1()
{
  Init();  
}
/** Updates main values of the SHA-1 hash, but if iArray is NULL, then nLength has special meaning ... 
    \param iArray input array of algorithm
    \param nLength length of iArray
*/
void CSHA1::Update(const unsigned char* iArray,int nLength)
{

  unsigned long int pole[80];
  unsigned int i,temp,_zero=0;

  if (nLength >= 0)
    for (i=0;i<nLength;i++)
      pole[i]=iArray[i];
  else
    i=0;

  //pokud je delka pole mensi nez 64, jde o posledni cast souboru/bufferu
  if (i < 64)
    {
      if (nLength != -2) pole[i++]=128;
      //pokud se to tam vleze, vrazime tam delku celyho textu
      if (i < 56)
	{
	  Nuluj(i,56);
	  Nuluj(64,80);

	  for (unsigned j=0;j<8;j++)
	   pole[63-j]=delka[j];
	}
      else
	{
	  _zero=1;
	  Nuluj(i,80);	  
	}
      
    }

  for (i=0;i<64;i+=4)
    pole[i/4]=charToDword(pole[i+3],pole[i+2],pole[i+1],pole[i]);

  for (i=16;i<80;i++)
    pole[i]=rol32((pole[i-3] ^ pole[i-8] ^ pole[i-14] ^ pole[i-16]),1);

  unsigned long int a=h0,b=h1,c=h2,d=h3,e=h4,k,f;
  
  for (i=0;i<80;i++)
    {
      if ((0 <= i) && (i<=19))
	{
	  f = Ch(b,c,d);
	  k=0x5A827999;
	}
      if ((20 <= i) && (i<=39))
	{
	  f = Parity(b,c,d);
	  k = 0x6ED9EBA1;
	}
      if ((40 <= i) && (i<=59))
	{
	  f = Maj(b,c,d);
	  k = 0x8F1BBCDC;
	}
      if ((60 <= i) && (i<=79))
	{
	  f = Parity(b,c,d);
	  k = 0xCA62C1D6;
	}
      temp = rol32(a,5)+ f + e +k + pole[i];
      e = d;
      d = c;
      c = rol32(b,30);
      b = a;
      a = temp;
    }

  h0 = h0 + a;
  h1 = h1 + b ;
  h2 = h2 + c;
  h3 = h3 + d;
  h4 = h4 + e;

  if (_zero)
    Update(NULL,-2);
}

/** Function computes SHA-1 hash from input c-style (\\0 terminated) string
    \param text Input c-style string
    \returns none
*/
void CSHA1::Hash_string(const unsigned char * text)
{
  unsigned long int l=strlen((const char*)text);

  Hash_buffer(text,l);
}

/** Function computes SHA-1 hash from the input buffer of choosen length
    \param text Input buffer
    \param l Length of input buffer
*/
void CSHA1::Hash_buffer(const unsigned char *text,unsigned long int l)
{
  set_delka(l);

  while(l>=64)
    {
      Update(text,64);
      text+=64;
      l-=64;
    }

  if (l>0)
    Update(text,l);
  else
    Update(NULL,-1);
}

/** Computes SHA-1 hash of file
    \param name filename of the file from you want to compute hash
    \return none
    \todo Some checks ....
    \todo Get file size :)
*/
void CSHA1::Hash_file(const unsigned char *name)
{
  ifstream input((const char*)name,std::ios::binary);
  word64 ll;
  
  ll = input.tellg();
  input.seekg(0,ios::end);
  ll= -( ll - input.tellg());
  input.seekg(0,ios::beg);
  set_delka(ll);
  
  unsigned char buffer[64];
  unsigned l=0;
    
  while((l=input.read((char*)buffer,64).gcount())==64)
      Update(buffer,64);      

  if (l>0)
    Update(buffer,l);
  else
    Update(NULL,-1);

  input.close();
    
}
