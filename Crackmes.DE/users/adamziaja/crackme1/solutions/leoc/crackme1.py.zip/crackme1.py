#!/usr/bin/env python
# -*- coding: utf-8 -*-
# solution for Crackmes.de
# crackme1 by adamziaja
# Published: 14. May, 2014
# Difficulty: 1 - Very easy, for newbies
# Platform: Unix/linux etc.
# Language: C/C++
import sys

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print >> sys.stderr, '''usage: ./crackme1.py <username>'''
        sys.exit(1)

    # if 8 <= len(sys.argv[1]) <= 12:
    if len(sys.argv[1]) < 8 or len(sys.argv[1]) > 12:
        print >> sys.stderr, '''username must be between 8 and 12!'''
        sys.exit(1)

    username = sys.argv[1]
    xmm0 = ''
    for i in range(len(username)):
        if i & 1:
            xmm0 += str(ord(username[i].upper()))
        else:
            xmm0 += str(ord(username[i].lower()))
    usernamelength = 2 * (len(username) - 8)
    serial = xmm0[usernamelength:usernamelength+8]
    print "serial number: " + serial
