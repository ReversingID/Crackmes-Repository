#include <iostream.h>
#include <stdlib.h>

int main(){
	char user_input[10];
	unsigned long userID;
	
	cout<<"Keygen for LoseSpeed's NoMessageBoxAlarm, by Ultrasound\n\n";
	cout<<"Please enter your user ID: ";
	cin.getline(user_input, 11, '\n');

	userID=atol(user_input);

	userID-=9090;

	ultoa(userID, user_input, 10);

	cout<<"\nYour serial is: "<<user_input<<"\n\n";

	return 0;
}