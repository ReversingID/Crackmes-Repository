#undef UNICODE
#undef _UNICODE
//#define _CRT_SECURE_NO_WARNINGS
#include <windows.h>
#include <CommCtrl.h>
#include "resource.h"
#include "./MIRACL/miracl.h"

#define	APP_NAME		"Ilay's Calculator - Keygen"
//#define	NAME_MAX		30

// proto
int base64_encode(unsigned char *source, size_t sourcelen, char *target, size_t targetlen);

//----------------------------------------
void Test (HWND hDlg)
{
	HWND hWnd, hDlgItem;
	char szSerial[128]={0};

	hWnd = FindWindow (NULL, "Calculater");
	if (hWnd == NULL)
	{
		ShellExecute (NULL, NULL, "crackme.exe", NULL, NULL, SW_SHOW);
		Sleep (250);
		hWnd = FindWindow (NULL, "Calculater");
	}
	if (hWnd == NULL)
		{MessageBox (hDlg, "Please start crackme.exe first", APP_NAME, 0); return;}

	GetDlgItemText (hDlg, IDC_EDIT_SERIAL, szSerial, sizeof(szSerial));

	if (hDlgItem = GetDlgItem (hWnd, 1000))
		SendMessage (hDlgItem, WM_SETTEXT, 0, (LPARAM)szSerial);
	if (hDlgItem = GetDlgItem (hWnd, 1052))
		PostMessage (hWnd, WM_COMMAND, 1052, (LPARAM)hDlgItem);
}
//----------------------------------------
BOOL Generate (HWND hDlg)
{
	miracl *mip;
	big serial_big, E, D, N;
	char SerialNum[32] = "_VitaGuard", bBuf[128]={0}, szOut[128]={0}, bBufTest[128]={0};
	short sBuf;
	int i, intNumLen, intBuf;
	unsigned char bChar;

	srand (GetTickCount ());
	// Initialize MIRACL library
	mip = mirsys (0x100, 0x10);
	if (mip == 0) return FALSE;
	serial_big = mirvar(0); E = mirvar(3); D = mirvar(0); N = mirvar(0);
	mip->IOBASE = 16;

	// private exponent - D
	cinstr (D, "930AC2AE7FB620E8978771D67C301EFDFBDD72DBCB0F9204EE7FA8EA1A7DCC8B");
	// modulus - N
	cinstr (N, "DC902405BF91315CE34B2AC1BA482E7ED62166C9F9203FCB45DD8B8034237793");

	for (;;) {
		// randomize serial
		sBuf = rand();
		SerialNum[0] = LOBYTE(sBuf);
		SerialNum[11] = sBuf >> 8;
		for (i=12; i<32; i+=2) {
			sBuf = rand();
			SerialNum[i] = LOBYTE(sBuf);
			SerialNum[i+1] = sBuf >> 8;
		}

		bytes_to_big (32, (char*)SerialNum, serial_big);
		powmod (serial_big, D, N, serial_big);				// serial = pow(serial,D) mod N

		intNumLen = big_to_bytes (sizeof(bBuf), serial_big, bBuf, FALSE);
		if (intNumLen != 32) continue;
		bChar = (bBuf[0] >> 2) & 0x3F;
		if (bChar < 52 || bChar > 61)	// first char of Base64 string should be the digit
			continue;

		// for unknown reason generated number is occasionally wrong
		// maybe low public exponent (3) causes a problem?
		// RSA test...
		powmod (serial_big, E, N, serial_big);				// serial = pow(serial,E) mod N
		intBuf = big_to_bytes (sizeof(bBufTest), serial_big, bBufTest, FALSE);
		if (intBuf != 32) continue;
		if (strcmp (&bBufTest[1], "VitaGuard")) continue;

		break;	// success
	}

	mirkill(serial_big); mirkill(E); mirkill(D); mirkill(N);
	mirexit ();

	base64_encode (bBuf, intNumLen, szOut, sizeof(szOut));
	SetDlgItemText (hDlg, IDC_EDIT_SERIAL, szOut);

	return TRUE;
}
//----------------------------------------
BOOL CALLBACK DialogProc(HWND  hwndDlg, UINT  uMsg, WPARAM  wParam, LPARAM  lParam )
{
	switch (uMsg)
	{
#ifdef NAME_MAX
	case WM_INITDIALOG:
		SendDlgItemMessage (hwndDlg, IDC_EDIT_NAME, EM_SETLIMITTEXT, NAME_MAX, 0);
		return TRUE;
#endif

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDC_BUTTON_GENERATE:
			Generate (hwndDlg); return TRUE;
		case IDCANCEL:
			EndDialog (hwndDlg, 0); return TRUE;
		case IDC_BUTTON_TEST:
			Test (hwndDlg); return TRUE;
		}
		break;
	}
	return FALSE;
}
//----------------------------------------
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	InitCommonControls ();
	DialogBoxParam (hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, DialogProc, 0);
	return (0);
}
