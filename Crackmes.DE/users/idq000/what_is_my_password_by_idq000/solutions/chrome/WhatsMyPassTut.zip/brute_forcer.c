#include <math.h>
#include <stdio.h>
int main()
{
   int hash[] = { 0x1a2c04, 0x885a2,  0x32e524, 0x3453b3, 
                  0x22a846, 0x0fb6ba, 0x1caa93, 0x22fa44, 
                  0x27c365, 0x7b87a,  0x6c258,  0x175db9 };
   double a = 11.0;      // constant input to pow()
   double c = 4235489.0; // constant input to fmod()
   int x, z;             // loop counters

   for(z=0; z <= 11; z++) {  // loop for each of the 11 hash values
      printf("%2d: ", z);
      for(x=0; x<= 0xffff; x++)  // loop for all 65536 inputs
         if ( (int)fmod(pow(x,a), c) == hash[z] )            
            printf(" %x", x);  // print the input which collides
      printf("\n");
   }
}
