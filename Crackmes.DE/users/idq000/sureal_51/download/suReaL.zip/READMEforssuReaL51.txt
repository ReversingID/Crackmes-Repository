Notes on suReaL 51

Almost impossible to crack for real serial(s).
Too easy to patch.

SO...
don't patch
find serial(s)
write tutorial
mission complete

Finding one serial is tough enough.
Send all results to idq000@prodigy.net

When you get frustrated, remember this program is crazy.

And one final note, yes there are real serials to it.

Good Luck!