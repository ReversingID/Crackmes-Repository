#include <miracl.h>
#include <windows.h>
#include "resource.h"

HINSTANCE hInst;



BOOL CALLBACK DlgProc (HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
int lenName,i=0;
	big E3,N,Name,len,sqr;
	big t1,t2,t3,t4;
	char sn[28]={0};
	char sn1[6]={0},sn2[6]={0},sn3[6]={0},sn4[6]={0};
	char szName[64]={0};
	miracl *mip;
switch (uMsg){
   case WM_CLOSE:
		EndDialog(hWnd,0);
		break;

   case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDC_Exit:
			EndDialog(hWnd,0);
		break;

		case IDC_Generate:
	lenName=GetDlgItemText(hWnd,IDC_Name, szName, 63);
	if(!lenName)
	{
		SetDlgItemText(hWnd,IDC_Serial,"Let me know your name!");
		break;
	}
	mip=mirsys(500,16);
	mip->IOBASE=16;
	E3=mirvar(0);
	N=mirvar(0);
	Name=mirvar(0);

//	cinstr(M11,"B42EEFAD05F6168B");
//	cinstr(M12,"9E63A3AFA9F7BCE4");
	cinstr(E3,"54E08FB8EEC50FD4");
	cinstr(N,"FA75F680B813A3E3");
//Get the Name and relevant big number
	len=mirvar(lstrlen(szName));
	strrev(szName);
	bytes_to_big(lenName,szName,Name);
	powmod(Name,len,N,Name);
	
	t1=mirvar(0);
	t2=mirvar(0);
	t3=mirvar(0);
	t4=mirvar(0);
	cinstr(t1,"153823EE3BB143F5");// =E3/4
	cinstr(t2,"FA75F680B813A3E2");// =N-1
	cinstr(t4,"3E9D7DA02E04E8F9");// =N+1 /4
	xgcd(t1,t2,t1,t1,t1);		  // t1*(N-1)=1

	subtract(N,Name,Name);
	powmod(Name,t1,N,t1);

	sqr=mirvar(2);
	powmod(t1,t4,N,t2);
	powmod(t2,sqr,N,t3);
	if(compare(t3,t1)!=0)
		subtract(N,t2,t2);
	powmod(t2,t4,N,t1);
	powmod(t1,sqr,N,t3);
	if(compare(t3,t2)!=0)
		subtract(N,t1,t1);


	sn[0]=0;
	wsprintf(sn4,"%d",subdiv(t1,0x10000,t1));
	wsprintf(sn3,"%d",subdiv(t1,0x10000,t1));
	wsprintf(sn2,"%d",subdiv(t1,0x10000,t1));
	wsprintf(sn1,"%d",subdiv(t1,0x10000,t1));

	lstrcat(sn,sn1);
	lstrcat(sn,"-");
	lstrcat(sn,sn2);
	lstrcat(sn,"-");
	lstrcat(sn,sn3);
	lstrcat(sn,"-");
	lstrcat(sn,sn4);
	SetDlgItemText(hWnd,IDC_Serial,sn);

	mirkill(sqr);
	mirkill(len);
	mirkill(E3);
	mirkill(N);
	mirkill(Name);
	mirkill(t1);
	mirkill(t2);
	mirkill(t3);
	mirkill(t4);
	mirexit();
		break;
		}
		break;
	case WM_INITDIALOG:
		SendMessage(hWnd,WM_SETICON,ICON_BIG,(LPARAM) LoadIcon(hInst,MAKEINTRESOURCE(ICO_MAIN)));
        break;
}
return 0;
}

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,PSTR szCmdLine, int iCmdShow)
{

	hInst=hInstance;
	DialogBoxParam(hInstance,MAKEINTRESOURCE(DLG_MAIN),0,(DLGPROC)DlgProc,0);
	return 0;
}