#include <windows.h>
#include <math.h>
#include <stdio.h>
#include <string>
#include "resource.h"
using namespace std;

const char Title[]="KeyGen for bLaCk-eye's JUN!OR Crackme";
const char Date[]="07/06/2004";

string name, serial;

/*****************************
KeyGen() algo
*****************************/
#include <vector>
#include "big.h"
#include "crt.h"

typedef vector<bool> bools;
typedef unsigned int word32;

Miracl mip(100);

Big ComputeCRT( Big a1, Big p1, Big a2, Big p2 )
{
	Big mod[2], rem[2];
	rem[0] = a1;
	rem[1] = a2;
	mod[0] = p1;
	mod[1] = p2;

	Crt crt( 2, mod );
	return crt.eval( rem );
}

Big TransformInverse( Big R )
{
	const static Big N1 = 0xFDD0B5FB;
	const static Big N2 = 0xF5BC716B;
	const static Big k = 0x10001;

	Big S1 = pow( R, k, N1 );
	Big S2 = pow( R, k, N2 );

	return ComputeCRT( S1, N1, S2, N2 );
}

char GetChar( Big num, int i )
{ return ( num[i/4] >> ((i%4)*8)  ) & 0xFF; }

Big Hash( Big R )
{
	const static Big N7 = 0x17;
	const static Big N8 = 0xFA579913;
	Big H = 0;

	for( int i = 0; i < 8; i++ )
		H += GetChar( R, i );

	for( int i = 0; i < 8; i++ )
		H = GetChar( R, i ) + pow( H, N7, N8 );

	return H;
}

bools intTobools( word32 a )
{
	bools res;
	for( int i = 0; i < 32; i++ )
	{
		res.push_back( a & 1 );
		a >>= 1;
	}
	return res;
}

word32 boolsToint( bools a )
{
	word32 res=0;
	for( int i = 31; i >= 0; i-- )
	{
		res <<= 1;
		res |= a[i] ? 1 : 0;
	}
	return res;
}

Big xorProcessInverse( Big R_ )
{
	bools R = intTobools( R_[0] );
	bools N = intTobools( 0 );

	N[31] = R[31];
	for( int i = 30; i >= 0; i-- )
		N[i] = N[i+1] ^ R[i];

	return (Big)boolsToint( N );
}

string ConvertNum( Big num )
{
	static string base = "BCDFGHJKMPQRTVWXY2346789";
	string result = "";

	if( num == 0 )
		result += base[0];

	while( num != 0 )
	{
		result = base[ num % base.length() ] + result;
		num /= base.length();
	}

	return result;
}

Big nameToBig( string name )
{
	const static int serialLength = 0x08;
	char buffer[0x08];

	if( name.length() > serialLength )
		throw exception( "Name too long" );

	for( int i = 0; i < serialLength; i++ )
		buffer[8-i-1] = i > name.length() ? 0 : name[i];

	return from_binary( serialLength, buffer );
}

void KeyGen()
{
	try
	{
		Big R = nameToBig( name );
		Big S1 = TransformInverse( R );
		Big S2 = xorProcessInverse( Hash( R ) );

		serial = "";
		serial += ConvertNum( S1 >> 32 );
		serial += '-';
		serial += ConvertNum( S1 - (( S1 >> 32 ) << 32 ) );
		serial += '-';
		serial += ConvertNum( S2 );
	}
	catch( exception& ex )
	{
		serial = (string)"Error: " + ex.what();
	}
}

/*****************************
DLG stuff..
*****************************/

// bitmap
HBITMAP hBitmap;
HBRUSH hBrush;

BOOL CALLBACK DialogProc( HWND hwndDlg, UINT uMsg ,WPARAM wParam, LPARAM lParam )
{
	switch( uMsg )
	{
	case WM_CLOSE:
		EndDialog( hwndDlg, 0 );
		break;

	case WM_INITDIALOG:
		srand( GetTickCount() );
		SetWindowText( hwndDlg, Title );
		SetDlgItemText( hwndDlg, IDC_DATE, Date );
		SetWindowPos(hwndDlg,HWND_TOPMOST,0,0,0,0,SWP_NOSIZE|SWP_NOMOVE);

		SetDlgItemText( hwndDlg, IDC_SERIAL, "Enter your name..." );
		break;

	case WM_COMMAND:
		if( LOWORD(wParam) == IDC_NAME )
		{
			char buffer[ 512 ];

			if( !GetDlgItemText( hwndDlg, IDC_NAME, buffer, 511 ) )
			{
				SetDlgItemText( hwndDlg, IDC_SERIAL, "Enter your name..." );
				break;
			}

			name = buffer;

			KeyGen();

			SetDlgItemText( hwndDlg, IDC_SERIAL, serial.c_str() );
			InvalidateRect( GetDlgItem(hwndDlg, IDC_NAME), NULL, true );
			InvalidateRect( GetDlgItem(hwndDlg, IDC_SERIAL), NULL, true );
		}

		break;


	case WM_CTLCOLORDLG:
	case WM_CTLCOLORLISTBOX:
	case WM_CTLCOLOREDIT:
	case WM_CTLCOLORSTATIC:
		HDC hdc;
		hdc = ( HDC )wParam;
		SetTextColor( hdc, RGB( 255, 255, 255 ));
		SetBkMode( hdc, TRANSPARENT	);
		return ( BOOL )hBrush;
	}
	return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	hBitmap = LoadBitmap( hInstance, MAKEINTRESOURCE( IDB_MAIN ));
	hBrush = CreatePatternBrush( hBitmap );

	DialogBox( hInstance, MAKEINTRESOURCE( IDD_DLG ), 0, DialogProc );

	DeleteObject( hBitmap );
	DeleteObject( hBrush );

	return 0;
}