#include <windows.h>
#include <math.h>
#include <stdio.h>
#include <string>
#include "resource.h"
using namespace std;

const char Title[]="KeyGen for bLaCk-eye's AiNAMOR Crackme";
const char Date[]="02/06/2004";

string name, serial;

/*****************************
		KeyGen() algo
*****************************/
#include "miracl/include/big.h"
#include "md5/md5class.h"

Miracl mip( 1000 );

string BigToString( Big& big );

int Hash32Process( string msg )
{
    unsigned short h1 = 0xFFFF, h2 = 0xFFFF;
    
	for ( string::iterator i = msg.begin(); i != msg.end(); i++) 
    {
        h1 = ( h1 + *i ) % 0xFFF1;
        h2 = ( h2 + h1 ) % 0xFFF1;
    }
    return ( h2 << 16 ) | h1;
}

void KeyGen()
{
	(&mip)->IOBASE = 60;
	Big Num1 = "d1WJGnkJiFAJReBRRmEBlNYJs6AK5p82TZFbUX8lnL1IbLoHpfWx9G0jetjscI3tGQ5Bf3PwI6x6HJcTi4sGVu";
	Big Num2 = "8xl1BRa4boktp7B5v3mw7xXQpITKXDnfUng7KqY3nUHGgAQCOVqLNj4b0IulVfaRadA0iQgalrLsXJa6orf8flb";

	string strRSA = "RSA = R. Rivest + A. Shamir + L. Adleman";
	Big RSA = from_binary( strRSA.length(), (char*)strRSA.c_str() );

	Big Hash32 = Hash32Process( name );

	CMD5 md5( name.c_str() );
	Big HashMD5 = from_binary( 16, (char*)md5.getMD5Digest() );

	serial = BigToString( ( (2 * HashMD5 * Num1 * pow(Hash32, 3) - pow(HashMD5, 4) + RSA * pow(Hash32, 4) * \
				Num1 - 2 * RSA * Hash32 * pow(HashMD5, 3)) * inverse (-HashMD5 + RSA * Hash32, Num2) ) % Num2 );
}

string BigToString( Big& big )
{
	miracl *mip=get_mip();
	mip->IOBUFF << big;
	return mip->IOBUFF;
}

/*****************************
		DLG stuff..
*****************************/

// bitmap
HBITMAP hBitmap;
HBRUSH hBrush;

BOOL CALLBACK DialogProc( HWND hwndDlg, UINT uMsg ,WPARAM wParam, LPARAM lParam )
{
	switch( uMsg )
	{
	case WM_CLOSE:
		EndDialog( hwndDlg, 0 );
		break;

	case WM_INITDIALOG:
		srand( GetTickCount() );
		SetWindowText( hwndDlg, Title );
		SetDlgItemText( hwndDlg, IDC_DATE, Date );
		SetWindowPos(hwndDlg,HWND_TOPMOST,0,0,0,0,SWP_NOSIZE|SWP_NOMOVE);

		SetDlgItemText( hwndDlg, IDC_SERIAL, "Enter your name..." );
		break;

	case WM_COMMAND:
		if( LOWORD(wParam) == IDC_NAME )
		{
			char buffer[ 512 ];

			if( !GetDlgItemText( hwndDlg, IDC_NAME, buffer, 511 ) )
			{
				SetDlgItemText( hwndDlg, IDC_SERIAL, "Enter your name..." );
				break;
			}

			name = buffer;

			KeyGen();

			SetDlgItemText( hwndDlg, IDC_SERIAL, serial.c_str() );
			InvalidateRect( GetDlgItem(hwndDlg, IDC_NAME), NULL, true );
			InvalidateRect( GetDlgItem(hwndDlg, IDC_SERIAL), NULL, true );
		}
		
		break;

		
	case WM_CTLCOLORDLG:
	case WM_CTLCOLORLISTBOX:
	case WM_CTLCOLOREDIT:
	case WM_CTLCOLORSTATIC:
		HDC hdc;
		hdc = ( HDC )wParam;
		SetTextColor( hdc, RGB( 255, 255, 255 ));
		SetBkMode( hdc, TRANSPARENT	);
		return ( BOOL )hBrush;
	}
	return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	hBitmap = LoadBitmap( hInstance, MAKEINTRESOURCE( IDB_MAIN ));
	hBrush = CreatePatternBrush( hBitmap );
	
	DialogBox( hInstance, MAKEINTRESOURCE( IDD_DLG ), 0, DialogProc );

	DeleteObject( hBitmap );
	DeleteObject( hBrush );

	return 0;
}