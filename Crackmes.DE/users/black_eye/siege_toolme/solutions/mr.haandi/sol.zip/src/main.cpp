#include <windows.h>
#include <windowsX.h>
#include <stdio.h>
#include "resource.h" 

HWND		hWnd;
unsigned char polyMultTable[256][256]={};
unsigned char polyInverseTable[256]={};

unsigned char polyLS[8][9];
unsigned char polyLSSolution[8];

void CreateTables(){
	for (unsigned int i=0;i!=256;i++){
		for (unsigned int j=0;j!=256;j++){
			polyMultTable[i][j]=0;
			for (unsigned char k=0;k!=8;k++){
				if (polyMultTable[i][j] & 0x80)
					polyMultTable[i][j]=(polyMultTable[i][j]*2)^0x87;
				else
					polyMultTable[i][j]*=2;
				if ((j<<k) & 0x80)
					polyMultTable[i][j]^=i;
			}
			if (polyMultTable[i][j]==1)
				polyInverseTable[i]=j;
		}
	}
}
unsigned int IntPowMod(unsigned int uiValue,unsigned char btPower){
	unsigned __int64 ui64Result=1;
	for (int i=0;i!=btPower;i++){
		ui64Result=(ui64Result*uiValue) % (unsigned __int64)0xFFFFFFFB;
	}
	return (unsigned int)ui64Result;
} //ui64Result=uiValue^btPower % 0xFFFFFFFB
unsigned char PolySelfPow(unsigned char polyInput, unsigned char polyPow){
	unsigned char polyResult=1;
	for (unsigned int i=0;i!=polyPow;i++){
		polyResult=polyMultTable[polyResult][polyInput];
	}
	return polyResult;
} //polyResult=polyInput^polyPow
unsigned char PolyPow(unsigned char polyInput){
	unsigned char polyResult=1;
	for (unsigned int i=0;i!=polyInput;i++){
		polyResult=polyMultTable[polyResult][0xAC];
	}
	return polyResult;
} //polyResult=(x^7+x^5+x^3+x^2)^polyInput
unsigned char PolyLog(unsigned char polyInput){
	unsigned char polyPow=1;
	unsigned char polyResult=0;
	while (polyPow!=polyInput){
		polyPow=polyMultTable[polyPow][0xAC];
		polyResult++;
	}
	return polyResult;
} //polyResult=log(btInput)
unsigned char EvalFunction(unsigned char polyX, unsigned char *btFunction, int iLen){
	unsigned char polyResult=0;
	for (int i=iLen;i>=0;i--){
		polyResult=polyMultTable[polyX][polyResult]^btFunction[i];
	}
	return polyResult;
} //polyResult=a0*polyX^0+a1*polyX^1+a2*polyX^2...
void SolveLS(){
	for (int i=0;i!=8;i++){
		for (int j=i;j!=8;j++){
			for (int k=8;k>=i;k--){
				polyLS[j][k]=polyMultTable[polyLS[j][k]][polyInverseTable[polyLS[j][i]]];
			}
		}
		for (int j=i+1;j!=8;j++){
			for (int k=8;k>=i;k--){
				polyLS[j][k]^=polyLS[i][k];
			}
		}
	}
	for (int i=7;i>=0;i--){
		polyLSSolution[i]=polyLS[i][8];
		for (int j=7;j>i;j--){
			polyLSSolution[i]^=polyMultTable[polyLS[i][j]][polyLSSolution[j]];
		}
	}
} //Solves the initialized system of linear equations
void SolveStep2(unsigned char *polyProduct,unsigned char *polyValues1){
	for (int i=0;i!=8;i++){
		polyValues1[i]=polyLSSolution[i];
		for (int j=0;j!=i;j++){
			polyValues1[i]^=polyMultTable[polyValues1[j]][polyProduct[i-j]];
		}
		polyValues1[i]=polyMultTable[polyValues1[i]][polyInverseTable[polyProduct[0]]];
	}
} //Find polyValues1 which satisfies polyValues2(polyLSSolution)=polyValues1*polyProduct
void SolveStep3(unsigned char *polyMain,unsigned char *polyValues1){
	for (int i=0;i!=8;i++){
		for (int j=0;j!=8;j++){
			polyLS[i][j]=PolySelfPow(polyMultTable[PolyPow(i+1)][0xF],j);
		}
	}
	for (int i=0;i!=8;i++){
		polyLS[i][8]=polyValues1[i];
		for (int j=8;j!=16;j++){
			polyLS[i][8]^=polyMultTable[PolySelfPow(polyMultTable[PolyPow(i+1)][0xF],j)][polyMain[j-0x8]];
		}
	}
	SolveLS();
}
void Action()
{
	char szName[256]="MR.HAANDI";
	GetDlgItemTextA(hWnd,IDC_DATA,szName, 256);
	if (strlen(szName)<1) {
		SetDlgItemTextA(hWnd,IDC_SIGNATURE,"Invalid data length!");
		return;
	}
	unsigned int uiV[4]={0x09012007,0x0FFFFFFF};
	for (int i=0;szName[i];i++){
		uiV[0]+=IntPowMod(0x09012007,szName[i]);
		uiV[1]+=IntPowMod(0x0FFFFFFF,szName[i]);
	}
	uiV[2]=uiV[1]; uiV[3]=uiV[0];
	for (int i=0;szName[i];i++){
		uiV[2]+=IntPowMod(uiV[1],szName[i]);
		uiV[3]+=IntPowMod(uiV[0],szName[i]);
	}
	unsigned char polyMain[2][8];
	memcpy(polyMain,&uiV,sizeof(uiV));
	unsigned char setPos[2][256] = {{8,9,10,11,12,13,14,15},{}};
	unsigned char polyProduct[256]={};
	memset(polyProduct,0,sizeof(polyProduct)); polyProduct[0]=1;
	for (int i=0;i!=8;i++){
		unsigned char polyResult=PolyPow(0xFF-setPos[0][i]);
		for (int j=i+1;j>0;j--){
			polyProduct[j]=polyMultTable[polyResult][polyProduct[j]]^polyProduct[j-1];
		}
		polyProduct[0]=polyMultTable[polyResult][polyProduct[0]];
	}
	unsigned char polyAdditional[5]={polyProduct[1],polyProduct[3],polyProduct[5],polyProduct[7]};
	
	unsigned char setRoots[8]={};
	unsigned char btPosition=0;
	for (int i=0;i!=256;i++){
		if (!EvalFunction(i,polyProduct,9))
			setRoots[btPosition++]=i;
	}
	unsigned char setXorValues[8]={};
	for (int i=0;i!=8;i++){
		setPos[1][i]=0xFF-PolyLog(setRoots[i]);
		setXorValues[i]=polyMain[0][setPos[1][i]-8]^polyMain[1][setPos[1][i]-8];
	}
	btPosition=0;
	for (int i=0;i!=8;i++){
		unsigned char polyRoot=setRoots[i];
		unsigned char polyResult=EvalFunction(polyMultTable[polyRoot][polyRoot],polyAdditional,4);
		polyResult=polyInverseTable[polyResult];
		polyResult=polyMultTable[polyResult][PolySelfPow(polyRoot,111)];
		polyResult=polyMultTable[setXorValues[i]][polyInverseTable[polyResult]];
		//polyLS represents a system of linear equations
		for (int j=0;j!=8;j++){
			polyLS[btPosition][j]=PolySelfPow(polyRoot,j);
		}
		polyLS[btPosition++][8]=polyResult;
	}
	
	SolveLS(); 
	unsigned char polyValues1[8];
	SolveStep2(polyProduct,polyValues1); 
	SolveStep3(polyMain[0],polyValues1);
	char szSerial[16+1]="";
	sprintf(szSerial,"%02X%02X%02X%02X%02X%02X%02X%02X",
		polyLSSolution[0],polyLSSolution[1],polyLSSolution[2],polyLSSolution[3],
		polyLSSolution[4],polyLSSolution[5],polyLSSolution[6],polyLSSolution[7]);
	SetDlgItemTextA(hWnd,IDC_SIGNATURE,szSerial);
	return;
}

void Initialization()
{
	CreateTables();
	SetDlgItemTextA(hWnd,IDC_DATA,"MR.HAANDI");
	
}

void ShowInfo(){
	char AboutMsg[400]="bLaCk-eye's SiEGE Toolme\n\n"
		"Protection: Modular Arithmetics, Polynomials\n\n"
		"Made by MR.HAANDI\n"
		"URL: http://mrhaandi.thecoderblogs.com\n"
		"MAIL: mrhaandi@gmail.com";

	MessageBoxA(hWnd,AboutMsg,"Info",MB_OK);
}

BOOL CALLBACK DlgProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam)
{
	switch(Message)
	{
	case WM_INITDIALOG:
		hWnd=hwnd;
		Initialization();
		break;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
			case IDC_DATA: if (HIWORD(wParam)==EN_CHANGE) Action(); break;
			case IDC_ACTION: Action(); break;
			case IDC_INFO: ShowInfo(); break;
			case IDC_EXIT: EndDialog(hwnd, 0); break;
		}
		break;
	case WM_CLOSE: EndDialog(hwnd, 0); break;
	default: return FALSE;
	}
	return TRUE;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)

{
	DialogBox(::GetModuleHandle(0), MAKEINTRESOURCE(IDD_DLGMAIN), NULL, DlgProc);
	return 0;
}