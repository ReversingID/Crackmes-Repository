#include <iomanip>
#include <iostream>
#include <gmp.h>
#include <sstream>
#include <string>

using namespace std;

string convertToNumber(string name)
{
  string goodPassword="524547444154412D";
  string result=goodPassword;

  for(int i=0;i<name.length();i++){
    ostringstream o;
    o<<hex<<setw(2)<<setfill('0')<<(int)name[i];
    result += o.str();
  }
  result += "00";
  cout <<result<<endl;

  return result;
}

int main()
{

  mpz_t d,n,res,b;

  string name;

  cout <<"Enter name : ";
  cin >> name;

  mpz_init(n);
  mpz_init(b);
  mpz_init(d);
  mpz_init(res);

  mpz_set_str(n,"C9003E9F9F2DD06EE2913D34805DC551D6C38A9E763704A16A88DC7793B0064BD1C7D49EAC51A3817969B351A7CC5FCECB1EFD2BFD436EC037B3008DD34F1D7B",16);
  mpz_set_str(d,"64801F4FCF96E83771489E9A402EE2A8EB61C54F3B1B8250B5446E3BC9D80325E8E3EA4F5628D1C0BCB4D9A8D3E62FE7658F7E95FEA1B7601BD98046E9A78EBF",16);
  mpz_set_str(res,convertToNumber(name).c_str(),16);

  mpz_powm(b,res,d,n); // b = res^d (mod n)
  gmp_printf("Serial number : %ZX\n",b);

  return 0;

}
