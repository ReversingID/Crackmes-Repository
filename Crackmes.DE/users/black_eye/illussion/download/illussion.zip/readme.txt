----------------- [ iLLUSiON CRACKME ] ---------------------------

author     : bLaCk-eye
protection : Math :)
difficulty : 1-2/10
type       : KEYGENME - PATCHME :)
date       : 3 August 2004


STORY:
	This little crackme is the result of a strange ideea i had.That's it you need to know.If you solve it i think you'll agree with me :)
	

RULEZ:
	Solving this little bastard is quite easy, you only need to think a little (i hope just like in all my crackmes :).
	To be a valid solution , your solution must be one of the two:
	1. keygen - i would love to see how you did it :)))
	2. keygen + patch - BE CAREFULL! you are allowed to patch ONLY 1 byte in the whole exe so be carefull!!

	Any other solution like patching more then one byte, a loader will not be accepted as valid!!!

GREETZ:

KANAL23 memberz: you lazy boys :)
TKM! memberz: hope we will do a good job :) (you know what i mean)
#Reversing4elites - my idols :)
.goolum - cheeerz mate :).watz up?
eveybody that knows me or has talked to me :-]


----------------- [ bLaCk-eye @ 2004 ] ---------------------------