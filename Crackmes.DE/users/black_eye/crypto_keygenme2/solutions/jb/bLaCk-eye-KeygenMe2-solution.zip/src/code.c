/*
cRYPTO kEYGENME 2 by bLaCk-eye
Keygen by jB

Protection: MD5, RC4, mod. maths
Compiled with lcc

The serials s1 and s2 must verify:
(s1^(-e)*userid^(-s2))*s2 mod n = rc4(name)
with n=p1*p2*p3*p4, product of 4 primes.
     e=F9B0D1F192EA5120EC1B
     
So we have s1^(-e)=rc4(name)*userid^s2*s2^(-1) mod n
ie: s1=(rc4(name)*userid^s2*s2^(-1))^d mod n,
with d=(-e)^(-1) mod phi(n)
      =(-e)^(-1) mod (p1-1)*(p2-1)*(p3-1)*(p4-1)
s2 is a random number such as 0<=s2<n
*/

#define WIN32_LEAN_AND_MEAN

#include <stdio.h>
#include <stdlib.h>
#include <windows.h> 	
#include <windowsx.h> 
#include <time.h>
#include "resource.h" 
#include "global.h"
#include "md5.h"
#include "miracl.h"
#include "rc4.h"

HINSTANCE hInst;
BOOL CALLBACK DlgProc( HWND hwnd, UINT uMsg, WPARAM wParam,LPARAM lParam);  
void GenererSerial(HWND hwnd);

unsigned char initname[]   = "jB / FFF";
unsigned char initcompany[] = "Fighting For Fun";
unsigned char name[100];
unsigned char company[100];
unsigned char userid[50];
unsigned char serial[400];


int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{ 
	hInstance = GetModuleHandle(NULL);
	hInst = hInstance;  
	DialogBoxParam(hInstance,MAKEINTRESOURCE(IDD_DIALOG1),NULL,DlgProc,(LPARAM)NULL);
 	return 0;
}

BOOL CALLBACK DlgProc( HWND hwnd, UINT uMsg, WPARAM wParam,LPARAM lParam)
{ 
   switch (uMsg)
   {
   		case WM_CLOSE:
   			EndDialog(hwnd,0); 
   			break;

		case WM_INITDIALOG:
			srand(time(NULL));
			SetDlgItemText(hwnd, IDC_NAME, initname);
			SetDlgItemText(hwnd, IDC_COMPANY, initcompany);
			SetFocus(GetDlgItem(hwnd,IDC_NAME));	
			return FALSE;
			
 		case WM_COMMAND:
   			switch(LOWORD(wParam))
   			{
   			case IDC_GENERER: 
				GenererSerial(hwnd);
				break;
			case IDC_ABOUT:
				MessageBox(hwnd, "cRYPTO kEYGENME 2 by bLaCk-eye\nKeygen by jB\n\nProtection: MD5-RC4-Modular maths","About...",MB_ICONINFORMATION | MB_OK | MB_APPLMODAL);
   			}
 		default:
   			return FALSE;
   }
   
   return TRUE;
}

void GenererSerial(HWND hwnd){
	MD5_CTX context;
	unsigned int tab[16];
	unsigned int id[4];
	rc4_key key;
  	unsigned char buffer[200];  	
	big p1,p2,p3,p4,n,phi_n,s1,s2,big_userid,cipher,e;
	int i=0;
	
	miracl *mip=mirsys(50,0);
	mip->IOBASE=16;

	memset(name, 0, sizeof(name));
   	memset(company, 0, sizeof(company));
   				
	GetDlgItemText(hwnd,IDC_NAME,name,100);
	GetDlgItemText(hwnd,IDC_COMPANY,company,100);
	GetDlgItemText(hwnd,IDC_USERID,userid,50);
	
	if(strlen(name)<3 || strlen(company)<3){
    	SetDlgItemText(hwnd, IDC_SERIAL, "Please enter a longer name or company");
    	return;
	}
		
	// Gets the User ID
    if(sscanf(userid,"%l8X%l8X%l8X%l8X",&id[0],&id[1],&id[2],&id[3])!=4){
    	SetDlgItemText(hwnd, IDC_SERIAL, "Please enter a valid User ID");
    	return;
	}

	if(!strcmp(name,company)){
	   	SetDlgItemText(hwnd, IDC_SERIAL, "Name and Company must be different to obtain a valid serial");
    	return;
	}
	    		
	p1=mirvar(0);
	p2=mirvar(0);
	p3=mirvar(0);
	p4=mirvar(0);
	n=mirvar(0);
	phi_n=mirvar(0);
	s1=mirvar(0);
	s2=mirvar(0);
	e=mirvar(0);
	big_userid=mirvar(0);
	cipher=mirvar(0);
	
	// Hashes the name
	MD5Init (&context);
    MD5Update (&context, name, strlen(name));
    MD5Final ((unsigned char *)tab, &context);

    // Hashes the company
   	MD5Init (&context);
    MD5Update (&context, company, strlen(company));
    MD5Final ((unsigned char *)(tab+4), &context);
    
    // Modifications on tab (coded like a pig, sorry...)
    tab[8]=(tab[0]+tab[4])*id[2];
    tab[12]=(tab[3]+tab[7])^id[3];
    
    while(i<3){
	    int ebpC=tab[5+i];
	    int esi=(tab[8+i] << 6)+(tab[5+i]^0xFFFFFFFF);
	    int ecx=tab[1+i];
	    int edx=(ecx>>4)+id[0];
	    ecx^=0xFFFFFFFF;
		esi^=edx;
		i++;
		edx=tab[11+i];
		tab[8+i]=esi;
		edx=edx*8+ecx;
		ecx=(ebpC >> 7)-id[1];
		edx^=ecx;
		tab[12+i]=edx;
	}

	// Converts the array, so we obtain 4 bignums		
    bytes_to_big(16,(unsigned char *)tab,p1);
    bytes_to_big(16,(unsigned char *)tab+16,p2);
    bytes_to_big(16,(unsigned char *)tab+32,p3);
    bytes_to_big(16,(unsigned char *)tab+48,p4);
    bytes_to_big(16,(unsigned char *)id,big_userid);
    
    nxprime(p1,p1);
    nxprime(p2,p2);
    nxprime(p3,p3);
    nxprime(p4,p4);
    
    // n=p1*p2*p3*p4
    multiply(p1,p2,n);
    multiply(n,p3,n);
    multiply(n,p4,n);
    
    // Calculus of phi(n)
    // phi(n) = (p1-1)*(p2-1)*(p3-1)*(p4-1) as p1,p2,p3,p4 are primes
    decr(p1,1,p1);
    decr(p2,1,p2);
    decr(p3,1,p3);
    decr(p4,1,p4);
	multiply(p1,p2,phi_n);
    multiply(phi_n,p3,phi_n);
    multiply(phi_n,p4,phi_n);
    
    // The 2nd part of the serial is a random bignum
    irand(rand());
    bigrand(n,s2);
    cotstr(s2,buffer);
    
    // Let's start some calculus
	powmod(big_userid,s2,n,big_userid);
    xgcd(s2,n,s2,s2,s2);

    // Encrypts the name (rc4), the key is the hash of the company
    prepare_key(tab+4,16,&key);
	rc4(name,32,&key);
	
	bytes_to_big(32,name,cipher);
	mad(cipher,big_userid,cipher,n,n,cipher);
	mad(cipher,s2,cipher,n,n,cipher);
		
	// Calculus of (-e)^(-1) mod phi(n)
	cinstr(e,"F9B0D1F192EA5120EC1B");
	negify(e,e);
	xgcd(e,phi_n,e,e,e);
	
	// End of the computation
	powmod(cipher,e,n,s2);
	
	cotstr(s2,serial);
	strcat(serial,"-");
	strcat(serial,buffer);
	SetDlgItemText(hwnd, IDC_SERIAL, serial);
	
	mirkill(p1);
	mirkill(p2);
	mirkill(p3);
	mirkill(p4);
	mirkill(n);
	mirkill(phi_n);
	mirkill(s1);
	mirkill(s2);
	mirkill(big_userid);
	mirkill(cipher);
	mirkill(e);
}