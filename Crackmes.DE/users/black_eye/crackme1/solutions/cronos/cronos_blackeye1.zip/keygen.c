#include <stdio.h>

void main(void)
{ char k1[]="Keygen1",k2[]="Kanal23",pass[]="aaaaaaa";
  int i,p=0,w1,w2,w;
  while(p<10)
  { w1=0;
    w2=0;
    for(i=0;i<7;i++)
    { w1=w1+(k1[i]^pass[i]);
      w2=w2+(k2[i]^pass[i]);
    }
    w=w1^w2;
    if(w==0x5c)
    { printf("%s\n",pass);
      p++;
    }
    i=6;
    pass[i]++;
    while(pass[i]>'z')
    { pass[i]='a';
      i--;
      pass[i]++;
    }
  } 
}