#include <windows.h>
#include "resource.h" 
#include "algorithm.cpp"
HWND		hWnd;

void Action()
{
	char szSerial[256]="";
	Generate(szSerial);
	SetDlgItemTextA(hWnd,IDC_SIGNATURE,szSerial);
	return;
}

void ShowInfo(){
	char AboutMsg[400]="Made by MR.HAANDI";
	MessageBoxA(hWnd,AboutMsg,"Info",MB_OK);
	return;
}
void Init()
{
	srand(GetTickCount());
	Initialize();
	set_key(ulKey, 256);
}
BOOL CALLBACK DlgProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam)
{
	switch(Message)
	{
	case WM_INITDIALOG:
		hWnd=hwnd;
		Init();
		break;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
			case IDC_ACTION: Action(); break;
			case IDC_INFO: ShowInfo(); break;
			case IDC_EXIT: EndDialog(hwnd, 0); break;
		}
		break;
	case WM_CLOSE: EndDialog(hwnd, 0); break;
	default: return FALSE;
	}
	return TRUE;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	DialogBox(::GetModuleHandle(0), MAKEINTRESOURCE(IDD_DLGMAIN), NULL, DlgProc);
	::ExitProcess(0);
	return 0;
}