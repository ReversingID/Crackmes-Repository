#include <windows.h>
#include "crypto/hpc_c.c"
#include "diskid32.cpp"
#include "crypto/md5.h"

unsigned long ulKey[64] = {
      0x8309D7A3, 0xF4F648F8, 0x781521B3, 0xF9AFB199, 0x8A4D2DE7, 0x2ECA4CCE, 
      0x1ED99552, 0x2844384E, 0xA002DF0A, 0x6860F117, 0xC37AB712, 0x533DFAE9, 
      0xBA6B8496, 0x199A63F2, 0xF5E5AE7C, 0xA26A16F7, 0x0F7BB639, 0x1B8193C1, 
      0xEA1AB4EE, 0xB82F91D0, 0x85DAB955, 0xE0BF413F, 0x5F80585A, 0x90D80B66, 
      0xA7C0D535, 0x69650633, 0x56940045, 0x769B986D, 0xC2B2FC97, 0x20DBFEB0, 
      0xE4D6EBE1, 0x1D4A47DD, 0x6E9EED42, 0x43CD3C49, 0xD407D227, 0x1867C7DE, 
      0x1F30CB89, 0xAA8FC68D, 0xC9DC74C8, 0xA4315C5D, 0x2C618870, 0x872B0D9F, 
      0x64548250, 0x40037D26, 0x731C4B34, 0x3BFDC4D1, 0xAB7FFBCC, 0xA55B3EE6, 
      0x9C2304AD, 0xF0225114, 0x7E717929, 0xE20E8CFF, 0x72BCEF0C, 0xA1376F75, 
      0x628ED3EC, 0xE810868B, 0xBE117708, 0xC5244F92, 0xCF9D3632, 0xACBBA6F3, 
      0x13A96C5E, 0xE3B52557, 0x013AA8BD, 0x462A5905
};
unsigned __int64 n=0xFFFFFFFFFFFFFFFF;
unsigned __int64 n_f[7]={0x3,0x5,0x11,0x101,0x281,0x10001,0x663D81};

unsigned __int64 PolyMul(unsigned __int64 p1,unsigned __int64 p2)
{
	unsigned __int64 p3=0;
	bool bReduce;
	do
	{
		if (p2 & 1) p3^=p1;
		bReduce=(p1>>63);
		p1<<=1;
		if (bReduce) p1^=0x1B;
	} while (p2>>=1);
	return p3;
}
unsigned __int64 PolyPow(unsigned __int64 p,unsigned __int64 e)
{
	unsigned __int64 p3=1;
	bool bReduce;
	do
	{
		if (e & 1) p3=PolyMul(p3,p);
		p=PolyMul(p,p);
	} while (e>>=1);
	return p3;
}
unsigned __int64 PolyInv(unsigned __int64 p)
{
	return PolyPow(p,0xFFFFFFFFFFFFFFFE);
};
unsigned __int64 ui64AddMod(unsigned __int64 p1,unsigned __int64 p2)
{
	unsigned __int64 p3=0;
	bool bReduce=(((p1+p2)<p1) || (((p1+p2)<p2)));
	p3=p1+p2;
	if (bReduce) p3+=n+2;
	return p3;
}
unsigned __int64 ui64MulMod(unsigned __int64 p1,unsigned __int64 p2)
{
	unsigned __int64 p3=0;
	bool bReduce;
	do
	{
		if (p2 & 1) p3=ui64AddMod(p3,p1);
		bReduce=(p1>>63);
		p1<<=1;
		if (bReduce) p1+=n+2;
	} while (p2>>=1);
	return p3;
}
unsigned __int64 GetOrder(unsigned __int64 p)
{
	unsigned __int64 p_n=0xFFFFFFFFFFFFFFFF;
	for (int i=0;i!=7;i++)
		if (PolyPow(p,p_n/n_f[i])==1) 
			p_n/=n_f[i];
	return p_n;
}
unsigned __int64 ui64Rand()
{
	unsigned __int64 p=0;
	for (int i=0;i!=5;i++)
		p=(p<<15) | rand();
	return p;
}
unsigned __int64 GetFieldGenerator()
{
	unsigned __int64 p;
	do{
		p=ui64Rand();
	} while (GetOrder(p)!=n);
	return p;
};
unsigned __int64 ui64Invert(unsigned __int64 a,unsigned __int64  n)
{
	unsigned __int64 b=n;
    __int64 x=0,lastx= 1;
    unsigned __int64 temp,quotient;
    while (b!=0)
	{
		temp=b;
        quotient=a/b;
        b=a%b; a=temp;
        temp=x; x=lastx-quotient*x; lastx=temp;
	}
	while (lastx<0) lastx+=n;
    return lastx;
}
unsigned __int64 NaivePolyLog(unsigned __int64 g,unsigned __int64 p,unsigned __int64 g_n)
{
	while (g_n--)
		if (PolyPow(g,g_n)==p)
			return g_n;
	return 0;
}
unsigned __int64 PollardRhoPolyLog(unsigned __int64 g,unsigned __int64 p,unsigned __int64 g_n)
{
	unsigned __int64 x[2],a[2],b[2];
	unsigned __int64 ra[16],rb[16],rp[16];
	for (int i=0;i!=16;i++)
	{
		ra[i]=ui64Rand() % (g_n-1)+1;
		rb[i]=ui64Rand() % (g_n-1)+1;
		rp[i]=PolyMul(PolyPow(g,ra[i]),PolyPow(p,rb[i]));
	}
	a[0]=a[1]=ra[0];
	b[0]=b[1]=rb[0];
	x[0]=x[1]=rp[0];
	do
	{
		int j=x[0] % 16;
		x[0]=PolyMul(x[0],rp[j]);
		a[0]=(a[0]+ra[j]) % g_n;
		b[0]=(b[0]+rb[j]) % g_n;
		for (int i=0;i!=2;i++)
		{
			j=x[1] % 16;
			x[1]=PolyMul(x[1],rp[j]);
			a[1]=(a[1]+ra[j]) % g_n;
			b[1]=(b[1]+rb[j]) % g_n;
		}
	} while (x[0]!=x[1]);
	a[0]=(g_n+a[0]-a[1]) % g_n;
	b[1]=(g_n+b[1]-b[0]) % g_n;
	return (a[0]*ui64Invert(b[1],g_n)) % g_n;
}
unsigned __int64 PolyLog(unsigned __int64 g,unsigned __int64 p)
{
	unsigned __int64 log[7];
	unsigned __int64 l=0;
	for (int i=0;i!=5;i++){
		log[i]=NaivePolyLog(PolyPow(g,n/n_f[i]),PolyPow(p,n/n_f[i]),n_f[i]);
		l=ui64AddMod(l,ui64MulMod(ui64MulMod(log[i],(n/n_f[i])),ui64Invert((n/n_f[i]) % n_f[i],n_f[i])));
	}
	for (int i=5;i!=7;i++){
		log[i]=PollardRhoPolyLog(PolyPow(g,n/n_f[i]),PolyPow(p,n/n_f[i]),n_f[i]);
		l=ui64AddMod(l,ui64MulMod(ui64MulMod(log[i],(n/n_f[i])),ui64Invert((n/n_f[i]) % n_f[i],n_f[i])));
	}
	return l;
}
	unsigned __int64 h;
	const unsigned __int64 c=0xF933547C63CBB977;
void Initialize()
{
	char szDriveId[256]="";
	getHardDriveComputerID (szDriveId);
	MD5Context context;
	MD5Init(&context);
	MD5Update(&context, (unsigned char *)szDriveId,strlen(szDriveId));
	unsigned char digest[16];
	MD5Final(digest, &context);
	unsigned int uid[4];
	unsigned __int64 ui64d[2];
	memcpy(ui64d,digest,16);
	ui64d[0]*=ui64d[1];
	h=0;
	for (int i=0;i!=8;i++){
		h<<=8;
		h|=ui64d[0] & 0xFF;
		ui64d[0]>>=8;
		
	}
}
void Generate(char *szSerial)
{
	u4byte uiSerial[4]={};
	unsigned __int64 s1,s2,s3;
	s1=GetFieldGenerator();
	s2=(s1>>32) | (s1<<32);
	//s3=Log_s1(2^h/c^s2)
	s3=PolyLog(s1,PolyMul(PolyPow(2,h),PolyInv(PolyPow(c,s2))));

	uiSerial[0]=bswap((unsigned int)(s1 & 0xFFFFFFFF));
	uiSerial[1]=bswap((unsigned int)((s1>>32) & 0xFFFFFFFF));
	uiSerial[3]=bswap((unsigned int)(s3 & 0xFFFFFFFF));
	uiSerial[2]=bswap((unsigned int)((s3>>32) & 0xFFFFFFFF));
	//HPC encryption
	encrypt(uiSerial,uiSerial);
	sprintf(szSerial,"%u-%u-%u-%u",uiSerial[0],uiSerial[1],uiSerial[2],uiSerial[3]);
}