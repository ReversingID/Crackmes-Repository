/*
 *  [> bLaCk-eye Crypto keygenme v1
 *
 *  Keygened by Amenesia//tkm! using miracl
 *
 *
 */

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <miracl.h>

#define NPRIMES 4

static big p,p1,order,lim1,lim2;
static BOOL flag=FALSE;

void iterate(big x,big q,big r,big a,big b)
{ /* apply Pollards random mapping */
    if (compare(x,lim1)<0)
    {
        mad(x,q,q,p,p,x);
        incr(a,1,a);
        if (compare(a,order)==0) zero(a);
        return;
    }
    if (compare(x,lim2)<0)
    {
        mad(x,x,x,p,p,x);
        premult(a,2,a);
        if (compare(a,order)>=0) subtract(a,order,a);
        premult(b,2,b);
        if (compare(b,order)>=0) subtract(b,order,b);
        return;
    }
    mad(x,r,r,p,p,x);
    incr(b,1,b);
    if (compare(b,order)==0) zero(b);
}

long rho(big q,big r,big m,big n)
{ /* find q^m = r^n */
    long iter,rr,i;
    big ax,bx,ay,by,x,y;
    ax=mirvar(0);
    bx=mirvar(0);
    ay=mirvar(0);
    by=mirvar(0);
    x=mirvar(1);
    y=mirvar(1);
    iter=0L;
    rr=1L;
    do
    { /* Brent's Cycle finder */
        copy(y,x);
        copy(ay,ax);
        copy(by,bx);
        rr*=2;
        for (i=1;i<=rr;i++)
        {
            iter++;
            iterate(y,q,r,ay,by);
            if (compare(x,y)==0) break;
        }
    } while (compare(x,y)!=0);

    subtract(ax,ay,m);
    if (size(m)<0) add(m,order,m);
    subtract(by,bx,n);
    if (size(n)<0) add(n,order,n);
    mirkill(y);
    mirkill(x);
    mirkill(by);
    mirkill(ay);
    mirkill(bx);
    mirkill(ax);
    return iter;
}


    asm
    { 

	MD5		proc near		

	var_10		= dword	ptr -10h
	var_C		= dword	ptr -0Ch
	var_8		= dword	ptr -8
	var_4		= dword	ptr -4
	arg_0		= dword	ptr  8
	arg_4		= dword	ptr  0Ch
	arg_8		= dword	ptr  10h

		push	ebp
		mov	ebp, esp
		add	esp, 0FFFFFFF0h
		push	eax
		push	ebx
		push	ecx
		push	edx
		push	edi
		push	esi
		mov	edi, [ebp+arg_0]
		mov	eax, [ebp+arg_4]
		inc	eax
		add	edi, eax
		mov	byte ptr [edi-1], 80h
		xor	edx, edx
		mov	ebx, 40h
		div	ebx
		neg	edx
		add	edx, 40h
		cmp	edx, 8
		jnb	short loc_0_401034
		add	edx, 40h

	loc_0_401034:				
		mov	ecx, edx
		xor	al, al
		repe stosb
		mov	eax, [ebp+arg_4]
		inc	edx
		add	[ebp+arg_4], edx
		xor	edx, edx
		mov	ebx, 8
		mul	ebx
		mov	[edi-8], eax
		mov	[edi-4], edx
		mov	edx, [ebp+arg_4]
		mov	edi, [ebp+arg_0]
		mov	esi, [ebp+arg_8]
		mov	dword ptr [esi], 67452301h
		mov	dword ptr [esi+4], 0EFCDAB89h
		mov	dword ptr [esi+8], 9BADC0DEh
		mov	dword ptr [esi+0Ch], 10325476h

	loc_0_401074:				
		mov	eax, [esi]
		mov	[ebp+var_4], eax
		mov	eax, [esi+4]
		mov	[ebp+var_8], eax
		mov	eax, [esi+8]
		mov	[ebp+var_C], eax
		mov	eax, [esi+0Ch]
		mov	[ebp+var_10], eax
		mov	eax, [ebp+var_8]
		mov	ebx, [ebp+var_C]
		mov	ecx, [ebp+var_10]
		and	ebx, eax
		not	eax
		and	eax, ecx
		or	eax, ebx
		add	eax, [ebp+var_4]
		add	eax, [edi]
		add	eax, 0D76AA478h
		mov	cl, 7
		rol	eax, cl
		add	eax, [ebp+var_8]
		mov	[ebp+var_4], eax
		mov	eax, [ebp+var_4]
		mov	ebx, [ebp+var_8]
		mov	ecx, [ebp+var_C]
		and	ebx, eax
		not	eax
		and	eax, ecx
		or	eax, ebx
		add	eax, [ebp+var_10]
		add	eax, [edi+4]
		add	eax, 0E8C7B756h
		mov	cl, 0Ch
		rol	eax, cl
		add	eax, [ebp+var_4]
		mov	[ebp+var_10], eax
		mov	eax, [ebp+var_10]
		mov	ebx, [ebp+var_4]
		mov	ecx, [ebp+var_8]
		and	ebx, eax
		not	eax
		and	eax, ecx
		or	eax, ebx
		add	eax, [ebp+var_C]
		add	eax, [edi+8]
		add	eax, 242070DBh
		mov	cl, 11h
		rol	eax, cl
		add	eax, [ebp+var_10]
		mov	[ebp+var_C], eax
		mov	eax, [ebp+var_C]
		mov	ebx, [ebp+var_10]
		mov	ecx, [ebp+var_4]
		and	ebx, eax
		not	eax
		and	eax, ecx
		or	eax, ebx
		add	eax, [ebp+var_8]
		add	eax, [edi+0Ch]
		add	eax, 0C1BDCEEEh
		mov	cl, 16h
		rol	eax, cl
		add	eax, [ebp+var_C]
		mov	[ebp+var_8], eax
		mov	eax, [ebp+var_8]
		mov	ebx, [ebp+var_C]
		mov	ecx, [ebp+var_10]
		and	ebx, eax
		not	eax
		and	eax, ecx
		or	eax, ebx
		add	eax, [ebp+var_4]
		add	eax, [edi+10h]
		add	eax, 0F57C0FAFh
		mov	cl, 7
		rol	eax, cl
		add	eax, [ebp+var_8]
		mov	[ebp+var_4], eax
		mov	eax, [ebp+var_4]
		mov	ebx, [ebp+var_8]
		mov	ecx, [ebp+var_C]
		and	ebx, eax
		not	eax
		and	eax, ecx
		or	eax, ebx
		add	eax, [ebp+var_10]
		add	eax, [edi+14h]
		add	eax, 4787C62Ah
		mov	cl, 0Ch
		rol	eax, cl
		add	eax, [ebp+var_4]
		mov	[ebp+var_10], eax
		mov	eax, [ebp+var_10]
		mov	ebx, [ebp+var_4]
		mov	ecx, [ebp+var_8]
		and	ebx, eax
		not	eax
		and	eax, ecx
		or	eax, ebx
		add	eax, [ebp+var_C]
		add	eax, [edi+18h]
		add	eax, 0A8304613h
		mov	cl, 11h
		rol	eax, cl
		add	eax, [ebp+var_10]
		mov	[ebp+var_C], eax
		mov	eax, [ebp+var_C]
		mov	ebx, [ebp+var_10]
		mov	ecx, [ebp+var_4]
		and	ebx, eax
		not	eax
		and	eax, ecx
		or	eax, ebx
		add	eax, [ebp+var_8]
		add	eax, [edi+1Ch]
		add	eax, 0FD469501h
		mov	cl, 16h
		rol	eax, cl
		add	eax, [ebp+var_C]
		mov	[ebp+var_8], eax
		mov	eax, [ebp+var_8]
		mov	ebx, [ebp+var_C]
		mov	ecx, [ebp+var_10]
		and	ebx, eax
		not	eax
		and	eax, ecx
		or	eax, ebx
		add	eax, [ebp+var_4]
		add	eax, [edi+20h]
		add	eax, 698098D8h
		mov	cl, 7
		rol	eax, cl
		add	eax, [ebp+var_8]
		mov	[ebp+var_4], eax
		mov	eax, [ebp+var_4]
		mov	ebx, [ebp+var_8]
		mov	ecx, [ebp+var_C]
		and	ebx, eax
		not	eax
		and	eax, ecx
		or	eax, ebx
		add	eax, [ebp+var_10]
		add	eax, [edi+24h]
		add	eax, 8B44F7AFh
		mov	cl, 0Ch
		rol	eax, cl
		add	eax, [ebp+var_4]
		mov	[ebp+var_10], eax
		mov	eax, [ebp+var_10]
		mov	ebx, [ebp+var_4]
		mov	ecx, [ebp+var_8]
		and	ebx, eax
		not	eax
		and	eax, ecx
		or	eax, ebx
		add	eax, [ebp+var_C]
		add	eax, [edi+28h]
		add	eax, 0FFFF5BB1h
		mov	cl, 11h
		rol	eax, cl
		add	eax, [ebp+var_10]
		mov	[ebp+var_C], eax
		mov	eax, [ebp+var_C]
		mov	ebx, [ebp+var_10]
		mov	ecx, [ebp+var_4]
		and	ebx, eax
		not	eax
		and	eax, ecx
		or	eax, ebx
		add	eax, [ebp+var_8]
		add	eax, [edi+2Ch]
		add	eax, 895CD7BEh
		mov	cl, 16h
		rol	eax, cl
		add	eax, [ebp+var_C]
		mov	[ebp+var_8], eax
		mov	eax, [ebp+var_8]
		mov	ebx, [ebp+var_C]
		mov	ecx, [ebp+var_10]
		and	ebx, eax
		not	eax
		and	eax, ecx
		or	eax, ebx
		add	eax, [ebp+var_4]
		add	eax, [edi+30h]
		add	eax, 6B901122h
		mov	cl, 7
		rol	eax, cl
		add	eax, [ebp+var_8]
		mov	[ebp+var_4], eax
		mov	eax, [ebp+var_4]
		mov	ebx, [ebp+var_8]
		mov	ecx, [ebp+var_C]
		and	ebx, eax
		not	eax
		and	eax, ecx
		or	eax, ebx
		add	eax, [ebp+var_10]
		add	eax, [edi+34h]
		add	eax, 0FD987193h
		mov	cl, 0Ch
		rol	eax, cl
		add	eax, [ebp+var_4]
		mov	[ebp+var_10], eax
		mov	eax, [ebp+var_10]
		mov	ebx, [ebp+var_4]
		mov	ecx, [ebp+var_8]
		and	ebx, eax
		not	eax
		and	eax, ecx
		or	eax, ebx
		add	eax, [ebp+var_C]
		add	eax, [edi+38h]
		add	eax, 0A679438Eh
		mov	cl, 11h
		rol	eax, cl
		add	eax, [ebp+var_10]
		mov	[ebp+var_C], eax
		mov	eax, [ebp+var_C]
		mov	ebx, [ebp+var_10]
		mov	ecx, [ebp+var_4]
		and	ebx, eax
		not	eax
		and	eax, ecx
		or	eax, ebx
		add	eax, [ebp+var_8]
		add	eax, [edi+3Ch]
		add	eax, 49B40821h
		mov	cl, 16h
		rol	eax, cl
		add	eax, [ebp+var_C]
		mov	[ebp+var_8], eax
		mov	eax, [ebp+var_8]
		mov	ebx, [ebp+var_C]
		mov	ecx, [ebp+var_10]
		and	eax, ecx
		not	ecx
		and	ecx, ebx
		or	eax, ecx
		add	eax, [ebp+var_4]
		add	eax, [edi+4]
		add	eax, 0F61E2562h
		mov	cl, 5
		rol	eax, cl
		add	eax, [ebp+var_8]
		mov	[ebp+var_4], eax
		mov	eax, [ebp+var_4]
		mov	ebx, [ebp+var_8]
		mov	ecx, [ebp+var_C]
		and	eax, ecx
		not	ecx
		and	ecx, ebx
		or	eax, ecx
		add	eax, [ebp+var_10]
		add	eax, [edi+18h]
		add	eax, 0C040B340h
		mov	cl, 9
		rol	eax, cl
		add	eax, [ebp+var_4]
		mov	[ebp+var_10], eax
		mov	eax, [ebp+var_10]
		mov	ebx, [ebp+var_4]
		mov	ecx, [ebp+var_8]
		and	eax, ecx
		not	ecx
		and	ecx, ebx
		or	eax, ecx
		add	eax, [ebp+var_C]
		add	eax, [edi+2Ch]
		add	eax, 265E5A51h
		mov	cl, 0Eh
		rol	eax, cl
		add	eax, [ebp+var_10]
		mov	[ebp+var_C], eax
		mov	eax, [ebp+var_C]
		mov	ebx, [ebp+var_10]
		mov	ecx, [ebp+var_4]
		and	eax, ecx
		not	ecx
		and	ecx, ebx
		or	eax, ecx
		add	eax, [ebp+var_8]
		add	eax, [edi]
		add	eax, 0E9B6C7AAh
		mov	cl, 14h
		rol	eax, cl
		add	eax, [ebp+var_C]
		mov	[ebp+var_8], eax
		mov	eax, [ebp+var_8]
		mov	ebx, [ebp+var_C]
		mov	ecx, [ebp+var_10]
		and	eax, ecx
		not	ecx
		and	ecx, ebx
		or	eax, ecx
		add	eax, [ebp+var_4]
		add	eax, [edi+14h]
		add	eax, 0D62F105Dh
		mov	cl, 5
		rol	eax, cl
		add	eax, [ebp+var_8]
		mov	[ebp+var_4], eax
		mov	eax, [ebp+var_4]
		mov	ebx, [ebp+var_8]
		mov	ecx, [ebp+var_C]
		and	eax, ecx
		not	ecx
		and	ecx, ebx
		or	eax, ecx
		add	eax, [ebp+var_10]
		add	eax, [edi+28h]
		add	eax, 2441453h
		mov	cl, 9
		rol	eax, cl
		add	eax, [ebp+var_4]
		mov	[ebp+var_10], eax
		mov	eax, [ebp+var_10]
		mov	ebx, [ebp+var_4]
		mov	ecx, [ebp+var_8]
		and	eax, ecx
		not	ecx
		and	ecx, ebx
		or	eax, ecx
		add	eax, [ebp+var_C]
		add	eax, [edi+3Ch]
		add	eax, 0D8A4E681h
		mov	cl, 0Eh
		rol	eax, cl
		add	eax, [ebp+var_10]
		mov	[ebp+var_C], eax
		mov	eax, [ebp+var_C]
		mov	ebx, [ebp+var_10]
		mov	ecx, [ebp+var_4]
		and	eax, ecx
		not	ecx
		and	ecx, ebx
		or	eax, ecx
		add	eax, [ebp+var_8]
		add	eax, [edi+10h]
		add	eax, 0E7D3FBC8h
		mov	cl, 14h
		rol	eax, cl
		add	eax, [ebp+var_C]
		mov	[ebp+var_8], eax
		mov	eax, [ebp+var_8]
		mov	ebx, [ebp+var_C]
		mov	ecx, [ebp+var_10]
		and	eax, ecx
		not	ecx
		and	ecx, ebx
		or	eax, ecx
		add	eax, [ebp+var_4]
		add	eax, [edi+24h]
		add	eax, 21E1CDE6h
		mov	cl, 5
		rol	eax, cl
		add	eax, [ebp+var_8]
		mov	[ebp+var_4], eax
		mov	eax, [ebp+var_4]
		mov	ebx, [ebp+var_8]
		mov	ecx, [ebp+var_C]
		and	eax, ecx
		not	ecx
		and	ecx, ebx
		or	eax, ecx
		add	eax, [ebp+var_10]
		add	eax, [edi+38h]
		add	eax, 0C33707D6h
		mov	cl, 9
		rol	eax, cl
		add	eax, [ebp+var_4]
		mov	[ebp+var_10], eax
		mov	eax, [ebp+var_10]
		mov	ebx, [ebp+var_4]
		mov	ecx, [ebp+var_8]
		and	eax, ecx
		not	ecx
		and	ecx, ebx
		or	eax, ecx
		add	eax, [ebp+var_C]
		add	eax, [edi+0Ch]
		add	eax, 0F4D50D87h
		mov	cl, 0Eh
		rol	eax, cl
		add	eax, [ebp+var_10]
		mov	[ebp+var_C], eax
		mov	eax, [ebp+var_C]
		mov	ebx, [ebp+var_10]
		mov	ecx, [ebp+var_4]
		and	eax, ecx
		not	ecx
		and	ecx, ebx
		or	eax, ecx
		add	eax, [ebp+var_8]
		add	eax, [edi+20h]
		add	eax, 455A14EDh
		mov	cl, 14h
		rol	eax, cl
		add	eax, [ebp+var_C]
		mov	[ebp+var_8], eax
		mov	eax, [ebp+var_8]
		mov	ebx, [ebp+var_C]
		mov	ecx, [ebp+var_10]
		and	eax, ecx
		not	ecx
		and	ecx, ebx
		or	eax, ecx
		add	eax, [ebp+var_4]
		add	eax, [edi+34h]
		add	eax, 0A9E3E905h
		mov	cl, 5
		rol	eax, cl
		add	eax, [ebp+var_8]
		mov	[ebp+var_4], eax
		mov	eax, [ebp+var_4]
		mov	ebx, [ebp+var_8]
		mov	ecx, [ebp+var_C]
		and	eax, ecx
		not	ecx
		and	ecx, ebx
		or	eax, ecx
		add	eax, [ebp+var_10]
		add	eax, [edi+8]
		add	eax, 0FCEFA3F8h
		mov	cl, 9
		rol	eax, cl
		add	eax, [ebp+var_4]
		mov	[ebp+var_10], eax
		mov	eax, [ebp+var_10]
		mov	ebx, [ebp+var_4]
		mov	ecx, [ebp+var_8]
		and	eax, ecx
		not	ecx
		and	ecx, ebx
		or	eax, ecx
		add	eax, [ebp+var_C]
		add	eax, [edi+1Ch]
		add	eax, 676F02D9h
		mov	cl, 0Eh
		rol	eax, cl
		add	eax, [ebp+var_10]
		mov	[ebp+var_C], eax
		mov	eax, [ebp+var_C]
		mov	ebx, [ebp+var_10]
		mov	ecx, [ebp+var_4]
		and	eax, ecx
		not	ecx
		and	ecx, ebx
		or	eax, ecx
		add	eax, [ebp+var_8]
		add	eax, [edi+30h]
		add	eax, 8D2A4C8Ah
		mov	cl, 14h
		rol	eax, cl
		add	eax, [ebp+var_C]
		mov	[ebp+var_8], eax
		mov	eax, [ebp+var_8]
		mov	ebx, [ebp+var_C]
		mov	ecx, [ebp+var_10]
		xor	eax, ebx
		xor	eax, ecx
		add	eax, [ebp+var_4]
		add	eax, [edi+14h]
		add	eax, 0FFFA3942h
		mov	cl, 4
		rol	eax, cl
		add	eax, [ebp+var_8]
		mov	[ebp+var_4], eax
		mov	eax, [ebp+var_4]
		mov	ebx, [ebp+var_8]
		mov	ecx, [ebp+var_C]
		xor	eax, ebx
		xor	eax, ecx
		add	eax, [ebp+var_10]
		add	eax, [edi+20h]
		add	eax, 8771F681h
		mov	cl, 0Bh
		rol	eax, cl
		add	eax, [ebp+var_4]
		mov	[ebp+var_10], eax
		mov	eax, [ebp+var_10]
		mov	ebx, [ebp+var_4]
		mov	ecx, [ebp+var_8]
		xor	eax, ebx
		xor	eax, ecx
		add	eax, [ebp+var_C]
		add	eax, [edi+2Ch]
		add	eax, 6D9D6122h
		mov	cl, 10h
		rol	eax, cl
		add	eax, [ebp+var_10]
		mov	[ebp+var_C], eax
		mov	eax, [ebp+var_C]
		mov	ebx, [ebp+var_10]
		mov	ecx, [ebp+var_4]
		xor	eax, ebx
		xor	eax, ecx
		add	eax, [ebp+var_8]
		add	eax, [edi+38h]
		add	eax, 0FDE5380Ch
		mov	cl, 17h
		rol	eax, cl
		add	eax, [ebp+var_C]
		mov	[ebp+var_8], eax
		mov	eax, [ebp+var_8]
		mov	ebx, [ebp+var_C]
		mov	ecx, [ebp+var_10]
		xor	eax, ebx
		xor	eax, ecx
		add	eax, [ebp+var_4]
		add	eax, [edi+4]
		add	eax, 0A4BEEA44h
		mov	cl, 4
		rol	eax, cl
		add	eax, [ebp+var_8]
		mov	[ebp+var_4], eax
		mov	eax, [ebp+var_4]
		mov	ebx, [ebp+var_8]
		mov	ecx, [ebp+var_C]
		xor	eax, ebx
		xor	eax, ecx
		add	eax, [ebp+var_10]
		add	eax, [edi+10h]
		add	eax, 4BDECFA9h
		mov	cl, 0Bh
		rol	eax, cl
		add	eax, [ebp+var_4]
		mov	[ebp+var_10], eax
		mov	eax, [ebp+var_10]
		mov	ebx, [ebp+var_4]
		mov	ecx, [ebp+var_8]
		xor	eax, ebx
		xor	eax, ecx
		add	eax, [ebp+var_C]
		add	eax, [edi+1Ch]
		add	eax, 0F6BB4B60h
		mov	cl, 10h
		rol	eax, cl
		add	eax, [ebp+var_10]
		mov	[ebp+var_C], eax
		mov	eax, [ebp+var_C]
		mov	ebx, [ebp+var_10]
		mov	ecx, [ebp+var_4]
		xor	eax, ebx
		xor	eax, ecx
		add	eax, [ebp+var_8]
		add	eax, [edi+28h]
		add	eax, 0BEBFBC70h
		mov	cl, 17h
		rol	eax, cl
		add	eax, [ebp+var_C]
		mov	[ebp+var_8], eax
		mov	eax, [ebp+var_8]
		mov	ebx, [ebp+var_C]
		mov	ecx, [ebp+var_10]
		xor	eax, ebx
		xor	eax, ecx
		add	eax, [ebp+var_4]
		add	eax, [edi+34h]
		add	eax, 289B7EC6h
		mov	cl, 4
		rol	eax, cl
		add	eax, [ebp+var_8]
		mov	[ebp+var_4], eax
		mov	eax, [ebp+var_4]
		mov	ebx, [ebp+var_8]
		mov	ecx, [ebp+var_C]
		xor	eax, ebx
		xor	eax, ecx
		add	eax, [ebp+var_10]
		add	eax, [edi]
		add	eax, 0EAA127FAh
		mov	cl, 0Bh
		rol	eax, cl
		add	eax, [ebp+var_4]
		mov	[ebp+var_10], eax
		mov	eax, [ebp+var_10]
		mov	ebx, [ebp+var_4]
		mov	ecx, [ebp+var_8]
		xor	eax, ebx
		xor	eax, ecx
		add	eax, [ebp+var_C]
		add	eax, [edi+0Ch]
		add	eax, 0D4EF3085h
		mov	cl, 10h
		rol	eax, cl
		add	eax, [ebp+var_10]
		mov	[ebp+var_C], eax
		mov	eax, [ebp+var_C]
		mov	ebx, [ebp+var_10]
		mov	ecx, [ebp+var_4]
		xor	eax, ebx
		xor	eax, ecx
		add	eax, [ebp+var_8]
		add	eax, [edi+18h]
		add	eax, 4881D05h
		mov	cl, 17h
		rol	eax, cl
		add	eax, [ebp+var_C]
		mov	[ebp+var_8], eax
		mov	eax, [ebp+var_8]
		mov	ebx, [ebp+var_C]
		mov	ecx, [ebp+var_10]
		xor	eax, ebx
		xor	eax, ecx
		add	eax, [ebp+var_4]
		add	eax, [edi+24h]
		add	eax, 0D9D4D039h
		mov	cl, 4
		rol	eax, cl
		add	eax, [ebp+var_8]
		mov	[ebp+var_4], eax
		mov	eax, [ebp+var_4]
		mov	ebx, [ebp+var_8]
		mov	ecx, [ebp+var_C]
		xor	eax, ebx
		xor	eax, ecx
		add	eax, [ebp+var_10]
		add	eax, [edi+30h]
		add	eax, 0E6DB99E5h
		mov	cl, 0Bh
		rol	eax, cl
		add	eax, [ebp+var_4]
		mov	[ebp+var_10], eax
		mov	eax, [ebp+var_10]
		mov	ebx, [ebp+var_4]
		mov	ecx, [ebp+var_8]
		xor	eax, ebx
		xor	eax, ecx
		add	eax, [ebp+var_C]
		add	eax, [edi+3Ch]
		add	eax, 1FA27CF8h
		mov	cl, 10h
		rol	eax, cl
		add	eax, [ebp+var_10]
		mov	[ebp+var_C], eax
		mov	eax, [ebp+var_C]
		mov	ebx, [ebp+var_10]
		mov	ecx, [ebp+var_4]
		xor	eax, ebx
		xor	eax, ecx
		add	eax, [ebp+var_8]
		add	eax, [edi+8]
		add	eax, 0C4AC5665h
		mov	cl, 17h
		rol	eax, cl
		add	eax, [ebp+var_C]
		mov	[ebp+var_8], eax
		mov	eax, [ebp+var_8]
		mov	ebx, [ebp+var_C]
		mov	ecx, [ebp+var_10]
		not	ecx
		or	eax, ecx
		xor	eax, ebx
		add	eax, [ebp+var_4]
		add	eax, [edi]
		add	eax, 0F4292244h
		mov	cl, 6
		rol	eax, cl
		add	eax, [ebp+var_8]
		mov	[ebp+var_4], eax
		mov	eax, [ebp+var_4]
		mov	ebx, [ebp+var_8]
		mov	ecx, [ebp+var_C]
		not	ecx
		or	eax, ecx
		xor	eax, ebx
		add	eax, [ebp+var_10]
		add	eax, [edi+1Ch]
		add	eax, 432AFF97h
		mov	cl, 0Ah
		rol	eax, cl
		add	eax, [ebp+var_4]
		mov	[ebp+var_10], eax
		mov	eax, [ebp+var_10]
		mov	ebx, [ebp+var_4]
		mov	ecx, [ebp+var_8]
		not	ecx
		or	eax, ecx
		xor	eax, ebx
		add	eax, [ebp+var_C]
		add	eax, [edi+38h]
		add	eax, 0AB9423A7h
		mov	cl, 0Fh
		rol	eax, cl
		add	eax, [ebp+var_10]
		mov	[ebp+var_C], eax
		mov	eax, [ebp+var_C]
		mov	ebx, [ebp+var_10]
		mov	ecx, [ebp+var_4]
		not	ecx
		or	eax, ecx
		xor	eax, ebx
		add	eax, [ebp+var_8]
		add	eax, [edi+14h]
		add	eax, 0FC93A039h
		mov	cl, 15h
		rol	eax, cl
		add	eax, [ebp+var_C]
		mov	[ebp+var_8], eax
		mov	eax, [ebp+var_8]
		mov	ebx, [ebp+var_C]
		mov	ecx, [ebp+var_10]
		not	ecx
		or	eax, ecx
		xor	eax, ebx
		add	eax, [ebp+var_4]
		add	eax, [edi+30h]
		add	eax, 655B59C3h
		mov	cl, 6
		rol	eax, cl
		add	eax, [ebp+var_8]
		mov	[ebp+var_4], eax
		mov	eax, [ebp+var_4]
		mov	ebx, [ebp+var_8]
		mov	ecx, [ebp+var_C]
		not	ecx
		or	eax, ecx
		xor	eax, ebx
		add	eax, [ebp+var_10]
		add	eax, [edi+0Ch]
		add	eax, 8F0CCC92h
		mov	cl, 0Ah
		rol	eax, cl
		add	eax, [ebp+var_4]
		mov	[ebp+var_10], eax
		mov	eax, [ebp+var_10]
		mov	ebx, [ebp+var_4]
		mov	ecx, [ebp+var_8]
		not	ecx
		or	eax, ecx
		xor	eax, ebx
		add	eax, [ebp+var_C]
		add	eax, [edi+28h]
		add	eax, 0FFEFF47Dh
		mov	cl, 0Fh
		rol	eax, cl
		add	eax, [ebp+var_10]
		mov	[ebp+var_C], eax
		mov	eax, [ebp+var_C]
		mov	ebx, [ebp+var_10]
		mov	ecx, [ebp+var_4]
		not	ecx
		or	eax, ecx
		xor	eax, ebx
		add	eax, [ebp+var_8]
		add	eax, [edi+4]
		add	eax, 85845DD1h
		mov	cl, 15h
		rol	eax, cl
		add	eax, [ebp+var_C]
		mov	[ebp+var_8], eax
		mov	eax, [ebp+var_8]
		mov	ebx, [ebp+var_C]
		mov	ecx, [ebp+var_10]
		not	ecx
		or	eax, ecx
		xor	eax, ebx
		add	eax, [ebp+var_4]
		add	eax, [edi+20h]
		add	eax, 6FA87E4Fh
		mov	cl, 6
		rol	eax, cl
		add	eax, [ebp+var_8]
		mov	[ebp+var_4], eax
		mov	eax, [ebp+var_4]
		mov	ebx, [ebp+var_8]
		mov	ecx, [ebp+var_C]
		not	ecx
		or	eax, ecx
		xor	eax, ebx
		add	eax, [ebp+var_10]
		add	eax, [edi+3Ch]
		add	eax, 0FE2CE6E0h
		mov	cl, 0Ah
		rol	eax, cl
		add	eax, [ebp+var_4]
		mov	[ebp+var_10], eax
		mov	eax, [ebp+var_10]
		mov	ebx, [ebp+var_4]
		mov	ecx, [ebp+var_8]
		not	ecx
		or	eax, ecx
		xor	eax, ebx
		add	eax, [ebp+var_C]
		add	eax, [edi+18h]
		add	eax, 0A3014314h
		mov	cl, 0Fh
		rol	eax, cl
		add	eax, [ebp+var_10]
		mov	[ebp+var_C], eax
		mov	eax, [ebp+var_C]
		mov	ebx, [ebp+var_10]
		mov	ecx, [ebp+var_4]
		not	ecx
		or	eax, ecx
		xor	eax, ebx
		add	eax, [ebp+var_8]
		add	eax, [edi+34h]
		add	eax, 4E0811A1h
		mov	cl, 15h
		rol	eax, cl
		add	eax, [ebp+var_C]
		mov	[ebp+var_8], eax
		mov	eax, [ebp+var_8]
		mov	ebx, [ebp+var_C]
		mov	ecx, [ebp+var_10]
		not	ecx
		or	eax, ecx
		xor	eax, ebx
		add	eax, [ebp+var_4]
		add	eax, [edi+10h]
		add	eax, 0F7537E82h
		mov	cl, 6
		rol	eax, cl
		add	eax, [ebp+var_8]
		mov	[ebp+var_4], eax
		mov	eax, [ebp+var_4]
		mov	ebx, [ebp+var_8]
		mov	ecx, [ebp+var_C]
		not	ecx
		or	eax, ecx
		xor	eax, ebx
		add	eax, [ebp+var_10]
		add	eax, [edi+2Ch]
		add	eax, 0BD3AF235h
		mov	cl, 0Ah
		rol	eax, cl
		add	eax, [ebp+var_4]
		mov	[ebp+var_10], eax
		mov	eax, [ebp+var_10]
		mov	ebx, [ebp+var_4]
		mov	ecx, [ebp+var_8]
		not	ecx
		or	eax, ecx
		xor	eax, ebx
		add	eax, [ebp+var_C]
		add	eax, [edi+8]
		add	eax, 2AD7D2BBh
		mov	cl, 0Fh
		rol	eax, cl
		add	eax, [ebp+var_10]
		mov	[ebp+var_C], eax
		mov	eax, [ebp+var_C]
		mov	ebx, [ebp+var_10]
		mov	ecx, [ebp+var_4]
		not	ecx
		or	eax, ecx
		xor	eax, ebx
		add	eax, [ebp+var_8]
		add	eax, [edi+24h]
		add	eax, 0EB86D391h
		mov	cl, 15h
		rol	eax, cl
		add	eax, [ebp+var_C]
		mov	[ebp+var_8], eax
		mov	eax, [ebp+var_4]
		add	[esi], eax
		mov	eax, [ebp+var_8]
		add	[esi+4], eax
		mov	eax, [ebp+var_C]
		add	[esi+8], eax
		mov	eax, [ebp+var_10]
		add	[esi+0Ch], eax
		add	edi, 40h
		sub	edx, 40h
		jnz	loc_0_401074
		mov	ecx, 4

	loc_0_4019CF:			
		mov	eax, [esi]
		xchg	al, ah
		rol	eax, 10h
		xchg	al, ah
		mov	[esi], eax
		add	esi, 4
		loop	loc_0_4019CF
		pop	esi
		pop	edi
		pop	edx
		pop	ecx
		pop	ebx
		pop	eax
		leave
		retn	0Ch
	MD5		endp
    }


void main()
{ 

  /* ---------------------- var ---------------------- */
  char hash[45];
  char key[4];
  char cnom[64];
  char nom[20];
  char keyend[30];
  int longNom;

    int i,id,np=4;
    long iter;
    big pp[NPRIMES],rem[NPRIMES];
    big m,n,Q,R,q,w,x,generator;
    big_chinese bc;
    miracl *mip=mirsys(50,0);
    for (i=0;i<NPRIMES;i++) 
    {
        pp[i]=mirvar(0);
        rem[i]=mirvar(0);
    }
    q=mirvar(0);
    generator=mirvar(0);
    Q=mirvar(0);
    R=mirvar(0);
    w=mirvar(0);
    m=mirvar(0);
    n=mirvar(0);
    x=mirvar(0);
    p=mirvar(0);
    p1=mirvar(1);
    order=mirvar(0);
    lim1=mirvar(0);
    lim2=mirvar(0);
 
	mip->IOBASE=16;

	cinstr(pp[0],"2");
	cinstr(pp[1],"9D");
	cinstr(pp[2],"9C7");
	cinstr(pp[3],"1244426C27");

	cinstr(p, "DB10266AB0FD5B");
	cinstr(p1,"DB10266AB0FD5A");
	cinstr(generator, "CC3183A81DF91");

    subdiv(p,3,lim1);
    premult(lim1,2,lim2);




/* --------------------- Start ---------------------------- */

    printf("\t [bLaCk-eye Crypto KeygenMe #1] by Amenesia//tkm!\n");
    printf("\t ------------------------------------------------\n");

    printf("Name: \t");
    scanf("%20s",&nom);
    strcpy(cnom,nom);
    longNom = strlen(nom);  

/* --------------------- Compute Key ---------------------------- */
   asm
    { 
                 .486                     // to use bswap	
 		 lea     ecx, [hash]
                 push    ecx
		 mov	 ebx, dword ptr longNom
                 push    ebx
                 lea     ecx, [cnom]
                 push    ecx
                 call    MD5
 		 lea     ecx, [hash]  
                 mov     eax, [ecx]
                 xor     eax, [ecx+12]
                 and     eax, [ecx+4]
                 imul    eax, [ecx+8]
		 lea     ecx, [key] 
		 bswap   eax
                 mov     [ecx], eax
    }
/* -------------------------------------------------------------- */ 
    
    bytes_to_big(4,key,q); 
    
    

/* --------------------- DLP Solver ---------------------------- */
    crt_init(&bc,np,pp);
    for (i=0;i<np;i++)
    { /* accumulate solutions for each pp */
        copy(p1,w);
        divide(w,pp[i],w);
        powmod(q,w,p,Q);
        powmod(generator,w,p,R);
        copy(pp[i],order);
        rho(Q,R,m,n);
        xgcd(m,order,w,w,w);
        mad(w,n,n,order,order,rem[i]);
    }
    crt(&bc,rem,x);   /* apply Chinese remainder thereom */
    crt_end(&bc);

/* -------------------------------------------------------------- */  




/* --------------------- Print key ---------------------------- */
    cotstr(x,keyend);
    strcat(nom, "#");	
    strcpy(cnom,nom);	
    strcat(cnom,keyend);
    while(strlen(cnom)<10)     // Add 0 
	{
	 strcat(nom, "0");
	 strcpy(cnom,nom);
	 strcat(cnom,keyend);
	}

    printf("\nKey: %s\n",cnom );
    getch();
}