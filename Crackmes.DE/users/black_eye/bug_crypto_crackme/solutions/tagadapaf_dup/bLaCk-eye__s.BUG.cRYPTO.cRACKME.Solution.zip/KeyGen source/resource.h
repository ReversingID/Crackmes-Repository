//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by rc.rc
//
#define IDB_MAIN                        103
#define IDI_ICON1                       107
#define IDD_DLG                         113
#define IDC_NAME                        1000
#define IDC_SERIAL                      1001
#define IDC_LICENSE                     1001
#define IDC_DATE                        1002
#define IDC_ACTIVATION                  1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        114
#define _APS_NEXT_COMMAND_VALUE         40002
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
