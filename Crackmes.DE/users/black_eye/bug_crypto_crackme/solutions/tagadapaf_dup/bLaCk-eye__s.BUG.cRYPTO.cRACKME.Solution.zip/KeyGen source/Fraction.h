#pragma once
#include <vector>

template< typename Integer > 
class ContinuedFraction
{
public:
	ContinuedFraction( Integer Numer, Integer Denom );
	virtual ~ContinuedFraction(void) {}

	vector< Integer > Quotient;
	vector< Integer > ConvergentNumer;
	vector< Integer > ConvergentDenom;

	int size;

private:
	Integer N, D, a, p[2], q[2];
};


template< typename Integer >
ContinuedFraction< Integer >::ContinuedFraction( Integer Numer, Integer Denom )
{
	N = Numer;
	D = Denom;
	a = N / D;

	p[1] = 1;
	p[0] = a;

	q[1] = 0;
	q[0] = 1;

	Quotient.push_back( a );
	ConvergentNumer.push_back( p[0] );
	ConvergentDenom.push_back( q[0] );

	while( true )
	{
		Integer temp;

		temp = N % D;
		N = D;
		D = temp;

		if( D == 0 )
			break;

		a = N / D;

		temp = a * p[0] + p[1];
		p[1] = p[0];
		p[0] = temp;

		temp = a * q[0] + q[1];
		q[1] = q[0];
		q[0] = temp;

		Quotient.push_back( a );
		ConvergentNumer.push_back( p[0] );
		ConvergentDenom.push_back( q[0] );
	}

	size = Quotient.size();
}