#include "rc4.h"
#include <algorithm>


RC4::RC4( char Key[], int KeyLength )
{
	context1 = context2 = 0;

	for( int i = 0; i < RC4TableLength; i++ )
		Table[ i ] = i;

	int toswap = 0;
	for( int i = 0; i < RC4TableLength; i++ )
	{
		toswap = ( Table[ i ] + Key[ i % KeyLength ] + toswap ) % RC4TableLength;
		std::swap( Table[ toswap ], Table[ i ] );
	}
}

void RC4::Process( char Data[], int DataLength )
{
	for( int i = 0; i < DataLength; i++ )
	{
		context2 += Table[ ++context1 ];
		std::swap( Table[ context1 ], Table[ context2 ] );
		Data[ i ] ^= Table[ ( Table[ context1 ] + Table[ context2 ] ) % RC4TableLength ];
	}
}