#include <windows.h>
#include <math.h>
#include <stdio.h>
#include <string>
#include "resource.h"
using namespace std;

const char Title[]="KeyGen for bLaCk-eye's BUG cRYPTO cRACKME";
const char Date[]="26/07/2005";

string name, license, activation;

/*****************************
KeyGen() algo
*****************************/
#include <vector>
#include "big.h"
#include "crt.h"
#include "md5/md5class.h"
#include "rc4.h"
#include "Fraction.h"

Miracl mip(100);

string BigToString( Big& big, int base=0 );

void Wiener_bLaCkeyeBuggedVersion( Big& n, Big& e, Big& p, Big& q )
{
	// bugged version, do not use.
	Big dBound = root( n, 4 ) / 3;
	ContinuedFraction< Big > cf( n, e );

	for( int i = 1; i < cf.size; i++ )
	{
		if( dBound < cf.ConvergentNumer[i] )
			throw exception( "(Wiener) cant find p,q" );

		Big sum = n - ( cf.ConvergentNumer[i] * e - 1 ) / cf.ConvergentDenom[i] + 1;
		
		if( sum <= 0 )
			continue;

		Big dif = 2 * sqrt( (sum/2)*(sum/2) - n );

		q = ( sum + dif ) / 2;
		p = ( sum - dif ) / 2;

		if( p*q == n )
			break;
	}
}

void Wiener( Big& n, Big& e, Big& p, Big& q )
{
	Big dBound = root( n, 4 ) / 3;
	ContinuedFraction< Big > cf( e, n );

	for( int i = 1; i < cf.size; i++ )
	{
		if( dBound < cf.ConvergentDenom[i] )
			throw exception( "(Wiener) cant find p,q" );

		Big sum = n - ( cf.ConvergentDenom[i] * e - 1 ) / cf.ConvergentNumer[i] + 1;
		
		if( sum <= 0 )
			continue;

		Big dif = 2 * sqrt( (sum/2)*(sum/2) - n );

		q = ( sum + dif ) / 2;
		p = ( sum - dif ) / 2;

		if( p*q == n )
			break;
	}
}

Big LicenseEncryption( Big L )
{
	char temp[16];
	int length = to_binary( L, 16, temp, 0 );
	RC4 cipher( "RETEAM", 6 );
	cipher.Encrypt( temp, length );
	return from_binary( length, temp );
}

void KeyGen()
{
	try
	{	
		CMD5 MD5( name.c_str() );
		int* MD5i = (int*)MD5.getMD5Digest();
		int MD0 = abs( MD5i[0] );
		int MD3 = abs( MD5i[3] );
		
		Big q = nextprime( Big(MD0) << 32 );
		Big p = nextprime( Big(MD3) << 32 );

		if( p > q  /* || q > 2*p */ )
			throw exception( "Can't make a serial for this name" );

		Big A = p*q;
		Big dBound = root( A, 4 ) / 3;

		Big L, Lencrypted, d;

		// get a suitable d
		for( d = 2; d < dBound; ++d )
		{
			if( gcd( d, (p-1)*(q-1) ) == 1 )
			{
				L = inverse( d, (p-1)*(q-1) );
				Lencrypted = LicenseEncryption( L );
				if( Lencrypted < A )
					break;

			}
		}

		// test them now, if it's not working, we could try to find some other (p,q) but i'm too lazy.
		Wiener( A, L, p, q );

		try
		{
			Wiener_bLaCkeyeBuggedVersion( A, L, p, q );
		}
		catch( exception&  )
		{
			throw exception( "Serial wont work, even if we are in the Wiener's attack assumptions." );
		}

		if( q >> 32 != MD0 || p >> 32 != MD3 )
			throw exception( "Some obscure reason" );

		license = BigToString( Lencrypted, 32 );
		activation = BigToString( A, 32 );

	}
	catch( exception& ex )
	{
		license = "An error occured";
		activation = ex.what();
	}
}

string BigToString( Big& big, int base )
{
	if( base )
	{
		int oldBase = (&mip)->IOBASE;
		(&mip)->IOBASE = base;
		(&mip)->IOBUFF << big;
		(&mip)->IOBASE = oldBase;
	}
	else
		(&mip)->IOBUFF << big;
	return (&mip)->IOBUFF;
}

/*****************************
DLG stuff..
*****************************/

// bitmap
HBITMAP hBitmap;
HBRUSH hBrush;

BOOL CALLBACK DialogProc( HWND hwndDlg, UINT uMsg ,WPARAM wParam, LPARAM lParam )
{
	switch( uMsg )
	{
	case WM_CLOSE:
		EndDialog( hwndDlg, 0 );
		break;

	case WM_INITDIALOG:
		srand( GetTickCount() );
		SetWindowText( hwndDlg, Title );
		SetDlgItemText( hwndDlg, IDC_DATE, Date );
		SetDlgItemText( hwndDlg, IDC_SERIAL, "Enter your name..." );
		break;

	case WM_COMMAND:
		if( LOWORD(wParam) == IDC_NAME )
		{
			char buffer[ 512 ];

			if( !GetDlgItemText( hwndDlg, IDC_NAME, buffer, 511 ) )
			{
				SetDlgItemText( hwndDlg, IDC_LICENSE, "" );
				SetDlgItemText( hwndDlg, IDC_ACTIVATION, "Enter your name..." );
				name = "";
				break;
			}

			string newName = buffer;
			if( newName != name )
			{
				name = newName;
				KeyGen();
				SetDlgItemText( hwndDlg, IDC_LICENSE, license.c_str() );
				SetDlgItemText( hwndDlg, IDC_ACTIVATION, activation.c_str() );
			}

			InvalidateRect( GetDlgItem(hwndDlg, IDC_NAME), NULL, true );
			InvalidateRect( GetDlgItem(hwndDlg, IDC_LICENSE), NULL, true );
			InvalidateRect( GetDlgItem(hwndDlg, IDC_ACTIVATION), NULL, true );
		}

		break;


	case WM_CTLCOLORDLG:
	case WM_CTLCOLORLISTBOX:
	case WM_CTLCOLOREDIT:
	case WM_CTLCOLORSTATIC:
		HDC hdc;
		hdc = ( HDC )wParam;
		SetTextColor( hdc, RGB( 255, 255, 255 ));
		SetBkMode( hdc, TRANSPARENT	);
		return ( BOOL )hBrush;
	}
	return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	hBitmap = LoadBitmap( hInstance, MAKEINTRESOURCE( IDB_MAIN ));
	hBrush = CreatePatternBrush( hBitmap );

	DialogBox( hInstance, MAKEINTRESOURCE( IDD_DLG ), 0, DialogProc );

	DeleteObject( hBitmap );
	DeleteObject( hBrush );

	return 0;
}