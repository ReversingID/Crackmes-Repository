#pragma once

#define RC4TableLength 0x100

class RC4
{
public:
	RC4( char Key[], int KeyLength );
	~RC4() {}

	void Encrypt( char Data[], int DataLength ) { Process( Data, DataLength ); }
	void Decrypt( char Data[], int DataLength ) { Process( Data, DataLength ); }

private:
	void Process( char Data[], int DataLength );
	unsigned char Table[ RC4TableLength ];
	unsigned char context1, context2;
	
};
