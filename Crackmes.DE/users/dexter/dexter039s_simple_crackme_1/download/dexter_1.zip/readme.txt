This is simple enough. Written in Borland C++BuilderX (bloaty)

-Dexter

Email me your solution if you're terribly bored (hexboy24@programmer.net)

shouts to #bgrc, #cracking4newbies