// Keygen for Hellfish Braincrack crackme by TSCube 18/06/2001

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/* ------------------- globals --------------------- */
char digits[5][255][2]; // stay with me ;-)
int index[5] = {0,0,0,0,0};



/************************************************************
* ror_byte
*
* DESCRIPTION :
*
*  Rotates a byte 'n' times towards right
*
*
* RETURNS
* rotated byte
*************************************************************/
unsigned char ror_byte(unsigned char byte, // byte to rotate
                       unsigned int n)     // number of bits to rotate
{
	unsigned char rolled = byte;
	while (n--)
	{
		if (rolled & 1) rolled = ((rolled>>1) | 128);
		else rolled = (rolled >> 1);
	}
	
	return rolled;
}



/************************************************************
* ror_byte
*
* DESCRIPTION :
*
* Rotates a byte 'n' times towards left
*
*
* RETURNS
* rotated byte
*************************************************************/
unsigned char rol_byte(unsigned char byte, // byte to rotate
                       unsigned int n)     // number of bits to rotate
{
	unsigned char rolled = byte;
	while (n--)
	{
		if (rolled & 128) rolled = ((rolled<<1) | 1);
		else rolled = (rolled << 1);
	}
	
	return rolled;
}



/************************************************************
* check_serial
*
* DESCRIPTION :
*
* Checks if serial is correct
* This is only a 'C++' translation of the crackme check function
*
*
* RETURNS
* 0 if serial is correct
* 1 if serial is not correct
*************************************************************/
int check_serial(char* serial) // serial to check
{
	unsigned char var1,var2,var3;
	unsigned char hexSerial[23];
	
	if (strlen(serial)!=11) return 1;
	
	// 31 32 33 34 35 | 36 37 38 39 30 31 -> 31 32 33 34 35 | 36 37 38 39 30 29
	serial[10] = serial[10] ^ 0x18;
	
	// 31 32 33 34 35 | 36 37 38 39 30 29 -> 73 B3 F3 33 73 | B3 F3 33 73 33 29
	for (int i=0;i<10;i++)
	{
		var1 = serial[i];
		var1 = rol_byte(var1,2);
		var1 = var1 ^ 0xFF;
		var1 = var1 + 8;
		var1 = var1 ^ 0x22;
		var1 = var1 << 4;
		var1 = var1 ^ 0x63;
		serial[i] = var1;
	}
	
	// 73 B3 F3 33 73 | B3 F3 33 73 33 29 -> 34 33 2E 3D 30 | B3 F3 33 73 33 29
	for (int i=0;i<5;i++)
	{
		var1 = serial[i];
		var2 = serial[i+5];
		
		var1 = var1 >> 2;
		var2 = var2 ^ 0xFF;
		var2 = var2 << 2;
		var1 = var1 ^ var2;
		var1 = ror_byte(var1,2);
		var1 = var1 + 0x0A;
		var2 = var2 >> 2;
		var2 = var2 + 0x14;
		var1 = var1 ^ var2 ^ (i+1);
		
		serial[i] = var1;
	}
	
	// 34 33 2E 3D 30 | B3 F3 33 73 33 29 -> 34 33 2E 3D 30 | 70 30 FF F0 30 29
	for (int i=0;i<5;i++)
	{	
		var1 = serial[i];
		var2 = serial[i+5];
		
		var1 = var1 >> 2;
		var2 = var2 ^ 0x7E;
		var2 = var2 << 2;
		var1 = var1 ^ var2;
		var1 = ror_byte(var1,2);
		var1 = var1 + 0x19;
		var2 = var2 >> 2;
		var2 = var2 + 0x0A;
		var1 = var1 ^ var2;
		
		serial[i+5] = var1;
	}
	
	
	hexSerial[0] = 0x00; // for strcat()
	
	for (int i=0;i<11;i++)
	{
		char buffer[3];
		sprintf(buffer,"%02X",(unsigned char)serial[i]);
		printf("buffer = %s\n",buffer);
		strcat(hexSerial,buffer);
	}
	
	printf("%s\n",hexSerial);
	if (strcmp(hexSerial,"312E363D3430DF70F0705F")!=0) return 1; // incorrect serial
	return 0; // serial OK
}




/************************************************************
* bruteforce
*
* DESCRIPTION :
*
* Bruteforces all possible serials
* (uses globals 'digits' and 'index')
*
* RETURNS
* 0
*************************************************************/
int bruteforce(void)
{
	unsigned char magic[11] = { 0x31, 0x2E, 0x36, 0x3D, 0x34, 0x30, 
	                            0xDF, 0x70, 0xF0, 0x70, 0x5F}; // magic buffer for serial to find
	                            
	/*unsigned char magic[12] = { 0x34, 0x33, 0x2E, 0x3D, 0x30, 0x70, 
	                            0x30, 0xFF, 0xF0, 0x30, 0x29, 0x00 };*/ // magic buffer for serial "12345678901"
	                           	 	                            
	
	
	for (int i=0;i<5;i++)
	{
		for (unsigned char brute1=0x30;brute1<0x7a;brute1++) // we only bruteforce chars from '0' to 'z'
		{
			for (unsigned char brute2=0x30;brute2<0x7a;brute2++)
			{
				unsigned char var1,var2,tmp1,tmp2;
				
				// loop 1 STEP 1
				var1 = brute1;//var1 = serial[i];
				var1 = rol_byte(var1,2);
				var1 = var1 ^ 0xFF;
				var1 = var1 + 8;
				var1 = var1 ^ 0x22;
				var1 = var1 << 4;
				var1 = var1 ^ 0x63;
				tmp1 = var1; //serial[i] = var1;
				
				// loop 1 STEP 2
				var1 = brute2;//var1 = serial[i];
				var1 = rol_byte(var1,2);
				var1 = var1 ^ 0xFF;
				var1 = var1 + 8;
				var1 = var1 ^ 0x22;
				var1 = var1 << 4;
				var1 = var1 ^ 0x63;
				tmp2 = var1; //serial[i] = var1;
				
				
				// loop 2
				var1 = tmp1; //var1 = serial[i];
				var2 = tmp2; //var2 = serial[i+5];
				var1 = var1 >> 2;
				var2 = var2 ^ 0xFF;
				var2 = var2 << 2;
				var1 = var1 ^ var2;
				var1 = ror_byte(var1,2);
				var1 = var1 + 0x0A;
	 			var2 = var2 >> 2;
				var2 = var2 + 0x14;
				var1 = var1 ^ var2 ^ (i+1);
				tmp1 = var1; //serial[i] = var1;
				
				// loop 3
				var1 = tmp1; //var1 = serial[i];
				var2 = tmp2; //var2 = serial[i+5];
				var1 = var1 >> 2;
				var2 = var2 ^ 0x7E;
				var2 = var2 << 2;
				var1 = var1 ^ var2;
				var1 = ror_byte(var1,2);
				var1 = var1 + 0x19;
				var2 = var2 >> 2;
				var2 = var2 + 0x0A;
				var1 = var1 ^ var2;
				tmp2 = var1; //serial[i+5] = var1;
				
				if ( (tmp1==magic[i]) && (tmp2==magic[i+5]) )
				{
					digits[i][index[i]][0] = brute1;
					digits[i][index[i]][1] = brute2;
					index[i]++;
					//printf("Possible values -> serial[%d]=%c serial[%d]=%c\n",i,brute1,i+5,brute2);
				}
			}
			
		}
		
	}
	
	
	return 0;
	
}





int main(void)
{	
	int rnd1,rnd2,rnd3,rnd4,rnd5;
	
	printf("Keygen for Hellfish Braincrack crackme by TSCube 18/06/2001\n\n");
	
	bruteforce(); // fills 'digits' array
	
	while(1) // endless loop -> CTRL-C to exit
	{
		srand( (unsigned)time( NULL ) );
		rnd1 = rand() %index[0];
		rnd2 = rand() %index[1];
		rnd3 = rand() %index[2];
		rnd4 = rand() %index[3];
		rnd5 = rand() %index[4];
	
		printf("Possible serial = %c%c%c%c%c%c%c%c%c%cG (<enter> to continue or CTRL-C to stop)",digits[0][rnd1][0],digits[1][rnd2][0],digits[2][rnd3][0],digits[3][rnd4][0],digits[4][rnd5][0],digits[0][rnd1][1],digits[1][rnd2][1],digits[2][rnd3][1],digits[3][rnd4][1],digits[4][rnd5][1]);
		getchar();
	}
	return 0;
}