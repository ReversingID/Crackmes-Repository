One or two keys may mutate when entered, The cause being the textbox is not optimised
for taking such keys.
for eg.

Name: PlzKeyGenME
Key: xxXX=XXxx%

the key when entered into the text box becomes

xxXX=XX

which is invalid. dont ask me to explain that!!!!!!!!!!!!!!!

and ofcourse donot try to find a key for any of the key's generated :) in that case Some of the keys generated would be void :(