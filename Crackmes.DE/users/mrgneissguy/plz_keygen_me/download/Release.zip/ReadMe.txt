The usual...

No Patching.
No Brute Forcing.

Write a keygen and a tut.



This Keygenme's code is short, but it's very difficult to solve.

It starts by creating a byte array from the ascii serial and an empty result array of the same length.

It then loops through the array incrementing the index on each loop.  On each loop, it performs an L-shift on byte_0 2 bits and an R-shift on byte_1 2 bits.  It then performs a bitwise xor on the shifted bytes, storing the result in the result array.

Finally, it compares bytes in the result array at indexes 1/3 array length, 2/3 array length and 3/3 array length to the bytes of the name at indexes 1/3 name length, 2/3 name length and 3/3 name length.  If the bytes are equal, the keygenme is unlocked!.

Sample serial:

Name:  xRAX
Serial:  aGFcowSy7J8yVgP12dV