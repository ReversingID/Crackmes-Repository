#include "time.h"
#include "stdlib.h"
#include "stdio.h"

static char str1[31];

int main()
{
	srand((unsigned)time( NULL ));
	int a=0;
	while (a<=0x1D)
	{
		rand();
		__asm
		{
			lea ebx,[str1]
			add ebx,a
			mov ecx,eax
			mov eax,0x66666667
			imul ecx
			sar edx,2
			mov eax,ecx
			sar eax,0x1f
			sub edx,eax
			mov eax,edx
			shl eax,2
			add eax,edx
			add eax,eax
			sub ecx,eax
			mov eax,ecx
			add al,0x30
			mov byte ptr[ebx],al
		}
		a++;
	}
	str1[a]=0;
	printf("Serial: %s\n",str1);
}
