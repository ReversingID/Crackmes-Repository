
//==========================================================================
//        Dionosis solution-2 for LeeviON's first crackme with Assemby
//                           Dionosis.RE@gmail.com
//                                2010/01/09
//==========================================================================


#include <windows.h>


int GetError( int errorId)
{
   switch( errorId)
   {
       case 1:
          MessageBoxA( 0, "Unable to retrieve the target's path !", "Error", MB_ICONERROR); break;
       case 2:
          MessageBoxA( 0, "Unable to create the target's process !\r\n\r\nBe sure this loader is in the same directory than the target.", "Error", MB_ICONERROR); break;
       case 3:
          MessageBoxA( 0, "Unable to patch the target !", "Error", MB_ICONERROR); break;
       case 4:
          MessageBoxA( 0, "Unable to resume the patched target !", "Error", MB_ICONERROR); break;
       default:
          MessageBoxA( 0, "Unknown error", "Error", MB_ICONERROR); break;
   }

   return errorId;
}

int main( int ac, char **av)
{
    int i=0,j=0;
    int ret, nb;

    char targetShortName[]= "crackme1.exe\0";
    char targetFullName[261];

    DWORD patch = 0x000083E8;   // jmp 00401088

    PROCESS_INFORMATION Process = {0};
	STARTUPINFO Start = {0};


	// Setting start struct
	Start.cb = sizeof(STARTUPINFO);
	Start.lpReserved = NULL;
	Start.lpReserved2 = NULL;
	Start.cbReserved2 = 0;
	Start.lpDesktop = NULL;
	Start.dwFlags = 0;

    // Retrieve target path (without overflow verification)
    ret= GetModuleFileNameA( 0, targetFullName, 261);
    if( ret==261)   return GetError( 1);

    for( ; targetFullName[i]!=0; i++);
    for( ; targetFullName[i-1]!=0x5C; i--);
    for( ; targetShortName[j]!=0; j++, i++)  { targetFullName[i]=targetShortName[j]; }
    targetFullName[i]=0;

    // Launch the target in suspended mode
    ret = CreateProcess(NULL, targetFullName, NULL, NULL, FALSE, CREATE_SUSPENDED, NULL, NULL, &Start, &Process);
    if( !ret)   return GetError( 2);

    // Patch the target
    ret= WriteProcessMemory( Process.hProcess, (LPVOID)0x401000, (LPCVOID)&patch, (SIZE_T)4, (SIZE_T*)&nb);
    if( !ret || nb!=4)   return GetError( 3);

    // Resume the target
    ret= ResumeThread( Process.hThread);
    if( ret==-1)   return GetError( 4);


    return 0;
}
