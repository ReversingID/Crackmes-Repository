This CrackMe "simulates" when some programs trial time ends.

Tasks:
1. Kill the message
2. Get the name
3. Get the serial
4. Write a solution

The activate button will enable when you have writed the right name and serial.
PS. either if you enable the Activate-button, you must have right
serial code and name. =) Happy cracking!