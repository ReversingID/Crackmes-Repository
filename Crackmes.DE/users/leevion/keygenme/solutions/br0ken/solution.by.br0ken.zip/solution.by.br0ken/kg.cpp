#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<conio.h>
int Random(int,int);
void main()
 {
	char str1[] = "BCDFGHJKLMNPQRSTVWXZ";
	char str2[] = "AEIOUY";
	int i;
	char ch;
	printf("************************************************\n");
	printf("************** Keygen by br0ken ****************\n");
	printf("************************************************\n");
	printf("\n\nPress any key to start generating valid keys...\n\n");
	getch();
	start:
	for(int j =0;j<50;j++)
	{
	for(i=1;i<=31;i++) 
	{
	
		if((i%2)==1)
		printf("%c",str1[Random(19,0)]);
		else
		printf("%c",str2[Random(5,0)]);
	
	}
	printf("\n");
	}
  	printf("\n\nDo you want more? (y/n)  : ");
  	ch=getch();
  	if(ch == 'y' || ch == 'Y')
	goto start;
}

int Random(int higher,int lower)
{
	return ((rand() % higher - lower) + lower + 1);
}