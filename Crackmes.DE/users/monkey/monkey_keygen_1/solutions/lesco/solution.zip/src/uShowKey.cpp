//---------------------------------------------------------------------------

#include <windows.h>
//---------------------------------------------------------------------------
//   Wichtiger Hinweis zur DLL-Speicherverwaltung, falls die DLL die statische
//   Version der Laufzeitbibliothek (RTL) verwendet:
//
//   Wenn die DLL Funktionen exportiert, die String-Objekte (oder Strukturen/
//   Klassen, die verschachtelte Strings enthalten) als Parameter oder Funktionsergebnisse �bergibt,
//   mu� die Bibliothek MEMMGR.LIB im DLL-Projekt und anderen Projekten,
//   die die DLL verwenden, vorhanden sein. Sie ben�tigen MEMMGR.LIB auch dann,
//   wenn andere Projekte, die die DLL verwenden, new- oder delete-Operationen
//   auf Klassen anwenden, die nicht von TObject abgeleitet sind und die aus der DLL exportiert
//   werden. Durch das Hinzuf�gen von MEMMGR.LIB wird die DLL und deren aufrufende EXEs
//   angewiesen, BORLNDMM.DLL als Speicherverwaltung zu benutzen. In diesem Fall
//   sollte die Datei BORLNDMM.DLL zusammen mit der DLL weitergegeben werden.
//
//   Um die Verwendung von BORLNDMM.DLL, zu vermeiden, sollten String-Informationen als "char *" oder
//   ShortString-Parameter weitergegeben werden.
//
//   Falls die DLL die dynamische Version der RTL verwendet, m�ssen Sie
//   MEMMGR.LIB nicht explizit angeben.
//---------------------------------------------------------------------------

#pragma argsused
#include <SysUtils.hpp>
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void* lpReserved)
{
        return 1;
}
void __stdcall __declspec(dllexport) DisplayKey(LPCTSTR key)
{
        
        HWND wnd;
        wnd = FindWindow("TForm1","monkey keygen #1");
        wnd = FindWindowEx(wnd, 0, "TEdit", 0);
        if(wnd != 0)
        {
                SendMessage(wnd,WM_SETTEXT,0,(long)key);
        }
        return;
}
//---------------------------------------------------------------------------
