// sha1.cpp and sha1.h by Dr Brian Gladman <brg@gladman.me.uk>
// modified by asik

#include <iostream>
#include <string.h>
#include <stdio.h>

#include "sha1.h"

using namespace std;

char UserName[32];
unsigned char hash[40];
int i = 0;

int main()
{
	printf(" keygen for 'monkey keygen 4.4' by asik\n max name length: 31\n");
	printf(" name: ");
	cin.getline (UserName, 32);
	sha1(hash, UserName, (int)strlen(UserName));
	printf(" serial: ");
	for(i = 0; i < 20; i++)
	{
		printf("%02x", hash[i]);
	}
	return 0;
}