---[ Crackme OS: Written by monkey of the MBE Crew ]---
---[ OS Version: 1.2b Build 6                      ]---
---[   Released: 20050806                          ]---
---[                                               ]---
---[ I consider this cracked if you change any of  ]---
---[ the header. Save the modified image and post  ]---
---[ on the forums. Good luck. This is the hardest ]---
---[ crackme I have ever maded, so I hope you know ]---
---[ what you are doing. :)                        ]---

1. Use the rawwrite program to copy floppy.img to a floppy drive.
2. Reboot with the floppy disk in your PC.
3. Once it boots, you will be prompted to select either CrackmeOS
  or to boot from your C:\ drive. Select CrackmeOS and hit <ENTER>
4. Let CrackmeOS boot
5. Be amazed that it does nothing except let you use your keyboard.
6. Once your done playing around, eject your floppy and reboot your PC.