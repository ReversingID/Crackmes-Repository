 ------------------------------------------------------------
| monkey keygen #2
|
| diff: 3.5/10 (Experience is required. Brain is optional)
 ------------------------------------------------------------

This should be pretty easy if you have had some experience, I
was thinking about packing it with tELock, but I haven't found
anything that can unpack it, so i didn't want it to be impossible
to crack.

As always, email the solution with the source code and I will
send you the project with full source.

Email: neobob@gamebox.net

Have fun. :)