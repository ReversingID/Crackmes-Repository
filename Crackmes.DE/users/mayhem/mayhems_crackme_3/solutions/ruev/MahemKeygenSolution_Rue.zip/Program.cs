﻿using System;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace MahemKeygen
{
    internal class Program
    {
        [STAThread]
        private static void Main(string[] args)
        {
            bool retry = true;
            while (retry)
            {
                retry = false;
                Console.WriteLine("Enter your name:");
                string name = string.Empty;

                //Make sure the length of the name is greater than 2
                if ((name = Console.ReadLine()).Length < 2)
                {
                    //If not, retry
                    retry = true;
                    continue;
                }

                //Serial Generation function
                string str2 = getHash(name);
                int num = 0;
                int length = name.Length;
                int num3 = ((length*8) + length) + 63;
                for (int i = 0; i < str2.Length; i++)
                {
                    num += str2[i];
                }
                string serial = string.Concat(new object[] {(int) name[length - 1], num3, 63, num});
                //

                Clipboard.SetText(serial);
                Console.WriteLine("Serial '{0}' copied to clipboard", serial);
                Console.WriteLine("Again? [y/n]");
                if (Console.ReadLine().ToLower() == "y")
                    retry = true;
            }
        }

        public static string getHash(string value)
        {
            byte[] bytes = Encoding.ASCII.GetBytes(value);
            byte[] buffer2 = new SHA512Managed().ComputeHash(bytes);
            string str = string.Empty;
            foreach (byte num in buffer2)
            {
                str = str + num.ToString("X2");
            }
            return str;
        }
    }
}