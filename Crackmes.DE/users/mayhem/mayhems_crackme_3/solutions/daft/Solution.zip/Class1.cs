
using System;
using System.Security.Cryptography;
using System.Text;
using System.Diagnostics;

namespace KeygenCSharp
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			Console.WriteLine ("");
			Console.WriteLine ("Mayhem's CrackMe #3 - Keygen");
			Console.WriteLine ("(c)Piet Carpentier - HFC - 2010");
			Console.WriteLine ("");
			Console.Write ("Enter Your Name : ");

			string text = Console.ReadLine();
			string str2 = getHash(text);
			int num = 0;
			int length = text.Length;
			
			// Validate if the name is longer then 2 chars.
			if (length < 2)
			{
                Console.WriteLine ("Sorry your name must at least be 2 charters...");
			}
			else 
			{
				int num3 = ((length * 8) + length) + 0x3f;
				for (int i = 0; i < str2.Length; i++)
				{
					num += str2[i];
				}
				string str3 = string.Concat(new object[] { (int) text[length - 1], num3, 0x3f, num });
				
				Console.Write ("This is your key: ");			
				Console.Write (str3);

			}
			
			Console.WriteLine ("");
	
		}

		public static string getHash(string value)
		{
			byte[] bytes = Encoding.ASCII.GetBytes(value);
			byte[] buffer2 = new SHA512Managed().ComputeHash(bytes);
			string str = string.Empty;
			foreach (byte num in buffer2)
			{
				str = str + num.ToString("X2");
			}
			return str;
		}
 	}
}
