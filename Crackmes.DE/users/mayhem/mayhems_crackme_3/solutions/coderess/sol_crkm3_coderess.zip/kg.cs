using System;
using System.Security.Cryptography;	// SHA512
using System.Text;
using System.Data;
using System.Windows.Forms;


namespace kg
{
	class Class
	{
		[STAThread]
		static void Main(string[] args)
		{
				Console.WriteLine("Enter your name: ");
				string szName = Console.ReadLine();
				string hash   = Hash( szName );
				int    len    = szName.Length;
				int    sum2   = ( ( len * 8) + len ) + 63;
				int    sum    = 0;

				for (int i = 0; i < hash.Length; i++) {
					sum += hash[i];
				}

				string str3 = string.Concat(new object[] { (int) szName[len - 1], sum2, 63, sum });
				Console.WriteLine(str3);
				Console.ReadLine();
		
		}
		//
		// Calculate SHA512 hash
		//
		public static string Hash(string pszStr)
		{
				byte[] HexBytes   = Encoding.ASCII.GetBytes(pszStr);
				byte[] SHA512Hash = new SHA512Managed().ComputeHash(HexBytes);
				string Text       = string.Empty;

				foreach (byte sum in SHA512Hash){
					Text = Text + sum.ToString("X2");
				}
				return Text;
		}
	}
}


