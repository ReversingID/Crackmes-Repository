A slightly different approach I decided to try for a crackme idea, I know its not a viable solution in a real environment however I thought it might be fun to solve.

Rules:
1. There are no rules, just get a goodboy, any way is acceptable.

Have fun!