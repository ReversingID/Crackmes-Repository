﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Keygen
{
    public partial class KeygenForm : Form
    {
        int[] Name_FixedKey = new int[40]
        {0xD3,  0x13C, 0x11A,  0xBD,   0x9C,   0xC3,   0x7A,   0x171,
         0x144, 0x14F, 0xEF,   0xAD,   0x13A,  0x164,  0xB3,   0xA2,
         0x118, 0xA4,  0x161,  0xC0,   0x14C,  0x188,  0xDF,   0xF5,
         0x11C, 0xD4,  0x92,   0xA7,   0xF4,   0x137,  0x162,  0x134,
         0x8D,  0x156, 0x122,  0x133,  0xB7,   0x18E,  0x8B,   0x124};

        string Serial_FixedKey = 
            "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

        public KeygenForm()
        {
            InitializeComponent();
        }

        private int ComputeNameValue(string Name)
        {
            int CalculatedValue = 0;
            for (int i = 0; i < Name.Length; i++)
            {
                CalculatedValue += ((((Name[i]*Name_FixedKey[i])*15)*4)+0x699);
            }
            return CalculatedValue;
        }

        private string ComputeSerial(int NameValue)
        {
            int KeyLenght = 0;

            while (NameValue > Math.Pow(62, KeyLenght))
            {
                KeyLenght++; 
            }
            KeyLenght--;

            char[] Serial = new char[KeyLenght+1];

            for (int i = KeyLenght; i > 0; i--)
            {
                int KeyCharValue = 0;
                while ((Math.Pow(62, i) * KeyCharValue) < NameValue)
                {
                    KeyCharValue++;
                }
                if (KeyCharValue > 0) KeyCharValue--;
                NameValue -= (int)(Math.Pow(62, i) * KeyCharValue);
                Serial[i] = Serial_FixedKey[KeyCharValue];
            }
            Serial[0] = Serial_FixedKey[NameValue];
            return new string(Serial);
        }

        private void GenerateButton_Click(object sender, EventArgs e)
        {
            if (InputField.Text != "")
            {
                if (InputField.Text.Length > 40)
                {
                    MessageBox.Show("Name must be shorter than 40 characters!");
                }
                else
                {
                    int NameValue = ComputeNameValue(InputField.Text);
                    SerialBox.Text = ComputeSerial(NameValue);
                }
            }
            else MessageBox.Show("Please enter your name!");
        }
    }
}
