﻿namespace Keygen
{
    partial class KeygenForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.InputField = new System.Windows.Forms.TextBox();
            this.NameLabel = new System.Windows.Forms.Label();
            this.GenerateButton = new System.Windows.Forms.Button();
            this.SerialBox = new System.Windows.Forms.TextBox();
            this.SerialLabel = new System.Windows.Forms.Label();
            this.CreditsLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // InputField
            // 
            this.InputField.Location = new System.Drawing.Point(56, 6);
            this.InputField.Name = "InputField";
            this.InputField.Size = new System.Drawing.Size(179, 20);
            this.InputField.TabIndex = 0;
            this.InputField.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Location = new System.Drawing.Point(12, 9);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(38, 13);
            this.NameLabel.TabIndex = 1;
            this.NameLabel.Text = "Name:";
            // 
            // GenerateButton
            // 
            this.GenerateButton.Location = new System.Drawing.Point(125, 62);
            this.GenerateButton.Name = "GenerateButton";
            this.GenerateButton.Size = new System.Drawing.Size(110, 23);
            this.GenerateButton.TabIndex = 2;
            this.GenerateButton.Text = "Generate";
            this.GenerateButton.UseVisualStyleBackColor = true;
            this.GenerateButton.Click += new System.EventHandler(this.GenerateButton_Click);
            // 
            // SerialBox
            // 
            this.SerialBox.BackColor = System.Drawing.Color.White;
            this.SerialBox.Location = new System.Drawing.Point(56, 35);
            this.SerialBox.Name = "SerialBox";
            this.SerialBox.ReadOnly = true;
            this.SerialBox.Size = new System.Drawing.Size(179, 20);
            this.SerialBox.TabIndex = 3;
            this.SerialBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // SerialLabel
            // 
            this.SerialLabel.AutoSize = true;
            this.SerialLabel.Location = new System.Drawing.Point(14, 38);
            this.SerialLabel.Name = "SerialLabel";
            this.SerialLabel.Size = new System.Drawing.Size(36, 13);
            this.SerialLabel.TabIndex = 4;
            this.SerialLabel.Text = "Serial:";
            // 
            // CreditsLabel
            // 
            this.CreditsLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.CreditsLabel.AutoSize = true;
            this.CreditsLabel.Enabled = false;
            this.CreditsLabel.Location = new System.Drawing.Point(2, 73);
            this.CreditsLabel.Name = "CreditsLabel";
            this.CreditsLabel.Size = new System.Drawing.Size(66, 13);
            this.CreditsLabel.TabIndex = 5;
            this.CreditsLabel.Text = "2012 Caelint";
            // 
            // KeygenForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(243, 90);
            this.Controls.Add(this.CreditsLabel);
            this.Controls.Add(this.SerialLabel);
            this.Controls.Add(this.SerialBox);
            this.Controls.Add(this.GenerateButton);
            this.Controls.Add(this.NameLabel);
            this.Controls.Add(this.InputField);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "KeygenForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Mayhem\'s C++ Crackme #2 Keygen";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox InputField;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Button GenerateButton;
        private System.Windows.Forms.TextBox SerialBox;
        private System.Windows.Forms.Label SerialLabel;
        private System.Windows.Forms.Label CreditsLabel;
    }
}

