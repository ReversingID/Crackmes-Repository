﻿namespace WindowsApplication2
{
    partial class keygen
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.bComenzar = new System.Windows.Forms.Button();
            this.bSalir = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cNombre = new System.Windows.Forms.TextBox();
            this.cSerial = new System.Windows.Forms.TextBox();
            this.barra = new System.Windows.Forms.ProgressBar();
            this.bAbortar = new System.Windows.Forms.Button();
            this.cLog = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // bComenzar
            // 
            this.bComenzar.Location = new System.Drawing.Point(223, 172);
            this.bComenzar.Name = "bComenzar";
            this.bComenzar.Size = new System.Drawing.Size(75, 23);
            this.bComenzar.TabIndex = 0;
            this.bComenzar.Text = "Comenzar";
            this.bComenzar.UseVisualStyleBackColor = true;
            this.bComenzar.Click += new System.EventHandler(this.bComenzar_Click);
            // 
            // bSalir
            // 
            this.bSalir.Location = new System.Drawing.Point(394, 172);
            this.bSalir.Name = "bSalir";
            this.bSalir.Size = new System.Drawing.Size(75, 23);
            this.bSalir.TabIndex = 1;
            this.bSalir.Text = "Salir";
            this.bSalir.UseVisualStyleBackColor = true;
            this.bSalir.Click += new System.EventHandler(this.bSalir_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(220, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Nombre:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(220, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Serial:";
            // 
            // cNombre
            // 
            this.cNombre.Location = new System.Drawing.Point(269, 78);
            this.cNombre.Name = "cNombre";
            this.cNombre.ReadOnly = true;
            this.cNombre.Size = new System.Drawing.Size(200, 20);
            this.cNombre.TabIndex = 4;
            // 
            // cSerial
            // 
            this.cSerial.Location = new System.Drawing.Point(269, 108);
            this.cSerial.Name = "cSerial";
            this.cSerial.ReadOnly = true;
            this.cSerial.Size = new System.Drawing.Size(200, 20);
            this.cSerial.TabIndex = 5;
            // 
            // barra
            // 
            this.barra.Location = new System.Drawing.Point(223, 134);
            this.barra.Name = "barra";
            this.barra.Size = new System.Drawing.Size(246, 23);
            this.barra.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            this.barra.TabIndex = 6;
            this.barra.Visible = false;
            // 
            // bAbortar
            // 
            this.bAbortar.Location = new System.Drawing.Point(304, 172);
            this.bAbortar.Name = "bAbortar";
            this.bAbortar.Size = new System.Drawing.Size(75, 23);
            this.bAbortar.TabIndex = 7;
            this.bAbortar.Text = "Abortar";
            this.bAbortar.UseVisualStyleBackColor = true;
            this.bAbortar.Click += new System.EventHandler(this.bAbortar_Click);
            // 
            // cLog
            // 
            this.cLog.Location = new System.Drawing.Point(12, 41);
            this.cLog.Multiline = true;
            this.cLog.Name = "cLog";
            this.cLog.ReadOnly = true;
            this.cLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.cLog.Size = new System.Drawing.Size(202, 239);
            this.cLog.TabIndex = 33;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(266, 267);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(145, 13);
            this.label3.TabIndex = 34;
            this.label3.Text = "Verificando datos capturados";
            this.label3.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(453, 16);
            this.label4.TabIndex = 35;
            this.label4.Text = "Generador de claves para \'braynfack\' por Pepelux (http://www.pepelux.org)";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(495, 292);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cLog);
            this.Controls.Add(this.bAbortar);
            this.Controls.Add(this.barra);
            this.Controls.Add(this.cSerial);
            this.Controls.Add(this.cNombre);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bSalir);
            this.Controls.Add(this.bComenzar);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "KeyGen";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bComenzar;
        private System.Windows.Forms.Button bSalir;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox cNombre;
        private System.Windows.Forms.TextBox cSerial;
        private System.Windows.Forms.ProgressBar barra;
        private System.Windows.Forms.Button bAbortar;
        private System.Windows.Forms.TextBox cLog;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}

