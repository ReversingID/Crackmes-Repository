using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace WindowsApplication2
{
    public partial class keygen : Form
    {
        public keygen()
        {
            InitializeComponent();
        }

        int WORD_LENGTH = 32;
        Thread tareaNombres;
        Thread tareaSeriales;
        Thread tareaBusqueda;
        List<string> listaNombres;
        List<string> listaNombresCod;
        List<string> listaSeriales;
        List<string> listaSerialesCod;
        String alfabeto = " abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        String numeros = " 0123456789";
        private delegate void updateUI(String value1, String value2);
        private delegate void updateUIL(String value, int x);
        private delegate void updateUIF();

        private void fin()
        {
            if (this.InvokeRequired == false)
            {
                bAbortar.Enabled = false;
                bComenzar.Enabled = true;
                barra.Visible = false;
                timer1.Enabled = false;

                MessageBox.Show("El programa para de analizar en cuanto encuentra los primeros seriales" + Environment.NewLine
                    + "De las combinaciones encontradas se pueden generar muchas m�s, simplemente cambiando las posiciones pares del nombre y/o serial");

                try { tareaBusqueda.Abort(); }
                catch { }
            }
            else
            {
                updateUIF updateMethod = new updateUIF(this.fin);
                this.Invoke(updateMethod, new object[] { });
            }
        }

        private void actualizaLog(String value1, String value2)
        {
            if (this.InvokeRequired == false)
            {
                cLog.Text += value1 + " - " + value2 + Environment.NewLine;
            }
            else
            {
                updateUI updateMethod = new updateUI(this.actualizaLog);
                this.Invoke(updateMethod, new object[] { value1, value2 });
            }
        }

        private void actualizaLabel(String value, int x)
        {
            if (this.InvokeRequired == false)
            {
                if (x == 1)
                    label3.Visible = false;

                if (x == 2)
                    cNombre.Text = value;

                if (x == 3)
                    cSerial.Text = value;
            }
            else
            {
                updateUIL updateMethod = new updateUIL(this.actualizaLabel);
                this.Invoke(updateMethod, new object[] { value, x });
            }
        }

        private void bSalir_Click(object sender, EventArgs e)
        {
            try { tareaNombres.Abort(); }
            catch { }
            try { tareaSeriales.Abort(); }
            catch { }
            try { tareaBusqueda.Abort(); }
            catch { }

            Close();
        }

        private void bComenzar_Click(object sender, EventArgs e)
        {
            bComenzar.Enabled = false;
            bAbortar.Enabled = true;
            listaNombres = new List<string>();
            listaNombresCod = new List<string>();
            listaSeriales = new List<string>();
            listaSerialesCod = new List<string>();

            tareaNombres = new Thread(GeneraNombres);
            tareaNombres.Start();
            tareaSeriales = new Thread(GeneraSeriales);
            tareaSeriales.Start();

            barra.Visible = true;
            timer1.Interval = 10000; // 10 segundos
            timer1.Enabled = true;
        }

        private void GeneraNombres()
        {
            String test;

            for (int i1 = 0; i1 < alfabeto.Length; i1++)
            {
                for (int i2 = 0; i2 < alfabeto.Length; i2++)
                {
                    for (int i3 = 0; i3 < alfabeto.Length; i3++)
                    {
                        for (int i4 = 0; i4 < alfabeto.Length; i4++)
                        {
                            test = Convert.ToString(alfabeto[i1]) + Convert.ToString(alfabeto[i2])
                                 + Convert.ToString(alfabeto[i3]) + Convert.ToString(alfabeto[i4]);

                            test = test.Trim();
                            String test2 = "";

                            foreach (char c in test)
                                test2 += c + "x";

                            if (test2 != "")
                            {
                                this.actualizaLabel(test2, 2);

                                listaNombres.Add(test2);
                                listaNombresCod.Add(CodificaNombre(test2));
                            }

                            Thread.Sleep(3);
                        }
                    }
                }
            }
        }

        private void GeneraSeriales()
        {
            String test;

            for (int i1 = 0; i1 < numeros.Length; i1++)
            {
                for (int i2 = 0; i2 < numeros.Length; i2++)
                {
                    for (int i3 = 0; i3 < numeros.Length; i3++)
                    {
                        for (int i4 = 0; i4 < numeros.Length; i4++)
                        {
                            for (int i5 = 0; i5 < numeros.Length; i5++)
                            {
                                for (int i6 = 0; i6 < numeros.Length; i6++)
                                {
                                    for (int i7 = 0; i7 < numeros.Length; i7++)
                                    {
                                        for (int i8 = 0; i8 < numeros.Length; i8++)
                                        {
                                            test = Convert.ToString(numeros[i1]) + Convert.ToString(numeros[i2])
                                                 + Convert.ToString(numeros[i3]) + Convert.ToString(numeros[i4])
                                                 + Convert.ToString(numeros[i5]) + Convert.ToString(numeros[i6])
                                                 + Convert.ToString(numeros[i7]) + Convert.ToString(numeros[i8]);

                                            test = test.Trim();
                                            String test2 = "";

                                            foreach (char c in test)
                                                test2 += c + "0";

                                            if ((test2 != "") && (!test2.Contains(" 0")))
                                            {
                                                this.actualizaLabel(test2, 3);

                                                listaSeriales.Add(test2);
                                                listaSerialesCod.Add(CodificaSerial(test2));
                                            }

                                            Thread.Sleep(3);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        private string CodificaNombre(string nombre)
        {
            int eax;
            String hex;
            Int64 ecx = 0;
            bool x = false;

            foreach (char car in nombre)
            {
                x = !x;

                if (x == true)
                {
                    eax = Convert.ToInt32(car);
                    ecx += eax;                         // add ecx, eax
                    ecx = rol(ecx, 6);                  // rol ecx, 6
                    ecx = ecx ^ 43690;                  // xor ecx, 0AAAAh

                    if (ecx.ToString("X").Length > 8)   // nos quedamos con 1 word solamente
                        ecx = ecx & 4294967295;         // ecx AND 0FFFFFFFFh
                }
            }

            if (ecx.ToString("X").Length > 8)           // nos quedamos con 1 word solamente
                ecx = ecx & 4294967295;                 // ecx AND 0FFFFFFFFh

            ecx = rol(ecx, 6);                          // rol ecx, 6

            if (ecx.ToString("X").Length > 8)           // nos quedamos con 1 word solamente
                ecx = ecx & 4294967295;                 // ecx AND 0FFFFFFFFh

            ecx = ecx ^ 43690;                          // xor ecx, 0AAAAh

            hex = ecx.ToString("X");

            return hex.PadLeft(8, '0').ToUpper();
        }

        private string CodificaSerial(string serial)
        {
            int eax;
            String hex;
            Int64 ecx = 0;
            bool x = false;

            foreach (char car in serial)
            {
                x = !x;

                if (x == true)
                {
                    eax = Convert.ToInt32(car);
                    ecx += eax;                         // add ecx, eax
                    ecx = ror(ecx, 12);                 // ror ecx, 0Ch
                    hex = ecx.ToString("X");
                    ecx = ecx ^ 21845;                  // xor ecx, 05555h

                    hex = ecx.ToString("X");
                    if (ecx.ToString("X").Length > 8)   // nos quedamos con 1 word solamente
                        ecx = ecx & 4294967295;         // ecx AND 0FFFFFFFFh
                    hex = ecx.ToString("X");
                }
            }

            hex = ecx.ToString("X");
            if (ecx.ToString("X").Length > 8)           // nos quedamos con 1 word solamente
                ecx = ecx & 4294967295;                 // ecx AND 0FFFFFFFFh
            hex = ecx.ToString("X");

            ecx = ror(ecx, 12);                         // ror ecx, 0Ch

            if (ecx.ToString("X").Length > 8)           // nos quedamos con 1 word solamente
                ecx = ecx & 4294967295;                 // ecx AND 0FFFFFFFFh

            ecx = ecx ^ 21845;                          // xor ecx, 05555h

            hex = ecx.ToString("X");

            return hex.PadLeft(8, '0').ToUpper();
        }

        private Int64 rol(Int64 valor, int posiciones)
        {
            return (valor << posiciones) | (valor >> (WORD_LENGTH - posiciones)); 
        }

        private Int64 ror(Int64 valor, int posiciones)
        {
            return (valor >> posiciones) | (valor << WORD_LENGTH - posiciones);
        }

        private void bAbortar_Click(object sender, EventArgs e)
        {
            try { tareaNombres.Abort(); }
            catch { }
            try { tareaSeriales.Abort(); }
            catch { }
            try { tareaBusqueda.Abort(); }
            catch { }

            bComenzar.Enabled = true;
            bAbortar.Enabled = false;
            barra.Visible = false;
            timer1.Enabled = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label3.Visible = true;

            try
            {
                tareaNombres.Suspend();
                tareaSeriales.Suspend();

                tareaBusqueda = new Thread(BuscaCoincidencias);
                tareaBusqueda.Start();
            }
            catch 
            {
                label3.Visible = false;
            }
        }

        private void BuscaCoincidencias()
        {
            bool encontrado = false;

            try
            {
                foreach (String nombre in listaNombresCod)
                {
                    if (listaSerialesCod.Contains(nombre))
                    {
                        int posN = listaNombresCod.IndexOf(nombre);
                        int posS = listaSerialesCod.IndexOf(nombre);
                        this.actualizaLog(listaNombres[posN], listaSeriales[posS]);

                        encontrado = true;
                    }
                }
            }
            catch { }

            this.actualizaLabel("", 1);

            if (encontrado == false)
            {
                timer1.Enabled = true;
                tareaNombres.Resume();
                tareaSeriales.Resume();
                tareaBusqueda.Abort();
            }
            else
            {
                timer1.Enabled = false;

                try { tareaNombres.Abort(); }
                catch { }
                try { tareaSeriales.Abort(); }
                catch { }

                this.fin();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            bComenzar.Enabled = true;
            bAbortar.Enabled = false;
        }
    }
}