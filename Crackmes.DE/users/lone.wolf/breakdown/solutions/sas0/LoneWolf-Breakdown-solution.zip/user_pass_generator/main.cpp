#include <iostream>
#include <string>
#include <sstream>

#define USERNAME_XOR 0xDEADBEEF
#define MAX_TRANSFORM_VALUE 0xB8EA3EE8
#define MIN_TRANSFORM_VALUE 0x58923E8E
#define BASE_VALUE 0x04453E8E
#define MIN_RANGE_1 0x00000006
#define MAX_RANGE_1 0x0000000F
#define MIN_RANGE_3 0x00000000
#define MAX_RANGE_3 0x0000005A

unsigned long long xorshift64star(unsigned long long& rX);

struct tTransformElement 
{
    explicit tTransformElement(char passwordCharacter, unsigned char range12, unsigned char range3) :
        mPasswordCharacter(passwordCharacter), mRange12(range12), mRange3(range3) {}
    tTransformElement(const tTransformElement& rCopy) : mPasswordCharacter(rCopy.mPasswordCharacter), mAllRanges(rCopy.mAllRanges) {}
    const char mPasswordCharacter;
    union {
        const unsigned char mAllRanges;
        struct {
            const unsigned char mRange12 : 4;
            const unsigned char mRange3 : 4;
        };
    };
private:
    tTransformElement(void);
};

int main(int argc, char* argv[])
{
    std::string username_chars;
    // Create table of printable characters
    for (char c = 32; c < 127; c++)
        username_chars.append(1, c);
    // Table elements are sorted in ascending order by range3 value
    const tTransformElement appendix_b_table[] = { tTransformElement('1', 15, 0), tTransformElement('0', 14, 1), tTransformElement('3', 13, 2), tTransformElement('2', 12, 3), tTransformElement('5', 11, 4), 
                                                   tTransformElement('4', 10, 5), tTransformElement('7', 9, 6), tTransformElement('6', 8, 7), tTransformElement('9', 7, 8), tTransformElement('8', 6, 9)
                                                 };

    std::cout << "=========[Lone.Wolf's Breakdown! username/password generator]=========" << std::endl;

    if (4 != argc) {
        std::cout << "Usage: " << argv[0] << " seed iterations max_username_length";
        return -1;
    }

    unsigned int username_key = 0;
    unsigned int common_ukey = 0;

    unsigned long long seed = strtoull(argv[1], NULL, 10);
    if (0LL == seed || (ULLONG_MAX == seed && errno == ERANGE)) {
        std::cout << "Invalid seed value " << argv[1] << std::endl;
        return -1;
    }
    unsigned long long rnd_password_seed = seed;

    unsigned long long iterations = strtoull(argv[2], NULL, 10);
    if (0LL == iterations || (ULLONG_MAX == iterations && errno == ERANGE)) {
        std::cout << "Invalid iteration value " << argv[2] << std::endl;
        return -1;
    }

    unsigned long long max_username_length = strtoull(argv[3], NULL, 10);
    if (0LL == max_username_length || (ULLONG_MAX == max_username_length && errno == ERANGE)) {
        std::cout << "Invalid maximal username length value " << argv[3] << std::endl;
        return -1;
    }

    if (max_username_length < 4) {
        std::cout << "Minimal username length must be 4." << std::endl;
        return -1;
    }

    unsigned long long exp_idx = 0;
    char exp_char = 0;
    unsigned int rnd_idx;
    for (unsigned long long curr_it = 0; curr_it < iterations; curr_it++) {
        std::stringstream username;
        username_key = common_ukey = 0;
        for (unsigned long long i = 0; i < max_username_length; i++) {
            exp_idx = (0 == exp_idx) ? xorshift64star(seed) : exp_idx;
            exp_char = username_chars[exp_idx % username_chars.size()];
            exp_idx /= username_chars.size();
            username << exp_char;
            username_key = (username_key & 0xFFFFFF00) | (unsigned int)exp_char;     // loadsb
            username_key = (username_key << 4) | ((username_key & 0xF0000000) >> 28);   // rol eax, 4
            username_key = (username_key & 0xFFFF0000) |
                ((username_key & 0x000000FF) << 8) |                         // xchg ah, al
                ((username_key & 0x0000FF00) >> 8);
            username_key ^= USERNAME_XOR;                                           // xor eax, 0xDEADBEEF
            common_ukey += username_key;                                                // add edx, eax

            // Username length must be greater or equal 4 an final transformation value must be lower then 3
            if (i < 4 || ((int)common_ukey) >= 3) continue;
            // Condition 1
            if (common_ukey > MAX_TRANSFORM_VALUE || common_ukey < MIN_TRANSFORM_VALUE) continue;
            // Condition 2 must match pattern 0xR1R200R3 where R1, R2 and R3 represents ranges
            unsigned int range_values = common_ukey - BASE_VALUE;
            // Extract ranges
            unsigned int range_1 = ((range_values & 0xFF000000) >> 24);
            unsigned int range_2 = ((range_values & 0x00FF0000) >> 16);
            unsigned int range_3 = (range_values & 0x000000FF);
            if (((range_values & 0x0000FF00) >> 8) != 0) continue;
            // Condition 2a -> 6 <= (range 1 - range 2) <= 15
            unsigned int cond_2a = range_1 - range_2;
            if (!(MIN_RANGE_1 <= cond_2a && MAX_RANGE_1 >= cond_2a)) continue;
            // Condition 2c -> 0x00 <= range 3 <= 0x5A
            if (!(MIN_RANGE_3 <= range_3 && MAX_RANGE_3 >= range_3)) continue;
            // Calculate range 2 (10 iterations)
            unsigned int range_2_10 = 0;
            std::stringstream password;
            for (unsigned int rounds = 0; rounds < 10; rounds++) {
                rnd_idx = (0 == range_3) ? 0 : ((range_3 > 9) ? (((9 - rounds) * 9 > range_3) ? xorshift64star(rnd_password_seed) % 10 : 9) : range_3);
                range_3 -= appendix_b_table[rnd_idx].mRange3;
                range_2_10 += appendix_b_table[rnd_idx].mRange12;
                password << appendix_b_table[rnd_idx].mPasswordCharacter;
            }
            unsigned int eleventh_password_char = range_2 - range_2_10;
            if (!(MIN_RANGE_1 <= eleventh_password_char && MAX_RANGE_1 >= eleventh_password_char)) continue;
            password << appendix_b_table[MAX_RANGE_1 - eleventh_password_char].mPasswordCharacter;
            unsigned int twelveth_password_char = range_1 - range_2;
            if (!(MIN_RANGE_1 <= twelveth_password_char && MAX_RANGE_1 >= twelveth_password_char)) continue;
            password << appendix_b_table[MAX_RANGE_1 - twelveth_password_char].mPasswordCharacter;
            std::cout << username.str() << std::endl << password.str() << std::endl << std::endl;
        }
    }

    return 0;
}

unsigned long long xorshift64star(unsigned long long& rX)
{
    rX ^= rX >> 12; // a
    rX ^= rX << 25; // b
    rX ^= rX >> 27; // c
    return rX * 2685821657736338717ULL;
}
