--] M&M's CRACKME [--

A little serialme coded in asm! It's relatively easy, but BRUTEFORCING is forbidden !
Just use your brain, a pen and a paper, it's only logical :]

Enjoy :]


haiklr^NAS


klr63@hotmail.com
http://everyones-world.info
http://haiklr.new.fr