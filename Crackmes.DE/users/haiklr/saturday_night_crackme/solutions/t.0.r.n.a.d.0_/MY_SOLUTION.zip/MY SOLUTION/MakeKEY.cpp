#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <windows.h>

using namespace std;

unsigned int GlobalUnitDelay = 1;

void gotoxy(int x, int y)
{
    static COORD Position;
    Position.X = x;
    Position.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Position);
}

void Text_Animate(char *X)
{

    while( *X != '\0' )
    {
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_GREEN | FOREGROUND_INTENSITY);

        putchar('X');
        Sleep(GlobalUnitDelay);

        putchar('\b');
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_INTENSITY);
        putchar(*X);

        ++X;
    }
}

int main()
{
    char The_Key[16];
    unsigned long Zoom;

    The_Key[0] = 'D';           The_Key[1] = 'a';           The_Key[2] = 'n';           The_Key[3] = 'c';
    The_Key[4] = 'e';           The_Key[5] = ' ';           The_Key[6] = 'w';           The_Key[7] = 'i';
    The_Key[8] = 't';           The_Key[9] = 'h';           The_Key[10] = ' ';          The_Key[11] = 'm';
    The_Key[12] = 'e';          The_Key[13] = ' ';          The_Key[14] = '!';

    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_INTENSITY);

    putchar(10);
    Text_Animate ("/");
    Zoom = 13;
    while( Zoom-- ) { printf ("======"); Sleep (GlobalUnitDelay); }
    putchar('\\');

    printf("|                                                                              |");

    printf("|");
    Text_Animate("*  Welcome to T.0.R.N.A.D.0.'s KeyMaker for haiklr's Saturday Night Crackme  *");
    printf("|");

    printf("|                                                                              |");

    Text_Animate ("\\");
    Zoom = 13;
    while( Zoom-- ) { printf ("======"); Sleep (GlobalUnitDelay); }
    putchar('/');

    putchar(10);
    putchar(10);
    Text_Animate(">> Please enter the Entropy-Factor [NUMERIC, Range : 1 - 50] : ");
    scanf("%lu",&Zoom);

    srand(time(0));
    Zoom *= (unsigned long)(rand()%21);
    Zoom *= (unsigned long)(rand()%51);

    unsigned int j, k;
    char x;
    gotoxy(60,10);
    Text_Animate("Completed : ");
    for(unsigned int i = 0; i <= Zoom; ++i)
    {
        j = rand()%14;
        k = rand()%14;
        x = *(The_Key+j);
        *(The_Key+j) = *(The_Key+k);
        *(The_Key+k) = x;
        gotoxy(72,10);
        printf("%.2f %c\n",(100.0*i)/Zoom,'%');
    }
    The_Key[15] = '\0';

    gotoxy(0,10);
    Text_Animate(">> The generated key is : ");
    Text_Animate(The_Key);

    putchar(10);
    FILE *FilePointer;
    FilePointer = fopen("_._","w");
        fprintf(FilePointer,The_Key);
        fprintf(FilePointer,"%c",0);
    fclose(FilePointer);

    putchar(10);
    Text_Animate(">> Key-File _._ successfully generated in the current directory.");
    putchar(10);
    putchar(10);
    system("pause");
    return 0;
}
