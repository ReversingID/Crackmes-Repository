Hysteria Crackme

My last keygenme coded in asm.
Just use your brain, a pen and a paper ! No big equations... think about an original way to solve it !
BRUTEFORCING and PATCHING are always forbidden ! 
Writing a keygen/tutorial is the only solution allowed ;)

Have fun !

haiklr

http://haiklr.new.fr