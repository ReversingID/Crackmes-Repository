// HysteriaDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Hysteria.h"
#include "HysteriaDlg.h"
#include "Common.h"
#include "Crc32Static.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHysteriaDlg dialog

CHysteriaDlg::CHysteriaDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CHysteriaDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CHysteriaDlg)
	m_sName = _T("");
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CHysteriaDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHysteriaDlg)
	DDX_Control(pDX, IDC_BGENERATE, m_ctlBgenerate);
	DDX_Text(pDX, IDC_ENAME, m_sName);
	DDV_MaxChars(pDX, m_sName, 24);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CHysteriaDlg, CDialog)
	//{{AFX_MSG_MAP(CHysteriaDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_EN_CHANGE(IDC_ENAME, OnChangeEname)
	ON_BN_CLICKED(IDC_BGENERATE, OnBgenerate)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHysteriaDlg message handlers

BOOL CHysteriaDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CHysteriaDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CHysteriaDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CHysteriaDlg::OnChangeEname() 
{
	UpdateData(true);

	if (m_sName.GetLength() < 4)
		m_ctlBgenerate.EnableWindow(false);
	else
		m_ctlBgenerate.EnableWindow(true);

	UpdateData(false);
}

void CHysteriaDlg::OnBgenerate() 
{
	//Declaring variables
	char cName[25] = {0};
	unsigned int iSerial[6] = {0}, iHash1 = 0, iHash2 = 0, iHash3 = 0, iResult = 0, iResult2 = 0;
	int iLength = 0;
	CString sFile("");

	//Reading input
	GetDlgItemText(IDC_ENAME, cName, 25);
	iLength = strlen(cName);

	//CRC32 hash of name
	CCrc32Static::StringCrc32(cName, (unsigned long&)iHash1);
	iHash2 = iHash1;
	__asm
	{
		movzx eax, cName[0]
		mov byte ptr iHash2, al
	}
	sFile.Format("%X.", iHash2);
	

	//Serial Generation
	iHash2 = iHash1 % 99;
	iHash3 = iHash2 ^ 0x2007;

	iSerial[0] = iHash2 - 1;
	iSerial[2] = iHash2;
	iSerial[3] = iHash3 - 1;
	iSerial[1] = iHash3;
	iSerial[4] = iSerial[0];
	iSerial[5] = iSerial[3];

	//KeyFile Write
	try
	{
		CFile fKeyfile(sFile, CFile::modeCreate | CFile::modeWrite);
		fKeyfile.Write((BYTE*)iSerial, sizeof(iSerial));
		sFile = "Keyfile:\n" + fKeyfile.GetFilePath() + ".";
		fKeyfile.Close();
		AfxMessageBox(sFile);
	}
	catch(CFileException* fe)
	{
		char szMsg[256];
		fe->GetErrorMessage(szMsg, sizeof(szMsg));
		printf("%s\n", szMsg);
		AfxMessageBox(szMsg, MB_ICONHAND, 0);
		fe->Delete();
	}
}
