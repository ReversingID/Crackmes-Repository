// HysteriaDlg.h : header file
//

#if !defined(AFX_HYSTERIADLG_H__0E92089A_4D24_4F98_B357_5EEC961CB2F9__INCLUDED_)
#define AFX_HYSTERIADLG_H__0E92089A_4D24_4F98_B357_5EEC961CB2F9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CHysteriaDlg dialog

class CHysteriaDlg : public CDialog
{
// Construction
public:
	CHysteriaDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CHysteriaDlg)
	enum { IDD = IDD_HYSTERIA_DIALOG };
	CButton	m_ctlBgenerate;
	CString	m_sName;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHysteriaDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CHysteriaDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnChangeEname();
	afx_msg void OnBgenerate();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HYSTERIADLG_H__0E92089A_4D24_4F98_B357_5EEC961CB2F9__INCLUDED_)
