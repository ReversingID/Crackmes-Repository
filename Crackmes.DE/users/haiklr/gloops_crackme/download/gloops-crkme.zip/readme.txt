
---------> <------------> <---------
---------> GLOOPS CRACKME <---------
---------> <------------> <---------

Un nouveau crackme en asm, histoire de faire chauffer un petit coup Olly :]
C'est environ du level 1, pas de packer, pas d'anti-debug, un peu de patience et de logique et le tour est jou�. 

Les r�gles sont simples : afficher le message de goodboy ! Le premier qui patch/bruteforce garre � lui !

Le crackme est r�solvable sans bruteforce, un package cerveau/crayon/papier devrait largement suffir, m�me si quelques recherches sous Google peuvent �tre utiles (chercher du c�t� de la perfection...) :]

Voila voila, j'esp�re que quelques personnes se pencheront dessus ! Vous pouvez m'envoyer vos solutions par mp/mail...

Bon courage !


__________________________________

haiklr^NAS - octobre 2006

klr63@hotmail.com
http://everyones-world.info
http://haiklr.new.fr
__________________________________
