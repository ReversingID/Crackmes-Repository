#include <stdio.h>

int main()
{
    int Testing, Factor, SumFactor;

    for( Testing = 512; Testing < 8193; ++Testing )
    {
        SumFactor = 0;
        for( Factor = 2; Factor < Testing; ++Factor )
            if (!(Testing % Factor))
                SumFactor += Factor;
        if (SumFactor == Testing-1)
            printf("%d = %X is PERFECT !\n", Testing, Testing);
    }
    return 0 ;
}
