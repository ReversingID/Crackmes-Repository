//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SadPrincess.rc
//
#define IDC_BVALIDATE                   2
#define IDC_BGENERATE                   2
#define IDD_SADPRINCESS_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDC_ENAME                       1000
#define IDC_EPASSWORD                   1001
#define IDC_ESERIAL1                    1002
#define IDC_ESERIAL2                    1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
