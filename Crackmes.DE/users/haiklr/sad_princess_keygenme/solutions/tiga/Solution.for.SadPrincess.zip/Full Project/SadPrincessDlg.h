// SadPrincessDlg.h : header file
//

#if !defined(AFX_SADPRINCESSDLG_H__3E75E79C_12B3_4D38_AC6A_D15916A4402C__INCLUDED_)
#define AFX_SADPRINCESSDLG_H__3E75E79C_12B3_4D38_AC6A_D15916A4402C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CSadPrincessDlg dialog

class CSadPrincessDlg : public CDialog
{
// Construction
public:
	int rndint(double dInput);
	double log2x(double dInput);
	CSadPrincessDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CSadPrincessDlg)
	enum { IDD = IDD_SADPRINCESS_DIALOG };
	CButton	m_ctlBgenerate;
	CString	m_sName;
	CString	m_sPassword;
	CString	m_sSerial1;
	CString	m_sSerial2;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSadPrincessDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CSadPrincessDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnChangeEname();
	afx_msg void OnBgenerate();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SADPRINCESSDLG_H__3E75E79C_12B3_4D38_AC6A_D15916A4402C__INCLUDED_)
