int xo = 0;
void Generate(HWND hWnd)
{
	unsigned long w[5] = {0};
	w[1] = 1000;
	char name[50], serial[50], sn1[] = "125()00()6", serial2[50];
	int len = GetDlgItemText(hWnd,IDC_NAME,name,50);
	if ( len == 0 ){
		SetDlgItemText(hWnd,IDC_SERIAL,"A name please");}
	else
	{
		for (int i = 0; i < len; i++){
	w[0] += name[i];}
	w[2] = w[0] + 0x2007;
	w[3] = (w[0] + 0x2007) ^ 4;
	w[0] = atan(w[0])*1000;
	xo ^= 1;
	sn1[5] = sn1[6] = xo + 0x30;
	wsprintf(serial,"%u-%u",w[0],w[2]);
	wsprintf(serial2,"%u-%u",w[0],w[3]);
	SetDlgItemText(hWnd,IDC_SERIAL,sn1);
	SetDlgItemText(hWnd,IDC_SERIAL2,serial2);
	SetDlgItemText(hWnd,IDC_SERIAL4,serial);
	}

}