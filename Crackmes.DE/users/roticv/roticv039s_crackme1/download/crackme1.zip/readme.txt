Greetings all,

I had time to waste so I decided to code one crackme. Just remember that things are not always as what you think it is. This crackme was coded in fasm, and since I am a lazy guy. I did not add any resource, bear with the lack of GUI for the moment. For now, just toy with some ideas I had for this crackme. 

Regards,
Roticv 