Hi,

This is my crackme # 2 "Find my passw0rd".
In this one, i've try to make the job a little harder.

Code: ASM
Protection: Custom
Level: 2

Objectives:

_ Unpack if needed
_ Find the password
_ submit a tuto

Rules:
Patching not allowed...

tested on WinXP SP2 but should work on SP1 and Win2K.

Good work !

Znycuk