Hi,

Here is cracKme#3, i think this one will be hard for real newbies.
But not for the good reversers from crackmes.de  :-)

I wish that you will have fun defeating it !

Note: My RDG Packer Detector seems to have a false positive on it. 



==================================================================
Code: ASM
Protection: Custom
Level: 2 (maybe)
==================================================================

Objectives:

_ Unpack if needed
_ Make a keygen
_ submit a tuto (it should also describe the protector)



==================================================================
Rules:
>>>  Patching the goodboy jump is not allowed 	<<<
>>> As a Keygen is required: no serial fishing 	<<<
==================================================================

tested on WinXP PRO SP2, WinXP Home SP1, and Win2K SP4.

Good work !

Znycuk