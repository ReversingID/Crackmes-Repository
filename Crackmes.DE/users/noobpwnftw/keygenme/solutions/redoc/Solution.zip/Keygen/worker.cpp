#include "main.h"
#include <stdio.h>
#include "SHA/sha2.h"
extern "C" {
	#include "miracl/miracl.h"
};

big g_PrimeTable[RAND_MAX+1];

/*
//----------------------------------
void GenRndNumber256 (DWORD dwRndSeed, OUT BYTE Number[32])
{
	memset (Number, 0, 32);
	// init RNG
	srand (dwRndSeed);

	Number[0] = 0x80;		// high bit = 1
	for (int i=1; i<256; i++)
	{
		BYTE cBit = rand() * 2.0 * 0.000030517578125;
		if (cBit)
			Number[i / 8] |= 1 << (7 - i%8);
	}
}
//----------------------------------
bool SavePrimeTable ()
{
	miracl *mip;
	big bigPrime;
	DWORD i;
	FILE *f;
	BYTE bigPrimeRaw[32];

	mip = mirsys (200, 16);		// Initialize MIRACL library
	if (mip == 0) return false;
	mip->IOBASE = 16;
	bigPrime = mirvar (0);

	f = fopen ("PrimeTable.txt", "wb");

	for (i=0; i<=RAND_MAX; i++)
	{
		GenRndNumber256 (i, bigPrimeRaw);
		bytes_to_big (32, (char*)&bigPrimeRaw, bigPrime);
		nxprime (bigPrime, bigPrime);
		cotnum (bigPrime, f);
	}
	fclose (f);
	mirexit ();
	return true;
}
*/
//----------------------------------
bool MIRACL_Init()
{
	miracl *mip;
	FILE *f;

	mip = mirsys (200, 16);		// Initialize MIRACL library
	if (mip == 0) return false;
	mip->IOBASE = 16;

	f = fopen ("PrimeTable.txt", "rb");
	if (f == NULL)
		{mirexit (); return false;}

	for (DWORD i=0; i<=RAND_MAX; i++)
	{
		g_PrimeTable[i] = mirvar (0);
		cinnum (g_PrimeTable[i], f);
	}
	fclose (f);
	return true;
}
//----------------------------------
void MIRACL_Exit()
{
	mirexit ();
}
//----------------------------------
bool FactorBig3 (big big3, OUT big &big1, OUT big &big2)
{
	for (DWORD i=0; i<=RAND_MAX; i++)
	{
		if (!divisible (big3, g_PrimeTable[i]))
			continue;
		copy (g_PrimeTable[i], big2);		// big2 founded
		copy (big3, big1);
		divide (big1, big2, big1);		// big1 = big3 / big2
		if (!isprime (big1))
			continue;
		return true;
	}
	return false;
}
// factorize N by using private key D
// http://www.di-mgt.com.au/rsa_factorize_n.html
//----------------------------------
bool Factor_N_from_private_key (big bigD1, big bigN, OUT big &bigP, OUT big &bigQ)
{
	big bigK, bigT, bigG, bigTwo, bigX, bigY, bigE10001, bigOne;
	bigK=mirvar(0); bigT=mirvar(0); bigG=mirvar(0); bigTwo=mirvar(2); bigX=mirvar(0); bigY=mirvar(0);
	bigE10001=mirvar (0x10001); bigOne=mirvar (1);

	multiply (bigD1, bigE10001, bigK);
	subtract (bigK, bigOne, bigK);	// k = de-1

	irand (GetTickCount ());  // init miracl RNG
	for (DWORD i=0; i<100; i++)
	{
		do  {
			bigbits (512, bigG);		// random g, g<N
		} while (0 <= compare (bigG, bigN));
		copy (bigK, bigT);	// t = k

		while (divisible (bigT, bigTwo))		// t is divisible by 2
		{
			divide (bigT, bigTwo, bigT);			// t = t / 2
			powmod (bigG, bigT, bigN, bigX);	// x = pow(g, t) mod n
			if (0 < compare (bigX, bigOne))		// x > 1
			{
				subtract (bigX, bigOne, bigX);
				egcd (bigX, bigN, bigY);					// y = gcd (x-1, n)
				if (0 < compare (bigY, bigOne))		// y > 1
				{
					// success
					copy (bigY, bigP);				// p = y
					copy (bigN, bigQ);
					divide (bigQ, bigP, bigQ);	// q = N / p
					return true;
				}
			}
		}
	}
	return false;
}
//----------------------------------
bool Compute (char szName[130], char szBig3[130], char szBig4[130], char szN[130], char szAnswer[256])
{
	miracl *mip;
	big big1, big2, big3, big4, bigP, bigQ, bigN, bigSHA512, bigOne, bigF, bigE10001, bigE10003, bigD0, bigD1, bigD2, bigAnswer;
	DWORD i;
	sha512_ctx ctx;
	BYTE sha512_hash[64] = {0};
	BYTE D_raw[64] = {0};

	big1=mirvar(0); big2=mirvar(0); big3=mirvar(0); big4=mirvar(0); bigP=mirvar(0); bigQ=mirvar(0);	bigN=mirvar(0); bigSHA512=mirvar(0);
	bigOne=mirvar(1); bigF=mirvar(0); bigE10001=mirvar(0x10001); bigE10003=mirvar(0x10003); bigD1=mirvar(0); bigD2=mirvar(0); bigD0=mirvar(0);
	bigAnswer=mirvar(0);

	sha512_init (&ctx);
	sha512_update (&ctx, (unsigned char*)szName, strlen (szName));
	sha512_final (&ctx, sha512_hash);
	sha512_hash[0] &= 0x0F;		// zeroing high 4 bits

	bytes_to_big (sizeof(sha512_hash), (char*)sha512_hash, bigSHA512);
	cinstr (big3, szBig3);
	cinstr (big4, szBig4);
	cinstr (bigN, szN);

	//////////////////////////////////////////////////////////////////////////
	// factor  big3=big1*big2
	if (!FactorBig3 (big3, big1, big2))
		return false;

	// with factored big3 we can compute private key D2 for equation
	// big4 = pow (D1, 0x10001) mod big3
	subtract (big1, bigOne, big1);	// p-1
	subtract (big2, bigOne, big2);	// q-1
	multiply (big1, big2, bigF);			// bigF = (p-1)(q-1)
	copy (bigE10001, bigD2);			// 0x10001
	xgcd (bigD2, bigF, bigD2, bigD2, bigD2);		// private key D2

	// decrypt private key D1
	powmod (big4, bigD2, big3, bigD1);		// D1 = pow (big4, D2) mod big3

	// to get original D1 we must xor it by NameHash: D1 ^= sha512_hash
	big_to_bytes (sizeof(D_raw), bigD1, (char*)D_raw, FALSE);
	for (i=0; i<64; i++)
		D_raw[i] ^= sha512_hash[i];
	bytes_to_big (sizeof(D_raw), (char*)D_raw, bigD1);

	//////////////////////////////////////////////////////////////////////////
	// now we have to factorize modulus N=p*q using its private key D1
	if (!Factor_N_from_private_key (bigD1, bigN, bigP, bigQ))
		return false;
	//////////////////////////////////////////////////////////////////////////
	// with factorized N=p*q we can compute private key D0 for the equation
	// bigNamehash = pow (bigAnswer, 0x10003) mod N
	subtract (bigP, bigOne, bigP);	// p-1
	subtract (bigQ, bigOne, bigQ);	// q-1
	multiply (bigP, bigQ, bigF);			// bigF = (p-1)(q-1)
	copy (bigE10003, bigD0);			// 0x10003
	xgcd (bigD0, bigF, bigD0, bigD0, bigD0);		// private key D0
	//////////////////////////////////////////////////////////////////////////
	// now we can compute Answer
	// bigAnswer = pow (bigNamehash, D0) mod N
	powmod (bigSHA512, bigD0, bigN, bigAnswer);
	cotstr (bigAnswer, szAnswer);
	return true;
}