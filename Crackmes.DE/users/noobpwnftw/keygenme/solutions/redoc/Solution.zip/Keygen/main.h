#undef UNICODE
#undef _UNICODE
#include <Windows.h>

#define APP_NAME	"noobpwnftw's KeygenMe - Keygen"
#define MSG(x)		MessageBox (g_hDlg, x, APP_NAME, 0);