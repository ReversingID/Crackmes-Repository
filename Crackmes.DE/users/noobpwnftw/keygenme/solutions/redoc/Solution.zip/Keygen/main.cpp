#include "main.h"
#include "resource.h"
#include <Commctrl.h>

// proto
bool MIRACL_Init();
void MIRACL_Exit();
bool Compute (char szName[130], char szBig3[130], char szBig4[130], char szN[130], char szAnswer[256]);
// global vars
HWND g_hDlg;

//----------------------------------
bool Generate (HWND hDlg)
{
	DWORD dwRet;
	HWND hWndCrackme, hCtrl;
	char szN[130], szBig3[130], szBig4[130], szBig2[130]={0};
	char szName[130] = {0}, szRequest[512] = {0};
	STARTUPINFO start_info = {sizeof(STARTUPINFO)};
	PROCESS_INFORMATION process_info = {0};

	if (!GetDlgItemText (hDlg, IDC_EDIT_NAME, szName, sizeof(szName)))
		{MSG ("Please specify your name"); SetFocus (GetDlgItem (hDlg, IDC_EDIT_NAME)); return false;}
	if (256 > GetDlgItemText (hDlg, IDC_EDIT_REQUEST, szRequest, sizeof(szRequest)))
		{MSG ("Please specify request string"); SetFocus (GetDlgItem (hDlg, IDC_EDIT_REQUEST)); return false;}

	// parsing N, big3, big4 from request
	memcpy (szN, szRequest, 128); szN[128] = 0;
	memcpy (szBig3, &szRequest[128], 128); szBig3[128] = 0;
	memcpy (szBig4, &szRequest[256], 128); szBig4[128] = 0;

	char szAnswer[256] = {0};
	if (!Compute (szName, szBig3, szBig4, szN, szAnswer))
		{MSG ("Something wrong happened"); return false;}

	SetDlgItemText (hDlg, IDC_EDIT_SERIAL, szAnswer);
	return true;
}
//----------------------------------
bool Generate2 (HWND hDlg)
{
	DWORD i, dwRet;
	HWND hWndCrackme, hCtrl;
	char szN[130], szBig3[130], szBig4[130], szBig2[130]={0};
	char szName[130] = {0}, szRequest[512] = {0};
	STARTUPINFO start_info = {sizeof(STARTUPINFO)};
	PROCESS_INFORMATION process_info = {0};

	if (!GetDlgItemText (hDlg, IDC_EDIT_NAME, szName, sizeof(szName)))
		{MSG ("Please specify your name"); SetFocus (GetDlgItem (hDlg, IDC_EDIT_NAME)); return false;}

	hWndCrackme = FindWindow (0, "KeygenMe");
	if (hWndCrackme == 0)
		{MSG ("Can't find crackme window.\r\nPlease start KeygenMe.exe"); return false;}

	hCtrl = GetDlgItem (hWndCrackme, 1000);		// set name
	SendMessage (hCtrl, WM_SETTEXT, 0, (LPARAM)szName);
	for (i=0,dwRet=0; i<2 && dwRet<256; i++)
	{
		hCtrl = GetDlgItem (hWndCrackme, 1002);
		SendMessage (hWndCrackme, WM_COMMAND, 1002, (LPARAM)hCtrl);		// push button Request/Reset
		hCtrl = GetDlgItem (hWndCrackme, 1001);		// get request string
		dwRet = SendMessage (hCtrl, WM_GETTEXT, sizeof(szRequest), (LPARAM)szRequest);
	}
	if (dwRet < 256)
		{MSG ("Request generating problem"); return false;}
	SetDlgItemText (hDlg, IDC_EDIT_REQUEST, szRequest);
	// parsing N, big3, big4 from request
	memcpy (szN, szRequest, 128); szN[128] = 0;
	memcpy (szBig3, &szRequest[128], 128); szBig3[128] = 0;
	memcpy (szBig4, &szRequest[256], 128); szBig4[128] = 0;

	char szAnswer[256] = {0};
	if (!Compute (szName, szBig3, szBig4, szN, szAnswer))
		{MSG ("Something wrong happened"); return false;}

	SetDlgItemText (hDlg, IDC_EDIT_SERIAL, szAnswer);
	//////////////////////////////////////////////////////////////////////////
	// test the answer
	hCtrl = GetDlgItem (hWndCrackme, 1003);		// set answer
	SendMessage (hCtrl, WM_SETTEXT, 0, (LPARAM)szAnswer);
	hCtrl = GetDlgItem (hWndCrackme, 1004);		
	PostMessage (hWndCrackme, WM_COMMAND, 1004, (LPARAM)hCtrl);		// push button Check

	return true;
}
//----------------------------------
BOOL CALLBACK DialogProc(HWND  hwndDlg, UINT  uMsg, WPARAM  wParam, LPARAM  lParam )
{
	switch (uMsg)
	{
	case WM_INITDIALOG:
		g_hDlg = hwndDlg;
		#ifdef NAME_MAX
		SendDlgItemMessage (hwndDlg, IDC_EDIT_NAME, EM_SETLIMITTEXT, NAME_MAX, 0);
		#endif
		HICON hIcon;	// dialog icon
		if (hIcon = LoadIcon(GetModuleHandle(0), MAKEINTRESOURCE(IDI_ICON1))) {
			SendMessage(hwndDlg, WM_SETICON, TRUE, (LPARAM)hIcon);
			SetClassLong (hwndDlg, GCL_HICON, (LONG)hIcon);
		}
		if (!MIRACL_Init())
			{MSG ("Can't initialize MIRACL module"); EndDialog (hwndDlg, 0);}
		return TRUE;

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDC_BUTTON_GENERATE:
			Generate(hwndDlg); return TRUE;
 		case IDC_BUTTON_TEST:
 			Generate2(hwndDlg); return TRUE;
		case IDCANCEL:
			MIRACL_Exit ();
			EndDialog (hwndDlg, 0); return TRUE;
		}
		break;
	}
	return FALSE;
}
//----------------------------------
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	InitCommonControls();
	DialogBox (hInstance, MAKEINTRESOURCE(IDD_DIALOG1), 0, DialogProc);
	return 0;
}
