#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef unsigned int uint;
typedef unsigned long long int ulong;

uint umulhi(uint a, uint b)
{
  return (uint)((((ulong)a) * ((ulong)b))>>32);
}

uint get_random_uint()
{
  uint result = 0;
  int i;
  for (i = 0; i < 4; i++)
  {
    result = (result << 8) | (uint)rand();
  }
  return result;
}
int main(int argc, char**argv) 
{
  uint v161 = 0, v166 = 0, v353 = 0, v355 = 0, 
    v474 = 0, v477 = 0, v282 = 0, v288 = 0;
    uint mask28 = 0x6487169F, mask16 = 0x20890481, 
    mask35 = 0x5B7A027F, mask47 = 0x11258023;
  int i;
  uint s[8+1];
  s[0] = 0xDEADC0DE;
  srand(time(NULL));

  while (true) 
  {
    //get some random values
    v161 = get_random_uint();
    v474 = get_random_uint();
    v355 = get_random_uint();

    //first test v474 XOR v288 XOR 35059FC5 == 48A86FC4 
    v288 = 0x48A86FC4 ^ 0x35059FC5 ^ v474;

    //second test v166 XOR v355 XOR 54A80618 == 489AC581
    v166 = 0x489AC581 ^ 0x54A80618 ^ v355;

    //third test v477 XOR v474 XOR 35059FC5 == 6582138E
    v477 = 0x6582138E ^ 0x35059FC5 ^ v474;

    //fourth test ... == v282
    v282  = ~(((umulhi(0xF0F0F0F1, v161 ^ 0x698B93C2)>>4) * (v355 ^ 0x54A80618)) + 
      ((umulhi(0x4EC4EC4F, v161 ^ 0x698B93C2) >> 2) * (v474 ^ 0x35059FC5)) + 
      ((v355 ^ 0x54A80618) * (v474 ^ 0x35059FC5)));

    //fifth test ... == v353
    v353 = ~(((v161 ^ 0x698B93C2) - 
      ((umulhi(0xAAAAAAAB,  ((v161 ^ 0x698B93C2) * (v474 ^ 0x35059FC5))) >> 1)) + 
      (v355 ^ 0x54A80618)));

    //compose serial
    s[1] = ((v161 ^ v166) & mask16) ^ v161; s[6] = ((v161 ^ v166) & mask16) ^ v166;
    s[3] = ((v353 ^ v355) & mask35) ^ v353; s[5] = ((v353 ^ v355) & mask35) ^ v355;
    s[4] = ((v474 ^ v477) & mask47) ^ v474; s[7] = ((v474 ^ v477) & mask47) ^ v477;
    s[2] = ((v282 ^ v288) & mask28) ^ v282; s[8] = ((v282 ^ v288) & mask28) ^ v288;

    //print serial
    for (i = 1; i <= 8; i++)
    {
      printf("%08X", s[i]);
    }
    printf("\nPress ENTER to generate a new serial.\n");
    while (getchar() != '\n');
  }   
}