#include <stdio.h>

typedef unsigned int	u32;
typedef unsigned short	u16;
typedef unsigned char	u8;

typedef signed int		s32;
typedef signed short	s16;
typedef signed char		s8;

int main() {
	int i;
	char name[82];
	u32 chk = 0;

	printf("KeyGen for FaTmiKE's Crackme #2\n2005 Parasyte\n\n");

	printf("Enter Your Name: ");
	fgets(name, 81, stdin);
	if ((strlen(name) - 1) < 4) { //take into account the newline!
		printf("Name must contain 4 or more characters!\n\n");
		system("pause");
		return 1;
	}
	name[strlen(name) - 1] = 0; //remove trailing newline

	//checksum the entered name
	for (i = 0; i < strlen(name); i++) {
		chk += name[i];
	}
	chk *= 0xDEADBEEF; //the checksum offset... nice ;)

	if (!(chk & 0xF0000000)) {
		printf("The entered name is invalid, due to a bug in the crackme!\nPlease choose another name\n\n");
		system("pause");
		return 1;
	}

	//"generate" the key!
	printf("Your serial is: K%02XE-W%02XL-S%02XH-I%02XT\n\n", //Yahoo! "KEWL SHIT"
		((chk >> 0x18) & 0xFF),
		((chk >> 0x10) & 0xFF),
		((chk >> 0x08) & 0xFF),
		((chk >> 0x00) & 0xFF));

	system("pause");
	return 0;
}
