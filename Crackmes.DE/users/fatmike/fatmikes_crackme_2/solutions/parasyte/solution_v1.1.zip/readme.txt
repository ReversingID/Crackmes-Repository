Solution to FaTmiKE's Crackme #2
by Parasyte, 2005

Tools used:
 UPX
 IDA Pro


Well, here's my solution. I'm pretty bad with tutorials, so I'll keep this real
short and simple.

The first thing you notice when inspecting this crackme is that it's packed
with UPX. So just unpack it with UPX!
Next, open the unpacked exe in IDA Pro, and we're taken right to the WinMain()
function, which contains a very handy call to DialogBoxParamA() Like so:

.text:004013E9 6A 00                           push    0                       ; dwInitParam
.text:004013EB 68 50 14 40 00                  push    offset DialogFunc       ; lpDialogFunc
.text:004013F0 6A 00                           push    0                       ; hWndParent
.text:004013F2 6A 65                           push    65h                     ; lpTemplateName
.text:004013F4 50                              push    eax                     ; hInstance
.text:004013F5 FF 15 A8 80 40 00               call    ds:DialogBoxParamA      ; Create a modal dialog box from a
.text:004013F5                                                                 ; dialog box template resource



Double click on "DialogFunc" and you're taken right into the message handler.
(Whew, this is tough, so far! :D)
Run the program with F9, and set a breakpoint on the DialogFunc address (0x00401450)
then enter some fake name and serial. When you push the "Register" button, you'll
be greeted with a break! Step through the assembly until you reach the jump table
stuff here:

.text:0040148F 33 C9                           xor     ecx, ecx
.text:00401491 8A 88 58 17 40 00               mov     cl, ds:byte_401758[eax]
.text:00401497 FF 24 8D 44 17 40 00            jmp     ds:off_401744[ecx*4]


Step into the jmp instruction (F7) and you'll end up here:

.text:004014F4                         loc_4014F4:                             ; CODE XREF: DialogFunc+47j
.text:004014F4                                                                 ; DATA XREF: .text:off_401744o
.text:004014F4 33 F6                           xor     esi, esi
.text:004014F6 89 75 0C                        mov     [ebp+arg_4], esi
.text:004014F9 8B 3D 4C 92 40 00               mov     edi, dword_40924C

...

Yadda, yadda... Now we're in the message handler for the Register button. If you
step through to the first two calls within this code, you'll find that they are
both calls to GetDlgItemTextA(). And if you made it this far, I'm certain you can
figure out that the first gets the name you entered, and the second gets the
serial. After this, you'll see a few interesting compares. These are obviously
checking the lengths of the entered name and serial. This is pretty important:

.text:00401543 83 FA 03                        cmp     edx, 3
.text:00401546 0F 8E 3B 01 00 00               jle     loc_401687
.text:0040154C 83 7D 10 13                     cmp     [ebp+arg_8], 13h
.text:00401550 0F 85 31 01 00 00               jnz     loc_401687

The first compare ensures the entered name is greater than 3! The second ensures
the serial is exactly 19 characters long.


Now we know what to enter to get passed these checks; a name that's no less than 4
characters long, and a serial that's exactly 19 characters long. Run the program
and do so. When you hit the Register button, start stepping from your breakpoint
and watch these compares pass. (Or better yet, delete that old breakpoint and put
one at 0x00401556!)

Now, we know the string lengths required. If we continue on, we'll find a read from
"byte_40921C" ... Well, we know the serial was stored to 00409218 by the second call
to GetDlgItemTextA()! So this code is reading pieces of our entered serial. It
compares a few characters of our serial with 0x2D, which so happens to be the ASCII
value for a hyphen (-). And if you do a little thinking, you'll see which pieces of
the serial it is comparing. If any of these compares fail, the registration fails.
To save a little time and to keep the bore factor near a minimum, the code simply
verifies that the entered serial is in the proper format. And that format is as
follows:

xxxx-xxxx-xxxx-xxxx

Where 'x' represents one of the actual characters of the serial.
So I continued the program with F9, and entered a "properly formatted" serial:

0123-4567-89ab-cdef

A new breakpoint at 0x0040157E verifies that the serial format is correct. This
section of code clears an array held at [ebp+var_34]... Nothing special. Move on
down to 0x0040158C and we see our first interesting piece of code!
Oh, how the excitement overwhelms...


.text:0040158C 33 C0                           xor     eax, eax
.text:0040158E 85 D2                           test    edx, edx
.text:00401590 7E 0C                           jle     short loc_40159E
.text:00401592
.text:00401592                         loc_401592:                             ; CODE XREF: DialogFunc+14Cj
.text:00401592 0F BE 4C 05 98                  movsx   ecx, byte ptr [ebp+eax+var_68]
.text:00401597 03 F1                           add     esi, ecx
.text:00401599 40                              inc     eax
.text:0040159A 3B C2                           cmp     eax, edx
.text:0040159C 7C F4                           jl      short loc_401592
.text:0040159E 69 F6 EF BE AD DE               imul    esi, 0DEADBEEFh
.text:004015A4 89 75 0C                        mov     [ebp+arg_4], esi

This is really quite simple here, but it turns out to be the most important piece
of code in the whole registration process. Again, if you've been paying attention,
that first call to GetDlgItemTextA() placed the entered name into [ebp+var_68].
And now we have code accessing this area of memory. If you follow this little loop
step-by-step, it should be clear that it's adding all bytes of the name together.
This is a classic example of a checksum. Almost all serial number verifiers will
do something similar, whether it's a checksum, CRC, MD5, or other kind of one-way
hash, these are pretty good ways to generate a unique number to help "randomize"
the serial. And in this case, a simple checksum will do it!

After the loop exits (it's checksummed the entire name, by this time) it will
execute that interesting imul instruction at 0x0040159E. Notice the second factor;
0xDEADBEEF! Can't help but love nerd jargon. ;D
So then, this multiplication is a simple "checksum offset" to help randomize our
ZOMG-SEKRIT-NUMBR some more. Then it's tucked nicely away into [ebp+arg_4].

OK, fun's over! Back to the grunt-work.
The following call goes to wsprintf(), and it's passing our ZOMG-SEKRIT-NUMBR with
the format "%X" ... Trust me! Dig through those pointers that are pushed. It all
makes sense!


[NOTE: The use of "%X" here causes a bug with magic numbers less than 0x10000000,
because wsprintf will output a string with less than 8 characters. This will make
the serial number INVALID by placing NULLs within the serial. This bug may have
been avoided by using "%08X" instead.]


After that, parts of the serial are compared with the printed output from wsprintf.
So yeah, that's pretty much it for our ZOMG-SEKRIT-NUMBR! Now that we know how to
generate it, write down the algorithm in your notes, then continue on!


The code which does all of this ZOMG-SEKRIT-NUMBR comparing is just another part
of the serial format. Again, I know you are a lazy bum, so I'll give you the format
so far, and we can skip the unneeded explanation:

x01x-x23x-x45x-x67x

Where each number represents the digits of our ZOMG-SEKRIT-NUMBR in hex... from
left-to-right, of course. (So if your ZOMG-SEKRIT-NUMBR really was 0x01234567,
that would be your serial, so far.)

If you enter your proper serial-so-far and try to register, the program will
disable most of the windows. And of course you can see the code which does this at
0x00401641. BUT! If you try to "Go!" you'll see just how screwed you really are.
If you did try the registration and it disabled the windows (meaning the serial is
good ... but not quite good enough) then you'll have to just restart the program so
you can figure out what the rest of the "algorithm" is to generate the rest of your
serial!

After all of the formatting checks pass, at 0x00401638, it looks like the only thing
the routine does from here is disable the windows and return. But that's an illusion.
The trained eye will be able to spot two instructions which don't have a damn thing
to do with the disabling of windows;

.text:0040163B 8B 0D 8C 92 40 00               mov     ecx, dword_40928C
...
.text:0040164D 89 0D 58 92 40 00               mov     dword_409258, ecx

If you double click on dword_40928C, it takes you to a little area with more numbers.
But these are special numbers. See, they are pointers. More specifically, they are
pointers into the .text area. That means ... this is replacing a function pointer.
OOoooh, Sneaky! dword_40928C points to 0x004012B0, so go there by double clicking on
it! Ahh, yes, it really is a sub routine... Set a breakpoint on it, and RUN! (F9!)

Now that the windows are all (hopefully) disabled, you're ready to figure out the
rest of the serial format. With the new breakpoint in place, hit GO! If all is well,
you'll end up with the break at 0x004012B0.
Here we have more comparisons with the entered serial, as you can see starting with
the read from byte_409218. If you follow the code, you can see it pulls those first
four 'unknown' characters from the entered serial, shifts them into byte positions,
and ORs them together, effectively creating a 32-bit integer from the four chars.
The result is stored into dword_409290. Remember this.
Next, it does the same thing with the last four 'unknown' characters, and places the
result into dword_409294. Remember this as well!


Next, a call to sub_401110()!
If we go in here, we see reads from dword_409290 and dword_409294!
*GASP*!
*GASP* I SAY!

We also have some interesting reads from an array starting at dword_409148. If you
double click on that, (and you should) you'll see the contents of this array. Might be
wise to make some notes of these values. There are 23 of them in all (each 32-bits wide).

As we continue, we see a bunch of silly XORs. These are all changing the data in that
23-element array we just discovered. It's rather boring work to work through it all.
It just changes each element by XOR'ing them with the values from dword_409290 then
dword_409294, in an alternating pattern. Blah blah! You can exit this routine now, since
we know what it does.


Now we find another function pointer call... This one leads to sub_401770()
In here, we find the very last step of the serial algorithm!

.text:00401776 81 3D 98 91 40 00 E8 7B+        cmp     dword_409198, 97BE8h
.text:00401780 0F 85 32 01 00 00               jnz     loc_4018B8
.text:00401786 81 3D 5C 91 40 00 FF D1+        cmp     dword_40915C, 0D8BD1FFh
.text:00401790 0F 85 22 01 00 00               jnz     loc_4018B8


Yep, that's all there is to it!
Pay attention, now!

We know that the XOR-modified array is at dword_409148... We also know that it is 23
elements long. From this info, it's plain to see that dword_409198 (as seen above) is
element 20 from that very array. Not surprisingly, dword_40915C is element 5.
Now if we think back REAL HARD, we might be able to remember that these array elements
were XOR'd with the last remaining 'unknown' characters in the serial. And to top it off,
we know that all even elements were XOR'd with the first of the four unknowns. And all
odd elements were XOR'd with the last four unknowns.

Finally, we can deduce these unknowns simply because XOR is reversible. Take the value
from dword_409198 (0x4B4C2CA4) and XOR it with 0x00097BE8. (See how this is working?
looks a lot like the code above, eh?) Of course the result is 0x4B45574C. Do the same
with the next one, and you get 0x53484954. NOW we know the required values for these
last two compares to pass successfully. And if we remember how these values were
generated in the first place, (shifting four bytes into a 32-bit integer) we can just
reverse that process and put these new values into the right positions in the serial.

OR, it's just a whole lot easier to type these into a hex editor and plug the actual
characters into the blank spots in our serial. When you enter these into a hex editor,
you'll find that they spell "KEWL" and "SHIT" respectively. Nice!

Our final serial format is (with numbers representing the ZOMG-SEKRIT-NUMBR, remember?):

K01E-W23L-S45H-I67T



Having all this wonderful information handy, we can write a KeyGen!
Rather than going through and documenting that process, just check the included keygen
source code. Problem solved.




In the tradition of my previous reverse engineering documentation;
WORK IT HARDER!
