// written by bilbo - 23oct05
// compiled with MSVC running "cl -W3 md5calc.c md5.c"

#include <stdio.h>
#include <string.h>
#include "md5.h"

void
do_md5(char *in/*ascii in*/, char *out/*32-char ascii out*/)
{
	int i;
	unsigned char md5sum[16];  // MD5 binary

	md5_starts();
	md5_update(in, strlen(in));
	md5_finish(md5sum);

		// convert binary to hex
	for (i=0; i<16; i++) sprintf(out+i*2, "%02X", md5sum[i]);
}

void
main(void)
{
	unsigned l, oldl;
	char out[32+1];  // MD5 ascii

	out[32] = 0;  // trailing null
	printf(".");  // first dot

		// md5(??????81) = ....4E26E075....................
	for (l=0x00000081, oldl=0; l>oldl/*until wraparound*/; l+=0x100) {
		char s[8+1];

			// 16 dots will be shown
		if (l>>28 != oldl>>28) printf(".");

		sprintf(s, "%08X", l);
		do_md5(s, out);

		if (!strncmp(&out[4], "4E26E075", 8)) printf("%x\n", l);
		oldl = l;
		}
}
// RESULT is C30F5E81
