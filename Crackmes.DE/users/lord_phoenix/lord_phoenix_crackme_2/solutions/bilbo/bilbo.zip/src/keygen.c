// written by bilbo - 23oct05
// compiled with MSVC running "cl -W3 keygen.c md5.c"

#include <stdio.h>
#include <string.h>
#include "md5.h"

void
do_md5(char *in/*ascii in*/, char *out/*32-char ascii out*/)
{
	int i;
	unsigned char md5sum[16];  // MD5 binary

	md5_starts();
	md5_update(in, strlen(in));
	md5_finish(md5sum);

		// convert binary to hex
	for (i=0; i<16; i++) sprintf(out+i*2, "%02X", md5sum[i]);
}

void
main(void)
{
	char name[128];
	char md5_out[32+1];  // ascii
	char chunk1[8+1], chunk2[8+1], chunk3[4+1], serial[20+1];
	unsigned uchunk1, uchunk2;

	md5_out[32] = chunk1[8] = chunk2[8] = chunk3[4] = 0;  // trailing nulls

	printf("Enter your name: ");
	if (!gets(name)) return;

		// chunk1 and uchunk1
	do_md5(name, md5_out);
	strncpy(chunk1, md5_out, 8);
	sscanf(chunk1, "%08X", &uchunk1);
	strcpy(serial, chunk1);

		// chunk2 and uchunk2
	sprintf(chunk2, "%08X", uchunk1^0xC30F5E81);
	sscanf(chunk2, "%08X", &uchunk2);
	strcat(serial, chunk2);

		// chunk3
	do_md5(serial, md5_out);
	strncpy(chunk3, md5_out+3, 4);
	strcat(serial, chunk3);

	printf("your serial is %s\n", serial);
}
