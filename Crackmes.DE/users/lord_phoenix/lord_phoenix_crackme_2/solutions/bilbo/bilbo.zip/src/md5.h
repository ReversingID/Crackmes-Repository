#ifndef _MD5_H
#define _MD5_H

#ifndef uint8
#define uint8  unsigned char
#endif

#ifndef uint32
#define uint32 unsigned long int
#endif

uint32 state[4];

typedef struct
{
	uint32 total[2];
	uint8 buffer[64];
} md5_context;

void md5_starts(void);
void md5_update(uint8 *input, uint32 length);
void md5_finish(uint8 digest[16]);

#endif /* md5.h */
