/*****************************************
 * Created by [BiGBOi]                   *
 * 6/30/05                               *
 * Solution to CrackMe#1.by.lord_Phoenix *
 *****************************************/

#include <iostream>
#include "bigint.h"

typedef RossiBigInt BigInt;

using namespace std;

void reverseGenProc(int Bit0, int Bit1, int Bit2, int Bit3, int Bit4, 
int Bit5, int Bit6, int Bit7);
 
int main()
{
	reverseGenProc(0x2,0xC,0xB,0x8,0x4,0x0,0x1,0x4);

	return 0;
}

void reverseGenProc(int Bit0, int Bit1, int Bit2, int Bit3, int Bit4, 
int Bit5, int Bit6, int Bit7)
{
	BigInt nullifier(0x8000);
	BigInt blah(0);
	nullifier = nullifier * BigInt(0x10000);
	nullifier = nullifier + BigInt(0x00FF);

	BigInt last2(0x0);

	for(int u=0x30;u<0x47;u++)
{
	for(int w=0x30;w<0x47;w++)
{
		last2 = ((BigInt(u) * BigInt(w) * BigInt(0xBC)) & 
nullifier);
if(last2==BigInt(0x70))
{
	for(int x=0x30;x<0x47;x++)
{
		last2 = ((BigInt(w) * BigInt(x) * BigInt(0x3A)) & 
nullifier); 
if(last2==BigInt(0x70))
{
	for(int y=0x30;y<0x47;y++)
{
		last2 = ((BigInt(x) * BigInt(y) * BigInt(0xDE)) & 
nullifier);
if(last2==BigInt(0x14))
{
	for(int z=0x30;z<0x47;z++)
{
		last2 = ((BigInt(y) * BigInt(z) * BigInt(0x2F)) & 
nullifier);
if(last2==BigInt(0x91))
{

int tempu = u;
int tempw = w;
int tempx = x;
int tempy = y;
int tempz = z;

if(tempu>=0x30 && tempu<0x40)
	tempu=tempu-0x30;
else
	tempu=tempu-0x37;

if(tempw>=0x30 && tempw<0x40)
	tempw=tempw-0x30;
else
	tempw=tempw-0x37;

if(tempx>=0x30 && tempx<0x40)
	tempx=tempx-0x30;
else
	tempx=tempx-0x37;

if(tempy>=0x30 && tempy<0x40)
	tempy=tempy-0x30;
else
	tempy=tempy-0x37;

if(tempz>=0x30 && tempz<0x40)
	tempz=tempz-0x30;
else
	tempz=tempz-0x37;

tempu = tempu ^ Bit1;
tempw = tempw ^ Bit2;
tempx = tempx ^ Bit3;
tempy = tempy ^ Bit4;
tempz = tempz ^ Bit5;

cout << "Second 8..." << endl;
cout << "XyyyyyXX" << endl;
cout << hex << uppercase << "X"<< tempu  << tempw << tempx << tempy << 
tempz << 
"XX" << endl;

}}}}}}}}}

}
