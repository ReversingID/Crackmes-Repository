/*****************************************
 * Created by [BiGBOi]                   *
 * 6/30/05                               *
 * Solution to CrackMe#1.by.lord_Phoenix *
 *****************************************/
                                     
#include <iostream>
#include "bigint.h"

typedef RossiBigInt BigInt;

using namespace std;

BigInt Serial[20];
BigInt finalSerial[20];

// varValsA[8], varValsB[8]
// Values that will be adjusted during the serial generation
// They are the same values.  I need two of them because the values
// will change after I run the calcCodeBase() method and I need
// to run it twice.

BigInt varValsA[8] = 
{BigInt(0x75),BigInt(0x49),BigInt(0xBC),BigInt(0x3A),BigInt(0xDE),BigInt(0x2F),BigInt(0xFD),BigInt(0x1A)};

BigInt varValsB[8] = 
{BigInt(0x75),BigInt(0x49),BigInt(0xBC),BigInt(0x3A),BigInt(0xDE),BigInt(0x2F),BigInt(0xFD),BigInt(0x1A)};

// Method to calculate serial numbers
void calcCodeBase(BigInt constVals[], BigInt varVals[]);

int main()
{
	char aUserName[20];
	BigInt constValsC[16];
	BigInt constValsB[16];
	BigInt tempA(0);

	int n=0;
	int m=0;
	int counter=0;

	cout << "KeyGen for lord_Phoenix's Crack Me #1" << endl;
	cout << "Author: [BiGBOi]" << endl;
	cout << "Date:   June 30, 2005" << endl << endl;
	cout << "Max size for the username is 15" << endl;
	cout << "Username: ";
	cin >> aUserName;

	while(aUserName[m] != '\0')
	{
		if(counter==15)
		{
			cout << "Input string too long";
			return 0;
		}

		constValsC[m] = BigInt((int)aUserName[m]);
		m++;
		counter++;
	}

	constValsC[m] = BigInt(0x2A);

	calcCodeBase(constValsC, varValsA);

	for(int i=7; i>=4; i--)
		Serial[7-i] = varValsA[i];

	Serial[4]=Serial[0] ^ BigInt(0x49);
	Serial[5]=Serial[1] ^ BigInt(0xDF);
	Serial[6]=Serial[2] ^ BigInt(0x97);
	Serial[7]=Serial[3] ^ BigInt(0x5C);

	for(n=0; n<16; n=n+2)
	{
		tempA = Serial[n/2] % BigInt(0x10);

		if(tempA < BigInt(0xA))
			constValsB[n+1] = tempA + BigInt(0x30);
		else
			constValsB[n+1] = tempA + BigInt(0x37);

		tempA = Serial[n/2] / BigInt(0x10);

		if(tempA < BigInt(0xA))
			constValsB[n] = tempA + BigInt(0x30);
		else
			constValsB[n] = tempA + BigInt(0x37);
		
	}

	// The last byte of the constant values must be 0x2A
	constValsB[n] = BigInt(0x2A);

	// This just makes sure that if there was a leading 0
	// that it will still be displayed

	for(int m=0;m<8;m++)
	{
		finalSerial[2*m+1] = Serial[m] % BigInt(0x10);
		finalSerial[2*m] = Serial[m] / BigInt(0x10);

	}

	// Figures out the last 4 chars
	calcCodeBase(constValsB, varValsB);

	cout << "Serial:   ";

	for(int m=0;m<20;m++)
		cout << hex << uppercase << finalSerial[m];

	return 0;
}

/*

This method performs the calculations described in the tutorial as
the 'calculation method'.  It takes an input table and multiplies
it by a table that is always the same and stores the values.

*/
void calcCodeBase(BigInt constVals[], BigInt varVals[])
{
	BigInt secondHexNum(100000);
	secondHexNum = secondHexNum * BigInt(21474);
	secondHexNum = secondHexNum + BigInt(83903);

	BigInt firstHexNum(100000);
	firstHexNum = BigInt(21474) * firstHexNum;
	firstHexNum = firstHexNum + BigInt(83655);

	BigInt temp(0);
	int count = 1;
	int b = 0;
	int lengthInt = 0;

	int i=0;

	while(constVals[i] != BigInt(0x2A))
	{
		i++;
		lengthInt++;
	}

	lengthInt++;

	BigInt EAX(count);
	BigInt EDX(0);
	BigInt ECX(lengthInt);
	BigInt EDI(0);
	BigInt dataDL(0);

	int counter = 1;

	for(int k=0; k < 16; k++)
	{
		EAX = BigInt(counter);
		EDX = BigInt(0);

		EDX = EAX % ECX;
		EAX = EAX / ECX;

		for(b=0; BigInt(b)<EDX; b++)
			b=b;

		EAX = constVals[b];

		EDI = BigInt(count) & firstHexNum;

		dataDL = varVals[count];

		EAX = dataDL * EAX;

		EAX = EAX & secondHexNum;

		varVals[count] = EAX;

		count++;
		counter++;
		if(count == 8)
			count = 0;

		if(counter == lengthInt){
			counter = 0;
		}
	}

	// Figures out last 4 Characters
	BigInt partA(0);
	partA = varVals[6] % BigInt(0x10);
	BigInt partB(varVals[5]);
	BigInt partC(0);
	partC = varVals[4] / BigInt(0x10);

	// Makes sure that leading zeros are displayed
	finalSerial[16] = partA;
	finalSerial[17] = partB / BigInt(0x10);
	finalSerial[18] = partB % BigInt(0x10);
	finalSerial[19] = partC;
}
