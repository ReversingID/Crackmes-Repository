////////////////////////////////////////////////////////////
// lord_Phoenix - Crackme #9
// Keygen by jB
// Jan. 29, 2007
//
// SCOP, Euler's Tour
// Solved using Wansdorff's rule
//
// http://jardinezchezjb.free.fr / resrever@gmail.com
////////////////////////////////////////////////////////////

#include "all.h"
#include "scop.h"
#include "wansdorff.h"

DWORD hash32(LPBYTE lpData, UINT nDataLen)
{
	DWORD crc = ~0L;
	UINT i, j;
	for(i = 0; i < nDataLen; i++)
	{
		DWORD c = *lpData++;
		DWORD d;
		for(j = 0; j < 8; j++)
		{			
			d = c ^ crc;
			crc >>= 1;
			if(d & 1)
				crc ^= 0xEDB88320;
			c >>= 1;
		}
	}
	return ~crc;
}

createMovesArray(DWORD *moveArray)
{
	int i;
	int moves[BOARD_SIZE * BOARD_SIZE - 1];
	wansdorff(moves);

	for(i = 0; i < 4; i++)
		moveArray[i] = 0;
	moveArray[0] = (rand() << 16) | rand();
	for(i = 0; i < 8; i++)
	{
		moveArray[1] <<= 4;
		moveArray[2] <<= 4;
		moveArray[3] <<= 4;
		moveArray[1] |= moves[7 - i];
		moveArray[2] |= moves[15 - i];
		moveArray[3] |= moves[23 - i];
	}
}

DWORD WINAPI GenererSerial(HWND hwnd)
{
	TCHAR name[MAX_NAME];
	TCHAR serial[MAX_SERIAL];
	int i, j;
	DWORD knight_ops[4];
	DWORD crcName;
	
	if(GetDlgItemText(hwnd, IDC_NAME, name, MAX_NAME) < MIN_NAME)
	{
		SetDlgItemText(hwnd, IDC_SERIAL,"Please enter a longer name...");
		return FALSE;
	}
	createMovesArray(knight_ops);
	crcName = hash32(name, (unsigned int)strlen(name));
	for(i = 0; i < 4; i++)
		knight_ops[i] ^= crcName;
	init_key(name, (unsigned int)strlen(name));
	encrypt(knight_ops, 4, &kt);
	
	j = 0;
	for(i = 0; i < 16; i++)
		j += sprintf_s(serial + j, MAX_SERIAL - j, "%02X", ((BYTE *)knight_ops)[i]);

	SetDlgItemText(hwnd, IDC_SERIAL, serial);
	return TRUE;
}
