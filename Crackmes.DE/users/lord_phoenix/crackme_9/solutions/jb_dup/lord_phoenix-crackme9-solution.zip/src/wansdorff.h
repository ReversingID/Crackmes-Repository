#ifndef __WARNSDORFF_H__
#define __WARNSDORFF_H__

#define BOARD_SIZE	5
#define START_X		0
#define START_Y		0

void wansdorff(int *moves);
int getPlace(int pos);

#endif