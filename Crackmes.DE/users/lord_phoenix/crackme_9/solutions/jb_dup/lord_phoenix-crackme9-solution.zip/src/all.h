#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <stdlib.h>
#include "rsrc/resource.h"

#define PROGNAME "lord_Phoenix - Crackme #9"
#define MIN_NAME 4
#define MAX_NAME 48
#define MAX_SERIAL 33

