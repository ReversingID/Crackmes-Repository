#include "chessboard.h"

void DrawChessboard(HWND hWnd, BOOL bDrawMoves)
{
	static xSize, ySize;
	HWND hGraph;
	static RECT r;
	HDC hdcGraph, hdc;
	HBITMAP hBitmap;
	int i, j;
	POINT prevPos = {0, 0};

	// Get window dimension
	GetClientRect(GetDlgItem(hWnd, IDC_GRAPH), &r);
	xSize = r.right;
	ySize = r.bottom;

	// Create a memory device and a compatible bitmap
	hGraph = GetDlgItem(hWnd, IDC_GRAPH);
	hdcGraph = GetDC(hGraph);
	hdc = CreateCompatibleDC(hdcGraph);
	hBitmap = CreateCompatibleBitmap(hdcGraph, xSize, ySize);
	SelectObject(hdc, hBitmap);

	// Draw the chessboard
	for(i = 0; i < 5; i++)
	{
		for(j = 0; j < 5; j++)
		{
			RECT rc;
			rc.top = (LONG)((ySize / 5.) * i);
			rc.bottom = (LONG)((ySize / 5.) * (i+1));
			rc.left = (LONG)((xSize /5.) * j);
			rc.right = (LONG)((xSize / 5.) * (j + 1));
			if((5 * i + j) % 2 == 0)
				FillRect(hdc, &rc, (HBRUSH)WHITE_BRUSH);
			else FillRect(hdc, &rc, (HBRUSH)BLACK_BRUSH);
		}
	}

	// Draw the knight moves
	if(bDrawMoves)
	{
		HPEN hPen, hPenOld;
		HBRUSH hBrush, hBrushOld;
		int x, y;

		hPen = CreatePen(PS_SOLID, 2, RGB(251, 142, 0));
		hPenOld = SelectObject(hdc, hPen);
		hBrush = CreateSolidBrush(RGB(255, 255, 0));
		hBrushOld = SelectObject(hdc, hBrush);

		x = (int)(.5 * xSize / 5.);
		y = (int)(.5 * ySize / 5.);
		MoveToEx(hdc, x, y,	NULL);
		for(i = 0; i < 25; i++)
		{
			int j = 0;
			j = getPlace(i + 1);
			x = (int)((j / 5 + .5) * xSize / 5);
			y = (int)((j % 5 + .5)  * ySize / 5);
			LineTo(hdc, x, y);
		}
		SelectObject(hdc, hBrushOld);
		DeleteObject(hBrush);
		SelectObject(hdc, hPenOld);
		DeleteObject(hPen);
	}

	// Copy the memory device content to our window
	BitBlt(hdcGraph, 0, 0, xSize + 1, ySize + 1, hdc, 0, 0, SRCCOPY);
	DeleteObject(hBitmap);
	DeleteDC(hdc);		
	ReleaseDC(hGraph, hdcGraph);
}
