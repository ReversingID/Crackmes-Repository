Didn't bother writing any code ;)

I used my own dissasembler so the trick with fake javap output is kind of obvious, then just did a little spreadsheet for overflow values with (x *(-37)) + 42 == 1720653869 mod INT

answer = -975145735

crackme 2.1 looks nastier! :)