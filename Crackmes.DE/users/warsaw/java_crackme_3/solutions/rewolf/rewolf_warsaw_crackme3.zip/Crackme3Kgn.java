import java.util.*;
import java.math.*;

public class Crackme3Kgn 
{
	public static BigInteger egcd(BigInteger a, BigInteger b)
	{
		BigInteger u = BigInteger.ONE;
		BigInteger x = BigInteger.ZERO;
		BigInteger w = a;
		BigInteger z = b;

		while (w.compareTo(BigInteger.ZERO) != 0)
		{
			if (w.compareTo(z) < 0)
			{
				BigInteger t = u;
				u = x; x = t;
				t = w; w = z; z = t;
			}
			BigInteger q = w.divide(z);
			u = u.subtract( q.multiply(x) );
			w = w.subtract( q.multiply(z) );
		}
		if (x.compareTo(BigInteger.ZERO) < 0)
			x = x.add(b);

		return x;
	}	
	
	public static BigInteger charArrToBigInt(char[] charr, int size)
	{
		if (0 == size)
			size = charr.length;
		BigInteger ret = BigInteger.ZERO;
		for (int i = size - 1; i >= 0; i--)
		{
			ret = ret.multiply(new BigInteger("65536"));
			ret = ret.add(new BigInteger(Integer.toString(charr[i])));
		}
		return ret;
	}
		
	public static void main(String[] args) 
	{
		char[] output_c1 =
		{			/*   0       1       2       3       4       5       6       7       8       9 */
		/*   0 */	0x00D9, 0x00B9, 0x00B0, 0x0040, 0x0040, 0x0040, 0x006E, 0x0074, 0x0012, 0x00C2,
		/*  10 */	0x00E6, 0x00E8, 0x00DE, 0x00E4, 0x00CA, 0x00BE, 0x0060, 0x001A, 0x0014, 0x0040,
		/*  20 */	0x0040, 0x0040, 0x0070, 0x0074, 0x0012, 0x00D2, 0x00C6, 0x00DE, 0x00DC, 0x00E6,
		/*  30 */	0x00E8, 0x00BE, 0x0060, 0x001A, 0x0014, 0x0040, 0x0040, 0x0040, 0x0072, 0x0074,
		/*  40 */	0x0012, 0x00C2, 0x00C2, 0x00D8, 0x00DE, 0x00C2, 0x00C8, 0x001A, 0x0014, 0x0040,
		/*  50 */	0x0040, 0x0040, 0x0062, 0x0060, 0x0074, 0x0012, 0x00D2, 0x00DC, 0x00EC, 0x00DE,
		/*  60 */	0x00D6, 0x00CA, 0x00E6, 0x00E8, 0x00C2, 0x00E8, 0x00D2, 0x00C6, 0x0012, 0x0046,
		/*  70 */	0x0064, 0x006C, 0x0076, 0x0040, 0x005E, 0x005E, 0x009A, 0x00CA, 0x00E8, 0x00D0,
		/*  80 */	0x00DE, 0x00C8, 0x0040, 0x00D4, 0x00C2, 0x00EC, 0x00C2, 0x005E, 0x00D8, 0x00C2
		};		
	
		BigInteger bigC = charArrToBigInt(output_c1, 89);
		BigInteger bigIncor = charArrToBigInt("Incorrect!".toCharArray(), 0);
		BigInteger bigCor = charArrToBigInt("Correct!".toCharArray(), 0);
		
		BigInteger bigA = new BigInteger("" + Double.doubleToLongBits(1.112536929253537e-308));
		BigInteger bigB = new BigInteger("" + Double.doubleToLongBits(1.112536929253532e-308));
		
		BigInteger bigAB = bigA.multiply(bigB);		
		BigInteger big78 = new BigInteger("78");	//0x49 + 5
		
		BigInteger temp2 = bigCor.add(bigIncor).add(big78);		// ("Correct!"+ "Incorrect!" + 0x49 + 5)
		BigInteger serial = egcd(bigAB, bigC).multiply(temp2).multiply(bigAB).subtract(temp2).divide(bigC);
		
		BigInteger big10000 = new BigInteger("65536");
		while (serial.compareTo(BigInteger.ZERO) != 0)
		{
			System.out.print(String.format("%04X", serial.mod(big10000)));
			serial = serial.divide(big10000);
		}
	}
}