import com.sun.jdi.IntegerType;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/*
 * Answer v2 - the non brute force version.
 *
 * lab27 (for warsaw java crackme 2.1)
 *
 * Answer =  -3279289298764909349
 *
 * stimpy:crackmes$ java -jar crackme2.1.jar -3279289298764909349
 * Correct!
 *
 *
 *
 * Things which are interesting about the crackme
 *
 * Constants hidden in ConstantValue attributes
 * Impossible names
 * JSR for control flow
 * exceptions for control flow
 * Unextractable jar due to overlong filename.
 * magic kept in stateful static.
 *
 * I've tidied up the original function to remove the obfuscated +64 loop - this was just 64 * low 5 bits of arg.
 *
 */
public class Warsaw2crackNonBrute {

    public static void main(String [] arg) {
        long val = 0xD27D9FC1D760B4DBL;      // -3279289298764909349

        // The original puzzle has a stateful static which starts out at 'question', and is
        // decremented by 'subtract' each time.   We're going to use these to reverse the answer, so
        // we compute them outside of the function, to make it stateless.
        int question = 1161407507;
        int subtract = 895940907;

        int question1 = question - subtract;    // 265466600
        int question2 = question1 - subtract;

        // verify answer.
        System.out.println("FWIW, known answer = ");
        System.out.println(val + " == " + Long.toHexString(val));
        System.out.println("Test high " + test((int)(val >>> 32), question1));
        System.out.println("Test low  " + test((int)val, question2));

        int high = reverse_test(question1);
        int low  = reverse_test(question2);

        System.out.println(Integer.toHexString(high) + Integer.toHexString(low));

        System.out.println((test(high, question1) == 0 && test(low, question2) == 0) ? "Correct" : "Incorrect");

    }



    // This is the inverse of the function 'test'.
    //
    // The bitwise logic is a pain to work through, but it's there ;)
    // The only really ugly bit
    // is inverting v37a = v30 + (v30 << 4) in the presence of overflow
    // - we have to do it nybble by nybble.
    public static int reverse_test(int question) {

        // return ((v46 ^ (v46 >>> 16)) ^ question);   --->
        // question = v46 ^ (v46 >>> 16);
        int v46r = (question & 0xffff0000) | ( (question >>> 16) ^ (question & 0xffff));
        int cr = ((v46r >>> 27) << 6);
        int v37r = ((v46r ^ (cr << 21)) << 5) | 0x8; // 8 as we KNOW the lower 5 bits in v37
        int v37ar = v37r - 1337;

        int mask = 0xf;
        int maskoff = 0;
        // There's probably an easier way to solve v37 = v30 + (v30 << 4) with overflow, but
        // I'm not thinking right now ;)
        boolean carry = false;
        int last = 0;
        int v30r = 0;

        for (int x=0;x<8;++x, maskoff+=4, mask <<= 4) {
            int thisival = ((v37ar & mask) >>> (maskoff));
            if (carry) thisival--;

            if (thisival < last) {
                // must be a carry.
                thisival += 0x10;
                carry = true;
            } else {
                carry = false;
            }
            int add = thisival - last;
            last = add;
            v30r |= (add << maskoff);
        }
        //  int v30 = ((c + b) | 31)   -->    (v30 & ~31) - c = b
        int br = (v30r & ~31) - cr;
        int ar = cr >>> 6;

        int stackval_0r = ar | br;
        return stackval_0r;
    }


    /*
     * This is a reimplementation of the original function, however I've simplified it
     * to remove the looping and the exception handling.
     */
    public static int test(int stackval_0, int question) {
        // stackval_1 = 64 * low 5 bits of stackval_0.
        int a = stackval_0 & 31;
        int b = stackval_0 & ~31;

        int stackval_1 = a << 6;
        int v30 = ((stackval_1 + b) | 31);
        int v37 = ((v30 + (v30 << 4)) + 1337);
        int v46 = ((v37 >>> 5) ^ (stackval_1 << 21));
        return ((v46 ^ (v46 >>> 16)) ^ question);
    }

    /*

    This is what the original function looked like.

    In my code above, I've called decode.?? "question"
    and wwwww.wwwwww "subtract"

    public static final synchronised int (I)I(int stackval_0)
{
    stackval_1 = 5;
    try {
        decode.?? = (decode.?? - wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww.wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww);
        ** GOTO lbl12
lbl5: // 1 sources:
        // -ve array sizing makes this loop exit via an exception handler.
        v60 = (new int[(v60 % 2)].length + (v60 + v60));
        ** GOTO lbl14
    }
    catch (java/lang/Throwable v25) {
        v30 = ((stackval_1 + stackval_0) | 31);
        v37 = ((v30 + (v30 << 4)) + 1337);
        v46 = (((v37 | v37) >>> 5) ^ (stackval_1 << 21));
        return ((v46 ^ (v46 >>> 16)) ^ decode.??);
    }
lbl12: // 1 sources:
    stackval_1 = -64;
    v60 = (-1 >>> stackval_0);
lbl14: // 2 sources:
    stackval_1 = (stackval_1 + 64);
    ** GOTO lbl5
}

     */
}
