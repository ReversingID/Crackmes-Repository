CrackMe #5 by m@[tador]

Compiler: Delphi 6.0
Packer: N/A

1. Find valid Name/Serial pair.
2. Write keygen (or selfkeygen if you can).

Patching not allowed.

Good luck!
