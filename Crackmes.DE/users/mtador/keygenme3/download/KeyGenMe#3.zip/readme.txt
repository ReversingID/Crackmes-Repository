KeyGenMe #3

Autor: m@[tador]
Date: 3 Dec 2005

Platform: Windows
Compiler: Delphi 6.0. (no VCL, Win32API only)
Packer: No
Level: 2 (No so hard)
Protection: there is some crazy debug protection

Patching: Not allowed
KeyGenerator: This is the target.

Hope you'l enjoy!
