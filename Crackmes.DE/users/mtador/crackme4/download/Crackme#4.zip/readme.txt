CrackMe #4 by m@[tador]

1. Find valid Name/Serial pair.
2. Write keygen (or selfkeygen if you can).

Patching not allowed.

Good luck!
