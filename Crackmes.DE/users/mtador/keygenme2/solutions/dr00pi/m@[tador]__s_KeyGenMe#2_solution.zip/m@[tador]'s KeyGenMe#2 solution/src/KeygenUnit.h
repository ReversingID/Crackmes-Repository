//---------------------------------------------------------------------------

#ifndef KeygenUnitH
#define KeygenUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TFormKeygen : public TForm
{
__published:	// IDE-managed Components
        TEdit *EditName;
        TEdit *EditSerial;
        TButton *ButtonGenerate;
        TButton *ButtonExit;
        void __fastcall ButtonExitClick(TObject *Sender);
        void __fastcall ButtonGenerateClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TFormKeygen(TComponent* Owner);
        AnsiString Name;
        AnsiString Serial;
        unsigned int character;
        unsigned intDiv;
};
//---------------------------------------------------------------------------
extern PACKAGE TFormKeygen *FormKeygen;
//---------------------------------------------------------------------------
#endif
