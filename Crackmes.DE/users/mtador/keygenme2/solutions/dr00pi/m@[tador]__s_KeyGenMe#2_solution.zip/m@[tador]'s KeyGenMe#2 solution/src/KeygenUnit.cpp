//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "KeygenUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFormKeygen *FormKeygen;
//---------------------------------------------------------------------------
__fastcall TFormKeygen::TFormKeygen(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFormKeygen::ButtonExitClick(TObject *Sender)
{
        Application->Terminate();        
}
//---------------------------------------------------------------------------
void __fastcall TFormKeygen::ButtonGenerateClick(TObject *Sender)
{
        Name = EditName->Text;
        Serial = "";
        intDiv = Name.Length()/3;
        for (int j=1; j<=Name.Length();j++) {
                character = unsigned(Name[j]);
                Serial += char( (character^intDiv)+(5*j)-j );
        }
        EditSerial->Text = Serial;
}
//---------------------------------------------------------------------------
