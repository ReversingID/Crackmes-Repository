Autor: m@[tador]
Date: 25 November 2005

Platform: Windows
Compiler: Delphi 6.0. (no VCL, Win32API only)
Packer: No
Level: 2 (No so hard)

Patching: Not allowed
KeyGenerator: This is the target.

Hope you'l enjoy!
