// keygen for yyyyyyy's yyyyyyy1
// http://crackmes.de/users/yyyyyyy/yyyyyyy1/

// Compile with
// gcc -Wall -Wextra -Werror -pedantic -ansi -std=c99 -O3 keygen.c
// the only requisite flag is -std=c99

// The serial is made of 16 character between '!' and 'z'.
// The expected first character is computed from the 15 others.
// The keygen picks randomly 15 correct characters.
// Then, it computes the expected character.
// If it is not a correct character, it just replays.

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
char firstchar(char serial[16])
{
	unsigned long ebx = 0;
	char* esi = serial+1;
	for (char ecx = 15; ecx; ecx--, esi++)
	        ebx = ~((ebx ^ *esi) + 0x2a)-1;
	return ebx;
}
int main()
{
	srand(time(NULL));
	char serial[17];
	serial[16] = 0;
	while (1)
	{
		for (int i = 1; i < 16; i++)
			serial[i] = '!' + (rand() % ('z' - '!'));
		char c = firstchar(serial);
		if ('!' <= c && c <= 'z')
		{
			serial[0] = c;
			break;
		}
	}
	printf("%s\n", serial);
	return 0;
}
