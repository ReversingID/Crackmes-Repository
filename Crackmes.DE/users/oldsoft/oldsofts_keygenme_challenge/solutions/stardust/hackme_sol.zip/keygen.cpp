#include <cstdlib>
#include <iostream>

using namespace std;

#define KGEN_3(x) (x ^ 0x23)

int main(int argc, char *argv[])
{
    int code;
    char dummystring[20];   
    char user[50];
    char company[50];
    char serial[200];
    int arg_0,i,dummy_val,number1,number2;    
        
    printf("User:");
    scanf("%s",&user);
    printf("Company:");
    scanf("%s",&company);
    
    strcpy(serial,"C");     //Start character
    
    number1=KGEN_3(0x19f)+strlen(user);
    number2=KGEN_3(0x1A8)+strlen(company);
    arg_0=(number1*number2) & 0xffff;   //word-Range 
    
    code=((strlen(company)*arg_0*0x148) ^ strlen(user)) & 0xffff; //word-Range
    
    if (code>0x7fff) code-= 0x10000; //negative number in word-Range
    itoa(code,dummystring,10);
    strcat(serial,dummystring);

    dummy_val=(user[strlen(user)-1]+number1) ^ (KGEN_3(arg_0)*0x20D);
	code=(((KGEN_3(0x160)*strlen(user)) ^ dummy_val)+(arg_0*arg_0)) & 0xffff;

    if (code>0x7fff) code-= 0x10000; //negative number in word-Range
    itoa(code,dummystring,10);
    strcat(serial,dummystring);
	
	for (i=0;i<strlen(company);i++)
	{
        code=(strlen(company)*arg_0+((company[i]+arg_0) ^ KGEN_3(arg_0))) & 0xffff;
        
        if (code>0x7fff) code-= 0x10000; //negative number in word-Range
        itoa(code,dummystring,10);
        strcat(serial,dummystring);
    }

    printf("%s\n",serial);
    
        system("PAUSE");
    return EXIT_SUCCESS;
}
