OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
|OldSoft's KeyGenMe Challenge|
OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO


This is a little KeyGenMe app.
It's hard, because the key is freeform.

You must make a keygen, or a patch. I allow both, because key is so long (40+ chars)

OldSoft