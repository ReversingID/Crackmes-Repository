#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    FILE *pFile; 
    char name[21],name_len;
    int i,v_104,v_106;
    long checksum[3];
    
    for(i=0;i<21;i++) name[i]=0;   //Init to Zeros (not neccessary)
    printf("Enter a Name (5 to 20 characters):");
    scanf("%20s",&name);
    name_len=strlen(name);
    
    v_104=name_len+7;     //Init Checksum1
    v_106=0x0fff;         //Init Checksum1
    
    for(i=0;i<name_len;i++)      //Calculate Checksum
    {
      v_104=((v_104+name[i])^0x2BC)^(v_106/7);
      v_106-=(i+1)+0x2A;
      if(v_106<0xbff) v_106+=0xa00;                                                
    }
    
    checksum[0]=v_104;
    checksum[1]=v_106;
    checksum[2]=v_106-v_104+0xff-name_len;
    
    pFile=fopen("reg.key","w");
    fwrite(&name_len,1,1,pFile);
    fwrite(name,1,20,pFile);
    fwrite(checksum,4,3,pFile);
    fclose(pFile);
    system("PAUSE");
    return EXIT_SUCCESS;
}
