package org.ebfe.cm.rolling;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.Vector;


public class Keygen {
	
	public static void main(String[] args) throws Exception {
		Keygen kg = new Keygen();
		File file = new File("key.rol");
		
		System.out.println("generating " + file.getAbsolutePath());		
		generateKey(file);
	}

	public static void generateKey(File file) throws Exception {
		int key[] = new int[0x87a23];
		Random rand = new Random(System.currentTimeMillis());
				
		key[0] = 121;
		key[1] = 121 + rand.nextInt(255-121);
		for (int i = 2; i < key.length; i++) {
			key[i] = rand.nextInt(0x100);
		}
	
		FileOutputStream fos = new FileOutputStream(file);
		for(int i : key) {
			fos.write(i);
		}
		fos.close();
	}
}
