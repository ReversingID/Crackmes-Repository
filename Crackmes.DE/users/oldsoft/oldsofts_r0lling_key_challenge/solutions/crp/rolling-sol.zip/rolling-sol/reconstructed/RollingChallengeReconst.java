// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) disassembler
// Source File Name:   RollingChallenge.java

import java.io.FileInputStream;
import java.io.PrintStream;

public class RollingChallengeReconst {
	
	public static int a[];
	public static FileInputStream b;
	public static int c;
	public static boolean d;
	public static boolean e;
	private static String B[];
	
	public RollingChallengeReconst() {
	}
	
	public static int a(int i) {
		int local1;
		//    0    0:iload_0
		//    1    1:istore_1
		local1 = i;
		do {
			//    2    2:iinc            1  -12
			local1 -= 12;
			//    3    5:iload_1
			//    4    6:sipush          254
			//    5    9:icmpgt          2
		} while(local1 > 254);
		
		//    6   12:iload_1
		// <editor-fold defaultstate="collapsed" desc="junk"> 
		//    7   13:getstatic       #88  <Field boolean e>
		//    8   16:ifne            6
		// </editor-fold>    
		//    9   19:ireturn
		return local1;
	}
	
	
	public static boolean a_cleaned_up() {
		int     magic;
		magic = 0;

		for(int index = 2; index < a.length; index++) {

			if(index > 0x30d40 && index < 0x61a80) {
				a[index] |= a[index] / 3;
			}

			magic += a(a[index]);

			if(a[index] == 0) {
				magic = 0;
			}
			
			if(a[index] > 200) {
				magic += 2;
			}
			magic++;
		}
		
		do {	
			magic = 121;
		} while(magic > a[1]);
		
		if(magic != a[0]) {
			return false;
		}
		return true;
	}
	
	
	public static boolean a() {
		boolean local4;
		int     local0, local1, local2, local3;
		
		//    0    0:getstatic       #88  <Field boolean e>
		//    1    3:istore          4
		local4 = e;
		//    2    5:iconst_0
		//    3    6:istore_0
		local0 = 0;
		//    4    7:iconst_0
		//    5    8:istore_1
		local1 = 0;
		//    6    9:iconst_2
		//    7   10:istore_2
		local2 = 2;
		//    8   11:iload_2
		//    9   12:getstatic       #2   <Field int[] a>
		//   10   15:arraylength
		//   11   16:icmpge          169
		while(local2 < a.length) {
			//   12   19:iload_2
			//   13   20:ldc1            #3   <Int 0x30d40>
			// <editor-fold defaultstate="collapsed" desc="junk"> 
			//   14   22:iload           4
			//   15   24:ifne            182
			if(local4)
				;//goto 182


			//   16   27:iload           4
			//   17   29:ifne            70
			if(local4)
				;//goto 70
			// </editor-fold>    
			//   18   32:icmple          61
			//   19   35:iload_2
			//   20   36:ldc1            #4   <Int 0x61a80>
			// <editor-fold defaultstate="collapsed" desc="junk"> 
			//   21   38:iload           4
			//   22   40:ifne            70
			if(local4)
				; //goto 70
			// </editor-fold> 
			//   23   43:icmpge          61
			if(local2 > 0x30d40 && local2 < 0x61a80) {
				//   24   46:getstatic       #2   <Field int[] a>
				//   25   49:iload_2
				//   26   50:dup2
				//   27   51:iaload
				//   28   52:getstatic       #2   <Field int[] a>
				//   29   55:iload_2
				//   30   56:iaload
				//   31   57:iconst_3
				//   32   58:idiv
				//   33   59:ior
				//   34   60:iastore
				a[local2] |= a[local2] / 3;
			}
			//   35   61:iload_0
			//   36   62:getstatic       #2   <Field int[] a>
			//   37   65:iload_2
			//   38   66:iaload
			//   39   67:invokestatic    #5   <Method int a(int)>
			//   40   70:iadd
			//   41   71:istore_0
			local0 = a(a[local2]) + local0;

			//   42   72:getstatic       #2   <Field int[] a>
			//   43   75:iload_2
			//   44   76:iaload
			// <editor-fold defaultstate="collapsed" desc="junk"> 
			//   45   77:iload           4
			//   46   79:ifne            92
			if(local4)
				; //goto 92
			// </editor-fold> 
			//   47   82:ifne            87
			if(a[local2] == 0) {
				//   48   85:iconst_0        
				//   49   86:istore_0  
				local0 = 0;
			}

			//   50   87:getstatic       #2   <Field int[] a>
			//   51   90:iload_2
			//   52   91:iaload
			// <editor-fold defaultstate="collapsed" desc="junk">
			//   53   92:iload           4
			//   54   94:ifne            107
			if(local4)
				; // goto 107
			// </editor-fold> 
			//   55   97:sipush          200
			//   56  100:icmple          106
			if(a[local2] > 200) {
				//   57  103:iinc            0  2
				local0 += 2;
			}

			//   58  106:iload_2
			// <editor-fold defaultstate="collapsed" desc="junk">
			//   59  107:iload           4
			//   60  109:ifne            128
			if(local4)
				; // goto 128
			// </editor-fold> 
			//   61  112:ifle            161
			while(local2 > 0) {
				//   62  115:iinc            0  1
				local0++;
				// <editor-fold defaultstate="collapsed" desc="junk">
				//   63  118:iload           4
				//   64  120:ifne            164
				if(local4)
					; //goto 164
				// </editor-fold> 
				//   65  123:getstatic       #2   <Field int[] a>
				//   66  126:iload_2
				//   67  127:iaload
				//   68  128:sipush          324
				//   69  131:icmplt          161
				if(a[local2] < 324)
					break;		// always true

				//   70  134:getstatic       #2   <Field int[] a>
				//   71  137:iload_2
				//   72  138:iconst_1
				//   73  139:isub
				//   74  140:iaload
				//   75  141:bipush          32
				//   76  143:isub
				//   77  144:istore_3
				local3 = a[local2-1] - 32;
				// <editor-fold defaultstate="collapsed" desc="junk">
				//   78  145:iload           4
				//   79  147:ifne            164
				if(local4)
					;//goto 164
				// </editor-fold> 
				//   80  150:iload_3
				//   81  151:getstatic       #2   <Field int[] a>
				//   82  154:iload_2
				//   83  155:iaload
				//   84  156:icmpeq          161
				if(local3 != a[local2]) {
					//   85  159:iconst_0
					//   86  160:ireturn
					return false;
				}
				break;
			}

			//   87  161:iinc            2  1
			local2++;

			//   88  164:iload           4
			//   89  166:ifeq            11
			if(local4)
				;//goto 11
		}
		
		do {	
			//   90  169:iload_0
			//   91  170:iload_0
			//   92  171:bipush          121
			//   93  173:isub
			//   94  174:isub
			//   95  175:istore_0
			local0 = local0 - local0 - 121;
			
			//   96  176:iload_0
			//   97  177:getstatic       #2   <Field int[] a>
			//   98  180:iconst_1
			//   99  181:iaload
			//  100  182:icmpgt          169
		} while(local0 > a[1]);
		
		//  101  185:getstatic       #2   <Field int[] a>
		//  102  188:iconst_0
		//  103  189:iaload
		// <editor-fold defaultstate="collapsed" desc="junk">
		//  104  190:iload           4
		//  105  192:ifne            207
		if(local4)
			; //goto 207
		// </editor-fold> 
		//  106  195:iload_0
		// <editor-fold defaultstate="collapsed" desc="junk">
		//  107  196:iload           4
		//  108  198:ifne            182
		if(local4)
			; // goto 182
		// </editor-fold> 
		//  109  201:icmpeq          206
		if(local0 != a[0]) {
			//  110  204:iconst_0
			//  111  205:ireturn
			return false;
		}
		
		//  112  206:iconst_1
		// <editor-fold defaultstate="collapsed" desc="junk">		
		//  113  207:getstatic       #90  <Field boolean d>
		//  114  210:ifeq            226
		//  115  213:iload           4
		//  116  215:ifeq            222
		//  117  218:iconst_0
		//  118  219:goto            223
		//  119  222:iconst_1
		//  120  223:putstatic       #88  <Field boolean e>
		if(d) {
			if(!local4)
				e = true;
			else 
				e = false;
		}
		// </editor-fold> 		
		//  121  226:ireturn
		return true;
	}
	
	public static boolean b() {
		try {
			FileInputStream fis = new FileInputStream(B[5]);
			int i = 0;
			while(i < a.length) {
				a[i] = fis.read();
				i++;
			}
		} catch (Exception e) {
			return false;
		}
		return true;
	}
	
	public static void main(String args[]) {
		boolean keyfileRead, keyfileValid;
		
		System.out.println(B[1]);	// "Welcome to OldSofts R0lling Key Challenge!"
		System.out.println(B[3]);	// "You must make a valid keyfile, to success!"
		System.out.print(B[0]);		// "Checking key.""
		keyfileRead = b();		// load keyfile
		System.out.print(".");
		keyfileValid = a_cleaned_up();		// verify keyfile
		System.out.print(".");
		System.out.println(" ");
		
		if(keyfileRead && keyfileValid) {
			System.out.println(B[2]);	// "Good Job! You made it!"
		} else {
			System.out.println(B[4]);	// "Keyfile invalid! Try again :)"
		}
	}
	
	private static String strdecode(String str) {
		char key[] = { 14, 62, 43, 98, 76};
		char ca[] = str.toCharArray();
		for(int i = 0; i < ca.length; i++) {
			ca[i] ^= key[i % key.length];
		}
		return new String(ca);
	}
	
	static
	{
		//    0    0:bipush          6
		//    1    2:anewarray       String[]
		B = new String[6];
		//    2    5:dup
		//    3    6:iconst_0
		//    4    7:ldc1            #17  <String "MVN\001'gPLB'kG\005">
		//    5    9:jsr             59
		//    6   12:aastore
		B[0] = strdecode("MVN\001'gPLB'kG\005");
		//    7   13:dup
		//    8   14:iconst_1
		//    9   15:ldc1            #14  <String "Y[G\001#c[\013\026#.qG\006\037aX_\021l\\\016G\016%`Y\013))w\036h\n-bRN\f+k\037">
		//   10   17:jsr             59
		//   11   20:aastore
		B[1] = strdecode("Y[G\001#c[\013\026#.qG\006\037aX_\021l\\\016G\016%`Y\013))w\036h\n-bRN\f+k\037");
		//   12   21:dup
		//   13   22:iconst_2
		//   14   23:ldc1            #24  <String "IQD\006lDQIClWQ^B!oZNB%z\037">
		//   15   25:jsr             59
		//   16   28:aastore
		B[2] = strdecode("IQD\006lDQIClWQ^B!oZNB%z\037");
		//   17   29:dup
		//   18   30:iconst_3
		//   19   31:ldc1            #16  <String "WQ^B!{M_B!oUNB-.HJ\016%j\036@\0075hWG\007`.JDB?{]H\007?}\037">
		//   20   33:jsr             59
		//   21   36:aastore
		B[3] = strdecode("WQ^B!{M_B!oUNB-.HJ\016%j\036@\0075hWG\007`.JDB?{]H\007?}\037");
		//   22   37:dup
		//   23   38:iconst_4
		//   24   39:ldc1            #23  <String "E[R\004%b[\013\013\"x_G\013(/\036\177\0205._L\003%`\036\021K">
		//   25   41:jsr             59
		//   26   44:aastore
		B[4] = strdecode("E[R\004%b[\013\013\"x_G\013(/\036\177\0205._L\003%`\036\021K");
		//   27   45:dup
		//   28   46:iconst_5
		//   29   47:ldc1            #7   <String "e[RL>aR">
		//   30   49:jsr             59
		//   31   52:aastore
		B[5] = strdecode("e[RL>aR");
		//   32   53:putstatic       #110 <Field String[] B>
		//   33   56:goto            157
		//
		// start of strdecoder see strdecode();
		//
		//   34   59:astore_0
		//   35   60:invokevirtual   #99  <Method char[] String.toCharArray()>
		//   36   63:dup
		//   37   64:arraylength
		//   38   65:swap
		//   39   66:iconst_0
		//   40   67:istore_1
		//   41   68:goto            136
		//   42   71:dup
		//   43   72:iload_1
		//   44   73:dup2
		//   45   74:caload
		//   46   75:iload_1
		//   47   76:iconst_5
		//   48   77:irem
		//   49   78:tableswitch     0 3: default 128
		//                   0 108
		//                   1 113
		//                   2 118
		//                   3 123
		//   50  108:bipush          14
		//   51  110:goto            130
		//   52  113:bipush          62
		//   53  115:goto            130
		//   54  118:bipush          43
		//   55  120:goto            130
		//   56  123:bipush          98
		//   57  125:goto            130
		//   58  128:bipush          76
		//   59  130:ixor
		//   60  131:int2char
		//   61  132:castore
		//   62  133:iinc            1  1
		//   63  136:swap
		//   64  137:dup_x1
		//   65  138:iload_1
		//   66  139:icmpgt          71
		//   67  142:new             #93  <Class String>
		//   68  145:dup_x1
		//   69  146:swap
		//   70  147:invokespecial   #103 <Method void String(char[])>
		//   71  150:invokevirtual   #108 <Method String String.intern()>
		//   72  153:swap
		//   73  154:pop
		//   74  155:ret             0
		//
		//
		//
		//   75  157:ldc1            #25  <Int 0x87a23>
		//   76  159:newarray        int[]
		//   77  161:putstatic       #2   <Field int[] a>
		a = new int[0x87a23];
		//   78  164:iconst_0
		//   79  165:putstatic       #26  <Field int c>
		c = 0;
		//   80  168:return
	}
}
