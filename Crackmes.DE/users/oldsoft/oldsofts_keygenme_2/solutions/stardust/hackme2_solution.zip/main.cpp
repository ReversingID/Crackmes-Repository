#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    char name[51];  //Just limit to 50 characters, not necessary
    int check1, check2;
    
    printf("Enter a Name (5 to 50 characters):");
    scanf("%50s",&name);

    check1=0;    
    for(int i=1;i<=strlen(name);i++) check1+=name[i-1]+i+3;
    check2=(strlen(name)>>1)*3+strlen(name);

    printf("%d-%d\n",check2,check1);
    system("PAUSE");
    return EXIT_SUCCESS;
}
