[K2] - CrackMe (KeygenME) written by Aleksandar Ruzicic a.k.a krckoorascic

|--[ CodeName: [K2]
|	|--[ Version: 2.00.0008
|	|--[ Compiler: VB6 + SP6
|	|--[ Compile Date: 3/30/05
|--[ Objective:
|	|--[ Unpack
|	|--[ Kill NAG!
|	|--[ Enable check button
|	|--[ Write WORKING keygen
|	|--[ Write tutorial
|--[ Extra: EasterEgg, try to find it ;o)


RULEZ:
You have to write (WORKING) keygen for this, NO patching alowed, just simple keygenerator...
You can send keygens (and tutorials) to krckoorascic@gmail.com (if you want)

Greetz:
[ES] members, [Ded4], Ice...

