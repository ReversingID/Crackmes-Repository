I don't know how difficult it is, but i believe it's not obvious and a little bit tricky one.
The best solution must be the name/key pair.
And, this one wants a lot of your resources, so you better don't try to solve it while running something else :)
/*I guess, that with everything closed it must be ok everywhere - it worked correct even on the old 633Mhz Celeron*/

So, as it is said, close all other programs and crack it! ;)
Good luck!

Cheers,
vptrlx.