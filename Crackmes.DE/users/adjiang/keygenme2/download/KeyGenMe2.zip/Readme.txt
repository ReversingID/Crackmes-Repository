KeyGenMe2 by Adjiang Include License.dat
Hi all cracker,i just make my new keygenme!
Rules:
1.Find a valid serial.
2.No Patching and Brute Force is allowed.
3.Enjoy:)
Keygen it and send your solution at slzeagle@hotmail.com

Best Regards
Adjiang