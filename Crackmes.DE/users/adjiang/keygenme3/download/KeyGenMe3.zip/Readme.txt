KeyGenMe3 by Adjiang
Mission Objectives:
1.Find a valid serial.
2.No Patching and Brute Force is allowed.
3.Enjoy:)
Keygen it and send your solution at slzeagle@hotmail.com

Best Regards
Adjiang