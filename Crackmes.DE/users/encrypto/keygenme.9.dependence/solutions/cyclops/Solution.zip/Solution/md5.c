
//[Cyclops]
//modded
//Enc's 9
#include<stdio.h>

#ifndef uint8
#define uint8  unsigned char
#endif

#ifndef uint32
#define uint32 unsigned long int
#endif

#define BSWAP(x) \
     ((((x) & 0xff000000) >> 24) | (((x) & 0x00ff0000) >>  8) | \
      (((x) & 0x0000ff00) <<  8) | (((x) & 0x000000ff) << 24))

#define ROL(x, n)       (((x) << (n)) | ((x) >> (32-(n))))
#define ROR(x, n)		(((x) << (32-(n))) | ((x) >> (n)))

unsigned long md5_s1=0x9D230ADE,md5_s2=0x13908DAD,md5_s3=0x0DADC0DEA,md5_s4=0x0BADC0DEA;

typedef struct
{
    uint32 total[2];
    uint32 state[4];
    uint8 buffer[64];
}
md5_context;
#define GET_UINT32(n,b,i)                       \
{                                               \
    (n) = ( (uint32) (b)[(i)    ]       )       \
        | ( (uint32) (b)[(i) + 1] <<  8 )       \
        | ( (uint32) (b)[(i) + 2] << 16 )       \
        | ( (uint32) (b)[(i) + 3] << 24 );      \
}

#define PUT_UINT32(n,b,i)                       \
{                                               \
    (b)[(i)    ] = (uint8) ( (n)       );       \
    (b)[(i) + 1] = (uint8) ( (n) >>  8 );       \
    (b)[(i) + 2] = (uint8) ( (n) >> 16 );       \
    (b)[(i) + 3] = (uint8) ( (n) >> 24 );       \
}

void md5_starts( md5_context *ctx )
{
    ctx->total[0] = 0;
    ctx->total[1] = 0;

    ctx->state[0] = md5_s1;
    ctx->state[1] = md5_s2;
    ctx->state[2] = md5_s3;
    ctx->state[3] = md5_s4;
}

void md5_process( md5_context *ctx, uint8 data[64] )
{
    uint32 X[16], A, B, C, D;

    GET_UINT32( X[0],  data,  0 );
    GET_UINT32( X[1],  data,  4 );
    GET_UINT32( X[2],  data,  8 );
    GET_UINT32( X[3],  data, 12 );
    GET_UINT32( X[4],  data, 16 );
    GET_UINT32( X[5],  data, 20 );
    GET_UINT32( X[6],  data, 24 );
    GET_UINT32( X[7],  data, 28 );
    GET_UINT32( X[8],  data, 32 );
    GET_UINT32( X[9],  data, 36 );
    GET_UINT32( X[10], data, 40 );
    GET_UINT32( X[11], data, 44 );
    GET_UINT32( X[12], data, 48 );
    GET_UINT32( X[13], data, 52 );
    GET_UINT32( X[14], data, 56 );
    GET_UINT32( X[15], data, 60 );

#define S(x,n) ((x << n) | ((x & 0xFFFFFFFF) >> (32 - n)))

#define P(a,b,c,d,k,s,t)                                \
{                                                       \
    a += F(b,c,d) + X[k] + t; a = S(a,s) + b;           \
}

    A = ctx->state[0];
    B = ctx->state[1];
    C = ctx->state[2];
    D = ctx->state[3];

#define F(x,y,z) (z ^ (x & (y ^ z)))

    P( A, B, C, D,  0,  7, 0xA76AA478 );
    P( D, A, B, C,  1,  9, 0xE847B756 );
    P( C, D, A, B,  2, 17, 0x24B070DB );
    P( B, C, D, A,  3, 18, 0xDEADC0DE );
    P( A, B, C, D,  4,  3, 0xF57B0FAF );
    P( D, A, B, C,  5, 12, 0xFADEC0DE );
    P( C, D, A, B,  6, 17, 0x0EEDFADE );
    P( B, C, D, A,  7, 22, 0xFD469F01 );
    P( A, B, C, D,  8,  7, 0x698A98D8 );
    P( D, A, B, C,  9, 12, 0x8B4AF7AF );
    P( C, D, A, B, 10, 20, 0xFFFC5BB1 );
    P( B, C, D, A, 11, 22, 0x895CDEBE );
    P( A, B, C, D, 12,  7, 0x6B901F22 );
    P( D, A, B, C, 13, 12, 0xFB987193 );
    P( C, D, A, B, 14, 17, 0xA67D438E );
    P( B, C, D, A, 15, 22, 0x49BE0821 );

#undef F

#define F(x,y,z) (y ^ (z & (x ^ y)))

    P( A, B, C, D,  1,  5, 0xF61E2C62 );
    P( D, A, B, C,  6,  9, 0xCA40B340 );
    P( C, D, A, B, 11, 14, 0x265E5A51 );
    P( B, C, D, A,  0, 20, 0xE9B6C7AA );
    P( A, B, C, D,  5,  5, 0xD62F105D );
    P( D, A, B, C, 10,  9, 0x02441453 );
    P( C, D, A, B, 15, 14, 0xD8A1E681 );
    P( B, C, D, A,  4, 20, 0xE7D3FBC8 );
    P( A, B, C, D,  9,  5, 0x21E1CDE6 );
    P( D, A, B, C, 14,  9, 0xC33707D6 );
    P( C, D, A, B,  3, 14, 0xF4D50D87 );
    P( B, C, D, A,  8, 20, 0x455A14ED );
    P( A, B, C, D, 13,  5, 0xA9E3E905 );
    P( D, A, B, C,  2,  9, 0xFCEFA3F8 );
    P( C, D, A, B,  7, 14, 0x676F02D9 );
    P( B, C, D, A, 12, 20, 0x8D2A4C8A );

#undef F

#define F(x,y,z) (x ^ y ^ z)

    P( A, B, C, D,  5,  4, 0xFFFA3942 );
    P( D, A, B, C,  8, 11, 0x8771F681 );
    P( C, D, A, B, 11, 16, 0x6D9D6122 );
    P( B, C, D, A, 14, 23, 0xFDE5380C );
    P( A, B, C, D,  1,  4, 0xA4BEEA44 );
    P( D, A, B, C,  4, 11, 0x4BDECFA9 );
    P( C, D, A, B,  7, 16, 0xF6BB4B60 );
    P( B, C, D, A, 10, 23, 0xBEBFBC70 );
    P( A, B, C, D, 13,  4, 0x289B7EC6 );
    P( D, A, B, C,  0, 11, 0xEAA127FA );
    P( C, D, A, B,  3, 16, 0xD4EF3085 );
    P( B, C, D, A,  6, 23, 0x04881D05 );
    P( A, B, C, D,  9,  4, 0xD9D4D039 );
    P( D, A, B, C, 12, 11, 0xE6DB99E5 );
    P( C, D, A, B, 15, 16, 0x1FA27CF8 );
    P( B, C, D, A,  2, 23, 0xC4AC5665 );

#undef F

#define F(x,y,z) (y ^ (x | ~z))

    P( A, B, C, D,  0,  6, 0xF4292244 );
    P( D, A, B, C,  7, 10, 0x432AFF97 );
    P( C, D, A, B, 14, 15, 0xAB9423A7 );
    P( B, C, D, A,  5, 21, 0xFC93A039 );
    P( A, B, C, D, 12,  6, 0x655B59C3 );
    P( D, A, B, C,  3, 10, 0x8F0CCC92 );
    P( C, D, A, B, 10, 15, 0xFFEFF47D );
    P( B, C, D, A,  1, 21, 0x85845DD1 );
    P( A, B, C, D,  8,  6, 0x6FA87E4F );
    P( D, A, B, C, 15, 10, 0xFE2CE6E0 );
    P( C, D, A, B,  6, 15, 0xA3014314 );
    P( B, C, D, A, 13, 21, 0x4E0811A1 );
    P( A, B, C, D,  4,  6, 0xF7537E82 );
    P( D, A, B, C, 11, 10, 0xBD3AF235 );
    P( C, D, A, B,  2, 15, 0x2AD7D2BB );
    P( B, C, D, A,  9, 21, 0xEB86D391 );

#undef F

    ctx->state[0] += A;
    ctx->state[1] += B;
    ctx->state[2] += C;
    ctx->state[3] += D;
}

void md5_update( md5_context *ctx, uint8 *input, uint32 length )
{
    uint32 left, fill;

    if( ! length ) return;

    left = ctx->total[0] & 0x3F;
    fill = 64 - left;

    ctx->total[0] += length;
    ctx->total[0] &= 0xFFFFFFFF;

    if( ctx->total[0] < length )
        ctx->total[1]++;

    if( left && length >= fill )
    {
        memcpy( (void *) (ctx->buffer + left),
                (void *) input, fill );
        md5_process( ctx, ctx->buffer );
        length -= fill;
        input  += fill;
        left = 0;
    }

    while( length >= 64 )
    {
        md5_process( ctx, input );
        length -= 64;
        input  += 64;
    }

    if( length )
    {
        memcpy( (void *) (ctx->buffer + left),
                (void *) input, length );
    }
}

static uint8 md5_padding[64] =
{
 0x80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

void md5_finish( md5_context *ctx, uint8 digest[16] )
{
    uint32 last, padn;
    uint32 high, low;
    uint8 msglen[8];

    high = ( ctx->total[0] >> 29 )
         | ( ctx->total[1] <<  3 );
    low  = ( ctx->total[0] <<  3 );

    PUT_UINT32( low,  msglen, 0 );
    PUT_UINT32( high, msglen, 4 );

    last = ctx->total[0] & 0x3F;
    padn = ( last < 56 ) ? ( 56 - last ) : ( 120 - last );

    md5_update( ctx, md5_padding, padn );
    md5_update( ctx, msglen, 8 );

    PUT_UINT32( ctx->state[0], digest,  0 );
    PUT_UINT32( ctx->state[1], digest,  4 );
    PUT_UINT32( ctx->state[2], digest,  8 );
    PUT_UINT32( ctx->state[3], digest, 12 );
}
MD5(char *str,char *hash)
{
	int j;
    md5_context ctx;
    unsigned char md5sum[16];
    md5_starts( &ctx );
    md5_update( &ctx, (uint8 *) str, strlen( str ) );
    md5_finish( &ctx, md5sum );
    for( j = 0; j < 16; j++ )
    {
		sprintf( hash + j * 2, "%02x", md5sum[j] );
    }
	return 0;
}
#undef GET_UINT32
#undef PUT_UINT32
#undef P

/*
int main()
{
	char szIn[]="9F0715F4EFB68B871BD56F594BECD22D42260E0A1752DA13AB782EB1BB3AD7B5A49A6F713C88486E80B9BC56A2BB16A5B5C1752680345B8EEAD88C732C9720";
	char hash[50];

	MD5(szIn,hash);

	printf("%s\n", hash);
	return 0;
}
*/
int Hash(char *szName, char *szHash)
{
	unsigned long constants[]={
	0xCEC360AB, 0xA0FDEA76, 0x3CB10738, 0x2505A3FD, 0x8D8C07BF, 0xBDD14910, 0x7012D1CA, 0x51FEC95A,
	0x310FD44E, 0x1887EA27, 0x0C43F513, 0x0621FA89, 0x9310FD44, 0x13EE6E3A, 0xBBB98F63, 0x5D77CDFF,
	0x825B5466, 0xAA94FD6D, 0x0102DFA8, 0x00816FD4, 0x04CDA65E, 0xA8E8AEEA, 0x929602F8, 0x494B017C,
	0xE45F85A7, 0xAAD50FCA, 0xA1764AAC, 0x89738DA0, 0xAC59570B, 0x5F73C99B, 0xDC51F8A0, 0xFDC37B40,
	0x890BB393, 0x5DFFD290, 0x2EFFE948, 0x177FF4A4, 0xEF3F9416, 0xC5DA4F29, 0x34598DAD, 0x006166B8,
	0x0030B35C, 0x001859AE, 0xB686B863, 0x0006166B, 0x00030B35, 0xB561D748, 0x00CFBC9D, 0x0E9B42F8,
	0x5088DC52, 0x384AD072, 0x14223714, 0x0A111B8A, 0x5FA2859F, 0x0B120BD5, 0xF38D0438, 0x79C6821C,
	0x3CE3410E, 0x1E71A087, 0x0F38D043, 0x99D8973D, 0x03CE3410, 0x18BC5268, 0x03B96144, 0x4308D6C8};

	int temp = 0;
	int Counter = 0;
	int Counter2;
	unsigned long tEax;
	unsigned long tt;
	//char szName[]="CyclopstCm!EEEEEtCm!";
	char szHash_1[130]={0};
	char szTemp[10];
	char hash[50];

	//Custom Hash
	//It is flawed. Some of the ROL,ROR,BSWAP doesnt make any difference
	while(Counter!=16)
	{
		Counter2 = 64;
		temp = 0;
		while(Counter2 != 0)
		{
			tEax = (szName[Counter]%0x26)^constants[temp];
			tEax = BSWAP(tEax);
			//tEax = ROL(tEax, 5);
			tEax += 0xFADEC0DE;
			tEax += constants[temp];
			tEax ^= constants[Counter];
			//BSWAP(tt);
			//ROR(tt,6);
			tEax += constants[temp];
			tEax -= constants[Counter];
			temp++;
			Counter2--;
		}
		tEax ^= constants[Counter];
		sprintf(szTemp,"%X",tEax);
		strcat(szHash_1, szTemp);

		//cTemp2++;
		Counter++;
	}
	
	

	MD5(szHash_1,hash);

	Counter2 = 0;
	//ConvertBase256StringToHexString()
	for ( Counter=0; Counter<strlen(hash); Counter++)
	{
		if((hash[Counter]>>4) < 10)
		{
			sprintf(szHash+Counter2,"%c",(hash[Counter]>>4)+48);
			Counter2++;
			//printf("%c",(hash[Counter]>>4)+48);
		}
		else
		{
			sprintf(szHash+Counter2,"%c",(hash[Counter]>>4)+55);
			Counter2++;
			//printf("%c",(hash[Counter]>>4)+55);
		}
		if((hash[Counter]&15) < 10)
		{
			sprintf(szHash+Counter2,"%c",(hash[Counter]&15)+48);
			Counter2++;
			//printf("%c",(hash[Counter]&15)+48);
		}
		else
		{
			sprintf(szHash+Counter2,"%c",(hash[Counter]&15)+55);
			Counter2++;
			//printf("%c",(hash[Counter]&15)+55);
		}
	}
	return 0;
}
