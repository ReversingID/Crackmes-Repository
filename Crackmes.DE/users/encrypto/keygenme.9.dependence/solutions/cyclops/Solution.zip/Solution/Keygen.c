//The code is not at all optimized. I know its weird, but works fine!
void Make_Serial(HWND hWnd,char *name,char *serial)
{
	int i;
	char szSerial[256];
	miracl *mip;
	big bK,b_G,bP,bP_1,bR,bH, bX, bOne;

	mip=mirsys(0x64,0);
	mip->IOBASE = 16;
	bK = mirvar(21);
	bP_1 = mirvar(0);
	b_G = mirvar(0);
	bP = mirvar(0);
	bR = mirvar(0);
	bH = mirvar(0);
	bX = mirvar(0);
	bOne = mirvar(1);

	strcat(name,"tCm!");
	for(i=strlen(name);i<16;i++)
	{
		name[i]='E';
	}
	name[i] = 0x00;
	Hash(name,szSerial);

	cinstr(b_G, "B5E4249F57F3E529");
	cinstr(bP,"F281A0901DC57A5F");
	cinstr(bH,szSerial);
	cinstr(bX,"CFB4DDFEB7C33B01");
	cinstr(bP_1,"F281A0901DC57A5E");

	powmod(b_G,bK,bP,bR);

	multiply(bX,bR,bX);
	powmod(bX,bOne,bP_1,bX);

	subtract(bH,bX,bH);
	powmod(bH,bOne,bP_1,bH);

	xgcd(bK,bP_1,bK,bK,bK);		//k-1

	multiply(bK,bH,bK);

	powmod(bK,bOne,bP_1,bH);


	cotstr(bR, szSerial);
	cotstr(bH, serial);

	strcat(szSerial,serial);


	SetDlgItemText(hWnd,IDC_SERIAL,szSerial);

	//strcpy(serial,name);
}