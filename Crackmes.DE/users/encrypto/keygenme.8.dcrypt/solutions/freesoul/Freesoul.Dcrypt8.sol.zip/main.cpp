
		#include <stdio.h>
		#include <windows.h>
		#include <commctrl.h>
		#include "resource.h"

		#define TITLE "Dcrypt#8 [Encrypto] keygen [freesoul]"

		#pragma comment(lib, "comctl32.lib")

		char* gen(char* name);
		HINSTANCE	hInst;

		void error(void) {
			MessageBox(NULL,"Error","Error",MB_OK);
		}

		void Int64toStr(unsigned int value1, unsigned int value2)
		{
			int offs;
			__asm {
				mov offs, eax
			}
			char* string;
			string = new char[22];
			signed __int64  res = 0;
			res = value2 * 0x100000000;
			res+= value1;	
			_i64toa(res, string, 10);
			__asm{
				push ecx
				mov ecx, dword ptr [offs]
				mov dword ptr [ecx], eax
				pop ecx
			}
			return;
		}

		BOOL CALLBACK DialogProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
		{	
			switch (message)
			{
			case WM_CLOSE:
				EndDialog(hWnd,0);
				break;
			case WM_COMMAND:
				switch (HIWORD(wParam))
				{
				case STN_CLICKED:
					if(LOWORD(wParam) == ID_FREESOUL)
					MessageBox(hWnd, "Target: Dcrypt#8 [Encrypto]\n\nProtections:\n- Long homemade hash (ripped)", "About", MB_OK);
					break;
				case EN_CHANGE:
					switch (LOWORD(wParam))
					{
					case IDNAME:
						char *name;
						name = new char[16];
						GetDlgItemText(hWnd, IDNAME, name, 16);
						if(strlen(name)<1 || strlen(name)>15 || strlen(name)<4)
						SetDlgItemText(hWnd, IDSERIAL, (char*)"Enter a name (>3 && <16)");
						else
						SetDlgItemText(hWnd, IDSERIAL, gen(name));
						break;
					}
					break;
				}
				break;
			case WM_INITDIALOG:
				SendMessage(hWnd,  WM_SETICON, ICON_SMALL,(LPARAM) LoadIcon(hInst, MAKEINTRESOURCE(IDI_ICON1)));
				SendMessage(hWnd,  WM_SETICON, ICON_BIG,(LPARAM) LoadIcon(hInst, MAKEINTRESOURCE(IDI_ICON1)));
				RECT r;
				GetWindowRect(hWnd, &r);
				SetWindowPos(hWnd, 0, GetSystemMetrics(SM_CXSCREEN)/2-r.right/2, GetSystemMetrics(SM_CYFULLSCREEN)/2-r.bottom/2, r.right, r.bottom, 0);	
				SetWindowText(hWnd, TITLE);
				char *name;
				name = new char[32];
				DWORD len = 32;
				GetUserName(name, &len);
				SetDlgItemText(hWnd, IDNAME, name);
				break;
			}
			return 0;
		}

		int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
		{
			hInst=hInstance;
			InitCommonControls();
			DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_MAIN), NULL, (DLGPROC)DialogProc,0);
			return 0;
		}

		char* gen(char* name)
		{
			char* serial;
			serial = new char[36]; 
			int* pre_serial;
			pre_serial = new int[4];
			__asm{
				pushad
				mov eax, name[0]
				;mov ecx, nlen
				;mov dword ptr [eax-0x4], ecx
				call generate
				mov ecx, dword ptr pre_serial[0]
				mov ebx, dword ptr [eax]
				mov dword ptr [ecx], ebx
				add eax, 4h
				add ecx, 4h
				mov ebx, dword ptr [eax]
				mov dword ptr [ecx], ebx
				add eax, 4h
				add ecx, 4h
				mov ebx, dword ptr [eax]
				mov dword ptr [ecx], ebx
				add eax, 4h
				add ecx, 4h
				mov ebx, dword ptr [eax]
				mov dword ptr [ecx], ebx
				
				jmp end
		generate:
				push ebp
				mov ebp,esp
				mov ecx,0x3D
		L003:
				push 0x0
				push 0x0
				dec ecx
				jnz L003
				push ebx
				push esi
				mov ebx,edx
				mov dword ptr ss:[ebp-0x4],eax
				mov eax,dword ptr ss:[ebp-0x4]
				call call20
				xor eax,eax
				push ebp
				push 0x045BD5A
				push dword ptr fs:[eax]
				mov dword ptr fs:[eax],esp
				mov dword ptr ss:[ebp-0x58],0x0
				mov dword ptr ss:[ebp-0x54],0x0
				mov dword ptr ss:[ebp-0x10],0x20077002
				mov dword ptr ss:[ebp-0xC],0x0
				mov dword ptr ss:[ebp-0x18],0x20088002
				mov dword ptr ss:[ebp-0x14],0x0
				mov dword ptr ss:[ebp-0x20],0x77ABDCCE
				mov dword ptr ss:[ebp-0x1C],0x0
				mov dword ptr ss:[ebp-0x28],0x3314521A
				mov dword ptr ss:[ebp-0x24],0x0
				mov dword ptr ss:[ebp-0x30],0x99977766
				mov dword ptr ss:[ebp-0x2C],0x0
				mov dword ptr ss:[ebp-0x38],0x66666666
				mov dword ptr ss:[ebp-0x34],0x0
				mov dword ptr ss:[ebp-0x40],0xF0FFBE56
				mov dword ptr ss:[ebp-0x3C],0x0
				mov dword ptr ss:[ebp-0x48],0x8CEEBAD
				mov dword ptr ss:[ebp-0x44],0x0
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x24]
				push dword ptr ss:[ebp-0x28]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x34]
				push dword ptr ss:[ebp-0x38]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				mov eax,dword ptr ss:[ebp-0x4]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0x24]
				push dword ptr ss:[ebp-0x28]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x34]
				push dword ptr ss:[ebp-0x38]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0x68]
				call Int64toStr
				add esp, 8h							;resituate stack
				mov eax,dword ptr ss:[ebp-0x68]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x34]
				push dword ptr ss:[ebp-0x38]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0x6C]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x6C]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x24]
				push dword ptr ss:[ebp-0x28]
				push dword ptr ss:[ebp-0x34]
				push dword ptr ss:[ebp-0x38]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x24]
				push dword ptr ss:[ebp-0x28]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0x70]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x70]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x24]
				push dword ptr ss:[ebp-0x28]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0x74]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x74]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x34]
				push dword ptr ss:[ebp-0x38]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0x24]
				push dword ptr ss:[ebp-0x28]
				push dword ptr ss:[ebp-0x24]
				push dword ptr ss:[ebp-0x28]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x34]
				push dword ptr ss:[ebp-0x38]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0x78]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x78]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x34]
				push dword ptr ss:[ebp-0x38]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x34]
				push dword ptr ss:[ebp-0x38]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0x7C]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x7C]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x24]
				push dword ptr ss:[ebp-0x28]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x34]
				push dword ptr ss:[ebp-0x38]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0x80]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x80]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0x24]
				push dword ptr ss:[ebp-0x28]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x34]
				push dword ptr ss:[ebp-0x38]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0x84]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x84]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x24]
				push dword ptr ss:[ebp-0x28]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x34]
				push dword ptr ss:[ebp-0x38]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0x88]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x88]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0x8C]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x8C]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0x90]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x90]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0x94]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x94]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x34]
				push dword ptr ss:[ebp-0x38]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0x98]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x98]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x34]
				push dword ptr ss:[ebp-0x38]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0x9C]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x9C]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x34]
				push dword ptr ss:[ebp-0x38]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0xA0]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0xA0]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x34]
				push dword ptr ss:[ebp-0x38]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0xA4]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0xA4]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x34]
				push dword ptr ss:[ebp-0x38]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0xA8]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0xA8]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x34]
				push dword ptr ss:[ebp-0x38]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0xAC]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0xAC]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x34]
				push dword ptr ss:[ebp-0x38]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0xB0]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0xB0]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x34]
				push dword ptr ss:[ebp-0x38]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0xB4]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0xB4]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x24]
				push dword ptr ss:[ebp-0x28]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x34]
				push dword ptr ss:[ebp-0x38]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0xB8]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0xB8]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x24]
				push dword ptr ss:[ebp-0x28]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x34]
				push dword ptr ss:[ebp-0x38]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0xBC]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0xBC]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x24]
				push dword ptr ss:[ebp-0x28]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x34]
				push dword ptr ss:[ebp-0x38]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0xC0]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0xC0]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x24]
				push dword ptr ss:[ebp-0x28]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x34]
				push dword ptr ss:[ebp-0x38]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0xC4]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0xC4]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x24]
				push dword ptr ss:[ebp-0x28]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x34]
				push dword ptr ss:[ebp-0x38]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0xC8]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0xC8]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x24]
				push dword ptr ss:[ebp-0x28]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x34]
				push dword ptr ss:[ebp-0x38]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0xCC]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0xCC]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x24]
				push dword ptr ss:[ebp-0x28]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x34]
				push dword ptr ss:[ebp-0x38]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0xD0]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0xD0]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x24]
				push dword ptr ss:[ebp-0x28]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x34]
				push dword ptr ss:[ebp-0x38]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0xD4]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0xD4]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x24]
				push dword ptr ss:[ebp-0x28]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x34]
				push dword ptr ss:[ebp-0x38]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0xD8]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0xD8]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0xDC]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0xDC]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x2C]
				push dword ptr ss:[ebp-0x30]
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x3C]
				push dword ptr ss:[ebp-0x40]
				push dword ptr ss:[ebp-0x44]
				push dword ptr ss:[ebp-0x48]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x1C]
				push dword ptr ss:[ebp-0x20]
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				push dword ptr ss:[ebp-0xC]
				push dword ptr ss:[ebp-0x10]
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0xE0]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0xE0]
				call call50
				mov dword ptr ss:[ebp-0x50],eax
				mov dword ptr ss:[ebp-0x4C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0xE4]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0xE4]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x54]
				push dword ptr ss:[ebp-0x58]
				lea eax,dword ptr ss:[ebp-0xE8]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0xE8]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x54]
				push dword ptr ss:[ebp-0x58]
				lea eax,dword ptr ss:[ebp-0xEC]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0xEC]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x54]
				push dword ptr ss:[ebp-0x58]
				lea eax,dword ptr ss:[ebp-0xF0]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0xF0]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x54]
				push dword ptr ss:[ebp-0x58]
				lea eax,dword ptr ss:[ebp-0xF4]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0xF4]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x54]
				push dword ptr ss:[ebp-0x58]
				lea eax,dword ptr ss:[ebp-0xF8]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0xF8]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x54]
				push dword ptr ss:[ebp-0x58]
				lea eax,dword ptr ss:[ebp-0xFC]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0xFC]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x54]
				push dword ptr ss:[ebp-0x58]
				lea eax,dword ptr ss:[ebp-0x100]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x100]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x54]
				push dword ptr ss:[ebp-0x58]
				lea eax,dword ptr ss:[ebp-0x104]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x104]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x54]
				push dword ptr ss:[ebp-0x58]
				lea eax,dword ptr ss:[ebp-0x108]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x108]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x54]
				push dword ptr ss:[ebp-0x58]
				lea eax,dword ptr ss:[ebp-0x10C]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x10C]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x54]
				push dword ptr ss:[ebp-0x58]
				lea eax,dword ptr ss:[ebp-0x110]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x110]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x54]
				push dword ptr ss:[ebp-0x58]
				lea eax,dword ptr ss:[ebp-0x114]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x114]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x54]
				push dword ptr ss:[ebp-0x58]
				lea eax,dword ptr ss:[ebp-0x118]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x118]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x54]
				push dword ptr ss:[ebp-0x58]
				lea eax,dword ptr ss:[ebp-0x11C]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x11C]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x54]
				push dword ptr ss:[ebp-0x58]
				lea eax,dword ptr ss:[ebp-0x120]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x120]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x54]
				push dword ptr ss:[ebp-0x58]
				lea eax,dword ptr ss:[ebp-0x124]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x124]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x54]
				push dword ptr ss:[ebp-0x58]
				lea eax,dword ptr ss:[ebp-0x128]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x128]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x54]
				push dword ptr ss:[ebp-0x58]
				lea eax,dword ptr ss:[ebp-0x12C]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x12C]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x54]
				push dword ptr ss:[ebp-0x58]
				lea eax,dword ptr ss:[ebp-0x130]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x130]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x54]
				push dword ptr ss:[ebp-0x58]
				lea eax,dword ptr ss:[ebp-0x134]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x134]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x54]
				push dword ptr ss:[ebp-0x58]
				lea eax,dword ptr ss:[ebp-0x138]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x138]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0x13C]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x13C]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0x140]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x140]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0x144]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x144]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0x148]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x148]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0x14C]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x14C]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0x150]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x150]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0x154]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x154]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x50]
				adc edx,dword ptr ss:[ebp-0x4C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x4C]
				push dword ptr ss:[ebp-0x50]
				lea eax,dword ptr ss:[ebp-0x158]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x158]
				call call50
				mov dword ptr ss:[ebp-0x58],eax
				mov dword ptr ss:[ebp-0x54],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x54]
				push dword ptr ss:[ebp-0x58]
				lea eax,dword ptr ss:[ebp-0x15C]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x15C]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x160]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x160]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x164]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x164]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x168]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x168]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x16C]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x16C]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x170]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x170]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x174]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x174]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x178]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x178]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x17C]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x17C]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x180]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x180]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x184]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x184]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x188]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x188]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x18C]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x18C]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x190]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x190]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x194]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x194]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x198]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x198]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x19C]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x19C]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x1A0]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x1A0]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x1A4]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x1A4]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x1A8]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x1A8]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x1AC]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x1AC]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x1B0]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x1B0]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x1B4]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x1B4]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x1B8]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x1B8]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x1BC]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x1BC]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x1C0]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x1C0]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x1C4]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x1C4]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x1C8]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x1C8]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x1CC]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x1CC]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x1D0]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x1D0]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x1D4]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x1D4]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x20]
				mov edx,dword ptr ss:[ebp-0x1C]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x28]
				mov edx,dword ptr ss:[ebp-0x24]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x30]
				mov edx,dword ptr ss:[ebp-0x2C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x40]
				mov edx,dword ptr ss:[ebp-0x3C]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x48]
				mov edx,dword ptr ss:[ebp-0x44]
				add eax,dword ptr ss:[ebp-0x58]
				adc edx,dword ptr ss:[ebp-0x54]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x38]
				mov edx,dword ptr ss:[ebp-0x34]
				add eax,dword ptr ss:[ebp-0x60]
				adc edx,dword ptr ss:[ebp-0x5C]
				push edx
				push eax
				push dword ptr ss:[ebp-0x5C]
				push dword ptr ss:[ebp-0x60]
				lea eax,dword ptr ss:[ebp-0x1D8]
				call Int64toStr
				add esp, 8h
				mov eax,dword ptr ss:[ebp-0x1D8]
				call call50
				mov dword ptr ss:[ebp-0x60],eax
				mov dword ptr ss:[ebp-0x5C],edx
				; End hashing...
				pushad
				lea ecx, [ebp-0x38]
				mov eax, dword ptr [ebp-0x5c]
				mov dword ptr [ecx], eax
				add ecx, 4h
				mov eax, dword ptr [ebp-0x60]
				mov dword ptr [ecx], eax
				add ecx, 4h
				mov eax, dword ptr [ebp-0x4C]
				mov dword ptr [ecx], eax
				add ecx, 4h
				mov eax, dword ptr [ebp-0x50]
				mov dword ptr [ecx], eax
				popad
				lea eax, [ebp-0x38] 
				pop edx
				pop ecx
				pop ecx
				pop esi
				pop ebx
				mov esp,ebp
				pop ebp
				retn
		call20:
				test eax,eax
				je L006
				mov edx,dword ptr ds:[eax-0x8]
				inc edx
				jle L006
				lock inc dword ptr ds:[eax-0x8]
		L006:
				retn
		call30:							; modified for getting strlen
				test eax, eax
				je L00x
				pushad
				push eax
				call my_strlen
				mov ecx, eax
				pop eax
				mov dword ptr ds:[eax-0x4], ecx
				popad
				mov eax, dword ptr ds:[eax-0x4]
		L00x:
				retn
				my_strlen:
				push ebp
				mov ebp, esp
				push ebx
				push ecx
				mov ebx, [ebp+8]
				mov ecx, 0
		L1:
				mov eax, [ebx]
				test eax, eax
				jz L2
				inc ebx
				inc ecx
				jmp L1
		L2:
				mov eax, ecx
				pop ecx
				pop ebx
				pop ebp
				ret
		call8C:
				cmp cl,0x20
				jl L011
				cmp cl,0x40
				jl L007
				xor edx,edx
				xor eax,eax
				retn
		L007:
				mov eax,edx
				xor edx,edx
				shr eax,cl
				retn
		L011:
				shrd eax,edx,cl
				shr edx,cl
				retn
		call6C:
				cmp cl,0x20
				jl Lx11
				cmp cl,0x40
				jl Lx07
				xor edx,edx
				xor eax,eax
				retn
		Lx07:
				mov edx,eax
				shl edx,cl
				xor eax,eax
				retn
		Lx11:
				shld edx,eax,cl
				shl eax,cl
				retn
		call00:
				push ebp
				mov ebp,esp
				add esp,-0x8
				mov eax,dword ptr ss:[ebp+0x8]
				mov ecx,eax
				mov eax,dword ptr ss:[ebp+0x10]
				mov edx,dword ptr ss:[ebp+0x14]
				call call8C
				push edx
				push eax
				mov eax,0x32
				xor edx,edx
				sub eax,dword ptr ss:[ebp+0x8]
				sbb edx,dword ptr ss:[ebp+0xC]
				mov ecx,eax
				mov eax,dword ptr ss:[ebp+0x10]
				mov edx,dword ptr ss:[ebp+0x14]
				call call6C
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				mov dword ptr ss:[ebp-0x8],eax
				mov dword ptr ss:[ebp-0x4],edx
				mov eax,dword ptr ss:[ebp-0x8]
				mov edx,dword ptr ss:[ebp-0x4]
				pop ecx
				pop ecx
				pop ebp
				retn 0x10
		call48:
				push edx
				push eax
				mov eax,dword ptr ss:[esp+0x10]
				mul dword ptr ss:[esp]
				mov ecx,eax
				mov eax,dword ptr ss:[esp+0x4]
				mul dword ptr ss:[esp+0xC]
				add ecx,eax
				mov eax,dword ptr ss:[esp]
				mul dword ptr ss:[esp+0xC]
				add edx,ecx
				pop ecx
				pop ecx
				retn 0x8
		call70:
				mov edx,dword ptr ds:[eax]
				test edx,edx
				je L013
				mov dword ptr ds:[eax],0x0
				mov ecx,dword ptr ds:[edx-0x8]
				dec ecx
				jl L013
				lock dec dword ptr ds:[edx-0x8]
				jnz L013
				push eax
				lea eax,dword ptr ds:[edx-0x8]
				call error
				pop eax
		L013:
				retn
		call50:
				push ebp
				mov ebp,esp
				add esp,-0x18
				push ebx
				push esi
				push edi
				mov dword ptr ss:[ebp-0x4],eax
				mov eax,dword ptr ss:[ebp-0x4]
				call call20
				xor eax,eax
				push ebp
				push 0x0458A5C
				push dword ptr fs:[eax]
				mov dword ptr fs:[eax],esp
				mov dword ptr ss:[ebp-0x18],0x7890F0FF
				mov dword ptr ss:[ebp-0x14],0x123456
				mov eax,dword ptr ss:[ebp-0x4]
				call call30
				mov esi,eax
				test esi,esi
				jle L1015
				mov edi,0x1
		L022:
				mov eax,edi
				cdq
				push edx
				push eax
				push dword ptr ss:[ebp+0x4C]
				push dword ptr ss:[ebp+0x48]
				mov eax,edi
				cdq
				call call48
				call call48
				add eax,dword ptr ss:[ebp+0x48]
				adc edx,dword ptr ss:[ebp+0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov bl,byte ptr ds:[eax+edi-0x1]
				mov eax,ebx
				and eax,0xFF
				xor edx,edx
				xor eax,dword ptr ss:[ebp+0x48]
				xor edx,dword ptr ss:[ebp+0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				xor eax,dword ptr ss:[ebp+0x10]
				xor edx,dword ptr ss:[ebp+0x14]
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				xor eax,dword ptr ss:[esp]
				xor edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				xor eax,eax
				mov al,bl
				imul edi
				cdq
				xor eax,dword ptr ss:[esp]
				xor edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				and eax,dword ptr ss:[ebp+0x48]
				and edx,dword ptr ss:[ebp+0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				xor eax,dword ptr ss:[ebp+0x48]
				xor edx,dword ptr ss:[ebp+0x4C]
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				xor eax,dword ptr ss:[ebp+0x48]
				xor edx,dword ptr ss:[ebp+0x4C]
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				xor eax,dword ptr ss:[esp]
				xor edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				push 0x7
				push 0x29348AD
				call call00
				add eax,dword ptr ss:[ebp-0x18]
				adc edx,dword ptr ss:[ebp-0x14]
				mov dword ptr ss:[ebp-0x18],eax
				mov dword ptr ss:[ebp-0x14],edx
				mov eax,edi
				cdq
				push edx
				push eax
				push dword ptr ss:[ebp+0x3C]
				push dword ptr ss:[ebp+0x38]
				mov eax,edi
				cdq
				call call48
				call call48
				add eax,dword ptr ss:[ebp+0x38]
				adc edx,dword ptr ss:[ebp+0x3C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				and eax,dword ptr ss:[ebp+0x18]
				and edx,dword ptr ss:[ebp+0x1C]
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov bl,byte ptr ds:[eax+edi-0x1]
				xor eax,eax
				mov al,bl
				imul edi
				cdq
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				xor eax,dword ptr ss:[ebp+0x38]
				xor edx,dword ptr ss:[ebp+0x3C]
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,ebx
				and eax,0xFF
				xor edx,edx
				and eax,dword ptr ss:[ebp+0x8]
				and edx,dword ptr ss:[ebp+0xC]
				xor eax,dword ptr ss:[esp]
				xor edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				and eax,dword ptr ss:[ebp+0x38]
				and edx,dword ptr ss:[ebp+0x3C]
				or eax,dword ptr ss:[esp]
				or edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				and eax,dword ptr ss:[ebp+0x38]
				and edx,dword ptr ss:[ebp+0x3C]
				xor eax,dword ptr ss:[esp]
				xor edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				push 0x0
				push 0x983240DA
				call call00
				add eax,dword ptr ss:[ebp-0x18]
				adc edx,dword ptr ss:[ebp-0x14]
				mov dword ptr ss:[ebp-0x18],eax
				mov dword ptr ss:[ebp-0x14],edx
				mov eax,edi
				cdq
				push edx
				push eax
				push dword ptr ss:[ebp+0x34]
				push dword ptr ss:[ebp+0x30]
				mov eax,edi
				cdq
				call call48
				call call48
				add eax,dword ptr ss:[ebp+0x30]
				adc edx,dword ptr ss:[ebp+0x34]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov bl,byte ptr ds:[eax+edi-0x1]
				mov eax,ebx
				and eax,0xFF
				xor edx,edx
				xor eax,dword ptr ss:[ebp+0x38]
				xor edx,dword ptr ss:[ebp+0x3C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				xor eax,dword ptr ss:[ebp+0x20]
				xor edx,dword ptr ss:[ebp+0x24]
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				xor eax,dword ptr ss:[esp]
				xor edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				xor eax,eax
				mov al,bl
				imul edi
				cdq
				xor eax,dword ptr ss:[esp]
				xor edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp+0x38]
				mov edx,dword ptr ss:[ebp+0x3C]
				xor eax,dword ptr ss:[ebp+0x30]
				xor edx,dword ptr ss:[ebp+0x34]
				xor eax,dword ptr ss:[esp]
				xor edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				xor eax,dword ptr ss:[ebp+0x30]
				xor edx,dword ptr ss:[ebp+0x34]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				xor eax,dword ptr ss:[ebp+0x30]
				xor edx,dword ptr ss:[ebp+0x34]
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				or eax,dword ptr ss:[esp]
				or edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				push 0x0
				push 0x1297DEFD
				call call00
				add eax,dword ptr ss:[ebp-0x18]
				adc edx,dword ptr ss:[ebp-0x14]
				mov dword ptr ss:[ebp-0x18],eax
				mov dword ptr ss:[ebp-0x14],edx
				mov eax,edi
				cdq
				push edx
				push eax
				push dword ptr ss:[ebp+0x2C]
				push dword ptr ss:[ebp+0x28]
				mov eax,edi
				cdq
				call call48
				call call48
				add eax,dword ptr ss:[ebp+0x28]
				adc edx,dword ptr ss:[ebp+0x2C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				and eax,dword ptr ss:[ebp-0x18]
				and edx,dword ptr ss:[ebp-0x14]
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov bl,byte ptr ds:[eax+edi-0x1]
				xor eax,eax
				mov al,bl
				imul edi
				cdq
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,ebx
				and eax,0xFF
				xor edx,edx
				and eax,dword ptr ss:[ebp+0x30]
				and edx,dword ptr ss:[ebp+0x34]
				xor eax,dword ptr ss:[esp]
				xor edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				and eax,dword ptr ss:[ebp+0x28]
				and edx,dword ptr ss:[ebp+0x2C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp+0x30]
				mov edx,dword ptr ss:[ebp+0x34]
				xor eax,dword ptr ss:[ebp+0x28]
				xor edx,dword ptr ss:[ebp+0x2C]
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				xor eax,dword ptr ss:[esp]
				xor edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				and eax,dword ptr ss:[ebp+0x28]
				and edx,dword ptr ss:[ebp+0x2C]
				xor eax,dword ptr ss:[esp]
				xor edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				push 0x9
				push 0x823E7283
				call call00
				add eax,dword ptr ss:[ebp-0x18]
				adc edx,dword ptr ss:[ebp-0x14]
				mov dword ptr ss:[ebp-0x18],eax
				mov dword ptr ss:[ebp-0x14],edx
				mov eax,edi
				cdq
				push edx
				push eax
				push dword ptr ss:[ebp+0x24]
				push dword ptr ss:[ebp+0x20]
				mov eax,edi
				cdq
				call call48
				call call48
				add eax,dword ptr ss:[ebp+0x20]
				adc edx,dword ptr ss:[ebp+0x24]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov bl,byte ptr ds:[eax+edi-0x1]
				mov eax,ebx
				and eax,0xFF
				xor edx,edx
				xor eax,dword ptr ss:[ebp+0x28]
				xor edx,dword ptr ss:[ebp+0x2C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				xor eax,dword ptr ss:[ebp+0x28]
				xor edx,dword ptr ss:[ebp+0x2C]
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				xor eax,dword ptr ss:[esp]
				xor edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				xor eax,eax
				mov al,bl
				imul edi
				cdq
				xor eax,dword ptr ss:[esp]
				xor edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp+0x28]
				mov edx,dword ptr ss:[ebp+0x2C]
				and eax,dword ptr ss:[ebp+0x20]
				and edx,dword ptr ss:[ebp+0x24]
				xor eax,dword ptr ss:[esp]
				xor edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				xor eax,dword ptr ss:[ebp+0x20]
				xor edx,dword ptr ss:[ebp+0x24]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				xor eax,dword ptr ss:[ebp+0x20]
				xor edx,dword ptr ss:[ebp+0x24]
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				or eax,dword ptr ss:[esp]
				or edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				push 0x8
				push 0xDAA8932D
				call call00
				add eax,dword ptr ss:[ebp-0x18]
				adc edx,dword ptr ss:[ebp-0x14]
				mov dword ptr ss:[ebp-0x18],eax
				mov dword ptr ss:[ebp-0x14],edx
				mov eax,edi
				cdq
				push edx
				push eax
				push dword ptr ss:[ebp+0x1C]
				push dword ptr ss:[ebp+0x18]
				mov eax,edi
				cdq
				call call48
				call call48
				add eax,dword ptr ss:[ebp+0x18]
				adc edx,dword ptr ss:[ebp+0x1C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				and eax,dword ptr ss:[ebp+0x30]
				and edx,dword ptr ss:[ebp+0x34]
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov bl,byte ptr ds:[eax+edi-0x1]
				xor eax,eax
				mov al,bl
				imul edi
				cdq
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp+0x20]
				mov edx,dword ptr ss:[ebp+0x24]
				xor eax,dword ptr ss:[ebp+0x18]
				xor edx,dword ptr ss:[ebp+0x1C]
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				and eax,dword ptr ss:[ebp+0x18]
				and edx,dword ptr ss:[ebp+0x1C]
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,ebx
				and eax,0xFF
				xor edx,edx
				and eax,dword ptr ss:[ebp+0x20]
				and edx,dword ptr ss:[ebp+0x24]
				xor eax,dword ptr ss:[esp]
				xor edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				and eax,dword ptr ss:[ebp+0x18]
				and edx,dword ptr ss:[ebp+0x1C]
				xor eax,dword ptr ss:[esp]
				xor edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				push 0x5
				push 0x894DDE89
				call call00
				add eax,dword ptr ss:[ebp-0x18]
				adc edx,dword ptr ss:[ebp-0x14]
				mov dword ptr ss:[ebp-0x18],eax
				mov dword ptr ss:[ebp-0x14],edx
				mov eax,edi
				cdq
				push edx
				push eax
				push dword ptr ss:[ebp+0x14]
				push dword ptr ss:[ebp+0x10]
				mov eax,edi
				cdq
				call call48
				call call48
				add eax,dword ptr ss:[ebp+0x10]
				adc edx,dword ptr ss:[ebp+0x14]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov bl,byte ptr ds:[eax+edi-0x1]
				mov eax,ebx
				and eax,0xFF
				xor edx,edx
				xor eax,dword ptr ss:[ebp+0x18]
				xor edx,dword ptr ss:[ebp+0x1C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				xor eax,dword ptr ss:[ebp+0x8]
				xor edx,dword ptr ss:[ebp+0xC]
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				xor eax,dword ptr ss:[esp]
				xor edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				xor eax,eax
				mov al,bl
				imul edi
				cdq
				push edx
				push eax
				mov eax,dword ptr ss:[ebp+0x18]
				mov edx,dword ptr ss:[ebp+0x1C]
				and eax,dword ptr ss:[ebp+0x10]
				and edx,dword ptr ss:[ebp+0x14]
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				xor eax,dword ptr ss:[esp]
				xor edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				xor eax,dword ptr ss:[ebp+0x10]
				xor edx,dword ptr ss:[ebp+0x14]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				xor eax,dword ptr ss:[ebp+0x10]
				xor edx,dword ptr ss:[ebp+0x14]
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				or eax,dword ptr ss:[esp]
				or edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				push 0x5
				push 0x894DDEA9
				call call00
				add eax,dword ptr ss:[ebp-0x18]
				adc edx,dword ptr ss:[ebp-0x14]
				mov dword ptr ss:[ebp-0x18],eax
				mov dword ptr ss:[ebp-0x14],edx
				mov eax,edi
				cdq
				push edx
				push eax
				push dword ptr ss:[ebp+0xC]
				push dword ptr ss:[ebp+0x8]
				mov eax,edi
				cdq
				call call48
				call call48
				add eax,dword ptr ss:[ebp+0x48]
				adc edx,dword ptr ss:[ebp+0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				and eax,dword ptr ss:[ebp+0x48]
				and edx,dword ptr ss:[ebp+0x4C]
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov bl,byte ptr ds:[eax+edi-0x1]
				xor eax,eax
				mov al,bl
				imul edi
				cdq
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp+0x10]
				mov edx,dword ptr ss:[ebp+0x14]
				xor eax,dword ptr ss:[ebp+0x8]
				xor edx,dword ptr ss:[ebp+0xC]
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,ebx
				and eax,0xFF
				xor edx,edx
				and eax,dword ptr ss:[ebp+0x10]
				and edx,dword ptr ss:[ebp+0x14]
				xor eax,dword ptr ss:[esp]
				xor edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				and eax,dword ptr ss:[ebp+0x8]
				and edx,dword ptr ss:[ebp+0xC]
				or eax,dword ptr ss:[esp]
				or edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				and eax,dword ptr ss:[ebp+0x8]
				and edx,dword ptr ss:[ebp+0xC]
				xor eax,dword ptr ss:[esp]
				xor edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				push 0x5
				push 0x894DDEB9
				call call00
				add eax,dword ptr ss:[ebp-0x18]
				adc edx,dword ptr ss:[ebp-0x14]
				mov dword ptr ss:[ebp-0x18],eax
				mov dword ptr ss:[ebp-0x14],edx
				mov eax,edi
				cdq
				push edx
				push eax
				push dword ptr ss:[ebp+0xC]
				push dword ptr ss:[ebp+0x8]
				mov eax,edi
				cdq
				call call48
				call call48
				add eax,dword ptr ss:[ebp+0x48]
				adc edx,dword ptr ss:[ebp+0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				and eax,dword ptr ss:[ebp+0x48]
				and edx,dword ptr ss:[ebp+0x4C]
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov bl,byte ptr ds:[eax+edi-0x1]
				xor eax,eax
				mov al,bl
				imul edi
				cdq
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp+0x10]
				mov edx,dword ptr ss:[ebp+0x14]
				xor eax,dword ptr ss:[ebp+0x8]
				xor edx,dword ptr ss:[ebp+0xC]
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,ebx
				and eax,0xFF
				xor edx,edx
				and eax,dword ptr ss:[ebp+0x10]
				and edx,dword ptr ss:[ebp+0x14]
				xor eax,dword ptr ss:[esp]
				xor edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				and eax,dword ptr ss:[ebp+0x8]
				and edx,dword ptr ss:[ebp+0xC]
				or eax,dword ptr ss:[esp]
				or edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				and eax,dword ptr ss:[ebp+0x8]
				and edx,dword ptr ss:[ebp+0xC]
				xor eax,dword ptr ss:[esp]
				xor edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				push 0x5
				push 0x894DDEC9
				call call00
				add eax,dword ptr ss:[ebp-0x18]
				adc edx,dword ptr ss:[ebp-0x14]
				mov dword ptr ss:[ebp-0x18],eax
				mov dword ptr ss:[ebp-0x14],edx
				mov eax,edi
				cdq
				push edx
				push eax
				push dword ptr ss:[ebp+0xC]
				push dword ptr ss:[ebp+0x8]
				mov eax,edi
				cdq
				call call48
				call call48
				add eax,dword ptr ss:[ebp+0x48]
				adc edx,dword ptr ss:[ebp+0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				and eax,dword ptr ss:[ebp+0x48]
				and edx,dword ptr ss:[ebp+0x4C]
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov bl,byte ptr ds:[eax+edi-0x1]
				xor eax,eax
				mov al,bl
				imul edi
				cdq
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp+0x10]
				mov edx,dword ptr ss:[ebp+0x14]
				xor eax,dword ptr ss:[ebp+0x8]
				xor edx,dword ptr ss:[ebp+0xC]
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,ebx
				and eax,0xFF
				xor edx,edx
				and eax,dword ptr ss:[ebp+0x10]
				and edx,dword ptr ss:[ebp+0x14]
				xor eax,dword ptr ss:[esp]
				xor edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				and eax,dword ptr ss:[ebp+0x8]
				and edx,dword ptr ss:[ebp+0xC]
				or eax,dword ptr ss:[esp]
				or edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				and eax,dword ptr ss:[ebp+0x8]
				and edx,dword ptr ss:[ebp+0xC]
				xor eax,dword ptr ss:[esp]
				xor edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				push 0x5
				push 0x894DDED9
				call call00
				add eax,dword ptr ss:[ebp-0x18]
				adc edx,dword ptr ss:[ebp-0x14]
				mov dword ptr ss:[ebp-0x18],eax
				mov dword ptr ss:[ebp-0x14],edx
				mov eax,edi
				cdq
				push edx
				push eax
				push dword ptr ss:[ebp+0xC]
				push dword ptr ss:[ebp+0x8]
				mov eax,edi
				cdq
				call call48
				call call48
				add eax,dword ptr ss:[ebp+0x48]
				adc edx,dword ptr ss:[ebp+0x4C]
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				and eax,dword ptr ss:[ebp+0x48]
				and edx,dword ptr ss:[ebp+0x4C]
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov bl,byte ptr ds:[eax+edi-0x1]
				xor eax,eax
				mov al,bl
				imul edi
				cdq
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp+0x10]
				mov edx,dword ptr ss:[ebp+0x14]
				xor eax,dword ptr ss:[ebp+0x8]
				xor edx,dword ptr ss:[ebp+0xC]
				and eax,dword ptr ss:[esp]
				and edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,ebx
				and eax,0xFF
				xor edx,edx
				and eax,dword ptr ss:[ebp+0x10]
				and edx,dword ptr ss:[ebp+0x14]
				xor eax,dword ptr ss:[esp]
				xor edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				and eax,dword ptr ss:[ebp+0x8]
				and edx,dword ptr ss:[ebp+0xC]
				or eax,dword ptr ss:[esp]
				or edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				and eax,dword ptr ss:[ebp+0x8]
				and edx,dword ptr ss:[ebp+0xC]
				xor eax,dword ptr ss:[esp]
				xor edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				push edx
				push eax
				push 0x5
				push 0x894DDEE9
				call call00
				add eax,dword ptr ss:[ebp-0x18]
				adc edx,dword ptr ss:[ebp-0x14]
				mov dword ptr ss:[ebp-0x18],eax
				mov dword ptr ss:[ebp-0x14],edx
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add dword ptr ss:[ebp+0x48],eax
				adc dword ptr ss:[ebp+0x4C],edx
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add dword ptr ss:[ebp+0x38],eax
				adc dword ptr ss:[ebp+0x3C],edx
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add dword ptr ss:[ebp+0x30],eax
				adc dword ptr ss:[ebp+0x34],edx
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add dword ptr ss:[ebp+0x28],eax
				adc dword ptr ss:[ebp+0x2C],edx
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add dword ptr ss:[ebp+0x20],eax
				adc dword ptr ss:[ebp+0x24],edx
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				add dword ptr ss:[ebp+0x18],eax
				adc dword ptr ss:[ebp+0x1C],edx
				mov eax,dword ptr ss:[ebp-0x4]
				mov al,byte ptr ds:[eax+edi-0x1]
				and eax,0xFF
				xor edx,edx
				push edx
				push eax
				mov eax,dword ptr ss:[ebp-0x18]
				mov edx,dword ptr ss:[ebp-0x14]
				call call48
				push edx
				push eax
				push dword ptr ss:[ebp-0x14]
				push dword ptr ss:[ebp-0x18]
				mov eax,dword ptr ss:[ebp+0x10]
				mov edx,dword ptr ss:[ebp+0x14]
				call call48
				push edx
				push eax
				mov eax,dword ptr ss:[ebp+0x48]
				mov edx,dword ptr ss:[ebp+0x4C]
				add eax,dword ptr ss:[ebp+0x38]
				adc edx,dword ptr ss:[ebp+0x3C]
				add eax,dword ptr ss:[ebp+0x30]
				adc edx,dword ptr ss:[ebp+0x34]
				add eax,dword ptr ss:[ebp+0x28]
				adc edx,dword ptr ss:[ebp+0x2C]
				add eax,dword ptr ss:[ebp+0x20]
				adc edx,dword ptr ss:[ebp+0x24]
				add eax,dword ptr ss:[ebp+0x18]
				adc edx,dword ptr ss:[ebp+0x1C]
				add eax,dword ptr ss:[esp]
				adc edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				add eax,dword ptr ss:[ebp-0x18]
				adc edx,dword ptr ss:[ebp-0x14]
				add eax,dword ptr ss:[esp]
				adc edx,dword ptr ss:[esp+0x4]
				add esp,0x8
				add dword ptr ss:[ebp-0x18],eax
				adc dword ptr ss:[ebp-0x14],edx
				inc edi
				dec esi
				jnz L022
		L1015:
				mov eax,dword ptr ss:[ebp-0x18]
				mov dword ptr ss:[ebp-0x10],eax
				mov eax,dword ptr ss:[ebp-0x14]
				mov dword ptr ss:[ebp-0xC],eax
				xor eax,eax
				pop edx
				pop ecx
				pop ecx
				mov dword ptr fs:[eax],edx
				;L1025:
				lea eax,dword ptr ss:[ebp-0x4]
				call call70
				mov eax,dword ptr ss:[ebp-0x10]
				mov edx,dword ptr ss:[ebp-0xC]
				pop edi
				pop esi
				pop ebx
				mov esp,ebp
				pop ebp
				retn 0x48
		end:
				popad
			}

			sprintf(serial, "%08X-%08X-%08X-%08X", pre_serial[0], pre_serial[1], pre_serial[2], pre_serial[3]);
			return serial;
		}
