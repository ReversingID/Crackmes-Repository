
print "".join([chr( ord(b) + 20) for b in "`TU_KU_KRXMS"])
