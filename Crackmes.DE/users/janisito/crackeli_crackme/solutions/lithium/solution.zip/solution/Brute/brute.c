#define _CRT_SECURE_NO_DEPRECATE

#include <stdio.h>
#include <stdlib.h>

// THESE VALUES ARE SPECIFIC TO MY HARD DRIVE VOLUME ID
// CHANGE THEM FOR YOUR VOLUME ID!!!!
#define V1	0xC0068E84
#define V2	0x78386FCA
#define	V3	0x85C3E5F7
#define V4	0x40C02209

#define MAGIC	0x203C6AE4

unsigned int transform(unsigned int input);

int main()
{
	unsigned int i, j, k, l, x;

	i = 2222;
	
	for (j = 1; j < 10000; j++)
	{
		printf("j: %d\n", j);
		for (k = j; k < 10000; k++)
		{
			for (l = k; l < 10000; l++)
			{
				x = (V1+transform(i))*(V2+transform(j))*((V3+transform(k))-0x10100)*(V4+transform(l));
				if (x == MAGIC)
				{
					printf("FOUND! %x:%x:%x:%x MAGIC=%x\n", i, j, k, l, x);
					printf("V1: %x\n", V1+transform(i));
					printf("V2: %x\n", V2+transform(j));
					printf("V3: %x\n", V3+transform(k));
					printf("V4: %x\n", V4+transform(l));

					return 0;
				}
				
			}
		}
	}

	return 0;
}

unsigned int transform(unsigned int input)
{
	_asm{
		mov eax, input
		xor ebx, ebx
		mov ecx, 0xA

		xor edx, edx
		div ecx
		add edx, 0x30
		shl edx, 0x18
		or ebx, edx

		xor edx, edx
		div ecx
		add edx, 0x30
		shl edx, 0x10
		or ebx, edx

		xor edx, edx
		div ecx
		add edx, 0x30
		shl edx, 0x8
		or ebx, edx

		xor edx, edx
		div ecx
		add edx, 0x30
		or ebx, edx

		mov eax, ebx
	}
}
