Janisito's Crackeli Crackme II

The goal with this crackme is to find a valid serial. No keygen wanted! (Only bonus)
However... you cannot patch the .exe, that is, serial needs to be working on an unmodified .exe.

Get to work cracker!

// Janisito