#include <windows.h>
#include "resource.h"
#include "BigLib.h"

#define WS_EX_LAYERED		0x80000
#define LWA_ALPHA			0x00002
#define LWA_COLORKEY		0x00001


typedef BOOL ( WINAPI *PSETLAYEREDWINDOWATTRIBUTES)(HWND hwnd,
    COLORREF crKey,
    BYTE bAlpha,
    DWORD dwFlags
);

PSETLAYEREDWINDOWATTRIBUTES pSetLayeredWindowAttributes;

const char *D = "6NpJkKtqUvuPW01oKfe4Ent4";

bool generateSerial(char *name,char *serial)
{
	if( strlen(name) < 4 ) {
		strcpy(serial,"Your name is too short");
		return false;
	}
	//remove spaces:
	int i,j;
	for( i = 0, j = 0; name[i] != 0; ++i ) {
		if( isalpha(name[i]) ) 
			name[j++] = name[i];
		else if( isspace(name[i]) );
		else {
			strcpy(serial,"Invalid character(s) in name");
			return false;
		}
	}
	name[j] = 0;
	HBIG d,bName;
	d = BigCreate(BIG_512,BIG_STRING,(DWORD)D,64);
	bName = BigCreate(BIG_512,BIG_STRING,(DWORD)name,64);
	BigSub(d,bName);
	BigToString(d,serial,64);
	return true;
}

#define TRANSPARENCY		0xE0
#define SLEEP_TIME			40

DWORD WINAPI appear(HWND hWin)
{
	BYTE t;
	for( t = 0; t <= TRANSPARENCY; t += 0x10 ) {
		(*pSetLayeredWindowAttributes)(hWin,0,t,LWA_ALPHA);
		Sleep(SLEEP_TIME);
	}
	return 0;
}

DWORD WINAPI fade(HWND hWin)
{
	BYTE t;
	if( pSetLayeredWindowAttributes ) {
		for( t = TRANSPARENCY; t != 0; t -= 0x10 ) {
			(*pSetLayeredWindowAttributes)(hWin,0,t,LWA_ALPHA);
			Sleep(SLEEP_TIME);
		}
	
	}
	EndDialog(hWin,0);
	return 0;
}

const char *ABOUT= "Thanks to all members of NoXfire for this crackme\n"
				   "Greets go to all members of crackmes.de";


INT_PTR CALLBACK dlgProc(HWND hWin,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	
	HINSTANCE hUser32;
	int length;
	char name[16],serial[32];
	switch(uMsg) {
	case WM_INITDIALOG:
		SendDlgItemMessage(hWin,EDT_NAME,EM_LIMITTEXT,15,0);
		pSetLayeredWindowAttributes = 0;
		SetDlgItemText(hWin,EDT_NAME,"Enter your name");
		SetWindowLong(hWin,GWL_EXSTYLE,GetWindowLong(hWin,GWL_EXSTYLE) | WS_EX_LAYERED);
		hUser32 = GetModuleHandle("user32.dll");
		if( hUser32 ) {
			pSetLayeredWindowAttributes = (PSETLAYEREDWINDOWATTRIBUTES)
										  GetProcAddress(hUser32,"SetLayeredWindowAttributes");
			if( pSetLayeredWindowAttributes ) {
				(*pSetLayeredWindowAttributes)(hWin,0,0,LWA_ALPHA);
				CreateThread(0,0,(LPTHREAD_START_ROUTINE)appear,(void*)hWin,0,0);
	
			}
		}
        break; 
	case WM_CLOSE:
		CreateThread(0,0,(LPTHREAD_START_ROUTINE)fade,(void*)hWin,0,0);
		break;
	case WM_COMMAND:
		if( HIWORD(wParam) == BN_CLICKED ) {
			if( LOWORD(wParam) == BTN_CHECK ) {
				GetDlgItemText(hWin,EDT_NAME,name,sizeof(name));
				generateSerial(name,serial);
				SetDlgItemText(hWin,EDT_SERIAL,serial);
			}
			else if( LOWORD(wParam) == BTN_ABOUT ) {
				MessageBox(hWin,ABOUT,"About",MB_ICONINFORMATION);				
			}
		}
		break;
	default:
		return false;
	
	}
	return true;
}

int CALLBACK WinMain(HINSTANCE hInst,HINSTANCE hPrev,LPSTR cmd,int show)
{
	return DialogBox(hInst,MAKEINTRESOURCE(IDD_DIALOG1),0,(DLGPROC)dlgProc);
}


