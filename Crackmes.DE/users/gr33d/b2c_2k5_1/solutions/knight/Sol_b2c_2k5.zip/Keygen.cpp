#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <stdio.h>
#include "resource.h"

void Generate(HWND hWnd)
{
	int len = GetWindowTextLength(GetDlgItem(hWnd, IDC_NAME));
	char name[0x80];
	int key = 0;
	if(len < 5)
	{
		MessageBox(hWnd, "Atleast 5 chars please!", "Type in your name!", MB_OK | MB_ICONEXCLAMATION);
		return;
	}
	GetDlgItemText(hWnd, IDC_NAME, name, 0x80);
	for(int i = 0; i < len; i++)
		key += name[i];
	key = 0xC390 - (key - len);
	key = ((key + 0x400) << 0x10) | 0xBF56;
	sprintf(name, "%.X", key);
	SetDlgItemText(hWnd, IDC_SERIAL, name);
}

static BOOL CALLBACK DlgAbout(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
	case WM_INITDIALOG:
		SetDlgItemText(hwnd, IDC_EDIT1, "2005 - 07 - 23");
		SetDlgItemText(hwnd, IDC_EDIT2, "Knight");
		SetDlgItemText(hwnd, IDC_EDIT3, "b2c_2k5 (b2c_2k5.exe)");
		break;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDOK:
			EndDialog(hwnd, 0);
			break;
		}
		break;
	default:
		return FALSE;
	}
	return true;
}

static BOOL CALLBACK DlgFunc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
	case WM_INITDIALOG:
		SendMessage(hwnd, WM_SETICON, ICON_SMALL, (LPARAM)LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1)));
		SendMessage(hwnd, WM_SETICON, ICON_BIG, (LPARAM)LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1)));
		return TRUE;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDC_BEXIT:
			EndDialog(hwnd, 0);
			break;
		case IDC_BABOUT:
			DialogBox(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_ABOUT), hwnd, DlgAbout);
			break;
		case IDC_BGEN:
			Generate(hwnd);
			break;
		}
		break;
	case WM_CLOSE:
		EndDialog(hwnd, 0);
	default:
		return FALSE;
	}
	return TRUE;
}

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	return DialogBox(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, DlgFunc);
}
