#include <iostream>

using namespace std;

void printSerial(string username){
    int len=username.length();
    int code;
    for(int i=0;i<len&&i<10;i++){
                       code=username[i]%10;
                       code^=i;
                       code+=2;
                       if(code>=10) code=code-10;
                       cout<<(char)(code+10*7);
    }
}


int main(){
    string username;
    int i=0;
    int len,code;
    cout<<"user:\t";
    cin>>username;
    cout<<"key:\t";
    printSerial(username);
    cout<<endl;
    system("pause");
}
