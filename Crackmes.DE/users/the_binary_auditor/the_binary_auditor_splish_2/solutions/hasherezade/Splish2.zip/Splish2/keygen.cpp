#include <iostream>

using namespace std;

void printSerial(string username){
    int len=username.length();
    char code=0, b=0;
    char* key=new char[len+1];
    key[len]='\0';
    
    for(int i=len;i>0;i--){ //big loop
            code=username[i-1];
            do{ //small loop
               b++;
               code^=b;
            }while(code<'D'||code >'M');    
            
            code-=20;
            key[i-1]=code;
    }
    cout<<key;
}


int main(){
    string username;
    int i=0;
    int len,code;
    cout<<"user:\t";
    cin>>username;
    cout<<"key:\t";
    printSerial(username);
    cout<<endl;
    system("pause");
}
