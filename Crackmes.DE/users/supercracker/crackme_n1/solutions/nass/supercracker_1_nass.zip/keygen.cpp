#ifdef __BORLANDC__
  #pragma argsused
#endif

#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>

int main( int argc, char * argv[] )
{
  int userLen, x;
  signed long a;
  unsigned char userName[1000];
  unsigned char userSerial[1000];
  unsigned char tempSerial[50];

  memset(userName, 0, 1000);
  memset(userSerial, 0, 1000);

  printf("Keygen by NaSS\n\nEnter your name: ");
  scanf("%s", userName);
  userLen = strlen(userName);

  for (x=0; x<userLen; x++)
  {
    a = userName[x];
    a = a * 0x8EAE5;
    a = a ^ 0x6F37F;
    a = a / 0x130F;
    a = a * 0x1F4;
    a = a * 0x14D3;
    a = a - 0x6F5BB;
    a = abs(a);
    //
    sprintf(tempSerial, "%d", a);
    strcat(userSerial, tempSerial);
  }

  printf("Your serial is: %s\n\n", userSerial);
  system("PAUSE");

  return 0;
}
