 #include <stdio.h>
 
  int main()
 {
 int nbr1,nbr2;
 
 printf("****************************************************\n");
 printf(" Keygen for KeygenWoo KeygenMe by Neitsa [RIF]   \n");
 printf("****************************************************\n \n");
  
 //hmm, ok here's the main part of the keygen :)
 __asm {//asm inline
		mov eax,1
		CPUID
		mov nbr1,eax
		mov nbr2,ebx
	 }

   printf("Serial: %08lX-666-%08lX29A",nbr1,nbr2);
   printf("\n\n   Press ENTER to exit \n\n");
   getchar();
   
   return 0;  
 }