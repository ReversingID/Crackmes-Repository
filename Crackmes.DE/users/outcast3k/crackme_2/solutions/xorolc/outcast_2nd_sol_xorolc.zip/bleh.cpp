#include <windows.h>
#include <stdio.h>
#include <string.h>

int main(){

unsigned char Name[50]={0};
unsigned char Code[25]={0};
unsigned long mn=0,mn2=0x53,tmp,tmp2;
unsigned int i;
	

printf("Please enter your name: ");
gets(Name);

for(i=0;i<strlen(Name);i++){
tmp=Name[i]*(i + 1);
tmp2=(i + 1) *0x13;
tmp2=(tmp2*2)+0x3;
mn=tmp*tmp2;
mn2+=mn*tmp2;
}

sprintf(Code,"%d",mn2);
strcat(Code,"-Oc3k");
printf("Your Code is: %s",Code);
getchar();

return 0;
}