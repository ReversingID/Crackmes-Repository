/*** OutCast3k Crackme #2 Keygen by Sphinx [04/25/2001] ********************/

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

void main()
{
  char Name[17];
  unsigned long int RealCode,eax,ebx,esi,tmp;
  int i;

  puts("\nOutCast3k Crackme #2 Keygen by Sphinx [04/25/2001]\n");

  Name[0] = 16;
  printf("Enter your name: ");
  cgets(Name);
  if (Name[1] < 1)
  {
   printf("\nError: Name should be >= 1 character.\n");
   exit(0);
  }

  ebx = 1;
  RealCode = 0x53;
  for (i = 2; i <= Name[1]+2; i++)
  {
    eax = Name[i];
    eax = eax * ebx;
    tmp = eax;
    eax = ebx * 0x13;
    eax = eax + eax;
    eax = eax + 0x3;
    esi = eax;
    eax = tmp;
    eax = eax * esi;
    eax = eax * esi;
    RealCode = RealCode + eax;
    ebx++;
  }

  printf("\nRegistration #1: 13028-31x23e93-z14d20");
  printf("\nRegistration #2: %lu-Oc3k\n", RealCode);
}
