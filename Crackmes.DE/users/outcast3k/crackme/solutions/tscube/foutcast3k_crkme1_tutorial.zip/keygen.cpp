// Keygen for OutCast3k Crackme #1 by TSCube 23/12/2000

#include <stdio.h>
#include <string.h>

int main(void)
{
	char name[100];
	unsigned int serial;
	unsigned char namelen;

	puts("Keygen for OutCast3k Crackme #1 by TSCube 23/12/2000\n");

	printf("Name : ");
	gets(name);
	namelen = strlen(name);

	if (namelen<2)
	{
		puts("At least 2 letters please !");
		return 1;
	}

	__asm
	{
	xor edi,edi
	mov bl,01h

loop1:
	lea eax,name
	xor edx, edx
	mov dl, bl
	movzx eax, byte ptr [eax+edx-01]
	mov edx, eax
	shl eax, 0Eh
	add eax, edx
	add edi, eax
	inc ebx
	cmp bl, byte ptr [namelen]
	jbe loop1

	lea eax,name
	movzx eax, byte ptr [eax+01]
	imul eax, 0C13h
	sar eax, 01h
	jns next1
	adc eax, 00h

next1:
	imul ebx, eax, 0533h
	add ebx, 1FF6h
	lea eax,name
	movzx eax, byte ptr [eax]
	add ebx, eax
	imul edi, ebx
	mov dword ptr[serial],edi
	}

	printf("Unlock code = 001182102\n");
	printf("Serial : %08X",serial);

	puts("\n\n<enter> to finish");
	getchar();

	return 0;
}