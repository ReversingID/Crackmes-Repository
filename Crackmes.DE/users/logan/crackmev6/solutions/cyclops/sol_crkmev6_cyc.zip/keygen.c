/*
	Keygen for [Crackme V6 by Logan] By Cyclops
	Protection: Some anti debug+straight serial generation
*/

#include <stdio.h>

main()
{
	char name[25];
	char serial[25];
	int edi=16;				;//fixed serial length
	int len,i=0,cntr;
	unsigned char temp;

	printf("Enter ur name:");
	fgets(name,25,stdin);
	len=strlen(name);
	name[--len]=0x00;			//get rid of '\n'
	if(len<4)					//len<4 == no serial :P
	{
		printf("Name should be more than 4 chars!!!\n");
		return -1;
	}
	printf("Serial: ");
	for(cntr=0;cntr<edi;cntr++)
	{							//Serial Calculation
		temp=name[i]-edi;		//}
		temp+=cntr;				// }->printf("%c",name[i]-edi+cntr+len+1);
		temp+=len+1;			//}
		printf("%c",temp);
		i++;
		if(i==4)				//Only 4 chars :)
			i=0;
	}
	printf("\n");
	getchar();
	return 0;
}