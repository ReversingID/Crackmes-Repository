// logan's CrackmeV5 sol.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <conio.h>
#include <string.h>
using namespace std;
void getSerial(void);
char getHash(char x,bool f);
char name[10] = {0};
char serial[15] = {0};
unsigned long count = 0;

int _tmain(int argc, _TCHAR* argv[])
{
	cout << "Solution to logan's CrackmeV5 By - TELOPHASE/TEAM ICU" << endl;
	cout << "\t\t\twww.teamicu.org" << endl;
	cout << "Enter Name(5 chars only): ";
	cin >> name;
	if ( strlen(name) > 5)
	{	
		cout << "Name Should Be Only 5 Chars Long";
		getch();
		exit(0);
	}
	getSerial();
	cout << "Serial(11 chars): " << serial;
	getch();
	return 0;
}

void getSerial(void)
{
	int i = 0;
	while(i < 5)
	{
		count = i;
		serial[i] = getHash(name[i],true);
		i++;
	}
	serial[i] = '-';
	i = 0;
	while(i < 5)
	{
		count = i;
		serial[i+6] = getHash(name[i],false);
		i++;
	}
	
}
char getHash(char x, bool f)
{
	unsigned long t = x;
	unsigned long tt = f;
	char z = ' ';
	__asm
	{
					MOV ESI,t
					XOR EDI,EDI
hash:
		            MOV ECX,ESI
					MOV EBX,0AH
					MOV EAX,ECX
		            CDQ
		            IDIV EBX
				    MOV EAX,66666667H
		            ADD EDI,EDX
		            IMUL ECX
			        SAR EDX,2
		            MOV EAX,EDX
			        SHR EAX,1FH
		            ADD EDX,EAX
				    MOV ESI,EDX
					JNZ short hash
					MOV t,edi
	}

	if(f)
	{
		t += unsigned long(name[count] - count);
	}
	else
	{
		t += unsigned long((name[count]- count)-6);
	}
	z = (char) t;
	return z;
}