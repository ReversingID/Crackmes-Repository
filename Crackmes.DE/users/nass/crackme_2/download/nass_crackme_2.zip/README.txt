NaSS
Crackme 2
June 28th 2004
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Another pure win32 asm crackme.
Protection: name/serial only



Files Included:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

NaSS_2.exe		The crackme executable file
README.txt		The explanations about this crackme.



Tasks:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

1: Find a valid serial for your name (that should be quite easy)
2: code a keygen (a little bit harder... you'll see)



Allowed:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

No patching (useless for the keygen, anyway)
No bruteforcing
Everything else is just fine

Good Luck, and most important, have fun.



Greetings to kao and .Goolum for their solutions to my Crackme#1

-- 
NaSS
