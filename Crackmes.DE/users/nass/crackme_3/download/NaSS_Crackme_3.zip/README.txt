NaSS
Crackme 3
August 13th 2004
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This is my third crackme, written purely in MASM. I do not think this is a hard crackme.
But (I think, you'll tell me later) that it is original. And that can make it harder
for beginners.

Anyway, I really had fun coding it (as for the two previous crackmes), and I hope you'll have
fun cracking it.


Files Included:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

NaSS_3.exe      The crackme file
README.txt      The instructions


Tasks:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Make the crackme say "You did it". Only then you will have defeated the crackme and be able to
send a tutorial to crackmes.de

Allowed:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

You are not allowed to patch the EXE, nor to use a loader.
The rest is up to you.

Final word:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

If you have any question, ot find bug in the crackme (though I tested it), please send me a mail.
You'll find my email on www.crackmes.de

And don't forget:
If you can't eat it, if you can't fuck it, piss on it !