#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void GetNameValues(char * name, int * results);
void sub_40128A(unsigned int a, unsigned int b, unsigned int c, unsigned int d, unsigned int * results);
void sub_401269(unsigned int a, unsigned int b, unsigned int c, unsigned int d, unsigned int * results);

int main(void) 
{
    char username[] = "username";
    unsigned int * NamesValues;
    unsigned int * AddValues;
    unsigned int * MultValues;
    unsigned int * Serial;

    NamesValues = malloc(4 * sizeof(int));
    AddValues = malloc(2 * sizeof(int));
    MultValues = malloc(2 * sizeof(int));
    Serial = malloc(4 * sizeof(int));
    
    GetNameValues(username, NamesValues);
    sub_401269(NamesValues[0], NamesValues[1], NamesValues[2], NamesValues[3], AddValues);
    sub_40128A(NamesValues[0], NamesValues[1], NamesValues[2], NamesValues[3], MultValues);

    Serial[0] = AddValues[0];
    Serial[1] = AddValues[1];
    Serial[2] = MultValues[0];
    Serial[3] = MultValues[1];
    
    printf("%08x-%08x-%08x-%08x\n\n", Serial[0], Serial[1], Serial[2], Serial[3]);

    return 0;
}

void sub_40128A(unsigned int a, unsigned int b, unsigned int c, unsigned int d, unsigned int * results)
{
    unsigned int x, y, ans1, ans2;
    x = a * c;
    y = b * d;
    ans1 = x - y;

    x = a * d;
    y = b * c;
    ans2 = x + y;

    results[0] = ans1;
    results[1] = ans2;
}

void sub_401269(unsigned int a, unsigned int b, unsigned int c, unsigned int d, unsigned int * results)
{
    results[0] = a + c;
    results[1] = b + d;
}

void GetNameValues(char * name, int * results)
{
    int len = strlen(name);

    int nameSum = 0;

    for(int c = 0; c < len; c++)
    {
        nameSum += (int)name[c];
    }

    int nameMul = (nameSum - 1);
    nameMul *= 3;

    unsigned int nameShift = 0x12345678;
    
    for(int c = 0; c <= len; c++)
    {
        //printf("nameShift: 0x%x\n", nameShift);
        nameShift ^= name[c];
        //printf("      XOR: 0x%x   (nameShift ^ \'%c\' [0x%x])\n", nameShift, name[c], name[c]);
        //nameShift = (nameShift << 1) | (nameShift >> (sizeof(unsigned int) * 8 - 1));
        //printf("      ROL: 0x%x\n", nameShift);
        //nameShift = (nameShift << 1) | (nameShift >> (sizeof(unsigned int) * 8 - 1));
        //printf("      ROL: 0x%x\n", nameShift);
        //nameShift = (nameShift << 1) | (nameShift >> (sizeof(unsigned int) * 8 - 1));
        //printf("      ROL: 0x%x\n", nameShift);
        //nameShift = (nameShift << 1) | (nameShift >> (sizeof(unsigned int) * 8 - 1));
        //printf("      ROL: 0x%x\n", nameShift);
        //nameShift = (nameShift << 1) | (nameShift >> (sizeof(unsigned int) * 8 - 1));
        //printf("      ROL: 0x%x\n", nameShift);
        //printf("ROL(5): 0x%x\n", nameShift);
        //printf("-------------------------------------------\n");
        nameShift = (nameShift << 5) | (nameShift >> (sizeof(unsigned int) * 8 - 5));
    }

    int quo = nameShift;
    nameShift %= (unsigned int)0x7a69;
    quo /= (unsigned int)0x7a69;
    int nameAnd = quo & 0x0FFF;
    
    results[0] = nameSum;
    results[1] = nameMul;
    results[2] = nameShift;
    results[3] = nameAnd;
}
