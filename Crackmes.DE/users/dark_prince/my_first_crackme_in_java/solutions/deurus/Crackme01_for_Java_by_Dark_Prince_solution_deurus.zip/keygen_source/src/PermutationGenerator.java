import java.util.ArrayList;
import java.util.Iterator;

public class PermutationGenerator
{

    public PermutationGenerator(String aWord)
    {
        word = aWord;
    }

    public ArrayList getPermutations()
    {
        ArrayList result = new ArrayList();
        if(word.length() == 0)
        {
            result.add(word);
            return result;
        }
        for(int i = 0; i < word.length(); i++)
        {
            String shorterWord = (new StringBuilder()).append(word.substring(0, i)).append(word.substring(i + 1)).toString();
            PermutationGenerator shorterPermutationGenerator = new PermutationGenerator(shorterWord);
            ArrayList shorterWordPermutations = shorterPermutationGenerator.getPermutations();
            String s;
            for(Iterator i$ = shorterWordPermutations.iterator(); i$.hasNext(); result.add((new StringBuilder()).append(word.charAt(i)).append(s).toString()))
                s = (String)i$.next();

        }

        return result;
    }

    private String word;
}
