import java.util.ArrayList;

public class Dark
{

    public Dark()
    {
    }

    public String StrM(String s1, String cmp, int c1)
    {
        s1 = s1.substring(0, 5);
        PermutationGenerator pm = new PermutationGenerator(s1);
        ArrayList permut = pm.getPermutations();
        s2 = (String)permut.get(3);
        s3 = (String)permut.get(10);
        s4 = (String)permut.get(17);
        ch1 = s2.charAt(3);
        ch2 = s3.charAt(3);
        ch3 = s4.charAt(3);
        n1 = ch1;
        n2 = ch2;
        n3 = ch3;
        c1 <<= 2;
        c2 = c1 & 0xff;
        c3 = c1 ^ c2;
        c4 = c1 | c3;
        d = c2 * 2 + c3 * 3 + c4 * 4 + n1 * 10 + n2 * 11 + n3 * 12;
        s5 = String.valueOf(d);
        s6 = s5;
        s5 = s5.substring(0, 2);
        y = Integer.parseInt(s5);
        y1 = Integer.parseInt(s6);
        int a[][] = {
            {
                2, 2, y
            }, {
                4, 6, 2
            }, {
                3, 4, 4
            }
        };
        int b[][] = {
            {
                2, 2, 3
            }, {
                8, 9, 5
            }, {
                6, 2, 2
            }
        };
        int c[][] = new int[3][3];
        for(int i = 0; i < 3; i++)
        {
            for(int j = 0; j < 3; j++)
            {
                c[i][j] = 0;
                for(int k = 0; k < 3; k++)
                    c[i][j] = c[i][j] + a[i][k] * b[k][j];

            }

        }

        y2 = c[2][2];
        y2 = y2 * y1;
        return String.valueOf(y2);
    }

    
    String s2;
    String s3;
    String s4;
    String s5;
    String s6;
    int c2;
    int c3;
    int c4;
    int n1;
    int n2;
    int n3;
    int d;
    int y;
    int y1;
    int y2;
    char ch1;
    char ch2;
    char ch3;
}
