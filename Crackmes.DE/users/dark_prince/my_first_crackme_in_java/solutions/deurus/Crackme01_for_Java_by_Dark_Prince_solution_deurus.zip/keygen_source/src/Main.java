import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

public class Main extends JFrame
{

    public Main()
    {
        initComponents();
    }

    private void initComponents()
    {
        jDialog1 = new JDialog();
        jPanel1 = new JPanel();
        jLabel1 = new JLabel();
        t1 = new JTextField();
        jLabel2 = new JLabel();
        t2 = new JTextField();
        jLabel3 = new JLabel();
        c1 = new JComboBox();
        done = new JButton();
        clear = new JButton();
        GroupLayout jDialog1Layout = new GroupLayout(jDialog1.getContentPane());
        jDialog1.getContentPane().setLayout(jDialog1Layout);
        jDialog1Layout.setHorizontalGroup(jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGap(0, 400, 32767));
        jDialog1Layout.setVerticalGroup(jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGap(0, 300, 32767));
        setDefaultCloseOperation(3);
        setTitle("Crackme01 - Keygen by deurus");
        setBounds(new Rectangle(400, 200, 0, 0));
        setResizable(false);
        jPanel1.setBorder(BorderFactory.createTitledBorder(null, "Another keygen by deurus", 0, 2, new Font("Times New Roman", 0, 10)));
        jLabel1.setText("Name:");
        jLabel2.setText("Key:");
        jLabel3.setText("Your Country:");
        c1.setModel(new DefaultComboBoxModel(new String[] {
            "Australia", "Brazil", "Egypt", "Germany", "India", "Mexico", "Other"
        }));
        done.setText("Generate");
        done.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent evt)
            {
                doneActionPerformed(evt);
            }

            final Main this$0;

            
            {
                this$0 = Main.this;
                //super();
            }
        }
);
        clear.setText("Clear");
        clear.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent evt)
            {
                clearActionPerformed(evt);
            }

            {
            }
        }
);
        GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addGap(26, 26, 26).addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(jLabel2, -2, 71, -2).addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(jLabel1).addComponent(t1, -2, 149, -2).addComponent(t2, -2, 149, -2)).addGap(33, 33, 33).addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false).addComponent(jLabel3).addGroup(jPanel1Layout.createSequentialGroup().addComponent(done, -2, 61, -2).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(clear, -2, 61, -2)).addComponent(c1, 0, -1, 32767)))).addContainerGap(30, 32767)));
        jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE).addComponent(jLabel1).addComponent(jLabel3)).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE).addComponent(t1, -2, -1, -2).addComponent(c1, -2, -1, -2)).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED).addComponent(jLabel2).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE).addComponent(t2, -2, -1, -2).addComponent(done).addComponent(clear)).addContainerGap(36, 32767)));
        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addComponent(jPanel1, -2, -1, -2).addContainerGap(-1, 32767)));
        layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addComponent(jPanel1, -2, -1, -2).addContainerGap(-1, 32767)));
        pack();
    }

    private void doneActionPerformed(ActionEvent evt)
    {
        String str2 = null;
        int m = 0;
        int sum = 0;
        String cmp = t2.getText();
        String str1 = t1.getText();
        c1.getSelectedItem();
        Object selectedItem = c1.getSelectedItem();
        if(selectedItem != null)
            str2 = selectedItem.toString();
        for(int i = 0; i < str1.length(); i++)
            if(Character.isLetter(str1.charAt(i)))
            {
                m = str1.charAt(i);
                sum += m;
            }

        Dark dr = new Dark();
        t2.setText(dr.StrM(str2, cmp, sum));
    }

    private void clearActionPerformed(ActionEvent evt)
    {
        t1.setText("");
        t2.setText("");
    }

    public static void main(String args[])
    {
        try
        {
            javax.swing.UIManager.LookAndFeelInfo arr$[] = UIManager.getInstalledLookAndFeels();
            int len$ = arr$.length;
            int i$ = 0;
            do
            {
                if(i$ >= len$)
                    break;
                javax.swing.UIManager.LookAndFeelInfo info = arr$[i$];
                if("Nimbus".equals(info.getName()))
                {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
                i$++;
            } while(true);
        }
        catch(ClassNotFoundException ex)
        {
            //Logger.getLogger(Main.getName()).log(Level.SEVERE, null, ex);
        }
        catch(InstantiationException ex)
        {
        	//Logger.getLogger(Main.getName()).log(Level.SEVERE, null, ex);
        }
        catch(IllegalAccessException ex)
        {
        	//Logger.getLogger(Main.getName()).log(Level.SEVERE, null, ex);
        }
        catch(UnsupportedLookAndFeelException ex)
        {
        	//Logger.getLogger(Main.getName()).log(Level.SEVERE, null, ex);
        }
        EventQueue.invokeLater(new Runnable() {

            public void run()
            {
                (new Main()).setVisible(true);
            }

        }
);
    }

    private JComboBox c1;
    private JButton clear;
    private JButton done;
    private JDialog jDialog1;
    private JLabel jLabel1;
    private JLabel jLabel2;
    private JLabel jLabel3;
    private JPanel jPanel1;
    private JTextField t1;
    private JTextField t2;


}
