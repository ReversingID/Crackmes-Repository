#include <Windows.h>
#include <stdio.h>

typedef signed short int sint16_t;
typedef unsigned short int uint16_t;
typedef unsigned char uchar;

uint16_t mul(uint16_t a, uint16_t b)
{
	return ((a * b) & 0x07FFF);
}

uint16_t add(uint16_t a, uint16_t b)
{
	int res = ((a + b) & 0x07FFF);
	return res;
}

uint16_t hash(char *str, int t)
{
	int len = strlen(str);
	uint16_t rhash = 0;
	for (int i = 0; i < len; ++i)
		rhash = add(rhash + t, add(mul((uchar)str[i], 0x5557), (((uchar)str[i] & 0x1eef) | 0x5557)));
	return rhash;
}

int main(int argc, char* argv[])
{
	char str[32];
	int len = 32;
	while (len > 16)
	{
		printf("Enter name (length must be less than 16): ");
		scanf("%s", str);
		len = strlen(str);
		if (len > 16)
			printf("Name too long. Try again\n");
	}
	printf("Your key is: ");
	for (int i = 0; i < 8; ++i)
		printf("%02x", hash(&str[i % len], i) % 0xFF);
	getchar();
	getchar();
	return 0;
}

