Coded by Rue.

Lambda KeygenMe

My second KeygenMe, this one is considerably
harder than my first one, coded in C++ using
some C++11 features.

Rules:
[+] Keygen
[-] No Patching

Contact: rue.virii@gmail.com