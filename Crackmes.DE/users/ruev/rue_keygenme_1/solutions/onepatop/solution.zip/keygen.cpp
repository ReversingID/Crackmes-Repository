//Create a new C++ CLR Console project and copy this in your main cpp file.
#include "stdafx.h"

using namespace System;
using namespace System::Security::Cryptography;
using namespace System::Text;

String^ getMD5String(String^ inputString)
{
 array<Byte>^ byteArray = Encoding::ASCII->GetBytes(inputString);
 MD5CryptoServiceProvider^ md5provider = gcnew MD5CryptoServiceProvider();
 array<Byte>^ byteArrayHash = md5provider->ComputeHash(byteArray);
 return BitConverter::ToString(byteArrayHash);
}

int main(array<System::String ^> ^args)
{
 String^ username;
 Console::WriteLine("Username:");
 username =Console::ReadLine();
 username=getMD5String(username);
 Console::WriteLine("MD5 HASH:");
 Console::WriteLine(username);

 array<Char>^destination = {' ','0',' ','1',' ','0',' ','1',' ','0',' ','0',' ','0',' ','0',' ','0',' ','1',' ','0',' ','1',' ','0',' ','0',' ','0',' ','0','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x'};

 int n=0;
 int i=0;
 for(i=0;i<24;i++){
	 if(i%3!=0){
   username->CopyTo( i-1, destination, n, 1 );
   n+=2;
	 }
 }
	 n=32;
	 for(i=24;i<48;i++){
	 if((i%3)!=0){
   username->CopyTo( i-1, destination, n, 1 );
   n++;
	 }
	 }
	
   Console::WriteLine("Serial:");
   Console::WriteLine( destination );
   Console::ReadKey();
 return 0;
}
