﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.Windows.Forms;

namespace Keygen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void generate_serialClick(object sender, EventArgs e)
        {
            int[] randomnumerics = new int[16];
            char[] serialchar = new char[48];
            byte[] md5bytes = MD5.Create().ComputeHash(Encoding.ASCII.GetBytes(name.Text));
            char[] md5char = BitConverter.ToString(md5bytes).Replace("-", "").ToCharArray();
            
            for (int i = 0; i < 0x10; i++) serialchar[i * 2] = md5char[i];
            for(int i=0x10;i<0x20;i++) serialchar[i+0x10]=md5char[i];

            Random rn = new Random();
            for (int i = 0; i < 16; i++) randomnumerics[i] = rn.Next(0, 10);
            for (int i = 0; i < 3; i++)
            {
                if (((randomnumerics[i] + randomnumerics[i + 1]) % 2) == 0) randomnumerics[i + 1]++;
                randomnumerics[i + 1] %= 10; 
            }
            for (int i = 4; i < 7; i++)
            {
                if (((randomnumerics[i] + randomnumerics[i + 1]) % 2) == 1) randomnumerics[i + 1]++;
                randomnumerics[i + 1] %= 10;
            }
            for (int i = 8; i < 11; i++)
            {
                if (((randomnumerics[i] + randomnumerics[i + 1]) % 2) == 0) randomnumerics[i + 1]++;
                randomnumerics[i + 1] %= 10;
            }
            for (int i = 12; i < 15; i++)
            {
                if (((randomnumerics[i] + randomnumerics[i + 1]) % 3) == 1) randomnumerics[i + 1]++;
                randomnumerics[i + 1] %= 10;
            }
 
            for (int i = 0; i < 0x10; i++) serialchar[i * 2 + 1] = Convert.ToChar(randomnumerics[i]+0x30);
            serial.Text = new string(serialchar);
        }
    }
}
