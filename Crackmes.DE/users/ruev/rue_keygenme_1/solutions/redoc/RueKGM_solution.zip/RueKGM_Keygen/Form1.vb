﻿Public Class Form1

	Public Function MD5Hash(ByVal input As String) As String
		Dim buffer As Byte() = System.Security.Cryptography.MD5.Create.ComputeHash(System.Text.Encoding.ASCII.GetBytes(input))
		Dim str As String = String.Empty
		Dim i As Integer

		For i = 0 To buffer.Length - 1
			str = (str & buffer(i).ToString("X2"))
		Next i
		Return str
	End Function

	Private Function Generate() As String
		Dim szMD5Hash As String = Me.MD5Hash(Me.txtName.Text)
		Dim szSerial As String = "444444444444444444444444444444444444444444444444"
		Dim i As Integer, intNum As Integer

		For i = 1 To 16
			Mid(szSerial, (i * 2) - 1, 1) = Mid(szMD5Hash, i, 1)
		Next (i)

		For i = 33 To 48
			Mid(szSerial, i, 1) = Mid(szMD5Hash, i - 16, 1)
		Next i

		i = 1
		Do While (i < 7)
			intNum = Integer.Parse(szSerial.Substring((i + 2), 1))
			If (((Integer.Parse(szSerial.Substring(i, 1)) + intNum) Mod 2) = 0) Then
				Mid(szSerial, i + 3, 1) = Asc(intNum + 1)
			End If
			i = (i + 2)
		Loop

		i = 9
		Do While (i < 15)
			intNum = Integer.Parse(szSerial.Substring((i + 2), 1))
			If (((Integer.Parse(szSerial.Substring(i, 1)) + intNum) Mod 2) = 1) Then
				Mid(szSerial, i + 3, 1) = Asc(intNum + 1)
			End If
			i = (i + 2)
		Loop

		i = 17
		Do While (i < 22)
			intNum = Integer.Parse(szSerial.Substring((i + 2), 1))
			If (((Integer.Parse(szSerial.Substring(i, 1)) + intNum) Mod 2) = 0) Then
				Mid(szSerial, i + 3, 1) = Asc(intNum + 1)
			End If
			i = (i + 2)
		Loop

		i = 25
		Do While (i < 31)
			intNum = Integer.Parse(szSerial.Substring((i + 2), 1))
			If (((Integer.Parse(szSerial.Substring(i, 1)) + intNum) Mod 3) = 1) Then
				Mid(szSerial, i + 3, 1) = Chr(intNum + 1)
			End If
			i = (i + 2)
		Loop

		Return szSerial
	End Function


	Private Sub ButtonGenerate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonGenerate.Click
		txtSerial.Text = Generate()
	End Sub

End Class
