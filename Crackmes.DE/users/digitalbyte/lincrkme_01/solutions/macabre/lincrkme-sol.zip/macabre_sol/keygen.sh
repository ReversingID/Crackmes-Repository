#!/bin/sh
function reverse()
{
	string=$1
	len=$(echo -n $string | wc -c)
	while test $len -gt 0
	do
	rev=$rev$(echo $string | cut -c $len)
	len=$(( len - 1 ))
	done
	echo $rev
}

if [ -z $1 ]; then
   echo "Usage: $0 <username>"
   exit 1
fi

echo "username: $1"
echo -n "serial: "
reverse $1
