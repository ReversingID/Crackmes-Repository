/*
		keygen for [mars by [_j_]] by Cyclops
		http://cyclops.ueuo.com
		Protection: SHA512+DH
*/
#include<stdio.h>
#include<windows.h>
#include "miracl.h"

main()
{
	FILE *fp;
	unsigned long vol;
	unsigned char szVol[10],hash[80];
	char temp[300];
	miracl *mip;

	big bHash,bLine1,bLine2,bLine3,bExp,bBase;
	sha512 sh;
	int i=0;
	mip=mirsys(0x64,0);
	mip->IOBASE = 16;
	bHash=mirvar(0);
	bLine1=mirvar(0);
	bLine2=mirvar(0);
	bLine3=mirvar(0);
	bExp=mirvar(0x12341234);
	bBase=mirvar(3);

	GetVolumeInformation(0,0,0,&vol,0,0,0,0);
	sprintf(szVol,"%x",vol);
	shs512_init(&sh);
	while(szVol[i])
	{
		shs512_process(&sh,szVol[i]);
		i++;
	}
	shs512_hash(&sh,hash);
	bytes_to_big(0X40,hash,bHash);
	while(isprime(bHash)!=1)
		incr(bHash,1,bHash);

	fp=fopen("userkey.txt","r+");
	if(!fp)
	{
		printf("Error!,Cant read the file!");
		return -1;
	}
	fgets(temp,300,fp);
	cinstr(bLine1,temp);
	powmod(bBase,bExp,bHash,bLine2);
	powmod(bLine1,bExp,bHash,bLine3);
	cotstr(bLine2,temp);
	fputs("\n",fp);
	fputs(temp,fp);
	cotstr(bLine3,temp);
	fputs("\n",fp);
	fputs(temp,fp);
	fclose(fp);
	mirkill(bHash);
	mirkill(bLine1);
	mirkill(bLine2);
	mirkill(bLine3);
	mirkill(bExp);
	mirkill(bBase);

	return 0;
}



