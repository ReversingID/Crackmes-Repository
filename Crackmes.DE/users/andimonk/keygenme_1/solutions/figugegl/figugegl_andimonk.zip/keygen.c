/*************************************************************************

 Filename:		Keygen.c
 Purpose:		Keygen for AndiMonk Keygenme #1
 Author:		figugegl
 Version:		1.0
 Date:			26.10.2001

*************************************************************************/


/*------------------------------------------------------------------------
	Include files
------------------------------------------------------------------------*/
#include <windows.h>
#include <stdio.h>
#include "keygenres.h"
#include "math.h"


/*------------------------------------------------------------------------
	Prototypes
------------------------------------------------------------------------*/
LRESULT CALLBACK MainDlgProc	(HWND, UINT, WPARAM, LPARAM) ;



/*------------------------------------------------------------------------
	Global variables
------------------------------------------------------------------------*/


/*------------------------------------------------------------------------
 Procedure:     WinMain
 Purpose:       Application entry point. Registers a class of the same
                type than the dialog class,calls DialogBox and then exits
 Input:         Standard
 Output:        None
 Errors:        None
------------------------------------------------------------------------*/
int WINAPI WinMain (HINSTANCE hInst, HINSTANCE hPrevInst, PSTR szCmdLine, int CmdShow)
{
	static TCHAR	szAppName[] = TEXT ("keygen") ;
	WNDCLASS		wc ;

	memset (&wc, 0, sizeof (wc));					// fill structure wndclass with '0'

	wc.lpfnWndProc		= MainDlgProc ;				// callback procedure
	wc.cbWndExtra		= DLGWINDOWEXTRA ;
	wc.hInstance		= hInst ;
	wc.hIcon			= LoadIcon (hInst, MAKEINTRESOURCE (ICO_FIGU)) ;
	wc.hCursor			= LoadCursor (NULL, IDC_ARROW) ;
	wc.hbrBackground	= (HBRUSH) (COLOR_BTNFACE + 1) ;
	wc.lpszClassName	= szAppName ;

	RegisterClass (&wc);

	return DialogBox (hInst, MAKEINTRESOURCE (DLG_MAIN), NULL, (DLGPROC) MainDlgProc);
}


/*------------------------------------------------------------------------
 Procedure:     CalculateSerial
 Purpose:       Calculate a valid serial
 Input:         hWnd:	Handle of the Dialogbox
 Output:        None
 Errors:        None
------------------------------------------------------------------------*/
void CalculateSerial (HWND hWnd)
{
	char	szName[32];
	char	szSerial[12] = "";
	int		iNameLen;
	int		i;

	iNameLen = GetDlgItemTextA (hWnd, EDF_NAME, szName, 32);

	if (iNameLen < 6)
		SetDlgItemTextA (hWnd, EDF_SERIAL, NULL);
	else
	{
		if (iNameLen > 8)
			iNameLen = 8;
		for (i = 0; i < iNameLen; i++)
		{
			szSerial[i] =  0x31 + (szName[i] & 0xF) % 9;
		}

		SetDlgItemTextA (hWnd, EDF_SERIAL, szSerial);
	}
}


/*------------------------------------------------------------------------
 Procedure:     KeyFileAndRegistry
 Purpose:       Calculate serial for keyfile and registry
 Input:         hwnd:	Handle of the Dialogbox
 Output:        None
 Errors:        None
------------------------------------------------------------------------*/
void KeyFileAndRegistry (HWND hWnd)
{
	HANDLE 	hFile, hKey;
	char	szFileName[]		= "`";
	char	szRegSerial[8]		= "";
	char	szKeyFileSerial[32]	= "figugegl";
	char	szRegKey[]			= "\\AM";
	char	szSubKey[]			= "amkgme";
	int		cCountBytes			= 0;
	DWORD	dwResult;
	double	dSerial;
	int 	i, iRest, iSerial;

	// get serial from editfield and calculate serial for keyfile
	iSerial = GetDlgItemInt (hWnd, EDF_SERIAL, NULL, TRUE);
	for (i = 8; i < 28; i++)
	{
		iRest = iSerial % (-2);
		if (iRest < 0)
		{
			iRest = 1;
			iSerial -= 1;
		}
		cCountBytes += iRest;
		szKeyFileSerial[i] = iRest + 0x30;
		iSerial /= (-2);
		if (iSerial == 0)
		{
			break;
		}
	}

	//----- create keyfile and write string
	hFile = CreateFileA (szFileName, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	WriteFile (hFile, szKeyFileSerial, sizeof (szKeyFileSerial), &dwResult, NULL);
	CloseHandle (hFile);

	// get serial from editfield and calculate serial for registry
	iSerial = GetDlgItemInt (hWnd, EDF_SERIAL, NULL, TRUE);
	iSerial /= cCountBytes;
	dSerial = (double) sqrt (iSerial);
	wsprintfA (szRegSerial, "%d", (int) (dSerial));

	//----- update registry
	RegCreateKeyExA (HKEY_LOCAL_MACHINE, szRegKey, 0, 0, REG_OPTION_NON_VOLATILE, KEY_WRITE, 0, &hKey, &dwResult);
	RegSetValueExA (hKey, szSubKey, 0, REG_SZ, szRegSerial, sizeof (szRegSerial));
	RegCloseKey (hKey);

	MessageBoxA (hWnd, TEXT ("Keyfile and \nRegistry updated!"), TEXT ("Success"), MB_OK);
	return;
}


/*------------------------------------------------------------------------
 Procedure:     AboutDlgProc
 Purpose:       Handles the messages of the About-Window
 Input:         Standard
 Output:        TRUE if the message was processed
 Errors:        None
------------------------------------------------------------------------*/
LRESULT CALLBACK AboutDlgProc (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
     switch (message)
     {
     case WM_INITDIALOG:
          return TRUE ;

     case WM_COMMAND:
          if (LOWORD (wParam) == BUT_OK)
          {
               EndDialog (hDlg, 0) ;
               return TRUE ;
          }
          break ;
     }
     return FALSE ;
}


/*------------------------------------------------------------------------
 Procedure:     DialogFunc
 Purpose:       It handles all messages.
 Input:         Standard.
 Output:        TRUE if the message was processed
 Errors:        None
------------------------------------------------------------------------*/
LRESULT CALLBACK MainDlgProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	static TCHAR	szFigugegl[] = TEXT ("figugegl");

	switch (message)
	{
	case WM_INITDIALOG:
		SendDlgItemMessageA (hWnd, EDF_NAME, EM_LIMITTEXT, 20, 0);
		SetDlgItemTextA (hWnd, EDF_NAME, szFigugegl);
		return 0 ;

	case WM_COMMAND:
		switch (LOWORD (wParam))
		{
		case EDF_NAME:			// Namefield
			if (HIWORD (wParam) == EN_CHANGE)
			{
				CalculateSerial (hWnd);
		 		return 0;
			}
			break;

		case BUT_ABOUT:			// About
			DialogBox (NULL, MAKEINTRESOURCE (DLG_ABOUT), hWnd, (DLGPROC) AboutDlgProc);
			return 0;

		case BUT_KEYFILE:		// Keyfile button
			KeyFileAndRegistry (hWnd);
			return 0;
		}
		break;

	case WM_CLOSE:
		PostQuitMessage (0) ;
		return 0 ;
	}
	return DefWindowProc (hWnd, message, wParam, lParam) ;
}

