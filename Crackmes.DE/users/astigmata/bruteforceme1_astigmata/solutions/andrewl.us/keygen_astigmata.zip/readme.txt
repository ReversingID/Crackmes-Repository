brute.cu      the successful brute forcer in CUDA/C

stepX.jpg     visual steps on how to solve this crackme

solution.txt  some writeup drivel

.\failures\*  techniques that failed

log.html      a full log of when/what the bruter accomplished
logger.cgi    the cgi script that got reports from brute forcing machine and made the
              statistics you see in log.html

readme.txt    me!