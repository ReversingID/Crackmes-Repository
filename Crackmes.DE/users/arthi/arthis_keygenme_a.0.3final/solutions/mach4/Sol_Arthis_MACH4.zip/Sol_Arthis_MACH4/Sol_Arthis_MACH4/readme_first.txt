*******Solution by MACH4*********

Target: Arthi's Arthis Keygenme A.0.3Final

info:
Difficulty: 8 - *VERY VERY* hard
Platform: Windows
Language: (Visual) Basic

Published: 12. Oct, 2005
Downloads: 841

Solution:

20 Feb 2009

First part is the SWF Movie file.

Download swfOpener to view it, it resizes automatically to your desktop, free too!
info: http://www.unhsolutions.net/SWF-Opener/index.html
setup.exe: http://www.unhsolutions.net/downloads/SWFOpenerSetup.exe

Second part is the PDF file.

I tore this one apart to show that no VB program is safe,
but if something wasn't explained just post the question.

Greetz to crackmes.de and all members...

MACH4