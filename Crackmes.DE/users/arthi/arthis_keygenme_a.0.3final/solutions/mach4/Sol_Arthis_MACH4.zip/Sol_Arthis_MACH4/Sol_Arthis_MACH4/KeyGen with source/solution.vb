Option Explicit

Private Sub Command1_Click()

Dim name, buffer As String
Dim eax, esi, temp As Double
Dim counter1, ebp30 As Long
name = Text1.Text

If Len(name) = 0 Then
MsgBox ("Need an input!")
Text2.Text = ""
Exit Sub
End If

counter1 = 1
esi = 0
GoTo start2
start1:
counter1 = counter1 + 1
If (counter1 > Len(name)) Then
GoTo done
End If
esi = ebp30 * 2
start2:
esi = esi + -5708 + (Asc(Mid(name, counter1, 1)) * 123) + (Len(name) * 2 + 4266)
temp = esi + 5363763
esi = 55677
temp = temp + esi + 151413
ebp30 = temp
GoTo start1
done:
Text2.Text = Hex(temp) & (counter1 - 1)

End Sub
