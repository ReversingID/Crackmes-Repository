require "imageruby"

include ImageRuby

File.delete("key.bmp") if File.exists?("key.bmp")

puts "Enter your name:"

keys = [0, 0, 0]
name = gets.chomp


0.upto(name.size / 3) do |x|
	keys[0] += name[3*x+0].ord unless name[3*x+0].class == NilClass
	keys[1] += name[3*x+1].ord unless name[3*x+1].class == NilClass
	keys[2] += name[3*x+2].ord unless name[3*x+2].class == NilClass
end


template = Image.from_file("initial_pict.bmp") if File.exists?("initial_pict.bmp")

puts keys[0].to_s() + " " + keys[1].to_s() + " " + keys[2].to_s()

image = Image.new(128, 128 )


0.upto(127) do |i|
	0.upto(127) do |j|
		initial_color = template.get_pixel(i, j)
		output_color = initial_color
		output_color.r = (initial_color.r * 0.5 + keys[0] * 0.249).round
		output_color.g = (initial_color.g * 0.5 + keys[1] * 0.249).round
		output_color.b = (initial_color.b * 0.5 + keys[2] * 0.249).round
 		#puts output_color.r.to_s() + " " + output_color.g.to_s() + " " + output_color.b.to_s()
		image.set_pixel(i, j, output_color)

	end
end

image.save("key.bmp",:bmp)
puts "file: key.bmp has been generated!" if File.exists?("key.bmp")
