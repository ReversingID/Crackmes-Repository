
#define _CRT_SECURE_NO_WARNINGS

#undef UNICODE
#undef _UNICODE
#include <windows.h>
#include <CommCtrl.h>
#include "resource.h"
#include "main.h"

// definitions
#define	APP_NAME		"Polynomial's KeygenMe of impossibility"
#define	NAME_MAX		30
// prototypes
BOOL CALLBACK DialogProc(HWND  hwndDlg, UINT  uMsg, WPARAM  wParam, LPARAM  lParam );
void Generate (HWND hDlg);
void Test (HWND hDlg);

//----------------------------------------
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	InitCommonControls ();
	DialogBoxParam (hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, DialogProc, 0);
	return (0);
}

//----------------------------------------
BOOL CALLBACK DialogProc(HWND  hwndDlg, UINT  uMsg, WPARAM  wParam, LPARAM  lParam )
{
	switch (uMsg)
	{
		case WM_INITDIALOG:
		#ifdef NAME_MAX
			SendDlgItemMessage (hwndDlg, IDC_EDIT_NAME, EM_SETLIMITTEXT, NAME_MAX, 0);
		#endif
			return TRUE;

		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
				case IDC_BUTTON_GENERATE:
					Generate (hwndDlg);
					return TRUE;
				case IDC_BUTTON_TEST:
					//Test (hwndDlg);
					return TRUE;
				case IDCANCEL:
					EndDialog (hwndDlg, 0);
					return TRUE;
			}
			break;
	}
	return FALSE;
}
//----------------------------------------
void Generate (HWND hDlg)
{
	LARGE_INTEGER	liNum, liBuf;
	char szName[32]={0}, szSerial[10]={0}, cField[0x200]={0};
	DWORD dwLen;
	int i, intIdx, intBuf;

	dwLen = GetDlgItemText (hDlg, IDC_EDIT_NAME, szName, sizeof(szName));	// User Name
	if (dwLen == 0) return ;

	liBuf.QuadPart = 0x11B6F6B1098AB633;

_004011B0:
	for (i=0; i<0x200; i++)
	{
		intIdx = i % dwLen;
		intBuf = char(i & 0xFF);
		cField[i] = g_KeyTable[szName[intIdx]] ^ intBuf;
		if ((i > 0) && (cField[i-1] >= 0))
			cField[i] ^= g_KeyTable[cField[i-1]];
		intBuf = (i * i) - 11;
		__asm{ SAR DWORD PTR[intBuf],1 }
		cField[i] ^= intBuf;
	}

_00401280:
	for (i=0x10; i<0x1F0; i+=4)
		cField[i] *= cField[i+4];

_00401329:
	for (i=0; i<0x200; i+=8)
	{
		liNum.QuadPart = cField[i] + (cField[i+1] * 0xFF) + (cField[i+2] * 0xFF00) + (cField[i+3] * 0xFF0000);
		liNum.QuadPart += (cField[i+4] * 0xFF000000) + (cField[i+5] * 0xFF00000000) + (cField[i+6] * 0xFF0000000000) + (cField[i+7] * 0xFF000000000000);

		liBuf.QuadPart *= liNum.QuadPart;
		liBuf.QuadPart -= 1;

		liBuf.QuadPart ^= liNum.QuadPart;
	}
_004014FB:
	liBuf.QuadPart = ULONGLONG(liBuf.QuadPart) % 0xC8BE1499;
	liBuf.HighPart = 0;
	liBuf.LowPart ^= 0xC7D8E9F0;
	liBuf.QuadPart = ~liBuf.QuadPart;

	wsprintf (szSerial, "%08X", liBuf.LowPart);
	SetDlgItemText (hDlg, IDC_EDIT_SERIAL, szSerial);	// Serial
}
