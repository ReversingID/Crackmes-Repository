:::::::::::::::::Obnoxious's KeygenMe #1:::::::::::::::::

Well, i had been thinking of writing a keygenme for a long time n finally this is what i have to offer. i dd not hear any chiptunes in any of the .net crackmes, so i decided to put some music into mine. hope u guys like it.

Difficulty You Decide!
Language c#.net

::::rules::::
No patching.
No Bruteforcing.
Write a tut if u crack it!
For newbies its ok if u dont make a keygen!
But the bigGuns like MACH4,Jim~,costy,digital acid n the others should make a keygen.

Happy cracking
Thanks to all at crackmes.de