Obnoxious'sKGM +++[>+++<-]>+. :P

Crackeme  Difficulty: 2
Keygening Difficulty: 3+

Valid Solutions: Keygen(for pros). Smaller serials appreciated.
               : Name/Serial combination for noobs.


Patching allowed if your name's too long. Understand what i mean? :P

Objective: Get yourself a well sounding good boy message(min 2 words), simple :P The good boy must be in CAPITALS.

Greets to andrewl.us(yup the javascript crackme will come in the next few days), brother cyclops :P, br0ken(gr8 buddy), indomit(hows ya man?) ~jim, Mach4 and all other friends @ crackmes.de.