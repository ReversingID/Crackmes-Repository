You need Python 2.3 or greater to run this. 2.5 is recommended.
To run it, simply perform from command line:

	python Keygen.py

Sorry about this, but it was just too much of a pain to code it in C++, with MD5 encryptions and string operations and whatnot.
