﻿using System;
using System.Text;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace Optimise_KeyGen
{
    public partial class Form1 : Form
    {
        Random rand = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        private void RandomSolveDiophantine(out int X, out int Y, out int Z)
        {
            Z = 0;
            do // Loop, until a good solution is found
            {
                X = rand.Next(1, 1288);
                int temp = 20625 - 16 * X;

                Y = -1;
                for (int i = 0; i < temp / 10; i++)
                {
                    if ((temp - 10 * i) % 17 == 0)  // Accept values and break
                    {
                        Y = (temp - 10 * i) / 17;
                        Z = i;
                        break;
                    }
                }
            } while (Y == -1); // Y == -1 => there is no good solution yet
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void buttonGenerate_Click(object sender, EventArgs e)
        {
            if (textBoxName.Text == "")
            {
                MessageBox.Show("I will give you a serial, but you\nhave to give me your name, first!");
                return;
            }

            // Compute the sum of the bytes in the MD5 hash of the given name
            MD5CryptoServiceProvider provider = new MD5CryptoServiceProvider();
            byte[] name = Encoding.ASCII.GetBytes(textBoxName.Text);
            int sum = 0;
            name = provider.ComputeHash(name);
            foreach (byte b in name)
            {
                sum += b;
            }

            int X, Y, Z;
            do  // Loop until X, Y and Z are solutions for the inequalities as well
            {
                RandomSolveDiophantine(out X, out Y, out Z);
            }
            while (Y + 4 * Z > 2000 || 2 * X + Y + Z > 3600 || X + Y + 3 * Z > 6001);
            
            textBoxSerial.Text = string.Format("{0} - {1} - {2} - {3}", X, Y, Z, sum);
        }
    }
}
