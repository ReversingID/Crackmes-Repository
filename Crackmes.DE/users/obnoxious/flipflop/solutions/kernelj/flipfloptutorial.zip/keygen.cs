using System;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Drawing;

namespace FlipFlop {
   class KeygenForm : Form {
      const int LEFTMARGIN = 25;
      const int TOPMARGIN = 25;
      const int STEPX = 30;
      const int STEPY = 30;
      const int NAMESIZE = 155;
      const int MILLISECS = 500;
      Label lblName = new Label();
      TextBox txtName = new TextBox();
      Button btnGenerate = new Button();
      TextBox txtKey = new TextBox();
      public KeygenForm() {
         lblName.Text = "Name: ";
         lblName.Location = new Point(0,1);
         lblName.AutoSize = true;
         base.Controls.Add(lblName);
         txtName.Location = new Point(lblName.Width,1);
         txtName.Width = NAMESIZE;
         base.Controls.Add(txtName);
         btnGenerate.Text = "Generate Key";
         btnGenerate.AutoSize = true;
         btnGenerate.Location = new Point(lblName.Width + NAMESIZE + 10,0);
         base.Controls.Add(btnGenerate);
         txtKey.Multiline = true;
         txtKey.Size = new Size(290,95);
         txtKey.Location = new Point(1,270);
         base.Controls.Add(txtKey);
         base.Text = "Keygen: FlipFlop by Obnoxious";
         btnGenerate.Click += new EventHandler(Generate);
         base.Size = new Size(300,400);
      }
      private void Generate(Object sender, EventArgs e) {
         txtKey.Text = "";
         this.Refresh();
         byte[] bytes = Encoding.ASCII.GetBytes(txtName.Text);
         int sum = 0;
         foreach (byte c in bytes) {
            sum += c;
         }
         int i = (sum & 0xff) % 7;
         int j = (sum & 0xff0) % 7;
         Graphics g = this.CreateGraphics();
         Pen grid = new Pen(Color.Gray,1f);
         Pen shape = new Pen(Color.Black,5f);
         for (int k=0;k<=8;k++) {
            DrawGridLine(g,grid,k,0,k,8);
            DrawGridLine(g,grid,0,k,8,k);
         }
         Thread.Sleep(MILLISECS);
         DrawGridLine(g,shape,i,j,i+1,j);
         DrawGridLine(g,shape,i+1,j,i+1,j+1);
         DrawGridLine(g,shape,i+1,j+1,i,j+1);
         DrawGridLine(g,shape,i,j+1,i,j);
         Thread.Sleep(MILLISECS);
         TileGrid(g,shape,i,j,0,0,8,8);
      }
      private void TileGrid(Graphics g, Pen pen, int i, int j, int left, int top, int right, int bottom) {
         int size = Math.Abs(left - right);
         if (size < 2) return;
         int midx = (left + right) / 2;
         int midy = (top + bottom) / 2;
         int tdx = i < midx ? -1 : 1;
         int tdy = j < midy ? -1 : 1;
         TileGrid(g,pen,i,j,midx+tdx*size/2,midy+tdy*size/2,midx,midy);
         DrawLShape(g,pen,midx,midy,tdx,tdy);
         for (int dx=-1;dx<=1;dx+=2) {
            for (int dy=-1;dy<=1;dy+=2) {
               if (tdx != dx || tdy != dy) {
                  TileGrid(g,pen,dx==1?midx:midx-1,dy==1?midy:midy-1,midx+dx*size/2,midy+dy*size/2,midx,midy);
               }
            }
         }
      }
      private void DrawLShape(Graphics g, Pen pen, int x, int y, int dx, int dy) {
         DrawGridLine(g,pen,x,y,x+dx,y);
         DrawGridLine(g,pen,x,y,x,y+dy);
         DrawGridLine(g,pen,x-dx,y-dy,x+dx,y-dy);
         DrawGridLine(g,pen,x-dx,y-dy,x-dx,y+dy);
         DrawGridLine(g,pen,x+dx,y,x+dx,y-dy);
         DrawGridLine(g,pen,x,y+dy,x-dx,y+dy);
         int midx = dx==1 ? x-1 : x;
         int midy = dy==1 ? y-1 : y;
         txtKey.Text = txtKey.Text + midx + (midy+dy) + midx + midy + (midx+dx) + midy;
         txtKey.Refresh();
         Thread.Sleep(MILLISECS);
      }
      private void DrawGridLine(Graphics g, Pen pen, int x1, int y1, int x2, int y2) {
         g.DrawLine(pen,LEFTMARGIN+x1*STEPX,TOPMARGIN+y1*STEPY,LEFTMARGIN+x2*STEPX,TOPMARGIN+y2*STEPY);
      }
   }
   static class Keygen {
      static void Main() {
         Application.EnableVisualStyles();
         Application.Run(new KeygenForm());
      }
   }
}