﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
//using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string license123;
        Random rnd;
        int first;
        int seed;
        string oldName = string.Empty;
        private void button1_Click(object sender, EventArgs e)
        {
            license123 = string.Empty;

            rnd = new Random();
            //stolden from  function007()
            //{
            string text = textBox1.Text;
            int num = 0;
            byte[] bytes = Encoding.ASCII.GetBytes(text);
            foreach (byte num2 in bytes)
            {
                num += num2;
            }
            
            if ((num%2) ==1)
            {
                //odd must have 5 triplets
                //let first trippplet be odd
                //01-02-03 is the smallest
                first = 1+ rnd.Next(15);
                
                if (first % 2 == 0)
                    first--;
                
                license123 = Synt(first) + "-";
                workOnEvenNumber(num - first);

            }
            else
            {
                //even can use 4 tripplets
                license123 = string.Empty;
                workOnEvenNumber(num);
            }

            checkLicense();
        }
        private void workOnEvenNumber(int num)
        {
            int tripplet3,tripplet1,tripplet4,tripplet2;
            
            //use double tripplets
            int doubletipplet = num / 2;
            if ((doubletipplet % 2) == 1)
            {
                //odd, must force 
                int doubletippletFirst = (num - 1) / 2;
                int doubletippletSec = 2 + (num - 1) / 2;
                //check if tripplest will be odd
                if ((((doubletippletFirst) / 2) % 2) == 1)
                {
                    //odd, ok
                    seed = rnd.Next(15);//salt
                    if (seed % 2 == 1)
                        seed--;
                    
                    tripplet1 = -seed+(doubletippletFirst) / 2;
                    tripplet2 = seed+(doubletippletFirst) / 2;


                }
                else
                {
                    //even, must force
                    tripplet1 = (doubletippletFirst - 1) / 2;
                    tripplet2 = 2 + (doubletippletFirst - 1) / 2;

                }
                if ((((doubletippletSec) / 2) % 2) == 1)
                {
                    //odd, ok
                    int seed2 = rnd.Next(15);//salt
                    if (seed2 % 2 == 1)
                        seed2--;
                    tripplet3 = -seed2+(doubletippletSec) / 2;
                    tripplet4 = seed2+(doubletippletSec) / 2;


                }
                else
                {
                    //even, must force
                    tripplet3 = (doubletippletSec - 1) / 2;
                    tripplet4 = 2 + (doubletippletSec - 1) / 2;

                }   

            }
            else
            {
                //even, check if tripplest will be odd
                if ((((doubletipplet) / 2) % 2) == 1)
                {
                    //odd, ok
                    seed = rnd.Next(15);//salt
                    if (seed % 2 == 1)
                        seed--;
                    int seed2 = rnd.Next(15);//salt
                    if (seed2 % 2 == 1)
                        seed2--;

                    tripplet1 = -seed + (doubletipplet) / 2;
                    tripplet2 = seed + (doubletipplet) / 2;
                    tripplet3 = -seed2+ tripplet1;
                    tripplet4 = seed2 +tripplet2;

                }
                else
                {
                    //even, must force
                    tripplet1 = (doubletipplet-1) / 2;
                    tripplet2 = 2 + (doubletipplet - 1) / 2;
                    tripplet3 = tripplet1;
                    tripplet4 = tripplet2;

                }                 
            }
            license123 += Synt(tripplet1) + "-" + Synt(tripplet2) + "-" + Synt(tripplet3) + "-" + Synt(tripplet4);
            
        }
        
        private string Synt(int num)
        {
            //assume odd
            string zerosstring1 = string.Empty;
            string zerosstring2 = string.Empty;
            string zerosstring3 = string.Empty;

            int first = num / 2;
            int sec = 1 + num / 2;

            int zeroes = rnd.Next(3);//salt
            for (int i = 0; i <= zeroes; i++) { zerosstring1 += "0"; }
            zeroes = rnd.Next(3);//salt
            for (int i = 0; i <= zeroes; i++) { zerosstring2 += "0"; }
            zeroes = rnd.Next(3);//salt
            for (int i = 0; i <= zeroes; i++) { zerosstring3 += "0"; }

            string ret = zerosstring1 + first + "-" + zerosstring2 + sec + "-" + zerosstring3+num;
            return ret;
        }
        
        private void checkLicense()
        {
            if (oldName != textBox1.Text)
                richTextBox1.Text = string.Empty;

            if (chkvalid())
            {
                richTextBox1.Text += license123 + Environment.NewLine;
                oldName = textBox1.Text;
            }
            else
            {
                richTextBox1.Text += "faild to generate proper license" + Environment.NewLine; ;
            }
        }


//code stolen from the CrackME
        
        #region CodeStolenFromOrdProg
		
        //check for "-" must be 11 or 14 of them in the key
        private bool chkvalid()
        {
            try
            {
                string text = license123;
                int num = 0;
                for (int i = 0; i < text.Length; i++)
                {
                    if (text.Substring(i, 1) == "-")
                    {
                        num++;
                    }
                }
                return (((num == 11) || (num == 14)) && chk());
            }
            catch
            {
                return false;
            }
        }
        private bool chk()
        {
            try
            {
                int[] numArray = function3();
                int num = 0;
                for (int i = 0; i < numArray.Length; i += 3)
                {
                    if (((numArray[i] + numArray[i + 1]) == numArray[i + 2]) && (Math.Abs((int)(numArray[i + 1] - numArray[i])) == 1))
                    {
                        num++;
                    }
                }
                switch (num)
                {
                    case 4:
                        return ((((numArray[2] + numArray[5]) + numArray[8]) + numArray[11]) == function007());

                    case 5:
                        return (((((numArray[2] + numArray[5]) + numArray[8]) + numArray[11]) + numArray[14]) == function007());
                }
                return false;
            }
            catch
            {
                return false;
            }
        }

        private int[] function3()
        {
            try
            {
                string text = license123;
                int[] numArray = new int[15];
                int index = 0;
                while (text.Contains("-"))
                {
                    numArray[index] = Convert.ToInt32(text.Substring(0, text.IndexOf("-")));
                    text = text.Substring(text.IndexOf("-"), text.Length - text.IndexOf("-")).Remove(0, 1);
                    index++;
                }
                numArray[index] = Convert.ToInt32(text);
                int[] numArray2 = new int[index + 1];
                for (int i = 0; i < numArray2.Length; i++)
                {
                    numArray2[i] = numArray[i];
                }
                return numArray2;
            }
            catch
            {
                return new int[15];
            }
        }

        private int function007()
        {
            string text = textBox1.Text;
            int num = 0;
            byte[] bytes = Encoding.ASCII.GetBytes(text);
            foreach (byte num2 in bytes)
            {
                num += num2;
            }
            return num;
        } 
	#endregion


    }
}
