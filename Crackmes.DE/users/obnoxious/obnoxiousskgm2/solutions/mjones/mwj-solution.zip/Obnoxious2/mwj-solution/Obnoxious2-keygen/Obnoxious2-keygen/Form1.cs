﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace Obnoxious2_keygen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.textBox1.Text = Convert.ToString(SystemInformation.UserName);
            this.textBox2.Text = Convert.ToString(SystemInformation.DoubleClickTime);
            this.textBox3.Text = getkey();
        }

        private string getmd5(string md5str)
        {
            MD5CryptoServiceProvider provider = new MD5CryptoServiceProvider();
            byte[] bytes = Encoding.ASCII.GetBytes(md5str);
            bytes = provider.ComputeHash(bytes);
            string str = "";
            foreach (byte num in bytes)
            {
                str = str + num.ToString("");
            }
            return str;
        }

        private string getkey()
        {
            int length = Convert.ToString(SystemInformation.UserName).Length;
            int num2 = length;
            string str2 = Convert.ToString(SystemInformation.UserName + SystemInformation.DoubleClickTime);
            string str3 = Convert.ToString(this.getmd5(str2)).Substring(length, 20).ToUpper();
            for (length = 4; length < str3.Length; length += num2)
            {
                str3 = str3.Insert(length, "-");
            }

            return str3;
        }
    }
}
