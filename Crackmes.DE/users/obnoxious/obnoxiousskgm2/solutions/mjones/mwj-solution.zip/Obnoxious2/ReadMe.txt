                             :::::::::::::::Obnoxious's KGM#2:::::::::::::::
My second crackme. Pretty simple n easy algo. Have fun cracking it!

Rules
Patch the nags if u want. (Alternately registering the software too will remove the nags.)
Make keygen+tut.

Thanks to all at crackmes.de!