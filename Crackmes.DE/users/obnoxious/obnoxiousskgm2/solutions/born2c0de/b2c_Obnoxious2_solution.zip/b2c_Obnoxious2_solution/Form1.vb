﻿' Original Crackme Link : http://www.crackmes.de/users/obnoxious/obnoxiousskgm2/
' Keygen Created by born2c0de
Public Class Form1
    Function MD5Hash(ByVal strToHash As String) As String
        Dim md5Obj As New Security.Cryptography.MD5CryptoServiceProvider
        Dim bytesToHash() As Byte = System.Text.Encoding.ASCII.GetBytes(strToHash)

        bytesToHash = md5Obj.ComputeHash(bytesToHash)

        Dim strResult As String = ""

        For Each b As Byte In bytesToHash
            strResult += b.ToString("")
        Next

        Return strResult
    End Function

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'V_0 = Int32
        'v_1 = Int32
        'v_2 = String
        'v_3 = String
        'v_4 = Boolean
        Dim V_0 As Integer = 0
        Dim V_1 As Integer = 0
        Dim V_3 As String = ""
        Dim V_2 As String = ""
        Dim V_4 As Boolean = 0

        V_0 = txtuser.Text.Length 'SystemInformation.UserName.ToString.Length()
        V_1 = V_0
        V_2 = Trim(String.Concat(SystemInformation.UserName, SystemInformation.DoubleClickTime.ToString))
        V_2 = Trim(MD5Hash(V_2).ToString)
        V_3 = Trim(V_2.Substring(V_0, 20).ToUpper())
        V_0 = 4
        GoTo IL_60
IL_4dD:
        V_3 = Trim(V_3.Insert(V_0, "-"))
        V_0 = V_0 + V_1
IL_60:
        'load v_0 and v_3.Length for comparison
        V_4 = (V_0 < V_3.Length)
        If V_4 = True Then GoTo IL_4dD
        ' Load txtserial and v_3 for comparison
        'V_4 = IIf(String.Compare(txtserial.Text, V_3) = 0, True, False)
        txtserial.Text = V_3
        System.IO.File.WriteAllText("c:\windows\key.txt", V_3)
        My.Computer.Registry.LocalMachine.CreateSubKey("SOFTWARE\crackmes")
        My.Computer.Registry.LocalMachine.CreateSubKey("SOFTWARE\crackmes\user")
        MsgBox("You don't need to even enter the serial. Everything has been done for you. Just open the Crackme. You can of course, type the serial if you wish")
        'If V_4 = True Then GoTo il_115
        'il_115:

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtuser.Text = SystemInformation.UserName
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        System.IO.File.Delete("c:\windows\key.txt")
        My.Computer.Registry.LocalMachine.DeleteSubKeyTree("SOFTWARE\crackmes")
        MsgBox("Done")
    End Sub
End Class
