#include<stdio.h>
#include<string.h>
#include<math.h>
#include<conio.h>
void main()
{
	
	
	
	
	unsigned long Serial=0,temp1,temp2,temp3;
	double dRoot;
	int i,len,root,temp;
	char Name[30],cSerial[8];

	printf("************************************************\n");
	printf("*** Keygen for Celtic's Keygenme 7 by br0ken ***\n");
	printf("************************************************\n");
    start:printf("\n\nName (5 or more chars) = ");
	scanf("%s",Name);
	len=strlen(Name);
	if(len <5)
	{
		printf("\n\nUmm, you need to enter 5 or more chars :P\nPress any key to try again");
		getch();
		goto start;
    } 
	
	
	for(i=0;i<len;i++)
	{
		
		
		temp1 = 3 * len + Name[i];
		temp2 = len ^ temp1;
		temp3 = 3 * len * temp2;
		Serial= Serial + temp3;
	
	
	}

	temp=i=sprintf(cSerial,"%d",Serial);
	dRoot=sqrt(Serial);
	root=(int)dRoot;
	if(dRoot-root >= 0.5)
	{
		root++;
	}
	
	
	do
	{
		temp = temp + root - 2;
		i--;
	}
	while(i);

	printf("\n\nSerial = %d%d\n",temp,Serial);
    getch();
}