Try to write a valid keygen for this crackme.
If you manage to do this without patching, then
feel free to send a tutorial+keygen to me or http://www.crackmes.de.

Difficulty : 2/10

Good luck :)

zephyrous@inbox.lv