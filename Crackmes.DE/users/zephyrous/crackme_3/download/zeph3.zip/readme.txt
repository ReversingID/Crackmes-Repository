Try to write a valid keygen for this crackme.
If you manage to do this without patching, then
feel free to send a tutorial+keygen to me or http://www.crackmes.de

Difficulty : 3/10

Good luck :)


zephyrous@inbox.lv
-------------------------------
Greets: (in no particular order)
Cik Siti, Ancient_One, Kwai_Lo, ManKind, Bengaly, ytc, snaker, fuss, 
Detten, chainie, Unpacking Gods crew, Stingduck, ^DAEMON^, _pusher_, w00tz,
cluesurf, Goofy, BiW-Reversing team, and all crackers/reversers 
out there..