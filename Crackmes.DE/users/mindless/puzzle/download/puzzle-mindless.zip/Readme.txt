
Puzzle - KeyGenme

by mindless		23rd Feb. 2008

Level:    4 - Needs special knowledge
Platform: Windows
Language: C/C++


-------------------------------------------------------------------------------------------------------


This is my first crackme so I apologize in case you find it boring, specially hard or specially easy.
Any comments will be much appreciated.

The key is to make a working KeyGen for any username given. It's got some crypto inside and no
anti-debugging protection; hope you find this protection scheme interesting. I'm looking forward for 
the feedback since this is my very first attempt of making such things.

Note: I've found some problems running it under Vista and I will try to fix them as soon as possible.

Thank you !

mindless