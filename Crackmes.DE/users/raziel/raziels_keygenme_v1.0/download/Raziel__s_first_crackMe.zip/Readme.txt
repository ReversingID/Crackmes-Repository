Hi all,
This is my first crack me so do not expect too much.
The ruls:
1.Do not patch it cause it's not designed to pe "patch resistant" and it won't be any kind of achievement.
2.Try to understand how the algo is working and code a keygen

PS:Great thanks for everybody from the forum who tried to help me solving some technicl problems;