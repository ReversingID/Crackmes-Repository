import java.lang.Math.*;

/*******************************
 * Keygen for Raziel's first crack me.
 * By MoUsE-WiZ
 * Also happens to be my first attempt at a solution
 * so forgive me if I'm doing it wrong.
 *
 * Java is a silly language for this sort of work, but
 * doing it in C would probably have just resulted in me
 * copying and pasting the disassembled code and that seems
 * like cheating some how.
 * 
 * Judging from the comments it looks like the length of his
 * algorithm was a turn off for most people, I figured it's not
 * really different doing 1 long easy one or 10 short easy ones for
 * practice, so whatever.
 * Function starts@ 0040141E
 ********************************/
public class Raz {


	private int	namSe	= 0; //His algorithm is using 3 seeds to generate the serial
	private int	idSe	= 0; //one based on name, one on ID, and one loosely on the name
	private int sillySe = 0; //EBP-20 is the ID seed, EBP-1E is the name seed, the one I've decided
	private String serial;   //is rather silly is in EBP-14, but is used mostly in EDI
	private String name;	 //Serial is stored at 0023FA44 while it is being generated
	private String id;		 //A pointer to the name is in EBP-1C
	
	/*******************
	 * Proper usage: java Raz name id
	 *
	 * He's nice enough to show the user the ID he generates, so I didn't
	 * bother to catch it for you.
	 *******************/
	public static void main(String args[]) {
		
		Raz keyGen = new Raz();
		System.out.println(keyGen.go(args[0], args[1]));
	}
	
	private String go(String n, String i){
		name = n;
		id = i;
		char temp = 0x8B; //that's the character at 23FA44-3, it's used later.
		serial = ""+temp+"?w"; //The algo checks the 3 preceding characters in sn for uniqueness, so initialize it
		genIdSeed(); //Then generate the ID seed
		genNameSeed(); //Then the name seed
		int nameIdx = serialPass1(); //Do one pass of the serial, initializing it to a string of bytes
		sillySe = (int)(Math.log(namSe)/Math.log(10)); //Set up the silly seed (which has been 1 or 2 fairly consistently)
		serialPass2(nameIdx); //And do the second pass of the serial, ending in 'A'-'Z'.
		return ("SN: "+ serial.substring(3));
	}
	
	//loop at 00401454
	//generating ID seed is rather simple, it is stored in a word hence the &
	private void genIdSeed(){
		
		for(int i=0;i<id.length();i++){
			char c = id.charAt(i);
			idSe = (int)(0xFFFF&(((idSe+c-1) ^ 0x21)+i));
		}
	
	}
	
	//loop at 00401488
	//same idea for the name seed, also stored as a word
	private void genNameSeed(){
	
		for(int i=0;i<name.length();i++){
			char c = name.charAt(i);
			namSe = (int)(0xFFFF&((namSe+c-1) ^ 0x39));
		}
	}
	
	//loop at 004014B3
	//EBP-1C actually points into the name rather than the start, after this loop it is not
	//guarenteed to be at 0 and is used in the 2nd pass, hence the return.
	private int serialPass1(){
		int snIdx = 2; //the first 3 characters of serial are just there for reference, not part of the SN
		char n;
		char d;
		int nameIdx = 0;
		int idIdx = 0;
		for(int i=0;i<0x17;i++) { //length of serial is hardcoded at 0x17
			n = name.charAt(nameIdx);
			n = (char)(0xFF&((0xFF&namSe) ^ n)); //Although the name seed is stored as a word, it is used as a byte here
			namSe--;
			d = id.charAt(idIdx); //using both the name and the id to generate the initial bytes for the sn
			n = (char)(0xFF&(n|d)); //using both of them and the name seed in byte operations
			idIdx++;
			nameIdx++;
			serial=serial+n;
			snIdx++;
			if(idIdx==id.length()) idIdx=0; //since length of serial is fixed need to make sure to
			if(nameIdx==name.length()) nameIdx=0; //loop through both ID&name strings as needed
			//nested loop at 004014EC
			while((n==0)||(n==serial.charAt(snIdx-1))){ //I haven't had a test case where a 00 ended up in my
				n=zeroInSN(snIdx, n, nameIdx); //initial bytes, but it does check for that.
				if(n==serial.charAt(snIdx-1)){ //more importantly it also checks if the new byte matches the preceding
					n = name.charAt(nameIdx); //byte and does more manipulation if it does.
					n = (char)(n ^ i);
					n = (char)(n|idSe);
					n = (char)((0xFF&n) ^ (0xFF&namSe));
					namSe = namSe-3;
					serial=serial.substring(0, serial.length()-1)+n;
				}
			}
		}
		return nameIdx;
	}
			
	//part of the above, if it tries to set a byte to 00 it needs to redo it as 00 is how it knows
	//it's at end of string in pass 2.
	private char zeroInSN(int snIdx, char n, int nameIdx){
		while(n==0){
			n = (char)((n&0xFF)|(idSe&0xFF));
			serial=serial.substring(0, serial.length()-1)+n;
			idSe++;
			n = name.charAt(nameIdx);
		}
		return n;
	}
	
	//big loop at 00401565
	private void serialPass2(int nameIdx) {
		int snIdx = 3; //3 here instead of 2 as now we have an initial byte to work with
		for(int i = 0; i<0x17; i++){ //his loop terminates when it finds a 00, I figured a for loop was easier.
			char c = serial.charAt(snIdx); //We're mostly working with the byte pointed to by ESI at 23FA44+whatever
			c = (char)(c&0xFF); //Unicode is gay.
			//loop at 00401572
			while(!((0xFF&(c-0x41))<=0x19)) { //This is basically "Is c a capital letter?"... unsigned compare here
				//loop at 0040157E
				while(!((c<0x5A)||(c>0x7F))) { //Is c>'Z'?  But it's signed, so 0x80 to 0xFF <'Z'.
					c = (char)(c-(0xFF&sillySe)); //repeated subtraction of silly seed to bring it into range
					sillySe++; //with silly seed being incremented each time as well
					//after that's done it checks if it matches any of the 3 preceding characters
					if((c==serial.charAt(snIdx-1))||(c==serial.charAt(snIdx-2))||(c==serial.charAt(snIdx-3))){
						//and if it matches any of them it generates a new character for us
						//this time based on bit operations from the char that EBP-1C was left pointing at
						//EBP-1C always points to the same character in this part of the loop
						c = name.charAt(nameIdx);
						c = (char)(c ^ sillySe);
						c = (char)(c|idSe);
						c = (char)(c ^ namSe);
						c = (char)(c&0xFF);
						namSe = namSe-3;
					}		
				}
				//loop at 004015CC
				//same sort of idea as the above loop, but this time it wants to make sure you didn't
				//go too low (0x40 = '@', 0x41='A')
				while(!((c>0x40)&&(c<=0x7F))) {
					c=(char)(c-(0xFF&sillySe)); //it's still using subtraction though, then loops back to the top
					sillySe++;
					//and again it doesn't want you to have consecutive characters.
					if((c==serial.charAt(snIdx-1))||(c==serial.charAt(snIdx-2))||(c==serial.charAt(snIdx-3))){
						c = name.charAt(nameIdx);
						c = (char)(c ^ sillySe);
						c = (char)(c|idSe);
						c = (char)((c&0xFF) ^ (namSe&0xFF));
						namSe = namSe-3;
					}				
				}
			}
			//popping a character into the middle of a string is really messy in java.
			//I should've used an array and converted to string at the end, but I forgot about this part
			//and by then I was all set up using a string and didn't feel like changing that.
			serial = serial.substring(0,snIdx)+c+serial.substring(snIdx+1);
			snIdx++; //then move on to next byte
			sillySe--; //but not before changing up silly seed a bit.
			sillySe=sillySe ^ 0x3;
		}
	}
}
				
			
		
		
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	