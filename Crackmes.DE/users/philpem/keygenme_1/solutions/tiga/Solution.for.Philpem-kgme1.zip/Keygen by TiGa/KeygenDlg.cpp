// KeygenDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Keygen.h"
#include "KeygenDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CKeygenDlg dialog

CKeygenDlg::CKeygenDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CKeygenDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CKeygenDlg)
	m_sCdKey = _T("");
	m_sInsKey = _T("");
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CKeygenDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CKeygenDlg)
	DDX_Control(pDX, IDC_BGENERATE, m_ctlGenerate);
	DDX_Text(pDX, IDC_ECDKEY, m_sCdKey);
	DDV_MaxChars(pDX, m_sCdKey, 23);
	DDX_Text(pDX, IDC_EINSTKEY, m_sInsKey);
	DDV_MaxChars(pDX, m_sInsKey, 23);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CKeygenDlg, CDialog)
	//{{AFX_MSG_MAP(CKeygenDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BEXIT, OnBexit)
	ON_EN_CHANGE(IDC_ECDKEY, OnChangeEcdkey)
	ON_BN_CLICKED(IDC_BGENERATE, OnBgenerate)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CKeygenDlg message handlers

BOOL CKeygenDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CKeygenDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CKeygenDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CKeygenDlg::OnBexit() 
{
	OnOK();	
}

void CKeygenDlg::OnChangeEcdkey() 
{
	UpdateData(true);
	if (m_sCdKey.GetLength() == 23)
		m_ctlGenerate.EnableWindow(true);
	else
		m_ctlGenerate.EnableWindow(false);
	UpdateData(false);
}

void CKeygenDlg::OnBgenerate() 
{
	UpdateData(true);

	CString sConstKey1 = "QWMF-KCMV-MRPJKC-MPQZIE", sConstKey2 = "MAVS-GWER-DYMRNT-LKMKUV",
		sCdKey = m_sCdKey, sInsKey = "";
	unsigned char cCdKey[23] = {0}, cInsKey[23] = {0}, cConstKey1[23] = {0}, cConstKey2[23] = {0},
		cKey1[23] = {0}, cKey2[23] = {0}, cKey3[23] = {0};
	unsigned int iTemp = 13;

	if ((sCdKey.GetAt(4) == '-') && (sCdKey.GetAt(9) == '-') && (sCdKey.GetAt(16) == '-'))
	{
	for (int i = 0; i < 23; i++)
	{
		cCdKey[i] = sCdKey.GetAt(i);
		cConstKey1[i] = sConstKey1.GetAt(i);
		cConstKey2[i] = sConstKey2.GetAt(i);

		if (cConstKey1[i] == '-')
		{
			cKey1[i] = '-';
			cKey2[i] = '-';
			cKey3[i] = '-';
		}
		else
		{
			cKey1[i] = cConstKey1[i] - 'A';
			cKey1[i] ^= 255;
			
			iTemp += cCdKey[i];
			cKey1[i] ^= cCdKey[i];
			cKey1[i] <<= 2;
			cKey1[i] += cCdKey[i];
		}
	}

	for (i = 0; i < 23; i++)
	{
		if (cConstKey1[i] != '-')
		{
			if (i > 1)
				cKey1[i] ^= iTemp;

				cKey1[i] ^= 255;

//reverse
			//get absolute value
			cKey3[i] = cConstKey2[i] - 'A';
			cKey3[i] ^= 255;  // reverse of &31
			cKey3[i] ^= 31;

			//first part XOR last part
			cKey2[i] = cKey1[i] ^ cKey3[i];
			cKey2[i] += 13;
			cKey2[i] -= 237;

			//translate into readable chars
			cKey2[i] &= 31;
			if (cKey2[i] < 26)
				cKey2[i] += 'A';
			else
			{
				//weird reverse of %6
				cKey2[i] -= 22;
				if (cKey2[i] < 8)
					cKey2[i] %= 4;
				else
				{
					cKey2[i] %= 4;
					cKey2[i] += 4;
				}
				cKey2[i] += '0';
			}
		}
		//output
		sInsKey += cKey2[i];
	}

	m_sInsKey = sInsKey;
	UpdateData(false);	
}
	else
		AfxMessageBox("Cd Key must follow the format xxxx-xxxx-xxxxxx-xxxxxx",0,0);
}
