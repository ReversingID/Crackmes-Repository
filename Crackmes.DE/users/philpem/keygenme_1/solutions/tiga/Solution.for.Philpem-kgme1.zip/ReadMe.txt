Philpem's Quick-n-dirty keygenme #1: CD keys and other fun stuff

This is a simple keygenme I threw together in a couple of hours. It takes a CD key and
a licence key as input, then outputs a string depending on the keypair's validity.

Objective: Reverse engineer the algorithm and write a keygen.

Rules:
  1. No patching. You must reverse engineer the key generation algorithm.
  2. Use whatever tools you want - Ollydbg, Softice, w32dasm, IDA...
  3. The CD key and Install key should be keyboard-enterable. That means no funny symbols.
     Upper and lower case alphanumerics (letters and numbers) and "-" only.

You should provide:
  1. A tutorial - however long you want - to explain how you broke the algorithm.
  2. A working CD Key and Install Key pair.
  3. optional - the source code for your keygen. Let others learn from your code :)

I've given this a fairly low rating. The algorithm is pretty simple, and shouldn't be
too difficult to keygen. If you get stuck, work through the algorithm and try and work out
how everything works. You might even be able to simplify the code a little :)

Have fun!