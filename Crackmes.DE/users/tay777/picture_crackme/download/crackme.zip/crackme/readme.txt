Rules:
No patching

Find the secert combo into the house by pressing on the right combonation of doors and windows.


