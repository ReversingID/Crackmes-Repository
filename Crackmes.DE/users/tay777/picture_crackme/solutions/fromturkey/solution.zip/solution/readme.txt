The clicking order is "34105621546"

--------------------------------
fromTurkey - 2008
talhasavash@hotmail.com
--------------------------------

