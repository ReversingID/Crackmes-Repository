/* Backtracer for ACT-1 Challenge by Dr. Animadei [UCF] 19-Feb-1998
 * (c) 2002,03 by RElf
 *
 * Greetings to Dr.Cipher, EOD, acw
 */

#include <stdio.h>
#include <memory.h>
#include <ctype.h>

#ifdef __GNUC__
//#include <unistd.h>   // usleep()
#include <stdlib.h>   // sleep() and _beginthread()

#ifdef PTHREAD
#include <pthread.h>
#endif

#endif

#ifdef __WATCOMC__
#include <process.h>
#include <dos.h>
#endif

// `long long' format string modifier
#if defined(__WIN32__) || defined(__WATCOMC__)
#define LLP "I64"
#else
#define LLP "ll"
#endif

// Process indicator update duration
int psec = 300;
#define PSTACK 10240

typedef unsigned char byte;
typedef unsigned short word;

#define theword(x) (*(word*)&(x))

// First byte of pwdfinal is unknown
byte pwdfinal[] = {
    0x00,
    0x1C, 0xB4, 0x25, 0x9C, 0xB9, 0x6D, 0x8A, 0xB4, 0x1B, 0x54, 0xCA, 0x21, 0x1C, 0x25, 0xDA, 0xB9
};

// We know first and last four chars: "\r\n\nC????????????ns!$"
// Likely, it is "\r\n\nCongratulations!"
const byte plainmsg[] = "\r\n\nCongratulations!$";

const unsigned char xoredmsg[] = {
    0x6F, 0xCF, 0x6D, 0x1E, 0x0B, 0x8F, 0x8B, 0xCC, 0x3F, 0x18, 0x21, 0x39, 0x38, 0xE3, 0x43, 0x75
    // the tail was used to learn first/last four bytes of plainmsg
    // 0x0C, 0xB6, 0x46, 0x79
};

const byte hashinit[] = "ACT-1 CHALLENGE!";

#ifdef TEST
// Pwd: "TestTestTestTest"
// final.ax = 0x4B2F
const byte pwdtest[] = {
    0x0E,
    0x1D, 0xC6, 0x6F, 0x3E, 0xC8, 0x7E, 0x38, 0x6F, 0x36, 0xC7, 0xFF, 0xAF, 0x29, 0x0E, 0xAE, 0x88
};
const byte hashtest[] = {
    0x22, 0x0E, 0x87, 0x1A, 0x1E, 0x2C, 0x12, 0x76, 0xD3, 0x33, 0x0C, 0xD4, 0xEF, 0xC5, 0x8C, 0x66,
    0x87
};
#endif

// State.status constants
#define ST_NORMAL 0
#define ST_ENTRY1 1
#define ST_ENTRY2 2
#define ST_DEADLOCK 255

typedef struct {
    word ax,cx,dx;
    byte hash[0x12]; // value of the last byte is never used, but it's necessary for access theword(hash[0x10])
    byte pwd[0x11];
    byte status;
} STATE;

STATE cpu, final;

#define maxsize (1<<20)
STATE stack[maxsize];
int stacksize = 0;
int dosavestack = 0;

long long hits=0, iter=0, branch=0;

inline void savestate(byte st) {
    if(stacksize>=maxsize) {
        fprintf(stderr,"Memory storage exhausted!\n");
        abort();
    }
    //memmove(&stack[stacksize],&cpu,sizeof(STATE));
    stack[stacksize] = cpu;
    stack[stacksize++].status = st;
}

inline void restorestate() {
    branch++;
    if( dosavestack ) {
	FILE *f = fopen("act-1-bt.stx","wb");

	fwrite(&final.pwd[0],1,1,f);
	fwrite(&final.hash[0x10],1,1,f);
	fwrite(&final.ax,2,1,f);

	fwrite(stack,sizeof(STATE),stacksize,f);
	fclose(f);
        dosavestack = 0;
    }
    //memmove(&cpu,&stack[--stacksize],sizeof(STATE));
    cpu = stack[--stacksize];
}

void progress(void* nouse) {
    while(1) {

#ifdef SLEEPMS
        sleep(psec*1000);
#else
        sleep(psec);
#endif

	fprintf(stderr,"\r%02X:%02X:%04X: cx=%02x : stack=%6d : hits=%6"LLP"d : ips=%8"LLP"d : bps=%8"LLP"d\n",
                final.pwd[0],final.hash[0x10],final.ax,
                cpu.cx,stacksize,hits,iter/psec,branch/psec);
        iter = 0;
        branch = 0;

	// request to save the stack
        dosavestack = 1;
    }
}

int main(int argc, char* argv[]) {
    int i;
    unsigned int initpwd0 = 0, inithash0x10 = 0, initax = 0;
    FILE *f = fopen("act-1-bt.pwd","rb");

    puts("ACT-1 BackTracer 3.4 (c) 2002,04 by RElf");

    //DosSetPriority(PRTYS_PROCESS,PRTYC_IDLETIME,PRTYD_MAXIMUM,0);
    //DosSetPriority(0,1,31,0);

    if(f) {
        fclose(f);
        puts("Error: act-1-bt.pwd found! Enjoy it! =)");
        return 2;
    }

    // Parsing command line
    for(i=1;i<argc;i++) if(argv[i][0]=='-' && argv[i][1]!='?' ) {
	switch(tolower(argv[i][1])) {
	case 's':
	    if(3 != sscanf(argv[++i],"%x:%x:%x",&initpwd0,&inithash0x10,&initax) ) {
		puts("Invalid -s argument");
		return 3;
	    }
            break;
	case 'p':
	    if(1 != sscanf(argv[++i],"%d",&psec) ) {
		puts("Invalid -p argument");
		return 3;
	    }
            break;
	}
    }
    else {
	printf("Usage: %s [ -? ] [ -s XX:YY:ZZZZ ] [ -p <seconds> ]\n",argv[0]);
	return 1;
    }

    // prepare Final state
#ifdef TEST
    memmove(final.pwd,pwdtest,0x11);
    memmove(final.hash,hashtest,0x11);
#else
    memmove(final.pwd,pwdfinal,0x11);
    // Set final values of hash array
    for(i=0;i<0x10;i++) final.hash[(0x14-i)&0xF] = plainmsg[i]^xoredmsg[i];
    //for(i=0;i<0x10;i++) printf("%02X ",hashfinal[i]); printf("\n");
    //Values are: 64 5D 67 C5 62 1A 2A 97 59 55 54 6C 5E BE EC E1
#endif
    final.status = ST_NORMAL;
    final.dx = 0;
    final.cx = 1;

    final.ax = initax;
    final.pwd[0] = initpwd0;
    final.hash[0x10] = inithash0x10;

    // Restore saved stack
    f = fopen("act-1-bt.stx","rb");
    if( f ) {
        fprintf(stderr,"Restoring execution stack... ");

	fseek(f,0,SEEK_END);
	stacksize = (ftell(f)-4)/sizeof(STATE);
        fprintf(stderr,"size=%d",stacksize);
	fseek(f,0,SEEK_SET);

	fread(&final.pwd[0],1,1,f);
	fread(&final.hash[0x10],1,1,f);
	fread(&final.ax,2,1,f);

	if( stacksize ) fread(stack,sizeof(STATE),stacksize,f);

	fclose(f);
        fprintf(stderr," done\n");
    }
    else {
	if( 0==initpwd0 && 0==inithash0x10 && 0==initax ) {
	    puts("No stack file found. Use `-s' option.");
	    return 4;
	}
	fprintf(stderr,"Brute-forcing from %02X:%02X:%04X\n",initpwd0,inithash0x10,initax);
    }

    // Staring progress thread
    fprintf(stderr,"Starting progress indicator thread... ");
    {
        int tid;
#ifdef __GNUC__
#ifdef PTHREAD
        pthread_create(&tid,0,&progress,0);
#else
        tid = _beginthread(&progress,0,PSTACK,0);
#endif
#else // WATCOMC
#ifdef __NT__
        tid = _beginthread(&progress,PSTACK,0);
#else
         { void* stack = (void*) malloc(PSTACK);
           tid = _beginthread(&progress,stack,PSTACK,0);
         }
#endif
#endif
         fprintf(stderr,"tid=%d done\n",tid);
    }

    do {         // Loop over all values of final.pwd[0]
        do {     // Loop over all values of final.hash[0x10]
            do { // Loop over all final.ax

                cpu = final;

                if( stacksize ) restorestate();

		hits = 0;

                fprintf(stderr,"\r%02X:%02X:%04X",final.pwd[0],final.hash[0x10],final.ax);

                // Now we backtrace the program until dx=0x10, cx=0x10 and ax=0
                while(1) {
                    int carry0, carry1;
                    int bx;

                    if(cpu.status==ST_DEADLOCK) {
                        if(stacksize==0) break;
                        restorestate();
                    }

                    iter++;

                    switch(cpu.status) {

                    case ST_NORMAL: // Entry point for state of type ST_NORMAL

                        cpu.dx++;                                             // dec dx
                        theword(cpu.hash[0]) ^= cpu.ax;                          // xor word ptr Magic, ax
                        cpu.ax = ~cpu.ax;                                     // not ax
                        cpu.ax += cpu.cx;                                     // sbb ax, cx
                        cpu.ax += cpu.dx;                                     // sub ax, dx
                        // Take care about carry flag of 'sub ax, dx'
                        carry0 = cpu.ax>=cpu.dx;
                        carry1 = ((cpu.ax+1)&0xFFFF)<cpu.dx;
                        if(carry1) {
                            if(carry0) savestate(ST_ENTRY1); // Ambiguity: saving variant carry=0 for future
                            cpu.ax++;
                        } else if(!carry0) {               // Deadlock
                            cpu.status = ST_DEADLOCK;
                            continue;
                        }

                    case ST_ENTRY1: // Entry point for state of type ST_ENTRY1

                        cpu.dx ^= cpu.ax;                                     // xor dx, ax

                        // Postpone since we don't know value of bx yet:      // xor [bx+hash+1], ax

                        cpu.dx -= cpu.cx;                                     // adc dx, cx
                        // Figure out what was carry flag
                        // Note: it arrives as a result of  add ax, [bx+pwd]
                        // where bx = (dx-carry) & 0xF
                        // Note: (dx-carry) cannot be zero as a value of DX at beginning of the loop
                        carry0 = (theword(cpu.pwd[cpu.dx&0xF]) <= cpu.ax) && (cpu.dx!=0);
                        carry1 = (theword(cpu.pwd[(cpu.dx-1)&0xF]) > cpu.ax) && (cpu.dx!=1);

                        if(carry1) {
                            if(carry0) savestate(ST_ENTRY2); // Ambiguity: saving variant carry=0 for future
                            cpu.dx--;
                        } else if(!carry0) {                 // Deadlock
                            cpu.status = ST_DEADLOCK;
                            continue;
                        }

                    case ST_ENTRY2: // Entry point for state of type 2

                        bx = cpu.dx & 0xF;
                        theword(cpu.hash[bx+1]) ^= cpu.ax;                  // Now do postponed: xor [bx+hash+1], ax
                        cpu.ax -= theword(cpu.pwd[bx]);                     // add ax, [bx+pwd]
                        theword(cpu.pwd[bx]) ^= cpu.ax;                     // xor [bx+pwd], ax
                        cpu.ax -= theword(cpu.hash[bx]);                    // add ax, [bx+hash]

                        if( cpu.dx==0x10 )
                            if( cpu.cx==0x10 ) { // It might be the end
                                if( (cpu.ax==0) && !memcmp(cpu.hash+1,hashinit+1,0x10)) { // Success
                                    int i;
                                    FILE *f = fopen("act-1-bt.pwd","wb");
                                    fwrite(cpu.pwd,1,0x11,f);
                                    fclose(f);
                                    printf("\nWell done!\nPassword (hex): ");
                                    for(i=0;i<0x11;i++) printf("%02X ",cpu.pwd[i]);
                                    printf("\nPassword (txt): ");
                                    for(i=1;i<0x11;i++) printf("%c",cpu.pwd[i]);
                                    printf("\n");
                                    return 0;
                                }
                                hits++;
                            } else {
                                savestate(ST_NORMAL);  // Ambiguity: it might be the beginning of dx-loop, or just an occasion
                                cpu.cx++; cpu.dx = 0;  // Following the first variant and save the second for future
                            }

                    default: cpu.status = ST_NORMAL;

                    }
                }
            } while(++final.ax);
        } while(++final.hash[0x10]);
    } while(++final.pwd[0]);
    puts("No solution! =(");
    return 1;
}
