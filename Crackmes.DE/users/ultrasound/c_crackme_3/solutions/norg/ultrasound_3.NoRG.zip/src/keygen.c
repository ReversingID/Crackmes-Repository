#include <stdio.h>
#include <windows.h>
#include <commctrl.h> 
#include "resource.h"

HINSTANCE       hInst;
extern int  get_hash(), namelen;
extern char name[], hash_8[];
char            p2[32], serial[32], badname[] = "Enter more 1 char in name.";
int             p3;


void getserial(void){
        int i, c1, c2, target;


        srand( (unsigned)GetTickCount() );

        get_hash();

        p3 = 0; 
        for(i = 0; name[i] != 0; i++){
                p3 += name[i];
        };
        p3 ^= 1;

        for(i = 0; i < 8; i++){
                target = hash_8[i] + 0x8F * (rand() % 5);       
                c1     = target / 26;
                c2     = target - c1 * 26;
                p2[i*2]   = c1 + 'A';
                p2[i*2+1] = c2 + 'A';
        };
        p2[17] = 0;
}


BOOL CALLBACK DialogProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{       
        switch (message)
        {    
        case WM_CLOSE:
                EndDialog(hWnd,0);
                break;
        case WM_COMMAND:
			switch (LOWORD(wParam)){ 
			case ID_GENERATE:
                        namelen = GetDlgItemTextA(hWnd, IDC_NAME, name, 15);
                        if (namelen < 1 ){
                                SetDlgItemTextA(hWnd, IDC_SERIAL, badname);
                                break;
                        }
                        
                        getserial();
        
                        sprintf(serial, "ULT-%s%c%d", p2, rand() % 26 + 'A', p3);
                        SetDlgItemTextA(hWnd, IDC_SERIAL, serial);
                break;
                }
        case WM_INITDIALOG:
                break;
        }
     return 0;
}

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{
        hInst=hInstance;
        DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, (DLGPROC)DialogProc,0);
        return 0;
}
