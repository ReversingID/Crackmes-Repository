Information:
- not packed/crypted
- includes a little anti debug trick

Rules: NO PATCHING

What to do?
Create a fully working Keygen. :)

Good luck to everyone!
by MaxXor