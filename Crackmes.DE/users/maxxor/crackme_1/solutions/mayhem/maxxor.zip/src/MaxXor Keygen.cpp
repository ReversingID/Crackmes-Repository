#include "stdafx.h"
#include <iostream>
#include "base64.h"
#include <conio.h>


int _tmain(int argc, _TCHAR* argv[])
{
	char name[50];

	printf(" ==========================\n|  MaxXor Crackme - Keygen |\n|                          |\n|        By Mayhem         |\n ==========================\n\n");

	printf("Name: ");
	gets(name);

	std::cout << "Serial: " << base64_encode(reinterpret_cast<const unsigned char*>(name), strlen(name)) << "\n";



	_getch();
}

