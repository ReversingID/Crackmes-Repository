Information:
============
- platform: Windows
- language: C
- protection: find it out

Goals:
======
GOLD:   * create a working keygen
        * remove the nag screen

SILVER: * get a working username/serial combination
        * remove the nag screen

BRONZE: * make it accept every username/serial combination
        * remove the nag screen

WOOD:   * remove the nag screen || make it accept every username/serial combination

Good luck and happy reversing!
MaxX0r // RTN
www.rtn-team.cc
