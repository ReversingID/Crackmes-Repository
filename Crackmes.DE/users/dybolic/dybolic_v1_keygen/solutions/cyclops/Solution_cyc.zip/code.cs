
public void Generate()
{
	string szName = string.Empty;
	string szSerial = string.Empty;
	if (txtName.Text.Length > 4)
	{
		szName = txtName.Text;

		szSerial += szName[0];
		szSerial += 'a';
		szSerial += szName[1];
		szSerial += 'a';
		szSerial += '-';

		szSerial += szName[1];
		szSerial += 'a';
		szSerial += szName[2];
		szSerial += 'e';
		szSerial += '-';

		szSerial += szName[2];
		szSerial += 'a';
		szSerial += szName[3];
		szSerial += 'i';
		szSerial += '-';

		szSerial += szName[3];
		szSerial += 'a';
		szSerial += szName[4];
		szSerial += 'm';

		txtSerial.Text = szSerial;
	}
	else
	{
		txtSerial.Text = "Please provide lengthier name!";
	}
}