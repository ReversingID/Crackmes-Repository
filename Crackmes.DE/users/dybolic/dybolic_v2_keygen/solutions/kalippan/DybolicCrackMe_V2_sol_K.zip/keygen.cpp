#include<iostream>
#include<cstring>
#include<string>
#include<math.h>
using namespace std;
char* expo(char*,int,int);
char *hash(char *str);
int *j;

void main()
{
char name[35],*str2,*str3;
char st2[20]={0},st3[35]={0};
int q,ch1,ch2;
int i;

cout<< "Keygenerator For DybolicCrackMe_V2"<<"\n"<<"Keygenner : Kalippan\n\n";
cout<<"Enter Name: ";
cin>>name;
cout<<"Serial: ";
str2=0;
str3=0;
st3[33]=0;
str2=expo(name,16,strlen(name));
for(q=0;q<16;q++)
st2[q]=*(str2+q);
st2[q]=NULL;
//cout<<st2;
str2=hash(name);

for(q=0;q<10;q++)
st3[q]=*(str2+q);
st3[q]=NULL;
str3=expo(st3,32,*j);

for(int w=0;w<32;w++)
st3[w]=*(str3+w);
for(i=0;i<16;i++)
{
	q=st2[i];
	q/=2;
	ch1=st3[2*i]+48;
	ch2=st3[2*i+1]+48;
	ch1+=ch2;
	ch1/=2;
	q-=ch1;
	q=abs(q);
	if (q<=0)
	{q=1;}
	while(q>36)
		q/=2;
	if (i%4==0 && i!=0)
		cout<<"-";
	if (q<=26)
	cout <<char(q+64);
	if (q>26)
	cout <<char(q+48);
	

 
}
cout<<"\n";



}
char* expo(char* str,int len,int leng)
{
int p;
p=leng;
//cout <<str<<*(str+1);
int j=0;
int i=0;
char s[40]={0};
char *res;
int num = 0;
int num2 = p - 1;
int num3 = p/ 2;
int length = p;
int num5 = p - 1;
bool flag = false;
for (i = 0; i < len; i++)
    {
        if (num == num5)
        {
            num = 0;
        }
        if (num2 == 0)
        {
            num2 = num5;
        }
        if (num3 == (num5 - 1))
        {
            flag = false;
        }
        else if (num3 == 1)
        {
            flag = true;
        }
         s[j++]= *(str+num);
		 if (j==len) break;
		 s[j++]= *(str+num3);
		 if (j==len) break;
	     s[j++]= *(str+num2);
		 if (j==len) break;
        num++;
        num2--;
        if (flag)
        {
            num3++;
        }
        else
        {
            num3--;
        }
    }
res=s;
return res;
}



char *hash(char *str)
{
	long result =0;
	double x=4;
	char* hsh;
	int e=0;
	char desperate[10];
	char desperate1[10];
	int p=strlen(str);
	for(int i=0;i<strlen(str);i++)
	{
		result=result+pow(x,p)+str[i];
		p--;
	}
	for (e=0;e<10;e++)
	{
		int r;
		r= result % 10;
		desperate[e]=r;
		if (result<10) 
		{
			desperate[e+1]=NULL;
			break;
		}
		result/=10;
	}
	int b=0;
	for (int a=e;a>=0;a--)
	{
		
		desperate1[b]=desperate[a]; 
		b++;
	
	}
	desperate1[b]=NULL; 
	::j=&b;
    hsh=desperate1 ;
//	hsh=(*result);
	return hsh;
}
