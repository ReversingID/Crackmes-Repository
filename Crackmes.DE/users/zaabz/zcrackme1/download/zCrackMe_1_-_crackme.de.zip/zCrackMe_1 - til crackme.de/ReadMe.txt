This is my first crackme, aswell as its my first c++ program.
The task is to reverse the algorithm, and create some serial keys. Patching is not allowed.
If you feel like making a tutorial, please put some effort in it, as I have used a good amount of time in making the crackme.

Here you have some examples:
Account name:
ZaabZ
Serial:
1300NX-2990XN-7800ED-10920DE-4680UM-1300IB-2990BI-7670VP-10400PV-4160LK-520CZ

Account name:
CrimeRider
Serial:
2680LK-6164KL-16080YT-22512TY-9648RA-2680FC-6164CZ-15812ZF-21440NX-8576XN-1072VP


Account name:
CrackMe
Serial:
2020LK-4646KL-12120YT-16968TY-7272RA-2020FC-4646CZ-11918ZF-16160NX-6464XN-808VP

Account name:
Firstcppcrackme
Serial:
3960NX-9108XN-23760ED-33264DE-14256UM-3960IB-9108BI-23364VP-31680PV-12672LK-1584CZ

Account name:
Oh_lol@Crack-me
Serial:
4400NX-10120XN-26400ED-36960DE-15840UM-4400IB-10120BI-25960VP-35200PV-14080LK-1760CZ

Have fun cracking

ZaabZ