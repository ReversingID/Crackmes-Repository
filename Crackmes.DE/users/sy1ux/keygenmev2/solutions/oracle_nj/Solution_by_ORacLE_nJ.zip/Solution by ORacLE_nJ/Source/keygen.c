#include <stdio.h>
#include <windows.h>
#include "resource.h"

DWORD buffer;
char serialA[20],serialB[20];


VOID CreateKeyFile()
{
	FILE *f;
	f=fopen("sy1ux.key","w");
	fprintf(f,"%c%c%c%c%c%c%c%c%c",0x4F,0x52,0x61,0x63,0x4C,0x45,0x5F,0x6E,0x4A);
	fclose(f);
}



VOID RunProcess()
{
	PROCESS_INFORMATION pi;
	STARTUPINFO si;

	char program[]= "KeyGenMeV2.exe";
	int result;

	ZeroMemory(&si, sizeof(si));
	ZeroMemory(&pi, sizeof(pi));

	result = CreateProcess(program,	NULL, NULL, NULL, FALSE,
		CREATE_NEW_CONSOLE | NORMAL_PRIORITY_CLASS, NULL, NULL, &si, &pi);


	if (result == 0)
	{
		MessageBox(NULL, "Where is the keygenme?!?!", "Aargh!!", MB_OK);
		exit(1);
	}
}




VOID SerialA(char *serialA)
{
	SYSTEMTIME st;
	GetLocalTime(&st);
	sprintf(serialA,"VX%d0x7d8%dPH%d",st.wHour,st.wDayOfWeek,st.wMinute);
}




VOID SerialB(char *serialB)
{
	char UName[50]={0},str[50]={0};
	unsigned long int sum;
	unsigned long int t1=0x36,t2=0x124,t3=0xD5,t4=8;
	unsigned long int i,l=sizeof(UName);

	GetUserNameA(&UName[0], &l);

	l = strlen(UName);

	sum=0;
	for( i=0; i<l; i++ )
		sum += UName[i] + t1;

	sprintf(UName,"%d-",sum);

	sum=0;
	for(i=0;i<l;i++)
		sum += (UName[i] * t2);

	for(i=0;i<l;i++)
		str[5+i] = UName[i];

	sprintf(str,"%d-",sum);

	lstrcatA((str+5),str);

	sum=0;
	for( i=0; i<l; i++ )
		sum += (str[5+i] + t3);

	sprintf(str,"%d-",sum);

	lstrcatA((str+5),str);

	sum=0;
	for( i=0; i<l; i++ )
		sum += (str[5+i] * t4);

	sprintf(str,"%d",sum);

	lstrcatA((str+5),str);

	sprintf(serialB,"%s",(str+5));
}




HINSTANCE	hInst;

BOOL CALLBACK DialogProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{    
	case WM_CLOSE:
		EndDialog(hWnd,0);
		break;

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{ 
		case IDC_GENERATE:

			SerialB(&serialB[0]);

			SetDlgItemText(hWnd, IDC_1, serialA);
			SetDlgItemText(hWnd, IDC_2, serialB);
			
			break;

		case IDC_ABOUT:
			MessageBox(hWnd, "Keygen By ORacLE_nJ\n\noraclevirus@gmail.com", "About", MB_OK);
			break;
		}
		break;

	case WM_INITDIALOG:
		SendMessageA(hWnd,WM_SETICON,(WPARAM) 1,(LPARAM) LoadIconA(hInst,MAKEINTRESOURCE(IDI_ICON)));
		break;
	}
     return 0;
}



int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{
	hInst=hInstance;
	CreateKeyFile();
	RunProcess();
	SerialA(&serialA[0]);
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, (DLGPROC)DialogProc,0);
	return 0;
}