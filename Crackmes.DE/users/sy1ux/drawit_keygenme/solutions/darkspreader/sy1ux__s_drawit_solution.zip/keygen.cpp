#include <windows.h>
#include <cstdio>
#include <ctime>
#include <cstdlib>

#define COLOUR_GREEN 2
#define COLOUR_BLUE 3
#define COLOUR_YELLOW 4

bool done = false; // a flag later used by drawinwindow()

HWND hWindow; // this will store the handle to the keygenme's window
HWND colour_button; // this will store the handle to the "Colour" button
HWND backButton; // this will store the handle to the "Back" button

int yellow_counter=0, blue_counter=0; // these variables will contain the number of pixels of each colour used so far
int current_colour=1; // we will need this to know what colour we are currently using

void changewindowcolor(int ile) // this function emulates clicking on the "Colour" button
{
    colour_button = FindWindowEx(hWindow, NULL, NULL, "Colour"); // finding child window entitled "Colour"

    int z;
    for (z=0; z<ile; z++) // repeat the click for n times
    {
    SendMessage(colour_button, WM_LBUTTONDOWN, (WPARAM)MK_LBUTTON, (LPARAM)MAKELPARAM(1,1)); // emulate clicking the button
    SendMessage(colour_button, WM_LBUTTONUP, (WPARAM)0, (LPARAM)MAKELPARAM(1,1)); // emulate releasing mouse button
    current_colour++;
    if (current_colour > 5) current_colour = 1;
    }
}

void drawinwindow(int x, int y, int len) // this function draws in the keygenme's window
{
    done = false; // this must be cleared out in order to enter the function's loop
    int tmp=x; // we store the X coordinate for later comparison

    //When using SendMessage, I move the X and Y coordinates by 2 pixels because Windows uses "device units"
    //for positioning (whatever it means), which are not compatible with single pixels.

    while (!done) // are we done yet?
    {

    srand(clock()); // initialize the pseudo-number generator

    changewindowcolor(rand() % 5); // pick up a random colour

    switch (current_colour)
    {
        case COLOUR_GREEN:
            changewindowcolor(1); // prevent us from using the green colour, pick up red
            break;
        case COLOUR_BLUE:
            blue_counter+=5;
            if (blue_counter >= 0x61A8) // make sure we don't exceed the limit
            {
                if (yellow_counter < 0x61A8) { changewindowcolor(1); yellow_counter+=5; } // if so, try to use yellow
                else changewindowcolor(2); // if yellow cannot be used, use red
            }
            break;
        case COLOUR_YELLOW:
            yellow_counter+=5;
            if (yellow_counter >= 0x61A8) // make sure we don't exceed the limit
            {
                changewindowcolor(2); // use black
            }
            break;
    }

    SendMessage(hWindow, WM_LBUTTONDOWN, (WPARAM)MK_LBUTTON, (LPARAM)MAKELPARAM(x+2,y+2)); // emulate pressing the mouse button
    SendMessage(hWindow, WM_MOUSEMOVE, (WPARAM)MK_LBUTTON, (LPARAM)MAKELPARAM(x+2,y+2)); // emulate the mouse movement
    x++; // increment the X coordinate

    Sleep(50); // let the CPU take a breath ;)
    if (x >= tmp+len) done = true; // check if we reached the desired line length
    SendMessage(hWindow, WM_LBUTTONUP, (WPARAM)0, (LPARAM)MAKELPARAM(x+2,y+2)); // emulate releasing the mouse button
    }


}

int main()
{

    MessageBox(NULL, "Please wait patiently for the keygen to complete its task.\n\
The window will now be hidden to avoid messaging problems.",
                     "KeyGen by DarkSpreader", MB_ICONINFORMATION | MB_OK);

    hWindow = FindWindow(NULL, "DrawIt! KeyGenMe by Sy1ux"); // we find the keygenme's window
    if (!hWindow) // check if the handle is correct, if not, display error message
    {
        MessageBox(NULL, "Couldn't find the keygenme's window!", "Oops!", MB_ICONHAND|MB_OK);
        exit(0); // exit the program
    }

    ShowWindow(hWindow,SW_HIDE); // we hide the window to avoid problems with sending messages

    // the following three lines are here just in case someone didn't click on "Back" button
    backButton = FindWindowEx(hWindow, NULL, NULL, "Back"); // now we find the "Back" button
    SendMessage(backButton, WM_LBUTTONDOWN, (WPARAM)MK_LBUTTON, (LPARAM)MAKELPARAM(1,1)); // and emulate the click
    SendMessage(backButton, WM_LBUTTONUP, (WPARAM)0, (LPARAM)MAKELPARAM(1,1)); // then release the button

    int q;
    for (q=5; q<170; q+=5) drawinwindow(0,q,275); // draw 34 lines in the keygenme's window, 275px long

    MessageBox(hWindow, "Now go ahead and click 'Check' !\nKeyGen coded by DarkSpreader, Aug 25, 2009.\n",
                     "Task completed!", MB_ICONINFORMATION|MB_OK);

    ShowWindow(hWindow, SW_RESTORE); // we restore the window with our painting in it :-)
    BringWindowToTop(hWindow); // bring the window to the top

    return 0; // finally, exit the program!
}
