To use the keygen, run Sy1ux's keygenme and then run keygen.exe.
The window will be hidden and will be restored when the keygen completes its task.

Source code of the keygen written in C++.

Best regards,
DarkSpreader.