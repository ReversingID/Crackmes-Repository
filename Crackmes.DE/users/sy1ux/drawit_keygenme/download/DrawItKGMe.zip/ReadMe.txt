DrawIt! KeyGenMe by Sy1ux

The key you have to find is a picture.
Draw something, and be creativ.
After you've found a valid key. Try to keygen it. 
It's possible!