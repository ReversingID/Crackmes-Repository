#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    char a1[]="\xc4\x68\xce\x25\x69\xa4\x4f\xa4";
    char a2[]="\xb4\x09\xba\x46\x01\xcd\x21\xc3";
    for(int i=0;i<8;i++)
        printf("%c",a1[i]^a2[i]);
    
    printf("\n");
    system("PAUSE");
    return EXIT_SUCCESS;
}
