Hey, guys.

Please check out my first crackme, which is written for both Windows and DOS.
It might me a little bit hard, so I chose a simple Password.
Please send how you cracked it, too, because of the simple Password :D

Sorry for my bad English (I'm from Germany)

Cheese Cracker