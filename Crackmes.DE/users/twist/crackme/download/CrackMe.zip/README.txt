Hi,

Welcome to this crackmes. I hope you'll enjoy it.

Your objective is to make a working Keygen for it!
No selfkeygen or Patch please! Just a Keygen!
I made a keygen by myself and it shouldn't be that hard :-).

Bye!


 