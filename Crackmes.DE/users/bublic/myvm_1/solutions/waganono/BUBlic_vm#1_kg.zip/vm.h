#include <windows.h>

#define DECODE_SUCCESS 1

/* Instruction struct */
typedef struct op_decoded{
	BYTE info1;
	BYTE info2;	/* Op size : byte word dword */
	BYTE type; /* (NEW) 0,1,2 scale,imm32,reg ou [reg] */
	DWORD op;
	DWORD op_scale;
	DWORD reg_scale;
}op_decoded;

typedef struct inst_decoded{
	DWORD opcode;		/* Opcode index */
	DWORD inst_len; 	/* Instruction total length */
	DWORD nb_ops;		/* Operand number (0,1,2) */
	op_decoded ops[3];  /* operand(s) */
}inst_decoded;


/* VM data type */
const TCHAR dtype_str[3][6]={
	"BYTE",
	"WORD",
	"DWORD"
};

/* VM registers */
const TCHAR reg_str[8][4]={
	"EAX",
	"EBX",
	"ECX",
	"EDX",
	"EBP",
	"ESI",
	"EDI",
	"ESP"
};

/* VM instructions */
const TCHAR inst_str[0x1E][6]={
  "CALL",  // 00 ??
  "ADD",   // 01	  
  "MOV",   // 02 
  "PUSH",  // 03
  "POP",   // 04
  "XX",   // 05
  "LEA",   // 06
  "XX",    // 07      
  "DIV",   // 08 
  "RET",   // 09 	   
  "SUB",   // 0A    
  "CMP",   // 0B
  "JMP",   // 0C 
  "JE",    // 0D
  "JX",  // 0E     
  "JX",  // 0F      
  "JX",  // 10     
  "CALL",  // 11 
  "RET",   // 12  ??     
  "SHL",   // 13      
  "SHR",   // 14    
  "AND",   // 15     
  "OR",    // 16     
  "XOR",   // 17     
  "NOT",   // 18     
  "JNZ",   // 19  ??      
  "XX",  // 1A     
  "XX",  // 1B     
  "MOV",  // 1C     
  "TEST",  // 1D
};