/* iNCLUDE */
#include "stdafx.h"
#include <windows.h>
#include <stdio.h>
#include <math.h>
#include "vm.h"



/* Filled with pcode to disassemble */
BYTE vm_pcode[4096];

/* Globals */
unsigned pcode_size;
inst_decoded cur_inst;






/* Disassembler usage */
void banner(){
	printf("BUBlic VM disassembler by waganono\n");
}
void usage(){
	printf("vm_disasm <filename.c0d>\n");
}






/* Read raw pcode from a file & store it */
unsigned read_pcode(TCHAR *filename,BYTE *to){
	HANDLE hFile;
	DWORD file_size,nb_reads;

	hFile=CreateFile(filename,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	if(hFile==INVALID_HANDLE_VALUE)
		return 0;
	file_size = GetFileSize(hFile,NULL);
	ReadFile(hFile,to,file_size,&nb_reads,NULL);
	CloseHandle(hFile);

	return nb_reads;
}







/* print decoded instruction struct */
void print_s_idecode(inst_decoded *i_dec){
	printf("%02X %02X %02X - %02X%02X %08X - %02X%02X %08X  (%02X-%02X)    ",
		i_dec->opcode,i_dec->inst_len,i_dec->nb_ops,i_dec->ops[0].info1,
		i_dec->ops[0].info2,i_dec->ops[0].op,i_dec->ops[1].info1,i_dec->ops[1].info2,i_dec->ops[1].op,
		i_dec->ops[0].type,i_dec->ops[1].type);
}

/* Decode raw pcode instruction to struct */
int decode_instruction(BYTE *ip,inst_decoded *i_decoded){
	BYTE *eip = ip;
	DWORD inst_len;
	DWORD ind=0;
	BYTE len;
	int coeff,flag;

	/* Zero */
	ZeroMemory(i_decoded,sizeof(inst_decoded));

	/* Decode instruction header (2 first bytes) */
	i_decoded->opcode = *eip;
	i_decoded->inst_len = *(eip+1) >> 2;
	i_decoded->nb_ops = *(eip+1) & 03;

	/* if no operands */
	if(!i_decoded->nb_ops)
		return 0;
	eip+=2;

	/* Decode operand(s) */	
	do{
		flag=0;
		i_decoded->ops[ind].info1= *eip >> 4;
		i_decoded->ops[ind].info2= *eip & 0x0F;
		i_decoded->ops[ind].type= *(eip+1);
		eip+=2;
		inst_len = (i_decoded->ops[ind].type & 0x0F) + 1;
		switch (i_decoded->ops[ind].type >> 4){
			
			case 2:
				while(*eip){
					len = *eip >> 4;
					if(*eip & 8)
						coeff = -1;
					else
						coeff = 1;

					if(!(*eip & 7)){
						if(!flag){
							i_decoded->ops[ind].op = *(eip+1);   /* eip+1 = regnum */
							i_decoded->ops[ind].reg_scale = 0xFF;
						}
						else
							i_decoded->ops[ind].reg_scale = *(eip+1); /* eip+1 = reg_scale */
						flag=1;
					}					
					else if((*eip & 7)==1){
						if(!len)
							i_decoded->ops[ind].op_scale = 0;
						else if(len==1)
							i_decoded->ops[ind].op_scale =coeff * *(eip+1);
						else if(len==2)
							i_decoded->ops[ind].op_scale =coeff * *((WORD *)(eip+1));
						else
							i_decoded->ops[ind].op_scale =coeff * *((DWORD *)(eip+1));
						
					}
					eip += len;
				}
				eip++;
				break;

			/* decode imm32 */
			case 1:	
				if(!inst_len)
					break;
				if(inst_len==1)
					i_decoded->ops[ind].op = (*eip);
				else if(inst_len==2)
					i_decoded->ops[ind].op = *((WORD *)eip);
				else
					i_decoded->ops[ind].op = *((DWORD *)eip);
				eip += inst_len;
				break;
	
			/* decode registers */
			case 0:
				if(!i_decoded->ops[ind].info1)
					i_decoded->ops[ind].op = *eip;   // imm reg
				if((i_decoded->ops[ind].info1==2)||(i_decoded->ops[ind].info1==1))
					i_decoded->ops[ind].op = *eip;   // mem [reg]
				eip += inst_len;
				break;
		}		

	}while(++ind!=i_decoded->nb_ops);
					

	return DECODE_SUCCESS;
}

/* Print assembly-like operand */
int print_operand(op_decoded *o_dec){
	int cas = o_dec->type>>4;
	int data_size;

	/* reg32  */
	if(!cas){
		if(!o_dec->info1)
			printf("%s",reg_str[o_dec->op]);
		else
			printf("[%s]",reg_str[o_dec->op]);
	}

	/* imm32 */
	else if(cas==1){
		data_size = 1 + o_dec->type & 0x0F;
		if(data_size==1)
			printf("%02X",(BYTE)o_dec->op);
		else if(data_size==2)
			printf("%04X",(WORD)o_dec->op);
		else
			printf("%08X",(DWORD)o_dec->op);
	}
	else if(cas==2){
		printf("[%s%c%X",reg_str[o_dec->op],((int)o_dec->op_scale<0)?'-':'+',abs(o_dec->op_scale));
		if(o_dec->reg_scale!=0xFF)
			printf("+%s",reg_str[o_dec->reg_scale]);
		printf("]");
	}
	else 
		return 0;
	return 1;
}

/* Print assembly-like decoded instruction */
int print_instruction(inst_decoded *i_dec){

	/* print instruction */
	printf("%s ",inst_str[i_dec->opcode]);

	/* print operands */
	if(i_dec->nb_ops==1)
		print_operand(&i_dec->ops[0]);	
	else if(i_dec->nb_ops==2){
		print_operand(&i_dec->ops[0]);
		printf(",");
		print_operand(&i_dec->ops[1]);
	}

	printf("\n");
	return 1;
}




/* Main work */
int main(int argc, TCHAR **argv){
	BYTE *eip;

	/* Check args */
	banner();
	if(argc!=2){
		usage();
		return 1;
	}

	/* Read raw pcode from file */
	printf("[*] Reading pcode from %s...");
	if(!(pcode_size=read_pcode(argv[1],vm_pcode))){
		printf("error cannot open file\n");
		return 1;
	}printf("[ok]\n");


	/* Disassembly loop */
	eip = vm_pcode;
	printf("[*] Disassembling pcode...\n\n");
	do{
		decode_instruction(eip,&cur_inst);
		//	print_s_idecode(&cur_inst);
		printf("%08X : ",eip-vm_pcode);
		print_instruction(&cur_inst);
		eip += cur_inst.inst_len;
	}while((eip-vm_pcode)<0xBC0);
	
	/*	if(result!=DECODE_SUCCESS)
		printf("There was some error\n");
	else
		printf("Well done reverser\n");*/


	/* Enjoy :) */
	printf("\nEnjoy the magic now!\n");

	return 0;
}


// e815b642f5ce37cda597a6e61c219981 (md5 Waganono)
// 2b61e7e50742f5092774608afc02fb970acda352 (sha1)          

