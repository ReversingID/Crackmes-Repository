// koko.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>

BYTE md5_s[0x200];


/* Custom MD5 data (length=len) */
void custom_MD5(BYTE *md5_struct,BYTE *data,int len,BYTE *digest){
	__asm{
md5_init:
		MOV EAX,[EBP+8]
		MOV DWORD PTR DS:[EAX],0x67452301
		MOV ECX,[EBP+8]
		MOV DWORD PTR DS:[ECX+4],0x0EFCDAB89
		MOV EDX,[EBP+8]
		MOV DWORD PTR DS:[EDX+8],0x98BADCFE
		MOV EAX,[EBP+8]
		MOV DWORD PTR DS:[EAX+0x0C],0x10325476
		MOV ECX,[EBP+0x10]
		SHL ECX,03
		MOV EDX,[EBP+8]
		MOV [EDX+10h],ECX
		MOV EAX,[EBP+8]
		MOV DWORD PTR DS:[EAX+0x14],00 
		MOV DWORD PTR DS:[EBP-4],00 
		JMP md5_update
loop_update:
		MOV ECX,[EBP-4]
		ADD ECX,01
		MOV [EBP-4],ECX
md5_update:
		MOV EDX,[EBP-4]
		CMP EDX,[EBP+10h]
		JE cont_pad
		MOV EAX,[EBP+8]
		ADD EAX,[EBP-4]
		MOV ECX,[EBP+0Ch]
		ADD ECX,[EBP-4]
		MOV DL,BYTE PTR DS:[ECX+0]
		MOV BYTE PTR DS:[EAX+18h],DL
		JMP loop_update
cont_pad:
		MOV EAX,[EBP+8]
		ADD EAX,[EBP+10h]
		MOV BYTE PTR DS:[EAX+18h],80h
		MOV DWORD PTR DS:[EBP-8],00 
		JMP cont_pad1
cont_pad0:
		MOV ECX,[EBP-8]
		ADD ECX,01
		MOV [EBP-8],ECX
cont_pad1:
		MOV EDX,3Fh
		SUB EDX,[EBP+10h]
		CMP [EBP-8],EDX
		JE md5_final
		MOV EAX,[EBP+10h]
		ADD EAX,[EBP-8]
		MOV ECX,[EBP+8]
		MOV BYTE PTR DS:[ECX+19h+EAX],0
		JMP cont_pad0

md5_final:
		MOV EDX,[EBP+8]
		MOV EAX,[EBP+8]
		MOV ECX,[EAX+10h]
		MOV [EDX+50h],ECX
		MOV EDX,[EBP+8]
		ADD EDX,18h
		PUSH EDX
		MOV EAX,[EBP+8]
		PUSH EAX
		CALL md5_calc
		ADD ESP,8h
		MOV DWORD PTR DS:[EBP-0Ch],00
		JMP hi1
loopies:
		MOV ECX,[EBP-0Ch]
		ADD ECX,01
		MOV [EBP-0Ch],ECX
hi1:
		CMP DWORD PTR DS:[EBP-0Ch],10h 
		JE hi2
		MOV EDX,[EBP+14h] 
		ADD EDX,[EBP-0Ch]
		MOV EAX,[EBP+8]
		ADD EAX,[EBP-0Ch]
		MOV ECX,[EAX+0]
		MOV [EDX+0],ECX
		JMP loopies
hi2:
		MOV DWORD PTR DS:[EBP-10h],00 
		JMP hi3
hi22:
		MOV EDX,[EBP-10h]
		ADD EDX,01
		MOV [EBP-10h],EDX
hi3:
		CMP DWORD PTR DS:[EBP-10h],04 
		JE end_l1
		MOV EAX,[EBP+8]
		ADD EAX,[EBP-10h]
		MOV DWORD PTR DS:[EAX],00 
		JMP hi22
end_l1:
		MOV ESP,EBP
		POP EBP
		RET 
			
			
md5_calc:
		PUSH EBP
		MOV EBP,ESP
		SUB ESP,10h
		MOV EAX,[EBP+8]
		MOV ECX,[EAX]
		MOV [EBP-4],ECX
		MOV EDX,[EBP+8]
		MOV EAX,[EDX+4]
		MOV [EBP-8],EAX
		MOV ECX,[EBP+8]
		MOV EDX,[ECX+8]
		MOV [EBP-10h],EDX
		MOV EAX,[EBP+8]
		MOV ECX,[EAX+0Ch]
		MOV [EBP-0Ch],ECX
		MOV EDX,[EBP-8]
		NOT EDX
		OR EDX,[EBP-0Ch]
		XOR EDX,[EBP-4]
		MOV EAX,[EBP+0Ch]
		ADD EDX,[EAX+8]
		MOV ECX,[EBP-10h]
		LEA EDX,[ECX+2AD7D2BBh+EDX]
		MOV [EBP-10h],EDX
		MOV EAX,[EBP-10h]
		SHL EAX,0Fh
		MOV ECX,[EBP-10h]
		SHR ECX,11h
		OR EAX,ECX
		MOV [EBP-10h],EAX
		MOV EDX,[EBP-10h]
		ADD EDX,[EBP-0Ch]
		MOV [EBP-10h],EDX
		MOV EAX,[EBP-4]
		NOT EAX
		OR EAX,[EBP-10h]
		XOR EAX,[EBP-0Ch]
		MOV ECX,[EBP+0Ch]
		ADD EAX,[ECX+24h]
		MOV EDX,[EBP-8]
		LEA EAX,[EDX-14792C6Fh+EAX]
		MOV [EBP-8],EAX
		MOV ECX,[EBP-8]
		SHL ECX,15h
		MOV EDX,[EBP-8]
		SHR EDX,0Bh
		OR ECX,EDX
		MOV [EBP-8],ECX
		MOV EAX,[EBP-8]
		ADD EAX,[EBP-10h]
		MOV [EBP-8],EAX
		MOV ECX,[EBP+8]
		MOV EDX,[ECX]
		ADD EDX,[EBP-4]
		MOV EAX,[EBP+8]
		MOV [EAX],EDX
		MOV ECX,[EBP+8]
		MOV EDX,[ECX+4]
		ADD EDX,[EBP-8]
		MOV EAX,[EBP+8]
		MOV [EAX+4],EDX
		MOV ECX,[EBP+8]
		MOV EDX,[ECX+8]
		ADD EDX,[EBP-10h]
		MOV EAX,[EBP+8]
		MOV [EAX+8],EDX
		MOV ECX,[EBP+8]
		MOV EDX,[ECX+0Ch]
		ADD EDX,[EBP-0Ch]
		MOV EAX,[EBP+8]
		MOV [EAX+0Ch],EDX
		MOV ESP,EBP
		POP EBP
		RET 
	}
}


/* XTEA encipher */
void XTEA_encipher(unsigned int num_rounds,DWORD *v,DWORD *k) {
    DWORD v0=v[0], v1=v[1], i;
    DWORD sum=0, delta=0xC001C0DE;

    for(i=0;i<num_rounds;i++){
        v0 += ((v1 << 4 ^ v1 >> 5) + v1) ^ (sum + k[sum & 3]);
        sum += delta;
        v1 += ((v0 << 4 ^ v0 >> 5) + v0) ^ (sum + k[sum>>11 & 3]);
    }

    v[0]=v0; 
	v[1]=v1;
}


DWORD bswap(DWORD a){
	__asm{
		mov eax,a
		bswap eax
	}	
}

void KeyGen(BYTE *name,TCHAR *key){
	DWORD len,ind=0;
	DWORD vect[2],xkey[4];

	// Custom MD5(name)
	len = lstrlen((TCHAR *)name);
	custom_MD5(md5_s,name,len,(BYTE *)xkey);

	// Cipher name with XTEA
	len = lstrlen((TCHAR *)name);
	do{
		vect[0] = ((DWORD *)name)[ind*2];
		vect[1] = ((DWORD *)name)[1+ind*2];
		XTEA_encipher(32,vect,xkey);
		wsprintf(key+ind*16,"%08X%08X",bswap(vect[0]),bswap(vect[1]));
		ind++;
	}while(ind!=(1+(len/8)));
}

