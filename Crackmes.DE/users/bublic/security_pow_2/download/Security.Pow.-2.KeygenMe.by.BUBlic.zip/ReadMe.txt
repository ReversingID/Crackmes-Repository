Rules

Disallowed:
-patching
-blind bruteforcing

Allowed:
-thinking about the hidden message (once again)
-finding some correct serials
-writing a keygen/tutorial ;)

Hint1: solve the riddle
Hint2: make your homework (I mean this METAPHORICALLY; whithout any background knowledge of that protection, you'll get lost in the algo!)
Hint3: I've found no library for that one, so I had to code a C++ lib on my own, maybe gonna share it on request.