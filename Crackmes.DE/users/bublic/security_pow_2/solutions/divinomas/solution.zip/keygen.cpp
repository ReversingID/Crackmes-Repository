// BUBlic Security Pow 2Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "BUBlic Security Pow 2.h"
#include "BUBlic Security Pow 2Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBUBlicSecurityPow2Dlg dialog

CBUBlicSecurityPow2Dlg::CBUBlicSecurityPow2Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBUBlicSecurityPow2Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CBUBlicSecurityPow2Dlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CBUBlicSecurityPow2Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBUBlicSecurityPow2Dlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CBUBlicSecurityPow2Dlg, CDialog)
	//{{AFX_MSG_MAP(CBUBlicSecurityPow2Dlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_GEN, OnGen)
	ON_BN_CLICKED(IDC_Exit, OnExit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBUBlicSecurityPow2Dlg message handlers

BOOL CBUBlicSecurityPow2Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	OnGen();
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CBUBlicSecurityPow2Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CBUBlicSecurityPow2Dlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

CString T="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

int GetC(CString C)
{
	return T.Find(C);
}




void CBUBlicSecurityPow2Dlg::OnGen() 
{
	// TODO: Add your control notification handler code here
	GetDlgItemText(IDC_NAME,name);
	int i=0;

	CString f,fr;
	f=" 0 0 1 2 1 1 1 1 2 0 0 0 1 1 0 0 1 0 1 2 0 2 2 0 2 1 2 0 1 2 1 1 1 2 1 1 2 0 2 2 1 0 1 0 2 0 1 1 2 1 1 1 0 0 2";
	int d[58]={0},cur=0;
	fr=f.Tokenize(" ",cur);
	i=0;
	d[i++]=atoi(fr);
	while(fr!="")
	{
		fr=f.Tokenize(" ",cur);
		d[i++]=atoi(fr);
	}

	int d1[19]={0};
	for(int i=0;i<19;i++)
	{
		d1[i]=d[3*i]+d[3*i+1]*4+d[3*i+2]*16+21;
	}

	int d2[19]={0};


	int r1=abs(rand())%0x40;
	int r2=abs(rand())%0x40;

	int sum=(r1+2*r2)%0x40;
	for(int i=0;i<19;i++)
	{
		d2[i]=sum+d1[i];
		d2[i]%=0x40;
		sum+=d1[i];
		sum%=0x40;
	}


	

	CString sn,ss;
	
	ss="0123456789012345678";      
	for(i=0;i<19;i++)
		ss.SetAt(i,T[d2[i]]);
	sn="";
	sn+=T[r1];
	sn+=T[r2];
	sn+=ss;
	SetDlgItemText(IDC_SN,sn);
}

void CBUBlicSecurityPow2Dlg::OnExit() 
{
	// TODO: Add your control notification handler code here
	EndDialog(0);
}
