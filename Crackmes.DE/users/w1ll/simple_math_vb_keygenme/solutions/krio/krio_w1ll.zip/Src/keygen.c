//
// Keygen for w1ll's VB Math Keygenme by kRio (C) 2004
//

#include <windows.h>

HANDLE hInstance;
char format[]="%01u%01u%01u%01u%01u%01u";

LRESULT CALLBACK WndProc(HANDLE hWin, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	HICON hIcon;
	int s1,s2,r[4],i;
	char buffer[10];

	switch(uMsg)
	{
	case WM_INITDIALOG:
		hIcon=LoadIcon(hInstance,(char *)100);
		SendMessage(hWin,WM_SETICON,ICON_SMALL,(long)hIcon);
		SendMessage(hWin,WM_SETICON,ICON_BIG,(long)hIcon);
	case WM_COMMAND:
		switch(wParam)
		{
		case 10:
			s1=GetTickCount();
			s1%=9;
			s1++;
			s2=10-s1;
			Sleep(1);

			for(i=0;i<4;i++)
			{
				r[i]=GetTickCount();
				Sleep(1);
				r[i]%=9;
				r[i]++;
			}

			wsprintf(buffer,format,s1,r[0],r[1],r[2],r[3],s2);
			SetDlgItemText(hWin,1,buffer);

			s1=6;
			s2=1;

			for (i=0;i<4;i++)
			{
				r[i]=GetTickCount();
				Sleep(1);
				r[i]%=9;
				r[i]++;
			}

			wsprintf(buffer,format,s1,r[0],r[1],r[2],r[3],s2);
			SetDlgItemText(hWin,2,buffer);

			s1=2;
			s2=GetTickCount();
			s2%=9;
			s2++;
			Sleep(1);

			for (i=0;i<4;i++)
			{
				r[i]=GetTickCount();
				Sleep(1);
				r[i]%=9;
				r[i]++;
			}

			wsprintf(buffer,format,s1,r[0],r[1],r[2],r[3],s2);
			SetDlgItemText(hWin,3,buffer);
		default:
			return 0;
		}
	case WM_CLOSE:
		EndDialog(hWin,0);
	default:
		return 0;
	}

	return 0;
}

void WinMainCRTStartup()
{
	hInstance=GetModuleHandle(0);
	DialogBoxParam(hInstance,(char *)1000,0,WndProc,0);
	ExitProcess(0);
}