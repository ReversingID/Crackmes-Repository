#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>

#define CHAR_BUFFER_SIZE 96
#define CHECKBOX_NUM 52
#define byte unsigned char

int main(int argc, char argv[]){

	/* name buffer */
	char buffer[CHAR_BUFFER_SIZE + 1];
  byte checkboxes[CHECKBOX_NUM];
  byte delimiters[] = {'~','_','^','-'};
	
	/* these bytes represent values for slide controls */
	byte slide_1_left, slide_1_right, slide_2_left, slide_2_right, \
		 slide_3_left, slide_3_right, slide_4_left, slide_4_right, slide_5_left, slide_5_right;
		 
	/* variable which will hold sum for name hash */
	int hash = 0;
	int i = 0;
  int j = 0;
	byte x,y,cboxSum;

  /* variables which will be used to calculate serial number */
  int upperCaseHash = 0;
  int nameHash = 0;
  int lowerCaseHash = 0;
  int sumOfHash;
  int sumOfHashNumbers = 0;
	
	memset(&buffer,0,CHAR_BUFFER_SIZE);
  memset(&checkboxes,0,CHECKBOX_NUM);
	
	printf("Enter name (3 chars min): ");
	fgets(buffer,CHAR_BUFFER_SIZE,stdin);
	
	// calculate first hash
	while(0x0A != buffer[i]){
		hash = hash + (int)buffer[i] + (int)toupper(buffer[i]) + (int)tolower(buffer[i]);
    upperCaseHash = upperCaseHash + (int)toupper(buffer[i]);
    nameHash = nameHash + (int)buffer[i];
    lowerCaseHash = lowerCaseHash + (int)tolower(buffer[i]);
		i++;
	}

  if (i < 3){
    printf("Name must have at least 3 chars");
    return 1;
  }

  /* calculate parts of serial */
  upperCaseHash = upperCaseHash + upperCaseHash + 0x190;
  nameHash = (nameHash - 0x64) * 3;
  lowerCaseHash = lowerCaseHash + lowerCaseHash - 0x140;
  sumOfHash = hash - 0x0E;
	
	/* convert hash to decimal value */
	sprintf(buffer,"%d",hash);
	
	i = 0;
	hash = 0;
	
	/* sum all numbers of current hash to get new hash for slide control calculation */
	while (0x00 != buffer[i]){
		hash = hash + (int)(buffer[i] & 0x0F);
		i++;
	}

  /* last part of serial */
  sumOfHashNumbers = hash + 0x0F;

  j = 0;
  /* generate printable serial format */
  for (i = 0; i < 4; i++){
    switch(i){
      
      case 0:
        sprintf((buffer + j),"%d",upperCaseHash);
        break;

      case 1:
        sprintf((buffer + j),"%d",nameHash);
        break;

      case 2:
        sprintf((buffer + j),"%d",lowerCaseHash);
        break;

      case 3:
        sprintf((buffer + j),"%d",sumOfHash);
        break;
    }

    while(0x00 != buffer[j]){
      j++;
    }
    buffer[j] = delimiters[i];
    j++;
  }
  sprintf((buffer + j),"%d",sumOfHashNumbers);
  printf("\nSerial number: %s\n",buffer);
	
	/* if hash is between 0 and 9 */
	if (hash <= 9){
		//x = 0, y = hash
		//fill up slide values for output
		slide_1_left = 0x02;
		slide_4_left = 0x05;
		slide_5_right = 0x01;
		slide_2_right = 0x04;
		slide_5_left = 0x08;
		
		if (hash <= 4){
			slide_3_left = (byte)(hash + hash);
			slide_2_left = (byte)(hash + 2);
			slide_4_right = (byte)(hash + 4);
			slide_3_right = (byte)(hash + hash + 1);
			slide_1_right = (byte)(hash + hash - 2);
		}
		else{
			slide_3_right = (byte)(hash - 3);
			slide_1_right = (byte)(hash - 1);
			slide_2_left = (byte)(hash + 1);
			slide_3_left = (byte)(hash - 3);
			slide_4_right = (byte)(hash - 4);
		}
	}
	else{
		sprintf(buffer,"%d",hash);
		x = buffer[0] & 0x0F;
		y = buffer[1] & 0x0F;
		
		if (x == 0x00){
			slide_1_left = 0x02;
			slide_4_left = 0x05;
			slide_5_right = 0x01;
			slide_2_right = 0x04;
			slide_5_left = 0x08;
		}
		else{
			if (x <= 4){
				slide_1_left = x + 2;
				slide_2_right = x + x;
				slide_4_left = x + 5;
				slide_5_left = x + x - 2;
				slide_5_right = x + x + 2;
			}
			else{
				slide_5_left = x - 2;
				slide_5_right = x + 1;
				slide_1_left = x - 4;
				slide_4_left = x + 1;
				slide_2_right = x - 1;
			}
		}
		
		if (y == 0){
			slide_1_right = 0x03;
			slide_3_left = 0x07;
			slide_3_right = 0x00;
			slide_4_right = 0x0A;
			slide_2_left = 0x09;
		}
		else{
			if (y <= 4){
				slide_3_left = y + y;
				slide_2_left = y + 2;
				slide_4_right = y + 4;
				slide_3_right = y + y + 1;
				slide_1_right = y + y - 2;
			}
			else{
				slide_3_right = y - 3;
				slide_1_right = y - 1;
				slide_2_left = y + 1;
				slide_3_left = y - 3;
				slide_4_right = y - 4;
			}
		}
	}

  if((x == 0) && (y == 0)){
    cboxSum = hash;
  }
  else{
    cboxSum = x + y;
  }

  switch(cboxSum){
  
    case 0:
    case 1:
      checkboxes[0] = 1;
      checkboxes[7] = 1;
      checkboxes[14] = 1;
      checkboxes[21] = 1;
      checkboxes[35] = 1;
      checkboxes[47] = 1;
      checkboxes[38] = 1;
      checkboxes[36] = 1;
      break;

    case 2:
    case 3:
      checkboxes[1] = 1;
      checkboxes[8] = 1;
      checkboxes[15] = 1;
      checkboxes[22] = 1;
      checkboxes[51] = 1;
      checkboxes[46] = 1;
      checkboxes[37] = 1;
      checkboxes[39] = 1;
      break;

    case 4:
    case 5:
      checkboxes[5] = 1;
      checkboxes[10] = 1;
      checkboxes[13] = 1;
      checkboxes[27] = 1;
      checkboxes[32] = 1;
      checkboxes[43] = 1;
      checkboxes[41] = 1;
      checkboxes[19] = 1;
      break;

    case 6:
    case 7:
      checkboxes[2] = 1;
      checkboxes[3] = 1;
      checkboxes[16] = 1;
      checkboxes[18] = 1;
      checkboxes[27] = 1;
      checkboxes[33] = 1;
      checkboxes[50] = 1;
      checkboxes[45] = 1;
      break;

    case 8:
    case 9:
      checkboxes[4] = 1;
      checkboxes[6] = 1;
      checkboxes[9] = 1;
      checkboxes[12] = 1;
      checkboxes[24] = 1;
      checkboxes[29] = 1;
      checkboxes[48] = 1;
      checkboxes[40] = 1;
      break;

    case 10:
    case 11:
      checkboxes[11] = 1;
      checkboxes[34] = 1;
      checkboxes[28] = 1;
      checkboxes[31] = 1;
      checkboxes[49] = 1;
      checkboxes[42] = 1;
      checkboxes[40] = 1;
      checkboxes[20] = 1;
      break;

    default:
      checkboxes[25] = 1;
      checkboxes[26] = 1;
      checkboxes[17] = 1;
      checkboxes[20] = 1;
      checkboxes[30] = 1;
      checkboxes[44] = 1;
      checkboxes[50] = 1;
      checkboxes[36] = 1;
      break;
  }
	
  printf("\nEach column represent slide column in crackme,value 0 represent\noriginal position of slide, 10 represent max position of slide\n");
	printf("%d %d\n",slide_1_left,slide_1_right);
	printf("%d %d\n",slide_2_left,slide_2_right);
	printf("%d %d\n",slide_3_left,slide_3_right);
	printf("%d %d\n",slide_4_left,slide_4_right);
	printf("%d %d\n",slide_5_left,slide_5_right);

  printf("\nCheckbox values, checkbox 1 start at top left corner, checkbox 52 is at top right\nCheck at least next checkboxes: ");

  for(i = 0; i < CHECKBOX_NUM; i++){
    if(checkboxes[i] == 1){
      printf("%d ",(i + 1));
    }
  }
	printf("\n");
	return 0;
}
