B0rken ElGamal KeygenMe

Yet another company is making wild claims!
Your mission: prove that people shouldn't trust companies promoting "revolutionary" crypto algos.
Keygen this son of a crypto nightmare and write a DETAILED tutorial!

Rules:
1) The only acceptable solution is a keygen
2) No patching of course

You feelin' so smart you want to show off your patching skills?
Very well, let me make a couple suggestions:
004069A4: 00 -> 01
or
00401257: 75 -> EB
There are more places where you can patch, but the points many people too many times don't get are that:
1) the only acceptable solution is a keygen actually means that the only acceptable solution is a mothering keygen
2) no patching allowed means that if you try to post a patch or a patched executable I'll find out where you live and set you on fire

Have fun!
- SmilingWolf
