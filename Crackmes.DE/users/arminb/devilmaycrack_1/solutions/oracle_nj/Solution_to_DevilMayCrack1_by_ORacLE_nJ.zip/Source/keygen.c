
#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <windows.h>
#include"md5.cpp"

void main()
{
char name[50], h1[33] = {0}, h2[33] = {0}, temp[70] = {0};
char serial[33] = {0}, t1[12] = {0}, t2[12] = {0};

long int eax=0, edx=0, ecx=0, edi=0, esi=0, ebx=0, chk=0;
long int  u1 = 559038272, u2 = 0x21523F22;
int l, i, j;

printf("\n\nName : ");
gets(name);

l = strlen(name);
if(l>=5 && l<=16)
{
for(j=0; j<l; j++)
{
	eax = name[j];
	for(i=0; i<j+2; i++)
	{
		ecx = eax;
		eax &= 0x3FFFFFFF;
		ecx &= 0xC0000000;
		eax = eax*2;
		edi = eax;
		eax = ecx;
		eax = eax>>0x1E;
		eax &= 1;
		ebx ^= ebx;
		eax &= 0x80000000;
		edx = edi;
		ebx &= 1;
		eax |= ebx;
		eax |= edi;
	}
chk += eax;
}
chk -= u1;

ltoa(chk, t1, 10);
ltoa((l-u2), t2, 10);

GetMD5(t1, strlen(t1), h1);
GetMD5(t2, strlen(t2), h2);

strcat(strcat(temp,h1),h2);

GetMD5(temp, strlen(temp), serial);

printf("\n\nSerial : ");

for(i=0; i<16; i++)
{
	if(i !=0 && i%4 == 0) printf("-");
	printf("%c", toupper(serial[i]));
}
printf("\n");
}
else
printf("\nLength of name must be between 5 & 16 !!\n");

getch();
}
