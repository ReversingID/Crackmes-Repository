#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

char cleftable[64] = "A-CHRDw87lNS0E9B2TibgpnMVys5XzvtOGJcYLU+4mjW6fxqZeF3Qa1rPhdKIouk";

char keychar1(size_t pseudolen)
{
    return cleftable[(pseudolen ^ 0x3B) & 0x3F];
}

char keychar2(char *pseudo, int pseudolen)
{
    char *ptr = &pseudo[pseudolen];
    int sum = 0;

    while((--pseudolen) != -1)
    {
        ptr--;
        sum += (uint8_t)*ptr;
    }

    return cleftable[(sum ^ 0x4F) & 0x3F];
}

char keychar3(char *pseudo, int pseudolen)
{
    unsigned int sum = 1;
    while((--pseudolen) != -1)
    {
        sum = (sum * ((unsigned char)*pseudo)) & 0xFF;
        pseudo += 1;
    }

    return cleftable[(sum ^ 0x55) & 0x3F];
}

char keychar4(char *pseudo, int pseudolen)
{
    unsigned int sum = *pseudo;
    while((--pseudolen) != -1)
    {
        pseudo += 1;
        if(*pseudo <= (char)sum)
            continue;

        sum = (unsigned int)*pseudo;
    }

    sum ^= 0x0E;
    srand(sum);
    return cleftable[rand() & 0x3F];
}

int sub(char pseudochar, int num)
{
    unsigned int sum = 1;

    if(num == 0)
    {
        return sum;
    }

    sum *= pseudochar;

    while((--num) != 0)
    {
        sum *= pseudochar;
    }

    return sum;
}

char keychar5(char *pseudo, int pseudolen)
{
 unsigned int sum = 0;

    pseudolen -= 1;

    while(pseudolen != -1)
    {
        sum += sub(*pseudo, 2);
        sum &= 0xFF;
        pseudo += 1;
        pseudolen -= 1;
    }

    return cleftable[(sum ^ 0xEF) & 0x3F];
}

char keychar6(char pseudochar)
{
    int sum = 0;

    if(pseudochar != 0)
    {
        do
        {
            sum = rand();
        } while((--pseudochar) != 0);
    }

    return cleftable[((sum & 0xFF) ^ 0xE5) & 0x3F];
}

char pseudo[256];
char clef[7];

int main()
{
    printf("Please enter a pseudo: ");
    scanf("%s", pseudo);

    int pseudolen = strlen(pseudo);
    clef[0] = keychar1(pseudolen);
    clef[1] = keychar2(pseudo, pseudolen);
    clef[2] = keychar3(pseudo, pseudolen);
    clef[3] = keychar4(pseudo, pseudolen);
    clef[4] = keychar5(pseudo, pseudolen);
    clef[5] = keychar6(*pseudo);
    clef[6] = '\0';
    printf("clef: %s\n", clef);
    return 0;
}
