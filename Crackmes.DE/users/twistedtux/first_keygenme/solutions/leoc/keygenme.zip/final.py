#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import ctypes

# function count1
def count1(str1):
    num = (len(str1) ^ 0x3B) & 0x3F
    return num

# function count2
def count2(str1):
    num = 0
    for i in str1:
        num += ord(i)
    return (num ^ 0x4F) & 0x3F

# function count3
def count3(str1):
    num = 1
    for i in sys.argv[1]:
        num *= ord(i)
    return (num ^ 0x55) & 0x3F

# function count4
def count4(str1):
    num = str1[0]
    for i in str1:
        if ord(i) > ord(num):
            num = i
    c.srand(ord(num) ^ 0xe)
    return c.rand() & 0x3f

# function count5
def count5_1(char, num = 2):
    if num:
        result = ord(char)
        while True:
            #--num;
            num -= 1
            if not num:
                break
            result *= ord(char)
    return result

def count5(string, length):
    num = 0
    i = length - 1
    j = 0
    while i != -1:
        v5 = i
        num = count5_1(sys.argv[1][j], 2) + num
        j += 1
        i = v5 - 1
    return (num ^ 0xEF) & 0x3F

# function count6
def count6(str1):
    #global c
    num = 0
    if str1[0]:
        v2 = c.rand();
        i = ord(str1[0])
        while True:
            v5 = i - 1
            if not v5:
                break
            v4 = v5
            v2 = c.rand()
            i = v4
        num = v2 ^ 0xE5
    return num & 0x3F

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print >> sys.stderr, '''usage: ./flag.py <pseudo>'''
        sys.exit(1)

    string = "A-CHRDw87lNS0E9B2TibgpnMVys5XzvtOGJcYLU+4mjW6fxqZeF3Qa1rPhdKIouk"
    clef = ""
    label = []
    c = ctypes.CDLL("libc.so.6")
    length = len(sys.argv[1])
    pseudo = sys.argv[1]

    label.append(count1(pseudo))
    label.append(count2(pseudo))
    label.append(count3(pseudo))
    label.append(count4(pseudo))
    label.append(count5(pseudo, length))
    label.append(count6(pseudo))

    for i in label:
        clef += string[i]
    print clef
