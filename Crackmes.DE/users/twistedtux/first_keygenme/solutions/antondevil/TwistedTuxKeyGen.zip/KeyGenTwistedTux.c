/*
 ============================================================================
 Name        : KeyGenTwistedTux.c
 Author      : AntonDevil
 Version     : 1.0
 Copyright   : You free to use this code
 Description : Keygen for TwistedTux keygenme C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

unsigned int bin_op(size_t len) {
	return (len ^ 0x3B) & 0x3F;
}

unsigned int sum(char *str, size_t len) {
	unsigned int res = 0;
	while (len-- > 0)
		res += (unsigned char) str[len];
	return (res ^ 0x4F) & 0x3F;
}

unsigned int mul(char *str, size_t len) {
	unsigned int res = 1;
	while (len-- > 0)
		res *= (unsigned char) str[len];
	return (res ^ 0x55) & 0x3F;
}

unsigned int largest(char *str, size_t len) {
	unsigned int res = 0;
	while (len-- > 0)
		if (res <= (unsigned char) str[len])
			res = (unsigned char) str[len];
	res ^= 0xE;
	srand(res);
	return rand() & 0x3F;
}

unsigned int sum_sqr(char *str, size_t len) {
	unsigned int res = 0;
	while (len-- > 0)
		res += (unsigned char) str[len] * (unsigned char) str[len];
	return (res ^ 0xEF) & 0x3F;
}

unsigned int randTimes(size_t times) {
	int res = 0;
	if (times == 0)
		return 0;
	while (times-- > 0)
		res = rand();
	return ((unsigned int) res ^ 0xE5) & 0x3F;
}

int main(int argc, char **argv) {
	if (argc < 2) {
		printf("Utilisation : %s <pseudo>\n\n", argv[0]);
		return 1;
	}
	char *charset = "A-CHRDw87lNS0E9B2TibgpnMVys5Xzvt"
					"OGJcYLU+4mjW6fxqZeF3Qa1rPhdKIouk";
	char *pseudo = argv[1];
	char pass[7] = {'\0'};
	size_t pseudoLen = strlen(pseudo);

	pass[0] = charset[bin_op(pseudoLen)];
	pass[1] = charset[sum(pseudo, pseudoLen)];
	pass[2] = charset[mul(pseudo, pseudoLen)];
	pass[3] = charset[largest(pseudo, pseudoLen)];
	pass[4] = charset[sum_sqr(pseudo, pseudoLen)];
	pass[5] = charset[randTimes((unsigned char) pseudo[0])];

	printf("Password is: %s\n\n", pass);
	return 0;
}
