#include <windows.h>
#include <iostream>
#include <tchar.h>

int _tmain(int argc, _TCHAR* argv[])
{
	char firstname[256], true_serialNr[256];

	ZeroMemory(true_serialNr,256);

	std::cout<<"~~~~~~~~~~~~~~~~~~[Beaving's Beavme keygen]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<std::endl;
	std::cout<<"~~~~~~~~~~~~~~~~~~~~# by indivisible_int #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<std::endl;
	std::cout<<std::endl;
l1:  
	int fnlen=0;

	do
	{
		std::cout<<"Name must be at least 4 chars"<<std::endl;
		std::cout<<"Enter the firstname: "<<std::endl;
		std::cin>>firstname;
	}while((fnlen=strlen(firstname))<4);

	if(strstr(firstname,"a") || strstr(firstname,"A"))
	{
		_itoa(fnlen*0x12331+0x665EE0,true_serialNr,10);
	}
	else if(strstr(firstname,"e") || strstr(firstname,"E"))
	{
		_itoa(fnlen*0x477F+0x3A180,true_serialNr,10);
	}
	else if(strstr(firstname,"i") || strstr(firstname,"I"))
	{
		_itoa(fnlen*0x175C3+0x2D42BC,true_serialNr,10);
	}
	else if(strstr(firstname,"o") || strstr(firstname,"O"))
	{
		_itoa(fnlen*0x0E541+0x3A3540,true_serialNr,10);
	}
	else if(strstr(firstname,"u") || strstr(firstname,"U"))
	{
		_itoa(fnlen*0x5B9E+0x1FDA47,true_serialNr,10);
	}
	else
	{
		std::cout<<"Firstname must contain at least one of the following symbols: 'a','A','e','E','i','I','o','O','u','U'"<<std::endl;
		goto l1;
	}
	std::cout<<"SerialNr is: "<<true_serialNr<<std::endl;
	system("PAUSE");
	return 0;
}

