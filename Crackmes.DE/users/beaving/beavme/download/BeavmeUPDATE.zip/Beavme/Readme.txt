BeavmeUPDATE by Beaving (ICQ: 806899 MSN: beaving@freenet.de)

Protections:

 - some lame anti-patches ;)

Rules:

 - no bruteforcing

Mission:

 - try to patch it and/or make a keygen


It's my first crack me and I use some lameish methods but see urself ;)

I'm coding for 3 months now and I tried to create something new.

Example:

Firstname: Beaving
SerialNr: 7230775

or

Firstname: crackmes.de
SerialNr: 7528955

(info: serial is INT)