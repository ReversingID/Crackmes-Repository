/************************************
*                                   *
* Keygen for: CrackMe #2 by JoeMama *
* by ManSun^I.C.T.                  *
* date: 18.01.2004                  *
*                                   *
*************************************/

#include <iostream.h>
#include <stdio.h>

int strlen(char *t);
void join(char *dest, char *source);
void header(void);

void main(void)
{
char serial[100] = "JMC-";
char name[50];
char tab1[] = "-148";
char * wsk;
int i = 0;
int length = 0;
	
	header();
	//************** Check name length **********
	do {
		cout << "Enter Name: ";
		cin >> name;
		length = strlen(name);
		if(length < 5) cout << "Name must be > 4" << endl;
		}
	while(length < 5);

	if(length > 9) {name[9] = NULL;}        //Crackme red only 9 char name
		
	//*************** Name processing ************
	wsk = name;
	while(*wsk != NULL)
		{
		if(*wsk > 'H') *wsk -= i;			//0x48 = 'H'
		if(*wsk < 'H') *wsk += i;
		i++;
		wsk++;
		}

	//************** Composition serial **********
	join(serial, name);
	join(serial, tab1);
	cout << "Serial: " << serial << endl;

getchar();
}



/*-------Function counting length name--------*/
int strlen(char *t)
{
int l=0;
while ( *(t++) != '\0' )
      l++;
return l;
}

/*-------Function adding source to dest------*/
void join(char *dest, char *source)
{
while(*(dest++));
dest--;
while(*(dest++)=*(source++));
}

/*-------Header Keygen-----------------------*/
void header(void)
{
cout << "  ******************************" << endl
	 << "  * iDLE cRACKERS tEAM present *" << endl
	 << "  ******************************" << endl
     << " Keygen for CrackMe #2 by JoeMama" << endl
	 << " by ManSun^I.C.T." << endl << endl;
}