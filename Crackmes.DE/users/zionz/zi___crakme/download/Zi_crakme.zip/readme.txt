This is my first crakme, its written in BlitzBasic, i was not able to crack this :(.
Note: Consider it cracked if it accept any serial, not finding the right one.