#include <windows.h>
#include "DAX.h"

LRESULT CALLBACK WindowProcedure (HWND, UINT, WPARAM, LPARAM);


char szClassName[ ] = "Keygen";

int WINAPI WinMain (HINSTANCE hThisInstance,
                    HINSTANCE hPrevInstance,
                    LPSTR lpszArgument,
                    int nFunsterStil)

{
    HWND hwnd;              
    MSG messages;        
    WNDCLASSEX wincl;       
    HBRUSH hBrush;
    LOGBRUSH sBrush;

    wincl.hInstance = hThisInstance;
    wincl.lpszClassName = szClassName;
    wincl.lpfnWndProc = WindowProcedure;     
    wincl.style = CS_DBLCLKS;                
    wincl.cbSize = sizeof (WNDCLASSEX);


    wincl.hIcon = LoadIcon (NULL, IDI_WINLOGO);
    wincl.hIconSm = LoadIcon (NULL, IDI_WINLOGO);
    wincl.hCursor = LoadCursor (NULL, IDC_CROSS);
    wincl.lpszMenuName = NULL;                
    wincl.cbClsExtra = 0;                     
    wincl.cbWndExtra = 0;                   


sBrush.lbStyle = BS_SOLID;
sBrush.lbColor = RGB(0, 191, 255);
sBrush.lbHatch = 0;
hBrush = CreateBrushIndirect(&sBrush);

    wincl.hbrBackground = hBrush;


    if (!RegisterClassEx (&wincl))
        return 0;

 
    hwnd = CreateWindowEx (
           0,                  
           szClassName,       
           "Zi Crackme2 - Keygen",      
           WS_OVERLAPPEDWINDOW, 
           CW_USEDEFAULT,     
           CW_USEDEFAULT,       
           230,               
           250,               
           HWND_DESKTOP,      
           NULL,            
           hThisInstance,      
           NULL               
           );
HWND hTool;           




    ShowWindow (hwnd, nFunsterStil);


    while (GetMessage (&messages, NULL, 0, 0))
    {
       
        TranslateMessage(&messages);
    
        DispatchMessage(&messages);
    }

  
    return messages.wParam;
}

HWND edit1;
HWND edit2;
char buf[32]="";

LRESULT CALLBACK WindowProcedure (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)                  
    {
        case WM_DESTROY:
            PostQuitMessage (0);      
            break;
        case WM_CREATE: 
              
       CreateWindow (
       "button",         
       "Generate",
       WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
       60, 160, 90, 20,
       hwnd,           
       (HMENU)1,      
       ((LPCREATESTRUCT) lParam)->hInstance,
       NULL
       );
       
      edit1 = CreateWindowEx(WS_EX_CLIENTEDGE,
							"EDIT",
							"DaXXo",
							WS_BORDER|WS_VISIBLE|WS_CHILD|ES_CENTER,
							30,40,160,30,
							hwnd,
							0,
							((LPCREATESTRUCT) lParam)->hInstance,
							NULL);
							
	edit2 = CreateWindowEx(WS_EX_CLIENTEDGE,
							"EDIT",
							"",
							WS_BORDER|WS_VISIBLE|WS_CHILD|ES_CENTER,
							30,77,160,30,
							hwnd,
							0,
							((LPCREATESTRUCT) lParam)->hInstance,
							NULL);
       
       break;
       case WM_COMMAND:
      
       switch(LOWORD(wParam)){
       case 1:
 GetWindowText(edit1,buf,6);  
  
 if(Texlen(buf)!=5){
 MessageBox(0,"Error, Name Must be 5 chars","Error",MB_OK|MB_ICONERROR);
 return 0;}   
 
 __int64 i=0; // For older compilers just use int
 
 i = buf[0]+buf[1];
 i += buf[3];
 i *= buf[2];
 i += buf[4];
 i += buf[0];   
 i += buf[4];
 i *= buf[4];
 i += buf[3];
 
 strcpy(buf,ntos(i));
 
 SetWindowText(edit2,buf);      
        break;
      }
            
       
            break;
        default:                     
            return DefWindowProc (hwnd, message, wParam, lParam);
    }

    return 0;
}

