#ifndef _DAX_HPP
#define _DAX_HPP
#endif
#include <stdio.h>

int Texlen(char* len){   
int i=0;
char ab='i';  
while(ab != '\0'){         
ab = len[i];   
i++;}
i-=1; 
return i;    
}

char *ntos(int conv){
char buffer[512]="";          
sprintf(buffer, "%d", conv);               
return buffer;    
}

