﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.Windows.Forms;


namespace Keygen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void generate_serialClick(object sender, EventArgs e)
        {
            byte[] buffer = MD5.Create().ComputeHash(Encoding.ASCII.GetBytes(name.Text));
            decimal d = buffer[15] + 1.0M;
            for (int i = 0; i < 15; i++)
            {
                d = (1.0M / d) + buffer[14 - i]+1;
            }
            d = (1.0M + (buffer[5] % 4)) + (10.0M / d);

            decimal c = d * d + d;
            string c_string = (c * 100000000000000M).ToString("0");
            serial.Text = c_string.Substring(0,15) + "-" + (c_string.Length-15).ToString();
        }
    }
}
