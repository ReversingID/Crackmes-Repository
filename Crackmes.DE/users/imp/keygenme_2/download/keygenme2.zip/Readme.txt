Keygenme #2 by __imp__

This crackme is written in C#, therefore it's for those who familiar with .NET environment (.NET framework v1.0).
I didn't employ any 3rd party protectors or obfuscators.

Rules:
----------------------

It's up to you what tools and methods to use, everything is allowed.

To do:

1) Find the appropriate format for name and key.
2) Make a key generator.
3) Write a tutorial.

----------------------

Good luck,

__imp__				September 18, 2007