#include <windows.h>
#include "resource.h"

#include <string>
#include <sstream>
#include <iomanip>
using namespace std;

typedef unsigned __int64 QWORD;

QWORD pshufw8D(const QWORD& qwIn)
{
	//pshufw qwOut,qwIn,0x8D
	QWORD qwOut;
	const unsigned char* pcIn=reinterpret_cast<const unsigned char*>(&qwIn);
	unsigned char* pcOut=reinterpret_cast<unsigned char*>(&qwOut);
	pcOut[0]=pcIn[2];
	pcOut[1]=pcIn[3];
	pcOut[2]=pcIn[6];
	pcOut[3]=pcIn[7];
	pcOut[4]=pcIn[0];
	pcOut[5]=pcIn[1];
	pcOut[6]=pcIn[4];
	pcOut[7]=pcIn[5];
	return qwOut;
}

string GetKey(const string& sName)
{
	if(!sName.length()||
		sName.length()>51)
	{
		return "";
	}

	unsigned char acName[63+1];
	unsigned char cNameIndex=0;
	for(string::const_iterator psName=sName.begin();
		psName!=sName.end();
		++psName,++cNameIndex)
	{
		acName[cNameIndex]=
			*reinterpret_cast<const unsigned char*>(&(*psName));
	}

	for(;cNameIndex<sizeof(acName);++cNameIndex)
	{
		DWORD dw=cNameIndex/static_cast<DWORD>(sName.length());
		//the application is using the 'div' instruction!
		if(cNameIndex%sName.length())
		{
			reinterpret_cast<unsigned char*>(&dw)[1]=
				cNameIndex%static_cast<unsigned char>(sName.length());
		}

		acName[cNameIndex]=acName[reinterpret_cast<unsigned char*>(&dw)[1]]+
			reinterpret_cast<unsigned char*>(&dw)[1]+1;
	}

	QWORD qwNameHash=0;
	for(char cQuadWord=7;cQuadWord>=0;--cQuadWord)
	{
		qwNameHash^=*reinterpret_cast<QWORD*>(&acName[cQuadWord*8]);
		for(char cBit=63;cBit>=0;--cBit)
		{
			if(qwNameHash>>63)
			{
				qwNameHash<<=1;
				qwNameHash^=0x42F0E1EBA9EA3693;
			}

			qwNameHash<<=1;
		}
	}

	const unsigned char acShiftTable[64]={
		0xC,  0x1E, 0x5,  0xE,  0x27, 0x0,  0x1F, 0x8,  0x1C, 0x2C,
		0x15, 0x2F, 0x25, 0x38, 0x3E, 0x2E, 0x3B, 0x26, 0x13, 0x33,
		0x2D, 0x0D, 0x21, 0xA,  0x31, 0x12, 0x10, 0x6,  0xB,  0x3D,
		0x3F, 0x30, 0x2B, 0x34, 0x2,  0x17, 0x18, 0x22, 0x29, 0x4,
		0x32, 0x16, 0x23, 0x24, 0x37, 0x28, 0x3A, 0x39, 0x7,  0x1B,
		0x11, 0x14, 0x35, 0x1D, 0x3C, 0xF,  0x1,  0x3,  0x1A, 0x19,
		0x9,  0x2A, 0x20, 0x36};

	QWORD qwKey=pshufw8D(
		(pshufw8D(qwNameHash)>>5)|(pshufw8D(qwNameHash)<<(64-5)));
	for(unsigned char c=0;c<0x3D;++c)
	{
		QWORD qwNewKey=0;
		for(unsigned char cBit=0;cBit<64;++cBit)
		{
			if(qwKey&(1i64<<cBit))
			{
				qwNewKey|=(1i64<<acShiftTable[cBit]);
			}
		}
		qwKey=(qwNewKey<<11)|(qwNewKey>>(64-11));
	}

	ostringstream ssKey;
	ssKey << hex << uppercase << setfill('0') <<
		setw(4) << reinterpret_cast<WORD*>(&qwKey)[3] << "-" <<
		setw(4) << reinterpret_cast<WORD*>(&qwKey)[2] << "-" <<
		setw(4) << reinterpret_cast<WORD*>(&qwKey)[1] << "-" <<
		setw(4) << reinterpret_cast<WORD*>(&qwKey)[0];
	return ssKey.str();
}

BOOL CALLBACK EnumChildrenProc(HWND Child,pair<DWORD,HWND>*const pdwUserData)
{
	if(reinterpret_cast<DWORD>(GetMenu(Child))==pdwUserData->first)
	{
		pdwUserData->second=Child;
		return FALSE;
	}
	else
	{
		return TRUE;
	}
}

HWND FindChildWindow(const HWND& Parent,const DWORD& dwChildWindowID)
{
	pair<DWORD,HWND> dwUserData(dwChildWindowID,NULL);
	EnumChildWindows(Parent,
		reinterpret_cast<WNDENUMPROC>(EnumChildrenProc),
		reinterpret_cast<LPARAM>(&dwUserData));
	return dwUserData.second;
}

BOOL CALLBACK DlgProc(HWND Window,UINT Message,WPARAM WParam,LPARAM LParam)
{
	switch(Message)
	{
	case WM_INITDIALOG:
		SendDlgItemMessage(Window,IDC_NAME,EM_SETLIMITTEXT,51,0);
		SetDlgItemText(Window,IDC_NAME,"Trundle");
		break;

	case WM_COMMAND:
		switch(LOWORD(WParam))
		{
		case IDC_ABOUT:
			MessageBox(Window,
				"Solution to __imp__'s KeygenMe #3 by "
					"Christopher 'Trundle' Schmidt\n\n"
					"http://trundle.gamedev.de/",
				"Solution to __imp__'s KeygenMe #3 by Trundle",
				MB_OK);
			break;

		case IDC_EXIT:
			EndDialog(Window,0);
			break;

		case IDC_NAME:
			if(HIWORD(WParam)==EN_UPDATE)
			{
				char acName[51];
				GetDlgItemText(Window,IDC_NAME,acName,sizeof(acName));
				if(!GetKey(acName).length())
				{
					SetDlgItemText(Window,IDC_KEY,"[ERROR: Invalid name]");
					break;
				}
				
				SetDlgItemText(Window,IDC_KEY,GetKey(acName).c_str());
				if(FindWindow("KGME3","Keygenme #3 by __imp__"))
				{
					SendMessage(
						FindChildWindow(FindWindow("KGME3",
							"Keygenme #3 by __imp__"),0x3E9),
						WM_SETTEXT,
						0,
						reinterpret_cast<LPARAM>(acName));
					SendMessage(
						FindChildWindow(FindWindow("KGME3",
							"Keygenme #3 by __imp__"),0x3EA),
						WM_SETTEXT,
						0,
						reinterpret_cast<LPARAM>(GetKey(acName).c_str()));
				}
			}
			break;
		}
		break;

	case WM_CLOSE:
		EndDialog(Window,0);
		break;

	default:
		return FALSE;
	}

	return TRUE;
}

int WINAPI WinMain(HINSTANCE Instance,HINSTANCE,LPSTR,int iCmdShow)
{
	return DialogBox(Instance,MAKEINTRESOURCE(IDD_MAINDLG),NULL,DlgProc);
}