#include <iostream>
#include <limits>
using namespace std;

typedef unsigned __int16 WORD;

const unsigned char acShiftTable[64]={
	0xC,  0x1E, 0x5,  0xE,  0x27, 0x0,  0x1F, 0x8,  0x1C, 0x2C,
	0x15, 0x2F, 0x25, 0x38, 0x3E, 0x2E, 0x3B, 0x26, 0x13, 0x33,
	0x2D, 0x0D, 0x21, 0xA,  0x31, 0x12, 0x10, 0x6,  0xB,  0x3D,
	0x3F, 0x30, 0x2B, 0x34, 0x2,  0x17, 0x18, 0x22, 0x29, 0x4,
	0x32, 0x16, 0x23, 0x24, 0x37, 0x28, 0x3A, 0x39, 0x7,  0x1B,
	0x11, 0x14, 0x35, 0x1D, 0x3C, 0xF,  0x1,  0x3,  0x1A, 0x19,
	0x9,  0x2A, 0x20, 0x36};

unsigned char FindIndexInShiftTable(const unsigned char& cElement)
{
	for(unsigned char c=0;;++c)
	{
		if(acShiftTable[c]==cElement)
		{
			return c;
		}
	}
}

int main()
{
	unsigned char acWantedKeyBits[64];
	for(unsigned char cBit=0;cBit<64;++cBit)
	{
		unsigned char cCurrentBitSet=cBit;
		for(unsigned char c=0;c<0x3D;++c)
		{
			cCurrentBitSet=acShiftTable[cCurrentBitSet]+11;
			if(cCurrentBitSet>=64)
			{
				cCurrentBitSet-=64;
			}
		}

		acWantedKeyBits[cBit]=cCurrentBitSet;
	}

	unsigned int iNumExponents=0;
	//The virtual machine supports only loops with two byte control variables
	for(unsigned int iExponent=1;
		iExponent<=numeric_limits<WORD>::max();
		++iExponent)
	{
		unsigned char cBit;
		for(cBit=0;cBit<64;++cBit)
		{
			unsigned char cCurrentBitSet=cBit;
			for(unsigned int i=0;i<iExponent;++i)
			{
				if(cCurrentBitSet>=11)
				{
					cCurrentBitSet=FindIndexInShiftTable(cCurrentBitSet-11);
				}
				else
				{
					cCurrentBitSet=
						FindIndexInShiftTable(64-(11-cCurrentBitSet));
				}
			}

			if(cCurrentBitSet!=acWantedKeyBits[cBit])
			{
				break;
			}
		}

		if(cBit==64)
		{
			++iNumExponents;
			cout<<iExponent<<endl;
		}
	}

	cout<<endl<<
		"Altogether there are "<<iNumExponents<<
		" valid exponents."<<endl;

	return 0;
}