Author: Guy

Consider this my first crackme, hopefully soon to be one of many.

It mixes managed and unmanaged code, has plenty of anti-debug code, executable integrity checks, etc.

Sample name/serial:

Name: John
Serial: 1b1f

Rules:

Patches are allowed, keygen preferred.



Have fun!