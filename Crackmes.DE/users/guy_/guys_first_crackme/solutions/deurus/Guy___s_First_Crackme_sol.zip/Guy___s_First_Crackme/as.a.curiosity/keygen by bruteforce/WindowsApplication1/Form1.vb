﻿Imports System

Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim a, b, temp, temp2 As String
        Dim i, o, x As Integer
        TextBox2.Text = ""
        a = "!" & Chr(34) & "#$%&'()*+,-./012345689:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvxyz{|}~" & Chr(32)
        b = "ZVRNJFB1zvrnjfbxhXHpP`1tld\TLDomkigeca111ywusqOMKIGECA_][YWUSQ^ZVRNJFB1zvrnjfbxhXHpP`1tld\TL^"
        For i = 1 To Len(TextBox1.Text)
            temp = Mid(TextBox1.Text, i, 1)
            If temp = "7" Or temp = "w" Then
                o = 100
                GoTo errores
            End If
            For o = 1 To 93
                temp2 = Mid(a, o, 1)
                If temp = temp2 Then
                    x = o
                    GoTo labelo
                End If
            Next
labelo:
            TextBox2.Text = TextBox2.Text & Mid(b, x, 1)
        Next
errores:
        If o = 100 Then
            TextBox2.Text = "Chars w and 7 not supported"
            TextBox1.Text = ""
        End If
    End Sub
End Class
