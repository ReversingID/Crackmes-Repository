﻿Public Class Form1

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim t1, i As Integer
        txtserial.Text = ""
        For i = 1 To Len(txtname.Text)
            t1 = Asc(Mid(txtname.Text, i, 1))
            If t1 = 40 Or t1 = 56 Or t1 = 72 Or t1 = 73 Or t1 = 74 Or t1 = 104 Or t1 = 120 Then
                t1 = 49
                GoTo labelo2
            End If
            If t1 = 55 Or t1 = 119 Then
                t1 = 0
                txtserial.Text = "chars w and 7 not found"
                GoTo labelo
            Else
                If t1 < 64 Then
                    t1 = t1 + 64
                End If
                t1 = t1 Xor 51
                t1 = t1 * 2
                t1 = t1 Xor 137
                While t1 < 65
                    t1 = t1 * 2
                End While
                While t1 > 122
                    t1 = t1 / 2
                End While
labelo2:
                txtserial.Text = txtserial.Text & Chr(t1)
            End If
        Next
labelo:
    End Sub
End Class
