Findme by indomit.

I offer my new puzzle to you :) 

Rules are very simple:
1) Find correct serial;
2) No patching, no bruteforcing;
3) Write a small tutorial;

If you find some bugs or exploits, please report me :)

Regards, 
	indomit.