namespace key4me
{
    using System;

    internal class Sirtet
    {
        public Erugif Eru = new Erugif();
        private static int HEIGHT = 20;
        private bool is_game_over;
        private int result;
        private Random rnd;
        public bool[,] TheWell = new bool[WIDTH, HEIGHT];
        private static int WIDTH = 10;

        public Sirtet()
        {
            this.Clear();
            this.Init(0);
        }

        public Sirtet(Sirtet s)
        {
            rnd = s.rnd;
            result = s.result;
            is_game_over = s.is_game_over;
            int x = s.TheWell.GetLength(0), y = s.TheWell.GetLength(1);
            TheWell = new bool[x, y];
            for (int i = 0; i < x; i++)
                for (int j = 0; j < y; j++)
                    TheWell[i, j] = s.TheWell[i, j];
            Eru = new Erugif(s.Eru);
        }

        private bool CanFall(byte col)
        {
            int firstCol = this.GetFirstCol();
            int num3 = (this.GetLastCol() - firstCol) + 1;
            return (col <= (WIDTH - num3));
        }

        private bool CanSetFig(byte col, int row, int first_col, int last_col, int first_row, int last_row)
        {
            for (int i = first_col; i <= last_col; i++)
            {
                for (int j = first_row; j <= last_row; j++)
                {
                    int num3 = col + (i - first_col);
                    int num4 = row + (j - first_row);
                    if (num4 >= HEIGHT)
                    {
                        return false;
                    }
                    if (this.Eru.fig[i, j] && this.TheWell[num3, num4])
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        private void Clear()
        {
            for (int i = 0; i < WIDTH; i++)
            {
                for (int j = 0; j < HEIGHT; j++)
                {
                    this.TheWell[i, j] = false;
                }
            }
        }

        private int DeleteRow()
        {
            int num = 0;
            for (int i = 0; i < HEIGHT; i++)
            {
                int num3 = 0;
                for (int j = 0; j < WIDTH; j++)
                {
                    if (this.TheWell[j, i])
                    {
                        num3++;
                    }
                }
                if (num3 == WIDTH)
                {
                    this.DeleteRow(i);
                    num++;
                }
            }
            return num;
        }

        private void DeleteRow(int row)
        {
            bool[,] flagArray = new bool[WIDTH, HEIGHT];
            for (int i = HEIGHT - 1; i > 0; i--)
            {
                for (int m = 0; m < WIDTH; m++)
                {
                    if (i > row)
                    {
                        flagArray[m, i] = this.TheWell[m, i];
                    }
                    else
                    {
                        flagArray[m, i] = this.TheWell[m, i - 1];
                    }
                }
            }
            for (int j = 0; j < WIDTH; j++)
            {
                flagArray[j, 0] = false;
            }
            for (int k = 0; k < HEIGHT; k++)
            {
                for (int n = 0; n < WIDTH; n++)
                {
                    this.TheWell[n, k] = flagArray[n, k];
                }
            }
        }

        public bool DoMove(byte n, byte r)
        {
            if (this.CanFall(n))
            {
                this.Fall(n);
                if (!this.is_game_over)
                {
                    this.CheckRows();
                    return true;
                }
            }
            return false;
        }

        private void Fall(byte col)
        {
            int firstCol = this.GetFirstCol();
            int lastCol = this.GetLastCol();
            int firstRow = this.GetFirstRow();
            int lastRow = this.GetLastRow();
            int row = 0;
            while (!this.is_game_over && this.CanSetFig(col, row, firstCol, lastCol, firstRow, lastRow))
            {
                row++;
            }
            row--;
            if (row == -1)
            {
                this.is_game_over = true;
            }
            else
            {
                this.SetFig(col, row, firstCol, lastCol, firstRow, lastRow);
            }
        }

        private bool FullRowsExists()
        {
            for (int i = 0; i < HEIGHT; i++)
            {
                int num2 = 0;
                for (int j = 0; j < WIDTH; j++)
                {
                    if (this.TheWell[j, i])
                    {
                        num2++;
                    }
                }
                if (num2 == WIDTH)
                {
                    return true;
                }
            }
            return false;
        }

        public int GetFirstCol()
        {
            int num = 0;
            for (int i = 0; i < 4; i++)
            {
                bool flag = false;
                for (int j = 0; j < 4; j++)
                {
                    flag = flag || this.Eru.fig[i, j];
                }
                if (flag)
                {
                    return num;
                }
                num++;
            }
            return num;
        }

        public int GetFirstRow()
        {
            int num = 0;
            for (int i = 0; i < 4; i++)
            {
                bool flag = false;
                for (int j = 0; j < 4; j++)
                {
                    flag = flag || this.Eru.fig[j, i];
                }
                if (flag)
                {
                    return num;
                }
                num++;
            }
            return num;
        }

        public int GetLastCol()
        {
            int num = 3;
            for (int i = 3; i >= 0; i--)
            {
                bool flag = false;
                for (int j = 0; j < 4; j++)
                {
                    flag = flag || this.Eru.fig[i, j];
                }
                if (flag)
                {
                    return num;
                }
                num--;
            }
            return num;
        }

        public int GetLastRow()
        {
            int num = 3;
            for (int i = 3; i >= 0; i--)
            {
                bool flag = false;
                for (int j = 0; j < 4; j++)
                {
                    flag = flag || this.Eru.fig[j, i];
                }
                if (flag)
                {
                    return num;
                }
                num--;
            }
            return num;
        }

        public int GetResult()
        {
            return this.result;
        }

        private void CheckRows()
        {
            int num = 0;
            if (this.FullRowsExists())
            {
                num = this.DeleteRow();
            }
            switch (num)
            {
                case 1:
                    this.result += 100;
                    return;

                case 2:
                    this.result += 300;
                    return;

                case 3:
                    this.result += 600;
                    return;

                case 4:
                    this.result += 0x4b0;
                    return;
            }
        }

        public void Init(int ID)
        {
            this.Clear();
            this.rnd = new Random(ID);
            this.result = 0;
            this.is_game_over = false;
        }

        private void SetFig(byte col, int row, int first_col, int last_col, int first_row, int last_row)
        {
            for (int i = first_col; i <= last_col; i++)
            {
                for (int j = first_row; j <= last_row; j++)
                {
                    int num3 = col + (i - first_col);
                    int num4 = row + (j - first_row);
                    this.TheWell[num3, num4] = this.Eru.fig[i, j] || this.TheWell[num3, num4];
                }
            }
        }

        public int GenNextFig()
        {
            byte n = (byte) this.rnd.Next(5);
            switch (n)
            {
                case 2:
                    n = (byte) (n + ((byte) (this.rnd.Next(2) * 3)));
                    break;

                case 4:
                    n = (byte) (n + ((byte) (this.rnd.Next(2) * 2)));
                    break;
            }
            return n;
        }
    }
}

