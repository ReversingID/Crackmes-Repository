namespace key4me
{
    using System;

    internal class Erugif
    {
        public bool[,] fig = new bool[4, 4];

        public Erugif()
        {
            this.Clear();
        }

        public Erugif(Erugif e)
        {
            int x = e.fig.GetLength(0), y = e.fig.GetLength(1);
            fig = new bool[x, y];
            for (int i = 0; i < x; i++)
                for (int j = 0; j < y; j++)
                    fig[i, j] = e.fig[i, j];
        }

        private void Clear()
        {
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    this.fig[i, j] = false;
                }
            }
        }

        private void Rotate()
        {
            bool[,] flagArray = new bool[4, 4];
            for (int i = 0; i < 4; i++)
            {
                for (int k = 0; k < 4; k++)
                {
                    flagArray[3 - k, i] = this.fig[i, k];
                }
            }
            for (int j = 0; j < 4; j++)
            {
                for (int m = 0; m < 4; m++)
                {
                    this.fig[j, m] = flagArray[j, m];
                }
            }
        }

        private void Rotate(int rot)
        {
            for (int i = 0; i < rot; i++)
            {
                this.Rotate();
            }
        }

        public void SetFig(int n, int rot)
        {
            this.Clear();
            switch (n)
            {
                case 0:
                    bool flag;
                    bool flag2;
                    this.fig[2, 2] = flag = true;
                    this.fig[2, 1] = flag2 = flag;
                    this.fig[1, 1] = this.fig[1, 2] = flag2;
                    break;

                case 1:
                    bool flag4;
                    bool flag5;
                    this.fig[1, 3] = flag4 = true;
                    this.fig[1, 2] = flag5 = flag4;
                    this.fig[1, 0] = this.fig[1, 1] = flag5;
                    break;

                case 2:
                    bool flag7;
                    bool flag8;
                    this.fig[1, 2] = flag7 = true;
                    this.fig[1, 1] = flag8 = flag7;
                    this.fig[2, 0] = this.fig[2, 1] = flag8;
                    break;

                case 3:
                    bool flag10;
                    bool flag11;
                    this.fig[2, 1] = flag10 = true;
                    this.fig[1, 2] = flag11 = flag10;
                    this.fig[1, 0] = this.fig[1, 1] = flag11;
                    break;

                case 4:
                    bool flag13;
                    bool flag14;
                    this.fig[1, 2] = flag13 = true;
                    this.fig[2, 2] = flag14 = flag13;
                    this.fig[2, 0] = this.fig[2, 1] = flag14;
                    break;

                case 5:
                    bool flag16;
                    bool flag17;
                    this.fig[2, 2] = flag16 = true;
                    this.fig[2, 1] = flag17 = flag16;
                    this.fig[1, 0] = this.fig[1, 1] = flag17;
                    break;

                case 6:
                    bool flag19;
                    bool flag20;
                    this.fig[2, 2] = flag19 = true;
                    this.fig[1, 2] = flag20 = flag19;
                    this.fig[1, 0] = this.fig[1, 1] = flag20;
                    break;
            }
            this.Rotate(rot);
        }
    }
}

