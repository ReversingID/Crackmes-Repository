using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace key4me
{
    class Form1
    {
        byte[] q = new byte[1000];
        int pos = 0;
        public int konstanta = 9;

        private void dump()
        {
            Console.WriteLine(Convert.ToBase64String(q, 0, pos));
        }

        public int covered(bool[,] well)
        {
            int y = well.GetLength(0), x = well.GetLength(1);
            int result = 0;
            for (int j = 0; j < y; j++)
            {
                bool cover = false;
                for (int i = 0; i < x; i++)
                {
                    if (well[j, i])
                        cover = true;
                    else if (cover)
                        result++;
                }
            }
            return result;
        }

        static public void DumpWell(bool[,] well)
        {
            int x = well.GetLength(1), y = well.GetLength(0);
            for (int i = 0; i < x; i++)
            {
                Console.Write('|');
                for (int j = 0; j < y; j++)
                    Console.Write(well[j, i] ? 'X' : ' ');
                Console.WriteLine('|');
            }
            for (int j = 0; j < y + 2; j++)
                Console.Write('-');
            Console.WriteLine();
            Console.WriteLine();
        }

        public int evaluate(bool[,] before, bool[,] after, int start, int end)
        {
            int y = before.GetLength(0), x = before.GetLength(1);
            int result = konstanta * (covered(after) - covered(before));
            int topmost = x;
            for (int i = start; i < end; i++)
            {
                if (i >= y)
                    return int.MaxValue;
                for (int j = 0; j < x; j++)
                {
                    if (after[i, j])
                    {
                        if (topmost > j)
                            topmost = j;
                        break;
                    }
                }
            }
            return result - topmost;
        }

        public void Generate(Sirtet t)
        {
            int nextFig = t.GenNextFig();
            while (t.GetResult() <= 50000)
            {
                int fig = nextFig;
                nextFig = t.GenNextFig();

                int best = Int32.MaxValue;
                Sirtet next = null;
                q[pos] = 47;
                for (int i = 0; i < 10; i++)
                {
                    for (int j = 0; j < 4; j++)
                    {
                        Sirtet poss = new Sirtet(t);
                        poss.Eru.SetFig(fig, j);
                        int start = i, end = i + poss.GetLastCol() - poss.GetFirstCol() + 1;
                        if (!poss.DoMove((byte)i, (byte)j))
                            continue;
                        int badness = evaluate(t.TheWell, poss.TheWell, start, end);
                        for (int i2 = 0; i2 < 10; i2++)
                        {
                            for (int j2 = 0; j2 < 4; j2++)
                            {
                                Sirtet poss2 = new Sirtet(poss);
                                poss2.Eru.SetFig(nextFig, j2);
                                int start2 = i2, end2 = i2 + poss2.GetLastCol() - poss2.GetFirstCol() + 1;
                                if (!poss2.DoMove((byte)i2, (byte)j2))
                                    continue;

                                int badness2 = evaluate(poss.TheWell, poss2.TheWell, start2, end2);
                                //Console.WriteLine("moves {0} {1}, {2} {3}: {4}, {5}", i, j, i2, j2, badness, badness2);
                                if (badness + badness2 < best)
                                {
                                    next = poss;
                                    best = badness + badness2;
                                    q[pos] = (byte)(i * 4 + j);
                                }
                            }
                        }
                    }
                }
                if (next == null)
                {
                    Console.WriteLine("Oops, only {0} reached", t.GetResult());
                    dump();
                    return;
                }
                //Console.WriteLine("next move {0}, {1}", q[pos] / 4, q[pos] % 4);
                //DumpWell(next.TheWell);
                pos++;
                t = next;
            }
            dump();
        }

        public int GetID(string name)
        {
            SHA512Managed managed = new SHA512Managed();
            byte[] bytes = Encoding.ASCII.GetBytes(name);
            byte[] buffer2 = managed.ComputeHash(bytes);
            int num = 0;
            for (int i = 0; i < 0x10; i++)
            {
                int num3 = 0;
                for (int j = 0; j < 3; j++)
                {
                    num3 += buffer2[(4 * i) + j];
                    num3 = num3 << 8;
                }
                num3 += buffer2[(4 * i) + 3];
                num ^= num3;
            }
            return num;
        }
    }
    
    class Program
    {
        static void Main(string[] args)
        {
            Form1 f = new Form1();
            Sirtet t = new Sirtet();
            String name;

            try
            {
                name = args[0];
                f.konstanta = Int32.Parse(args[1]);
            }
            catch (Exception)
            {
                Console.WriteLine("Usage: keygen.exe <name> <ratio>");
                return;
            }

            t.Init(f.GetID(name));
            f.Generate(t);
        }
    }
}
