>>> The Cattle Crackme <<<

Rules are simple as always:
    1. No Patching.
    2. No Brute Forcing.

Write a keygen (for best, if there are more than one solution) 
or single key-file (for good) and a little tutorial.

------------------
    indomit
    Apr. 23, 2009.
------------------