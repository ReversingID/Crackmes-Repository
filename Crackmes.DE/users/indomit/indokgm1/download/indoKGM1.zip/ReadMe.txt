=====================================================
Crackme		: indoKGM1.exe
Author 		: indomit
Date 		: 21. Apr, 2006
=====================================================

Hello All!

This my first crackme and it very easy. Just find the correct serial, 
create keygen, and write a small tut.  =)
But it have TWO ways to key it:
	
1: For newbie: Try to find serial for your name 
               which make a goodboy message :)
2: For profi : Try to find name & serial 
               which make a VERY goodboy message %)

And for all - make a keygen %)
It was perfect if you try to create keygen without brute force.

And of coz, patches disallowed. 
It hasn't any anti-debugger stuff...

Good luck! ;)

PS: Tested only on Windows XP SP2.

=====================================================
Greets to CuTedEvil, l0calh0st, HMX0101, 
Ox87k, haggar, Mods and members of 
crackme.de and you! :)
