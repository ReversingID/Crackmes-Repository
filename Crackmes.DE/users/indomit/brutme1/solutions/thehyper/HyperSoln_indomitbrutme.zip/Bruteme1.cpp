
#include "stdafx.h"
int _tmain(int argc, _TCHAR* argv[])
{
	unsigned int a,b,val;
	for(a=0;a<=9999;a+=2)
	{
		for(b=0;b<=9999;b+=2)
		{
			_asm
			{
				mov edx,a
				mov ecx,b
				mov eax,0xd00b
	loopdude:
				XOR EDX,ECX
				MOV EBX,ECX
				SHL EBX,2
				MOV ECX,EDX
				SHR ECX,2
				ADD EBX,ECX
				MOV ECX,EBX
				XOR ECX,EDX
				DEC EAX
				JNZ loopdude
				MOV val,EBX
			}
			printf("%d %d\n",a,b);
			if(val==0x6F3AAD5A)
			{
				printf("Got it,the values are %d %d\nBye Byte",a,b);
				break;
			}
		}
	}
	for(a=1;a<=9999;a+=2)
	{
		for(b=1;b<=9999;b+=2)
		{
			_asm
			{
				mov edx,a
				mov ecx,b
				mov eax,0xd00b
	loopdude1:
				XOR EDX,ECX
				MOV EBX,ECX
				SHL EBX,2
				MOV ECX,EDX
				SHR ECX,2
				ADD EBX,ECX
				MOV ECX,EBX
				XOR ECX,EDX
				DEC EAX
				JNZ loopdude1
				MOV val,EBX
			}
			printf("%d %d\n",a,b);
			if(val==0x6F3AAD5A)
			{
				printf("Got it,the values are %d %d\nBye Byte",a,b);
				break;
			}
		}
	}
	for(a=0;a<=9999;a+=2)
	{
		for(b=1;b<=9999;b+=2)
		{
			_asm
			{
				mov edx,a
				mov ecx,b
				mov eax,0xd00b
	loopdude2:
				XOR EDX,ECX
				MOV EBX,ECX
				SHL EBX,2
				MOV ECX,EDX
				SHR ECX,2
				ADD EBX,ECX
				MOV ECX,EBX
				XOR ECX,EDX
				DEC EAX
				JNZ loopdude2
				MOV val,EBX
			}
			printf("%d %d\n",a,b);
			if(val==0x6F3AAD5A)
			{
				printf("Got it,the values are %d %d\nBye Byte",a,b);
				break;
			}
		}
	}
 	printf("Brute force completed! lol");
}
	
