This keyme based on the problem of the 10 coins, 
where over 3 weighing you must identify spurious coin, 
and know it lighter or heavier.

The main task of this keyme is to find the multipurpose key,
that be right for _any_ name. 
(it is not only one, but you may find one :)) 

Finding the key, suitable for one or some names is easy, 
but one for any name it is not the case.