CrackMe Name:	TrapMe
Author:		CoDe_InSiDe
When coded:	29-07-2002
Protection:	Packed, Encryption, Name/Serial


- Intro

Welcome to another CrackMe from me after quite some time heh...
I think this CrackMe isn't too hard, but i think it's not for the Newbie ;)
The CrackMe has been Packed with my own Packer which i *STILL* need to finish haha :P (I doubt
that i'll ever finish it...)
The program also contains some funny On-The-Fly Encryption.
No need to say more, just check it out :)
Oh and one thing, i've only tested this CrackMe on "Windows 98 SE" so i don't know if it runs on
other OS's but i actually don't really care...
I hope i didn't leave any bugs in it ;)


- Objectives

1. Get a valid Serial for your Name (Required)
2. You can make a Keygen if you want (Optional)
3. Write a Tutorial on how you did it, and what happens in the CrackMe (Required)
4. As an extra challenge, you can write some sortof Loader for the CrackMe, because of the Serial
   which can be in non-readable characters ;) Just check the program it'll become clear to you...
   (Optional)

And i think that's it, you could also create a Patcher or something like that, if you want ;)
Maybe also some Inline-Patching, hmm...


- Greets

Uhm...

		   "Everyone i know and everyone who knows me and YOU !!!"


			Don't trust the Outside, Trust the InSiDe !!!

					  Cya...

					CoDe_InSiDe


Homepage:	http://codeinside.anticrack.de
Unpacking page:	http://mup.anticrack.de
Email:		code.inside@home.nl
