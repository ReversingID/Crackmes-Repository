#define STRICT
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <condefs.h>
#include "resource.h"
#pragma hdrstop
//---------------------------------------------------------------------------
USERC("keygen.rc");
//---------------------------------------------------------------------------
BOOL CALLBACK DlgProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  switch (message)
  {
    case WM_INITDIALOG:
      SetDlgItemText(hWnd, EditID1, "*Sorcerer*");
      break;

    case WM_COMMAND:
{
  switch (LOWORD (wParam))
  {
    case ButtonID1:
      MessageBox(hWnd, "KeyGenerator for cyTOm!c`s CrackMe #1\nMade by: *Sorcerer*", "About", MB_OK);
      break;

    case ButtonID3:
      SendMessage(hWnd,WM_CLOSE,0,0);
      break;

    case ButtonID2:
    {

      char finalserial[255] = {0};
      int serial = 0;
      int serial2 = 0;
      int serial3 = 0;
      int j = 0;
      char Serial[255] = {0};
      char Serial2[255] = {0};
      char *Buffer = new char[255];

      GetDlgItemText(hWnd, EditID1, Buffer, 255);

      int Size = lstrlen(Buffer);

      if (Size >= 4)
                {

      for (int i = 0; i < Size; i++)
             {

      serial = (Buffer[i] * Size);
      serial2 += serial;
      serial = (serial ^ serial);

             }
      serial3 = serial2;

      serial2 = (serial2 ^ serial2);

      serial = (serial ^ serial);

      for (i = 0; i < Size; i++)
             {

      serial = (Buffer[i] ^ Size);
      serial2 += serial;
      serial = (serial ^ serial);

             }
      serial = (serial2 + serial3);

      serial2 = (serial2 ^ serial2);

      serial3 = (serial3 ^ serial3);

      while (j < Size)
             {
      i = 0;

      while (i < Size)
             {

      serial2 = (Buffer[i] * Buffer[j]);
      serial3 += serial2;
      serial2 = (serial2 ^ serial2);
      i++;
             }
      j++;
             }
      serial = (serial + serial3);

      serial3 = (serial3 ^ serial3);

      *Serial = 0;

      i = 0;

      __asm{

      push ebp
      xor ebx,ebx
      mov eax,serial
     start:
      rol eax,04
      mov bl,al
      ror ebx,04
      cmp ebx,09
      jle videre
     hit:
      sub ebx,04
      cmp ebx,09
      ja hit
     videre:
      add bl,0x30
      mov Serial,bl
      inc ebp
      xor al,al
      ror eax,08
      cmp eax,00
      jnz start
      pop ebp
      xor ebx,ebx

      }
      *finalserial = *Buffer;

      *(finalserial+1) = *(Buffer+1);
      *(finalserial+2) = *(Buffer+2);
      *(finalserial+3) = *(Buffer+3);

      *(finalserial+4) = *"-";

      lstrcat(finalserial, Serial);

      lstrcat(finalserial, "-");

      int Size2 = lstrlen(Serial);

      for (i = 0; i < Size2; i++)
             {

      serial = (Serial[i] * 0x2d);
      serial2 += serial;
      serial = (serial ^ serial);

             }

      __asm{

      push ebp
      xor ebx,ebx
      mov eax,serial2
     label1:
      rol eax,04
      mov bl,al
      ror ebx,04
      cmp ebx,09
      jle label3
     label2:
      sub ebx,04
      cmp ebx,09
      ja label2
     label3:
      add bl,0x30
      mov Serial2+3,bl
      dec ebp
      xor al,al
      ror eax,08
      cmp eax,00
      jnz label1
      pop ebp
      xor ebx,ebx

      }

      lstrcat(finalserial, Serial2);

      lstrcat(finalserial, "-");

      lstrcat(finalserial, "X");

      SetDlgItemText(hWnd, EditID3, finalserial);

      SetDlgItemText(hWnd, EditID2, Serial);
                }
      else
      SetDlgItemText(hWnd, EditID2, "Enter at least 4 chars");

    }
      break;
  }
}
      break;

    case WM_CLOSE:
      EndDialog(hWnd,0);
      break;
}
return 0;
}



int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nCmdShow)
{
  DialogBox(hInstance,MAKEINTRESOURCE(DialogID1),NULL,(DLGPROC)DlgProc);
  return 0;
}
