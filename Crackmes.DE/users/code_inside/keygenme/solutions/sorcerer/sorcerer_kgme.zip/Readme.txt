It was a good KeyGenMe for a newbie like me.
Keygen with source is in the zip file.

Made by: *Sorcerer*