#include <windows.h>
#include <stdio.h>
#include <conio.h>

#ifdef __cplusplus
extern "C" {
	int generate();
	extern char szname[], szorg[], szvalidsn[];
}

#endif
int main(int argc, char *argv[])
{
	printf("code_inside's 5th CrackMe -- keygen by NoRG.\n");
	printf("==========\n\n\n");

_badname:
	printf("Enter your Name         : ");
	gets(szname);
	if (0 == strlen(szname))
		goto _badname;

_badorg:
	printf("Enter your Organization : ");
	gets(szorg);
	if (0 == strlen(szorg))
		goto _badorg;

	generate();

	printf("Your serial             : %s", szvalidsn);

	printf("\n\nPress enter...");

	getch();

	return TRUE;
	}
