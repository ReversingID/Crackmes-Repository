/*************************************************************************

 Filename:		Keygen.c
 Purpose:		Keygen for Code_Inside TryThisOne
 Author:		figugegl
 Version:		1.0
 Date:			5.11.2001

*************************************************************************/


/*------------------------------------------------------------------------
	Include files
------------------------------------------------------------------------*/
#include <windows.h>
#include <stdio.h>
#include "keygenres.h"


/*------------------------------------------------------------------------
	Prototypes
------------------------------------------------------------------------*/
LRESULT CALLBACK MainDlgProc	(HWND, UINT, WPARAM, LPARAM) ;


/*------------------------------------------------------------------------
	Global variables
------------------------------------------------------------------------*/


/*------------------------------------------------------------------------
 Procedure:     WinMain
 Purpose:       Application entry point. Registers a class of the same
                type than the dialog class,calls DialogBox and then exits
 Input:         Standard
 Output:        None
 Errors:        None
------------------------------------------------------------------------*/
int WINAPI WinMain (HINSTANCE hInst, HINSTANCE hPrevInst, PSTR szCmdLine, int CmdShow)
{
	static TCHAR	szAppName[] = TEXT ("keygen") ;
	WNDCLASS		wc ;

	memset (&wc, 0, sizeof (wc));				// empty structure wc

	wc.lpfnWndProc		= MainDlgProc ;			// callback procedure
	wc.cbWndExtra		= DLGWINDOWEXTRA ;
	wc.hInstance		= hInst ;
	wc.hIcon			= LoadIcon (hInst, MAKEINTRESOURCE (ICO_FIGU)) ;
	wc.hCursor			= LoadCursor (NULL, IDC_ARROW) ;
	wc.hbrBackground	= (HBRUSH) (COLOR_BTNFACE + 1) ;
	wc.lpszClassName	= szAppName ;

	if (!RegisterClass (&wc))
		return 0;

	return DialogBoxParamA (hInst, MAKEINTRESOURCE (DLG_MAIN), NULL, (DLGPROC) MainDlgProc, 0);
}


/*------------------------------------------------------------------------
 Procedure:     CalculateSerial
 Purpose:       Calculate a valid serial
 Input:         hWnd:	Handle of the Dialogbox
 Output:        None
 Errors:        None
------------------------------------------------------------------------*/
void CalculateSerial (HWND hWnd)
{
	unsigned char	szSerial[32] = "";
	unsigned char	szHelp1[16]  = "";
	unsigned char	szHelp2[8]   = "";
	unsigned long	ulConstA     = 0xCDABBADC;
	unsigned long	ulHelp1;
	int				i, j, k;


	// calculate 2nd part of serial
	for (i = 0x20; i < 0xFF; i++)
	{
		if (((ulConstA % i) | 0x41) == i)
		{
			szHelp2[0] = i;
			for (k = 0, j = 0; j < 2; j++)
			{
				ulHelp1 = ulConstA;
				do
				{
					szHelp1[k] = (ulHelp1 % szHelp2[j]) | 0x41;
					ulHelp1 /= szHelp2[j];
					k++;
				}
				while (ulHelp1 > 0);
				szHelp2[1] = szHelp1[2];
			}
			szHelp2[2] = szHelp1[4];
			szHelp2[3] = szHelp1[6];
			szHelp2[4] = szHelp1[8];
			szHelp2[5] = '-';
			szHelp2[6] = 0;
			lstrcat (szSerial, szHelp2);
		}
	}

	SetDlgItemTextA (hWnd, EDF_SERIAL, szSerial);
}


/*------------------------------------------------------------------------
 Procedure:     AboutDlgProc
 Purpose:       Handles the messages of the about dialog
 Input:         Standard
 Output:        TRUE if the message was processed
 Errors:        None
------------------------------------------------------------------------*/
LRESULT CALLBACK AboutDlgProc (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
     switch (uMsg)
     {
     case WM_INITDIALOG:
          return 0;

     case WM_COMMAND:
          if (LOWORD (wParam) == BUT_OK)
          {
               EndDialog (hWnd, 0) ;
               return 0;
          }
          break ;
     }
     return FALSE ;
}


/*------------------------------------------------------------------------
 Procedure:     MainDialogProc
 Purpose:       It handles all messages of the main dialog
 Input:         Standard
 Output:        TRUE if the message was processed
 Errors:        None
------------------------------------------------------------------------*/
LRESULT CALLBACK MainDlgProc (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_INITDIALOG:
		return 0 ;

	case WM_COMMAND:
		switch (LOWORD (wParam))
		{
		case BUT_CHECK:			// Check
			EnableWindow (GetDlgItem (hWnd, BUT_CHECK), FALSE);
			CalculateSerial (hWnd);
			EnableWindow (GetDlgItem (hWnd, BUT_CHECK), TRUE);
	 		return 0;

		case BUT_ABOUT:			// About
			DialogBox (NULL, MAKEINTRESOURCE (DLG_ABOUT), hWnd, (DLGPROC) AboutDlgProc);
			return 0;
		}
		break;

	case WM_CLOSE:
		PostQuitMessage (0) ;
		return 0 ;
	}
	return DefWindowProc (hWnd, uMsg, wParam, lParam) ;
}

