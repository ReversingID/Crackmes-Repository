/*************************************************************************

 Filename:		part1.c
 Purpose:		Keygen for Code_Inside TryThisOne
 Author:		figugegl
 Version:		1.0
 Date:			5.11.2001

*************************************************************************/


/*------------------------------------------------------------------------
	Include files
------------------------------------------------------------------------*/
#include <windows.h>
#include <stdio.h>
#include "keygenres.h"


/*------------------------------------------------------------------------
	Prototypes
------------------------------------------------------------------------*/
LRESULT CALLBACK MainDlgProc	(HWND, UINT, WPARAM, LPARAM) ;


/*------------------------------------------------------------------------
	Global variables
------------------------------------------------------------------------*/


/*------------------------------------------------------------------------
 Procedure:     WinMain
 Purpose:       Application entry point. Registers a class of the same
                type than the dialog class,calls DialogBox and then exits
 Input:         Standard
 Output:        None
 Errors:        None
------------------------------------------------------------------------*/
int WINAPI WinMain (HINSTANCE hInst, HINSTANCE hPrevInst, PSTR szCmdLine, int CmdShow)
{
	static TCHAR	szAppName[] = TEXT ("keygen") ;
	WNDCLASS		wc ;

	memset (&wc, 0, sizeof (wc));				// empty structure wc

	wc.lpfnWndProc		= MainDlgProc ;			// callback procedure
	wc.cbWndExtra		= DLGWINDOWEXTRA ;
	wc.hInstance		= hInst ;
	wc.hIcon			= LoadIcon (hInst, MAKEINTRESOURCE (ICO_FIGU)) ;
	wc.hCursor			= LoadCursor (NULL, IDC_ARROW) ;
	wc.hbrBackground	= (HBRUSH) (COLOR_BTNFACE + 1) ;
	wc.lpszClassName	= szAppName ;

	if (!RegisterClass (&wc))
		return 0;

	return DialogBoxParamA (hInst, MAKEINTRESOURCE (DLG_MAIN), NULL, (DLGPROC) MainDlgProc, 0);
}


/*------------------------------------------------------------------------
 Procedure:     ModifyTable
 Purpose:       Modifies a table entry
 Input:         cSChar:         s[i]
                iTabElement:    number of element in table
 Output:        unsigned long:  modified table element
 Errors:        None
------------------------------------------------------------------------*/
unsigned long ModifyTable (char cSChar, int iTabElement)
{
	unsigned long ulVarA, ulVarB, ulVarC = 0;
	unsigned long ulConst    = 0x436F4465;
	unsigned long ulTable[6] = { 0x69CDF48C, 0x9D346C58, 0x38682AB8,
					             0x6BCEA284, 0x9F351A50, 0xD29B921C };
	int           i;

	ulVarA = cSChar * ulConst;
	ulVarB = ulTable[iTabElement] ^ ulVarA;

	// bswap :-)
	for (i = 0; i < 4; i++)
	{
		ulVarC <<= 8;
		ulVarC += (ulVarA & 0xFF);
		ulVarA >>= 8;
	}
	return (ulVarB + ulVarC);
}


/*------------------------------------------------------------------------
 Procedure:     CalculateVarE
 Purpose:       Modifies a table entry
 Input:         cSChar:         s[i]
 Output:        unsigned long:  calculated value
 Errors:        None
------------------------------------------------------------------------*/
unsigned long CalculateVarE (char cSChar)
{
	unsigned long ulVarA, ulVarB;
	int           i;

	ulVarA = cSChar;
	for (i = 0x20; i < 0x7F; i++)
	{
		ulVarB = i;
		ulVarB *= ulVarB;
		ulVarB += ulVarA;
		ulVarB *= ulVarB;
		ulVarA += ulVarB;
	}

	return (ulVarA);
}


/*------------------------------------------------------------------------
 Procedure:     CalculateSerial
 Purpose:       Calculate a valid serial
 Input:         hWnd:	Handle of the Dialogbox
 Output:        None
 Errors:        None
------------------------------------------------------------------------*/
void CalculateSerial (HWND hWnd)
{
	unsigned char	szSerial[32] = "";
	unsigned long	ulVarA, ulVarB;
	unsigned char	i, j;

	for (i = 0x20; i < 0xFF; i++)
	{
		ulVarA = ModifyTable (i, 1);
		for (j = 0x20; j < 0xFF; j++)
		{
			if (ulVarA == CalculateVarE (j))
			{
				wsprintfA (szSerial, "%d -- %X", i, ulVarA);
				SetDlgItemTextA (hWnd, EDF_SERIAL, szSerial);
				return;
			}
		}
	}

	return;
}


/*------------------------------------------------------------------------
 Procedure:     AboutDlgProc
 Purpose:       Handles the messages of the about dialog
 Input:         Standard
 Output:        TRUE if the message was processed
 Errors:        None
------------------------------------------------------------------------*/
LRESULT CALLBACK AboutDlgProc (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
     switch (uMsg)
     {
     case WM_INITDIALOG:
          return 0;

     case WM_COMMAND:
          if (LOWORD (wParam) == BUT_OK)
          {
               EndDialog (hWnd, 0) ;
               return 0;
          }
          break ;
     }
     return FALSE ;
}


/*------------------------------------------------------------------------
 Procedure:     MainDialogProc
 Purpose:       It handles all messages of the main dialog
 Input:         Standard
 Output:        TRUE if the message was processed
 Errors:        None
------------------------------------------------------------------------*/
LRESULT CALLBACK MainDlgProc (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_INITDIALOG:
		return 0 ;

	case WM_COMMAND:
		switch (LOWORD (wParam))
		{
		case BUT_CHECK:			// Check
			EnableWindow (GetDlgItem (hWnd, BUT_CHECK), FALSE);
			CalculateSerial (hWnd);
			EnableWindow (GetDlgItem (hWnd, BUT_CHECK), TRUE);
	 		return 0;

		case BUT_ABOUT:			// About
			DialogBox (NULL, MAKEINTRESOURCE (DLG_ABOUT), hWnd, (DLGPROC) AboutDlgProc);
			return 0;
		}
		break;

	case WM_CLOSE:
		PostQuitMessage (0) ;
		return 0 ;
	}
	return DefWindowProc (hWnd, uMsg, wParam, lParam) ;
}

