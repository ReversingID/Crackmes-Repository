/* Weditres generated include file. Do NOT edit */
#define	DLG_MAIN	100
#define	EDF_SERIAL	102
#define	BUT_ABOUT	103
#define	BUT_CHECK	105
#define	DLG_ABOUT	200
#define	BUT_OK	201
#define	ICO_FIGU	300
