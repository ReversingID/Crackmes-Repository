This is just a crackme I made a couple years before, it's called "Sticky Crackme", and though it has some time now, it's still a funny challenge. The idea behind ??this crackme is to have a fun time and to also check on an unconventional method of "registering" an app, sort of speak, you'll see what I mean. I think it can be interesting to deal around with this application and decipher its functioning. This crackme is not designed for noobs, it's intended for advanced newbies at least, if you have some average knowledge you shouldn't have any issue, it's a relative easy challenge though.
"...watch the code very close and you'll see some growing light..."

Rules: 
1- Not worth patching the executable as a final solution. 
2- Make a "keygen" in the language you want. The keygen should be considered as a GOLD solution if the same methods used by the crackme are used when registering it. That is, the keygen must register the application without the user having to do anything but to press a simple button ;) 
3- Make a tutorial on how you have overcome the crackme and the construction of the keygen.

That's pretty much it, hope you like it...
happy cracking to all!!
ThunderCls