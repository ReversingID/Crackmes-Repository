This is a very easy crackme I made for REtosCLS initiative, it is coded in C#, all you gotta do is to find a valid registration code, no patching as a valid solution (it wouldn't be funny at all), feel free to use the tools you like.
"...you are gonna have a quick review on your algebra skills for the final test ;)"

You are gonna need .Net Framework v3.5 installed to run this
Good luck! and Happy Cracking to All!!
ThunderCls