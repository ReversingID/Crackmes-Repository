==========================
b6b X-rem's CrackMe

     It's my 1st CrackMe )
==========================
(Sorry for my bad english)

Simple crackme (Difficult : Need some brains [2])
U should find valid Serial and RefID


When all done, send confirmation (as comment) on crackmes.de >>>
Registred to : User SeRiAl RefID
Example : [ Registred to : X-rem ASdgsdf123456 00000]


Rules :
NO Patching



==========================
ICQ: 365531140