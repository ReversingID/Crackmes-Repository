#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

int i=0, total=0, lName=0, midValue=0, lastChar=0;
char szName[100], *szTitle="versus's keygenme solution by draww @ crackmes.de";
//char *szSerialFmt="%d-%c-ALG";

int main(int argc, char *argv[])
{
    SetConsoleTitle(szTitle);
    system("COLOR 0E");
    printf("\n ! %s !\n\n",szTitle);
    printf("  � press ESC to exit after generating your serial �\n");
    printf("   � or press CTRL+BREAK to terminate this screen �\n\n\n");
    
keygen:
	printf(" � Enter your name: ");
	gets(szName);
    lName=lstrlen(szName);

	for(i=0;i<lName;i++)
	{
		total+=szName[i];
		total^=i+1;
	}
    
    lastChar=szName[lName-1];
    midValue=lastChar+0x30;
    
    while(midValue%10!=6) midValue++;                       

    printf(" � Your serial# is: %d-%c-ALG\n\n",total*10,midValue-lastChar);
    
    while(getch()!=VK_ESCAPE)
	{
	    total=0;
	    goto keygen;
	}
    
	return EXIT_SUCCESS;
}


