Hello , this is my first crackme.
The only rule is don't mess with the thread creation , since it's just like patching a single jump in a keygenme.

The goal is to make it accept your password.

I hope you will enjoy it 
--Boon