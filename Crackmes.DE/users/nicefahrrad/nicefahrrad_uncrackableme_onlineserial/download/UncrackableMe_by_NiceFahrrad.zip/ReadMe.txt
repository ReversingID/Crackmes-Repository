
This CrackMe checks online for the Serial,
Can you crack this anyway?

This is my first CrackMe i have made,
its written in .NET (nothing special),
You need to get the Message that you have the right serial entered!
I hope you enjoy it and dont fucked up by the anti debug mechanisms ;).
I would love to see a tutorial video answer.


how ever, good luck!


================================================================================
| By NiceFahrrad | nicefahrrad@hotmail.com <- you can get the source if wanted |
================================================================================


Pressing on 'Check Serial' Button sends the Key to the Server for the check.
You get an Answer if the Serial is OK or not.

If you have any problems:
1. Try to forward TCP Port 8000, if you still have problems
2. Try to deactivate Firewall

INFO: 
You will need .NET Framework 4.5.2

VirusScan Link:
https://www.virustotal.com/en/file/4c1d83c8f98cd3b6ffda3798e26f280d64240f7a88c2b3c969d85ece66ffc172/analysis/1446155217/