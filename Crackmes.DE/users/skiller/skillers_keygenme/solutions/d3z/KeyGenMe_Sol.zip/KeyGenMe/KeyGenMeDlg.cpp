// KeyGenMeDlg.cpp : implementation file
//

#include "stdafx.h"
#include "KeyGenMe.h"
#include "KeyGenMeDlg.h"
#include ".\keygenmedlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CKeyGenMeDlg dialog



CKeyGenMeDlg::CKeyGenMeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CKeyGenMeDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CKeyGenMeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CKeyGenMeDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
  ON_BN_CLICKED(IDOK, OnBnClickedOk)
END_MESSAGE_MAP()


// CKeyGenMeDlg message handlers

BOOL CKeyGenMeDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CKeyGenMeDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CKeyGenMeDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

BYTE CKeyGenMeDlg::Encode(BYTE val)
{
  BYTE c = val;
  _asm
  {
    add c,0xA
    xor c,0xC
    rol c,3
  }
  return c;
}

void CKeyGenMeDlg::OnBnClickedOk()
{
  CString code;
  GetDlgItemText( IDC_EDCODE, code );

  BYTE* serial = new BYTE[code.GetLength()];

  for (int i=0;i<code.GetLength();i++)
  {
    BYTE c = code.GetAt(i);
    c = Encode(c);
    c = Encode(c);

    serial[i] = c;
  }

  FILE* f = fopen("file.key","wb");
  if (f)
  {
    fwrite(serial,code.GetLength(),1,f);
    fclose(f);
    ::MessageBox(NULL,"file.key Written!","Done.",MB_OK);
  }
  else
  {
    ::MessageBox(NULL,"Cannot open file.key!","Error!",MB_OK);
  }

  delete [] serial;
}
