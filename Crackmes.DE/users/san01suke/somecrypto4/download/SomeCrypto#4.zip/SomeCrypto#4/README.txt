Just find correct password.

Post comment with good boy message as evidence of solving this.

Some crypto knowledge never hurt anyone.

P.S. Stupid bruteforce is not good solution.