#include <iostream.h>
#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <windows.h>

char name[50];
char part1, part2;
int lung=0;

void main()
{
   cout<<"Creakme_001 by DiS[IP] - Keygen by Ox87k";
	cout<<"\n\nName: ";
	gets(name);
   lung=strlen(name);

   if(lung<3)
   {
    	cout<<"\n\nPLEASE INSERT LESS THAN 3 CHARS IN NAME!";
      cout<<"\n\nPress any key to exit...";
      getch();
      exit(0);
   }

   cout<<"Serial: ";
   for(int i=0;i<lung;i++)
   {
   	if(name[i]==0x5A || name[i]==0x7A || name[i]==0x39)
      	name[i]--;

      part2=0x61+i;
      part1=name[i]+0x01;
      cout<<part1<<part2;
   }
	cout<<"\n\nPress any key to exit...";
   getch();
}
