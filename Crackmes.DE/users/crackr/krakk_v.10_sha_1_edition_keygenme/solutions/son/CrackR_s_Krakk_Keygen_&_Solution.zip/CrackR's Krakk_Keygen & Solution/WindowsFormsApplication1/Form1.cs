﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        
        private static string Hash(string input)
        {
            using (SHA1Managed managed = new SHA1Managed())
            {
                byte[] buffer1 = managed.ComputeHash(Encoding.UTF8.GetBytes(input));
                StringBuilder builder = new StringBuilder(buffer1.Length * 2);
                foreach (byte num2 in buffer1)
                {
                    builder.Append(num2.ToString("X2"));
                }
                return builder.ToString();
            }
        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {
            if (txtUsername.Text != "")
            {
                txtKey.Text = Hash(txtUsername.Text);
            }
            else
            {
                txtKey.Text = "";
            }

        }

   }
}