#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>

#define TIMELOOP 10000000
#define	LOOPX 0x40000				// how many iterations before we update status
#define DELTA 0x9E3779B9			// "magic delta value"
#define DATA0 0x9184EA05			// ...
#define DATA1 0x26440640			// ... datablock to decrypt

typedef unsigned int u32;

u32		data_0 = DATA0,
		data_1 = DATA1;
u32		TEAkey = 0;


__inline void tea_decrypt(void)
{
	register u32	sum = (DELTA << 5);
	register u32	y, z;
	register u32	i;

	y = data_0;
	z = data_1;
	for(i=32; i>0; i--)
	{
		z -= ((y >> 5) + TEAkey) ^ ((y << 4) + TEAkey) ^ (sum + y);
		y -= ((z >> 5) + TEAkey) ^ ((z << 4) + TEAkey) ^ (sum + z);
		sum -= DELTA;
	}
	data_0 = y;
	data_1 = z;
}


int main(void)
{
	u32		loop = 0, timeloop = 0;
	u32		lo = 0, hi = 0xFFFFFFFF;
	u32		time;

	printf("Applying brute force...\n");
	time = GetTickCount();
//	while((lo<hi) && (timeloop++ < TIMELOOP)) {		// use this to test speed
	while(lo<hi) {
		TEAkey = lo;
		tea_decrypt();
		if((data_0 == 0) && (data_1 == 0)) {
			printf("\nHeureka! Found that TEAkey = %08X\n", TEAkey);
			break;
		}

		TEAkey = hi;
		tea_decrypt();
		if((data_0 == 0) && (data_1 == 0)) {
			printf("\nHeureka! Found that TEAkey = %08X\n", TEAkey);
			break;
		}

		if((loop-- & 0xFFFFF) == 0) {
			printf("\rlo: %08X, hi: %08X", lo, hi);
		}
		lo++;
		hi--;
		data_0 = DATA0;
		data_1 = DATA1;
	}
	time = GetTickCount() - time;
	printf("\n%dms (%d.%dsec) elapsed.\n", time, time / 1000, time % 1000);

	printf("press enter to continue\n");
	getchar();
	return 0;
}

/*
lo: 5EF0521B, hi: A10FADE4
Heureka! Found that TEAkey = 5EF3184A
2249 seconds elapsed.
press enter to continue

(37.48 minutes and 29 seconds).

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
LCC-Win32 version:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
14619ms (14.619sec) elapsed
14573ms (14.573sec) elapsed
14633ms (14.633sec) elapsed
---------------------------
43825ms (43.825sec) total
14609ms (14.609sec) average

10000000 iterations, two tests per iteration = 20000000 tests.
About 1369019,1 tests per second.



~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
VC6++ version:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

14315ms (14.315sec) elapsed
14330ms (14.330sec) elapsed
14315ms (14.315sec) elapsed
---------------------------
42960ms (42.960sec) total
14320ms (14.320sec) average

About 1396648,0 test per second.
*/
