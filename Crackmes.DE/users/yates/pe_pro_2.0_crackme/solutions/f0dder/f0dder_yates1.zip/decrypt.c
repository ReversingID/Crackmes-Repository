/*
Note: this decryptor is tuned to the version of _crackme.exe *I* have. This should
very well be identical to the version you have, but if not... *shrug*. This is a
quick hack, so I didn't bother to make it fetch values out of the PE header, etc...
So be careful :)
*/
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>

#define DELTA			0x9E3779B9			// "magic delta value"
#define NUMBLOCKS		0xD780				// amount of blocks to decrypt
#define CODESTART		0x401000			// where decryption starts
#define MAGIC_OFFSET	0x600				// because I'm too lazy to look it up runtime

typedef unsigned char u8;
typedef unsigned int u32;

u32		data_0, data_1;
u32		TEAkey = 0x5EF3184A;



void tea_decrypt(void)
{
	u32	sum = (DELTA << 5);
	u32	y, z;
	u32	i;

	y = data_0;
	z = data_1;
	for(i=32; i>0; i--)
	{
		z -= ((y >> 5) + TEAkey) ^ ((y << 4) + TEAkey) ^ (sum + y);
		y -= ((z >> 5) + TEAkey) ^ ((z << 4) + TEAkey) ^ (sum + z);
		sum -= DELTA;
	}
	data_0 = y;
	data_1 = z;
}

int main(void)
{
	HANDLE	hfil, hmap;
	u8		*ptr;
	u32		*ptr32;
	u32		cnt;


	hfil = CreateFile("_crackme.exe", GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_SEQUENTIAL_SCAN, NULL);
	if(hfil == INVALID_HANDLE_VALUE) return 1;

	hmap = CreateFileMapping(hfil, NULL, PAGE_READWRITE, 0, 0, NULL);
	if(hmap == NULL) return 1;

	ptr = MapViewOfFile(hmap, FILE_MAP_WRITE, 0, 0, 0);
	if(ptr == NULL) return 1;

	printf("file mapped ok, decrypting...");
	// time to decrypt
	ptr32 = (u32 *) &ptr[MAGIC_OFFSET];
	for(cnt=NUMBLOCKS; cnt>0; cnt--)
	{
		data_0 = ptr32[0];
		data_1 = ptr32[1];
		tea_decrypt();
		ptr32[0] = data_0;
		ptr32[1] = data_1;
		ptr32 += 2;
	}
	printf("done!\n");

	UnmapViewOfFile(ptr);
	CloseHandle(hmap);
	CloseHandle(hfil);

	return 0;
}
