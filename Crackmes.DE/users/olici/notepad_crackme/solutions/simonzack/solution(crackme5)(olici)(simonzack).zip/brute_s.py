
import hashlib
import itertools

def brute_s(stream):
	'''
	args:
		stream should be opened in binary mode
	'''
	#RQS???U??????
	remChars='TVYacef'
	n='RR US RQ QQ RQ Rf RQ RS RR eT RR cS RR eU RQ QS RQ RQ RQ Qc RQ Rc RQ Qa RQ RQ RR SY RR VQ'.split(' ')
	#combine 2 possible chars with all remChars
	for r in itertools.permutations(remChars,len(remChars)):
		r=''.join(r)
		for i0 in range(8):
			for i1 in range(i0,8):
				r2=r[:i0]+'?'+r[i0:i1]+'?'+r[i1:]
				allChars='RQS'+r2[0]+r2[1]+r2[2]+'U'+r2[3]+r2[4]+r2[5]+r2[6]+r2[7]+r2[8]
				res=bytearray()
				for i in range(0,len(n),2):
					c0=allChars.index(n[i][0])*13+allChars.index(n[i][1])
					c1=allChars.index(n[i+1][0])*13+allChars.index(n[i+1][1])
					if c0>=100 or c1>=100:
						break
					c=c0*100+c1
					if c>0xFF:
						break
					#filter
					#if c<0x20:
					#	break
					res.append(c)
				else:
					#print(bytes(res))
					stream.write(res)
					stream.write(b'\r\n')

def removeDupChars(s):
	currChars=[]
	res=bytearray()
	for c in s:
		if c in currChars:
			continue
		else:
			currChars.append(c)
			res.append(c)
	return res

def padStr(s):
	c=len(s)+s[0]
	for i in range(len(s),10):
		c+=s[0]
		s.append(c)
	return s

def decKey(key):
	key=bytearray(hashlib.md5(key).hexdigest().upper().encode())
	#add 0x20
	for i in range(len(key)):
		key[i]+=0x20
	key=removeDupChars(key)
	key=padStr(key)
	#generate double chars
	doubleChars=[]
	for i in range(100):
		doubleChars.append(chr(key[i//len(key)])+chr(key[i%len(key)]))
	#get final key
	n='RR US RQ QQ RQ Rf RQ RS RR eT RR cS RR eU RQ QS RQ RQ RQ Qc RQ Rc RQ Qa RQ RQ RR SY RR VQ'.split(' ')
	res=[]
	for _n in n:
		try:
			res.append(doubleChars.index(_n))
		except ValueError:
			pass
	ret=bytearray()
	for i in range(0,len(res),2):
		try:
			ret.append((res[i]*100+res[i+1])&0xFF)
		except IndexError:
			ret.append(res[i])
	return ret

def searchKeyMatch(stream):
	'''
	args:
		stream should not be opened in binary mode
	'''
	while True:
		n=stream.readline()
		if len(n)==0:
			break
		n=n[:-1].encode()
		if decKey(n)==n:
			print('found: '+repr(n))
	
class test:
	def decKey():
		print(decKey(b'QnEo3zx74mIIc67PPvVF'))
		print(decKey(b'N!CC6=fO-_lasu:sng5q'))


def main():
	#stream=open('test.txt','wb')
	#brute_s(stream)
	#stream.close()
	stream=open('test.txt','r')
	searchKeyMatch(stream)
	stream.close()

if __name__=='__main__':
	main()
