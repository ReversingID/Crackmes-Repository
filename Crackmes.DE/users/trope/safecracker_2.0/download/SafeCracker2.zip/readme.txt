Ok here are the rules:

1. No patching to get to the good guy message. You may need to change a couple bytes here and there, but no patching to crack the safe.

2. Show me a psuedo-code keygen of how you cracked the safe. When you do crack it , you will see what I mean!

That's it! Have fun with this one...

~ Trope