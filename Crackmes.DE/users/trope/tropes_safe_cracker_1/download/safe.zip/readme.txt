1. No patching, too easy.

2. Just find out the combo to the "safe".

