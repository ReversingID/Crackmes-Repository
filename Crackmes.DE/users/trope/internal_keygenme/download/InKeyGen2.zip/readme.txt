Rules:


1. Turn this into an internal KeyGen

2. Use a MessageBox to display the correct serial

3. No adding new Sections. There's plenty of room.

4. Remove Number of Char Restrictions on name. You will see what I mean when you look at the disassembly.


That's all! Should be good practice for newbies.

Trope