#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv)
{
    char serial[0x80]; // The driver crackme only compute the 20 first bytes, but you can put a name to 0x78 bytes
    
    printf("\nARCHANGEL's Against Driver Keygen by _HellDashX_, %s\n", __DATE__);
    printf("---------------------------------\n");
    if(argc==1)
    {
               printf("Usage: Put a NAME with at least 20 chars\n");
               return 0;
    }
    
    memset(serial,0,0x80); // Put the stack buffer to 0 first for avoid garbage
    
    int bytes = strlen(argv[1]);
    if(bytes < 20)
    {
             printf("ERROR: The NAME needs 20 chars at least!!\n");
             return 0;
    }
    else if(bytes > 0x80)
    {
         printf("ERROR: The driver crackme only check 0x78 bytes, your name is bigger\n");
         return 0;
    }
    
    int i;
    for(i = 0;i < bytes;i++)
          serial[i] = *(argv[1] + i) ^ 3; // Make the serial, look the solution for more info
    
    printf("SERIAL: %s\n",serial);
          
    return 0;
}
               
    
