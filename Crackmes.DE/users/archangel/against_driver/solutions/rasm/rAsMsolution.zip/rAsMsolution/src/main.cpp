#include <Windows.h>

#define DIALOG1  1000
#define EDIT1    1001
#define EDIT2    1002

LRESULT CALLBACK MainProc(HWND Dlg,UINT message,WPARAM wParam,LPARAM lParam);


int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
   HWND hDlg;
   hDlg=CreateDialog(hInstance,(LPCTSTR)DIALOG1,NULL,(DLGPROC)MainProc);
   ShowWindow(hDlg,SW_SHOW);   
   
   MSG msg;
   while(GetMessage(&msg,NULL,0,0)==TRUE)
   {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
   }
   return 0;
}

LRESULT CALLBACK MainProc(HWND Dlg,UINT message,WPARAM wParam,LPARAM lParam)
{
   int Select;
   int i;
   int lenght;
   char Name[21];

   switch(message)
   {
   case WM_INITDIALOG:
	   SetWindowText(Dlg,"Against_Driver keygen by rAsM");
	   return FALSE;
   case WM_COMMAND:
       Select=LOWORD(wParam);
       switch(Select)
       {
	   case EDIT1:
		   if(HIWORD(wParam) == EN_CHANGE)
		   {
		   lenght = GetDlgItemTextA(Dlg,EDIT1,Name,21);
		   for (i=0; i<lenght; i++)
		   {
			   Name[i]= Name[i]^3;
		   }
		   for(i=lenght; i<20; i++)
		   {
			   Name[i]=0xBF;
		   }
		   Name[20]=0x00;
		   SetDlgItemText(Dlg,EDIT2,Name);
		   }
		   return FALSE;
       case IDCANCEL:
          EndDialog(Dlg,Select);
          PostQuitMessage(0);
          return TRUE;
       }
    default:
       return FALSE;
   }
}