*****************************************
Against Driver - CreackMe #1 by ARCHANGEL
*****************************************
Break the driver protection and find the
valid id-name & code, then write the
solution
*****************************************
Level 3 - Getting harder
*****************************************
If you have some critical crashes of the
crackme and it doesn't want to lunch
the driver after this, you need to delete
registry keys that makes the registration
of the driver. You can find them in:
HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services
and you need to delete only the information
about protection driver :-)
*****************************************
Good luck!
*****************************************
Greetings to: 111, Ara, RSI, Maximus,
Pe_Kill and to all www.cracklab.ru
*****************************************
I'll be back!
*****************************************