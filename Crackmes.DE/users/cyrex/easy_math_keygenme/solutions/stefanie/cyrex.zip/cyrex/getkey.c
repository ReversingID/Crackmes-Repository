#include <stdio.h>
#include <string.h>

int main()
{
	char username[50];
	char encrypted[50];
	char serial[50];
	char tmp;
	int x;

	printf("Username : ");
	fgets(username, 0xc8, stdin);

	for (x=0; x<strlen(username); x++) {
		tmp = username[x];
		tmp *= tmp;
		tmp ^= username[x];
		tmp ^= 0xc0;
		encrypted[x] = tmp;
	}

	for (x=0; x<strlen(encrypted); x++) {
		tmp = encrypted[2];
		tmp *=username[3];
		tmp ^= encrypted[x];
		tmp ^= 0xc0;
		encrypted[x] = tmp;
	}

	sprintf(serial,"%p-%x-%x-%p", encrypted[1], encrypted[2], \
			encrypted[2], encrypted[4]);

	printf("Serial   : %s\n", serial);

	return 0;
}
