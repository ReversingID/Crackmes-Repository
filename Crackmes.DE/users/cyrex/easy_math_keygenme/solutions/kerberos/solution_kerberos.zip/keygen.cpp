#include <iomanip>
#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>

using namespace std;

int main()
{
  string name;
  char *array;

  cout <<"Enter name : ";
  cin >> name;
  array = new char[name.length()];

  for (int i = 0; i<name.length(); i++){
    int l = (name[i]*name[i]) & 0xFF;
    l ^= name[i];
    l ^= 0xC0;
    array[i] = l;
  }

  for (int i =0;i < name.length();i++){
    int al = (array[2]*name[3]) & 0xFF;
    al ^= array[i];
    al ^= 0xC0;
    array[i]=al;
  }

  cout<<"Serial code : ";
  cout <<hex<<"0x"<<(int)array[1]<<"-"<<(int)array[2]<<"-"<<(int)array[2]<<"-0x"<<(int)array[4]<<endl;

  return 0;
}
