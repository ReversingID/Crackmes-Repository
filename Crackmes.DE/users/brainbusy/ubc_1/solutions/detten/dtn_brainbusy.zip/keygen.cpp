#include <iostream.h>
#include <conio.h>

int main () {

char name[20];
int i=0;
int serial=0;

cout<<"Name :";
cin>>name;

while (name[i]!='\0')
	{
     	serial+=(name[i]*8);
      i++;
   }
serial+=(i*8);
serial*=4;


cout<<endl<<"Serial = "<<serial;
getch();
}
