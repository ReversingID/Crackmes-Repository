/**
 * Keygen for br0ken's CrackMe #4
 * Author: mjones
 * Date: July 25, 2008
 *
 * Keygen creates a password for the app, then 
 * outputs the serial to the screen as well as
 * writing it to the file br0ken-key.txt
 *
 * Compiled with MinGW on Windows XP
 * > g++ -Wno-deprecated -o mwj-solution.exe mwj-solution.cpp
 */

#include <windows.h>
#include <fstream.h>
#include <iostream.h>

#define C1 0x4d
#define C2 0x11
#define C3 0x62
#define C4 0x8e
#define C5 0xbe
#define C6 0x1d
#define KEYFILE "br0ken-key.txt"

int main()
{
	ofstream k_file;
	BYTE k1, k2, k3, k4, k5, k6;
	
	k1 = C1 ^ 0x34;
	k2 = C2 ^ 0x78;
	k3 = C3 ^ 0x12;
	k4 = C4 ^ 0xfe;
	k5 = C5 ^ 0xdb;
	k6 = C6 ^ 0x78;
			
	k_file.open(KEYFILE);
	k_file	<< (char) k1 << (char) k2 << (char) k3
			<< (char) k4 << (char) k5 << (char) k6;
	k_file.close();
	
	cout	<< "Password: "
			<< (char) k1 << (char) k2 << (char) k3
			<< (char) k4 << (char) k5 << (char) k6
			<< endl;
			
	cout << "This password is stored in " << KEYFILE << endl;

	cin.get();
	return 0;
}
