Hello,

I had a couple of days to spare, so wrote this one.
All you need to do is find my password.


Rules
*****

There are no rules!
You may do anything you want to find the password.
Instructions to verify the pass is inside the cme.



Have fun!
br0ken

04/07/2009
dd/mm/yyyy
11:10 PM