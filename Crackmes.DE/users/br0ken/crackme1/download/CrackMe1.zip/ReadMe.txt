Hi, 

This is my first CM. So, be nice. Hehe ;)

Date 		: 	12/10/2007 [dd/mm/year]


To Do & Rules	:	Stage 1 - Find Pass - No Patching.

			Stage 2 - Keygen - No Patching.

			Stage 3 - Patch it.


Additional  	:	Report any bug[s] you may come across. You may find

			one or two ;)		


Compiler 	:	Dev-C++


Difficulty	:	Level 1
