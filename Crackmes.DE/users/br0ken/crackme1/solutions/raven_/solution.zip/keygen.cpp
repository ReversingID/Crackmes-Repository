#include <stdio.h>
#include <string.h>

void main()
{
	char name[255];
	int i, serial = -1;

	printf("Name: ");
	gets(name);

	for(i=0; i<strlen(name); i++)
	{
		serial += name[i] - 1;
	}

	printf("Serial: %d", serial);

	getchar();
}