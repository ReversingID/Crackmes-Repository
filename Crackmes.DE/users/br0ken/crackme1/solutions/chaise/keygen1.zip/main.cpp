
#define _WIN32_WINNT 0x0501
#include "resource.h"

#include <windows.h>
#include <stdlib.h>

#include <string.h>
#include <iostream>
HINSTANCE hinst;
HWND hwnd;
BOOL APIENTRY DlgProc(HWND Dlg,UINT message,WPARAM wParam,LPARAM lParam);
BOOL APIENTRY Dialog1Proc(HWND, UINT, WPARAM, LPARAM);
long lc(const char* chaine);
long cp(const char* chaine, char* chaine2);
long cmp(const char* chaine, char* chaine2);
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                                                LPSTR lpCmdLine, int nCmdShow)



{
       DialogBox(hInstance,"DIALOG1",NULL,(DLGPROC)DlgProc);


       return 0;
}
//---------------------------------------------------------------------------

BOOL APIENTRY DlgProc(HWND hDlg,UINT uMsg,WPARAM wParam,LPARAM lParam)
{

    switch (uMsg)
    {
      case WM_INITDIALOG:

         return TRUE;

      case WM_COMMAND:
         if (LOWORD(wParam) == IDOK)
              {

               char name[256]="",serial[31]="",buf1[31]="",serialin[31],message[41]="";
               char message1[20]= "invalid name";
               int sum=0;
                GetDlgItemText(hDlg, IDE_EDIT1, name, 256);
                int ln = strlen(name);
                if ((ln <  2) or (ln > 20))
                  {
                    strcpy (message, message1);
                    goto IMPRES;
                  }

             for (int i = 0;i<ln;i++)
                    {
                    sum = sum + int(name[i])-1;

                    }

                    sum = sum-1;

                    wsprintf(message,"%d",sum);

 IMPRES:              SetDlgItemText(hDlg, IDE_EDIT3,message) ;






              }
         if (LOWORD(wParam) == IDCANCEL)
                {
                   EndDialog(hDlg,0);
                   return TRUE;
                }


         if(LOWORD(wParam) == IDM_ABOUT)
                       DialogBox(hinst, "DIALOG2" , hwnd, (DLGPROC)Dialog1Proc);

      default:
         return FALSE;
    }
}

BOOL APIENTRY Dialog1Proc(HWND hDlg,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
    switch (uMsg)
    {
      case WM_INITDIALOG:

         return TRUE;

      case WM_COMMAND:
         if (LOWORD(wParam) == IDCANCEL || LOWORD(wParam) == IDOK)
                {
                   EndDialog(hDlg,0);
                   return TRUE;
                }

      default:
         return FALSE;
    }
}
