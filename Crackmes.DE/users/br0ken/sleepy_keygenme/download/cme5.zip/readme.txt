Sleepy Keygen me

To do
*****

Keygen + src + tut.
This has been tested on xpsp3, and should work on other OSes too. (but not tested)


Rules
*****

1. Rate cme after solving.
2. No patching.

Also, I recommend you use a naked version of olly (i.e no plugins)

Have fun!

br0ken
16/02/2009
dd/mm/yyyy