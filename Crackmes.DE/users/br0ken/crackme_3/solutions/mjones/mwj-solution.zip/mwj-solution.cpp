/**
* Keygen for br0ken's CrackMe 3
* Author: mjones
* August 22, 2009
*
* Keygen creates a serial for the app,
* then outputs the serial to STDOUT
*/

#include <string>
#include <iostream>

using namespace std;

int main() {
    string username;
    char key[11] = {0x40, 0x5E, 0x2A, 0x52, 0x24, 0x46, 0x56, 0x54, 0x25, 0x40, 0x00};

    unsigned int var_ebx;
    unsigned int var_ecx;

    unsigned int var_eax = 0x22FD00;
    unsigned int var_edx = 0xFAFF7264;
    unsigned int ebp_34c = 0;
    unsigned int ebp_350 = 0;
    unsigned int ebp_354 = 0;
    unsigned int ebp_35c = 0;
    unsigned int ebp_360 = 0;

    unsigned char var_al = 0;
    unsigned char var_cl = 0;
    unsigned char var_dl = 0;
    unsigned char flag = 0;


    do { // read in username
        std::cout << "Name: ";
        std::cin >> username;
    } while (username.length() == 0);

    while(ebp_35c < username.length()) {
        var_ebx = username[ebp_35c];                // MOVZX EBX, [EAX]
        var_ecx = username[ebp_35c];                // MOVZX ECX, [EAX]
        var_eax = (var_eax & 0xffff0000) 
                + (var_ecx & 0x000000ff);           // MOVSX AX, CL
        var_eax *= 0x67;                            // IMUL EAX, EAX, 67
        var_eax &= 0x0000ffff;                      // MOVZX EAX, AX
        var_eax >>= 8;                              // SHR EAX, 8
        var_edx = (var_edx & 0xffffff00)
                + (var_eax & 0x000000ff);           // MOV DL, AL

        
        var_dl = (var_edx & 0x000000ff);            // SAR DL, 2
        flag = (var_dl & 0x80);
        var_dl >>= 2;
        var_dl |= flag;
        var_edx = (var_edx & 0xffffff00) + var_dl;
        
        var_eax = (var_eax & 0xffffff00) 
                + (var_ecx & 0x000000ff);           // MOV AL, CL
        var_eax &= 0xffffff80;                      // SAR AL, 7
        var_edx -= (var_eax & 0x000000ff);          // SUB DL, AL
        var_eax = (var_eax & 0xffffff00)
                + (var_edx & 0x000000ff);           // MOV AL, DL

        var_al = ((var_eax & 0xff) << 2);        
        var_eax = (var_eax & 0xffffff00) + var_al;  // SHL AL, 2
        var_al += (var_edx & 0xff);                 // ADD AL, DL
        var_al += var_al;                           // ADD AL, AL
        var_cl = (var_ecx & 0xff) - var_al;         // SUB CL, AL
        var_al = var_cl;                            // MOV AL, CL
        var_ecx = (var_ecx & 0xffffff00) + var_cl;  // load cl into ecx, housekeeping
        var_eax = var_al;                           // MOVSX EAX, AL
        var_eax = key[var_eax];                     // MOVSX EAX, BYTE PTR DS:[EAX+EBP-348]
        var_edx = var_ebx;                          // MOV EDX, EBX
        var_edx ^= var_eax;                         // XOR EDX, EAX
        ebp_350 += var_edx;                         // LEA EAX, DWORD PTR SS:[EBP-350]
                                                    // ADD DWORD PTR DS:[EAX], EDX
        var_edx = username[ebp_35c];                // MOVZX EDX, [EAX]
        var_eax = key[ebp_35c];                     // MOVSX EAX, [EAX]
        var_eax *= var_edx;                         // IMUL EAX, EDX
        var_eax += ebp_354;                         // ADD EAX, [EBP-354]
        var_eax += 0xefef;                          // ADD EAX, 0EFEF
        ebp_354 = var_eax;                          // MOV [EBP-354], EAX
        ebp_360 = 0;                                // MOV [EBP-360], 0

        while(ebp_360 < username.length()) {
            var_eax = username[ebp_360];            // MOVSX EAX, [EAX]
            var_eax *= var_eax;                     // IMUL EAX, EAX
            var_eax += ebp_354;                     // ADD EAX, [EBP-354]
            var_eax -= ebp_350;                     // SUB EAX, [EBP-350]
            ebp_34c = var_eax;                      // MOV [EBP-34C], EAX
            ebp_360++;                              // LEA EAX,DWORD PTR SS:[EBP-360]
                                                    // INC DWORD PTR DS:[EAX]
        }
        
        ebp_35c++;                                  // LEA EAX,DWORD PTR SS:[EBP-35C]
                                                    // INC DWORD PTR DS:[EAX]
    }

    std::cout << "Your serial is: br0-" << ebp_354 << "-" << ebp_350 << ebp_34c << "-ken" << endl;

    std::cin.get();
    std::cin.get();
    return 0;
}