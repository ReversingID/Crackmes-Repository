/*
br0ken's Serial/Keygen Me
keyGen by kofiv

The password is any seven character message where the sum of the first six
characters [applied as (Character * ((Character*3) - 0x28))] is a multiple of 
10. The seventh character can be anything.

We generate a password by first creating a pair lookup table. This table will
contain pairs of valid character sums for all valid password characters. Any
character is valid, however for the sake of simplicity we only use the digits
0 through 9. Extending this to any character set is trivial and involves only
generating the proper lookup tables.

Character sums are generated according the the following algorithm:

	CharacterSum = (Character * ((Character * 3) - 0x28))

For our passwords we have the following character sums:

	0: 4992
	1: 5243
	2: 5500
	3: 5763
	4: 6032
	5: 6307
	6: 6588
	7: 6875
	8: 7168
	9: 7467

Next we need to generate three pairs. Since the password sum (sum of all
character sums) must be a multiple of 10 we do this by pairing character
sums that produce a multiple of 10. For example, 0 and 6 produce a multiple
of ten (0=4992 and 6=6588, 4992+6588=11580). We enter all possible pairs
into an integer array. This is our lookup table.

We randomly pick an entry from the array three times, this fills in the first
six characters of the password. The seventh is any random character.
*/

#include <iostream>
#include <time.h>
using namespace std;

const int pairLookup[18][2] = { 4, 6, 4, 8, 0, 6, 0, 8,
								6, 4, 8, 4, 6, 0, 8, 0,
								3, 5, 3, 9, 1, 5, 1, 9,
								5, 3, 9, 3, 5, 1, 9, 1,
								7, 7, 2, 2
};

int main(int argc, char *argv[])
{
	char key[8];
	int i = 0, idx = 0;

	cout << "br0ken's Serial/Keygen Me - keyGen by kofiv" << endl;

	srand((unsigned int)time(NULL));
	for(i = 0; i < 6; i += 2)
	{
		idx = rand() % 18;
		key[i  ] = pairLookup[idx][0] + 48;
		key[i+1] = pairLookup[idx][1] + 48;
	}
	
	key[6] = ((rand() % 10) + 48);
	key[7] = 0;

	cout << "Password: " << key << endl;
	return 0;
}