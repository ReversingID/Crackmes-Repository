// nhDlg.cpp : implementation file
//

#include "stdafx.h"
#include "nh.h"
#include "nhDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNhDlg dialog

CNhDlg::CNhDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CNhDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNhDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CNhDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNhDlg)
	DDX_Control(pDX, IDC_EDIT2, m_Edit2);
	DDX_Control(pDX, IDC_EDIT1, m_edit1);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CNhDlg, CDialog)
	//{{AFX_MSG_MAP(CNhDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_EN_CHANGE(IDC_EDIT1, OnChangeEdit1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNhDlg message handlers

BOOL CNhDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CNhDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CNhDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CNhDlg::OnOK() 
{
	// TODO: Add extra validation here
	
	CDialog::OnOK();
}

void CNhDlg::OnChangeEdit1() 
{
	const int a[16]={
		0x12,
		0x5C,
		0x34,
		0x22,
		0x0AB,
		0x9D,
		0x54,
		0x0,
		0x0DD,
		0x84,
		0x0AE,
		0x66,
		0x31,
		0x78,
		0x73,
		0x0CF};
	char s1[]="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	char sss[]="KEYGENNING4NEWBIES";
	CString s;
	m_edit1.GetWindowText(s);
	if (!s.IsEmpty())
	{
		unsigned long l=0x68656865;
		s=s+" is a whore.";
		char sq[0x40];
		strcpy(sq,(LPCTSTR)s);
		for(int i=s.GetLength();i<0x40;i++) sq[i]=0x0;
		for(i=0;i<16;i++)
		{
			unsigned long l1;
			strncpy((char *)&l1,&(sq[4*i]),4);
			l1+=(a[i]^i);
			__asm rol l1,7;
			l=l^l1;
		}
		CString key;
		for(i=0;i<=17;i++)
		{
			key.Insert(key.GetLength(),(s1[l%0x1a]^i^sss[i])+0x30);
			l=l<<3;
			__asm {
				mov eax,l
				mov edx,0x12345
				imul eax
				add eax,edx
				mov l,eax
			}
		}
		m_Edit2.SetWindowText(key);
	}
}
