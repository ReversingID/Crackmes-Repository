heya all fellahs,

this is keygenning4newbies keygenme #3,
as always, it should help you to improve your keygenning and learn you some new tricks.
This time, you'll have to face tables and lame ass encryption...
The protection algorithm isn't very hard, as i want some solution :p
i would also ask you to try to translate the algo into a coding language, whatever it is, like
C/C++, Delphi, VB..., just to avoid algo ripping.
Yeah, it is nice to rip an algo, but how do i know then that you understood it ? :}
if you write the keygen in full-asm, don't forget to join a complete tutorial/explaination on
how you reversed the algo. This paper will be published on analyst's site.

Send the whole package at seifer666@caramail.com

Good luck...,

Seifer[ECLiPSE/HellForge]

To Help you, here is a valid name/serial :
name : seifer
serial : ?5=>>HA=L3�G?C:CB5