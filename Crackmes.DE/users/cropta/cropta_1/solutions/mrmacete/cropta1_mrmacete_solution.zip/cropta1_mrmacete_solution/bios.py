import r2lang, sys, os, json

"""
usage: r2 -i bios.py -b 16 HardDisk
aei
aeim 0x2000 0xffff
aeip
e io.cache=true
(orpo, bios)
"e cmd.esil.intr=` `;.(orpo)"
e esil.gotolimit=0xffff
! (sleep 30 && killall -3 r2)&
aec
"""

r2 = r2lang

cylinders=20
heads=16
spt=63
bps=512

def wait_key():
	result = None
	if os.name == 'nt':
		import msvcrt
		result = msvcrt.getch()
	else:
		import termios
		fd = sys.stdin.fileno()
		oldterm = termios.tcgetattr(fd)
		newattr = termios.tcgetattr(fd)
		newattr[3] = newattr[3] & ~termios.ICANON & ~termios.ECHO
		termios.tcsetattr(fd, termios.TCSANOW, newattr)
		try:
			result = sys.stdin.read(1)
		except:
			pass
		finally:
			termios.tcsetattr(fd, termios.TCSAFLUSH, oldterm)
		return result


def handle_intr(intNum):
	regs = json.loads(r2.cmd('arj'))

	def xh(regName, setValue = None):
		val = regs[regName]
		if setValue == None:
			return (val & 0xff00)>>8
		else:
			val = (val & 0xff) | ((setValue & 0xff) << 8)
			r2.cmd('ar ' + regName + '=' + hex(val))
			return val

	def xl(regName, setValue = None):
		val = regs[regName]
		if setValue == None:
			return val & 0xff
		else:
			val = (val & 0xff00) | (setValue & 0xff)
			r2.cmd('ar ' + regName + '=' + hex(val))
			return val

	command = xh('ax') # ah

	if intNum == 0x13: # read/write disk
		if command == 2: # read from disk to memory
			nSectors = xl('ax') # al, number of sectors to read
			cylinder = xh('cx') # ch, cylinder
			firstSector = xl('cx') # cl, sector
			head = xh('dx') # dh, head
			destination = regs['bx'] & 0xffff # bx, buffer in memory

			source = (firstSector - 1 + (head + cylinder * heads) * spt ) * bps
			length = nSectors * bps

			r2.cmd('e io.cache=true')
			r2.cmd('wd ' + hex(source) + ' ' + hex(length) + ' @ ' + hex(destination))
			r2.cmd('ar cf=0')
		elif command == 8: # geometry
			driveNum = xl('dx') # dl drive number
			if driveNum != 0x80:
				r2.cmd('ar cf=1')
			else:
				r2.cmd('ar cf=0')
				r2.cmd('ar ax=0')
				r2.cmd('ar dx=' + hex(((heads-1) << 8) | 1))
				r2.cmd('ar cx=' + hex(spt | (cylinders << 8)))

	elif intNum == 0x16: #keyboard i/o
		if command == 0x10: # read extended key
			result = ord(wait_key())
			high = 0
			if result == 10:
				high = 0x1c
			elif result == 127:
				high = 0xe
			r2.cmd('ar ax=' + hex(result | (high << 8)))

	elif intNum == 0x10:
		if command == 0xe: # print char
			char = chr(xl('ax'))
			sys.stdout.write(char)
			sys.stdout.flush()


def bioscore(a):
	def _call(s):
		if s == "bios":
			ip = int(r2.cmd("ar ip"),0) - 2
			num = int(r2.cmd("?v $v@" + hex(ip)),0)
			handle_intr(num)
			return 1
		return 0

	return {
		"name" : "BiosCore",
		"license": "WPL",
		"desc": "toy bios",
		"call": _call
	}


r2lang.plugin("core", bioscore)
