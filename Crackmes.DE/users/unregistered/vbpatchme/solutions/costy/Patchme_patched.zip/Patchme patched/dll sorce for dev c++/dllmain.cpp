/* Replace "dll.h" with the name of your header */
#include "dll.h"
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>

BOOL CALLBACK EnumChildProc(HWND hwndChild, LPARAM lParam) {
     if (hwndChild != 0){
          EnableWindow(hwndChild,TRUE); //Enable all
          return TRUE;
          }
     else
         return FALSE;
     }
     
DLLIMPORT void enable (void)
{   
    // find patchme WINDOW
    HWND main_form;      
    main_form=FindWindow("ThunderRT6FormDC","UnReG15TeReD.!'s Patchme");
    //search all object inside the window
    EnumChildWindows(main_form, EnumChildProc, 0);
}




BOOL APIENTRY DllMain (HINSTANCE hInst     /* Library instance handle. */ ,
                       DWORD reason        /* Reason this function is being called. */ ,
                       LPVOID reserved     /* Not used. */ )
{
    switch (reason)
    {
      case DLL_PROCESS_ATTACH:
        break;

      case DLL_PROCESS_DETACH:
        break;

      case DLL_THREAD_ATTACH:
        break;

      case DLL_THREAD_DETACH:
        break;
    }

    /* Returns TRUE on success, FALSE on failure */
    return TRUE;
}

//written by costy
