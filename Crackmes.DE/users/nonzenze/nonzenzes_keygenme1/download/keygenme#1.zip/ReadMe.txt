Target: 			Keygenme#1.EXE
Platform:			WIN
Language:			ASM
Author: 			nonzenze
Date:					07/09/05
Difficulty:		1 - very easy, for newbies
================================================================================

DESCRIPTION
===========
This is my 1st crackme. It's coded in MASM and it is NOT packed or crypted. The algo used for calculating the registration code is simple. I tried to obfuscate this keygen a little bit- but i think, this is not very effective. I'm sure, you will reverse it fast.

I hope, you like it.

NOTE to the Pro's
=================
Give the newbies a chance to submit their solutions. :-}


Your Mission
============

Provide a working keygen, wich calculates correct registration codes. Send your solution to www.crackmes.de


regards,
	nonzenze