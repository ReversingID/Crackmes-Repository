1- Extract files to this folder C:\Keygen

2- Run keygen.exe

3- Find how the table keygen.dbf is modified

4- Write a tutorial.