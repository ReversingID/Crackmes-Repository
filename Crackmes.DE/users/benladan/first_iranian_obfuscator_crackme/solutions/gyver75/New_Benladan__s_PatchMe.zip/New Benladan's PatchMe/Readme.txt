
In this folder you will find:
1) The PDF solution;
2) The .EXE file patched;
3) Comments.txt: file used with Scherzo's LCB plugin;
4) myscrypt... patchmescript.txt;
5) Keygen subfolder;

by Gyver75