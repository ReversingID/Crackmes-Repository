#include "PatchMe.h"


static HINSTANCE hInst;
static char NameBuffer[MaxNameLength];
static char SerialBuffer[MaxSerialLength];

UINT NameLength;

// =================== KEYGEN ROUTINE ========================== 
u32 KeyEsp[MAXKEYSTREAM];
u32 State[4];
u8 CipherStream[MAXCIPHERSTREAM];
u8 TextStream[MAXTEXTSTREAM]; 

void Reset(u8 a[MAXTEXTSTREAM]){
	for (int i = 0; i < MAXTEXTSTREAM; i++)
		a[i] = 0x00;
}

u8 Move(u8 Dest[MAXTEXTSTREAM], u8 Source[MAXTEXTSTREAM], u8 Size){
	u8 Lun = 0;
	Reset(Dest);
	for (int i = 0; i < Size; i ++){
		Dest[i] = Source[i];
		Lun++;
	}
	return Lun;
}

void XorWord(u32 CK[4], u32 PT[4]){
	for (int k = 0; k < 4; k++) 
		State[k] = CK[k] ^ PT[k];
}

void SubShiftMixAdd(u32 CK[4], u32 S[4], const u8 L){
	u32 Temp[4]; 
	for (int k = 0; k < 4; k++){
		u8 a = (u8)((S[k%4]     & 0x000000ff)     ); 
		u8 b = (u8)((S[(k+1)%4] & 0x0000ff00) >> 8);
		u8 c = (u8)((S[(k+2)%4] & 0x00ff0000) >> 16);
		u8 d = (u8)((S[(k+3)%4] & 0xff000000) >> 24);
		if (!L)
			Temp[k] = Te1[a] ^ Te2[b] ^ Te3[c] ^ Te4[d];
		else
			Temp[k] = (u32)SBox[a] | ((u32)SBox[b] << 8) | ((u32)SBox[c] << 16) | ((u32)SBox[d] << 24);
	}
	XorWord(CK, Temp);
}

u32 RotWord(u32 i){
	u32 j = ((i & 0x000000ff) << 24) | (i >> 8);
	return j;
} 

u32 SubBytes(u32 i){
	u32 Temp = 0x00000000; u32 j;
	j = (i & 0xff000000) >> 24;  Temp |= (u32)(SBox[j] << 24);
	j = (i & 0x00ff0000) >> 16;  Temp |= (u32)(SBox[j] << 16);
	j = (i & 0x0000ff00) >>  8;  Temp |= (u32)(SBox[j] <<  8);
  j = (i & 0x000000ff);  
  Temp |= (u32)(SBox[j]);
	return Temp;
}

u32 Base64Encoder(u8 Dest[MAXTEXTSTREAM], u8 Source[MAXCIPHERSTREAM], u8 Size){

	u32 i = 0; 
	u32 j = 0;
	
	while( i<=(Size - 3)){ 	
		Dest[j    ] = Base64[( (Source[i  ] >> 2) & 0x3f )];
		Dest[j+1] = Base64[( (Source[i  ] << 4) | (Source[i+1] >> 4) ) & 0x3f ];
		Dest[j+2] = Base64[( (Source[i+1] << 2) | (Source[i+2] >> 6) ) & 0x3f ]; 
		Dest[j+3] = Base64[( (Source[i+2]       ) & 0x3f )];
		j += 4; i += 3;
	}
	if (i < Size){
		Dest[j  ] = Base64[( (Source[i] >> 2) & 0x3f )];
		Dest[j+1] = (i == (Size-1))? Base64[( (Source[i] << 4) & 0x30 )] : Base64[( (Source[i] << 4) | (Source[i+1] >> 4) ) & 0x3f ];
		Dest[j+2] = (i == (Size-1))? 0x3d : Base64[(Source[i+1] << 2) & 0x3c ];
		Dest[j+3] = 0x3d;
		j += 4; 
		}
	return j;
}

void EncryptProcess(void){

	u32 Temp[4] = {KeyEsp[0], KeyEsp[1], KeyEsp[2], KeyEsp[3]};
		
	// Initial Round;
	XorWord(Temp, State);
	// Central Rounds;
	for (int Round = 0; Round < 9; Round++){
		u8 Index = (Round+1) << 2;
		for (int k = 0; k < 4; k++)
			Temp[k] = KeyEsp[Index+k];
		SubShiftMixAdd(Temp, State, NoLast);
	}
	//Final Round;
	for (int k = 0; k < 4; k++)
		Temp[k] = KeyEsp[40+k]; 
	SubShiftMixAdd(Temp, State, Last);
}
	 
void KeySchedule(const u32 SK[4]){
	KeyEsp[0] = SK[0];
	KeyEsp[1] = SK[1];
	KeyEsp[2] = SK[2];
	KeyEsp[3] = SK[3];
	for (int j = 4; j <= 44 ; j++){
		if ((j % 4) == 0){
			KeyEsp[j] = RotWord(KeyEsp[j-1]); 
			KeyEsp[j] = SubBytes(KeyEsp[j]) ^ KeyEsp[j-4] ^ RCon[(j/4)-1];
		}
		else
			KeyEsp[j] = KeyEsp[j-1] ^ KeyEsp[j-4];
	}
}
       
void SerialGenerate(void){
	
	u32 TextLun = Move(TextStream, NameBuffer, NameLength);
	for (int j = 0; j < 4; j++){
		KeySchedule(SecretKey[j]);
		int Quotient = 0;
		for (int i = 0; i < (TextLun / 16); i++){
			State[0] = Getu32(TextStream       + (i << 4));
			State[1] = Getu32(TextStream +  4  + (i << 4));
			State[2] = Getu32(TextStream +  8  + (i << 4));
			State[3] = Getu32(TextStream + 12  + (i << 4));
			EncryptProcess();
			Putu32((CipherStream      + (i << 4)), State[0]);
			Putu32((CipherStream +  4 + (i << 4)), State[1]);
			Putu32((CipherStream +  8 + (i << 4)), State[2]);
			Putu32((CipherStream + 12 + (i << 4)), State[3]);
			Quotient++;
		}
		
		State[0] = ((TextLun%16) >  0)? Getu32(TextStream      + (Quotient << 4)): 0x00000000;
		State[1] = ((TextLun%16) >  4)? Getu32(TextStream +  4 + (Quotient << 4)): 0x00000000;
		State[2] = ((TextLun%16) >  8)? Getu32(TextStream +  8 + (Quotient << 4)): 0x00000000;
		State[3] = ((TextLun%16) > 12)? Getu32(TextStream + 12 + (Quotient << 4)): 0x00000000;
		State[3] |= (TextLun%16) << 24;
		EncryptProcess();
		Putu32((CipherStream      + (Quotient << 4)), State[0]);
		Putu32((CipherStream +  4 + (Quotient << 4)), State[1]);
		Putu32((CipherStream +  8 + (Quotient << 4)), State[2]);
		Putu32((CipherStream + 12 + (Quotient << 4)), State[3]);
		Quotient++;
		
		TextLun = Base64Encoder(TextStream, CipherStream, (Quotient << 4));
	}
	for (int i = 0; i < TextLun; i++)
		wsprintf(SerialBuffer + i, "%c", TextStream[i]);
		
}


// ============================================================

BOOL CALLBACK DlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam) {
      HICON Icon;
	HWND HandleName;

	switch (uMsg){
		case WM_INITDIALOG:
			Icon = LoadIcon(hInst, MAKEINTRESOURCE(G75));
			HandleName = GetDlgItem(hDlg, NameEdit);
			SerialGenerate();
			SetDlgItemText(hDlg, SerialEdit,SerialBuffer);
			PostMessage(hDlg, WM_COMMAND, (EN_SETFOCUS<<0x10)+NameEdit, (long int) HandleName);
			return TRUE;
		case WM_COMMAND:
			if (wParam == (EN_CHANGE<<0x10)+NameEdit){
				NameLength = GetDlgItemText(hDlg, NameEdit, NameBuffer, MaxNameLength);
				SerialGenerate();
				SetDlgItemText(hDlg, SerialEdit, SerialBuffer);
			} 
			else if (wParam == (BN_CLICKED<<0x10)+Quit) EndDialog(hDlg, 0);
			return TRUE;
		default:
			return FALSE;
	}
}

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd){
	hInst = GetModuleHandleA(NULL);
	InitCommonControls();
	DialogBox(hInst, MAKEINTRESOURCE(IDD_DIALOG), NULL, DlgProc);
	return 0;
}
