﻿Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBox1.Text = fReverseSerial("TapZ")
    End Sub

    Private Sub Form1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Click
        TextBox1.Text = fReverseSerial(fGenerateRandomString())
    End Sub

    Private Function fReverseSerial(ByVal sCharacters As String) As String
        Dim sLeft As String = sCharacters.Substring(0, 4) & "-" & ((Asc(sCharacters(0)) + (Asc(sCharacters(2)) * 10)) + &HCFC) & "-"
        Dim sRight As String = ((Asc(sCharacters(1)) + (Asc(sCharacters(3)) * 10)) + &H3E8)

        Return sLeft & sRight
    End Function

    Private Function fGenerateRandomString() As String
        Dim sString As String = Nothing
        Dim oRandom As New Random

        For i As Integer = 0 To (4 - 1) Step 1
            sString &= Convert.ToChar(Convert.ToInt32((26 * oRandom.NextDouble() + 65)))
        Next i

        Return sString.ToLower()
    End Function
End Class
