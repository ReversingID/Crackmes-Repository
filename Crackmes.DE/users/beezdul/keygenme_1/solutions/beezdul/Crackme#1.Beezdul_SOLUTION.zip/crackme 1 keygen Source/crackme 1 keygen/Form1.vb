﻿Public Class Form1
    Dim newpoint As New System.Drawing.Point
    Dim x, y As Integer
    Dim rnd As New System.Random '
    Dim hasbeenset = 0
    Public Declare Function FSOUND_Init Lib "music.dll" Alias "_FSOUND_Init@12" (ByVal mixrate As Integer, ByVal maxchannels As Integer, ByVal flags As Integer) As Byte
    Public Declare Function FMUSIC_LoadSong Lib "music.dll" Alias "_FMUSIC_LoadSong@4" (ByVal name As String) As Integer
    Public Declare Function FMUSIC_PlaySong Lib "music.dll" Alias "_FMUSIC_PlaySong@4" (ByVal urmodule As Integer) As Byte


    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click
        Me.Close()
    End Sub

    Private Sub Label1_MouseDown1(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Label1.MouseDown
        x = Control.MousePosition.X - Me.Location.X
        y = Control.MousePosition.Y - Me.Location.Y
    End Sub



    Private Sub Label1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Label1.MouseMove
        If e.Button = Windows.Forms.MouseButtons.Left Then
            newpoint = Control.MousePosition
            newpoint.X -= (x)
            newpoint.Y -= (y)
            Me.Location = newpoint
        End If
    End Sub

    Private Sub Label1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Label1.MouseUp

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim firstchars
        Dim Buffer1
        Dim Buffer2

        firstchars = rnd.Next(0, 10) & rnd.Next(0, 10) & rnd.Next(0, 10) & rnd.Next(0, 10) & "-"
        Buffer1 = firstchars.Chars(0) & firstchars.Chars(1) & firstchars.Chars(2) & firstchars.Chars(3) & "-" & Asc(firstchars.Chars(0)) + (Asc(firstchars.Chars(2)) * 10) + 3324 & "-"
        'Use chars 0 and two on hard coded
        Buffer2 = (Asc(firstchars.Chars(1)) + (Asc(firstchars.Chars(3))) * 10 + 1000)

        TextBox1.Text = Buffer1 & Buffer2
        firstchars = ""
        Buffer1 = 0
        Buffer2 = 0
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If hasbeenset = 0 Then

            Dim firstchars
            Dim Buffer1
            Dim Buffer2

            firstchars = rnd.Next(0, 10) & rnd.Next(0, 10) & rnd.Next(0, 10) & rnd.Next(0, 10) & "-"
            Buffer1 = firstchars.Chars(0) & firstchars.Chars(1) & firstchars.Chars(2) & firstchars.Chars(3) & "-" & Asc(firstchars.Chars(0)) + (Asc(firstchars.Chars(2)) * 10) + 3324 & "-"
            'Use chars 0 and two on hard coded
            Buffer2 = (Asc(firstchars.Chars(1)) + (Asc(firstchars.Chars(3))) * 10 + 1000)

            TextBox1.Text = Buffer1 & Buffer2
            firstchars = ""
            Buffer1 = 0
            Buffer2 = 0
            hasbeenset = 1
        End If
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim XMFilename As String = "myxmfile.xm" ' name of the xm file after extraction.
        Dim TempPath As String = System.IO.Path.GetTempPath() ' get the temp folder path
        Dim ExtractPath As String = TempPath & "\" & XMFilename ' file extraction path + xm filename

        ' extract the xm file to your temp folder
        Try
            System.IO.File.WriteAllBytes(ExtractPath, My.Resources.xmfile())
        Catch ex As Exception
            MsgBox(ex.Message) 'Elseif it fails
        End Try
        Try
            System.IO.File.WriteAllBytes(My.Application.Info.DirectoryPath & "\music.dll", My.Resources.Fmod())
        Catch ex As Exception
            MsgBox(ex.Message) 'Elseif it fails
        End Try

        FSOUND_Init(44001, 128, 0)
        Dim XMPointer As Integer = 0
        XMPointer = FMUSIC_LoadSong(System.IO.Path.GetTempPath() & "\myxmfile.xm") ' path to the xm file in the temp folder
        FMUSIC_PlaySong(XMPointer) ' play the music :)

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.Copy()
    End Sub
End Class
