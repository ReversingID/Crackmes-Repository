/* Target: KeyGenMe #1 by Yowmo
 * Type: KeygenMe
 * Difficulty: 2
 * Date: 18-07-09 10:00 AM
 * Author: Kilobyte
 * count: #5
*/


#include <stdio.h>
#include <windows.h>

const BYTE *pnames[11] = {"matrixba", "Ciwata", "QuAdR", "angelord", "ByPusat",
                  "MaXeLL", "K�naN", "zugzwang", "RedRose", "devrimcoskun",
                  "tarcin22"};

void level1(char *name)
{
    int len = strlen(name);
    DWORD result = 0;
    char serial[10];
    __asm
    {
        mov ecx,len
        sub ecx,2
        xor ebx,ebx
        mov edi,0xDEADBEEF
        mov edx,[name]
    l:
        cmp ebx,ecx
        jnb Done
        lea esi,[ebx+edx]
        mov eax,[esi]
        xor edi,eax
        mov [result],edi
        inc ebx
        jmp l
    }
    Done:
    sprintf(serial,"%X",result);
    printf("Level I: %s\n", serial);
}

void level2(char *name)
{
    TCHAR comp_name[100];
    DWORD bufferSize = 100;
    DWORD hash,hash2;
    char hbuff[15];     //computed hash buffer
    char serial[30];    //serial buffer.
    int len;

    // calculate hash 1 from computername
    GetComputerName(comp_name, &bufferSize);
    len = strlen(comp_name);
    hash = comp_name[len-1];
    hash = (((hash ^ 0x00035328) + 0xDEADBEEF) * 0x445) - 0x1BAD0BAD;
    hash = (hash << 3) ^ 0xD28FD035;

    // calculate hash 2 from name
    len = strlen(name);
    hash2 = name[len-1];
    hash2 = (((hash2 ^ 0x00035458) + len + 0xDEADBEEF) * 0x445) - 0x1BAD0BAD;
    hash2 = ((hash2 << 3) ^ 0xD44DE028) ^ 0x499529D9;

    // finalise
    hash ^= hash2;
    sprintf(hbuff,"%X",hash);

    // construct and print serial
    strcpy(serial,"TccT-");
    strcat(serial,hbuff);
    printf("Level II: %s\n", serial);

}

int main()
{

    char name[30];
    int i,n,len;

    printf("Name: ");
    fgets(name, 30, stdin); // don't tell the user just truncate it heh :P
    name[strlen(name) - 1] = '\0';  // darn fgets side effects
    len = strlen(name);
    if (len < 5) {
        printf("Name must be >= 5 and <= 25\n");
        system("pause");
        return(1);
    }

    n = 0;
    for (i = 0; i < 11; ++i) {
        if (strcmp(name, pnames[i]) == 0) {
            printf("Can't generate level1 serials for that name\n");
            printf("Level I: Go get that smiley face bro!\n");
            n = 1;          // found predefined name;
            break;
        }
    }

    if (n == 0)
        level1(name);

    level2(name);

    system("pause");
    return 0;
}
