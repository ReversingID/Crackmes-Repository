When viewing the video, be sure to change your resolution to 1280x1024.
If it's any lower you won't be able to see the video like it was intended to be seen.