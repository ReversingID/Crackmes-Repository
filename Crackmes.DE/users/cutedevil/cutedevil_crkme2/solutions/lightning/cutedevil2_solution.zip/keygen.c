#include <stdio.h>
#include <string.h>

void main()
{
	char	RegName[50];
	long	Counter = 0;

	while(1)
	{
		printf("KeyGen for CuTedEvil Crack Me #2");
		printf("\n\nRegistered Name: ");
		scanf("%[^\n\0]s", RegName);
		if(strlen(RegName) > 16)
		{
			printf("\nName must be shorter than 16 characters");
			continue;
		}

		if(strlen(RegName) == 0)
		{
			printf("\n\nNo name entered. Exiting.");
			printf("\nCtrl+C to close");
			while(1)
				Counter++;
		}

		break;
	}

	//print out the name
	printf("User Name: Cracked &\\zM$NJ'%s\n", RegName);

	//generate the serial
	for(Counter=0; Counter < (long)strlen(RegName); Counter++)
		RegName[Counter] = RegName[Counter] ^ (0x03 + (char)Counter);
	
	//print the serial
	printf("Serial: %s", RegName);

	printf("\n\nCtrl+C to close");
	while(1)
		Counter++;

	return;

}