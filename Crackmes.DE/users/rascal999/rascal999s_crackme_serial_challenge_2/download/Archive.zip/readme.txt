Serial challenge #2
20/07/08

serial - File to enter valid serial

Challenge: Find a valid serial key!

Extra challenge: Make a serial gen

Limits: None! Do what you want. Use anything.

Post full solution with a valid serial please.

Notes:

-This program (unlike my other ones) does not use
randomize or 'random numbers', this is pure algorithm.
-I've made a serial gen for it but it can take
between 2 - 120 seconds to find a valid serial.
Try and make an instantaneous one ;)

I may open-source serial.bas at some point.

Good luck (this should be easier than my encrypt program ;)