struct Y
{
	struct Y* A;
	struct Y* B;
	struct Y* C;
	struct Y* D;
	struct Y* E;
}

struct Y* FCT2(char* string, int len)
{
	x4 = FCT19();
	if (x4 == 0)
		return Y03;
	x4->A = string;
	x4->B = len;
	x4->C = len;
	return x4;
}

struct Y* <FCT19>()
{
	if (Y01->D == 0 && Y01->B == 0)
		FCT15(Y01, Y02, 20, 256);
	x4 = FCT16(Y01);
	if (x4 == 0)
		return NULL;
	x4->E = x4->D = x4->C = 0;
	return x4->C;
}

void <FCT15>(struct Y* ptr1, struct Y* ptr2[_], step, size);
{
	SET0_16B(ptr1);
	ptr1->D = xc = ptr2;
	for (x4 = 0; x4 < size; x4++, xc += step)
	{
		xc->A = 0;
		xc->B = x4 == param14-1 ? 0 : xc+step;
	}
}

struct Y* <FCT16>(struct Y* ptr)
{
	x4 = ptr->D;
	if (!x4)
		return 0;
	FCT17(ptr, x4);
	return x4;
}

void <FCT17>(struct Y* ptr1, struct Y* ptr2)
{
	(ptr1->C ? ptr1->C->B : ptr1->B) = ptr2;
	ptr2->A = ptr1->C;
	ptr2->B = 0;
	ptr1->C = ptr2;
	ptr1->A++;
}
