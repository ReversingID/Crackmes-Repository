// NOTE: OUT is set to stdout somewhere (instructions at 0x804b963)

<CHECK_PRINT>(___, char* string, int length)
{
	WARP_PRINT(string, length, 0);
	FCT25(0);
}

void <WARP_PRINT>(char* string, int length, ___)
{
	(VIRT_PRINT ? VIRT_PRINT : PRINT)(string, length, param10);
}

void <PRINT>(char* string, int length, ___)
{
	xc = string;
	if (!NCURSES)
	{
		fwrite(string, length, 1, stdout);
		fflush(stdout);
		return;
	}

	x4 = NCOL * NROW - ((ROW-1) * NCOL + COL) + 1;
	x8 = x4 < xc ? x4 : xc;

	memcpy(BUF1   + (ROW-1)* NCOL + COL - 1, string, x8);
	memset(BUF1+4 + (ROW-1)* NCOL + COL - 1, GLOBFC * 16 | *0x80568f8, x8);
//	memset(BUF1+4 + (ROW-1)* NCOL + COL - 1, 7, x8);

	while (length)
	{
		x10 = *xc & 0xff; // type casting
		if (x10 == 0)
			x10 = ' ';

		if (x10 <= 31)
		{
			if ((0x800d101 >> x10) % 2)
			{
				fputs(___, *OUT);
				fputc(x10 | 0x80, *OUT);
				fputs(___, *OUT);
			}
			else
				fputc(x10, *OUT);
		}
		else
			fputc(x10, *OUT);

		COL++;
		if (x10 == '\n' || COL >= NCOL)
		{
			COL = 1;
			ROW++;
			if (ROW > NROW)
				ROW = NROW
		}

		length--;
		xc++;
	}
	fflush(*OUT);
}
