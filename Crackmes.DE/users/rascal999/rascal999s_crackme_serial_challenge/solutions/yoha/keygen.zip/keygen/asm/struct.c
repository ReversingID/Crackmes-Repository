struct X
{
0x0:    struct* ?;
0x4:    struct* X; // next?
0x8:	struct MEM
	{
	0x0:	char*  data;
	0x4:    int allocated;
	0x8:
	};
};

struct Y
{
0x0:	int; // ???
0x4:    struct* X;
0x8:    struct* ?;
0xc:    struct* X;
};

void <FREEAT>(struct MEM* ptr)
{
	if (ptr && ptr->data)
	{
		free(ptr->data);
		ptr->data = 0;
		ptr->x4 = 0;
		ptr->x8 = 0;
	}
}

void* <ALLOCAT>(idx, size)
{
	if ((x4 = PTRARRAY[idx]_4))
		return x4;
	return PTRARRAY[idx]_4 = calloc(1, size);
}

struct MEM* <FCT19>()
{
	if (ENDRNDVECT->xc == 0 && ENDRNDVECT->x4 == 0)
		INITCHAIN(ENDRNDVECT, XARRAY, 20, 256);

	x4 = FCT16(ENDRNDVECT);
	if (x4 == NULL)
		return NULL;

	x4->x8  = 0; // x4->mem.x0 = NULL;
	x4->xc  = 0; // x4->mem.x4 = 0;
	x4->x10 = 0; // x4->mem.x8 = 0;
	return x4 + 8; // &x4->mem
}

struct X* <FCT16>(struct Y*)
{
	struct X* x4 = param8->xc;
	if (x4 == NULL)
		return NULL;
	FCT17(param8, x4);
	return x4;
}

void <FCT17>(struct Y*, struct X*)
{
	if (param8->x8)
		param8->x8->x4 = paramC;
	else
		param8->x4 = paramC;

	paramC->x0 = param8->x8;
	paramC->x4 = 0;          // paramC->mem->data = NULL;
	param8->x8 = paramC;
	param8->x0++;
}

void <INITCHAIN>(struct Y* parent, struct X children[], int step, int count)
{
	SET0_16B(parent);
	struct X* xc = children;
	parent->xc = xc;
	for (int x4 = 0; x4 < count; x4++)
	{
		xc->x0 = 0;
		xc->x4 = x14 >= count-1 ? NULL : xc + step;
		xc += step;
	}
}
