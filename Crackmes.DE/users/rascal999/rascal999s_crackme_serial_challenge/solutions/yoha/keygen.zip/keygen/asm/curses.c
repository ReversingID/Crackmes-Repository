void <WARP_GETYX>(int* x, int* y)
{
	(VIRT_GETYX ? VIRT_GETYX : GETYX)(x, y);
}

void <GETYX>(int* x, int* y);
{
	if (x) *x = NCURSES ? NCOL : 80;
	if (y) *y = NCURSES * NROW : 24;
}

<WARP_GETCOL>()
{
	(VIRT_GETCOL ? VIRT_GETCOL : GETCOL)();
}

int <GETCOL>()
{
	GETCOLROW(&x4, 0);
	return x4;
}

int <GETROW>()
{
	GETCOLROW(NULL, &x4);
	return x4;
}

void <GETCOLROW>(int* c, int* r)
{
	x4 = COL;
	x8 = ROW;
	if (NCURSES)
	{
		pthread_mutex_lock(&MUTEX);
		fflush(stdin);
		SETCOLOR(102, 0, 0);
		if (fscanf(stdin, "\033[%d;%dR", &x8, &x4) != 2)
		{
			x4 = COL;
			x8 = ROW;
		}
		pthread_mutex_unlock(&MUTEX);
	}
	if (c) *c = x4;
	if (r) *r = x8;
}

int <SETCOLOR>(int param8, int paramC, int param10)
{
	memcpy(&x28, ___, 7);
	if (NCURSES == 0)
		return -1;

	fflush(stdout);
	if (param8 > 17)
	{
		if (param8 == 107)
			fprintf(OUT, "\033[%dm", paramC); // set character attribute (color)
		fputs(*(x1b8+4*param8), OUT);
	}
	else
	{
		if (*(___+4*param8) == 0)
			return -1;

		x2c = tgoto(*(___+4*param8), paramC, param10);
		if (x2c == 0)
			return -1;

		tputs(x2c, 1, ___);
	}
	return 0;
}

<FCT67>
{
	x8 = malloc(20);
	x8 = ->x10 = x8;
	*___ = x8;

	*___ = WARP_GETCOL() - 1;
	WARP_GETYX(&x4, NULL);
	*___ = x4;
}
