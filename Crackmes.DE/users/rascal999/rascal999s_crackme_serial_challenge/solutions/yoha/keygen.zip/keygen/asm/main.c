int <main>(int argc, char** argv);
{
	SETGLOBS(argc, argc, 0);
	x* = 0;
	memset(&x48, 0, 9);
	x68 = &x48;
	x64 = &x48; // junk
	init x*;
	FCT3(0, FCT2("Rascal999 - 2008", 16), 1);
	ASK(FCT2("Enter serial> ", 15), 0, -1); // ASK gets the input
	FCT5(&x10, -1, 0);

	// the input is now in x10

	// x1c = sum of the first block's four bytes
	// x18 checks if every character is in A..Z (if not, equals -8)
	for (x14 = 1; x14 <= 4; x14++)
	{
		if (STR_AT(SUBSTR(&x10, x14, 1), 1) - 'A' > 26 || STR_AT(SUBSTR(&x10, x14, 1), 1) - 'A' < 0)
			x18 = -8;
		x1c += STR_AT(SUBSTR(&x10, x14, -1), 1);
	}

	// x20 = sum of the second block's four bytes
	// x18 checks if every character is in A..Z (if not, equals -8)
	for (x14 = 5; x14 <= 8; x14++)
	{
		if (STR_AT(SUBSTR(&x10, x14, 1), 1) - 'A' > 26 || STR_AT(SUBSTR(&x10, x14, 1), 1) - 'A' < 0)
			x18 = -8;
		x20 += STR_AT(SUBSTR(&x10, x14, -1), 1);
	}

	SRAND((uint64_t) x1c, 0);
	for (x14 = 1; x14 <= 8; x14++)
		x48[x14]_4 = (int) (RAND(VAR_A) * VAR_B + VAR_C);

	SRAND((uint64_t) x20, 0);
	for (x14 = 1; x14 <= 8; x14++)
	{
		tmp = (int) (RAND(VAR_A) * VAR_B);
		x48[x14]_4 = 'A' + ((x48[x14]_4^tmp) % 26);
	}

	// here x18 = 0 (five first characters in A..Z) or -8 (otherwise)
	// x18 is added something between 0 and 8
	// hence, we MUST have x18 = 0 before and then fulfill each test
	// intuitively: x10 == x68
	for (x14 = 9; x14 <= 16; x14++)
		if (STRCMP(PACKMEM(1, x68[x14]_4), -1, SUBSTR(&x10, x14, 1), -1) == 0)
			x18++;

	// the excepted length of the serial is 16 character
	// the first 8 bytes are used to compute what the second part is excepted to be
	if (STRLEN(&x10, -1) == 16 & x18 == 8)
		FCT3(0, FCT2("Good serial", 11), 1);
	else
		FCT3(0, FCT2("Bad serial", 10), 1);

	FREEAT(&x10);
	EXIT(0);
	return x4;
}

void <EXIT>(int status)
{
	exit(argc);
}

void <SETGLOBS>(int argc, char** argv, ___)
{
	GLOB80 = argc;
	GLOB84 = argc;
	GLOB5C = param10
}

void <SET0_16B>(void* ptr) // struct Z* ?
{
	memset(ptr, 0, 16);
}

void <FCT5>(struct MEM* dst, int len, ___)
{
	struct MEM x1018;
	x1018.allocated = FCT30(&x1018, 0x1000, 1, &x1018.x8);
	OVER_MEMMOVE(dst, len, &x1018, 0, param10);
	FCT25(0);
}

// puts back the input into dst
int <FCT30>(char* dst, ___, ___, ___)
{
	struct MEM* x18 = ALLOCAT(2, 24); // the input from the user
	*param14 = 0;
	init x*;
	char x4 = FCT51(x18); // take one character from the input
	if (x4 != -1)
	{
		switch (x4)
		{
			case '\n':
				x14 = 0;
				break;
			case '\r':
				x4 = FCT52(x18);
				if (x4 != '\n')
					FCT53(x18, x4);
				x14 = 0;
				break;
			case '"':
				if (xc == 0)
				{
					if (x8 != 0)
						goto default;
					xc = 1;
					goto lollabel;
				}
				xc = 0;
				if (x10 == 0)
					goto lollabel;
				x4 = FCT52(x18);
				break;
			case '#':
				if (xc != 0)
					goto default;
				break;
			case '&':
				x10 = 1;
				goto default;
			case ';':
				if (x10 == 0 && param10 == 0)
					x4++;
			case '%':
			case '<':
				if (x10 != 0)
					goto default;
				*param14 = 1;
				goto default:
			case '\t':
			case ' ':
				if (xc != 0 || param10 != 0)
					goto default;
				break;
			default:
				*dst = x4; // byte
				dst++;
				x8++;
			lollabel:
				if (x8 < paramC)
					x4 = FCT52(x18);
		}
	}
	if (x14 != 0)
		FCT54(x18, x4);
	return x8;
}

struct MEM* <SUBSTR>(struct MEM* string, int start, int length)
{
	if (string && string->x0 && string->x4 & MAX_INT)
	{
		int x8 = string->x4 & MAX_INT; // length (type casting)
		if (0 < start && start <= x8 && length)
		{
			start--;
			if (length < 0)
				length = x8;

			if (length > x8 - start)
				length = x8 - start;

			x4 = FCT79();
			if (x4)
			{
				MEMCPY2(x4->x0, string->x0 + start, length);
				x4->x0[length] = 0;
				return x4;
			}
			return DEFAULT;
		}
		return DEFAULT;
	}
	FREEMEM(string);
	return DEFAULT;
}

void* <MEMCPY2>(void* dst, void* src, int count)
{
	for (ecx=param10/4; ecx; ecx--) *(edi++) = *(esi++); // words
	for (ecx=param10%4; ecx; ecx--) *(edi++) = *(esi++); // bytes
	return param8;
}

// get the idx-th character from string
<FCT7>(struct MEM* string, int idx)
{
	if (string == 0)
		return 0;
	x8 = string->x4 & MAX_INT; // type casting
	if (string->x0 = 0 || x8 == 0 || idx <= 0 || idx > x8)
		return 0;
	x4 = string->x0[idx-1] & 0xff; // type casting
	OVER_FREEMEM(string);
	return x4;
}

// returns in FPU
double <RAND>(double)
{
	return LASTRND = (PTR_RAND)(param8); // EXTRACT_RAND
}

double <EXTRACT_RAND>(double)
{
	if ((float) param8 == 0) // never the case (VAR_A != 0)
		return LASTRND;

	x10[0] = 0;
	xc = ___;
	if (CURRNDIDX == 0)
		SRAND(0, ___, 3); // wat? (actually never occurs)

	if (CURRNDIDX >= &ENDRNDVECT)
	{
		for (x4 = 0; x4 <= 623; x4++)
		{
			x8 = (RNDVECT[x4]_4 & 0x80000000) | (RNDVECT[(x4+1)%624]_4 & MAX_INT);
			RNDVECT[x4]_4 = (x8/2) ^ RNDVECT[(x4+397)%624]_4 ^ x10[x8 % 2]_4;
		}
		CURRNDIDX = RNDVECT;
	}
	x8 = *CURRNDIDX;
	CURRNDIDX += 4;
	x8 ^= x8 >> 11;
	x8 ^= (x8 << 7) & ___;
	x8 ^= (x8 << 15) & ___;
	x8 ^= x8 >> 19;

	x18 = (double) x8 / *___;
	return x18; // as double
}

<STRCMP>(struct MEM* stringA, int lenA, struct MEM* string B, int lenB)
{
	if (stringA && stringB)
	{
		/* BEGIN HANDLING TYPE */
		if (stringA == 0)
		{
			x4 = 0;
			xc = 0;
		}
		else
		{
			if (lenA == -1)
			{
				x4 = stringA->x0;
				xc = stringA->x4 & MAX_INT;
			}
			else
			{
				x4 = stringA;
				xc = strlen(stringA);
			}
		}
		if (stringB == 0)
		{
			x8 = 0;
			x10 = 0;
		}
		else
		{
			if (lenB == -1)
			{
				x8 = stringB->x0;
				x10 = stringB->x4 & MAX_INT;
			}
			else
			{
				x8 = stringB;
				x10 = strlen(stringB);
			}
		}
		/* END HANDLING TYPE */

		FCT81(x4, x8, MIN(x10, xc));
		if (x14 == 0 && xc != x10)
			x14 = xc > x10 ? 1 : -1;
	}
	else if (stringA == 0)
	{
		if (stringB == 0)
			x14 = 0;
		else
		{
			/* BEGIN HANDLING TYPE */
			if (stringB == 0)
			{
				x8 = 0;
				x10 = 0;
			}
			else
			{
				if (lenB == -1)
				{
					x8 = stringB->x0;
					x10 = stringB->x4 & MAX_INT;
				}
				else
				{
					x8 = stringB;
					x10 = strlen(stringB);
				}
			}
			/* END HANDLING TYPE */

			x14 = stringB == 0 ? 0 : -1;
		}
	}
	else
	{
		/* BEGIN HANDLING TYPE */
		if (stringA == 0)
		{
			x4 = 0;
			xc = 0;
		}
		else
		{
			if (lenA == -1)
			{
				x4 = stringA->x0;
				xc = stringA->x4 & MAX_INT;
			}
			else
			{
				x4 = stringA;
				xc = strlen(stringA);
			}
		}
		/* END HANDLING TYPE */

		x14 = xc == 0 ? 0 : 1;
	}

	if (lenA == -1) FREEMEM(stringA);
	if (lenB == -1) FREEMEM(stringB);

	return x14;
}

int <STRLEN>(struct MEM* string, int type)
{
	if (string == 0)
		return 0;

	if (type == -1)
	{
		x4 = string->x4 & MAX_INT;
		OVER_FREEMEM(string);
		return x4;
	}
	else
	{
		return strlen(string);
	}
}

void <SRAND>(double seed, int)
{
	if (param10 == 0)
	{
		param10 = GLOB5C <= 0 ? 3 : // always here
		          GLOB5C <= 2 ? 1 :
		          GLOB5C == 3 ? 3 :
		                        4;
	}

	if (!seed)
		seed = GETTIME();

	switch (param10)
	{
		case 1:
			PTR_RAND = ___;
			x2c = (int) seed;
			srand(x2c);
			rand();
			break;
		case 2:
			PTR_RAND = ___;
			x28 = (int) seed;
			*___ = x28;
			break;
		case 4:
			PTR_RAND = ___;
			x18 = seed;
			x14 = paramC;
			x1c = param14;
			x1c ^= (x1c >> 10);
			x1c = (x1c << 8) | *___;
			*___ = 0x1c;
			break;
		default: // always here
			PTR_9 = EXTRACT_RAND;
			RNDVECT[0] = (int) seed; // apparently truncated
			for (xc = 1; xc <= 623; xc++)
				RNDVECT[xc]_4 = 0x19660d * RNDVECT[xc-1]_4 + 0x3c6ef35f;
			CURRNDIDX = ENDRNDVECT;
	}
}

doucle <GETTIME>()
{
	gettimeofday(&x8, 0);
	return (x8 * *___ + x4) * *___;
}
