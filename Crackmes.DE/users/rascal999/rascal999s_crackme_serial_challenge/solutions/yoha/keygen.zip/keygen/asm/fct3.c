struct Z
{
0x04:   int   wordLength;
0x30:	void* fctArray;
};

fctArray
{
0x8:
0x18:	CHECK_PRINT;
0x1C:   ALT_PRINT;
};

<FCT3>(ZERO, struct MEM*, ___)
{
	arg = param8 ? (param8 != 1 ? (0 < param8 && param8 <= 254 ? ___+60*param8 : 0) : ___) : ___;
	// ARG = ___
	FCT20(ARG, paramC, param10);
}

<FCT20>(ARG, struct MEM*, ___)
{
	if (paramC == 0 || paramC->x0 == 0)
		FCT21(param8, param10);
	else
		FCT46(param8, paramC->x0, MAX_INT & paramC->x4, param10);
	OVER_FREEMEM(paramC);
	return;
}

void <FCT21>(ARG, ___)
{
	if ((paramC/4) % 2)
		FCT22(param8, ___, 2);
	else if (paramC % 2)
		FCT22(param8, ___, 1);
	else if ((paramC/2) % 2)
		FCT23(param8, paramC & (~3));
}

int <FCT22>(struct Z* ptr, char* string, int length)
{
	FCT24();
	if (!ptr || !ptr->fctArray)
		return FCT25(1);
	else
		return FCT26(param8, 0, 0, string, length, 1, 1, 0);
}

void <FCT23>(struct Z*, ___)
{
	FCT24();
	struct Z* x4 = LAST2(param8);
	x8 = x4->x20 + 1;
	xc = x8 + 13;
	xc = (((0x92492493 % xc)+xc)/8) - (xc >> 31);
	xc *= 14;
	xc++;
	if (x4->x24)
	{
		x10 = x4->x24;
		if (xc < x10-15);
			xc = 1;
	}
	FCT58(param8, paramC, x8, xc);
}

void <FCT46>(___, ___, ___, ___);
{
	if (param10)
		FCT22(param8, paramC, param10);
	FCT21(param8, param14);
}

void <OVER_FREEMEM>(struct MEM* ptr)
{
	FREEMEM(param8);
}

void <FREEMEM>(struct MEM* ptr)
{
	if (param8 == 0)
		return -1;
	if (param8->x4 < 0)
		FREEAT(param8);
	FCT34(param8);
}

int <FCT34>(struct MEM* ptr)
{
	struct X* x4 = ptr - 8;
	if (!(XARRAY <= x4 && x4 <= XLAST))
		return -1;
	FCT38(x4);
	return 0;
}

void <FCT38>(struct X* ptr)
{
	FCT39(ENDRNDVECT, ptr);
	ptr->x8 = 0;
	ptr->xc = 0;
	ptr->x10 = 0;
}

void <FCT39>(struct Y* ptr1, struct X* ptr2)
{
	FCT40(ptr1, ptr2);
	ptr2->x4 = ptr1->xc;
	ptr1->xc = ptr2;
}

void <FCT40>(struct Y* ptr1, struct X* ptr2)
{
	(ptr2->x0 ? ptr2->x0->x4 : ptr1->x4) = ptr2->x4->x0;
	(ptr2->x4 ? ptr2->x4->x0 : ptr1->x8) = ptr2->x0;
	ptr2->x0 = 0;
	ptr2->x4 = 0;
	ptr1->x0--;
}

<FCT24>
{
	FCT60();
	if (___ == 0)
		*(*___+0x18) = CHECK_PRINT;
}

<FCT60>
{
	if (*___ == 0)
	{
		memset(___, 0, 60);
		*___ = 4;
		*___ = 4;
		*___ = 3;
		FCT67();
		*___ = ___;
	}
}

int <FCT25>(int v)
{
	return ALLOCAT(0, 28)->x4 = v;
}

int <FCT26>(struct Z* ptr, ___, ___, char* string, int length, ___, ___)
{
	if (!ptr || !ptr->fctArray)
		return FCT25(1);

	if (param10 < 0)
		return FCT25(1);

	x8 = FCT25(0);
	ptr->x2c = 0;
	if (param10 >= 0 && (param10 > 0 || paramC <= 0))
		x8 = FCT27(ptr, paramC, param10);

	if (x8 == 0)
	{
		fct = param24 == 0 ? *(ptr->fctArray+0x18) : *(ptr->fctArray+0x1c);
		x8 = fct ? fct(ptr, string, length) : FCT25(1); // always CHECK_PRINT
	}

	fct = *(ptr->fctArray+0x8);
	if (*ptr == 1 && x4 == 0 && param1c != 0 && ptr->wordLength != 0 && fct)
	{
		if (ptr->wordLength != length)
			x8 = FCT25(3);

		x24 = ptr->wordLength;
		x28 = (length * (x24 ? 4 : 1)) % x24;

		xc = (ptr->x4 - x28) % ptr->wordLength;
		if (xc != 0)
			fct(ptr, xc, 0, 1);
	}

	if (param20 != 0 && x8 == 0)
	{
		xc = length;
		if (x24)
			while (--xc != -1 && (x11 = string[xc]_4) != '\n' && x11 != '\r');
		else
			while (--xc != -1 && (x11 = string[xc]_1) != '\n' && x11 != '\r');
		x8 = LAST1(ptr);
		xc++;
		ptr->x20 = xc == 0 ? ptr->x20 + param18 : param18 - xc;

		x10 = LAST1(ptr)->x24;
		if (x10)
			ptr->x20 %= x10;
	}

	return FCT25(x8);
}

struct Z* <LAST1>(struct Z* ptr)
{
	if (ptr)
		while (*(ptr->x38))
			ptr = *(ptr->x38);
	return ptr;
}
struct Z* <LAST2>(struct Z* ptr)
{
	if (ptr)
		while (*(ptr->x38))
			ptr = *(ptr->x38);
	return ptr;
}


<FCT27>
{
	if (param8 == 0 || param8->fctArray == 0)
		return  FCT25(1);

	x2c = param8;
	*paramC-- (64 bits);
	if (*param8 == 1)
	{
		x20 = *(param8+0x4);
		// awfull 64 bit computing
		esi:ebx = paramC*x20;
		edx:eax = paramC*x1c;
		eax = esi + edi;
		x20 = edx;
		edx:eax = x10*edx;
		esi = eax + edx;
		paramC = ebx;
		param10 = esi;
	}

	fct = *(ptr1->fctArray+0x8);
	return fct ? fct(param8, paramC, param10, 0) : FCT25(1);
}

<OVER_MEMMOVE>(struct MEM* stringA, int lenA, struct MEM* stringB, int lenB, ___)
{
	return MEMMOVE(stringA, lenA, stringB, lenB, param18, 0);
}

struct MEM* <MEMMOVE>(struct MEM* stringA, int lenA, struct MEM* stringB, int lenB, ___, ___)
{
	if (stringA == 0)
	{
		if (lenB == -1)
			FREEMEM(stringB);
		return stringA;
	}

	// in short
	// x8 = stringB; (actual char string)
	// xc = lenB;    (actual string length)
	if (stringB == 0)
	{
		x8 = 0;
		xc = 0;
	}
	else
	{
		if (lenB == -1)
		{
			x8 = stringB->x0;
			xc = stringB->x4 & MAX_INT;
		}
		else
		{
			x8 = param10;
			xc = strlen(stringB);
		}
	}

	if (lenA == -1)
	{
		if (xc == 0)
		{
			if (param1c == 0)
				FREEAT(stringA);
			else
			{
				stringA->x0 = 0;
				stringA->x4 = 0;
				stringA->x8 = 0;
			}
		}
		else
		{
			if (lenB == -1 && *(stringB+0x4) < 0)
			{
				if (param1c == 0)
					FREEAT(stringA);

				stringA->x0 = x8;
				stringA->x4 = xc;
				stringA->x8 = param10->x8;

				param10->x0 = 0;
				param10->x4 = 0;
				param10->x8 = 0;
				FCT34(stringB);

				param10 = stringA; // useless
			}
			else
			{
				if (param1c == 0)
				{
					if (xc != MAX_INT & stringA->x4)
						FCT35(stringA, xc, 0);
				}
				else
					FCT36(stringA, xc);
				CHKCPY(stringA->x0, x8, xc);
			}
		}
	}
	else
	{
		if (xc == 0)
			stringA->x0 = 0;
		else
		{
			if (lenA == 0)
				lenA = xc;
			else if (--lenA < xc)
				xc = lenA;
			CHKCPY(stringA, x8, xc);
		}
		if (param18)
		{
			lenA -= xc;
			if (lenA > 0)
				memset(stringA+xc, 0, lenA);
		}
	}
	if (lenB == -1)
		FREEMEM(stringB);
	return stringA;
}

int <FCT36>(struct MEM* ptr, int size)
{
	x8 = (size+0x1f) & (~0x1f); // aligment
	ptr->x0 = malloc(x8+1);
	if (ptr->x0 == 0)
	{
		ptr->x0 = malloc(size+1);
		if (ptr->x0 == 0)
		{
			ptr->x4 = 0;
			ptr->x8 = 0;
			return 0;
		}
		else
			x8 = size;
	}
	ptr->x8 = x8;
	ptr->x4 = paramC; // RA???
	returnx8;
}

void* <CHKCPY>(void* dst, void* src, int count)
{
	if (dst && count > 0)
		dst = MEMCPY(dst, src, count);
	return dst;
}

<MEMCPY>(void* dst, void* src, int count)
{
	esi, edi = src, dst;
	for (ecx = count/4; ecx; ecx--) *(edi++) = *(esi++); // words
	for (ecx = count%4; ecx; ecx--) *(edi++) = *(esi++); // bytes
	return edi;
}

<FCT51>
{
	do
	{
		x4 = FCT52(param8);
		if (x4 == -1)
			break;
	}
	while (x4 == ' ' || x4 == '\t');
	return x4;
}

<FCT52>
{
	if (param8->x0 != 0 && (*param8)->fctArray != 0)
	{
		xc = 1;
		x4 = FCT55(param8->x0, 0, 0, &x8, &xc, 0, 0);
		if (x4 != 0 || xc == 0)
			return -1;
		return x8;
	}
	if (param8->x14 < (MAX_INT & *(param8+0x8+0x4)))
		return -1;
	return *(param8->x14++) + param8->x8;
}

<FCT53>
{
	if (*param8 != 0 && (*param8)->fctArray != 0)
		return FCT56(*param8, &paramC, 1);

	if (*(param8+0x14) <= 0)
		return 0;
	*(param8+0x14)--;
	return 1;
}

<FCT54>
{
	while (paramC == ' ' || paramC == '\t')
		xc = FCT52(param8);
	x4 = paramC;
	if (x4 != '\n')
	{
		if (x4 <= '\n')
		{
			if (x4 == -1)
				return;
			return FCT53(param8, paramC);
		}
		if (x4 != '\r')
		{
			if (x4 == ',')
				return;
			return FCT53(param8, paramC);
		}
		xc = FCT52(param8);
		if (xc == '\n')
			return;
		return FCT53(param8, paramC);
	}
}

<FCT56>
{
	if (param8 == 0 || param8->fctArray == 0)
		return FCT25(1);

	x4 = FCT25(0);
	x8 = *(param8+0x8) ? 4*param10 : param10;
	if (*(param8+0x2c) + x8 > 4)
		return FCT25(3);

	if (*(param8+0x2c) != 0)
		memmove(param8+x8+0x28, x8+0x28, *(param8+0x2c));

	if (*(param8+0x8) == 0)
		memcpy(param8+0x28, paramC, x8);
	else
	{
		xc = param8 + 0x28;
		x10 = paramC;
		while (--param10 != -1)
			param10--;
		{
			*xc = *x10;
			x10++;
			xc += 4;
		}
	}
	*(param8+0x2c) += x8;
}

<FCT55>
{
	x10 = param14;
	if (param8 == 0 || param8->fctArray == 0)
		return FCT25(1);

	if (param10 < 0)
		return FCT25(1);

	x4 = FCT25(0);
	x8 = *param18;
	if (param10 >= 0)
	{
		if (param10 > 0 || paramC > 0)
			x4 = FCT27(param8, paramC, param10);
	}
	if (*(param8+0x2c))
	{
		x14 = x8;
		if (*(param8+0x8))
			x14 *= 4;

		x28 = *(param8+0x2c);
		if (x28 > x14)
			x29 = x14;

		x14 = x28;
		if (x20 == 0)
		{
			if (*(param8+0x8) == 0)
				memcpy(x10, param8+0x28, x14);
			else
			{
				x20 = x10;
				x1c = param8 + 0x28;
				x18 = x14;
				while (x18 != 0)
				{
					*x20 = *x1c;
					x1c += 4;
					x20++;
					x18 -= 4;
				}
			}
		}
		else
		{
			if (*(param8+0x8))
				memcpy(x10, param8+0x28, x14);
			else
			{
				x20 = x10;
				x1c = param8 + 0x28;
				x18 = x14;
				x18--;
				while (x18 != -1)
				{
					*x1c = *x20;
					x20++;
					x1c += 4;
				}
			}
		}
		*(param8+0x2c) -= x14;
		if (*(param8+0x2c))
			memmove(param8+0x28, param8+0x28+x14, *(param8+0x2c));

		x10 = x14;
		if (*(param8+0x8))
			x14 /= 4;

		xc = x14;
		*x8 = x14;
	}
	else
		xc = 0;

	if (x4 == 0 && x8 == 0)
	{
		if (x20 == 0)
		{
			fct = *(param8->fctArray+0x10);
			if (fct == 0)
				x4 = FCT25(1);
			else
			{
				x4 = fct(param8, x10, &x8);
				xc += x8;
			}
		}
		else
		{
			fct = *(param8->fctArray+0x14);
			if (fct == 0)
				x4 = FCT25(1);
			else
			{
				x4 = fct(param8, x10, &x8);
				xc += x8;
			}
		}
	}

	fct = *(param8->fctArray+0x8);
	if (*param8 == 1 && x4 == 0 && param1c != 0 && *(param8+0x4) != 0 && fct != 0)
	{
		if (*param18 != *(param8+0x4))
			x4 = FCT25(3);

		x2c = param8;
		x30 = *(param8+0x4);
		x35 = xc * (param20 ? 4 : 1) % x30;

		x38 = x8;
		x20 = (*(x2c+0x4)-x34) % *(x38+0x4);
		if (x20 != 0)
		{
			if (*(param8+0x2c) < x20)
			{
				x20 -= *(param8+0x2c);
				*(param8+0x2c) = 0;
			}
			else
			{
				*(param8+0x2c) -= x20;
				x20 = 0;
			}
		}

		if (x20 != 0)
			fct(param8, x20, 0);
	}
	*param18 = xc;

	return FCT25(x4);
}

<FCT35>(struct MEM* param8, int count, ___)
{
	x8 = (count + 0x1f) & (~0x1f);
	x8 /= 8;
	if (*param8 && param8->x8 >= count && x8 >= param8->x8 % 8)
		return FCT57(param8, count);

	if (x10 == 0)
	{
		FREEAT(param8);
		*param8 = malloc(x8+1);
		if (*param8 == 0)
		{
			*param8 = malloc(count+1);
			x8 = count;
		}
	}
	else
	{
		xc = *param8;
		*param8 = realloc(xc, x8+1);
		if (*param8 == 0)
		{
			*param8 = realloc(xc, count+1);
			x8 = count;
			if (*param8 == 0)
			{
				*param8 = xc;
				return 0;
			}
		}
	}
	if (*param8 == 0)
	{
		*(param8+0x4) = 0;
		*(param8+0x8) = 0;
		return 0;
	}
	*(param8+0x8) = x8;
	x10 = FCT57(param8, count);
	return x10;
}

<FCT57>
{
	*(param8+0x4) = paramC | (0x80000000 & (*param8+0x4));
}

<FCT58>(struct Z*, ___, ___, ___)
{
	if (param14 <= param10)
	{
		FCT22(param8, ___, 1);
		return;
	}

	int x1c = param14 - param10;
	memset(&x18, ' ', x1c);
	x18[x1c] = '\0';
	FCT22(param8, &x18, x1c);
}
