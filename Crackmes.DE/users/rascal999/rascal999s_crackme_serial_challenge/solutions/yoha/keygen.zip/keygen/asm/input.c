// put the answer in the second indexed MEM structure
int <ALLOC_ASK>(struct MEM* prompt, ___, ___)
{
	FCT59();
	if (WARP_FCT62(1))
	{
		OVER_FREEMEM(prompt);
		return FCT61(0);
	}

	x4 = ALLOCAT(2, 24);
	FREEAT(&x4->x8);
	x4->x0 = 0;
	x4->x4 = 0;
	x4->x14 = 0;

	return WARP_ASK(prompt, x4->x8, -1, 0);
}

<FCT59>
{
	FCT60();
	if (*(*___+0x10) == 0)
	{
		x4 = *___;
		*(x4+0x10) = WARP_FCT62(1) ? *___ : *___;
	}
}

<WARP_FCT62>
{
	return (VIRT_FCT62 ? VIRT_FCT62 : FCT62)(param8);
}

<FCT62>
{
	return isatty(fileno(param8 ? stdin : stdout)) == 0;
}

int <WARP_ASK>(struct MEM* prompt, struct MEM* dst, int len, ___, ___, ___)
{
	return (VIRT_ASK ? VIRT_ASK : ASK)(prompt, dst, len, param14, param18, param1c);
}

int <ASK>(struct MEM* prompt, struct MEM* dst, int len, ___, ___, ___)
{
	WARP_PRINT(0, 0, 8);
	if (prompt)
	{
		if (*prompt)
			FCT3(0, prompt, 0);
		else
			OVER_FREEMEM(prompt);

		if (param18)
			OVER_FCT65(0, *___, 0);
	}

	struct MEM* x4 = OVER_GETINPUT(0);
	if (x1c)
		OVER_FCT21(0, 1);

	if (x4)
	{
		OVER_MEMMOVE(dst, len, x4, -1);
		return FCT25(0);
	}
	else
		return FCT25(4);
}

struct MEM* <OVER_GETINPUT>(___)
{
	x4 = FCT19();
	return x4 ? GETINPUT(x4, param8) : NULL;
}

<OVER_FCT21>
{
	FCT21(param8 ? (param8 != 1 ? (0 < param8 && param8 <= 254 ? ___+60*param8 : 0) : ___) : ___, paramC);
}

<OVER_FCT65>
{
	FCT65(param8 ? (param8 != -1 ? (0 < param8 && param8 <= 254 ? ___+60*param8 : 0) : ___) : ___);
}

<FCT65>
{
	if (paramC == 0)
		FCT21(param8, param10);
	else
		FCT66(param8, paramC, strlen(paramC));
}

<FCT66>
{
	if (param10)
		FCT22(param8, paramC, param10);
	FCT21(param8, param14);
}

// get a line of input and put it in param8
struct MEM* <GETINPUT>(struct MEM*, ___)
{
	x24 = 0;
	WARP_GETYX(&x14, &x18);

	x28 = (FCT68(0, 0, -1, 0, 0) + 32) % 2;
	x20 = (FCT68(0, 0, 0, 0, 0) + 32) & 0x7fffffff;
	x1c = x20;
	WARP_PRINT(param8->x0, x20, 0);
	FCT68(0, 0, paramC == 0, 0, 0);

	// each iteration handle one character
	do
	{
		x4c = 0;
		x50 =0;
		if (FCT69(&xc, &x10))
		{
			OVER_FCT65(0, ___, 0);
			FCT68(x10, xc, 0, 0, 0);
		}

		// the following part puts an input character into x2c
		while (WARP_TRYREAD() == 0) // attempt reading until success
			SLEEP(25);
		struct MEM* x54 = WARP_DOREAD(); // get the character which has been read
		if (!*x54)
			continue;
		char x2c;
		if (x54->allocated & 0x7fffffff == 2) // type casting
			x2c = (x54->data[1] & 0xff)*256 + 255; // little endian (first byte=255)
		else
			x2c = x54->data[0] & 0xff;
		OVER_FREEMEM(x54); // release x54


		if (paramC)
		{
			if (param8 && x1c < x20)
				x88 = *(param8->x0 + x1c);
			else
				x99 = 32;

			x98 = x99;
			x98 = x98 & 0xf;
			x56 = x98;
			OVER_FCT65(0, &x56, 0);
			FCT68(x10, xc, 0, 0, 0);
		}

		switch (x2c)
		{
			case x2c == 8:
				if (x1c == 0)
					break;
				FCT73(&xc, &x10, -1, 0, x14, x18);
				x1c--;
				x4c = 1;
				break;
			case x2c == 9:
				x24 = ((x1c+8)/8*8) - x1c; // 8 byte alignment
				memset(&x48, 32, x24);
				x50 = 1;
				break;
			case x2c == 27:
				FCT73(&xc, &x10, ~x1c, 0, x14, x18);
				x1c = 0;
				x4c = x20;
				break;
			case x2c == 0x53ff: // 'S'
				if (x20 != x1c)
				{
					x4c = 1;
					break;
				}
				FCT41();
				break;
			case x2c == 0x4bff: // 'K'
				if (x1c == 0)
					break;
				FCT73(&xc, &x10, -1, 0, x14, x18);
				x1c++;
				break;
			case x2c == 0x4dff: // 'M'
				if (x1c == x20)
					break;
				FCT73(&xc, &x10, 1, 0, x14, x18);
				x1c++;
				break;
			case x2c == 0x47ff: // 'G'
				FCT73(&xc, &x10, ~x1c, 0, x14, x18);
				x1c = 0;
				break;
			case x2c == 0x4fff: // 'O'
				FCT73(&xc, &x10, x20 - x1c, 0, x14, x18);
				x1c = x20;
				break;
			case x2c == 0x48ff: // 'H'
				if (x1c > x14)
					break;
				FCT73(&xc, &x10, ~x14, 0, x14, x18);
				x1c -= x14;
				break;
			case x2c == 0x50ff: // 'P'
				if (x14 + x1c > x20)
					break;
				FCT73(&xc, &x10, x14, 0, x14, x18);
				x1c += x14;
				break;
			default:
				if (x2c <= 31)
					break;
				if (x2c > 255)
					break;
				// printable characters
				x48 = x2c;
				x24 = 1; // length
				x50 = 1; // boolean
		}

		if (x4c != 0 || x50 != 0)
			FCT68(0, 0, 0, 0, 0);

		if (x4c)
		{
			x60 = FCT74();
			x64 = FCT74();
			x68 = FCT74();
			x6c = FCT6(x64, x4c+x1c+1, x20-x1c-x4c);
			OVER_MEMMOVE(param8, -1, x68, -1, 0);
			APPEND(param8, -1, x6c, -1, 0);

			x20 -= x4c;
			WARP_PRINT(param8->x0+x1c, x20-x1c, 0);
			x5c = FCT76(x4c, ' ');
			WARP_PRINT(*x5c, x4c, 0);
			OVER_FREEMEM(x5c);
			FCT68(x10, xc, -1, 0, 0);
		}

		if (x50)
			*(&x48+x24) = '\0'; // byte

		if (x50)
		{
			x6c = xc;
			x68 = x10;

			struct MEM* x64 = FCT77(&x48, x24+1); // pack it back in a MEM structure

			x60 = FCT74(param8);
			x5c = FCT74(param8);
			x70 = FCT6(x60, 1, x1c);
			x74 = FCT6(x5c, x1c+1, x20-x1c);
			OVER_MEMMOVE(param8, -1, x70, -1, 0);

			APPEND(param8, -1, x64, -1, 0); // add it to param8

			APPEND(param8, -1, x74, -1, 0);
			x20 += *24;
			WARP_PRINT(*param8+x1c, x20-x1c, 0);
			FCT69(&xc, &x10);
			if (x20-x24 == x1c)
			{
				xc = x6c;
				x10 = x68;
				FCT73(&xc, &x10, x24, 0, x24, x18);
			}
			else
			{
				x78 = x6c;
				x7c = x68;
				FCT78(&x78, &x7c, x1c-x20, 0, x14, x18);
				if (x18+1 < x7c || (x18+1 == x7c && x78 > 1))
				{
					FCT73(&xc, &x10, x20-x1c-x24, 0, x14, x18);
				}
				else
				{
					xc = x6c;
					x10 = x68;
					FCT73(&xc, &x10, x24, 0, x24, x28);
				}
			}
			*x1c = *x24;
		}
		FCT(68, 0, 0, paramC == 0, 0, 0);
	}
	while (x2c != '\r' && x2c != '\n');

	FCT69(&xc, &x10);
	FCT73(&xc, &x10, x20-x1c, 0, x14, x18);
	FCT68(0, 0, x28, 0, 0);
}

<WARP_TRYREAD>
{
	return (VIRT_TRYREAD ? VIRT_TRYREAD : TRYREAD)();
}

char <TRYREAD>()
{
	if (NCURSES == 0)
		return feof(stdin) == 0;
	else
		return xc = ~READNEXT(0) >= 0;
}

// INPUTIDX and UNKIDX are mod 256
// if !eatIt, the character will be actually read later
char <READNEXT>(bool eatIt)
{
	x4 = NEXTCHAR();
	if (x4 >= 0)
	{
		INPUT[INPUTIDX++]_4 = x4;
		if (INPUTIDX == UNKIDX)
			UNKIDX++;
	}
	if (UNKIDX != INPUTIDX)
	{
		x4 = INPUT[UNKIDX]_4;
		if (param8)
			UNKIDX++;
	}
	return x4;
}

char <NEXTCHAR>()
{
	char x8 = (GETCFCT)(); // FGETC
	if (x8 == 127)
		return 8;

	if (x8 == '\n')
		return '\r';

	if (x8 != 27)
		return x8;

	x8 = (*GETCFCT)(); // FGETC
	if (x8 == -1)
		return 27;
	
	// never get until there

	if (*___ == 0)
		FCT82();
	x4 = *___;
	while (x4)
	{
		if (*x4 == x8)
		{
			if (*(x4+0x2))
			{
				if (*(x4+0x2) == 512)
				{
					xc = (*GETCFCT)(); // FGETC
					x10 = (*GETCFCT)(); // FGETC
					x14 = (*GETCFCT)(); // FGETC
					if (*___)
						(*___)(xc, x10, x14);

					return -1;
				}
				return *(x4+0x2);
			}
			x8 = (*GETCFCT)(); // FGETC
			if (x8 == -1)
				retrun -1;

			x4 = *(x4+0x8);
		}
		else
			x4 = *(x4+0x4);
	}
	while ((GETCFCT()) >= 0); // FGETC
	return -1;
}

char <FGETC>()
{
	return fgetc(IN);
}

void <SLEEP>(int time)
{
	x8 = ( (param8*0x10624dd3) >> 6) - (param8 >> 31); (high part)
	// more operations
	select(0, 0, 0, 0, &x8);
}

<WARP_DOREAD>
{
	return (VIRT_DOREAD ? VIRT_DOREAD : DOREAD)();
}

// "eats" an input character and returns it in a MEM struct
<DOREAD>
{
	if (NCURSES == 0)
		return DEFAULT;

	x8 = READNEXT(1);
	if (x8 >= 0)
	{
		if ((x8/8) % 2)
		{
			struct MEM* x4 = FCT19();
			x4 = OVER_FCT79(x4, 2);
			x4->data[0] = 255;
			x4->data[1] = x8;
			x4->data[2] = 0;
			return x4;
		}

		return PACKMEM(1, (int) x8);
	}
	return DEFAULT;
}

struct MEM* <OVER_FCT79>(struct MEM*, int count)
{
	return FCT79(param8, count);
}

// returns a MEM structure with count+1 allocated memory
struct MEM* <FCT79>(struct MEM*, int count)
{
	inArg = param8 == NULL;
	if (inArg && !(param8 = FCT19()))
		return NULL;

	if (FCT35(param8, count, 0) == 0)
	{
		if (inArg)
			FCT34(count);
		return NULL;
	}
	param8->x4 |= 0x80000000;
	return param8;
}

// packs an int array into a MEM struct (elements%256)
// the second argument is actually an array pushed on the stacked
struct MEM* <PACKMEM>(int count, int c)
{
	if (count <= 0)
		return DEFAULT;

	x8 = &paramC;
	struct MEM* x4 = OVER_FCT79(0, count);
	if (x4)
	{
		for (x10 = 0; x10 < count; x10++, x8+=4)
			x4->x0[x10] = *x8;
		x4->x0[count] = '\0';
		return x4;
	}

	return DEFAULT;
}

// length is the occupied memory (strlen+1)
struct MEM* <FCT77>(char* string, int length)
{
	struct MEM* x8 = FCT19();
	if (x8 == 0)
		return DEFAULT;

	x8->x0 = string;
	x8->x4 = length ? length-1 : param8 ? strlen(param8) : 0;
	x8->x8 = x8->x4;
	return x8;
}

// first and third parameters are also handled as strings
// lenX = -1 indicates that stringX is to be handled as a MEM structure
// (all calls to APPEND are with lenA = lenB = -1)
struct MEM* <APPEND>(struct MEM* stringA, int lenA, struct MEM* stringB, int lenB, ___)
{
	if (stringA == 0)
	{
		if (lenB == -1)
			OVER_FREEMEM(stringB);
		return stringA;
	}

	if (stringB == 0)
	{
		x8 = 0;
		xc = 0;
	}
	else
	{
		if (lenB == -1)
		{
			x8 = stringB->x0;
			xc = MAX_INT & stringB->x4;
		}
		else
		{
			x8 = stringB;
			xc = strlen(stringB);
		}
	}

	if (xc > 0)
	{
		if (lenA == -1)
		{
			x10 = MAX_INT & stringA->x4;
			FCT35(stringA, xc+x10, -1);
			CHKCPY(stringA->x0 + x10, x8, xc);
		}
		else
		{
			x10 = strlen(stringA);
			if (lenA > 0)
			{
				lenA--;
				if (lenA - x10 < xc)
					xc = lenA - x10;
			}

			CHCKCPY(stringA+x10, x8, xc);
			if (param18 && lenA > 0)
			{
				lenA -= xc + x10;
				if (lenA > 0)
					memset(stringA + x10 + xc, 0, lenA);
			}
		}
	}

	if (lenB == -1)
		OVER_FREEMEM(stringB);
	return stringA;
}
