// keygen for Rascal999's Rascal999's crackme serial challenge!
// http://www.crackmes.de/users/rascal999/rascal999s_crackme_serial_challenge/

// Compile with
// gcc -Wall -Wextra -Werror -pedantic -ansi -std=c99 -O3 keygen.c
// the only requisite flag is -std=c99

// The serial (16 byte long) is split in two halves. The first one is
// made of two blocks ; the sum of the bytes of each block is computed,
// giving two integers. A 8 byte string is generated using the integers
// as seeds, and checked against the second half of the serial.

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>

uint32_t RNDVECT[624];
int CURRNDIDX;

void SRAND(uint32_t seed)
{
	RNDVECT[0] = seed;
	for (int xc = 1; xc <= 623; xc++)
		RNDVECT[xc] = 0x19660d * RNDVECT[xc-1] + 0x3c6ef35f;
	CURRNDIDX = 624;
}

double RAND()
{
	if (CURRNDIDX >= 624)
	{
		for (int x4 = 0; x4 <= 623; x4++)
		{
			uint32_t x8 = (RNDVECT[x4] & 0x80000000) | (RNDVECT[(x4+1)%624] & 0x7fffffff);
			RNDVECT[x4] = (x8/2) ^ RNDVECT[(x4+397)%624] ^ (x8%2 ? 0x9908b0df : 0);
		}
		CURRNDIDX = 0;
	}
	uint32_t x8 = RNDVECT[CURRNDIDX++];
	x8 ^= x8 >> 11;
	x8 ^= (x8 <<  7) & 0x9d2c5680;
	x8 ^= (x8 << 15) & 0xefc60000;
	x8 ^= x8 >> 18;
	return (double) x8 / 4294967296;
}
int main(int argc, char** argv)
{
	if (argc < 2)
	{
		printf("Usage: %s firsthalf\nWhere firsthalf must be made of eight uppercase letters (A..Z)\n", argv[0]);
		exit(0);
	}

	char* c = argv[1];
	if (strlen(c) < 8)
	{
		printf("I need eight characters (exceeding will be ignored)\n");
		exit(0);
	}

	for (int i = 0; i < 8; i++)
		if (!('A' <= c[i] && c[i] <= 'Z'))
		{
			printf("I can only use characters from the range A..Z\n");
			exit(0);
		}
	c[8] = 0;

	int firstSum = 0;
	for (int i = 0; i < 4; i++)
		firstSum += c[i];
	
	int secondSum = 0;
	for (int i = 4; i < 8; i++)
		secondSum += c[i];

	char secondHalf[9];
	secondHalf[8] = 0;

	SRAND(firstSum);
	
	for (int i = 0; i < 8; i++)
		secondHalf[i] = RAND() * 26 + 1;

	SRAND(secondSum);
	for (int i = 0; i < 8; i++)
	{
		int tmp = RAND() * 26; 
		secondHalf[i] = 'A' + ((secondHalf[i]^tmp) % 26);
	}

	printf("%s%s\n", c, secondHalf);
	return 0;
}
