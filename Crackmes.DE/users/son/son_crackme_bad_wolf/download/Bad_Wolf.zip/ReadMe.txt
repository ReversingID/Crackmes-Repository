Hello and welcome to SoN CrackMe Bad Wolf. Before you start you must crack the password to the
included zip file. Your real crackme is in there. Because this step is here only to make sure you
know how to use a zip cracker I will give you three large hints. The correct password only uses lower
case English letters and it's 7 characters long. If you have a good dictionary file then the password
should be in there. It's a common word. It's always helpful to have a zip cracker I say! Further
instructions inside of the 'SoN CrackMe Bad Wolf.zip' archive.
                                                                  -SoN