SoN CrackMe Tube Alloys

Objective: Write a keygen for this crackme.

Rules: No patching the exe and you have to write a keygen and submit it to crackmes.de.


This is another crackme from the creative spurt of SoN. We have decided that we only tend to write
crackmes that we enjoy and this is no exception. It's fun so we hope that you have a good time while
cracking it. It was tested on XP SP2 and 2000 server but it should work on all Windows systems. If 
you have problems with it then send us a message on crackmes.de and let us know your system specs.
Good luck and have fun. Learn something while you're at it.


Slitheen	: And who are you, if not human? 
Harriet Jones	: Who's not human? 
Rose Tyler	: He's not human. 
The Doctor	: Can I have a bit of hush? 
Harriet Jones	: Sorry... But he's got a Northern accent! 
Rose Tyler	: Lots of planets have a North!
The Doctor	: I said hush! 