SoN - (Scared Of Normal)
-=-=-=-=-=-=-=-=-=-=-=-=
Packed CrackMe 1
Crack Me #2 Total
Difficulty LeveL: 1-10    (4.3)


Protection Schemes:

	1. Packed
	2. Un-packing protection
	3. Protection against some debuggers and decompilers
	4. Registration
	5. P-Code

Background:
	This started as a way for us to teach ourselves a bit more about assembly and unpacking packed
	programs. From there we modified it a little bit and decided to submit it. We hope you learn a
	bit from it. Come on boys and girls, crack it!

Rules:
	No patches please. You have to write a keygen for this. It's not that hard, I promise.


********************************************************************************************************

Scully: Death by hypovolaemia. 95% blood loss. That's over 4 liters of blood. 

Mulder: I'd say the man was running on empty. 

Scully: The man's daughter, 8 years old... was away from his side for no more than 10 minutes. 
	She doesn't remember anything, there was no trace evidence found at the crime scene. 

Mulder: Any evidence would have be washed away by yesterday's rain. 

Scully: Oh, there were two small puncture wounds. 

Mulder: Are you at all familiar with the phenomena of cattle mutilations? 

********************************************************************************************************