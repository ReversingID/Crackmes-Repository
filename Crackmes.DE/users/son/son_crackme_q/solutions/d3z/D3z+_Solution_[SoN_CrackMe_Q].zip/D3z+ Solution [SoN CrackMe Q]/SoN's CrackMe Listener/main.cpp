// ------------------------------------------------------
// Solution to [SoN CrackMe Q]
// Author: D3z+
// Date: 20/05/07
// ------------------------------------------------------

#include <stdio.h>
#include <winsock2.h>

// Some strings used in the listener
char HTTP_Header [] = "HTTP/1.1 200 OK\r\nDate Fri, 21 Apr 20 06 02:00:50 GMT\r\nContent-Length: 5\r\nContent-Type: text/html\r\n\r\n";

// 01052000   90               NOP
// 01052001   57               PUSH EDI
// 01052002   FFD2             CALL EDX
// 01052004   C3               RETN
char bad_boy[] = {0x90,0x57,0xff,0xD2,0xC3};

// 01052000   90               NOP
// 01052001   57               PUSH EDI
// 01052002   FFD0             CALL EAX
// 01052004   C3               RETN
char good_boy[] = {0x90,0x57,0xff,0xD0,0xC3};

// The Listener Code
int main()
{
  SOCKET server;
  sockaddr_in local;
  WSADATA WSData;
  WORD wVersionRequested = MAKEWORD( 2, 2 );
  UINT uPort=502;


  if (WSAStartup( wVersionRequested, &WSData )) 
    return false;

  //Now we populate the sockaddr_in structure
  local.sin_family=AF_INET; //Address family
  local.sin_addr.s_addr=INADDR_ANY; //Wild card IP address
  local.sin_port=htons((u_short)uPort); //port to use

  //the socket function creates our SOCKET
  server=socket(AF_INET,SOCK_STREAM,0);

  //If the socket() function fails we exit
  if(server==INVALID_SOCKET)
  {
    return 0;
  }

  if(bind(server,(sockaddr*)&local,sizeof(local))!=0)
  {
    return 0;
  }

  if(listen(server,10)!=0)
  {
    return 0;
  }

  printf("Listening on port: %u\r\n", uPort );

  //we will need variables to hold the client socket.
  //thus we declare them here.
  SOCKET client;
  sockaddr_in from;
  int fromlen=sizeof(from);

  while(true)//we are looping endlessly
  {
    char temp[512];

    //accept() will accept an incoming
    //client connection
    client=accept(server,
      (struct sockaddr*)&from,&fromlen);

    printf( "--> Connection from: %s\r\n", inet_ntoa(from.sin_addr) );

    // Receive Get
    memset(temp,0,512);
    recv(client,temp,512,0);
    printf("--> Received from %s:\r\n\r\n%s\r\n",inet_ntoa(from.sin_addr),temp);

    // Send Answer
    send(client,HTTP_Header,strlen(HTTP_Header),0);
    printf("--> Sending:\r\n\r\n%s\r\n",temp);
    send(client,good_boy,5,0);
    printf("--> Sending:\r\n\r\n%s\r\n",good_boy);

    //close the client socket
    closesocket(client);

  }

  //closesocket() closes the socket and releases the socket descriptor
  closesocket(server);

  // Cleanup WSock2
  WSACleanup();
}
