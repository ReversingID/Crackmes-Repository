jE!_CRC_DRx.idb - fully commented IDA listing
reverse_dws.cpp - demo's how to undo crackme's mix operations
jeadd.cpp - demo's how to get the right value from CRCThread
exception_sequence - explains crackme SEH exception flow
KEY - key file
solution.txt - tutorial
notes.txt - some notes used, useful breakpoint locations

remember, to test out KEY it must be readonly, hidden, system, and archive

attrib +r +h +s +a KEY

