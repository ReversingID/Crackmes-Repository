///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	HEADERS & LIBRARYS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#define 			WIN32_LEAN_&_MEAN
#include 		<stdio.h>
#include 		<stdlib.h>
#include 		<math.h>
#include 		<time.h>
#include 		<windows.h>
#include 		<commctrl.h>
#include 		<commdlg.h>
#include			<windowsx.h>
#include 		<wincrypt.h>
#include			<objbase.h>


#include "Keygen.h"

#define MUSIC

#ifdef MUSIC	
	#include <ufmod.h>
	#include "Tune.h"
	#pragma comment (lib,"Winmm.lib")
	#pragma comment (lib,"ufmod.lib")
#endif


#include "miracl.h"
#pragma comment (lib,"miracl.lib")

//#define VCRT
#ifdef VCRT
	#pragma comment (lib,"libcmt.lib")
#else
	#pragma comment (lib,"wcrt.lib")
#endif

#pragma comment(linker, "/NODEFAULTLIB")



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	DEFINITIONS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#define BP __asm{db 0xcc}
#pragma warn(disable: 2145)


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	FUNCTION PROTOTYPES
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int CALLBACK WinMain(HINSTANCE hInst,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nCmdShow);
INT_PTR CALLBACK MainDialogProc(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam);
void CreateKey(HWND hWnd);
DWORD Checksum(char* pData,int len);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	GLOBAL VARIABLES
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
HINSTANCE hInstance;
HICON hIcon;
DWORD _iob;
LPSTR lpszProtection = 		"[ VESA's Simple KGM 2 - Keygen ]\n\n"
							"Protection:\n"
							"--------------------------------------------------\n\n"
							"Custom 32 bit checksum\n"
							"RSA 64 Bits\n"
							"\n--------------------------------------------------\n";



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	CODE
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


int CALLBACK WinMain(HINSTANCE hInst,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nCmdShow)
{
	hInstance = hInst;
	DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_MAIN),NULL,MainDialogProc,0);
	ExitProcess(0);
	return FALSE;
}

INT_PTR CALLBACK MainDialogProc(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	char szUserName[200] 		= "";
	MSGBOXPARAMS mbp  		={0};
	DWORD nSize 				= sizeof(szUserName);

	switch(uMsg)
	{
		case WM_INITDIALOG:
		{
			#ifdef MUSIC
			uFMOD_PlaySong(Tune,hInstance,XM_MEMORY);
			#endif
			hIcon = LoadIcon(hInstance,MAKEINTRESOURCE(ID_ICON_MAIN));
			SendMessage(hWnd,WM_SETICON,0,(LPARAM)hIcon);
			GetUserName(szUserName,&nSize);
			SetDlgItemText(hWnd,IDC_EDIT_NAME,szUserName);
			//CreateKey(hWnd);
			break;
		}

		case WM_CLOSE:
		{
			EndDialog(hWnd,0);
			break;
		}

		case WM_COMMAND:
		{
			switch(LOWORD(wParam))
			{
				case IDC_BUTTON_GENERATE:
				{
					CreateKey(hWnd);
					break;
				}

				case IDC_EDIT_NAME:
				{
					if (HIWORD(wParam) == EN_CHANGE)
						CreateKey(hWnd);

					break;
				}
				case IDC_BUTTON_ABOUT:
				{

					mbp.cbSize = sizeof(MSGBOXPARAMS);
					mbp.hwndOwner = hWnd;
					mbp.hInstance = hInstance;
					mbp.lpszText = lpszProtection;
					mbp.lpszCaption = "[ About ]";
					mbp.lpszIcon = MAKEINTRESOURCE(ID_ICON_MAIN);
					mbp.dwStyle = MB_USERICON;
					MessageBoxIndirect(&mbp);
					break;
				}
			
			}
			break;
		}
	
	}

	return FALSE;
}

void CreateKey(HWND hWnd)
{

	big m,n,d,c;
	miracl * mip;
	DWORD dwChecksum;
	int lenName;
	char szName[256] = "";
	char szSerial[256] = "";
	char szChecksum[16] = "";
	

	mip 	= mirsys(5000,16);
	m 		= mirvar(0);
	n 		= mirvar(0);
	d 		= mirvar(0);
	c 		= mirvar(0);

	mip->IOBASE 	= 16;

	cinstr(n,"F1CB476270EA27E9");
	cinstr(d,"BD8B5C2DD240213D");
	

	
	lenName = GetDlgItemText(hWnd,IDC_EDIT_NAME,szName,sizeof(szName));
	if ( (lenName < 4) || (lenName > 32) ) 
	{
		SetDlgItemText(hWnd,IDC_EDIT_ID,"Name must be between");
		SetDlgItemText(hWnd,IDC_EDIT_SERIAL,"4 and 32 chars in length . . .");
		goto Exit;
	}

	dwChecksum = Checksum(szName,lenName) ;

	sprintf(szChecksum,"%.08X",dwChecksum);

	cinstr(m,szChecksum);
	powmod(m,d,n,c);

	cotstr(c,szSerial);

	
	sprintf(szChecksum,"%.u",dwChecksum + 0xD4);

	SetDlgItemText(hWnd,IDC_EDIT_ID,szChecksum);
	SetDlgItemText(hWnd,IDC_EDIT_SERIAL,szSerial);

Exit:
	mirkill(m);
	mirkill(n);
	mirkill(d);
	mirkill(c);
	mirexit();	


	return;
}
