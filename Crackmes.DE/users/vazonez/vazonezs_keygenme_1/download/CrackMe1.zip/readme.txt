It`s my first crackme.
It`s very easy.
It`s for newbies.
It`s on MASM



VaZoNeZ '08
www.vazonez.at.ua
vazonez@mail.ru

UKRAINE RULEZ !!!