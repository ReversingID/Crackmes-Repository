/**
 * Keygen for VaZoNeZ Keygenme
 * Author: mjones
 * Date: July 24, 2008
 *
 * Keygen creates a serial for the app, then 
 * outputs the serial to the screen as well as
 * writing it to the file vazonez-key.txt
 */

#include <windows.h>
#include <fstream.h>
#include <iostream.h>

#define UNLENU 257 /* UNLEN in lmcons.h */
#define AUTHORKEYLEN 17
#define AUTHORKEY "VaZoNeZVaZoNeZ"
#define KEYFILE "vazonez-key.txt"
#define CL 0xa4 /* constant from the crackme */

int main()
{
	ofstream k_file;
	char username[UNLENU] = {0};
	char author_key[AUTHORKEYLEN] = AUTHORKEY;
	unsigned long username_len = sizeof(username);
	BYTE dl = 0x00;	
	
	if (GetUserName(username, &username_len)) {		
		for (int i = 0; i < 14; i++) {
			dl = (BYTE) author_key[i];						/* MOVZX EDX,BYTE PTR DS:[ECX] */							
			dl += (BYTE) username[0];						/* ADD DL, AL */
			dl ^= 5;										/* XOR DL, 5 */
			dl += (CL + i);									/* ADD DL, CL */
			dl -= 0x1e;										/* SUB DL, 1E */
			author_key[i] = (char) dl;						/* MOV BYTE PTR DS:[ECX],DL */
		}
		
		k_file.open(KEYFILE);
		k_file << author_key;
		k_file.close();
		
		cout << "Serial: " << author_key << endl;
		cout << "This serial is stored in " << KEYFILE << endl;
	}
	
	cin.get();
	
	return 0;
}
