So... after several months of intense procrastination I finally present to you CryxeNet 0.02b. I've learned a lot since
last time, and can proudly say that this protector is now somewhat of a challenge :D So, I would appreciate if you
unpack it, and write a tutorial. If you can't write a tutorial (no time), at least post a suggestion so that I may
improve my protection.Everything goes, just like in real life. And while you guys are at it, I'll be improving it for
Cryxenet 0.03... 8-D

PS PLEASE REPORT ANY COMPATIBILITY ISSUES!!!! State OS and .NET framework ver pls. Has been tested on Winxp SP1 and Winxp SP2.





Known issues:

-Crashes on Windows Vista when (DEP?) is enabled. I'm debating on even bothering to fix that =/
-Random AV warnings on lesser known AV's =/

-rendari