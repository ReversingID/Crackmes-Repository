This is a little .NET protector that I coded yesterday when I was bored. Look in todo.txt for further information
on its current features and features I plan to add.

The goal of this exercise is to unpack the protected keygenme and patch/keygen (whatever you prefer) it to display
the good boy message for any serial entered. No rules, anything flies, as long as you get the job done.

My only rquirement is that you write a tutorial when you finish and include some suggestions for the next version
of the protector!

-TFB 