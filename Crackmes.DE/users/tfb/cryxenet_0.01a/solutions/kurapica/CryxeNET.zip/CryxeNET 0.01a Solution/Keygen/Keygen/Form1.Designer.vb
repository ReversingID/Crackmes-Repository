<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Text_name = New System.Windows.Forms.TextBox
        Me.Text_ID = New System.Windows.Forms.TextBox
        Me.Text_Serial = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.CMD_Gen = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'Text_name
        '
        Me.Text_name.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Text_name.Location = New System.Drawing.Point(105, 14)
        Me.Text_name.Name = "Text_name"
        Me.Text_name.Size = New System.Drawing.Size(439, 21)
        Me.Text_name.TabIndex = 0
        Me.Text_name.Text = "Kurapica"
        '
        'Text_ID
        '
        Me.Text_ID.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Text_ID.Location = New System.Drawing.Point(105, 44)
        Me.Text_ID.Name = "Text_ID"
        Me.Text_ID.Size = New System.Drawing.Size(439, 21)
        Me.Text_ID.TabIndex = 0
        Me.Text_ID.Text = "1000"
        '
        'Text_Serial
        '
        Me.Text_Serial.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Text_Serial.Location = New System.Drawing.Point(105, 74)
        Me.Text_Serial.Name = "Text_Serial"
        Me.Text_Serial.Size = New System.Drawing.Size(440, 21)
        Me.Text_Serial.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(63, 17)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(35, 15)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(14, 47)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(84, 15)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Customer ID"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(49, 77)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(49, 15)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Serial"
        '
        'CMD_Gen
        '
        Me.CMD_Gen.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CMD_Gen.Location = New System.Drawing.Point(471, 107)
        Me.CMD_Gen.Name = "CMD_Gen"
        Me.CMD_Gen.Size = New System.Drawing.Size(75, 23)
        Me.CMD_Gen.TabIndex = 2
        Me.CMD_Gen.Text = "Generate"
        Me.CMD_Gen.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(556, 142)
        Me.Controls.Add(Me.CMD_Gen)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Text_Serial)
        Me.Controls.Add(Me.Text_ID)
        Me.Controls.Add(Me.Text_name)
        Me.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Unpackme Keygen by Kurapica"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Text_name As System.Windows.Forms.TextBox
    Friend WithEvents Text_ID As System.Windows.Forms.TextBox
    Friend WithEvents Text_Serial As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents CMD_Gen As System.Windows.Forms.Button

End Class
