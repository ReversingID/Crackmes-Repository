Imports System.Security.Cryptography
Imports System.IO
Imports System.Text

Public Class Form1

#Region "Decrypt Serial Using ID as a key to get the name"

    'The Keygen Me uses the Customer ID as a decryption key and then
    'Decrypts the Serial and the Result must be the name !

    Public Function GetName(ByVal Serial As String, ByVal ID As String) As String

        'Initialization vector
        Dim rgbIV As Byte() = New Byte() {121, 241, 10, 1, 132, 74, 11, 39, 255, 91, 45, 78, 14, 211, 22, 62}
        Dim managed As New RijndaelManaged

        'Serial is in Base64 form string, convert it to an array of bytes
        'Holds data to decrypt
        Dim buffer As Byte() = Convert.FromBase64String(Serial)


        'Prepare ID, must be at least 32 chars
        If (Strings.Len(ID) >= 32) Then
            ID = Strings.Left(ID, 32)
        Else
            Dim num3 As Integer = Strings.Len(ID)
            Dim number As Integer = (32 - num3)
            ID = (ID & Strings.StrDup(number, "X"))
        End If
        'Decryption key
        Dim bytes As Byte() = Encoding.ASCII.GetBytes(ID.ToCharArray)


        'Empty array to hold decrypted data
        Dim buffer4 As Byte() = New Byte((buffer.Length + 1) - 1) {}

        'Copy encrypted data to stream
        Dim stream2 As New MemoryStream(buffer)

        Try

            Dim stream As New CryptoStream(stream2, managed.CreateDecryptor(bytes, rgbIV), CryptoStreamMode.Read)
            stream.Read(buffer4, 0, buffer4.Length)
            stream.FlushFinalBlock()
            stream2.Close()
            stream.Close()

        Catch exception1 As Exception

        End Try

        Return Me.StripNullCharacters(Encoding.ASCII.GetString(buffer4))

    End Function

    Public Function StripNullCharacters(ByVal vstrStringWithNulls As String) As String

        Dim start As Integer = 1
        Dim str As String = vstrStringWithNulls
        Do While (start > 0)
            start = Strings.InStr(start, vstrStringWithNulls, ChrW(0), CompareMethod.Binary)
            If (start > 0) Then
                str = (Strings.Left(str, (start - 1)) & Strings.Right(str, (Strings.Len(str) - start)))
            End If
            If (start > str.Length) Then
                Return str
            End If
        Loop
        Return str

    End Function

#End Region

    'Generate serial
    Public Function GetSerial(ByVal Name As String, ByVal ID As String) As String

        'The Keygen me uses a symmetric Algorithm to encrypt and decrypt, so the key
        'for encryption and decryption is the same.
        '
        ' IF you Decrypt the Serial using the ID as a Key you will get the name
        ' So If you Encrypt the Name using the ID you will get the serial
        '
        '  NAME  <=====> ID <=====> Serial 
        '          ENC       DEC

        '-------------------------------------------------------------------------------

        '[1]
        'The Asymmetric Algorithm used for encryption
        Dim Enc As New Security.Cryptography.RijndaelManaged
        'Defines the basic operations of cryptographic transformations
        Dim EncOB As Security.Cryptography.ICryptoTransform
        'The Stream to which encrypted data will be written to
        Dim EncData As New IO.MemoryStream

        '[2]
        'Prepare ID which is the encryption key too, must be at least 32 chars.
        'In symmetric algos, same key is used for encryption and decryption
        'The if block fill the string with X char to fill the 32 spaces
        If ((ID.Length) >= 32) Then
            ID = Strings.Left(ID, 32)
        Else
            Dim num3 As Integer = Strings.Len(ID)
            Dim number As Integer = (32 - num3)
            ID = (ID & Strings.StrDup(number, "X"))
        End If
        'Convert the ID to an array of 32 bytes
        Dim bytes As Byte() = Encoding.ASCII.GetBytes(ID.ToCharArray)
        'Set the Encryptor Key and Initialization Vector
        Enc.Key = bytes
        Enc.IV = New Byte() {121, 241, 10, 1, 132, 74, 11, 39, 255, 91, 45, 78, 14, 211, 22, 62}



        'Encryption Objects
        EncOB = Enc.CreateEncryptor(Enc.Key, Enc.IV)
        'This class is not actually a stream but it will encrypt data and
        'write it to ENcData stream

        'This will link the Encryptor with the memory stream >>
        Dim EnST As New Security.Cryptography.CryptoStream(EncData, EncOB, Security.Cryptography.CryptoStreamMode.Write)

        'When we want to encrypt data we must call the EnST "Write" method
        'and it will write the encrypted data to the mempry stream object
        'First : Convert data we want to encrypt to bytes array
        Dim Data() As Byte = System.Text.Encoding.ASCII.GetBytes(Name)


        'Encrypt data
        EnST.Write(Data, 0, Data.Length)
        EnST.FlushFinalBlock()
        'Now the data is encrypted and written in the MemStream object "ENcData"

        'The Serial is in Base64 string form so we must convert final encrypted data to base64 string
        Enc.Clear()
        EnST.Close()
        EncData.Close()
        Erase Data

        Return Convert.ToBase64String(EncData.ToArray)

    End Function

    'Get the serial for the textboxes
    Private Sub CMD_Gen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CMD_Gen.Click

        Try


            Text_Serial.Text = GetSerial(Text_name.Text, Text_ID.Text)

            MsgBox("If you decrypt the serial you will get this name: " & vbNewLine & vbNewLine & GetName(Text_Serial.Text, Text_ID.Text), MsgBoxStyle.Information)

        Catch ex As Exception

            MsgBox(ex.Message, MsgBoxStyle.Critical)

        End Try

    End Sub

    'Initial serial
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Text_Serial.Text = GetSerial(Text_name.Text, Text_ID.Text)

    End Sub

    'Greetings fly to 

    ' UFO-Pu55y
    ' RET
    ' SnD


    '16-12-2007
    'Kurapica 
    'www.reteam.org\board

End Class
