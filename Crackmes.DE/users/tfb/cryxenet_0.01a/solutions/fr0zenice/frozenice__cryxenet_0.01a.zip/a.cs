using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Security.Cryptography;
using Microsoft.VisualBasic;
using System.IO;
using Microsoft.VisualBasic.CompilerServices;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Reflection;
using System.Globalization;

namespace IL2CS
{
    public partial class aForm : Form
    {
        public aForm()
        {
            InitializeComponent();
            this.d = new byte[0x927c1];
            this.e = new byte[0x927c1];
            this.f = new byte[0x927c1];
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(this.a("kom/Wb1qG5J5yRbp+B54JwzltwjWSOeCJZF0EKYHe5lNTUgUJzy8JQkHkl/OaQpVDwC/vMPmj0f1b0YXPAtOsw==", "1357924680"));
            this.b(this, e);
        }

        private string a(string A_0, string A_1)
        {
            byte[] rgbIV = new byte[] { 0x79, 0xf1, 10, 1, 0x84, 0x4a, 11, 0x27, 0xff, 0x5b, 0x2d, 0x4e, 14, 0xd3, 0x16, 0x3e };
            RijndaelManaged managed = new RijndaelManaged();
            byte[] buffer = Convert.FromBase64String(A_0);
            if (Strings.Len(A_1) >= 0x20)
            {
                A_1 = Strings.Left(A_1, 0x20);
            }
            else
            {
                int num3 = Strings.Len(A_1);
                int number = 0x20 - num3;
                A_1 = A_1 + Strings.StrDup(number, "X");
            }
            byte[] bytes = Encoding.ASCII.GetBytes(A_1.ToCharArray());
            byte[] buffer4 = new byte[buffer.Length + 1];
            MemoryStream stream2 = new MemoryStream(buffer);
            try
            {
                CryptoStream stream = new CryptoStream(stream2, managed.CreateDecryptor(bytes, rgbIV), CryptoStreamMode.Read);
                stream.Read(buffer4, 0, buffer4.Length);
                stream.FlushFinalBlock();
                stream2.Close();
                stream.Close();
            }
            catch (Exception exception1)
            {
                ProjectData.SetProjectError(exception1);
                ProjectData.ClearProjectError();
            }
            return this.a(Encoding.ASCII.GetString(buffer4));
        }

        public string a(string A_0)
        {
            int start = 1;
            string str = A_0;
            while (start > 0)
            {
                start = Strings.InStr(start, A_0, "\0", CompareMethod.Binary);
                if (start > 0)
                {
                    str = Strings.Left(str, start - 1) + Strings.Right(str, Strings.Len(str) - start);
                }
                if (start > str.Length)
                {
                    return str;
                }
            }
            return str;
        }

        [DllImport("kernel32", CharSet = CharSet.Ansi, SetLastError = true, ExactSpelling = true)]
        public static extern int IsDebuggerPresent();

        public byte[] d;
        public byte[] e;
        public byte[] f;

        public void c()
        {
            //Assembly.Load(this.d).EntryPoint.Invoke(null, null);
            File.WriteAllBytes("decrypted_assembly.exe", this.d);
        }

        public void b(object _A_0, EventArgs A_1)
        { // since A_0 is the sender, it's the Form!
            aForm A_0 = _A_0 as aForm;
            object V_0;
            int V_1;
            int V_2;
            int V_3;
            int V_4;
            System.IO.FileStream V_5;
            //System.IO.FileMode V_6;
            int V_7;
            int V_8;
            int V_9;
            int V_10;
            int V_11;
            int V_12;
            int V_13;
            int V_14;
            int V_15;
            object V_16;
            System.Threading.Thread V_17;
            int V_18;
            string V_19;
            int V_20;
            int V_21;

            V_0 = 600000;
            V_1 = 0;
            V_20 = 0;
            V_16 = RuntimeHelpers.GetObjectValue(new Object());
            V_7 = 4;
            V_11 = 5;
            goto IL_002A;
        //skips 3 instructions:
        // IL_0025 ldloc.s 11
        // IL_0027 add.ovf
        // IL_0028 stloc.s 7
        IL_002A:
            V_11 = V_7 * V_11;
            V_19 = "08w357djf30dfh+//dgjd=a";
            V_12 = 99;
            V_2 = aForm.IsDebuggerPresent() + V_12;
            if (V_2 != 99)
            {
                // IL_0050
                // we found a debugger! bail out
                MessageBox.Show(A_0.a("kom/Wb1qG5J5yRbp+B54JwzltwjWSOeCJZF0EKYHe5lNTUgUJzy8JQkHkl/OaQpVDwC/vMPmj0f1b0YXPAtOsw==", "1357924680"));
                // IL_07F9
                return;
            }

            // IL_004A
            V_12 = 99;
            V_13 = 89;
            V_14 = V_12 * V_13;
            if (V_12 > V_14)
            { // what?
                V_12 = 1171 + V_13;
            }
            V_15 = V_14 - V_12;
            V_12 = 138 + V_13;
            V_15 = V_12 + V_13;
            V_18 = V_12 + V_13;
            V_18 = V_13 - 99;
            V_21 = 37;
            V_19 = V_21.ToString("x");
            V_12 = 99;
            V_13 = 89;
            V_14 = V_12 * V_13;
            if (V_12 <= V_14)
            {
                V_12 = 1171 + V_13;
            }
            V_15 = V_14 - V_12;
            V_12 = 138 + V_13;
            V_15 = V_12 + V_13;
            V_4 = Int32.Parse(V_19, NumberStyles.HexNumber); // 515d = 203h, look up NumberStyles, you'll find a table ;)
            V_12 = 99;
            V_13 = 89;
            V_14 = V_12 * V_13;
            if (V_12 > V_14)
            {
                V_12 = 1171 + V_13;
            }
            V_15 = V_14 - V_12;
            V_12 = 138 + V_13;
            V_15 = V_12 + V_13;

            //interesting cryxed.dll stuff starts here!
            V_5 = new FileStream("cryxed.dll", FileMode.Open, FileAccess.Read, FileShare.Read, IntegerType.FromObject(V_0));
            goto IL_01AC;

            // reads the assembly into A_0.d (byte[])
        IL_01AC:
            if (V_5.Length > V_20)
            {
                V_1 = V_5.Read(A_0.d, V_20, IntegerType.FromObject(V_0)); // offset = V_20, buffer = 600000
                V_12 = 99;
                V_13 = 89;
                V_14 = V_12 * V_13;
                if (V_12 > V_14)
                {
                    V_12 = 1171 + V_13;
                }
                V_15 = V_14 - V_12;
                V_12 = 138 + V_13;
                V_15 = V_12 + V_13;
                V_20 = V_20 + V_1;
                goto IL_01AC;
            }

            // IL_01B8
            V_5.Close();
            V_3 = 0;

            // loops over the assembly and does cryptic stuff
        IL_03B3:
            if (V_3 < V_20)
            {
                V_18 = A_0.d[V_3] - 1;
                V_7 = 4;
                V_11 = 5;
                V_12 = 99;
                V_13 = 89;
                V_14 = V_12 * V_13;
                if (V_12 <= V_14)
                {
                    V_12 = 1171 + V_13;
                }
                V_15 = V_14 - V_12;
                V_12 = 138 + V_13;
                V_15 = V_12 + V_13;
                V_18 = V_18 ^ V_4; // xor, sweet
                V_7 = V_7 + V_11;
                V_11 = V_7 * V_11;
                if (V_18 > 255)
                {
                    V_7 = 128;
                    V_11 = V_7 * 2;
                    V_18 = V_18 - V_11;
                }
                if (V_18 >= 0)
                {
                    V_11 = 128;
                    V_7 = V_11 * 2;
                    V_12 = 99;
                    V_13 = 89;
                    V_14 = V_12 * V_13;
                    if (V_12 <= V_14)
                    {
                        V_12 = 1171 + V_13;
                    }
                    V_15 = V_14 - V_12;
                    V_12 = 138 + V_13;
                    V_15 = V_12 + V_13;
                    V_18 = V_18 + V_7;
                }
                // IL_0296
                A_0.e[V_3] = (byte)(V_18 + A_0.f[V_3]); // a bit complex in IL code, but you'll figure out :)
                V_12 = 99;
                V_13 = 89;
                V_14 = V_12 * V_13;
                if (V_12 > V_14)
                {
                    V_12 = 1171 + V_13;
                }
                V_15 = V_14 - V_12;
                V_12 = 138 + V_13;
                V_15 = V_12 + V_13;
                A_0.d[V_3] = A_0.f[V_3];
                V_12 = 99;
                V_13 = 89;
                V_14 = V_12 * V_13;
                if (V_12 > V_14)
                {
                    V_12 = 1171 + V_13;
                }
                V_15 = V_14 - V_12;
                V_12 = 138 + V_13;
                V_15 = V_12 + V_13;
                A_0.d[V_3] = (byte)(A_0.e[V_3] - A_0.d[V_3]); // again, a bit complex, just do it one by one
                A_0.e[V_3] = 98;
                A_0.f[V_3] = 55;
                V_12 = 99;
                V_13 = 89;
                V_14 = V_12 * V_13;
                V_14 = 89;
                A_0.e[V_3] = (byte)(V_14);
                if (V_12 <= V_14)
                {
                    V_12 = 1171 + V_13;
                }
                V_15 = V_14 + V_12;
                V_12 = 138 + V_13;
                V_15 = 88;
                A_0.f[V_3] = (byte)(V_15);
                V_15 = V_12 + V_13;
                V_3 = V_3 + 1;
                goto IL_03B3;
            }

            // IL_03BB
            A_0.Close();
            V_12 = 99;
            V_13 = 89;
            V_14 = V_12 * V_13;
            if (V_12 <= V_14)
            {
                V_12 = 1171 + V_13;
            }
            V_15 = V_14 - V_12;
            V_12 = 138 + V_13;
            V_15 = V_12 + V_13;
            // watch out! the following instruction is missing from the graph
            // IL_03fc ldvirtftn instance void class a::c()
            V_17 = new Thread(new ThreadStart(A_0.c));
            V_12 = 99;
            V_13 = 89;
            V_14 = V_12 * V_13;
            if (V_12 <= V_14)
            {
                V_12 = 1171 + V_13;
            }
            V_15 = V_14 - V_12;
            V_12 = 138 + V_13;
            V_15 = V_12 + V_13;
            V_12 = 99;
            V_13 = 89;
            V_14 = V_12 * V_13;
            if (V_12 > V_14)
            {
                V_12 = 1171 + V_13;
            }
            V_15 = V_14 - V_12;
            V_12 = 138 + V_13;
            V_15 = V_12 + V_13;
            V_17.Start();
            V_12 = 99;
            V_13 = 89;
            V_14 = V_12 * V_13;
            if (V_12 <= V_14)
            {
                V_12 = 1171 + V_13;
            }
            V_15 = V_14 - V_12;
            V_12 = 138 + V_13;
            V_15 = V_12 + V_13;
            V_12 = V_13;
            V_3 = V_12 - V_13;
            Thread.Sleep(1000);
            V_8 = V_3;
            V_9 = A_0.d[4];
            V_10 = A_0.d[1] + 968;
            V_8 = V_9 - V_10;
            V_9 = V_9 * 2;
            V_10 = V_9 + V_8;
            V_12 = 99;
            V_13 = 89;
            V_14 = V_12 * V_13;
            if (V_12 <= V_14)
            {
                V_12 = 1171 + V_13;
            }
            V_15 = V_14 - V_12;
            V_12 = 138 + V_13;
            V_15 = V_12 + V_13;
            V_12 = 99;
            V_13 = 89;
            V_14 = V_12 * V_13;
            if (V_12 <= V_14)
            {
                V_12 = 1171 + V_13;
            }
            V_3 = 0;
            V_15 = V_14 - V_12;
            V_12 = 138 + V_13;
            V_15 = V_12 + V_13;

        IL_06F5:
            if (V_3 < V_20)
            {
                V_8 = V_3;
                V_9 = A_0.d[4];
                V_10 = A_0.d[1] + 968;
                V_8 = V_9 - V_10;
                V_9 = V_9 * 2;
                V_10 = V_9 + V_8;
                V_12 = 99;
                V_13 = 89;
                V_14 = V_12 * V_13;
                if (V_12 > V_14)
                {
                    V_12 = 1171 + V_13;
                }
                V_15 = V_14 - V_12;
                V_12 = 138 + V_13;
                V_15 = V_12 + V_13;
                V_8 = V_3;
                V_9 = A_0.d[4];
                V_10 = A_0.d[1] + 968;
                V_8 = V_9 - V_10;
                V_9 = V_9 * 2;
                V_10 = V_9 + V_8;
                V_8 = V_3;
                V_9 = A_0.d[4];
                V_10 = A_0.d[1] + 968;
                V_8 = V_9 - V_10;
                V_9 = V_9 * 2;
                V_10 = V_9 + V_8;
                V_8 = V_3;
                V_9 = A_0.d[4];
                V_10 = A_0.d[1] + 968;
                V_8 = V_9 - V_10;
                V_9 = V_9 * 2;
                V_10 = V_9 + V_8;
                return;
            }
            else
            {
                V_8 = V_3;
                V_9 = A_0.d[4];
                V_10 = A_0.d[1] + 968;
                V_8 = V_9 - V_10;
                V_9 = V_9 * 2;
                V_10 = V_9 + V_8;
                V_12 = 00;
                V_13 = 89;
                V_14 = V_12 * V_13;
                if (V_12 <= V_14)
                {
                    V_12 = 1171 + V_13;
                }
                V_15 = V_14 - V_12;
                V_12 = 138 + V_13;
                V_15 = V_12 + V_13;
                A_0.d[V_3] = 0;
                V_12 = 99;
                V_13 = 89;
                V_14 = V_12 * V_13;
                if (V_12 > V_14)
                {
                    V_12 = 1171 + V_13;
                }
                V_15 = V_14 - V_12;
                V_12 = 138 + V_13;
                V_15 = V_12 + V_13;
                V_8 = V_3;
                V_9 = A_0.d[4];
                V_10 = A_0.d[1] + 968;
                V_8 = V_9 - V_10;
                V_9 = V_9 * 2;
                V_10 = V_9 + V_8;
                V_8 = V_3;
                V_9 = A_0.d[4];
                V_10 = A_0.d[1] + 968;
                V_8 = V_9 - V_10;
                V_9 = V_9 * 2;
                V_10 = V_9 + V_8;
                V_3 = V_3 + 1;
                V_12 = 99;
                V_13 = 89;
                V_14 = V_12 * V_13;
                if (V_12 > V_14)
                {
                    V_12 = 1171 + V_13;
                }
                V_15 = V_14 - V_12;
                V_12 = 138 + V_13;
                V_15 = V_12 + V_13;
                V_8 = V_3;
                V_9 = A_0.d[4];
                V_10 = A_0.d[1] + 968;
                V_8 = V_9 - V_10;
                V_9 = V_9 * 2;
                V_10 = V_9 + V_8;
                goto IL_06F5;
            }
        }

        public string DecryptString128Bit(string vstrStringToBeDecrypted, string vstrDecryptionKey)
        {
            byte[] rgbIV = new byte[] { 0x79, 0xf1, 10, 1, 0x84, 0x4a, 11, 0x27, 0xff, 0x5b, 0x2d, 0x4e, 14, 0xd3, 0x16, 0x3e };
            RijndaelManaged managed = new RijndaelManaged();
            byte[] buffer = Convert.FromBase64String(vstrStringToBeDecrypted);
            if (Strings.Len(vstrDecryptionKey) >= 0x20)
            {
                vstrDecryptionKey = Strings.Left(vstrDecryptionKey, 0x20);
            }
            else
            {
                int num3 = Strings.Len(vstrDecryptionKey);
                int number = 0x20 - num3;
                vstrDecryptionKey = vstrDecryptionKey + Strings.StrDup(number, "X");
            }
            byte[] bytes = Encoding.ASCII.GetBytes(vstrDecryptionKey.ToCharArray());
            byte[] buffer4 = new byte[buffer.Length + 1];
            MemoryStream stream2 = new MemoryStream(buffer);
            try
            {
                CryptoStream stream = new CryptoStream(stream2, managed.CreateDecryptor(bytes, rgbIV), CryptoStreamMode.Read);
                stream.Read(buffer4, 0, buffer4.Length);
                stream.FlushFinalBlock();
                stream2.Close();
                stream.Close();
            }
            catch (Exception exception1)
            {
                ProjectData.SetProjectError(exception1);
                ProjectData.ClearProjectError();
            }
            return this.StripNullCharacters(Encoding.ASCII.GetString(buffer4));
        }

        public string EncryptString128Bit(string vstrStringToBeEncrypted, string vstrEncryptionKey)
        {
            byte[] rgbIV = new byte[] { 0x79, 0xf1, 10, 1, 0x84, 0x4a, 11, 0x27, 0xff, 0x5b, 0x2d, 0x4e, 14, 0xd3, 0x16, 0x3e };
            RijndaelManaged managed = new RijndaelManaged();
            //byte[] buffer = Convert.FromBase64String(vstrStringToBeEncrypted);
            byte[] buffer = Encoding.ASCII.GetBytes(vstrStringToBeEncrypted);
            if (Strings.Len(vstrEncryptionKey) >= 0x20)
            {
                vstrEncryptionKey = Strings.Left(vstrEncryptionKey, 0x20);
            }
            else
            {
                int num3 = Strings.Len(vstrEncryptionKey);
                int number = 0x20 - num3;
                vstrEncryptionKey = vstrEncryptionKey + Strings.StrDup(number, "X");
            }
            byte[] bytes = Encoding.ASCII.GetBytes(vstrEncryptionKey.ToCharArray());
            MemoryStream stream2 = new MemoryStream();
            try
            {
                byte[] buffer4;
                CryptoStream stream = new CryptoStream(stream2, managed.CreateEncryptor(bytes, rgbIV), CryptoStreamMode.Write);
                stream.Write(buffer, 0, buffer.Length);
                stream.FlushFinalBlock();
                stream2.Position = 0;
                buffer4 = new byte[stream2.Length];
                stream2.Read(buffer4, 0, buffer4.Length);
                stream2.Close();
                stream.Close();
                return this.StripNullCharacters(Convert.ToBase64String(buffer4));
            }
            catch (Exception exception1)
            {
                MessageBox.Show(exception1.ToString());
                ProjectData.SetProjectError(exception1);
                ProjectData.ClearProjectError();
            }
            return "";
        }

        public string StripNullCharacters(string vstrStringWithNulls)
        {
            int start = 1;
            string str = vstrStringWithNulls;
            while (start > 0)
            {
                start = Strings.InStr(start, vstrStringWithNulls, "\0", CompareMethod.Binary);
                if (start > 0)
                {
                    str = Strings.Left(str, start - 1) + Strings.Right(str, Strings.Len(str) - start);
                }
                if (start > str.Length)
                {
                    return str;
                }
            }
            return str;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtSerial.Text = EncryptString128Bit(txtName.Text, txtID.Text);
        }
    }
}