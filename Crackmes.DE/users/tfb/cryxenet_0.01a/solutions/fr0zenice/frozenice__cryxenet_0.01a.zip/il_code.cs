.method public instance void  b(object A_0,
                                class [mscorlib]System.EventArgs A_1) cil managed
{
  // Code size       2043 (0x7fb)
  .maxstack  5
  .locals init (object V_0,
           int32 V_1,
           int32 V_2,
           int32 V_3,
           int32 V_4,
           class [mscorlib]System.IO.FileStream V_5,
           valuetype [mscorlib]System.IO.FileMode V_6,
           int32 V_7,
           int32 V_8,
           int32 V_9,
           int32 V_10,
           int32 V_11,
           int32 V_12,
           int32 V_13,
           int32 V_14,
           int32 V_15,
           object V_16,
           class [mscorlib]System.Threading.Thread V_17,
           int32 V_18,
           string V_19,
           int32 V_20,
           int32 V_21)
  IL_0000:  nop
  IL_0001:  ldc.i4     0x927c0
  IL_0006:  box        class [mscorlib]System.Int32
  IL_000b:  stloc.0
  IL_000c:  ldc.i4.0
  IL_000d:  stloc.1
  IL_000e:  ldc.i4.0
  IL_000f:  stloc.s    V_20
  IL_0011:  newobj     instance void object::.ctor()
  IL_0016:  call       object class [mscorlib]System.Runtime.CompilerServices.RuntimeHelpers::GetObjectValue(object)
  IL_001b:  stloc.s    V_16
  IL_001d:  ldc.i4.4
  IL_001e:  stloc.s    V_7
  IL_0020:  ldc.i4.5
  IL_0021:  stloc.s    V_11
  IL_0023:  br.s       IL_002a
  IL_0025:  ldloc.s    V_11
  IL_0027:  add.ovf
  IL_0028:  stloc.s    V_7
  IL_002a:  ldloc.s    V_7
  IL_002c:  ldloc.s    V_11
  IL_002e:  mul.ovf
  IL_002f:  stloc.s    V_11
  IL_0031:  ldstr      "08w357djf30dfh+//dgjd=a"
  IL_0036:  stloc.s    V_19
  IL_0038:  ldc.i4.s   99
  IL_003a:  stloc.s    V_12
  IL_003c:  call       int32 class a::IsDebuggerPresent()
  IL_0041:  ldloc.s    V_12
  IL_0043:  add.ovf
  IL_0044:  stloc.2
  IL_0045:  ldloc.2
  IL_0046:  ldc.i4.s   99
  IL_0048:  bne.un.s   IL_0050
  IL_004a:  ldc.i4.s   99
  IL_004c:  stloc.s    V_12
  IL_004e:  br.s       IL_006d
  IL_0050:  nop
  IL_0051:  ldarg.0
  IL_0052:  ldstr      "kom/Wb1qG5J5yRbp+B54JwzltwjWSOeCJZF0EKYHe5lNTUgUJz"
  + "y8JQkHkl/OaQpVDwC/vMPmj0f1b0YXPAtOsw=="
  IL_0057:  ldstr      "1357924680"
  IL_005c:  callvirt   instance string class a::a(string,
                                                  string)
  IL_0061:  call       valuetype [System.Windows.Forms]System.Windows.Forms.DialogResult class [System.Windows.Forms]System.Windows.Forms.MessageBox::Show(string)
  IL_0066:  pop
  IL_0067:  nop
  IL_0068:  br         IL_07f9
  IL_006d:  nop
  IL_006e:  ldc.i4.s   89
  IL_0070:  stloc.s    V_13
  IL_0072:  ldloc.s    V_12
  IL_0074:  ldloc.s    V_13
  IL_0076:  mul.ovf
  IL_0077:  stloc.s    V_14
  IL_0079:  ldloc.s    V_12
  IL_007b:  ldloc.s    V_14
  IL_007d:  ble.s      IL_0089
  IL_007f:  ldc.i4     0x493
  IL_0084:  ldloc.s    V_13
  IL_0086:  add.ovf
  IL_0087:  stloc.s    V_12
  IL_0089:  nop
  IL_008a:  ldloc.s    V_14
  IL_008c:  ldloc.s    V_12
  IL_008e:  sub.ovf
  IL_008f:  stloc.s    V_15
  IL_0091:  ldc.i4     0x8a
  IL_0096:  ldloc.s    V_13
  IL_0098:  add.ovf
  IL_0099:  stloc.s    V_12
  IL_009b:  ldloc.s    V_12
  IL_009d:  ldloc.s    V_13
  IL_009f:  add.ovf
  IL_00a0:  stloc.s    V_15
  IL_00a2:  ldloc.s    V_12
  IL_00a4:  ldloc.s    V_13
  IL_00a6:  add.ovf
  IL_00a7:  stloc.s    V_18
  IL_00a9:  ldloc.s    V_13
  IL_00ab:  ldc.i4.s   99
  IL_00ad:  sub.ovf
  IL_00ae:  stloc.s    V_18
  IL_00b0:  ldc.i4.s   37
  IL_00b2:  stloc.s    V_21
  IL_00b4:  ldloca.s   V_21
  IL_00b6:  ldstr      "x"
  IL_00bb:  call       instance string class [mscorlib]System.Int32::ToString(string)
  IL_00c0:  stloc.s    V_19
  IL_00c2:  ldc.i4.s   99
  IL_00c4:  stloc.s    V_12
  IL_00c6:  ldc.i4.s   89
  IL_00c8:  stloc.s    V_13
  IL_00ca:  ldloc.s    V_12
  IL_00cc:  ldloc.s    V_13
  IL_00ce:  mul.ovf
  IL_00cf:  stloc.s    V_14
  IL_00d1:  ldloc.s    V_12
  IL_00d3:  ldloc.s    V_14
  IL_00d5:  ble.s      IL_00e1
  IL_00d7:  ldc.i4     0x493
  IL_00dc:  ldloc.s    V_13
  IL_00de:  add.ovf
  IL_00df:  stloc.s    V_12
  IL_00e1:  nop
  IL_00e2:  ldloc.s    V_14
  IL_00e4:  ldloc.s    V_12
  IL_00e6:  sub.ovf
  IL_00e7:  stloc.s    V_15
  IL_00e9:  ldc.i4     0x8a
  IL_00ee:  ldloc.s    V_13
  IL_00f0:  add.ovf
  IL_00f1:  stloc.s    V_12
  IL_00f3:  ldloc.s    V_12
  IL_00f5:  ldloc.s    V_13
  IL_00f7:  add.ovf
  IL_00f8:  stloc.s    V_15
  IL_00fa:  ldloc.s    V_19
  IL_00fc:  ldc.i4     0x203
  IL_0101:  call       int32 class [mscorlib]System.Int32::Parse(string,
                                                                 valuetype [mscorlib]System.Globalization.NumberStyles)
  IL_0106:  stloc.s    V_4
  IL_0108:  ldc.i4.s   99
  IL_010a:  stloc.s    V_12
  IL_010c:  ldc.i4.s   89
  IL_010e:  stloc.s    V_13
  IL_0110:  ldloc.s    V_12
  IL_0112:  ldloc.s    V_13
  IL_0114:  mul.ovf
  IL_0115:  stloc.s    V_14
  IL_0117:  ldloc.s    V_12
  IL_0119:  ldloc.s    V_14
  IL_011b:  ble.s      IL_0127
  IL_011d:  ldc.i4     0x493
  IL_0122:  ldloc.s    V_13
  IL_0124:  add.ovf
  IL_0125:  stloc.s    V_12
  IL_0127:  nop
  IL_0128:  ldloc.s    V_14
  IL_012a:  ldloc.s    V_12
  IL_012c:  sub.ovf
  IL_012d:  stloc.s    V_15
  IL_012f:  ldc.i4     0x8a
  IL_0134:  ldloc.s    V_13
  IL_0136:  add.ovf
  IL_0137:  stloc.s    V_12
  IL_0139:  ldloc.s    V_12
  IL_013b:  ldloc.s    V_13
  IL_013d:  add.ovf
  IL_013e:  stloc.s    V_15
  IL_0140:  ldstr      "cryxed.dll"
  IL_0145:  ldc.i4.3
  IL_0146:  ldc.i4.1
  IL_0147:  ldc.i4.1
  IL_0148:  ldloc.0
  IL_0149:  call       int32 class [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.IntegerType::FromObject(object)
  IL_014e:  newobj     instance void class [mscorlib]System.IO.FileStream::.ctor(string,
                                                                                 valuetype [mscorlib]System.IO.FileMode,
                                                                                 valuetype [mscorlib]System.IO.FileAccess,
                                                                                 valuetype [mscorlib]System.IO.FileShare,
                                                                                 int32)
  IL_0153:  stloc.s    V_5
  IL_0155:  br.s       IL_01ac
  IL_0157:  ldloc.s    V_5
  IL_0159:  ldarg.0
  IL_015a:  ldfld      uint8[] a::d
  IL_015f:  ldloc.s    V_20
  IL_0161:  ldloc.0
  IL_0162:  call       int32 class [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.IntegerType::FromObject(object)
  IL_0167:  callvirt   instance int32 class [mscorlib]System.IO.FileStream::Read(uint8[],
                                                                                 int32,
                                                                                 int32)
  IL_016c:  stloc.1
  IL_016d:  ldc.i4.s   99
  IL_016f:  stloc.s    V_12
  IL_0171:  ldc.i4.s   89
  IL_0173:  stloc.s    V_13
  IL_0175:  ldloc.s    V_12
  IL_0177:  ldloc.s    V_13
  IL_0179:  mul.ovf
  IL_017a:  stloc.s    V_14
  IL_017c:  ldloc.s    V_12
  IL_017e:  ldloc.s    V_14
  IL_0180:  ble.s      IL_018c
  IL_0182:  ldc.i4     0x493
  IL_0187:  ldloc.s    V_13
  IL_0189:  add.ovf
  IL_018a:  stloc.s    V_12
  IL_018c:  nop
  IL_018d:  ldloc.s    V_14
  IL_018f:  ldloc.s    V_12
  IL_0191:  sub.ovf
  IL_0192:  stloc.s    V_15
  IL_0194:  ldc.i4     0x8a
  IL_0199:  ldloc.s    V_13
  IL_019b:  add.ovf
  IL_019c:  stloc.s    V_12
  IL_019e:  ldloc.s    V_12
  IL_01a0:  ldloc.s    V_13
  IL_01a2:  add.ovf
  IL_01a3:  stloc.s    V_15
  IL_01a5:  ldloc.s    V_20
  IL_01a7:  ldloc.1
  IL_01a8:  add.ovf
  IL_01a9:  stloc.s    V_20
  IL_01ab:  nop
  IL_01ac:  ldloc.s    V_20
  IL_01ae:  conv.i8
  IL_01af:  ldloc.s    V_5
  IL_01b1:  callvirt   instance int64 class [mscorlib]System.IO.FileStream::get_Length()
  IL_01b6:  blt.s      IL_0157
  IL_01b8:  ldloc.s    V_5
  IL_01ba:  callvirt   instance void class [mscorlib]System.IO.FileStream::Close()
  IL_01bf:  nop
  IL_01c0:  ldc.i4.0
  IL_01c1:  stloc.3
  IL_01c2:  br         IL_03b3
  IL_01c7:  ldarg.0
  IL_01c8:  ldfld      uint8[] a::d
  IL_01cd:  ldloc.3
  IL_01ce:  ldelem.u1
  IL_01cf:  ldc.i4.1
  IL_01d0:  sub.ovf
  IL_01d1:  stloc.s    V_18
  IL_01d3:  ldc.i4.4
  IL_01d4:  stloc.s    V_7
  IL_01d6:  ldc.i4.5
  IL_01d7:  stloc.s    V_11
  IL_01d9:  ldc.i4.s   99
  IL_01db:  stloc.s    V_12
  IL_01dd:  ldc.i4.s   89
  IL_01df:  stloc.s    V_13
  IL_01e1:  ldloc.s    V_12
  IL_01e3:  ldloc.s    V_13
  IL_01e5:  mul.ovf
  IL_01e6:  stloc.s    V_14
  IL_01e8:  ldloc.s    V_12
  IL_01ea:  ldloc.s    V_14
  IL_01ec:  ble.s      IL_01f8
  IL_01ee:  ldc.i4     0x493
  IL_01f3:  ldloc.s    V_13
  IL_01f5:  add.ovf
  IL_01f6:  stloc.s    V_12
  IL_01f8:  nop
  IL_01f9:  ldloc.s    V_14
  IL_01fb:  ldloc.s    V_12
  IL_01fd:  sub.ovf
  IL_01fe:  stloc.s    V_15
  IL_0200:  ldc.i4     0x8a
  IL_0205:  ldloc.s    V_13
  IL_0207:  add.ovf
  IL_0208:  stloc.s    V_12
  IL_020a:  ldloc.s    V_12
  IL_020c:  ldloc.s    V_13
  IL_020e:  add.ovf
  IL_020f:  stloc.s    V_15
  IL_0211:  ldloc.s    V_18
  IL_0213:  ldloc.s    V_4
  IL_0215:  xor
  IL_0216:  stloc.s    V_18
  IL_0218:  ldloc.s    V_7
  IL_021a:  ldloc.s    V_11
  IL_021c:  add.ovf
  IL_021d:  stloc.s    V_7
  IL_021f:  ldloc.s    V_7
  IL_0221:  ldloc.s    V_11
  IL_0223:  mul.ovf
  IL_0224:  stloc.s    V_11
  IL_0226:  ldloc.s    V_18
  IL_0228:  ldc.i4     0xff
  IL_022d:  ble.s      IL_0243
  IL_022f:  ldc.i4     0x80
  IL_0234:  stloc.s    V_7
  IL_0236:  ldloc.s    V_7
  IL_0238:  ldc.i4.2
  IL_0239:  mul.ovf
  IL_023a:  stloc.s    V_11
  IL_023c:  ldloc.s    V_18
  IL_023e:  ldloc.s    V_11
  IL_0240:  sub.ovf
  IL_0241:  stloc.s    V_18
  IL_0243:  nop
  IL_0244:  ldloc.s    V_18
  IL_0246:  ldc.i4.0
  IL_0247:  bge.s      IL_0295
  IL_0249:  ldc.i4     0x80
  IL_024e:  stloc.s    V_11
  IL_0250:  ldloc.s    V_11
  IL_0252:  ldc.i4.2
  IL_0253:  mul.ovf
  IL_0254:  stloc.s    V_7
  IL_0256:  ldc.i4.s   99
  IL_0258:  stloc.s    V_12
  IL_025a:  ldc.i4.s   89
  IL_025c:  stloc.s    V_13
  IL_025e:  ldloc.s    V_12
  IL_0260:  ldloc.s    V_13
  IL_0262:  mul.ovf
  IL_0263:  stloc.s    V_14
  IL_0265:  ldloc.s    V_12
  IL_0267:  ldloc.s    V_14
  IL_0269:  ble.s      IL_0275
  IL_026b:  ldc.i4     0x493
  IL_0270:  ldloc.s    V_13
  IL_0272:  add.ovf
  IL_0273:  stloc.s    V_12
  IL_0275:  nop
  IL_0276:  ldloc.s    V_14
  IL_0278:  ldloc.s    V_12
  IL_027a:  sub.ovf
  IL_027b:  stloc.s    V_15
  IL_027d:  ldc.i4     0x8a
  IL_0282:  ldloc.s    V_13
  IL_0284:  add.ovf
  IL_0285:  stloc.s    V_12
  IL_0287:  ldloc.s    V_12
  IL_0289:  ldloc.s    V_13
  IL_028b:  add.ovf
  IL_028c:  stloc.s    V_15
  IL_028e:  ldloc.s    V_18
  IL_0290:  ldloc.s    V_7
  IL_0292:  add.ovf
  IL_0293:  stloc.s    V_18
  IL_0295:  nop
  IL_0296:  ldarg.0
  IL_0297:  ldfld      uint8[] a::e
  IL_029c:  ldloc.3
  IL_029d:  ldloc.s    V_18
  IL_029f:  ldarg.0
  IL_02a0:  ldfld      uint8[] a::f
  IL_02a5:  ldloc.3
  IL_02a6:  ldelem.u1
  IL_02a7:  add.ovf
  IL_02a8:  conv.ovf.u1
  IL_02a9:  stelem.i1
  IL_02aa:  ldc.i4.s   99
  IL_02ac:  stloc.s    V_12
  IL_02ae:  ldc.i4.s   89
  IL_02b0:  stloc.s    V_13
  IL_02b2:  ldloc.s    V_12
  IL_02b4:  ldloc.s    V_13
  IL_02b6:  mul.ovf
  IL_02b7:  stloc.s    V_14
  IL_02b9:  ldloc.s    V_12
  IL_02bb:  ldloc.s    V_14
  IL_02bd:  ble.s      IL_02c9
  IL_02bf:  ldc.i4     0x493
  IL_02c4:  ldloc.s    V_13
  IL_02c6:  add.ovf
  IL_02c7:  stloc.s    V_12
  IL_02c9:  nop
  IL_02ca:  ldloc.s    V_14
  IL_02cc:  ldloc.s    V_12
  IL_02ce:  sub.ovf
  IL_02cf:  stloc.s    V_15
  IL_02d1:  ldc.i4     0x8a
  IL_02d6:  ldloc.s    V_13
  IL_02d8:  add.ovf
  IL_02d9:  stloc.s    V_12
  IL_02db:  ldloc.s    V_12
  IL_02dd:  ldloc.s    V_13
  IL_02df:  add.ovf
  IL_02e0:  stloc.s    V_15
  IL_02e2:  ldarg.0
  IL_02e3:  ldfld      uint8[] a::d
  IL_02e8:  ldloc.3
  IL_02e9:  ldarg.0
  IL_02ea:  ldfld      uint8[] a::f
  IL_02ef:  ldloc.3
  IL_02f0:  ldelem.u1
  IL_02f1:  stelem.i1
  IL_02f2:  ldc.i4.s   99
  IL_02f4:  stloc.s    V_12
  IL_02f6:  ldc.i4.s   89
  IL_02f8:  stloc.s    V_13
  IL_02fa:  ldloc.s    V_12
  IL_02fc:  ldloc.s    V_13
  IL_02fe:  mul.ovf
  IL_02ff:  stloc.s    V_14
  IL_0301:  ldloc.s    V_12
  IL_0303:  ldloc.s    V_14
  IL_0305:  ble.s      IL_0311
  IL_0307:  ldc.i4     0x493
  IL_030c:  ldloc.s    V_13
  IL_030e:  add.ovf
  IL_030f:  stloc.s    V_12
  IL_0311:  nop
  IL_0312:  ldloc.s    V_14
  IL_0314:  ldloc.s    V_12
  IL_0316:  sub.ovf
  IL_0317:  stloc.s    V_15
  IL_0319:  ldc.i4     0x8a
  IL_031e:  ldloc.s    V_13
  IL_0320:  add.ovf
  IL_0321:  stloc.s    V_12
  IL_0323:  ldloc.s    V_12
  IL_0325:  ldloc.s    V_13
  IL_0327:  add.ovf
  IL_0328:  stloc.s    V_15
  IL_032a:  ldarg.0
  IL_032b:  ldfld      uint8[] a::d
  IL_0330:  ldloc.3
  IL_0331:  ldarg.0
  IL_0332:  ldfld      uint8[] a::e
  IL_0337:  ldloc.3
  IL_0338:  ldelem.u1
  IL_0339:  ldarg.0
  IL_033a:  ldfld      uint8[] a::d
  IL_033f:  ldloc.3
  IL_0340:  ldelem.u1
  IL_0341:  sub
  IL_0342:  conv.ovf.u1
  IL_0343:  stelem.i1
  IL_0344:  ldarg.0
  IL_0345:  ldfld      uint8[] a::e
  IL_034a:  ldloc.3
  IL_034b:  ldc.i4.s   98
  IL_034d:  stelem.i1
  IL_034e:  ldarg.0
  IL_034f:  ldfld      uint8[] a::f
  IL_0354:  ldloc.3
  IL_0355:  ldc.i4.s   55
  IL_0357:  stelem.i1
  IL_0358:  ldc.i4.s   99
  IL_035a:  stloc.s    V_12
  IL_035c:  ldc.i4.s   89
  IL_035e:  stloc.s    V_13
  IL_0360:  ldloc.s    V_12
  IL_0362:  ldloc.s    V_13
  IL_0364:  mul.ovf
  IL_0365:  stloc.s    V_14
  IL_0367:  ldc.i4.s   89
  IL_0369:  stloc.s    V_14
  IL_036b:  ldarg.0
  IL_036c:  ldfld      uint8[] a::e
  IL_0371:  ldloc.3
  IL_0372:  ldloc.s    V_14
  IL_0374:  conv.ovf.u1
  IL_0375:  stelem.i1
  IL_0376:  ldloc.s    V_12
  IL_0378:  ldloc.s    V_14
  IL_037a:  ble.s      IL_0386
  IL_037c:  ldc.i4     0x493
  IL_0381:  ldloc.s    V_13
  IL_0383:  add.ovf
  IL_0384:  stloc.s    V_12
  IL_0386:  nop
  IL_0387:  ldloc.s    V_14
  IL_0389:  ldloc.s    V_12
  IL_038b:  sub.ovf
  IL_038c:  stloc.s    V_15
  IL_038e:  ldc.i4     0x8a
  IL_0393:  ldloc.s    V_13
  IL_0395:  add.ovf
  IL_0396:  stloc.s    V_12
  IL_0398:  ldc.i4.s   88
  IL_039a:  stloc.s    V_15
  IL_039c:  ldarg.0
  IL_039d:  ldfld      uint8[] a::f
  IL_03a2:  ldloc.3
  IL_03a3:  ldloc.s    V_15
  IL_03a5:  conv.ovf.u1
  IL_03a6:  stelem.i1
  IL_03a7:  ldloc.s    V_12
  IL_03a9:  ldloc.s    V_13
  IL_03ab:  add.ovf
  IL_03ac:  stloc.s    V_15
  IL_03ae:  ldloc.3
  IL_03af:  ldc.i4.1
  IL_03b0:  add.ovf
  IL_03b1:  stloc.3
  IL_03b2:  nop
  IL_03b3:  ldloc.3
  IL_03b4:  ldloc.s    V_20
  IL_03b6:  blt        IL_01c7
  IL_03bb:  ldarg.0
  IL_03bc:  callvirt   instance void class [System.Windows.Forms]System.Windows.Forms.Form::Close()
  IL_03c1:  nop
  IL_03c2:  ldc.i4.s   99
  IL_03c4:  stloc.s    V_12
  IL_03c6:  ldc.i4.s   89
  IL_03c8:  stloc.s    V_13
  IL_03ca:  ldloc.s    V_12
  IL_03cc:  ldloc.s    V_13
  IL_03ce:  mul.ovf
  IL_03cf:  stloc.s    V_14
  IL_03d1:  ldloc.s    V_12
  IL_03d3:  ldloc.s    V_14
  IL_03d5:  ble.s      IL_03e1
  IL_03d7:  ldc.i4     0x493
  IL_03dc:  ldloc.s    V_13
  IL_03de:  add.ovf
  IL_03df:  stloc.s    V_12
  IL_03e1:  nop
  IL_03e2:  ldloc.s    V_14
  IL_03e4:  ldloc.s    V_12
  IL_03e6:  sub.ovf
  IL_03e7:  stloc.s    V_15
  IL_03e9:  ldc.i4     0x8a
  IL_03ee:  ldloc.s    V_13
  IL_03f0:  add.ovf
  IL_03f1:  stloc.s    V_12
  IL_03f3:  ldloc.s    V_12
  IL_03f5:  ldloc.s    V_13
  IL_03f7:  add.ovf
  IL_03f8:  stloc.s    V_15
  IL_03fa:  ldarg.0
  IL_03fb:  dup
  IL_03fc:  ldvirtftn  instance void class a::c()
  IL_0402:  newobj     instance void class [mscorlib]System.Threading.ThreadStart::.ctor(object,
                                                                                         native int)
  IL_0407:  newobj     instance void class [mscorlib]System.Threading.Thread::.ctor(class [mscorlib]System.Threading.ThreadStart)
  IL_040c:  stloc.s    V_17
  IL_040e:  ldc.i4.s   99
  IL_0410:  stloc.s    V_12
  IL_0412:  ldc.i4.s   89
  IL_0414:  stloc.s    V_13
  IL_0416:  ldloc.s    V_12
  IL_0418:  ldloc.s    V_13
  IL_041a:  mul.ovf
  IL_041b:  stloc.s    V_14
  IL_041d:  ldloc.s    V_12
  IL_041f:  ldloc.s    V_14
  IL_0421:  ble.s      IL_042d
  IL_0423:  ldc.i4     0x493
  IL_0428:  ldloc.s    V_13
  IL_042a:  add.ovf
  IL_042b:  stloc.s    V_12
  IL_042d:  nop
  IL_042e:  ldloc.s    V_14
  IL_0430:  ldloc.s    V_12
  IL_0432:  sub.ovf
  IL_0433:  stloc.s    V_15
  IL_0435:  ldc.i4     0x8a
  IL_043a:  ldloc.s    V_13
  IL_043c:  add.ovf
  IL_043d:  stloc.s    V_12
  IL_043f:  ldloc.s    V_12
  IL_0441:  ldloc.s    V_13
  IL_0443:  add.ovf
  IL_0444:  stloc.s    V_15
  IL_0446:  ldc.i4.s   99
  IL_0448:  stloc.s    V_12
  IL_044a:  ldc.i4.s   89
  IL_044c:  stloc.s    V_13
  IL_044e:  ldloc.s    V_12
  IL_0450:  ldloc.s    V_13
  IL_0452:  mul.ovf
  IL_0453:  stloc.s    V_14
  IL_0455:  ldloc.s    V_12
  IL_0457:  ldloc.s    V_14
  IL_0459:  ble.s      IL_0465
  IL_045b:  ldc.i4     0x493
  IL_0460:  ldloc.s    V_13
  IL_0462:  add.ovf
  IL_0463:  stloc.s    V_12
  IL_0465:  nop
  IL_0466:  ldloc.s    V_14
  IL_0468:  ldloc.s    V_12
  IL_046a:  sub.ovf
  IL_046b:  stloc.s    V_15
  IL_046d:  ldc.i4     0x8a
  IL_0472:  ldloc.s    V_13
  IL_0474:  add.ovf
  IL_0475:  stloc.s    V_12
  IL_0477:  ldloc.s    V_12
  IL_0479:  ldloc.s    V_13
  IL_047b:  add.ovf
  IL_047c:  stloc.s    V_15
  IL_047e:  ldloc.s    V_17
  IL_0480:  callvirt   instance void class [mscorlib]System.Threading.Thread::Start()
  IL_0485:  nop
  IL_0486:  ldc.i4.s   99
  IL_0488:  stloc.s    V_12
  IL_048a:  ldc.i4.s   89
  IL_048c:  stloc.s    V_13
  IL_048e:  ldloc.s    V_12
  IL_0490:  ldloc.s    V_13
  IL_0492:  mul.ovf
  IL_0493:  stloc.s    V_14
  IL_0495:  ldloc.s    V_12
  IL_0497:  ldloc.s    V_14
  IL_0499:  ble.s      IL_04a5
  IL_049b:  ldc.i4     0x493
  IL_04a0:  ldloc.s    V_13
  IL_04a2:  add.ovf
  IL_04a3:  stloc.s    V_12
  IL_04a5:  nop
  IL_04a6:  ldloc.s    V_14
  IL_04a8:  ldloc.s    V_12
  IL_04aa:  sub.ovf
  IL_04ab:  stloc.s    V_15
  IL_04ad:  ldc.i4     0x8a
  IL_04b2:  ldloc.s    V_13
  IL_04b4:  add.ovf
  IL_04b5:  stloc.s    V_12
  IL_04b7:  ldloc.s    V_12
  IL_04b9:  ldloc.s    V_13
  IL_04bb:  add.ovf
  IL_04bc:  stloc.s    V_15
  IL_04be:  ldloc.s    V_13
  IL_04c0:  stloc.s    V_12
  IL_04c2:  ldloc.s    V_12
  IL_04c4:  ldloc.s    V_13
  IL_04c6:  sub.ovf
  IL_04c7:  stloc.3
  IL_04c8:  ldc.i4     0x3e8
  IL_04cd:  call       void class [mscorlib]System.Threading.Thread::Sleep(int32)
  IL_04d2:  nop
  IL_04d3:  ldloc.3
  IL_04d4:  stloc.s    V_8
  IL_04d6:  ldarg.0
  IL_04d7:  ldfld      uint8[] a::d
  IL_04dc:  ldc.i4.4
  IL_04dd:  ldelem.u1
  IL_04de:  stloc.s    V_9
  IL_04e0:  ldarg.0
  IL_04e1:  ldfld      uint8[] a::d
  IL_04e6:  ldc.i4.1
  IL_04e7:  ldelem.u1
  IL_04e8:  ldc.i4     0x3c8
  IL_04ed:  add.ovf
  IL_04ee:  stloc.s    V_10
  IL_04f0:  ldloc.s    V_9
  IL_04f2:  ldloc.s    V_10
  IL_04f4:  sub.ovf
  IL_04f5:  stloc.s    V_8
  IL_04f7:  ldloc.s    V_9
  IL_04f9:  ldc.i4.2
  IL_04fa:  mul.ovf
  IL_04fb:  stloc.s    V_9
  IL_04fd:  ldloc.s    V_9
  IL_04ff:  ldloc.s    V_8
  IL_0501:  add.ovf
  IL_0502:  stloc.s    V_10
  IL_0504:  ldc.i4.s   99
  IL_0506:  stloc.s    V_12
  IL_0508:  ldc.i4.s   89
  IL_050a:  stloc.s    V_13
  IL_050c:  ldloc.s    V_12
  IL_050e:  ldloc.s    V_13
  IL_0510:  mul.ovf
  IL_0511:  stloc.s    V_14
  IL_0513:  ldloc.s    V_12
  IL_0515:  ldloc.s    V_14
  IL_0517:  ble.s      IL_0523
  IL_0519:  ldc.i4     0x493
  IL_051e:  ldloc.s    V_13
  IL_0520:  add.ovf
  IL_0521:  stloc.s    V_12
  IL_0523:  nop
  IL_0524:  ldloc.s    V_14
  IL_0526:  ldloc.s    V_12
  IL_0528:  sub.ovf
  IL_0529:  stloc.s    V_15
  IL_052b:  ldc.i4     0x8a
  IL_0530:  ldloc.s    V_13
  IL_0532:  add.ovf
  IL_0533:  stloc.s    V_12
  IL_0535:  ldloc.s    V_12
  IL_0537:  ldloc.s    V_13
  IL_0539:  add.ovf
  IL_053a:  stloc.s    V_15
  IL_053c:  ldc.i4.s   99
  IL_053e:  stloc.s    V_12
  IL_0540:  ldc.i4.s   89
  IL_0542:  stloc.s    V_13
  IL_0544:  ldloc.s    V_12
  IL_0546:  ldloc.s    V_13
  IL_0548:  mul.ovf
  IL_0549:  stloc.s    V_14
  IL_054b:  ldloc.s    V_12
  IL_054d:  ldloc.s    V_14
  IL_054f:  ble.s      IL_055b
  IL_0551:  ldc.i4     0x493
  IL_0556:  ldloc.s    V_13
  IL_0558:  add.ovf
  IL_0559:  stloc.s    V_12
  IL_055b:  nop
  IL_055c:  ldc.i4.0
  IL_055d:  stloc.3
  IL_055e:  ldloc.s    V_14
  IL_0560:  ldloc.s    V_12
  IL_0562:  sub.ovf
  IL_0563:  stloc.s    V_15
  IL_0565:  ldc.i4     0x8a
  IL_056a:  ldloc.s    V_13
  IL_056c:  add.ovf
  IL_056d:  stloc.s    V_12
  IL_056f:  ldloc.s    V_12
  IL_0571:  ldloc.s    V_13
  IL_0573:  add.ovf
  IL_0574:  stloc.s    V_15
  IL_0576:  br         IL_06f5
  IL_057b:  ldloc.3
  IL_057c:  stloc.s    V_8
  IL_057e:  ldarg.0
  IL_057f:  ldfld      uint8[] a::d
  IL_0584:  ldc.i4.4
  IL_0585:  ldelem.u1
  IL_0586:  stloc.s    V_9
  IL_0588:  ldarg.0
  IL_0589:  ldfld      uint8[] a::d
  IL_058e:  ldc.i4.1
  IL_058f:  ldelem.u1
  IL_0590:  ldc.i4     0x3c8
  IL_0595:  add.ovf
  IL_0596:  stloc.s    V_10
  IL_0598:  ldloc.s    V_9
  IL_059a:  ldloc.s    V_10
  IL_059c:  sub.ovf
  IL_059d:  stloc.s    V_8
  IL_059f:  ldloc.s    V_9
  IL_05a1:  ldc.i4.2
  IL_05a2:  mul.ovf
  IL_05a3:  stloc.s    V_9
  IL_05a5:  ldloc.s    V_9
  IL_05a7:  ldloc.s    V_8
  IL_05a9:  add.ovf
  IL_05aa:  stloc.s    V_10
  IL_05ac:  ldc.i4.s   99
  IL_05ae:  stloc.s    V_12
  IL_05b0:  ldc.i4.s   89
  IL_05b2:  stloc.s    V_13
  IL_05b4:  ldloc.s    V_12
  IL_05b6:  ldloc.s    V_13
  IL_05b8:  mul.ovf
  IL_05b9:  stloc.s    V_14
  IL_05bb:  ldloc.s    V_12
  IL_05bd:  ldloc.s    V_14
  IL_05bf:  ble.s      IL_05cb
  IL_05c1:  ldc.i4     0x493
  IL_05c6:  ldloc.s    V_13
  IL_05c8:  add.ovf
  IL_05c9:  stloc.s    V_12
  IL_05cb:  nop
  IL_05cc:  ldloc.s    V_14
  IL_05ce:  ldloc.s    V_12
  IL_05d0:  sub.ovf
  IL_05d1:  stloc.s    V_15
  IL_05d3:  ldc.i4     0x8a
  IL_05d8:  ldloc.s    V_13
  IL_05da:  add.ovf
  IL_05db:  stloc.s    V_12
  IL_05dd:  ldloc.s    V_12
  IL_05df:  ldloc.s    V_13
  IL_05e1:  add.ovf
  IL_05e2:  stloc.s    V_15
  IL_05e4:  ldarg.0
  IL_05e5:  ldfld      uint8[] a::d
  IL_05ea:  ldloc.3
  IL_05eb:  ldc.i4.0
  IL_05ec:  stelem.i1
  IL_05ed:  ldc.i4.s   99
  IL_05ef:  stloc.s    V_12
  IL_05f1:  ldc.i4.s   89
  IL_05f3:  stloc.s    V_13
  IL_05f5:  ldloc.s    V_12
  IL_05f7:  ldloc.s    V_13
  IL_05f9:  mul.ovf
  IL_05fa:  stloc.s    V_14
  IL_05fc:  ldloc.s    V_12
  IL_05fe:  ldloc.s    V_14
  IL_0600:  ble.s      IL_060c
  IL_0602:  ldc.i4     0x493
  IL_0607:  ldloc.s    V_13
  IL_0609:  add.ovf
  IL_060a:  stloc.s    V_12
  IL_060c:  nop
  IL_060d:  ldloc.s    V_14
  IL_060f:  ldloc.s    V_12
  IL_0611:  sub.ovf
  IL_0612:  stloc.s    V_15
  IL_0614:  ldc.i4     0x8a
  IL_0619:  ldloc.s    V_13
  IL_061b:  add.ovf
  IL_061c:  stloc.s    V_12
  IL_061e:  ldloc.s    V_12
  IL_0620:  ldloc.s    V_13
  IL_0622:  add.ovf
  IL_0623:  stloc.s    V_15
  IL_0625:  ldloc.3
  IL_0626:  stloc.s    V_8
  IL_0628:  ldarg.0
  IL_0629:  ldfld      uint8[] a::d
  IL_062e:  ldc.i4.4
  IL_062f:  ldelem.u1
  IL_0630:  stloc.s    V_9
  IL_0632:  ldarg.0
  IL_0633:  ldfld      uint8[] a::d
  IL_0638:  ldc.i4.1
  IL_0639:  ldelem.u1
  IL_063a:  ldc.i4     0x3c8
  IL_063f:  add.ovf
  IL_0640:  stloc.s    V_10
  IL_0642:  ldloc.s    V_9
  IL_0644:  ldloc.s    V_10
  IL_0646:  sub.ovf
  IL_0647:  stloc.s    V_8
  IL_0649:  ldloc.s    V_9
  IL_064b:  ldc.i4.2
  IL_064c:  mul.ovf
  IL_064d:  stloc.s    V_9
  IL_064f:  ldloc.s    V_9
  IL_0651:  ldloc.s    V_8
  IL_0653:  add.ovf
  IL_0654:  stloc.s    V_10
  IL_0656:  ldloc.3
  IL_0657:  stloc.s    V_8
  IL_0659:  ldarg.0
  IL_065a:  ldfld      uint8[] a::d
  IL_065f:  ldc.i4.4
  IL_0660:  ldelem.u1
  IL_0661:  stloc.s    V_9
  IL_0663:  ldarg.0
  IL_0664:  ldfld      uint8[] a::d
  IL_0669:  ldc.i4.1
  IL_066a:  ldelem.u1
  IL_066b:  ldc.i4     0x3c8
  IL_0670:  add.ovf
  IL_0671:  stloc.s    V_10
  IL_0673:  ldloc.s    V_9
  IL_0675:  ldloc.s    V_10
  IL_0677:  sub.ovf
  IL_0678:  stloc.s    V_8
  IL_067a:  ldloc.s    V_9
  IL_067c:  ldc.i4.2
  IL_067d:  mul.ovf
  IL_067e:  stloc.s    V_9
  IL_0680:  ldloc.s    V_9
  IL_0682:  ldloc.s    V_8
  IL_0684:  add.ovf
  IL_0685:  stloc.s    V_10
  IL_0687:  ldloc.3
  IL_0688:  ldc.i4.1
  IL_0689:  add.ovf
  IL_068a:  stloc.3
  IL_068b:  ldc.i4.s   99
  IL_068d:  stloc.s    V_12
  IL_068f:  ldc.i4.s   89
  IL_0691:  stloc.s    V_13
  IL_0693:  ldloc.s    V_12
  IL_0695:  ldloc.s    V_13
  IL_0697:  mul.ovf
  IL_0698:  stloc.s    V_14
  IL_069a:  ldloc.s    V_12
  IL_069c:  ldloc.s    V_14
  IL_069e:  ble.s      IL_06aa
  IL_06a0:  ldc.i4     0x493
  IL_06a5:  ldloc.s    V_13
  IL_06a7:  add.ovf
  IL_06a8:  stloc.s    V_12
  IL_06aa:  nop
  IL_06ab:  ldloc.s    V_14
  IL_06ad:  ldloc.s    V_12
  IL_06af:  sub.ovf
  IL_06b0:  stloc.s    V_15
  IL_06b2:  ldc.i4     0x8a
  IL_06b7:  ldloc.s    V_13
  IL_06b9:  add.ovf
  IL_06ba:  stloc.s    V_12
  IL_06bc:  ldloc.s    V_12
  IL_06be:  ldloc.s    V_13
  IL_06c0:  add.ovf
  IL_06c1:  stloc.s    V_15
  IL_06c3:  ldloc.3
  IL_06c4:  stloc.s    V_8
  IL_06c6:  ldarg.0
  IL_06c7:  ldfld      uint8[] a::d
  IL_06cc:  ldc.i4.4
  IL_06cd:  ldelem.u1
  IL_06ce:  stloc.s    V_9
  IL_06d0:  ldarg.0
  IL_06d1:  ldfld      uint8[] a::d
  IL_06d6:  ldc.i4.1
  IL_06d7:  ldelem.u1
  IL_06d8:  ldc.i4     0x3c8
  IL_06dd:  add.ovf
  IL_06de:  stloc.s    V_10
  IL_06e0:  ldloc.s    V_9
  IL_06e2:  ldloc.s    V_10
  IL_06e4:  sub.ovf
  IL_06e5:  stloc.s    V_8
  IL_06e7:  ldloc.s    V_9
  IL_06e9:  ldc.i4.2
  IL_06ea:  mul.ovf
  IL_06eb:  stloc.s    V_9
  IL_06ed:  ldloc.s    V_9
  IL_06ef:  ldloc.s    V_8
  IL_06f1:  add.ovf
  IL_06f2:  stloc.s    V_10
  IL_06f4:  nop
  IL_06f5:  ldloc.3
  IL_06f6:  ldloc.s    V_20
  IL_06f8:  blt        IL_057b
  IL_06fd:  ldloc.3
  IL_06fe:  stloc.s    V_8
  IL_0700:  ldarg.0
  IL_0701:  ldfld      uint8[] a::d
  IL_0706:  ldc.i4.4
  IL_0707:  ldelem.u1
  IL_0708:  stloc.s    V_9
  IL_070a:  ldarg.0
  IL_070b:  ldfld      uint8[] a::d
  IL_0710:  ldc.i4.1
  IL_0711:  ldelem.u1
  IL_0712:  ldc.i4     0x3c8
  IL_0717:  add.ovf
  IL_0718:  stloc.s    V_10
  IL_071a:  ldloc.s    V_9
  IL_071c:  ldloc.s    V_10
  IL_071e:  sub.ovf
  IL_071f:  stloc.s    V_8
  IL_0721:  ldloc.s    V_9
  IL_0723:  ldc.i4.2
  IL_0724:  mul.ovf
  IL_0725:  stloc.s    V_9
  IL_0727:  ldloc.s    V_9
  IL_0729:  ldloc.s    V_8
  IL_072b:  add.ovf
  IL_072c:  stloc.s    V_10
  IL_072e:  ldc.i4.s   99
  IL_0730:  stloc.s    V_12
  IL_0732:  ldc.i4.s   89
  IL_0734:  stloc.s    V_13
  IL_0736:  ldloc.s    V_12
  IL_0738:  ldloc.s    V_13
  IL_073a:  mul.ovf
  IL_073b:  stloc.s    V_14
  IL_073d:  ldloc.s    V_12
  IL_073f:  ldloc.s    V_14
  IL_0741:  ble.s      IL_074d
  IL_0743:  ldc.i4     0x493
  IL_0748:  ldloc.s    V_13
  IL_074a:  add.ovf
  IL_074b:  stloc.s    V_12
  IL_074d:  nop
  IL_074e:  ldloc.s    V_14
  IL_0750:  ldloc.s    V_12
  IL_0752:  sub.ovf
  IL_0753:  stloc.s    V_15
  IL_0755:  ldc.i4     0x8a
  IL_075a:  ldloc.s    V_13
  IL_075c:  add.ovf
  IL_075d:  stloc.s    V_12
  IL_075f:  ldloc.s    V_12
  IL_0761:  ldloc.s    V_13
  IL_0763:  add.ovf
  IL_0764:  stloc.s    V_15
  IL_0766:  ldloc.3
  IL_0767:  stloc.s    V_8
  IL_0769:  ldarg.0
  IL_076a:  ldfld      uint8[] a::d
  IL_076f:  ldc.i4.4
  IL_0770:  ldelem.u1
  IL_0771:  stloc.s    V_9
  IL_0773:  ldarg.0
  IL_0774:  ldfld      uint8[] a::d
  IL_0779:  ldc.i4.1
  IL_077a:  ldelem.u1
  IL_077b:  ldc.i4     0x3c8
  IL_0780:  add.ovf
  IL_0781:  stloc.s    V_10
  IL_0783:  ldloc.s    V_9
  IL_0785:  ldloc.s    V_10
  IL_0787:  sub.ovf
  IL_0788:  stloc.s    V_8
  IL_078a:  ldloc.s    V_9
  IL_078c:  ldc.i4.2
  IL_078d:  mul.ovf
  IL_078e:  stloc.s    V_9
  IL_0790:  ldloc.s    V_9
  IL_0792:  ldloc.s    V_8
  IL_0794:  add.ovf
  IL_0795:  stloc.s    V_10
  IL_0797:  ldloc.3
  IL_0798:  stloc.s    V_8
  IL_079a:  ldarg.0
  IL_079b:  ldfld      uint8[] a::d
  IL_07a0:  ldc.i4.4
  IL_07a1:  ldelem.u1
  IL_07a2:  stloc.s    V_9
  IL_07a4:  ldarg.0
  IL_07a5:  ldfld      uint8[] a::d
  IL_07aa:  ldc.i4.1
  IL_07ab:  ldelem.u1
  IL_07ac:  ldc.i4     0x3c8
  IL_07b1:  add.ovf
  IL_07b2:  stloc.s    V_10
  IL_07b4:  ldloc.s    V_9
  IL_07b6:  ldloc.s    V_10
  IL_07b8:  sub.ovf
  IL_07b9:  stloc.s    V_8
  IL_07bb:  ldloc.s    V_9
  IL_07bd:  ldc.i4.2
  IL_07be:  mul.ovf
  IL_07bf:  stloc.s    V_9
  IL_07c1:  ldloc.s    V_9
  IL_07c3:  ldloc.s    V_8
  IL_07c5:  add.ovf
  IL_07c6:  stloc.s    V_10
  IL_07c8:  ldloc.3
  IL_07c9:  stloc.s    V_8
  IL_07cb:  ldarg.0
  IL_07cc:  ldfld      uint8[] a::d
  IL_07d1:  ldc.i4.4
  IL_07d2:  ldelem.u1
  IL_07d3:  stloc.s    V_9
  IL_07d5:  ldarg.0
  IL_07d6:  ldfld      uint8[] a::d
  IL_07db:  ldc.i4.1
  IL_07dc:  ldelem.u1
  IL_07dd:  ldc.i4     0x3c8
  IL_07e2:  add.ovf
  IL_07e3:  stloc.s    V_10
  IL_07e5:  ldloc.s    V_9
  IL_07e7:  ldloc.s    V_10
  IL_07e9:  sub.ovf
  IL_07ea:  stloc.s    V_8
  IL_07ec:  ldloc.s    V_9
  IL_07ee:  ldc.i4.2
  IL_07ef:  mul.ovf
  IL_07f0:  stloc.s    V_9
  IL_07f2:  ldloc.s    V_9
  IL_07f4:  ldloc.s    V_8
  IL_07f6:  add.ovf
  IL_07f7:  stloc.s    V_10
  IL_07f9:  nop
  IL_07fa:  ret
} // end of method a::b

