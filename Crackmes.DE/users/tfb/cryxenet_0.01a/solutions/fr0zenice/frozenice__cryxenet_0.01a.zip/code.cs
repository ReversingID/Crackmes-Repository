public void b(object A_0, EventArgs A_1)
{ // since A_0 is the sender, it's the Form!
	object V_0;
	int32 V_1;
	int32 V_2;
	int32 V_3;
	int32 V_4;
	System.IO.FileStream V_5;
	System.IO.FileMode V_6;
	int32 V_7;
	int32 V_8;
	int32 V_9;
	int32 V_10;
	int32 V_11;
	int32 V_12;
	int32 V_13;
	int32 V_14;
	int32 V_15;
	object V_16;
	System.Threading.Thread V_17;
	int32 V_18;
	string V_19;
	int32 V_20;
	int32 V_21;

	V_0 = 600000;
	V_1 = 0;
	V_20 = 0;
	V_16 = RuntimeHelpers.GetObjectValue(new Object());
	V_7 = 4;
	V_11 = 5;
	goto IL_002A;
	//skips 3 instructions:
	// IL_0025 ldloc.s 11
	// IL_0027 add.ovf
	// IL_0028 stloc.s 7
	IL_002A:
	V_11 = V_7 * V_11;
	V_19 = "08w357djf30dfh+//dgjd=a";
	V_12 = 99;
	V_2 = a.IsDebuggerPresent() + V_12;
	if (V_2 != 99)
	{
		// IL_0050
		// we found a debugger! bail out
		MessageBox.Show(A_0.a("kom/Wb1qG5J5yRbp+B54JwzltwjWSOeCJZF0EKYHe5lNTUgUJzy8JQkHkl/OaQpVDwC/vMPmj0f1b0YXPAtOsw==", "1357924680"));
		// decodes to: "Debugger detected! Please close it and restart the application!"
		// IL_07F9
		return;
	}
	
	// IL_004A
	V_12 = 99;
	V_13 = 89;
	V_14 = V_12 * V_13;
	if (V_12 > V_14)
	{ // what?
		V_12 = 1171 + V_13;
	}
	V_15 = V_14 - V_12;
	V_12 = 138 + V_13;
	V_15 = V_12 + V_13;
	V_18 = V_12 + V_13;
	V_18 = V_13 - 99;
	V_21 = 37;
	V_19 = V_21.ToString("x");
	V_12 = 99;
	V_13 = 89;
	V_14 = V_12 * V_13;
	if (V_12 <= V_14)
	{
		V_12 = 1171 + V_13;
	}
	V_15 = V_14 - V_12;
	V_12 = 138 + V_13;
	V_15 = V_12 + V_13;
	V_4 = Int32.Parse(V_19, NumberStyles.HexNumber); // 515d = 203h, look up NumberStyles, you'll find a table ;)
	V_12 = 99;
	V_13 = 89;
	V_14 = V_12 * V_13;
	if (V_12 > V_14)
	{
		V_12 = 1171 + V_13;
	}
	V_15 = V_14 - V_12;
	V_12 = 138 + V_13;
	V_15 = V_12 + V_13;
	
	//interesting cryxed.dll stuff starts here!
	V_5 = new FileStream("cryxed.dll", FileMode.Open, FileAccess.Read, FileShare.Read, IntegerType.FromObject(V_0));
	goto IL_01AC;
	
	// reads the assembly into A_0.d (byte[])
	IL_01AC:
	if (V_5.Length > V_20)
	{
		V_1 = V_5.Read(A_0.d, V_20, IntegerType.FromObject(V_0)); // offset = V_20, buffer = 600000
		V_12 = 99;
		V_13 = 89;
		V_14 = V_12 * V_13;
		if (V_12 > V_14)
		{
			V_12 = 1171 + V_13;
		}
		V_15 = V_14 - V_12;
		V_12 = 138 + V_13;
		V_15 = V_12 + V_13;
		V_20 = V_20 + V_1;
		goto IL_01AC;
	}
	
	// IL_01B8
	V_5.Close();
	V_3 = 0;
	
	// loops over the assembly and does cryptic stuff
	IL_03B3:
	if (V_3 < V_20)
	{
		V_18 = A_0.d[V_3] - 1;
		V_7 = 4;
		V_11 = 5;
		V_12 = 99;
		V_13 = 89;
		V_14 = V_12 * V_13;
		if (V_12 <= V_14)
		{
			V_12 = 1171 + V_13;
		}
		V_15 = V_14 - V_12;
		V_12 = 138 + V_13;
		V_15 = V_12 + V_13;
		V_18 = V_18 ^ V_4; // xor, sweet
		V_7 = V_7 + V_11;
		V_11 = V_7 * V_11;
		if (V_18 > 255)
		{
			V_7 = 128;
			V_11 = V_7 * 2;
			V_18 = V_18 - V_11;
		}
		if (V_18 >= 0)
		{
			V_11 = 128;
			V_7 = V_11 * 2;
			V_12 = 99;
			V_13 = 89;
			V_14 = V_12 * V_13;
			if (V_12 <= V_14)
			{
				V_12 = 1171 + V_13;
			}
			V_15 = V_14 - V_12;
			V_12 = 138 + V_13;
			V_15 = V_12 + V_13;
			V_18 = V_18 + V_7;
		}
		// IL_0296
		A_0.e[V_3] = V_18 + A_0.f[V_3]; // a bit complex in IL code, but you'll figure out :)
		V_12 = 99;
		V_13 = 89;
		V_14 = V_12 * V_13;
		if (V_12 > V_14)
		{
			V_12 = 1171 + V_13;
		}
		V_15 = V_14 - V_12;
		V_12 = 138 + V_13;
		V_15 = V_12 + V_13;
		A_0.d[V_3] = A_0.f[V_3];
		V_12 = 99;
		V_13 = 89;
		V_14 = V_12 * V_13;
		if (V_12 > V_14)
		{
			V_12 = 1171 + V_13;
		}
		V_15 = V_14 - V_12;
		V_12 = 138 + V_13;
		V_15 = V_12 + V_13;
		A_0.d[V_3] = A_0.e[V_3] - A_0.d[V_3]; // again, a bit complex, just do it one by one
		A_0.e[V_3] = 98;
		A_0.f[V_3] = 55;
		V_12 = 99;
		V_13 = 89;
		V_14 = V_12 * V_13;
		V_14 = 89;
		A_0.e[V_3] = V_14;
		if (V_12 <= V_14)
		{
			V_12 = 1171 + V_13;
		}
		V_15 = V_14 + V_12;
		V_12 = 138 + V_13;
		V_15 = 88;
		A_0.f[V_3] = V_15;
		V_15 = V_12 + V_13;
		V_3 = V_3 + 1;
		goto IL_03B3;
	}
	
	// IL_03BB
	A_0.Close();
	V_12 = 99;
	V_13 = 89;
	V_14 = V_12 * V_13;
	if (V_12 <= V_14)
	{
		V_12 = 1171 + V_13;
	}
	V_15 = V_14 - V_12;
	V_12 = 138 + V_13;
	V_15 = V_12 + V_13;
	// watch out! the following instruction is missing from the graph
	// IL_03fc ldvirtftn instance void class a::c()
	V_17 = new Thread(new ThreadStart(A_0.c));
	V_12 = 99;
	V_13 = 89;
	V_14 = V_12 * V_13;
	if (V_12 <= V_14)
	{
		V_12 = 1171 + V_13;
	}
	V_15 = V_14 - V_12;
	V_12 = 138 + V_13;
	V_15 = V_12 + V_13;
	V_12 = 99;
	V_13 = 89;
	V_14 = V_12 * V_13;
	if (V_12 > V_14)
	{
		V_12 = 1171 + V_13;
	}
	V_15 = V_14 - V_12;
	V_12 = 138 + V_13;
	V_15 = V_12 + V_13;
	V_17.Start();
	V_12 = 99;
	V_13 = 89;
	V_14 = V_12 * V_13;
	if (V_12 <= V_14)
	{
		V_12 = 1171 + V_13;
	}
	V_15 = V_14 - V_12;
	V_12 = 138 + V_13;
	V_15 = V_12 + V_13;
	V_12 = V_13;
	V_3 = V_12 - V_13;
	Thread.Sleep(1000);
	V_8 = V_3;
	V_9 = A_0.d[4];
	V_10 = A_0.d[1] + 968;
	V_8 = V_9 - V_10;
	V_9 = V_9 * 2;
	V_10 = V_9 + V_8;
	V_12 = 99;
	V_13 = 89;
	V_14 = V_12 * V_13;
	if (V_12 <= V_14)
	{
		V_12 = 1171 + V_13;
	}
	V_15 = V_14 - V_12;
	V_12 = 138 + V_13;
	V_15 = V_12 + V_13;
	V_12 = 99;
	V_13 = 89;
	V_14 = V_12 * V_13;
	if (V_12 <= V_14)
	{
		V_12 = 1171 + V_13;
	}
	V_3 = 0;
	V_15 = V_14 - V_12;
	V_12 = 138 + V_13;
	V_15 = V_12 + V_13;
	
	IL_06F5:
	if (V_3 < V_20)
	{
		V_8 = V_3;
		V_9 = A_0.d[4];
		V_10 = A_0.d[1] + 968;
		V_8 = V_9 - V_10;
		V_9 = V_9 * 2;
		V_10 = V_9 + V_8;
		V_12 = 99;
		V_13 = 89;
		V_14 = V_12 * V_13;
		if (V_12 > V_14)
		{
			V_12 = 1171 + V_13;
		}
		V_15 = V_14 - V_12;
		V_12 = 138 + V_13;
		V_15 = V_12 + V_13;
		V_8 = V_3;
		V_9 = A_0.d[4];
		V_10 = A_0.d[1] + 968;
		V_8 = V_9 - V_10;
		V_9 = V_9 * 2;
		V_10 = V_9 + V_8;
		V_8 = V_3;
		V_9 = A_0.d[4];
		V_10 = A_0.d[1] + 968;
		V_8 = V_9 - V_10;
		V_9 = V_9 * 2;
		V_10 = V_9 + V_8;
		V_8 = V_3;
		V_9 = A_0.d[4];
		V_10 = A_0.d[1] + 968;
		V_8 = V_9 - V_10;
		V_9 = V_9 * 2;
		V_10 = V_9 + V_8;
		return;
	}
	else
	{
		V_8 = V_3;
		V_9 = A_0.d[4];
		V_10 = A_0.d[1] + 968;
		V_8 = V_9 - V_10;
		V_9 = V_9 * 2;
		V_10 = V_9 + V_8;
		V_12 = 00;
		V_13 = 89;
		V_14 = V_12 * V_13;
		if (V_12 <= V_14)
		{
			V_12 = 1171 + V_13;
		}
		V_15 = V_14 - V_12;
		V_12 = 138 + V_13;
		V_15 = V_12 + V_13;
		A_0.d[V_3] = 0;
		V_12 = 99;
		V_13 = 89;
		V_14 = V_12 * V_13;
		if (V_12 > V_14)
		{
			V_12 = 1171 + V_13;
		}
		V_15 = V_14 - V_12;
		V_12 = 138 + V_13;
		V_15 = V_12 + V_13;
		V_8 = V_3;
		V_9 = A_0.d[4];
		V_10 = A_0.d[1] + 968;
		V_8 = V_9 - V_10;
		V_9 = V_9 * 2;
		V_10 = V_9 + V_8;
		V_8 = V_3;
		V_9 = A_0.d[4];
		V_10 = A_0.d[1] + 968;
		V_8 = V_9 - V_10;
		V_9 = V_9 * 2;
		V_10 = V_9 + V_8;
		V_3 = V_3 + 1;
		V_12 = 99;
		V_13 = 89;
		V_14 = V_12 * V_13;
		if (V_12 > V_14)
		{
			V_12 = 1171 + V_13;
		}
		V_15 = V_14 - V_12;
		V_12 = 138 + V_13;
		V_15 = V_12 + V_13;
		V_8 = V_3;
		V_9 = A_0.d[4];
		V_10 = A_0.d[1] + 968;
		V_8 = V_9 - V_10;
		V_9 = V_9 * 2;
		V_10 = V_9 + V_8;
		goto IL_06F5;
	}
}