#include "iostream.h"
#include <process.h>

char charconv(char charorig)
{
	if ((charorig < 32)) return charorig+32; //33
	else if (charorig > 126) return charorig-128; // 126
	else if ((charorig > 96) && (charorig < 123)) return charorig-32; // 95
	else return charorig;
}

bool checkstr(char *str)
{
	for (int i=0;i<5;i++)
	{
		if (charconv(str[i])!=str[i]) return false;
	}
	return true;
}

__int64 strint(char *str)
{
	__int64 m;
	m=0;
	for (int i=4;i>=0;i--)
	{
		m=m*(__int64)256+(__int64)str[i];
	}
	return m;
}

void intstr(__int64 w, char* str)
{
	__int64 w1=w;
	for (int i=0;i<5;i++)
	{
		str[i]=w1%(__int64)256;
		w1=w1/(__int64)256;
	}
}

void printint64(__int64 w)
{
	int w1, w2;
	w1=w/(__int64)100000;
	w2=w%(__int64)100000;
	cout << w1 << w2 << endl;
}

void strconv(char *str1, char *str2, char *str3, char *str4, char *str5)
{
	__int64 w1, w2, w3, w4, w5, w;
	w2=strint(str2);
	w3=strint(str3);
	w4=strint(str4);
	w5=strint(str5);
	w=44261125337190;
	w=w/(__int64)255;
	w1=(w-w2/(__int64)8-w3/(__int64)16-w4/(__int64)32-w5/(__int64)64)*(__int64)4;
	intstr(w1,str1);
	str1[5]=0;	
}

void change1(char *str1, char *str2, char *str3, char *str4, char *str5)
{
	for (int i=0;i<4;i++)
	{
		if (str1[i]>128) str2[i+1]=charconv(str2[i+1]+1);
		else if (str1[i]>96) str4[i+1]=charconv(str4[i+1]+1);
		if (str1[i]<32) str4[i+1]=charconv(str4[i+1]-1);
	}
	if (str1[4]<32) str2[4]=charconv(str2[4]+64-2*str1[4]);
	if (str1[4]>96) str2[4]=charconv(str2[4]+(str1[4]-96)*2);
	strconv(str1,str2,str3,str4,str5);
}

int allcharxor(char *str1, char *str2, char *str3, char *str4, char *str5)
{
	int a=1;
	int i;
	for (i=1;i<5;i++) a = a ^ (int) str1[i];
	for (i=0;i<5;i++) a = a ^ (int) str2[i];
	for (i=0;i<5;i++) a = a ^ (int) str3[i];
	for (i=0;i<5;i++) a = a ^ (int) str4[i];
	for (i=0;i<5;i++) a = a ^ (int) str5[i];
	return a;
}

void change2(char *str1, char *str2, char *str3, char *str4, char *str5, int a, int i1)
{
	int i,j;
	i=i1 % 4;
	j=i1 / 4;
	if (i==0) str5[j]=charconv(str5[j] ^ a);
	if (i==1) str4[j]=charconv(str4[j] ^ a);
	if (i==2) str3[j]=charconv(str3[j] ^ a);
	if (i==3) str2[j]=charconv(str2[j] ^ a);
}

int main()
{
	char str2[5],str3[5],str4[5],str5[5];
	char str1[6];
	int i;
	cout << "Enter four 5-char strings for starting keygenning:\n";
	cin >> str2;
	for (i=0;i<5;i++) str2[i]=charconv(str2[i]);
	cin >> str3;
	for (i=0;i<5;i++) str3[i]=charconv(str3[i]);
	cin >> str4;
	for (i=0;i<5;i++) str4[i]=charconv(str4[i]);
	cin >> str5;
	for (i=0;i<5;i++) str5[i]=charconv(str5[i]);
	strconv(str1,str2,str3,str4,str5);
	while (!(checkstr(str1)))
	{
		change1(str1,str2,str3,str4,str5);
	}
	int a=allcharxor(str1,str2,str3,str4,str5);
	i=0;
	while (a != 0)
	{
		change2(str1,str2,str3,str4,str5,a,i);
		strconv(str1,str2,str3,str4,str5);
		while (!(checkstr(str1)))
		{
			change1(str1,str2,str3,str4,str5);
		}
		a=allcharxor(str1,str2,str3,str4,str5);
		i++;
		if (i>19) i=0;
	}
	cout << str1 << str2 << str3 << str4 << str5 << endl;
	system("pause");
	return 0;
}
