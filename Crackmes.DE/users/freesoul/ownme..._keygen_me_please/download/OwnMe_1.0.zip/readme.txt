Hi! for those who remember my GreenEye, this is the next one :)
A bit longer... and I think a bit harder too 

Have fun with this one :D
