// WARNING:This code is provided as is.It may be buggy, slow, unreadable.
// If you want better code go hire a team of skilled programmers.


#include "stdafx.h"
extern "C"
{
	#include "miracl.h"
}
#define nums_len 32
big nums[nums_len];
big W;

void ReCurse(int flags[nums_len],int depth,big t)
{
	flags[depth]=0;
	add(t,nums[depth],t);
	int c = compare(t,W);
	if(c==-1)
	{
		if(depth==nums_len-1)
			{
				flags[depth]=0;
				subtract(t,nums[depth],t);
				return;
		}
		flags[depth]=1;
		ReCurse(flags,depth+1,t);
	}
	if(c==0)
	{

		flags[depth]=1;
		printf("Flags: ");
		for(int i=0;i<nums_len;i++){
			if(flags[i]==1){printf("1");}else{printf("0");}
					}
		printf("Serial: ");
		
		for(int i=nums_len-1;i>0;){
			int serialbyte=0;
			for(int j=0;j<4;j++)
			{
					if(flags[i-j]==1){
					if(j==0)serialbyte+=8;
					if(j==1)serialbyte+=4;
					if(j==2)serialbyte+=2;
					if(j==3)serialbyte+=1;
									  }
				
			}
			printf("%X",serialbyte);
			i-=4;
									}
		
	}
	if(depth==nums_len-1)
	{
		flags[depth]=0;
		subtract(t,nums[depth],t);
		return;
	}
	flags[depth]=0;
	subtract(t,nums[depth],t);
	ReCurse(flags,depth+1,t);
	
}
int _tmain(int argc, _TCHAR* argv[])
{
    
    miracl *mip=mirsys(4096,16);
	char *strs[nums_len];
	int flags[nums_len];
	int i;
	big t;

	for(i=0;i<nums_len;i++){
	flags[i]=0;
					}
	strs[0]="92AFFAB3787FE";
	strs[1]="18BFE189042AF";
	strs[2]="4CA99D6499C67";
	strs[3]="6BA6C2DA9544B";
	strs[4]="5BA8CDCD7A940";
	strs[5]="6A97828B0EDC3";
	strs[6]="2383C49CFC03B";
	strs[7]="84723DBE2A779";
	strs[8]="68752D4B7845F";
	strs[9]="4C7B5F697A50D";
	strs[10]="C434C119DA3";
	strs[11]="144F6D80868DC";
	strs[12]="D3A0E775AD22";
	strs[13]="6BFB74ADF3A42";
	strs[14]="7DAD7AC17AD8";
	strs[15]="3F373A3273355";
	strs[16]="7327282EBE514";
	strs[17]="8941CAB88C39F";
	strs[18]="1AC22E467E5B3";
	strs[19]="37A394651C895";
	strs[20]="3178A3C9C7E62";
	strs[21]="24BECBDC522B9";
	strs[22]="2AEC418AD2551";
	strs[23]="887F5CACF5202";
	strs[24]="31659AF72F722";
	strs[25]="21D3515CE8BD";
	strs[26]="168F0B45439C1";
	strs[27]="502DDEDF4B9F1";
	strs[28]="670BCFB9F243D";
	strs[29]="7B22A7642DDAC";
	strs[30]="2427B4D9CDADB";
	strs[31]="1F7882DE0C221";
	
	for(i=0;i<nums_len;i++){
	nums[i]=mirvar(0);
	instr(nums[i],strs[i]);
					}
	
	char *Wstring ="2DF12B91CE8EEA";
	W=mirvar(0);
	instr(W,Wstring);

	/*
				t=mirvar(0);
				add(t,nums[1],t);
				add(t,nums[3],t);
				add(t,nums[4],t);
				add(t,nums[14],t);
				add(t,nums[15],t);
				add(t,nums[17],t);
				add(t,nums[19],t);
				add(t,nums[22],t);
				add(t,nums[23],t);
				add(t,nums[30],t);
				add(t,nums[31],t);
				int c = compare(t,W);
				if(c==0){printf("GREAT SUCCESS!");}else{printf("This sucks!");}
	*/
	printf("Wait ");
	flags[0]=1;
	ReCurse(flags,1,nums[0]);
	flags[0]=0;
	t=mirvar(0);
	ReCurse(flags,1,t);
	
return 0;

}

