require 'digest/sha1'

puts "Keygen for Freesoul's Keygenme \"Problem\" - Numernia/crackmes.de/2010\nUsername:"

sha1 = (Digest::SHA1.hexdigest gets.chomp!).to_i(16)
serial = 0x6B9BA92BE20F44012348606AF8707FFF - ((sha1 * 0xBEBEC0CAC01A) % 0x26F3270D2D32C4B87778D88179AFF490)

puts "Serial: #{serial.to_s(16)}"