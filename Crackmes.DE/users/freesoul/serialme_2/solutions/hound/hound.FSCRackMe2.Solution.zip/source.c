#include <stdio.h>
#include <windows.h>

UINT GenerateSerial(LPTSTR szName) {
	TCHAR szOutput[32], szHashOne[16], szHashTwo[16], szHashThree[16], tcSingle, tcTemp;
	UINT i, j, k, l, iNameLength, iHashLength;

	TCHAR szSpecial[] = "Z00YWABKKD28LHMFNOP05Q4SI37TWRUE8VVUGUL9AB9AZHGZZC0";
	TCHAR szSpecial2[] = "XYPO";
	TCHAR szSpecial3[] = "ACKBWNKKHD";
	
	iNameLength = strlen(szName);

	if (iNameLength <= 3)
	{
		printf("Name too short\n");
		return 1;
	}

	szOutput[0] = 0x4E;
	szOutput[1] = 0x61;
	szOutput[2] = 0x52;
	szOutput[3] = 0x46;

	for (i=0, j=0; i < iNameLength; i++)
		j += *(szName + i);

	k = j * 3;
	k = k << 5;
	_itoa(k, szHashOne, 10);

	iHashLength = strlen(szHashOne);

	for (i=0; i<=4; i++) {
		j = iHashLength - i;
		tcSingle = szHashOne[j];
		tcSingle -= 0x30;
		tcSingle *= i;
		tcSingle++;
		tcTemp = tcSingle;

		if (tcTemp <= 0x32) {
			if (i==0) {
				tcTemp = 0x35 - iNameLength;
				tcTemp = szSpecial[tcTemp];
				szOutput[4+i] = tcTemp;
			}
			else {
				tcTemp = szSpecial[tcTemp];
				szOutput[4+i] = tcTemp;
			}
		}
		else
		{
			printf("Got to TODO section...\n");
		}
	
	}

	for (i=0, j=0; i < iNameLength; i++) {
		j++;
		if (j > 3)
			j = 0;
	}

	tcTemp = szSpecial2[j];
	szOutput[9] = tcTemp;

	tcTemp = *(szName + iNameLength - 1);
	tcTemp = toupper((int)tcTemp);

	if (tcTemp <= 'M') {
		tcTemp += 2;
	}
	else {
		tcTemp--;
	}
	szOutput[10] = tcTemp;

	tcSingle = toupper(*(szName + iNameLength - 1));
	tcTemp = toupper(*(szName));

	for (i=1; i<=3; i++) {
		if (tcSingle <= 'M') {
			tcTemp = tcSingle + i;
			szOutput[i+10] = tcTemp; 

		}
		else {
			tcTemp = tcSingle - i;
			szOutput[i+10] = tcTemp;

		}

		tcSingle = toupper(*(szName));

		if (tcSingle <= 'M') {
			tcTemp = tcSingle + i;
			szOutput[17-i] = tcTemp;

		}
		else {
			tcTemp = tcSingle - i;
			szOutput[17-i] = tcTemp;

		}
		
		tcSingle = toupper(*(szName + iNameLength - 1));
	}		



	for (i=0, j=0, l = 0; i<iNameLength; i++) {
		l = *(szName + i);
		l *= i;
		j += l;
	}

	j += 0x186A0;
	j -= iNameLength;
	
	_itoa(j, szHashTwo, 10);

	for (i=1; i <= 6; i++) {
		szOutput[16+i] = szHashTwo[i-1];
	}

	szOutput[23] = 0x2D;

	for (i=17, j=0; i<=22; i++) {
		j += szOutput[i];

	}

	_itoa(j, szHashThree, 10);
	
	tcTemp = szHashThree[0];

	szOutput[24] = szSpecial3[tcTemp - 0x30];

	tcTemp = toupper(*(szName + 1));	
	tcTemp -= 0x41;

	if (tcTemp > 0x19)
		return 1;
	else {
		switch(tcTemp) {

		case 1:
		case 13:
		case 15:
			tcTemp = 7;
			break;
		case 2:
		case 16:
			tcTemp = 6;
			break;
		case 4:
		case 20:
			tcTemp = 4;
			break;
		case 5:
		case 6:
		case 7:
		case 8:
		case 9:
		case 10:
		case 12:
		case 21:
			tcTemp = 3;
			break;
		case 3:
		case 11:
		case 19:
			tcTemp = 5;
			break;
		case 0:
		case 14:
			tcTemp = 8;
			break;
		case 17:
		case 18:
		case 25:
			tcTemp = 0;
			break;
		case 22:
		case 24:
			tcTemp = 2;
			break;
		case 23:
			tcTemp = 1;
			break;
		}

	}

	tcTemp += 0x41;
	
	iHashLength = strlen(szHashThree);

	tcTemp += szHashThree[iHashLength - 1];

	tcTemp -= 0x30;

	szOutput[25] = tcTemp;
	szOutput[26] = 0x44;

	szOutput[27] = '\0';

	printf("Name: %s\n", szName);
	printf("Serial = %s\n", szOutput);

	return 0;
}


int main()
{
	LPTSTR szName = "swurlystz";
	GenerateSerial(szName);

	return 0;
}
	

	
