//FSKeyGen - KeyGen program for freesoul's SerialMe #2
//Author - gibz (ct_bored@yahoo.com)
//
//This program is a big ugly mess that was thrown together rather rapidly, but it does the job
//Parts of it could certainly be optimized, but I wanted to keep it closer to the source disassembly
//I will attempt to answer any relevant questions, but don't ask me something stupid :)

#include <stdio.h>
#include <string.h>
#include <iostream>

//string constants from the source program
const char *strSerialStart = "NaRF";
const char *strLookup = "Z00YWABKKD28LHMFNOP05Q4SI37TWRUE8VVUGUL9AB9AZHGZZC0";
const char *strLookupSmall = "XYPO";
const char *strLookup3 = "ACKBWNKKHD";

//this may be done in the program with a switch, a bit hard to tell
//they seem random though, so I'll just hardcode them like this
const int nCharacterOffsets[] = { 8, 7, 6, 5, 4, 3, 3, 3, 3, 3, 3, 5, 6, 7, 8, 7, 6, 0, 0, 5, 4, 3, 2, 1, 2, 0, 3 };


int main(int argc, char *argv[])
{
	if (argc < 2)
	{
		printf("Usage: FSKeyGen <name>\n");
		return -1;
	}

	char *szName = argv[1];

	//because otherwise we'd break things
	int nNameLen = (int)strlen(szName);
	if (nNameLen <= 3)
	{
		printf("Name must be at least 4 characters!\n");
		return -1;
	}
	else if (nNameLen > 50)
	{
		printf("Name cannot be more than 50 characters!\n");
		return -1;
	}

	char szSerial[28] = {0};

	//all serials start with this character series
	strcpy(szSerial, strSerialStart);

	//sum the username
	int nNameSum = 0;
	for (int i = 0; i < nNameLen; i++)
	{
		//do this check here to save on looping
		if (!isalnum(szName[i]))
		{
			printf("Name must contain only letters and numbers!\n");
			return -1;
		}

		//this isn't checked directly by the program
		//but the algorithm prevents using names with numbers in the first or last place
		if (((i == 0) || (i == nNameLen-1)) && !isalpha(szName[i]))
		{
			printf("Name cannot have a number in the first or last positions!\n");
			return -1;
		}

		nNameSum += szName[i];
	}
	//the funny math in the program just results in this
	nNameSum *= 96;

	//to a string
	char sumStr[8];
	sprintf(sumStr, "%d", nNameSum);
	int nSumLen = (int)strlen(sumStr);

	//next 5 characters are based on the lookup string and the name sum string
	char x = 0;
	int nLookupIndex = 0;
	for (int i = 0; i < 5; i++)
	{
		x = sumStr[nSumLen - i];
		x -= 48;	// 48 is '0'
		x *= i;
		x++;

		//this test happens in the program, but I don't think it can ever occur
		if (x > 50)
		{
			printf("Oops! This shouldn't ever be able to happen!\n");
			return -2;
		}

		if (i == 0)
			nLookupIndex = 53 - nNameLen;
		else
			nLookupIndex = x;

		szSerial[4 + i] = strLookup[nLookupIndex];
	}

	//next char uses a loop that is equivalent to % 4
	nLookupIndex = nNameLen % 4;
	szSerial[9] = strLookupSmall[nLookupIndex];

	//next char is just based on the last character in the username
	const char cNameLastUpper = toupper(szName[nNameLen-1]);
	if (cNameLastUpper > 'M')
		x = cNameLastUpper - 1;
	else
		x = cNameLastUpper + 2;

	szSerial[10] = x;

	//next 6 chars use the first and last letters in the username, alternating front and back
	const char cNameFirstUpper = toupper(szName[0]);
	for (int i = 1; i < 4; i++)
	{
		//front part
		if (cNameLastUpper > 'M')
			x = cNameLastUpper - i;
		else
			x = cNameLastUpper + i;

		szSerial[10 + i] = x;

		//back part
		if (cNameFirstUpper > 'M')
			x = cNameFirstUpper - i;
		else
			x = cNameFirstUpper + i;

		szSerial[17 - i] = x;
	}

	//next 6 characters are formed from math on the username

	//calculate new name sum
	nNameSum = 0;
	for (int i = 0; i < nNameLen; i++)
		nNameSum += szName[i] * i;

	nNameSum += 100000 - nNameLen;

	//write the sum as a string to the serial
	sprintf(szSerial+17, "%d", nNameSum);

	//next character is always a '-'
	szSerial[23] = '-';

	//next 2 chars are based on the sum of the previous group

	//calculate the sum of the previous 6 characters in the serial
	int nSerialSum = 0;
	for (int i = 17; i < 23; i++)
		nSerialSum += szSerial[i];

	//as a string
	sprintf(sumStr, "%d", nSerialSum);

	//first char uses the numeric value of the first digit as a lookup
	nLookupIndex = sumStr[0] - '0';
	szSerial[24] = strLookup3[nLookupIndex];

	//the next char requires a lookup into an offset table, based on the character value
	x = toupper(szName[1]) - 'A';
	int nOffset;

	//this happens if the szName[1] is a number
	if ((unsigned char)x > 25)
		nOffset = nCharacterOffsets[sizeof(nCharacterOffsets) / sizeof(nCharacterOffsets[0]) - 1];
	else
		nOffset = nCharacterOffsets[x];

	//next char uses the last digit in the summed string, with an added offset
	szSerial[25] = sumStr[strlen(sumStr)-1] + 'A' - '0' + nOffset;

	//last character is always 'D'
	szSerial[26] = 'D';


	//we're done!
	printf("Username: %s\nSerial number: %s\n", szName, szSerial);

	return 0;
}
