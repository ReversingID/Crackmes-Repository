Blueowls knapsack crackme
#########################

This crypto crackme uses a hard additive knapsack encoding  as public key,
and an easy knapsack as private key. Therefor only I can decode any number
encoded with it, or can I?

In this  crackme,  you will have  to step  into the role of  cryptanalist, 
trying to discover the secret  connection between the 64 numbers.  Several
algorithms are  already  known  to  attack  this kind  of knapsack,  it is
however down  to you in  which approach you want to  take in solving  this
problem.

To be able to get the "decoding prize" out of the zip file, you will have
to enter  the password which encoded equals B75B63369A52F5F30CFE5E642  ;).

Above all, have fun!

BlueOwl.