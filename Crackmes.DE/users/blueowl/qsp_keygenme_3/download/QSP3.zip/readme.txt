Quantity Serial Protection #Level 3#
by BlueOwl

Details:

 Anti-Cracking.......None
 Anti-Debugging......None
 Encryption..........None
 Packing.............None
 Serial..............64bit
 Language............Assembler
 Operating System....WinAll
 Difficulty..........Medium/Hard (Easy for you? :))

Mission:

 Creating a keygen. One thing i should note you: I would prefer
 it if you coded something to reverse the decode, over doing it
 all by hand. This is not meant as an endurance crackme, but one
 to exercise your coding skills. Good luck and HAVE FUN. :)

Notes:

 Before you start making your solution you can practise by
 reversing this small routine. Try to make the encoding for it. 

 decode:shl     eax, 1
        jnb     branch
        shl     eax, 1
        jb      leave2
 leave1:xor     eax, 03FAAB249h
        add     ecx, 0BD6A6556h
        retn
 leave2:xor     eax, 0DBC303A3h
        xor     ecx, 0DC8D203Eh
        retn
 branch:shl     eax, 1
        jnb     leave4
 leave3:xor     eax, 020CE735Ah
        add     ecx, 01D2102B2h
        retn
 leave4:xor     eax, 0FE2AB260h
        sub     ecx, 0CFFC4715h
        retn

User/Serial examples:

 BlueOwl / MELJNBOE-NPDLIHIE
 Branching4Ever / NPNIPEIM-PJMBOBMH

Extra:

 Greets go to Black Eye (on request ;))

 Thanks betatesters VxF, and especially Sinclaire. :)
