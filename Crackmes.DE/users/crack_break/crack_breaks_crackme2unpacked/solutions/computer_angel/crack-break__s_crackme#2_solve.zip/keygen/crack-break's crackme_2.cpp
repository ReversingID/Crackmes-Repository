// crack-break's crackme_2.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>
#include <stdio.h>
#include <conio.h>

int _tmain(int argc, _TCHAR* argv[])
{
	CHAR sComputerName[16];
	CHAR input_username[100];
	CHAR real_serial[255];
	CHAR tmp_str[255];
	size_t count;
	DWORD size=100;


	printf("Input username:");
	_cgets_s((PCHAR)input_username,100,&count);

	GetComputerNameA(sComputerName, &size);
	int len = lstrlenA(sComputerName);
	ZeroMemory(&sComputerName[len],100-len);
	int index = 0;
	DWORD hash=0x0040102B;
	do
	{
		hash += *(DWORD *)&sComputerName[index] ^ 0x41544B41;
		index += 2;
	}
	while ( index <= len );
	wsprintfA(real_serial, "CIB-%d-", hash);
	wsprintfA(tmp_str, "CIB-%d-", 0x4030E0);
	lstrcatA(real_serial, tmp_str);
    wsprintfA(tmp_str, "UI");
    lstrcatA(real_serial, tmp_str);

	printf("Serial = %s\n",real_serial);
	getchar();


	return 0;
}

