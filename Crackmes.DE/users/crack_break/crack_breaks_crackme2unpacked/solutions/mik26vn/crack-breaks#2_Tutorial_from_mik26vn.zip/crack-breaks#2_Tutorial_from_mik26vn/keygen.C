////////////////////////////////////////////////////////////////////////////
// Keygen for crack-break's crackme#2(unpacked)
//
// Published: 17. Jan, 2008
// URL: http://www.crackmes.de/users/crack_break/crack_breaks_crackme2unpacked/
// Keygen was written by mik26vn/tastatur -18.Jan.2008
//
// Recommended & thanks to: crackmes.de, reaonline.net, SeeknDestroy...
////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <string>
#include <cctype>

using namespace std;

int main()
{
	char szComp[64]; // Computer Name
	int  szlng=0;	 // Length of Computer Name
	long s=0x0040102B, s0=0, s1=0x00000111;

	char Table[4] = { 0x41, 0x4B, 0x54, 0x41 };
	int i=0;
	
  	cout << "Computer Name :";
  	cin >> szComp;

	szlng=strlen(szComp);			// EDX

	for (int j=0; j<szlng; j++) szComp[j]= toupper(szComp[j]); //Uppercase all characters of Computer Name
	for (int j=szlng; j<64; j++) szComp[j]= 0x00; // Fill Computer Name String with 00 after

	do
	{	
		s0 = 0;			// EAX
		for (int j=3;j>=0;j--)	// (Block 4bytes from Computer Name) XOR 0x41544B41
		{
			s0 = s0 * 256;
			s0 += long(szComp[i+j] ^ Table[j]);
		}

		s += s0;		// ADD ESI, EAX
		s1+= s0;		// Key for Windows Vista
		i += 2;			// INC ECX 2 times
	}
	while (i <= szlng);
	
	cout << "Valid Serial  :" << "CIB-" << s << "-CIB-4206816-UI" << endl; //CIB-4206816-UI is hardcoded!
	cout << "Vista Serial  :" << "CIB-" << s1 << "-CIB-4206816-UI" << endl;

  
	return 0;
}
