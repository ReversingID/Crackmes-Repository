#include <stdio.h>
#include <conio.h>
#include <string.h>
main()
{

      //I know this is not the best way to code, but it works :P
      char name[255],serial[255];
      char hash1[255] = "'TDHUWNHI", hash2[255] = "'DUFDL*EUBFL", hash3[255] = "'SBDOIHLNC", hash4[255] = "'SOB'DHCB'DUFDLBU", hash5[255] = ".WUHA)", hash6[255] = "'CUFDRKF", hash7[255] = ".TUI@CFHC'URKB]";
      printf("Crack-Break's KeygenMe3\n\nCoded by br0ken\n\n\n");
		  
	  printf("\n\nEnter your name (15,16 or 17 characters only!) : ");
      scanf("%s",&name);
      if(strlen(name)==15)
	  {
	  serial[0] = name[0]/16 + hash1[0]/4 + 32;
      serial[1] = name[2]/16 + hash1[2]/4 + 32;
      serial[2] = name[4]/16 + hash1[4]/4 + 32;
      serial[3] = name[6]/16 + hash1[6]/4 + 32;
      serial[4] = '\0';
	  printf("\n\nSerial : %s",serial);
	  
	  }
	  if(strlen(name)==16)
      {
      serial[0] = name[0]/4 + hash2[0]/8 + 32;
      serial[1] = name[3]/4 + hash2[3]/8 + 32;
      serial[2] = name[6]/4 + hash2[6]/8 + 32;
      serial[3] = name[9]/4 + hash2[9]/8 + 32;
      serial[4] = '\0';
	  printf("\n\nSerial : %s",serial);
	 
	  }
	  if(strlen(name)==17)
	  {
      serial[0] = name[0]/16+ hash4[0];
      serial[1] = name[4]/16 + hash4[4];
      serial[2] = name[8]/16 + hash4[8];
      serial[3] = name[12]/16 + hash4[12];
      serial[4] = '\0';
	  printf("\n\nSerial : %s",serial);
	  
	  }
	  getch();
      return 0;
}