Hello,

maybe you're wondering about this huge size of this crackme?
No fear, it's only full of media.
If you have done, you will see a miniature demo scene.
So find the keyfile! As solution, write a keygen.

bunnX