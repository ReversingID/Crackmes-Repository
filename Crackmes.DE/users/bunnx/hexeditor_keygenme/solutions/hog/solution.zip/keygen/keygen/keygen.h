#pragma once

#define NAME_MIN_LEN	0x3
#define	NAME_MAX_LEN	0x15
#define	NAME_KEY_LEN	0x1B

#define NORMAL_NAME_CLR	0x0
#define SHORT_NAME_CLR	0x00C0C0C0
#define WRONG_NAME_CLR	0x000000FF