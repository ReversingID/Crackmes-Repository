//Keygen for Hexeditor Keygenme by BunnX [http://crackmes.de/users/bunnx/hexeditor_keygenme/]
//by _hog
//--------------------------------------
/*
This is my very first soultion here. As the first attempt I've took the first unresolved case of intermediate difficulty level.
I wonder whether I did it right selecting the case from archive, hope it was not a serious violation of resource rules :)
This case seems to be pretty simple actually and I even know why it was labeled so seriously as for "very professionals only".
Think there's no need to describe all the details of research process as all of them is commonly obvious, so just the main these.
1. "hexeditor.exe" has one procedure that is encrypted by simple xor operation, using the key of 0x14 bytes long. Only prolog and epilog of function remains unaffected. 
   The activator application will replace this piece of code after decryption if MD5 check will allow to do it. The hash value is hardcoded inside the activator.
2. Basically the decoding sequence looks like follows:
    - "Key" string transformed from ASCII to inner representation by array of substitution then expansion for each character of the string:
	   e.g. the "Key" is: "74 78 39 53 71 47 51 45 54 6A 56 6D 45 6F 2B 61 62 63 4E 61 4A 57 63 6C 31 44 61" - "tx9SqGQETjVmEo+abcNaJWcl1Da"
	   will be converted to: B7 1F 52 A8 64 04 4E 35 66 12 8F 9A 6D C3 5A 25 67 25 D4 36 80

	   acSubstArray[0x74] -> 0x2D (the position of "t" character in alphabet)
	   0x2D -> 101101 (each character in inner representation is 6-bit long)

	   acSubstArray[0x78] -> 0x31
	   0x31 -> 110001
	   
	   101101xx or 11xxxx -> 10110111 -> 0xB7
	   and so on...

	- "Name" string expanded up to 0x15 characters long:
	   e.g. the "Name" is "Test" will be expanded to "TestTestTestTestTestT"

	- then expanded name string will be xored with converted key value:
	   B7 1F 52 A8 64 04 4E 35 66 12 8F 9A 6D C3 5A 25 67 25 D4 36		(key value)
	   xor
	   54 65 73 74 54 65 73 74 54 65 73 74 54 65 73 74 54 65 73 74		(name string)
	   =
	   E3 7A 21 DC 30 61 3D 41 32 77 FC EE 39 A6 29 51 33 40 A7 42		(thus, we've got a code decryption key)

	-  the last action is obvious - just xor each byte of the key with appropriate byte of encoded data, then MD5, then "we happy".
 3. Where I got an actual decryption key value? It's quite simple due to a xor encoding. Just take enough amount of encoded data then divide it on fragments of key length, then take
    the most frequent byte for each column - it will be lakely a byte of the key value for this position. Then try to decrypt function's body and if it will be disassembled fine, so
	you've got a key too. If you got just partially valid code - check the bytes of key in the wrong positions and try to take the next value by frequency for this byte position.
	A couple of attempts will be enough to obtain the valid key value. That's all!
 4. An activator application itself is very raw and has a bunch of weakness and at least one serious bug as a result of using string processing operations for a byte array,
    where 0x00 value may be encountered before the actual string's end.

	Think this will be enough. And sorry for the bad English as I'm not a native speaker :)
*/

#include <Windows.h>
#include "keygen.h"
#include "resource.h"

const char acAlph[]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

unsigned char* GenerateKey(unsigned char* pacN, int iNl)
{
	int iI, iR;
	unsigned char cC;
	unsigned char* pacK;
	union
	{
		unsigned char acN[NAME_MAX_LEN];
		unsigned __int32 auV[6];
	};

	unsigned char acK[NAME_KEY_LEN+1];

	if(!(iI=iNl)) return NULL;
	while(iI) if(!strchr(acAlph,pacN[--iI])) return NULL;	//Simple safety check (unnecessary action)

	do
	{
		iR=NAME_MAX_LEN-iI;
		memcpy(acN+iI,pacN,(iR<iNl)?iR:iNl);				//Name expansion
		iI+=iNl;
		
	}while(iI<NAME_MAX_LEN);

	auV[0]^=0xDC217AE3;					//Append an encryption key
	auV[1]^=0x413D6130;
	auV[2]^=0xEEFC7732;
	auV[3]^=0x5129A639;
	auV[4]^=0x42A74033;
	auV[5]^=0xDC217AE3;
	if(memchr(acN,0,iI)) return NULL;	//Exclude the value that has a terminator character before the potential string's end

	for(iI=iR=0;iI<NAME_MAX_LEN;iR++)	//6-bit view to an ASCII representation (quite inefficient method)
	{
		switch(iR&3)
		{
		case 0:
			cC=acN[iI]>>2;
			break;
		case 1:
			cC=(acN[iI++]&3)<<4;
			cC|=acN[iI]>>4;
			break;
		case 2:
			cC=(acN[iI++]&0xF)<<2;
			cC|=acN[iI]>>6;
			break;
		default:
			cC=acN[iI++]&0x3F;
		}

		acK[iR]=acAlph[cC];
	}

	pacK=(unsigned char*)calloc(NAME_KEY_LEN+1,sizeof(char));
	memcpy(pacK,acK,NAME_KEY_LEN);
	return pacK;
}

//Here's the ugly GUI processing code.
int CALLBACK DialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	HWND hE;
	unsigned char* pacK;
	union
	{
		unsigned char acN[NAME_MAX_LEN+1];
		unsigned __int16 uNl;
	};

	switch(uMsg)
	{
	case WM_INITDIALOG:
		hE=GetDlgItem(hwndDlg,IDC_EDIT1);
		SendMessage(hE,EM_LIMITTEXT,NAME_MAX_LEN,NULL);
		SetFocus(hE);
		break;

	case WM_CLOSE:
		EndDialog(hwndDlg,true);
		break;

	case WM_CTLCOLOREDIT:
		if(lParam==(LPARAM)GetDlgItem(hwndDlg,IDC_EDIT1))
		{
			uNl=NAME_MAX_LEN+1;
			if(pacK=GenerateKey(acN,SendMessage((HWND)lParam,EM_GETLINE,0,(LPARAM)&acN)))
			{
				SetTextColor((HDC)wParam,(SendMessage((HWND)lParam,EM_LINELENGTH,0,NULL)<NAME_MIN_LEN)? SHORT_NAME_CLR:NORMAL_NAME_CLR);
				free(pacK);
			}
			else
			{
				SetTextColor((HDC)wParam,WRONG_NAME_CLR);
			}
		}
		return (int)GetStockObject(WHITE_BRUSH);

	case WM_COMMAND:
		if(LOWORD(wParam)==IDC_EDIT1)
		{
			switch(HIWORD(wParam))
			{
			case EN_CHANGE:
				if(uNl=(unsigned short)SendMessage((HWND)lParam,EM_LINELENGTH,0,NULL))
				{
					uNl=NAME_MAX_LEN+1;
					if(pacK=GenerateKey(acN,SendMessage((HWND)lParam,EM_GETLINE,0,(LPARAM)&acN)))
					{
						SendMessage(GetDlgItem(hwndDlg,IDC_EDIT2),WM_SETTEXT,NULL,(LPARAM)pacK);
						free(pacK);
					}
					else
					{
						SendMessage(GetDlgItem(hwndDlg,IDC_EDIT2),WM_SETTEXT,NULL,(LPARAM)"");
					}
				}
				else
				{
					SendMessage(GetDlgItem(hwndDlg,IDC_EDIT2),WM_SETTEXT,NULL,(LPARAM)"");
				}
				break;
			}
		}
	}

	return false;
}

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	DialogBoxParam(hInstance,MAKEINTRESOURCE(IDD_DIALOG1),NULL,&DialogProc,NULL);
	return NULL;
}



