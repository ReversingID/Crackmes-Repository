
Hexeditor crackme by bunnX

This crackme is a fully functional program (a little hexeditor), but.. you have to do something.
The hexeditor won't save your files, crack it! It's allowed and the idea behind this project. You can try to patch something, but i think it isn't the solution ;)
In fact it is: get a valid serial to a name of your choise and code a keygen.

Have fun!