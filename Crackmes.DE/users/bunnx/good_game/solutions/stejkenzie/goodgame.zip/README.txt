This is my first crackme, so please be keen on me.
I have seen iSSoGoo's solution and it's great, but I somehow managed to patch it
in a different way. Since I am not skilled in crackmes, I'm not sure if this solution
is even close to some "clean" solution or "good", but it works.

Here's (briefly) what I've done:

I tried renaming all the files, finding which are crucial and which are not.
That cut out the other two, leaving only the one with code. If the code is modified,
the program fould fail.

Then I started reversing.
Right before the "Testing CD drive." printing, there is a section that checks the code.
The loaded code is dependent on file - if it exists, it loads the code from file, if
it doesn't, it loads long "\x20" string - this happens on address 004021CF (REPS STOS BYTE PTR ES:[EDI]).
I tried messing with this piece of code to make it load the right code, but there was not enaugh
space for the instructions.

After a while, I was finally able to reverse that horrible checking loop starting at 00401623 and I
came to code like this:

loaded_from_file = 0x00333DA8
some_address = 0x00333D78

int counter = 0;
int check = 0;
while(counter < 0x0B)
{
	some_address[counter] = loaded_from_file[counter];
	// check = ?something?
	counter++;
}

Since this loop is really horribly written and the only thing it does can be written by REP MOVS instruction,
I took my chance here and replaced all those horrible instructions with few simple:

1) I loaded secret code into the loaded_from_file
2) I copied the contents of loaded_from_file to some_address
3) I moved the right contents into the EAX, so the 0041663 instruction (CMP EAX, 0B7) would pass.

From there, the secret code is written inside the program on the place where it would expect it (not so 
surprisingly) and it passes all the other checks. 

Please give me some feedback if this solution is even worthy or if it's not.
I can see that iSSoGoo's solution is far more complex, but I think mine is nice thanks to it's simplicity.

Thanks for nice crackme,

stejkenzie