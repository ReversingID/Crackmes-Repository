#include <stdio.h>

unsigned salt(unsigned hash, unsigned salt)
{
	unsigned tmp[2];
	tmp[0] = ~(salt & hash);
	tmp[1] = ~(hash & tmp[0]);
	tmp[0] = ~(salt & tmp[0]);

	return ~(tmp[0] & tmp[1]);
}

unsigned hash(const char* name)
{
	size_t len = strlen(name);
	size_t i;

	unsigned retn = 0;

	for(i = 0; i < len; i++)
	{
		int ch = name[i];
		unsigned tmp;
		ch &= 0x800001F;
		if(ch & 0x80000000)
		{
			ch--;
			ch |= 0xFFFFFFE0;
			ch++;
		}
		retn += (1 << (unsigned)ch) * name[i];
	}

	return retn;
}

int main(int argc, char* argv[])
{
	unsigned hashval;
	unsigned saltgroup_1;
	unsigned saltgroup_2;

	char buffer[18];
	memset(buffer, '\0', sizeof(buffer));

	if(argc != 2)
	{
		printf("Usage: %s <name>\n", argv[0]);
		return 0;
	}

	if(strlen(argv[1]) <= 4)
	{
		printf("Name must be > 4 characters\n");
		return 0;
	}

	hashval = hash(argv[1]);
	saltgroup_1 = salt(hashval, 0x2EFB3718) + salt(hashval, 0x32F54B88);
	saltgroup_2 = salt(hashval, 0x25B27AEF) + salt(hashval, 0x37075C49);

	sprintf(buffer, "%08X-%08X", saltgroup_1, saltgroup_2);

	printf("%s -> %s\n", argv[1], buffer);

	return 0;
}
