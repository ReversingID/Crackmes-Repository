#include <stdio.h>
#include <windows.h>
#include <commctrl.h> 
#include "resource.h"

#define TITLE "Ahmet Crackme#2 Keygen [freesoul]"

#pragma comment(lib, "comctl32.lib")

char* gen(char* name);
int algo(char* name);
int subalgo(int hash, int something);

HINSTANCE	hInst;

BOOL CALLBACK DialogProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{	

	switch (message)
	{    
	case WM_CLOSE:
		EndDialog(hWnd,0);
		break;

	case WM_COMMAND:
        switch (HIWORD(wParam))
        {
        case BN_CLICKED:
    		switch (LOWORD(wParam))
		    { 
            case IDGEN:


				//Gets name
				char *name;
				name = new char[50];
				GetDlgItemText(hWnd, IDNAME, name, 50);

				//checks if there is a name and >4
				if(strlen(name)<5)
					MessageBox(hWnd, "Name lenght must > 4", "Info", MB_OK);
				else
				SetDlgItemText(hWnd, IDSERIAL, gen(name)); 

                break;

             case IDABOUT:
				MessageBox(hWnd, "keygenned by freesoul... =)", "About", MB_OK);
                
                break;
		    }
            break;
        }
		break;

	case WM_INITDIALOG:
		// Load Icon
        SendMessage(hWnd,  WM_SETICON, ICON_SMALL,(LPARAM) LoadIcon(hInst, MAKEINTRESOURCE(IDI_ICON1)));
        SendMessage(hWnd,  WM_SETICON, ICON_BIG,(LPARAM) LoadIcon(hInst, MAKEINTRESOURCE(IDI_ICON1)));
		

		
		// Position the window
		RECT r;
		GetWindowRect(hWnd, &r);
		SetWindowPos(hWnd, 0, GetSystemMetrics(SM_CXSCREEN)/2-r.right/2, GetSystemMetrics(SM_CYFULLSCREEN)/2-r.bottom/2, r.right, r.bottom, 0);	

		// Set Window title
		SetWindowText(hWnd, TITLE);

		// Set windows username in textbox
		char *name;
		name = new char[32];
		DWORD len = 32;
		GetUserName(name, &len);
		SetDlgItemText(hWnd, IDNAME, name);

		// SetFocus
		SetFocus(GetDlgItem(hWnd, IDGEN));

		break;
	}
     return 0;
}

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{
	hInst=hInstance;
	InitCommonControls();
    DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_MAIN), NULL, (DLGPROC)DialogProc,0);
	return 0;
}

char* gen(char* name)
{

	int hash = algo(name);

	int a = 0x2EFB3718;
	int b = 0x32F54B88;
	int c = 0x25B27AEF;
	int d = 0x37075C49;

	int r1 = subalgo(hash, a) + subalgo(hash, b);
	int r2 = subalgo(hash, c) + subalgo(hash, d);

	char* serial;
	serial = new char[18];

	sprintf(serial, "%08X-%08X", r1, r2);

	return serial;

}


int algo(char* name)
{

signed int x, p, j;
j = 0;

unsigned int i;
for(i=0; i<strlen(name); i++)
{
x = name[i];
x = x & 0x8000001F; // so 0x..66 becomes 0x...06

if(x < 0)
{ 
x--;
x = x | 0x0FFFFFFE0; // bitwise OR
x++;
}

p = 1 << x;
p = name[i] * p;

j += p;
}

return j;
}



int subalgo(int hash, int something)
{
int a, b, c;

a = something & hash;
b = ~a; // not bitwise

c = b; // save x in p


a = hash & c;


a = ~a; // not 

c = c & something;
c = ~c; // not

a = a & c;
a = ~a; // not

return a;
}
