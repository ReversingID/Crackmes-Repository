#pragma once

class Random
{
public:
	Random(int Seed);
	int Next() { return this->InternalSample(); }
	int Next(int maxValue) { return (int) (this->Sample() * maxValue); }
	int Next(int minValue, int maxValue);
	double NextDouble() { return this->Sample(); }
	double Sample() { return (this->InternalSample() * 4.6566128752457969E-10); }

private:
	double GetSampleForLargeRange();
	int InternalSample();
	int inext;
	int inextp;
	int MBIG;
	int MSEED;
	int MZ;
	int SeedArray[0x38];
};
