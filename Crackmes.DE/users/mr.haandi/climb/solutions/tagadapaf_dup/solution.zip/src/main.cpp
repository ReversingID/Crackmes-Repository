#include <windows.h>
#include <string>
#include <sstream>
#include "resource.h"
using namespace std;

const char Title[]="KeyGen for MR.HAANDI's Climb";
const char Date[]="02/06/2008";

/*****************************
KeyGen() algo
*****************************/
#include "big.h"
#include "Random.h"

Miracl mip(100);
typedef unsigned int uint;

template <typename T>
const std::string to_string(const T& t)
{
	stringstream ss;
	ss << t;
	return ss.str();
}

string to_unicode(const string& str)
{
	string res = "";
	for (int i = 0; i < str.length(); i++) {
		res += str[i];
		res += '\0';
	}
	res += '\0';
	return res;
}

int GetHashCode(const string& str)
{
	string str_unicode = to_unicode(str);
    const char* chPtr = str_unicode.c_str();
    int num = 0x15051505;
    int num2 = num;
    int* numPtr = (int*) chPtr;
    for (int i = str.length(); i > 0; i -= 4)
    {
        num = (((num << 5) + num) + (num >> 0x1b)) ^ numPtr[0];
        if (i <= 2)
        {
            break;
        }
        num2 = (((num2 << 5) + num2) + (num2 >> 0x1b)) ^ numPtr[1];
        numPtr += 2;
    }
    return (num + (num2 * 0x5d588b65));
}

Big genRandomBits(int bits, Random& rand)
{
	Big data = ::rand(bits, 2);

    int num = bits >> 5;
    int num2 = bits & 0x1f;
    if (num2 != 0)
    {
        num++;
    }
    for (int i = 0; i < num; i++)
    {
        data[i] = (uint) (rand.NextDouble() * 4294967296);
    }
    for (int j = num; j < 70; j++)
    {
        data[j] = 0;
    }
    if (num2 != 0)
    {
        uint num5 = ((uint) 1) << (num2 - 1);
        data[num - 1] |= num5;
        num5 = ((uint) (-1)) >> (0x20 - num2);
        data[num - 1] &= num5;
    }
    else
    {
        data[num - 1] |= 0x80000000;
    }
	return data;
}

Big genPseudoPrime(int bits, int confidence, Random& rand)
{
    Big integer;
	(&mip)->NTRY = confidence;
    for (bool flag = false; !flag; flag = prime(integer))
    {
        integer = genRandomBits(bits, rand);
        integer[0] |= 1;
    }
    return integer;
}

string KeyGen(const string& name)
{
	int modificator = 1337;

	Random rand = GetHashCode(name);
	Big modulus = genPseudoPrime(0x40, 10, rand);

	gprime(2000);
	int index = 7;
	while ( gcd(modulus - 1, (&mip)->PRIMES[index]) != 1)
		index++;
	index = (&mip)->PRIMES[index];

	Big part2 = rand.Next(1, 0x7fffffff);

	Big a = 0;
	for (int i = 0; i != index; i++)
		a += rand.Next(1, 0x7fffffff);

	Big N = modulus;
	Big p = index;
	Big m = modificator;

	Big p_inv = inverse(p, N-1);
	Big part1 = pow(a*inverse(pow(m, 3), N) + pow(part2, p, N), p_inv, N) - part2;

	(&mip)->IOBASE = 0x24;
	return to_string(part1 % N);
}

/*****************************
DLG stuff..
*****************************/

// bitmap
HBITMAP hBitmap;
HBRUSH hBrush;

BOOL CALLBACK DialogProc( HWND hwndDlg, UINT uMsg ,WPARAM wParam, LPARAM lParam )
{
	switch( uMsg )
	{
	case WM_CLOSE:
		EndDialog( hwndDlg, 0 );
		break;

	case WM_INITDIALOG:
		srand( GetTickCount() );
		SetWindowText( hwndDlg, Title );
		SetDlgItemText( hwndDlg, IDC_DATE, Date );
		SetWindowPos(hwndDlg,HWND_TOPMOST,0,0,0,0,SWP_NOSIZE|SWP_NOMOVE);

		SetDlgItemText( hwndDlg, IDC_SERIAL, "Enter your name..." );
		break;

	case WM_COMMAND:
		if( LOWORD(wParam) == IDC_NAME )
		{
			char buffer[ 512 ];

			if( !GetDlgItemText( hwndDlg, IDC_NAME, buffer, 511 ) )
			{
				SetDlgItemText( hwndDlg, IDC_SERIAL, "Enter your name..." );
				break;
			}

			SetDlgItemText( hwndDlg, IDC_SERIAL, KeyGen(buffer).c_str() );
			InvalidateRect( GetDlgItem(hwndDlg, IDC_NAME), NULL, true );
			InvalidateRect( GetDlgItem(hwndDlg, IDC_SERIAL), NULL, true );
		}

		break;


	case WM_CTLCOLORDLG:
	case WM_CTLCOLORLISTBOX:
	case WM_CTLCOLOREDIT:
	case WM_CTLCOLORSTATIC:
		HDC hdc;
		hdc = ( HDC )wParam;
		SetTextColor( hdc, RGB( 255, 255, 255 ));
		SetBkMode( hdc, TRANSPARENT	);
		return ( BOOL )hBrush;
	}
	return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	hBitmap = LoadBitmap( hInstance, MAKEINTRESOURCE( IDB_MAIN ));
	hBrush = CreatePatternBrush( hBitmap );

	DialogBox( hInstance, MAKEINTRESOURCE( IDD_DLG ), 0, DialogProc );

	DeleteObject( hBitmap );
	DeleteObject( hBrush );

	return 0;
}