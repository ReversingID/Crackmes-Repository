Welcome to the Substitutions keygenme.

This keygenme is a simple demonstration
how reversers could potentially be tricked
into telling too much.
You will be dealing with a few substitutions.
The algorithm is simple enough, 
but not as simple as you might think at first.

A valid solution is a keygen with source code.
Patching to get the "good boy" message or 
injecting your code to let the keygenme 
generate serials itself is no fun. 

Goals:

    Write your own key generator to 
    produce a valid signature for any given name.


Bonus:

    Gold:   Don't get tricked and say nope.
            
    Silver: Don't get tricked while still saying yes.

    Bronze: Get tricked and say whatever you want.


Rules:
    
    No patching. No code injection.


Example (Data, Signature) pairs:

    (MR.HAANDI, 08-D4-E2-CE), (YourName, 88-4C-1A-26)


[SPOILER] My keygen source code length in C does not exceed 1024 symbols. [SPOILER]
	
	
Greets:
bLaCk-eye, KernelJ, jB, divinomas, halsten, Numernia
and other great reversers out there.


My info:
Email: mrhaandi@gmail.com