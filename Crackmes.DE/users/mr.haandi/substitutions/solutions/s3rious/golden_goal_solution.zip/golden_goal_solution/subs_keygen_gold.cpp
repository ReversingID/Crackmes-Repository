// ------------------------------------------------------------------------------------------------
/*
**  Substitutions Keygenme by MR.HAANDI (level 2)
**  Minimal Keygen by s3r1ous (Golden Goal)
**  23/09/2013
*/
// ------------------------------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// ------------------------------------------------------------------------------------------------
int main(int argc, char **argv)
{
    const char  s1[32]    = { "Are you tricked?" }, // 1st constant string
                s2[32]    = { "NOPE" };             // 2nd constant string
    char        data[128] = { '\0' };               // data
    int         v, i;                               // auxilary variables


    printf( "+--------------------------------------------------+\n");
    printf( "|       Substitutions Keygenme by MR.HAANDI        |\n");
    printf( "|             Minimal keygen by s3r1ous            |\n");
    printf( "|                   October 2013                   |\n");
    printf( "+--------------------------------------------------+\n\n");
    printf( "Enter your Data: " );
    scanf ( "%s", data );                       // read data

    if( strlen(data) < 2 )                      // get data length
    {
        printf( "Data must be at least 2 character long. Exiting.\n" );
        return -1;
    }

    for(v=0, i=0; data[i]!='\0'; i++) v = (v << 4) + (char)data[i];

    printf( "Signature: " );
    for( i=0; i<4; i++ )                        // start shuffling
	{
        printf( "%2X",  (s1[4*i+0] +  (v & 0x000000ff)) ^
                        (s1[4*i+1] + ((v & 0x0000ff00) >>  8) & 0xff) ^
                        (s1[4*i+2] + ((v & 0x00ff0000) >> 16) & 0xff) ^
                        (s1[4*i+3] + ((v & 0xff000000) >> 24) & 0xff) ^
                         s2[i] );

        if( i != 3 ) printf( "-" );
	}

    printf( "\n" );
    system( "pause" );
    
    return 0;
}
// ------------------------------------------------------------------------------------------------

