Welcome to my new creation: the short sign signature scheme.
Actually, I was just playing around with maths and suddenly this came up.
By the way, if you are not really a crypto geek, don't even bother to look inside, 
cause it's my most complex work till now. Far more complex than "Intersection #1".
However, this time no measures were taken to obfuscate the code.
Additionally, I myself think this is not keygenable at all, but maybe you are better than me.

To help you I implemented the whole scheme in the keygenme,
so you can see how public keys and signatures are generated. Feel free to attack any of the algorithms.

Your task is one of the following:
I give you:
Public key: PDACELKOGPGCABPOLFEPDBEGOEBAAAAAEPFNPAKLONFKGDKHMDOEMHFOPCFAAAAAAA
Data: MR.HAANDI
Signature: QE2NK2M76RPAYTF6D9

Guru level: Generate a signature for any name which verifies with the given public key.
Master level: Generate a different signature for "MR.HAANDI" or a different data for the given signature which is accepted with the given public key.
My level: Describe what is going on inside and why you cannot break this protection. 
          If I consider your description as good enough, you will be given the private key to finish the work.

To achieve the goals, you are not allowed to modify the target, however, you may use certain exploits if you find any ;)

Good luck, you will need it, as well as the hint: "no weil, no tate, no ate?".
