#ifndef MD5_H
#define MD5_H

int MD5(unsigned char *out,const unsigned char *in,unsigned long long inlen);

#endif

