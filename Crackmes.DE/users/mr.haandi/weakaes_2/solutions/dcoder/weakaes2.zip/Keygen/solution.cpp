
#include <cstdint>
#include <array>
#include <string>
#include <algorithm>
#include <iterator>
#include <iostream>
#include <random>
#include <stdexcept>

#include "md5.hpp"
#include "modp_b64.h"
#include "matrices.hpp"


template<size_t N>
using block = std::array<std::uint8_t, N>;

static inline block<16> MD5(std::string const& m)
{
	block<16> h;
	MD5(h.data(), reinterpret_cast<const unsigned char *>(m.c_str()), m.size());
	return h;
}

template<uint8_t m = 0xBB>
static inline uint8_t gf256_mul(uint8_t a, uint8_t b)
{
	uint8_t t = 0;
	while(b)
	{
		if(b & 1) t ^= a; 
		b >>= 1;

		uint8_t s = a & 0x80;
		a <<= 1;
		if( s ) a ^= m;
	}
	return t;
}

static inline uint8_t Sbox(uint8_t x)
{
	return gf256_mul(x, x) ^ x ^ 1;
}

static inline block<16> AddRoundKey(block<16> in, block<16> const& key)
{
	for(size_t i = 0; i < 16; ++i)
		in[i] ^= key[i];
	return in;
}

static inline block<16> SubBytes(block<16> in)
{
	for(size_t i = 0; i < 16; ++i)
		in[i] = Sbox(in[i]);
	return in;
}

static inline block<16> ShiftRows(block<16> in)
{
	uint8_t i, j;
	
	i = in[1]; in[1] = in[5]; in[5] = in[9]; in[9] = in[13]; in[13] = i;
    i = in[10]; in[10] = in[2]; in[2] = i;
    j = in[3]; in[3] = in[15]; in[15] = in[11]; in[11] = in[7]; in[7] = j;
    j = in[14]; in[14] = in[6]; in[6]  = j;

    return in;
}

static inline block<16> MixColumns(block<16> in)
{
	for (size_t i = 0; i < 16; i += 4)
    {
    	uint8_t a, b, c, d, e;
        a = in[i + 0]; 
        b = in[i + 1]; 
        c = in[i + 2]; 
        d = in[i + 3];

        e = a ^ b ^ c ^ d;

        in[i+0] ^= e ^ gf256_mul(a^b, 2);   
        in[i+1] ^= e ^ gf256_mul(b^c, 2);
        in[i+2] ^= e ^ gf256_mul(c^d, 2); 
        in[i+3] ^= e ^ gf256_mul(d^a, 2);
    }
    return in;
}

static inline block<16> NextKey(block<16> key, uint8_t rcon)
{
	block<16> next = key;

	next[0] ^= Sbox(next[13]) ^ rcon;
	next[1] ^= Sbox(next[14]);
	next[2] ^= Sbox(next[15]);
	next[3] ^= Sbox(next[12]);

	for(size_t i = 4; i < 16; ++i)
		next[i] ^= next[i - 4];

	return next;
}

static inline block<16> WeakAES(block<16> in, block<16> key)
{
	uint8_t rcon = 1;
	in = AddRoundKey(in, key);
	for(size_t r = 1; r < 10; ++r)
	{
		in  = SubBytes(in);
		in  = ShiftRows(in);
		in  = MixColumns(in);
		key = NextKey(key, rcon);
		rcon = gf256_mul(rcon, 2);
		in  = AddRoundKey(in, key);
	}
	in  = SubBytes(in);
	in  = ShiftRows(in);
	key = NextKey(key, rcon);
	in  = AddRoundKey(in, key);
	return in;
}

static inline block<16> Random()
{
	std::random_device rd;
	block<16> out;
	for(size_t i = 0; i < 16; ++i)
		out[i] = rd();
	return out;
}

static inline block<16> Xor(block<16> A, block<16> const& B)
{
	for(size_t i = 0; i < 16; ++i)
		A[i] ^= B[i];
	return A;
}

static inline block<16> MatrixVector(block<128*16> const& M, block<16> const& v)
{
	block<16> x = {0};
	for(size_t i = 0; i < 128; ++i)
	{
		uint8_t r = 0;
		for(size_t j = 0; j < 128; ++j)
		{
			size_t off = i*128 + j;
			uint8_t  a = 1&(M[off/8] >> (off % 8));
			uint8_t  b = 1&(v[j/8] >> (j%8));
			r ^= a&b;
		}
		x[i/8] ^= r << (i % 8);
	}
	return x;
}


static inline bool Check(std::string const& name, std::string signature)
{
	using namespace std;

	if( name.size() == 0 ) 
		throw runtime_error("Illegal name.");

	block<16> input1 = MD5(name + "brute");
	block<16> input2 = MD5(name + "force");
	block<16> key1;
	block<16> key2;
	
	modp::b64_decode(signature);
	
	if( signature.size() != 32 ) 
		throw std::runtime_error("Illegal keys.");

	copy_n(begin(signature) +  0, 16, begin(key1));
	copy_n(begin(signature) + 16, 16, begin(key2));

	block<16> output1 = WeakAES(input1, key1);
	block<16> output2 = WeakAES(input2, key2);
	
	reverse(begin(output2), end(output2));
	return equal(begin(output1) +  0, begin(output1) + 12, begin(output2));
}


static inline std::string Generate(std::string const& name)
{
	using namespace std;

	if( name.size() == 0 ) 
		throw runtime_error("Illegal name.");

	block<16> input1 = MD5(name + "brute");
	block<16> input2 = MD5(name + "force");
	const block<16> Z = {0};

	/*
		Mb*B1 + Mk*K1 + v = rev(Mb*B2 + Mk*K2 + v)
		Mk*K1 = rev(Mb*B2 + Mk*K2 + v) + Mb*B1 + v
		K1 = Mk^-1 * (rev(Mb*B2 + Mk*K2 + v) + Mb*B1 + v)
	*/

	auto key2 = Random();
	auto rhs1 = WeakAES(input2, key2);  // Mb*B2 + Mk*K2 + v
	auto rhs2 = WeakAES(input1, Z);     // Mb*B1 + v
	reverse(begin(rhs1), end(rhs1));    // rev(Mb*B2 + Mk*K2 + v)
	auto rhs  = Xor(rhs1, rhs2);         // rev(Mb*B2 + Mk*K2 + v) + Mb*B1 + v
	auto key1 = MatrixVector(pInv, rhs);// Mk^-1 * (rev(Mb*B2 + Mk*K2 + v) + Mb*B1 + v)

	string signature;
	copy(begin(key1), end(key1), back_inserter(signature));
	copy(begin(key2), end(key2), back_inserter(signature));
	modp::b64_encode(signature);

	if( !Check(name, signature) )
		throw runtime_error("All hell broke loose");

	return signature;
}

int main()
{
	using namespace std;
	try 
	{
		string name;
		cout << "Name  : ";
		getline(cin, name);
		cout << "Serial: " << Generate(name) << endl;
	}
	catch(exception const& e)
	{
		cout << "Error: " << e.what() << endl;
	}
	return 0;
}