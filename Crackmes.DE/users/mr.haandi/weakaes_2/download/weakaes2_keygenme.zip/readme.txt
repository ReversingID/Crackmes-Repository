Welcome to the WeakAES 2 keygenme.

I have tinkered with AES128 again and 
things get non-linear this time.

There are multiple ways to generate valid signatures.
You'll need to apply a few tricks to reduce 
the complexity to around 24bit bruteforce. 
Faster generators are possible, but require additional effort. 
You don't need to go that far. 

Example:
 Name: MR.HAANDI 
 Signature: J1X5cmxw4qjI7pdHUUBtfRdluw3e5caYgNs7elH52uE=

Goals: 
 Gold: Write a key generator. 
 Silver: Write a generator for valid (name, signature) pairs. 
 Bronze: Find a different signature for 'MR.HAANDI'. 

Rules: 
 No patching. 

Greets: 
 bLaCk-eye, KernelJ, jB, divinomas, halsten, Numernia, 
 s3Rious, redoC, Dcoder, pk__, ksydfius 
 and other great reversers out there. 

My info: 
 Email: mrhaandi@gmail.com