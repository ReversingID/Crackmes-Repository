Welcome to the WeakDSA keygenme.

It is often the case that developers simply rely on 
the strength of a cryptographic problem 
and do not follow exact standards.
Often this is a bad idea and from time to time we hear 
"RSA 4096 broken" or "ECDLP 512 defeated".

Now it is time for you to break the 511 bit 
prime order discrete logarithm problem.
Just kidding :) Don't you ever try that.

However there is a weakness 
in this custom scheme for you to attack.
You surely will recognise the signature scheme 
and spot the differences to the FIPS standard.


I'd say, you will need 
two cryptographic "techniques" to be successful.
Have fun.


Goals:

    Gold:   Write a fast generator for valid 
            (id, fingerprint, signature) triples. 
            "Fast" means more than one triple/minute.

    Silver: Write a slow generator for valid 
            (id, fingerprint, signature) triples. 
            "Slow" means less than one triple/minute.

    Bronze: Find a valid (id, fingerprint, signature) triple.


Rules:
    
    No patching.


For your motivation: 
My own generator (~150 lines C#) 
uses only the public key to produce ~1 triple/minute.
Considering the fact that I use slow C# BigInteger routines,
an optimized C solution would be way faster.


Greets:
bLaCk-eye, KernelJ, jB, divinomas, halsten, Numernia
and other great reversers out there.


My info:
Email: mrhaandi@gmail.com
