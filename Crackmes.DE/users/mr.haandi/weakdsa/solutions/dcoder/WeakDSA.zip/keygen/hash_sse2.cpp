#include <emmintrin.h>
#include "types.h"


#define ROL(x, c) _mm_xor_si128(_mm_slli_epi32(x, c), _mm_srli_epi32(x, 32-c))
#define block(i) _mm_set_epi32(in[(i)+16*3],in[(i)+16*2],in[(i)+16*1],in[(i)+16*0])
//#define block(i) _mm_load_si128((__m128i*)(in + 4*i))

/*
#define F1(w,x,y,z,i,c,s) w += (z ^ (x & (y ^ z))) + block(i) + c; w = (w << s) | (w >> (32 - s)); w += x;
#define F2(w,x,y,z,i,c,s) w += (y ^ (z & (x ^ y))) + block(i) + c; w = (w << s) | (w >> (32 - s)); w += x;
#define F3(w,x,y,z,i,c,s) w += (x ^ y ^ z)         + block(i) + c; w = (w << s) | (w >> (32 - s)); w += x;
#define F4(w,x,y,z,i,c,s) w += (y ^ (x | ~z))      + block(i) + c; w = (w << s) | (w >> (32 - s)); w += x;
*/

#define F1(w,x,y,z,i,c,s) \
do \
{ \
	/*w = _mm_add_epi32(w, _mm_xor_si128(z, _mm_and_si128(x, _mm_xor_si128(y, z))));*/ \
	w = _mm_add_epi32(w, _mm_or_si128(_mm_and_si128(x, y), _mm_andnot_si128(x, z))); \
	w = _mm_add_epi32(w, _mm_add_epi32(block(i), _mm_set1_epi32(c))); \
	w = ROL(w, s); \
	w = _mm_add_epi32(w, x); \
} while(0);

#define F2(w,x,y,z,i,c,s) \
do \
{ \
	/*w = _mm_add_epi32(w, _mm_xor_si128(y, _mm_and_si128(z, _mm_xor_si128(x, y))));*/ \
	w = _mm_add_epi32(w, _mm_or_si128(_mm_and_si128(x, z), _mm_andnot_si128(z, y))); \
	w = _mm_add_epi32(w, _mm_add_epi32(block(i), _mm_set1_epi32(c))); \
	w = ROL(w, s); \
	w = _mm_add_epi32(w, x); \
} while(0);

#define F3(w,x,y,z,i,c,s) \
do \
{ \
	w = _mm_add_epi32(w, _mm_xor_si128(x, _mm_xor_si128(y, z))); \
	w = _mm_add_epi32(w, _mm_add_epi32(block(i), _mm_set1_epi32(c))); \
	w = ROL(w, s); \
	w = _mm_add_epi32(w, x); \
} while(0);

#define F4(w,x,y,z,i,c,s) \
do \
{ \
	w = _mm_add_epi32(w, _mm_xor_si128(y, _mm_or_si128(x, _mm_xor_si128(z, _mm_set1_epi32(0xffffffff))))); \
	w = _mm_add_epi32(w, _mm_add_epi32(block(i), _mm_set1_epi32(c))); \
	w = ROL(w, s); \
	w = _mm_add_epi32(w, x); \
} while(0);

#define TRANSPOSE(a,b,c,d) \
do \
{ \
	__m128i b0, b1, b2, b3; \
	__m128i s0, s1, s2, s3; \
\
	b0 = _mm_unpacklo_epi32(a, b); \
	b1 = _mm_unpacklo_epi32(c, d); \
	b2 = _mm_unpacklo_epi64(b0, b1); \
	b3 = _mm_unpackhi_epi64(b0, b1); \
\
	s0 = _mm_unpackhi_epi32(a, b); \
	s1 = _mm_unpackhi_epi32(c, d); \
	s2 = _mm_unpacklo_epi64(s0, s1); \
	s3 = _mm_unpackhi_epi64(s0, s1); \
 \
	a = b2; \
	b = b3; \
	c = s2; \
	d = s3; \
\
} while(0);

/*
void crypto_hash_sse2(u32 out[4*4], u32 in[16*4])
{
	__m128i a = _mm_set1_epi32(0x67452301);
	__m128i b = _mm_set1_epi32(0xefcdab89);
	__m128i c = _mm_set1_epi32(0x98badcfe);
	__m128i d = _mm_set1_epi32(0x10325476);

	F1(a,b,c,d, 0,0xd76aa478, 7)
    F1(d,a,b,c, 1,0xe8c7b756,12)
    F1(c,d,a,b, 2,0x242070db,17)
    F1(b,c,d,a, 3,0xc1bdceee,22)
    F1(a,b,c,d, 4,0xf57c0faf, 7)
    F1(d,a,b,c, 5,0x4787c62a,12)
    F1(c,d,a,b, 6,0xa8304613,17)
    F1(b,c,d,a, 7,0xfd469501,22)
    F1(a,b,c,d, 8,0x698098d8, 7)
    F1(d,a,b,c, 9,0x8b44f7af,12)
    F1(c,d,a,b,10,0xffff5bb1,17)
    F1(b,c,d,a,11,0x895cd7be,22)
    F1(a,b,c,d,12,0x6b901122, 7)
    F1(d,a,b,c,13,0xfd987193,12)
    F1(c,d,a,b,14,0xa679438e,17)
    F1(b,c,d,a,15,0x49b40821,22)
  
    F2(a,b,c,d, 1,0xf61e2562, 5)
    F2(d,a,b,c, 6,0xc040b340, 9)
    F2(c,d,a,b,11,0x265e5a51,14)
    F2(b,c,d,a, 0,0xe9b6c7aa,20)
    F2(a,b,c,d, 5,0xd62f105d, 5)
    F2(d,a,b,c,10,0x02441453, 9)
    F2(c,d,a,b,15,0xd8a1e681,14)
    F2(b,c,d,a, 4,0xe7d3fbc8,20)
    F2(a,b,c,d, 9,0x21e1cde6, 5)
    F2(d,a,b,c,14,0xc33707d6, 9)
    F2(c,d,a,b, 3,0xf4d50d87,14)
    F2(b,c,d,a, 8,0x455a14ed,20)
    F2(a,b,c,d,13,0xa9e3e905, 5)
    F2(d,a,b,c, 2,0xfcefa3f8, 9)
    F2(c,d,a,b, 7,0x676f02d9,14)
    F2(b,c,d,a,12,0x8d2a4c8a,20)
  
    F3(a,b,c,d, 5,0xfffa3942, 4)
    F3(d,a,b,c, 8,0x8771f681,11)
    F3(c,d,a,b,11,0x6d9d6122,16)
    F3(b,c,d,a,14,0xfde5380c,23)
    F3(a,b,c,d, 1,0xa4beea44, 4)
    F3(d,a,b,c, 4,0x4bdecfa9,11)
    F3(c,d,a,b, 7,0xf6bb4b60,16)
    F3(b,c,d,a,10,0xbebfbc70,23)
    F3(a,b,c,d,13,0x289b7ec6, 4)
    F3(d,a,b,c, 0,0xeaa127fa,11)
    F3(c,d,a,b, 3,0xd4ef3085,16)
    F3(b,c,d,a, 6,0x04881d05,23)
    F3(a,b,c,d, 9,0xd9d4d039, 4)
    F3(d,a,b,c,12,0xe6db99e5,11)
    F3(c,d,a,b,15,0x1fa27cf8,16)
    F3(b,c,d,a, 2,0xc4ac5665,23)
  
    F4(a,b,c,d, 0,0xf4292244, 6)
    F4(d,a,b,c, 7,0x432aff97,10)
    F4(c,d,a,b,14,0xab9423a7,15)
    F4(b,c,d,a, 5,0xfc93a039,21)
    F4(a,b,c,d,12,0x655b59c3, 6)
    F4(d,a,b,c, 3,0x8f0ccc92,10)
    F4(c,d,a,b,10,0xffeff47d,15)
    F4(b,c,d,a, 1,0x85845dd1,21)
    F4(a,b,c,d, 8,0x6fa87e4f, 6)
    F4(d,a,b,c,15,0xfe2ce6e0,10)
    F4(c,d,a,b, 6,0xa3014314,15)
    F4(b,c,d,a,13,0x4e0811a1,21)
    F4(a,b,c,d, 4,0xf7537e82, 6)
    F4(d,a,b,c,11,0xbd3af235,10)
    F4(c,d,a,b, 2,0x2ad7d2bb,15)
    F4(b,c,d,a, 9,0xeb86d391,21)

    a = _mm_add_epi32(a, _mm_set1_epi32(0x67452301));
	b = _mm_add_epi32(b, _mm_set1_epi32(0xefcdab89));
	c = _mm_add_epi32(c, _mm_set1_epi32(0x98badcfe));
	d = _mm_add_epi32(d, _mm_set1_epi32(0x10325476));

	TRANSPOSE(a,b,c,d)

	_mm_store_si128((__m128i *)(out +  0), a);
	_mm_store_si128((__m128i *)(out +  4), b);
	_mm_store_si128((__m128i *)(out +  8), c);
	_mm_store_si128((__m128i *)(out + 12), d);

}
*/

void crypto_hash_sse2(u32 out[8*4], u32 in[16*8])
{
	__m128i a = _mm_set1_epi32(0x67452301);
	__m128i b = _mm_set1_epi32(0xefcdab89);
	__m128i c = _mm_set1_epi32(0x98badcfe);
	__m128i d = _mm_set1_epi32(0x10325476);
	
	__m128i e = _mm_set1_epi32(0x67452301);
	__m128i f = _mm_set1_epi32(0xefcdab89);
	__m128i g = _mm_set1_epi32(0x98badcfe);
	__m128i h = _mm_set1_epi32(0x10325476);

	F1(a,b,c,d, 0,0xd76aa478, 7)      F1(e,f,g,h, 0+16*4,0xd76aa478, 7)    
    F1(d,a,b,c, 1,0xe8c7b756,12)      F1(h,e,f,g, 1+16*4,0xe8c7b756,12)
    F1(c,d,a,b, 2,0x242070db,17)      F1(g,h,e,f, 2+16*4,0x242070db,17)
    F1(b,c,d,a, 3,0xc1bdceee,22)      F1(f,g,h,e, 3+16*4,0xc1bdceee,22)
    F1(a,b,c,d, 4,0xf57c0faf, 7)      F1(e,f,g,h, 4+16*4,0xf57c0faf, 7)
    F1(d,a,b,c, 5,0x4787c62a,12)      F1(h,e,f,g, 5+16*4,0x4787c62a,12)
    F1(c,d,a,b, 6,0xa8304613,17)      F1(g,h,e,f, 6+16*4,0xa8304613,17)
    F1(b,c,d,a, 7,0xfd469501,22)      F1(f,g,h,e, 7+16*4,0xfd469501,22)
    F1(a,b,c,d, 8,0x698098d8, 7)      F1(e,f,g,h, 8+16*4,0x698098d8, 7)
    F1(d,a,b,c, 9,0x8b44f7af,12)      F1(h,e,f,g, 9+16*4,0x8b44f7af,12)
    F1(c,d,a,b,10,0xffff5bb1,17)      F1(g,h,e,f,10+16*4,0xffff5bb1,17)
    F1(b,c,d,a,11,0x895cd7be,22)      F1(f,g,h,e,11+16*4,0x895cd7be,22)
    F1(a,b,c,d,12,0x6b901122, 7)      F1(e,f,g,h,12+16*4,0x6b901122, 7)
    F1(d,a,b,c,13,0xfd987193,12)      F1(h,e,f,g,13+16*4,0xfd987193,12)
    F1(c,d,a,b,14,0xa679438e,17)      F1(g,h,e,f,14+16*4,0xa679438e,17)
    F1(b,c,d,a,15,0x49b40821,22)      F1(f,g,h,e,15+16*4,0x49b40821,22)
                                                                  
    F2(a,b,c,d, 1,0xf61e2562, 5)      F2(e,f,g,h, 1+16*4,0xf61e2562, 5)
    F2(d,a,b,c, 6,0xc040b340, 9)      F2(h,e,f,g, 6+16*4,0xc040b340, 9)
    F2(c,d,a,b,11,0x265e5a51,14)      F2(g,h,e,f,11+16*4,0x265e5a51,14)
    F2(b,c,d,a, 0,0xe9b6c7aa,20)      F2(f,g,h,e, 0+16*4,0xe9b6c7aa,20)
    F2(a,b,c,d, 5,0xd62f105d, 5)      F2(e,f,g,h, 5+16*4,0xd62f105d, 5)
    F2(d,a,b,c,10,0x02441453, 9)      F2(h,e,f,g,10+16*4,0x02441453, 9)
    F2(c,d,a,b,15,0xd8a1e681,14)      F2(g,h,e,f,15+16*4,0xd8a1e681,14)
    F2(b,c,d,a, 4,0xe7d3fbc8,20)      F2(f,g,h,e, 4+16*4,0xe7d3fbc8,20)
    F2(a,b,c,d, 9,0x21e1cde6, 5)      F2(e,f,g,h, 9+16*4,0x21e1cde6, 5)
    F2(d,a,b,c,14,0xc33707d6, 9)      F2(h,e,f,g,14+16*4,0xc33707d6, 9)
    F2(c,d,a,b, 3,0xf4d50d87,14)      F2(g,h,e,f, 3+16*4,0xf4d50d87,14)
    F2(b,c,d,a, 8,0x455a14ed,20)      F2(f,g,h,e, 8+16*4,0x455a14ed,20)
    F2(a,b,c,d,13,0xa9e3e905, 5)      F2(e,f,g,h,13+16*4,0xa9e3e905, 5)
    F2(d,a,b,c, 2,0xfcefa3f8, 9)      F2(h,e,f,g, 2+16*4,0xfcefa3f8, 9)
    F2(c,d,a,b, 7,0x676f02d9,14)      F2(g,h,e,f, 7+16*4,0x676f02d9,14)
    F2(b,c,d,a,12,0x8d2a4c8a,20)      F2(f,g,h,e,12+16*4,0x8d2a4c8a,20)
                                                                  
    F3(a,b,c,d, 5,0xfffa3942, 4)      F3(e,f,g,h, 5+16*4,0xfffa3942, 4)
    F3(d,a,b,c, 8,0x8771f681,11)      F3(h,e,f,g, 8+16*4,0x8771f681,11)
    F3(c,d,a,b,11,0x6d9d6122,16)      F3(g,h,e,f,11+16*4,0x6d9d6122,16)
    F3(b,c,d,a,14,0xfde5380c,23)      F3(f,g,h,e,14+16*4,0xfde5380c,23)
    F3(a,b,c,d, 1,0xa4beea44, 4)      F3(e,f,g,h, 1+16*4,0xa4beea44, 4)
    F3(d,a,b,c, 4,0x4bdecfa9,11)      F3(h,e,f,g, 4+16*4,0x4bdecfa9,11)
    F3(c,d,a,b, 7,0xf6bb4b60,16)      F3(g,h,e,f, 7+16*4,0xf6bb4b60,16)
    F3(b,c,d,a,10,0xbebfbc70,23)      F3(f,g,h,e,10+16*4,0xbebfbc70,23)
    F3(a,b,c,d,13,0x289b7ec6, 4)      F3(e,f,g,h,13+16*4,0x289b7ec6, 4)
    F3(d,a,b,c, 0,0xeaa127fa,11)      F3(h,e,f,g, 0+16*4,0xeaa127fa,11)
    F3(c,d,a,b, 3,0xd4ef3085,16)      F3(g,h,e,f, 3+16*4,0xd4ef3085,16)
    F3(b,c,d,a, 6,0x04881d05,23)      F3(f,g,h,e, 6+16*4,0x04881d05,23)
    F3(a,b,c,d, 9,0xd9d4d039, 4)      F3(e,f,g,h, 9+16*4,0xd9d4d039, 4)
    F3(d,a,b,c,12,0xe6db99e5,11)      F3(h,e,f,g,12+16*4,0xe6db99e5,11)
    F3(c,d,a,b,15,0x1fa27cf8,16)      F3(g,h,e,f,15+16*4,0x1fa27cf8,16)
    F3(b,c,d,a, 2,0xc4ac5665,23)      F3(f,g,h,e, 2+16*4,0xc4ac5665,23)
                                                                  
    F4(a,b,c,d, 0,0xf4292244, 6)      F4(e,f,g,h, 0+16*4,0xf4292244, 6)
    F4(d,a,b,c, 7,0x432aff97,10)      F4(h,e,f,g, 7+16*4,0x432aff97,10)
    F4(c,d,a,b,14,0xab9423a7,15)      F4(g,h,e,f,14+16*4,0xab9423a7,15)
    F4(b,c,d,a, 5,0xfc93a039,21)      F4(f,g,h,e, 5+16*4,0xfc93a039,21)
    F4(a,b,c,d,12,0x655b59c3, 6)      F4(e,f,g,h,12+16*4,0x655b59c3, 6)
    F4(d,a,b,c, 3,0x8f0ccc92,10)      F4(h,e,f,g, 3+16*4,0x8f0ccc92,10)
    F4(c,d,a,b,10,0xffeff47d,15)      F4(g,h,e,f,10+16*4,0xffeff47d,15)
    F4(b,c,d,a, 1,0x85845dd1,21)      F4(f,g,h,e, 1+16*4,0x85845dd1,21)
    F4(a,b,c,d, 8,0x6fa87e4f, 6)      F4(e,f,g,h, 8+16*4,0x6fa87e4f, 6)
    F4(d,a,b,c,15,0xfe2ce6e0,10)      F4(h,e,f,g,15+16*4,0xfe2ce6e0,10)
    F4(c,d,a,b, 6,0xa3014314,15)      F4(g,h,e,f, 6+16*4,0xa3014314,15)
    F4(b,c,d,a,13,0x4e0811a1,21)      F4(f,g,h,e,13+16*4,0x4e0811a1,21)
    F4(a,b,c,d, 4,0xf7537e82, 6)      F4(e,f,g,h, 4+16*4,0xf7537e82, 6)
    F4(d,a,b,c,11,0xbd3af235,10)      F4(h,e,f,g,11+16*4,0xbd3af235,10)
    F4(c,d,a,b, 2,0x2ad7d2bb,15)      F4(g,h,e,f, 2+16*4,0x2ad7d2bb,15)
    F4(b,c,d,a, 9,0xeb86d391,21)      F4(f,g,h,e, 9+16*4,0xeb86d391,21)

    a = _mm_add_epi32(a, _mm_set1_epi32(0x67452301));
	b = _mm_add_epi32(b, _mm_set1_epi32(0xefcdab89));
	c = _mm_add_epi32(c, _mm_set1_epi32(0x98badcfe));
	d = _mm_add_epi32(d, _mm_set1_epi32(0x10325476));
	
	e = _mm_add_epi32(e, _mm_set1_epi32(0x67452301));
	f = _mm_add_epi32(f, _mm_set1_epi32(0xefcdab89));
	g = _mm_add_epi32(g, _mm_set1_epi32(0x98badcfe));
	h = _mm_add_epi32(h, _mm_set1_epi32(0x10325476));

	TRANSPOSE(a,b,c,d)
	TRANSPOSE(e,f,g,h)

	_mm_store_si128((__m128i *)(out +  0), a);
	_mm_store_si128((__m128i *)(out +  4), b);
	_mm_store_si128((__m128i *)(out +  8), c);
	_mm_store_si128((__m128i *)(out + 12), d);
	
	_mm_store_si128((__m128i *)(out + 16), e);
	_mm_store_si128((__m128i *)(out + 20), f);
	_mm_store_si128((__m128i *)(out + 24), g);
	_mm_store_si128((__m128i *)(out + 28), h);
}

