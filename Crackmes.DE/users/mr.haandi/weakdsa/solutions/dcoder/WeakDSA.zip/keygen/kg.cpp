
#include <iostream>
#include <array>
#include <set>
#include <map>
#include <unordered_map>
#include <unordered_set>
#include <tuple>
#include <random>
#include <algorithm>
#include <utility>
#include <iterator>
#include <string>
#include <cstdint>
#include <cassert>
#include <cctype>
#include <cstring>
#include <ctime>

#include <boost/thread.hpp>
#include <boost/chrono.hpp>

#include "types.h"
#include <gmp.h>
#include "hash.h"
#include "modp_b64.h"

static const size_t fieldSize = 64; // 512 bits
static const size_t idSize    = 6;
static const size_t fingerPrintSize = fieldSize - idSize;

mpz_t p;
mpz_t q;
mpz_t g;
mpz_t y;

bool deriveData(u8 out[fieldSize], const char *id, const char *fingerPrint)
{
    u8 md5[16] = {0};
    u8 fp[fieldSize] = {0};
    size_t i;
    
    if( fingerPrintSize != modp_b64_decode((char*)fp, fingerPrint, strlen(fingerPrint)) )
		return false;
    
    crypto_hash(md5, (u8*)id, strlen(id));
    
    for(i = 0; i < fingerPrintSize; ++i)
        out[i] = fp[i];
    for(size_t j = 0; i < fieldSize; ++i)
        out[i] = md5[j++];
    
    out[fieldSize - 1] &= 0x7f;
	return true;
}

bool Verify(const char *id, const char *fingerPrint, const char *signature)
{
    u8 hbytes[fieldSize] = {0};
    u8 srcArray[2*fieldSize] = {0};
    u8 srcR[fieldSize] = {0};
    u8 srcS[fieldSize] = {0};
    bool accept = false;
    
    mpz_t h, r, s, w, u1, u2, v1, v2, v;
    mpz_inits(h,r,s,w,u1,u2,v1,v2,v,0);

    if( !deriveData(hbytes, id, fingerPrint) )
		goto cleanup;

    mpz_import(h, fieldSize, -1, 1, 0, 0, hbytes);
    
	if(fieldSize*2 != modp_b64_decode((char*)srcArray, signature, strlen(signature)))
		goto cleanup;
    
    memcpy(srcR, srcArray, fieldSize);
    memcpy(srcS, srcArray + fieldSize, fieldSize);
    
    mpz_import(r, fieldSize, -1, 1, 0, 0, srcR);
    mpz_import(s, fieldSize, -1, 1, 0, 0, srcS);
    
    mpz_invert(w, s, q);
    mpz_mul(u1, h, w); mpz_mod(u1, u1, q);
    mpz_mul(u2, r, w); mpz_mod(u2, u2, q);
    
    mpz_powm(v1, g, u1, p);
    mpz_powm(v2, y, u2, p);
    mpz_mul(v, v1, v2); mpz_mod(v,v,p); mpz_mod(v,v,q);
    
    if( 0 == mpz_cmp(v, r) )
        accept = true;
    
cleanup:
    mpz_clears(h,r,s,w,u1,u2,v1,v2,v,0);
    return accept;
}


typedef std::tuple<std::string,std::string,std::string> tuple_type;
typedef std::unordered_map<u64, tuple_type> map_type;

map_type hash_table;
boost::mutex mutex;
std::random_device rd;
volatile bool preimage_found = false;
std::vector<std::pair<u64,u64>> preimages;

static void GenerateCandidatesThread(const size_t N)
{
	mpz_t a, b, binv, u1, u2, t, r, s, h;
	
	gmp_randstate_t prng;
	gmp_randinit_mt(prng);
	gmp_randseed_ui(prng, rd());

	mpz_inits(a, b, binv, u1, u2, t, r, s, h, 0);

	mpz_urandomm(b, prng, q);

	mpz_powm(u2, y, b, p);
	mpz_invert(binv, b, q);

	for(long i = 0; i < N; ++i)
	{
		char array_h[fieldSize] = {0};
		char array_r[fieldSize] = {0};
		char array_s[fieldSize] = {0};

		mpz_urandomm(a, prng, q);
		
		mpz_powm(u1, g, a, p);

		mpz_mul(r, u1, u2); mpz_mod(r, r, p); mpz_mod(r, r, q);

		mpz_mul(s, r, binv); mpz_mod(s, s, q);
		mpz_mul(h, s, a); mpz_mod(h, h, q);

		// Export
		mpz_export(array_h, NULL, -1, 1, 0, 0, h);
		mpz_export(array_r, NULL, -1, 1, 0, 0, r);
		mpz_export(array_s, NULL, -1, 1, 0, 0, s);

		std::string arr_h(array_h, fingerPrintSize);
		std::string arr_r(array_r, fieldSize);
		std::string arr_s(array_s, fieldSize);

		u64 hash =  *((u64*)(array_h + fingerPrintSize)) & ((1ULL << 47)-1);
		do 
		{
			boost::lock_guard<boost::mutex> lock(mutex);
			hash_table.insert(std::make_pair(hash, tuple_type(arr_h, arr_r, arr_s)));
		} while (0);
	}

	mpz_clears(a, b, binv, u1, u2, t, r, s, h, 0);
	gmp_randclear(prng);
}


void GenerateCandidates(const size_t N = 200000)
{
	size_t cpu_threads = boost::thread::hardware_concurrency();

	boost::thread_group thread_group;
	for(size_t i = 0; i < cpu_threads; ++i)
	{
		thread_group.add_thread(new boost::thread(GenerateCandidatesThread, N/cpu_threads));
	}

	thread_group.join_all();
}


static inline void transpose_state(u32 state[16*4])
{
	u32 out[16*4];

	for(size_t i = 0; i < 16; ++i)
	{
		out[i*4 + 0] = state[i +  0];
		out[i*4 + 1] = state[i + 16];
		out[i*4 + 2] = state[i + 32];
		out[i*4 + 3] = state[i + 48];
	}
	memcpy(state, out, sizeof(u32)*16*4);
}

template<size_t N> // length
static inline void make_state(u8 state[64*8], const char str[8][16])
{
	memset(state, 0, 64*8);

	for(size_t i = 0; i < 8; ++i)
	{
		memcpy(state + 64*i, str[i], N);
		state[N + 64*i] = 0x80;
		*((u64*)(state + 56 + 64*i)) = N*8;
	}
}



template<size_t N>
struct strconv
{
	template<typename T>
	static __forceinline void ultoa10(char *str, const T x)
	{
		strconv<N-1>::ultoa10(str, x/10);
		str[N-1] = (x % 10) + '0';
		str[N] = 0;
	}
};

template<>
struct strconv<1>
{
	template<typename T>
	static __forceinline void ultoa10(char *str, const T x)
	{
		str[0] = (x % 10) + '0';
	}
};


static void PreimageThread(const u64 start)
{
	for(u64 n = start; !preimage_found; n += 8)
	{
		u8 hash[8*16];
		u8 state[8*64];

		char str[8][16] = {0};

		for(size_t i = 0; i < 8; ++i)
			strconv<15>::ultoa10(str[i], n + i);

		make_state<15>(state, str);

		crypto_hash_sse2(reinterpret_cast<u32*>(hash), reinterpret_cast<u32*>(state));

		for(size_t i = 0; i < 8; ++i)
		{
			u64 x = *((u64*)(hash + 16*i)) & ((1ULL << 47)-1);
			if( hash_table.count( x ) )
			{
				do
				{
					boost::lock_guard<boost::mutex> lock(mutex);
					preimage_found = true;
					preimages.push_back(std::make_pair(n + i, x));
				} while(0);
				goto exit_thread;
			}
		}
	}
exit_thread:
	;
}

static std::pair<u64, u64> FindPreimage()
{
	size_t cpu_threads = boost::thread::hardware_concurrency();
	u64 N = 1ULL << 48;

	boost::thread_group thread_group;
	for(size_t i = 0; i < cpu_threads; ++i)
	{
		thread_group.add_thread(new boost::thread(PreimageThread, i*N/cpu_threads));
	}

	thread_group.join_all();

	return preimages.front();
}

void Forge()
{
	using boost::chrono::high_resolution_clock;
	using boost::chrono::milliseconds;
	using boost::chrono::duration_cast;

	high_resolution_clock::time_point start = high_resolution_clock::now();
	GenerateCandidates(1UL << 18);
	std::cout << "Generating candidates: " << 
		duration_cast<milliseconds>(high_resolution_clock::now() - start).count() << 
		"ms" << std::endl;
	
	start = high_resolution_clock::now();
	std::pair<u64, u64> solution = FindPreimage();
	std::cout << "Preimage finding: " << 
		duration_cast<milliseconds>(high_resolution_clock::now() - start).count() << 
		"ms" << std::endl;

	char id[32] = {0};
	strconv<15>::ultoa10(id, solution.first);

	tuple_type keys = hash_table[solution.second];
	std::string arr_h = std::get<0>(keys);
	std::string arr_r = std::get<1>(keys);
	std::string arr_s = std::get<2>(keys);

	std::cout << "Signature: (" << id << ", ";
	std::cout << modp::b64_encode(arr_h) << ", ";
	std::cout << modp::b64_encode(arr_r + arr_s) << ")" << std::endl;
}


int main(int argc, char **argv)
{
    mpz_init_set_str(p, "12343166190249099963844614971858188890660252314196981857116019178266498099196944436576774068596061785922642532486910253402920733695804947624905546363393363", 10);
    mpz_init_set_str(q, "6171583095124549981922307485929094445330126157098490928558009589133249049598472218288387034298030892961321266243455126701460366847902473812452773181696681", 10);
    mpz_init_set_str(g, "6786183533171661594262558814260314083384466978959974116431945959977589683740679922916498942642093589315722172714694250494775306223775833010063525305963887", 10);
    mpz_init_set_str(y, "10064244825758094072963970119807064710181088090418826682084640363233124440395354645467056460109079832312427767666487651151696929816590482407358254249751172", 10);
    
	std::cout << "WeakDSA existential forgery generator" << std::endl;
	Forge();
	                        
    mpz_clears(p,q,g,y,0);
    return 0;
}

