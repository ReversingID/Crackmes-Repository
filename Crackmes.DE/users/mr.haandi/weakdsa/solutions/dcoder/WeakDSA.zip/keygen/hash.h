
#ifndef __MD5_H__
#define __MD5_H__

int crypto_hash(unsigned char *out,const unsigned char *in, const unsigned long long inlen);
void crypto_hash_sse2(u32 out[8*4], u32 in[16*8]);

#endif

