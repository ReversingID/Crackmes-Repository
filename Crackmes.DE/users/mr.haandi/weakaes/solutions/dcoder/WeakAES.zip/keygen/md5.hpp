#ifndef MD5_H
#define MD5_H

#include <string>

int MD5(unsigned char *out,const unsigned char *in,unsigned long long inlen);
std::string MD5(const std::string &m)
{
	unsigned char h[16];
	MD5(h, reinterpret_cast<const unsigned char *>(m.c_str()), m.size());
	return std::string(reinterpret_cast<char *>(h), 16);
}

#endif

