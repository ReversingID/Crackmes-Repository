Rules

Keygen it ;)

About

Inspired by BUBlic's Thales keygenmes,
I introduce a keygenme, which brings the idea to a new level.

This time you're working in the R� space and use trigonometry.
Nevertheless, the idea is the same,
and if you understand the difference between jB's solutions
http://jardinezchezjb.free.fr/
and Kerberos's solutions
http://crackmes.de/users/bublic/thales_keygenme_2/
then you'll get this as well.

What I'd like to see is an elegant keygen,
which uses the basic math operations and trigonometry
avoiding equation system and even ax�+bx+c=0 solvers.
Of course, any valid keygen is appreciated.


Greetz:
bLaCk-eye, jB, halsten, KernelJ
and other great reversers out there.

My info:
Email: mrhaandi@gmail.com
Homepage: http://mrhaandi.thecoderblogs.com/


MR.HAANDI