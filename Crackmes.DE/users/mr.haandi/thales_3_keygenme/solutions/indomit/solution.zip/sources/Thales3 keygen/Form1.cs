﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Globalization;

namespace Thales3_keygen
{
    internal struct Vector
    {
        public double x0;
        public double x1;
        public double x2;
    }

    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtSignature.Text.Length > 0)
            Clipboard.SetText(txtSignature.Text);
        }

        private Vector VecSub(Vector a, Vector b)
        {
            Vector vector;
            vector.x0 = a.x0 - b.x0;
            vector.x1 = a.x1 - b.x1;
            vector.x2 = a.x2 - b.x2;
            return vector;
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            Vector vector;
            Vector vector2;
            Vector vector3;
            Vector vector4;
            Random random = new Random(this.txtName.Text.GetHashCode());
            vector.x0 = random.NextDouble() * 50.0;
            vector.x1 = random.NextDouble() * 50.0;
            vector.x2 = random.NextDouble() * 50.0;
            vector2.x0 = (random.NextDouble() * 50.0) + 100.0;
            vector2.x1 = (random.NextDouble() * 50.0) + 100.0;
            vector2.x2 = (random.NextDouble() * 50.0) + 100.0;
            double r = (random.NextDouble() * 50.0) + 10.0;

            Vector vec = VecSub(vector2, vector);
            double m = Math.Sqrt(vec.x0 * vec.x0 + vec.x1 * vec.x1 + vec.x2 * vec.x2);
            double x = r * r / m;                    //  x / r = r / m
            double y = Math.Sqrt(r * r - x * x);     //  r*r = x*x + y*y
            vector3.x0 = vector2.x0 - x / m * vec.x0;
            vector3.x1 = vector2.x1 - x / m * vec.x1;
            vector3.x2 = vector2.x2 - x / m * vec.x2;
            vector4.x0 = vec.x0 / m;  //cos(a)
            vector4.x1 = vec.x1 / m;  //cos(B)
            vector4.x2 = vec.x2 / m;  //cos(y)

            NumberFormatInfo nfi = new CultureInfo("en-US", false).NumberFormat;
            nfi.NumberDecimalSeparator = ",";

            txtSignature.Text =
                vector3.x0.ToString(nfi) + " " +
                vector3.x1.ToString(nfi) + " " +
                vector3.x2.ToString(nfi) + " " +
                y.ToString(nfi) + " " +
                vector4.x0.ToString(nfi) + " " +
                vector4.x1.ToString(nfi) + " " +
                vector4.x2.ToString(nfi);
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            this.Text = "Thales\x00b3 keygen by indomit";
        }
    }
}
