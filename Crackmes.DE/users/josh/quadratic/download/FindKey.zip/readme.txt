You have to find the key to solve the challenge.

The problem:
The .NET executable contains AES-encrypted text. It waits 
for you to input the correct key to display the clear text.
The key is somewhere hidden in the attached files.

The rules:
- Finding the complete final key,
- Description of the solution
- No key-posting to the discussion board

If the sugggested difficulty (Level 2) seems too high or too low
just drop a notice, it will be adapted accordingly.

Have fun! 

-josh