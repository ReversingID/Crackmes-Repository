
#define _CRT_SECURE_NO_WARNINGS

#undef UNICODE
#undef _UNICODE
#include <windows.h>
#include <CommCtrl.h>
#include "resource.h"

// definitions
#define	APP_NAME		"josh's SMS keygen"
#define	MSG_MAX		27		// max. lenght of encoded message
#define	OFFSET_BLUE	2		// offset to pixel blue part, 0-red, 1-green

// global vars
DWORD	g_CRC32_Lookup[0x100];
BYTE	g_Signum_Table[32];	// actually output text
DWORD g_dwKeys[0x10000];


// loads/saves pixels of bitmap blue channel, in blue_channel[] one pixel is represented as one byte
// bitmap must be .BMP, 256x256, 24 bits per pixel, uncompressed
//----------------------------------------
bool ProcessBlueBitmapData (bool bLoadOrSave, HWND hDlg, char *szFile, IN OUT char blue_channel[0x10000])
{
	DWORD i, j, dwSrc, dwDest;
	HANDLE hFile = INVALID_HANDLE_VALUE, hFileMap = 0;
	BYTE *pData, *pFileView = 0;

	if (bLoadOrSave)
		memset (blue_channel, 0, sizeof(char)*0x10000);

	// map bmp file to memory
	hFile = CreateFile (szFile, bLoadOrSave ? GENERIC_READ : GENERIC_READ|GENERIC_WRITE, 0, 0, OPEN_EXISTING, 0, 0);
	if (hFile == INVALID_HANDLE_VALUE) {
		MessageBox (hDlg, "Can't open specified file.", APP_NAME, 0);
		return false;
	}
	hFileMap = CreateFileMapping (hFile, 0, bLoadOrSave ? PAGE_READONLY : PAGE_READWRITE, 0, 0, 0);
	if (hFileMap == NULL) {
		MessageBox (hDlg, "Can't create FileMapping object.", APP_NAME, 0);
		goto err_hand;
	}
	pFileView = (BYTE*)MapViewOfFile (hFileMap, bLoadOrSave ? FILE_MAP_READ : FILE_MAP_WRITE, 0, 0, 0);
	if (pFileView == NULL) {
		MessageBox (hDlg, "Can't map view of file.", APP_NAME, 0);
		goto err_hand;
	}

	// file is mapped, test to: BMP, 256x256, 24bpx, uncompressed
	BITMAPFILEHEADER *pBMPheader = (BITMAPFILEHEADER*)pFileView;
	if (pBMPheader->bfType != 0x4D42)		goto invalid_format;		// must starts with 'BM'
	BITMAPINFOHEADER	*pBMPInfoHeader = (BITMAPINFOHEADER*) (pFileView + sizeof(BITMAPFILEHEADER));
	if (pBMPInfoHeader->biWidth != 256 || pBMPInfoHeader->biHeight != 256 ||
		pBMPInfoHeader->biBitCount != 24 || pBMPInfoHeader->biCompression != 0)
		goto invalid_format;		// must be 256x256, 24bpx, uncompressed

	// load/save blue data
	pData = pFileView + pBMPheader->bfOffBits;
	for (i=0; i<256; i++)
		for (j=0; j<256; j++)
		{
			dwDest = i*256 + j;
			dwSrc = 3 * ((255-i)*256 + j) + OFFSET_BLUE;		// lines in .bmp from bottom to top
			if (bLoadOrSave)
				blue_channel[dwDest] = pData[dwSrc];
			else
				pData[dwSrc] = blue_channel[dwDest];
		}


		// clear & exit
		if (pFileView)	UnmapViewOfFile (pFileView);
		if (hFileMap) CloseHandle (hFileMap);
		if (hFile != INVALID_HANDLE_VALUE)	CloseHandle (hFile);
		return true;

invalid_format:
		MessageBox (hDlg, "It must be .bmp, 256x256, 24bpx and uncompressed.", APP_NAME, 0);
err_hand:
		if (pFileView)	UnmapViewOfFile (pFileView);
		if (hFileMap) CloseHandle (hFileMap);
		if (hFile != INVALID_HANDLE_VALUE)	CloseHandle (hFile);
		return false;
}
// generates statical field DWORD g_dwKeys[0x10000]
//----------------------------------------
void FillKeyTable_10001A50()
{
	DWORD i, EAX, EBX, EDX;
	int Field1[0x100];		// temp field

	for (i=0; i<0x100; i++)
		Field1[i] = 0x100;
	memset (g_dwKeys, 0, sizeof(g_dwKeys));

	EBX = 0x7B;
	for (i=0; i<0x10000; i++)
	{
		EBX *= 0x343FD;	// IMUL
		EBX += 0x269EC3;
		EAX = EBX;
		EAX /= 0x10000;	// SHR EAX,0x10
		EAX &= 0x7FFF;
		EDX = EAX % 0x100;	// IDIV

		if (Field1 [EDX] == 0)
			do {
				EDX = (EDX + 1) % 0x100;	// IDIV
			} while (Field1 [EDX] == 0);

		g_dwKeys [i] = EDX;
		Field1 [EDX] -= 1;
	}
}
// generates DWORD g_CRC32_Lookup[0x100];
//----------------------------------------
int CRC32Init_100017D0()
{
	unsigned int v0;
	signed int v1, v4;
	int result, v5, v6, v7, v8, v9;

	v0 = 0;
	do {
		v1 = 0;
		if ( v0 & 1 )			v1 = 0x80;
		if ( (v0 >> 1) & 1 )	v1 |= 0x40;
		if ( (v0 >> 2) & 1 )	v1 |= 0x20;
		if ( (v0 >> 3) & 1 )	v1 |= 0x10;
		if ( (v0 >> 4) & 1 )	v1 |= 8;
		if ( (v0 >> 5) & 1 )	v1 |= 4;
		if ( (v0 >> 6) & 1 )	v1 |= 2;
		if ( (v0 >> 7) & 1 )	v1 |= 1;

		v6 = (v1 << 25) ^ (((v1 << 24) & 0x80000000) != 0 ? 0x4C11DB7 : 0);
		v7 = 2 * (2 * v6 ^ ((v6 & 0x80000000) != 0 ? 0x4C11DB7 : 0)) ^ (((2 * v6 ^ ((v6 & 0x80000000) != 0 ? 0x4C11DB7 : 0)) & 0x80000000) != 0 ? 0x4C11DB7 : 0);
		v8 = 2 * (2 * v7 ^ ((v7 & 0x80000000) != 0 ? 0x4C11DB7 : 0)) ^ (((2 * v7 ^ ((v7 & 0x80000000) != 0 ? 0x4C11DB7 : 0)) & 0x80000000) != 0 ? 0x4C11DB7 : 0);
		v9 = 2 * (2 * v8 ^ ((v8 & 0x80000000) != 0 ? 0x4C11DB7 : 0)) ^ (((2 * v8 ^ ((v8 & 0x80000000) != 0 ? 0x4C11DB7 : 0)) & 0x80000000) != 0 ? 0x4C11DB7 : 0);

		result =	2 * v9 ^ ((v9 & 0x80000000) != 0 ? 0x4C11DB7 : 0);
		g_CRC32_Lookup[v0] = result;
		v5 = 0;
		v4 = 31;
		do {
			if ( result & 1 )
				v5 |= 1 << v4;
			--v4;
			result = (unsigned int)result >> 1;
		} while ( v4 > -1 );

		g_CRC32_Lookup[v0++] = v5;
	} while ( (signed int)v0 <= 255 );

	return result;
}
//----------------------------------------
DWORD crc32(const BYTE *buf, DWORD dwLen)
{
	DWORD dw_CRC32 = 0xFFFFFFFF;
	for (int idx=0 ;idx<28; idx++)
		dw_CRC32 = g_CRC32_Lookup[buf[idx] ^ (unsigned char)dw_CRC32]  ^  (dw_CRC32 >> 8);
	return ~dw_CRC32;
}
// fills BYTE g_Signum_Table[32] - it's actually bit-field with sign information of field Buf[]
//----------------------------------------
void FillSignumTable_100016B0 (short Buf[0x100], BYTE	bSignum_Table[32])
{
	memset (bSignum_Table, 0, sizeof(BYTE)*32);
	for (DWORD i=0; i<256; i++)
		if (Buf[i] > 0)
			bSignum_Table[i/8] |= 1 << (i % 8);
}
/*
//----------------------------------------
bool FinalTest_10001740 ()
{
	DWORD dw_LastDWORD;
	DWORD dw_CRC32 = 0xFFFFFFFF;

	// computes CRC32 of first 28 bytes of Signum_Table
	for (int idx=0 ;idx<28; idx++)
		dw_CRC32 = g_CRC32_Lookup[g_Signum_Table[idx] ^ (unsigned char)dw_CRC32]  ^  ((unsigned int)dw_CRC32 >> 8);

	dw_CRC32 = ~dw_CRC32;
	dw_LastDWORD = *(DWORD *) &g_Signum_Table[28]; // this CRC must be at last DWORD of Signum_Table
	return (dw_LastDWORD == dw_CRC32) ? 1 : -4;
}
*/
// fills short Buf[0x100] according to char colorData[0x10000]
// colorData - one pixel is represented as one byte
// double ProcessColorData_10001080 (char *colorData/*ecx*/, short Buf[0x100]/*esi*/, DWORD Table2[5]);
//----------------------------------------
void ProcessColorData_10001080 (char *colorData, short Buf[0x100])
{
	DWORD dwIdxRow, dwIdxColumn, dwBufIdx;
	signed short intIncDec;
	float fAvg;

	memset (Buf, 0, sizeof(short)*0x100);
	// algo runs on data 254x254 pixels (due to 3x3 filter size)
	//top-cycle, runs 254-times
	for (dwIdxRow=1; dwIdxRow<=254; colorData+=256, dwIdxRow++)	// shift to new line
	{
		intIncDec = 0;		// only 0,1,-1

		// computes 254 pixel in one line
		for (dwIdxColumn=1; dwIdxColumn<=254; dwIdxColumn++)
		{
			dwBufIdx = g_dwKeys[dwIdxRow*256 + dwIdxColumn];
			fAvg = (double)colorData[dwIdxColumn + 256] - 
				0.5 * ((double)colorData[dwIdxColumn + 512] + (double)colorData[dwIdxColumn]);

			if ( fAvg > 0.0 )
			{++Buf[dwBufIdx]; intIncDec = 1;}
			else if ( fAvg < 0.0 )
			{--Buf[dwBufIdx]; intIncDec = -1;}
			else	// fAvg == 0.0
				Buf[dwBufIdx] += intIncDec;	// +1 or -1
		}

		//////////////////////////////////////////////////////////////////////
_base1356:
		intIncDec = 0;		// only 0,1,-1	

		// computes 254 pixel in one line
		for (dwIdxColumn=1; dwIdxColumn<=254; dwIdxColumn++)
		{
			dwBufIdx = g_dwKeys[dwIdxRow*256 + dwIdxColumn];
			fAvg = (double)colorData[dwIdxColumn + 256] -
				0.5 * ((double)colorData[dwIdxColumn + 257] + (double)colorData[dwIdxColumn + 255]);

			if ( fAvg > 0.0 )
			{++Buf[dwBufIdx]; intIncDec = 1;}
			else if ( fAvg < 0.0 )
			{--Buf[dwBufIdx]; intIncDec = -1;}
			else	// fAvg == 0.0
				Buf[dwBufIdx] += intIncDec;	// +1 or -1
		}
	} // for (dwIdxRow=...)		// top-cycle
}
// change colorData to match required Signum_Table
//----------------------------------------
void ChangeColorData (char *colorData)
{
	DWORD dwIdxColumn, dwIdxRow, dwIdx, dwPixel;
	short Buf[0x100];
	BYTE	bSignum_Table[32];

	do {
		for (dwIdxRow=1; dwIdxRow<=254; dwIdxRow++)
			for (dwIdxColumn=1; dwIdxColumn<=254; dwIdxColumn++)
			{
				dwPixel = dwIdxRow*256 + dwIdxColumn;
				dwIdx = g_dwKeys[dwPixel];
				if ( g_Signum_Table[dwIdx/8] & (1 << (dwIdx%8)) )
				{
					if (colorData[dwPixel] < 127)
						colorData[dwPixel]++;
				}
				else if (colorData[dwPixel] > -127)
					colorData[dwPixel]--;

			}
		// test new colorData
		ProcessColorData_10001080 (colorData, Buf);
		FillSignumTable_100016B0 (Buf, bSignum_Table);
		// if neccessary change again to match proper Signum_Table...
	}while (memcmp (bSignum_Table, g_Signum_Table, sizeof(g_Signum_Table)));
}
//----------------------------------------
bool Generate (HWND hDlg)
{
	char colorData[0x10000];
	char szImage[256]={0};
	DWORD i, dwMsgLen, dwCRC32;

	memset (g_Signum_Table, 0, sizeof(g_Signum_Table));
	dwMsgLen = GetDlgItemText (hDlg, IDC_EDIT_MSG, (LPSTR)g_Signum_Table, 28);
	for (i=dwMsgLen+1; i<28; i++)
		g_Signum_Table[i] = 'j';	// fill some data, 'j' is binary 01101010, that's ok

	// last dword = CRC32 (g_Signum_Table[0-27])
	CRC32Init_100017D0();
	dwCRC32 = crc32 (g_Signum_Table, 28);
	memcpy (&g_Signum_Table[28], &dwCRC32, sizeof(dwCRC32));

	if (!GetDlgItemText (hDlg, IDC_EDIT_IMAGE, szImage, sizeof(szImage)-1))
		{MessageBox (hDlg, "Choose bitmap file", APP_NAME, 0); return false;}
	if (!ProcessBlueBitmapData (true, hDlg, szImage, colorData))		// loads blue channel to colorData
		return false;
	FillKeyTable_10001A50();		// fill static field g_dwKeys[]
	ChangeColorData (colorData);	// adjusts pixels to accomodate our output string
	// save new colorData back
	if (!ProcessBlueBitmapData (false, hDlg, szImage, colorData))
		return false;

	MessageBox (hDlg, "Done!", APP_NAME, 0);
	return true;
}
//----------------------------------------
void DoOpenFile (HWND hDlg)
{
	char szBuffer[256]={0};
	OPENFILENAME ofn={0};

	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.hwndOwner = hDlg;
	ofn.lpstrFilter = "BMP files (*.bmp)\0*.bmp\0\0";
	ofn.lpstrFile = szBuffer;
	ofn.nMaxFile = sizeof(szBuffer);
	ofn.Flags = OFN_FILEMUSTEXIST | OFN_HIDEREADONLY;

	if (GetOpenFileName (&ofn))
		SetDlgItemText (hDlg, IDC_EDIT_IMAGE, szBuffer);
}
//----------------------------------------
BOOL CALLBACK DialogProc(HWND  hwndDlg, UINT  uMsg, WPARAM  wParam, LPARAM  lParam )
{
	switch (uMsg)
	{
	case WM_INITDIALOG:
#ifdef MSG_MAX
		SendDlgItemMessage (hwndDlg, IDC_EDIT_MSG, EM_SETLIMITTEXT, MSG_MAX, 0);
#endif
		SetDlgItemText (hwndDlg, IDC_EDIT_MSG, "Attack at early dawn!");
		return TRUE;

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDC_BUTTON_GENERATE:
			Generate (hwndDlg); return TRUE;
		case IDC_BUTTON_OPENFILE:
			DoOpenFile(hwndDlg); return TRUE;
		case IDCANCEL:
			EndDialog (hwndDlg, 0); return TRUE;
		}
		break;
	}
	return FALSE;
}
//----------------------------------------
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	InitCommonControls ();
	DialogBoxParam (hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, DialogProc, 0);
	return (0);
}