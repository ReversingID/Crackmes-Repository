#include <stdio.h>
#include <stdint.h>
#include <string.h>

#include <b64/cencode.h>

uint8_t signBytes2[] = {
    0x83, 0xC2, 0x0E, 0x89,
    0x1D, 0xF0, 0x30, 0x40,
    0x00, 0x53, 0x8D, 
};

int main(int argc, const char **argv) {
    if ( argc < 2 ) {
        printf("Usage %s <username>\n",argv[0]);
        return;
    }

    const char *name = argv[1];
    if ( strlen(name) != 8 ) {
        printf("Username must be 8 characters, yours is %u\n",strlen(name));
        return;
    }
    uint32_t idx = 0;
    uint32_t data[8];
    char ov[64];
    int i;
    base64_encodestate estate;

    for ( i = 0; i < 8; i++ ) {
        uint32_t vx = *((uint32_t*)(signBytes2 + (idx++)));
        uint32_t wv = *((uint32_t*)(name + i));
        data[i] = vx^wv;
    }

    base64_init_encodestate(&estate);
    int ct = base64_encode_block((char *)data, 10, ov, &estate);
    base64_encode_blockend(ov + ct, &estate);
    ov[8] = '\0';

    printf("%s %s\n",name,ov);
}