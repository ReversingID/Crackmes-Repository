#include "stdafx.h"
#include <conio.h>
int _tmain(int argc, _TCHAR* argv[])
{
	int hash1,hash2,hash3,n,i;
	char name[15],c;
	printf("Name: ");
	scanf("%14s",name);
	n=strlen(name);
	hash1=hash2=hash3=0;
	for(i=0;i<n;i++)
	{
		c=name[i];
		_asm
		{
			mov eax,hash1
			rol eax,7
			xor al,c
			mov hash1,eax
		}			
	}
	for(i=0;i<n;i++)
	{
		c=name[i];
		_asm
		{
			mov eax,hash2
			ror eax,7
			xor al,c
			mov hash2,eax
		}			
	}
	for(i=0;i<n;i++)
	{
		c=name[i];
		_asm
		{
			mov eax,hash3
			xor al,c
			not al
			rol eax,8
			xor al,c
			mov hash3,eax
		}			
	}
	printf("Serial: %u-%u-%u\n",hash1,hash2,hash3);
	_getch();
	return 0;
}

