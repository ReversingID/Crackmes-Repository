Well not much to say, simple packer for x64 images, writen today for fun of it.
Your task is to unpack it :) Nothing spectacular...

                                                        deroko of ARTeam