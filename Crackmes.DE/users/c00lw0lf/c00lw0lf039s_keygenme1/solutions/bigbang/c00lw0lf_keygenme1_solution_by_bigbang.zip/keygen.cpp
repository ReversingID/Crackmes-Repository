/******************************************************************								***								***
***		c00lw0lf - KeygenMe1				***
***								***
***	 	Keygen by Bigbang				***
***								***
***  Protection : RSA    					***
***								***
***	 RSA Features :		(all in hex)			***
***      ==============						***
*** 	n = 666AAA422FDF79E1D4E41EDDC4D42C51			***
***			p = 838512BE2D7B26B3			***
***			q = C759F807A2BCC2EB			***
***	d = 65537						***
***	e = 29F8EEDBC262484C2E3F60952B73D067			***
***								***
*******************************************************************/

#include <windows.h>
#include <stdio.h>
#include "resource.h"
#include "include/big.h"			// include MIRACL system

HINSTANCE  hInst   = NULL;

// D�claration des bignums
big bigmod,bigd,bigname,bigserial;

DWORD serialnumber;

// 
char recname[256];
char recserial[256];
char key[256];


/*
 * Genere le serial valide correspondant au serial pass� en argument
 *
 * retour :		serial dont un pointeur est pass� en argument
 *
 */
void generate(char *name, char *serial)
{
	miracl *mip=mirsys(200,0);

	// initialisation des bignums
	mip->IOBASE=16;		//radix=16

	bigmod=mirvar(0);
	bigname=mirvar(0);
	bigd=mirvar(0);
	bigserial=mirvar(0);

	cinstr(bigmod,"666AAA422FDF79E1D4E41EDDC4D42C51");
	cinstr(bigd,"65537");
	bytes_to_big(strlen(name),name,bigname);

	powmod(bigname,bigd,bigmod,bigserial);			// bigserial = bigname^bigd mod bigmod

	cotstr(bigserial,serial);

	mirkill(bigmod);
	mirkill(bigname);
	mirkill(bigd);
	mirkill(bigserial);
}



LRESULT CALLBACK DlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)  
{
	switch(msg)
	{
		case WM_INITDIALOG:
		{

			GetVolumeInformation("C:\\",0,0,&serialnumber,0,0,0,0);
			wsprintf(key,"%d",serialnumber);
			SetDlgItemText(hwnd,ID_TXT_NAME,key);

			GetDlgItemText(hwnd,ID_TXT_NAME,recname,256);
			generate(recname,recserial);
			SetDlgItemText(hwnd,ID_TXT_SERIAL,recserial);

  
			break;
		}
		case WM_COMMAND: 
		{
			switch(LOWORD(wParam))
			{

				case ID_BT_EXIT:
				{
					EndDialog(hwnd, FALSE);
					break;
				}
				
			}
			break;
		}

		case ID_CANCEL:
		{
			EndDialog(hwnd, FALSE);
			break;
		}

		break;

	 }

     return FALSE; 
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInst, LPSTR lpCmdLine, int nCmdShow)   
{
	hInst = hInstance; 
	DialogBox(hInst, MAKEINTRESOURCE(IDD_APP),NULL,(DLGPROC) DlgProc);

	return (0);
}