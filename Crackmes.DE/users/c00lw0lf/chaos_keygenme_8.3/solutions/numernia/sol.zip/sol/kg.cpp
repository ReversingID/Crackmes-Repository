unsigned long havalints[8] = {0,0,0,0,0,0,0,0};
      
void HavalInit()
{
	havalints[0] = 0x243F6A88;
	havalints[1] = 0x85A308D3;
	havalints[2] = 0x13198A2E;
	havalints[3] = 0x03707344;
	havalints[4] = 0xA4093822;
	havalints[5] = 0x299F31D0;
	havalints[6] = 0x082EFA98;
	havalints[7] = 0xEC4E6C89;
}
void HavalTransform()
{
	__asm
	{
		 mov     edi, edi
		push    ebp
        mov     ebp, esp
        add     esp, -020h
        pushad
        lea     esi, havalints
        mov     edi, eax
        mov     eax, dword ptr ds:[esi]
        mov     ebx, dword ptr ds:[esi+4]
        mov     ecx, dword ptr ds:[esi+8]
        mov     edx, dword ptr ds:[esi+0ch]
        mov     dword ptr ss:[ebp-020h], eax
        mov     dword ptr ss:[ebp-01ch], ebx
        mov     dword ptr ss:[ebp-018h], ecx
        mov     dword ptr ss:[ebp-014h], edx
        mov     eax, dword ptr ds:[esi+010h]
        mov     ebx, dword ptr ds:[esi+014h]
        mov     ecx, dword ptr ds:[esi+018h]
        mov     edx, dword ptr ds:[esi+01ch]
        mov     dword ptr ss:[ebp-010h], eax
        mov     dword ptr ss:[ebp-0ch], ebx
        mov     dword ptr ss:[ebp-8], ecx
        mov     dword ptr ss:[ebp-4], edx
        mov     eax, dword ptr ss:[ebp-8]
        mov     ecx, dword ptr ss:[ebp-0ch]
        mov     edx, dword ptr ss:[ebp-020h]
        xor     eax, dword ptr ss:[ebp-01ch]
        and     ecx, dword ptr ss:[ebp-010h]
        and     eax, dword ptr ss:[ebp-018h]
        and     edx, dword ptr ss:[ebp-014h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-8]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-4]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi]
        add     eax, ecx
        mov     dword ptr ss:[ebp-4], eax
        mov     eax, dword ptr ss:[ebp-0ch]
        mov     ecx, dword ptr ss:[ebp-010h]
        mov     edx, dword ptr ss:[ebp-4]
        xor     eax, dword ptr ss:[ebp-020h]
        and     ecx, dword ptr ss:[ebp-014h]
        and     eax, dword ptr ss:[ebp-01ch]
        and     edx, dword ptr ss:[ebp-018h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-0ch]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-8]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+4]
        add     eax, ecx
        mov     dword ptr ss:[ebp-8], eax
        mov     eax, dword ptr ss:[ebp-010h]
        mov     ecx, dword ptr ss:[ebp-014h]
        mov     edx, dword ptr ss:[ebp-8]
        xor     eax, dword ptr ss:[ebp-4]
        and     ecx, dword ptr ss:[ebp-018h]
        and     eax, dword ptr ss:[ebp-020h]
        and     edx, dword ptr ss:[ebp-01ch]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-010h]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-0ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+8]
        add     eax, ecx
        mov     dword ptr ss:[ebp-0ch], eax
        mov     eax, dword ptr ss:[ebp-014h]
        mov     ecx, dword ptr ss:[ebp-018h]
        mov     edx, dword ptr ss:[ebp-0ch]
        xor     eax, dword ptr ss:[ebp-8]
        and     ecx, dword ptr ss:[ebp-01ch]
        and     eax, dword ptr ss:[ebp-4]
        and     edx, dword ptr ss:[ebp-020h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-014h]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-010h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+0ch]
        add     eax, ecx
        mov     dword ptr ss:[ebp-010h], eax
        mov     eax, dword ptr ss:[ebp-018h]
        mov     ecx, dword ptr ss:[ebp-01ch]
        mov     edx, dword ptr ss:[ebp-010h]
        xor     eax, dword ptr ss:[ebp-0ch]
        and     ecx, dword ptr ss:[ebp-020h]
        and     eax, dword ptr ss:[ebp-8]
        and     edx, dword ptr ss:[ebp-4]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-018h]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-014h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+010h]
        add     eax, ecx
        mov     dword ptr ss:[ebp-014h], eax
        mov     eax, dword ptr ss:[ebp-01ch]
        mov     ecx, dword ptr ss:[ebp-020h]
        mov     edx, dword ptr ss:[ebp-014h]
        xor     eax, dword ptr ss:[ebp-010h]
        and     ecx, dword ptr ss:[ebp-4]
        and     eax, dword ptr ss:[ebp-0ch]
        and     edx, dword ptr ss:[ebp-8]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-01ch]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-018h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+014h]
        add     eax, ecx
        mov     dword ptr ss:[ebp-018h], eax
        mov     eax, dword ptr ss:[ebp-020h]
        mov     ecx, dword ptr ss:[ebp-4]
        mov     edx, dword ptr ss:[ebp-018h]
        xor     eax, dword ptr ss:[ebp-014h]
        and     ecx, dword ptr ss:[ebp-8]
        and     eax, dword ptr ss:[ebp-010h]
        and     edx, dword ptr ss:[ebp-0ch]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-020h]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-01ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+018h]
        add     eax, ecx
        mov     dword ptr ss:[ebp-01ch], eax
        mov     eax, dword ptr ss:[ebp-4]
        mov     ecx, dword ptr ss:[ebp-8]
        mov     edx, dword ptr ss:[ebp-01ch]
        xor     eax, dword ptr ss:[ebp-018h]
        and     ecx, dword ptr ss:[ebp-0ch]
        and     eax, dword ptr ss:[ebp-014h]
        and     edx, dword ptr ss:[ebp-010h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-4]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-020h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+01ch]
        add     eax, ecx
        mov     dword ptr ss:[ebp-020h], eax
        mov     eax, dword ptr ss:[ebp-8]
        mov     ecx, dword ptr ss:[ebp-0ch]
        mov     edx, dword ptr ss:[ebp-020h]
        xor     eax, dword ptr ss:[ebp-01ch]
        and     ecx, dword ptr ss:[ebp-010h]
        and     eax, dword ptr ss:[ebp-018h]
        and     edx, dword ptr ss:[ebp-014h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-8]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-4]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+020h]
        add     eax, ecx
        mov     dword ptr ss:[ebp-4], eax
        mov     eax, dword ptr ss:[ebp-0ch]
        mov     ecx, dword ptr ss:[ebp-010h]
        mov     edx, dword ptr ss:[ebp-4]
        xor     eax, dword ptr ss:[ebp-020h]
        and     ecx, dword ptr ss:[ebp-014h]
        and     eax, dword ptr ss:[ebp-01ch]
        and     edx, dword ptr ss:[ebp-018h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-0ch]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-8]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+024h]
        add     eax, ecx
        mov     dword ptr ss:[ebp-8], eax
        mov     eax, dword ptr ss:[ebp-010h]
        mov     ecx, dword ptr ss:[ebp-014h]
        mov     edx, dword ptr ss:[ebp-8]
        xor     eax, dword ptr ss:[ebp-4]
        and     ecx, dword ptr ss:[ebp-018h]
        and     eax, dword ptr ss:[ebp-020h]
        and     edx, dword ptr ss:[ebp-01ch]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-010h]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-0ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+028h]
        add     eax, ecx
        mov     dword ptr ss:[ebp-0ch], eax
        mov     eax, dword ptr ss:[ebp-014h]
        mov     ecx, dword ptr ss:[ebp-018h]
        mov     edx, dword ptr ss:[ebp-0ch]
        xor     eax, dword ptr ss:[ebp-8]
        and     ecx, dword ptr ss:[ebp-01ch]
        and     eax, dword ptr ss:[ebp-4]
        and     edx, dword ptr ss:[ebp-020h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-014h]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-010h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+02ch]
        add     eax, ecx
        mov     dword ptr ss:[ebp-010h], eax
        mov     eax, dword ptr ss:[ebp-018h]
        mov     ecx, dword ptr ss:[ebp-01ch]
        mov     edx, dword ptr ss:[ebp-010h]
        xor     eax, dword ptr ss:[ebp-0ch]
        and     ecx, dword ptr ss:[ebp-020h]
        and     eax, dword ptr ss:[ebp-8]
        and     edx, dword ptr ss:[ebp-4]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-018h]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-014h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+030h]
        add     eax, ecx
        mov     dword ptr ss:[ebp-014h], eax
        mov     eax, dword ptr ss:[ebp-01ch]
        mov     ecx, dword ptr ss:[ebp-020h]
        mov     edx, dword ptr ss:[ebp-014h]
        xor     eax, dword ptr ss:[ebp-010h]
        and     ecx, dword ptr ss:[ebp-4]
        and     eax, dword ptr ss:[ebp-0ch]
        and     edx, dword ptr ss:[ebp-8]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-01ch]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-018h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+034h]
        add     eax, ecx
        mov     dword ptr ss:[ebp-018h], eax
        mov     eax, dword ptr ss:[ebp-020h]
        mov     ecx, dword ptr ss:[ebp-4]
        mov     edx, dword ptr ss:[ebp-018h]
        xor     eax, dword ptr ss:[ebp-014h]
        and     ecx, dword ptr ss:[ebp-8]
        and     eax, dword ptr ss:[ebp-010h]
        and     edx, dword ptr ss:[ebp-0ch]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-020h]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-01ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+038h]
        add     eax, ecx
        mov     dword ptr ss:[ebp-01ch], eax
        mov     eax, dword ptr ss:[ebp-4]
        mov     ecx, dword ptr ss:[ebp-8]
        mov     edx, dword ptr ss:[ebp-01ch]
        xor     eax, dword ptr ss:[ebp-018h]
        and     ecx, dword ptr ss:[ebp-0ch]
        and     eax, dword ptr ss:[ebp-014h]
        and     edx, dword ptr ss:[ebp-010h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-4]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-020h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+03ch]
        add     eax, ecx
        mov     dword ptr ss:[ebp-020h], eax
        mov     eax, dword ptr ss:[ebp-8]
        mov     ecx, dword ptr ss:[ebp-0ch]
        mov     edx, dword ptr ss:[ebp-020h]
        xor     eax, dword ptr ss:[ebp-01ch]
        and     ecx, dword ptr ss:[ebp-010h]
        and     eax, dword ptr ss:[ebp-018h]
        and     edx, dword ptr ss:[ebp-014h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-8]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-4]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+040h]
        add     eax, ecx
        mov     dword ptr ss:[ebp-4], eax
        mov     eax, dword ptr ss:[ebp-0ch]
        mov     ecx, dword ptr ss:[ebp-010h]
        mov     edx, dword ptr ss:[ebp-4]
        xor     eax, dword ptr ss:[ebp-020h]
        and     ecx, dword ptr ss:[ebp-014h]
        and     eax, dword ptr ss:[ebp-01ch]
        and     edx, dword ptr ss:[ebp-018h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-0ch]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-8]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+044h]
        add     eax, ecx
        mov     dword ptr ss:[ebp-8], eax
        mov     eax, dword ptr ss:[ebp-010h]
        mov     ecx, dword ptr ss:[ebp-014h]
        mov     edx, dword ptr ss:[ebp-8]
        xor     eax, dword ptr ss:[ebp-4]
        and     ecx, dword ptr ss:[ebp-018h]
        and     eax, dword ptr ss:[ebp-020h]
        and     edx, dword ptr ss:[ebp-01ch]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-010h]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-0ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+048h]
        add     eax, ecx
        mov     dword ptr ss:[ebp-0ch], eax
        mov     eax, dword ptr ss:[ebp-014h]
        mov     ecx, dword ptr ss:[ebp-018h]
        mov     edx, dword ptr ss:[ebp-0ch]
        xor     eax, dword ptr ss:[ebp-8]
        and     ecx, dword ptr ss:[ebp-01ch]
        and     eax, dword ptr ss:[ebp-4]
        and     edx, dword ptr ss:[ebp-020h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-014h]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-010h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+04ch]
        add     eax, ecx
        mov     dword ptr ss:[ebp-010h], eax
        mov     eax, dword ptr ss:[ebp-018h]
        mov     ecx, dword ptr ss:[ebp-01ch]
        mov     edx, dword ptr ss:[ebp-010h]
        xor     eax, dword ptr ss:[ebp-0ch]
        and     ecx, dword ptr ss:[ebp-020h]
        and     eax, dword ptr ss:[ebp-8]
        and     edx, dword ptr ss:[ebp-4]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-018h]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-014h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+050h]
        add     eax, ecx
        mov     dword ptr ss:[ebp-014h], eax
        mov     eax, dword ptr ss:[ebp-01ch]
        mov     ecx, dword ptr ss:[ebp-020h]
        mov     edx, dword ptr ss:[ebp-014h]
        xor     eax, dword ptr ss:[ebp-010h]
        and     ecx, dword ptr ss:[ebp-4]
        and     eax, dword ptr ss:[ebp-0ch]
        and     edx, dword ptr ss:[ebp-8]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-01ch]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-018h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+054h]
        add     eax, ecx
        mov     dword ptr ss:[ebp-018h], eax
        mov     eax, dword ptr ss:[ebp-020h]
        mov     ecx, dword ptr ss:[ebp-4]
        mov     edx, dword ptr ss:[ebp-018h]
        xor     eax, dword ptr ss:[ebp-014h]
        and     ecx, dword ptr ss:[ebp-8]
        and     eax, dword ptr ss:[ebp-010h]
        and     edx, dword ptr ss:[ebp-0ch]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-020h]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-01ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+058h]
        add     eax, ecx
        mov     dword ptr ss:[ebp-01ch], eax
        mov     eax, dword ptr ss:[ebp-4]
        mov     ecx, dword ptr ss:[ebp-8]
        mov     edx, dword ptr ss:[ebp-01ch]
        xor     eax, dword ptr ss:[ebp-018h]
        and     ecx, dword ptr ss:[ebp-0ch]
        and     eax, dword ptr ss:[ebp-014h]
        and     edx, dword ptr ss:[ebp-010h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-4]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-020h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+05ch]
        add     eax, ecx
        mov     dword ptr ss:[ebp-020h], eax
        mov     eax, dword ptr ss:[ebp-8]
        mov     ecx, dword ptr ss:[ebp-0ch]
        mov     edx, dword ptr ss:[ebp-020h]
        xor     eax, dword ptr ss:[ebp-01ch]
        and     ecx, dword ptr ss:[ebp-010h]
        and     eax, dword ptr ss:[ebp-018h]
        and     edx, dword ptr ss:[ebp-014h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-8]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-4]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+060h]
        add     eax, ecx
        mov     dword ptr ss:[ebp-4], eax
        mov     eax, dword ptr ss:[ebp-0ch]
        mov     ecx, dword ptr ss:[ebp-010h]
        mov     edx, dword ptr ss:[ebp-4]
        xor     eax, dword ptr ss:[ebp-020h]
        and     ecx, dword ptr ss:[ebp-014h]
        and     eax, dword ptr ss:[ebp-01ch]
        and     edx, dword ptr ss:[ebp-018h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-0ch]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-8]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+064h]
        add     eax, ecx
        mov     dword ptr ss:[ebp-8], eax
        mov     eax, dword ptr ss:[ebp-010h]
        mov     ecx, dword ptr ss:[ebp-014h]
        mov     edx, dword ptr ss:[ebp-8]
        xor     eax, dword ptr ss:[ebp-4]
        and     ecx, dword ptr ss:[ebp-018h]
        and     eax, dword ptr ss:[ebp-020h]
        and     edx, dword ptr ss:[ebp-01ch]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-010h]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-0ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+068h]
        add     eax, ecx
        mov     dword ptr ss:[ebp-0ch], eax
        mov     eax, dword ptr ss:[ebp-014h]
        mov     ecx, dword ptr ss:[ebp-018h]
        mov     edx, dword ptr ss:[ebp-0ch]
        xor     eax, dword ptr ss:[ebp-8]
        and     ecx, dword ptr ss:[ebp-01ch]
        and     eax, dword ptr ss:[ebp-4]
        and     edx, dword ptr ss:[ebp-020h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-014h]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-010h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+06ch]
        add     eax, ecx
        mov     dword ptr ss:[ebp-010h], eax
        mov     eax, dword ptr ss:[ebp-018h]
        mov     ecx, dword ptr ss:[ebp-01ch]
        mov     edx, dword ptr ss:[ebp-010h]
        xor     eax, dword ptr ss:[ebp-0ch]
        and     ecx, dword ptr ss:[ebp-020h]
        and     eax, dword ptr ss:[ebp-8]
        and     edx, dword ptr ss:[ebp-4]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-018h]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-014h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+070h]
        add     eax, ecx
        mov     dword ptr ss:[ebp-014h], eax
        mov     eax, dword ptr ss:[ebp-01ch]
        mov     ecx, dword ptr ss:[ebp-020h]
        mov     edx, dword ptr ss:[ebp-014h]
        xor     eax, dword ptr ss:[ebp-010h]
        and     ecx, dword ptr ss:[ebp-4]
        and     eax, dword ptr ss:[ebp-0ch]
        and     edx, dword ptr ss:[ebp-8]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-01ch]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-018h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+074h]
        add     eax, ecx
        mov     dword ptr ss:[ebp-018h], eax
        mov     eax, dword ptr ss:[ebp-020h]
        mov     ecx, dword ptr ss:[ebp-4]
        mov     edx, dword ptr ss:[ebp-018h]
        xor     eax, dword ptr ss:[ebp-014h]
        and     ecx, dword ptr ss:[ebp-8]
        and     eax, dword ptr ss:[ebp-010h]
        and     edx, dword ptr ss:[ebp-0ch]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-020h]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-01ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+078h]
        add     eax, ecx
        mov     dword ptr ss:[ebp-01ch], eax
        mov     eax, dword ptr ss:[ebp-4]
        mov     ecx, dword ptr ss:[ebp-8]
        mov     edx, dword ptr ss:[ebp-01ch]
        xor     eax, dword ptr ss:[ebp-018h]
        and     ecx, dword ptr ss:[ebp-0ch]
        and     eax, dword ptr ss:[ebp-014h]
        and     edx, dword ptr ss:[ebp-010h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-4]
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-020h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+07ch]
        add     eax, ecx
        mov     dword ptr ss:[ebp-020h], eax
        mov     eax, dword ptr ss:[ebp-020h]
        mov     ebx, dword ptr ss:[ebp-010h]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-018h]
        mov     ecx, dword ptr ss:[ebp-01ch]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-8]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-0ch]
        and     eax, dword ptr ss:[ebp-014h]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-01ch]
        and     edx, dword ptr ss:[ebp-020h]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-0ch]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-4]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+014h]
        lea     eax, dword ptr ds:[ecx+eax+0452821e6h]
        mov     dword ptr ss:[ebp-4], eax
        mov     eax, dword ptr ss:[ebp-4]
        mov     ebx, dword ptr ss:[ebp-014h]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-01ch]
        mov     ecx, dword ptr ss:[ebp-020h]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-0ch]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-010h]
        and     eax, dword ptr ss:[ebp-018h]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-020h]
        and     edx, dword ptr ss:[ebp-4]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-010h]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-8]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+038h]
        lea     eax, dword ptr ds:[ecx+eax+038d01377h]
        mov     dword ptr ss:[ebp-8], eax
        mov     eax, dword ptr ss:[ebp-8]
        mov     ebx, dword ptr ss:[ebp-018h]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-020h]
        mov     ecx, dword ptr ss:[ebp-4]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-010h]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-014h]
        and     eax, dword ptr ss:[ebp-01ch]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-4]
        and     edx, dword ptr ss:[ebp-8]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-014h]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-0ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+068h]
        lea     eax, dword ptr ds:[ecx+eax+0be5466cfh]
        mov     dword ptr ss:[ebp-0ch], eax
        mov     eax, dword ptr ss:[ebp-0ch]
        mov     ebx, dword ptr ss:[ebp-01ch]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-4]
        mov     ecx, dword ptr ss:[ebp-8]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-014h]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-018h]
        and     eax, dword ptr ss:[ebp-020h]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-8]
        and     edx, dword ptr ss:[ebp-0ch]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-018h]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-010h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+048h]
        lea     eax, dword ptr ds:[ecx+eax+034e90c6ch]
        mov     dword ptr ss:[ebp-010h], eax
        mov     eax, dword ptr ss:[ebp-010h]
        mov     ebx, dword ptr ss:[ebp-020h]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-8]
        mov     ecx, dword ptr ss:[ebp-0ch]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-018h]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-01ch]
        and     eax, dword ptr ss:[ebp-4]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-0ch]
        and     edx, dword ptr ss:[ebp-010h]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-01ch]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-014h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+02ch]
        lea     eax, dword ptr ds:[ecx+eax+0c0ac29b7h]
        mov     dword ptr ss:[ebp-014h], eax
        mov     eax, dword ptr ss:[ebp-014h]
        mov     ebx, dword ptr ss:[ebp-4]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-0ch]
        mov     ecx, dword ptr ss:[ebp-010h]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-01ch]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-020h]
        and     eax, dword ptr ss:[ebp-8]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-010h]
        and     edx, dword ptr ss:[ebp-014h]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-020h]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-018h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+070h]
        lea     eax, dword ptr ds:[ecx+eax+0c97c50ddh]
        mov     dword ptr ss:[ebp-018h], eax
        mov     eax, dword ptr ss:[ebp-018h]
        mov     ebx, dword ptr ss:[ebp-8]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-010h]
        mov     ecx, dword ptr ss:[ebp-014h]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-020h]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-4]
        and     eax, dword ptr ss:[ebp-0ch]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-014h]
        and     edx, dword ptr ss:[ebp-018h]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-4]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-01ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+01ch]
        lea     eax, dword ptr ds:[ecx+eax+03f84d5b5h]
        mov     dword ptr ss:[ebp-01ch], eax
        mov     eax, dword ptr ss:[ebp-01ch]
        mov     ebx, dword ptr ss:[ebp-0ch]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-014h]
        mov     ecx, dword ptr ss:[ebp-018h]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-4]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-8]
        and     eax, dword ptr ss:[ebp-010h]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-018h]
        and     edx, dword ptr ss:[ebp-01ch]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-8]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-020h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+040h]
        lea     eax, dword ptr ds:[ecx+eax+0b5470917h]
        mov     dword ptr ss:[ebp-020h], eax
        mov     eax, dword ptr ss:[ebp-020h]
        mov     ebx, dword ptr ss:[ebp-010h]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-018h]
        mov     ecx, dword ptr ss:[ebp-01ch]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-8]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-0ch]
        and     eax, dword ptr ss:[ebp-014h]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-01ch]
        and     edx, dword ptr ss:[ebp-020h]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-0ch]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-4]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi]
        lea     eax, dword ptr ds:[ecx+eax+09216d5d9h]
        mov     dword ptr ss:[ebp-4], eax
        mov     eax, dword ptr ss:[ebp-4]
        mov     ebx, dword ptr ss:[ebp-014h]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-01ch]
        mov     ecx, dword ptr ss:[ebp-020h]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-0ch]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-010h]
        and     eax, dword ptr ss:[ebp-018h]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-020h]
        and     edx, dword ptr ss:[ebp-4]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-010h]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-8]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+05ch]
        lea     eax, dword ptr ds:[ecx+eax+08979fb1bh]
        mov     dword ptr ss:[ebp-8], eax
        mov     eax, dword ptr ss:[ebp-8]
        mov     ebx, dword ptr ss:[ebp-018h]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-020h]
        mov     ecx, dword ptr ss:[ebp-4]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-010h]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-014h]
        and     eax, dword ptr ss:[ebp-01ch]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-4]
        and     edx, dword ptr ss:[ebp-8]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-014h]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-0ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+050h]
        lea     eax, dword ptr ds:[ecx+eax+0d1310ba6h]
        mov     dword ptr ss:[ebp-0ch], eax
        mov     eax, dword ptr ss:[ebp-0ch]
        mov     ebx, dword ptr ss:[ebp-01ch]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-4]
        mov     ecx, dword ptr ss:[ebp-8]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-014h]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-018h]
        and     eax, dword ptr ss:[ebp-020h]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-8]
        and     edx, dword ptr ss:[ebp-0ch]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-018h]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-010h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+058h]
        lea     eax, dword ptr ds:[ecx+eax+098dfb5ach]
        mov     dword ptr ss:[ebp-010h], eax
        mov     eax, dword ptr ss:[ebp-010h]
        mov     ebx, dword ptr ss:[ebp-020h]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-8]
        mov     ecx, dword ptr ss:[ebp-0ch]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-018h]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-01ch]
        and     eax, dword ptr ss:[ebp-4]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-0ch]
        and     edx, dword ptr ss:[ebp-010h]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-01ch]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-014h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+4]
        lea     eax, dword ptr ds:[ecx+eax+02ffd72dbh]
        mov     dword ptr ss:[ebp-014h], eax
        mov     eax, dword ptr ss:[ebp-014h]
        mov     ebx, dword ptr ss:[ebp-4]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-0ch]
        mov     ecx, dword ptr ss:[ebp-010h]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-01ch]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-020h]
        and     eax, dword ptr ss:[ebp-8]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-010h]
        and     edx, dword ptr ss:[ebp-014h]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-020h]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-018h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+028h]
        lea     eax, dword ptr ds:[ecx+eax+0d01adfb7h]
        mov     dword ptr ss:[ebp-018h], eax
        mov     eax, dword ptr ss:[ebp-018h]
        mov     ebx, dword ptr ss:[ebp-8]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-010h]
        mov     ecx, dword ptr ss:[ebp-014h]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-020h]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-4]
        and     eax, dword ptr ss:[ebp-0ch]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-014h]
        and     edx, dword ptr ss:[ebp-018h]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-4]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-01ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+010h]
        lea     eax, dword ptr ds:[ecx+eax+0b8e1afedh]
        mov     dword ptr ss:[ebp-01ch], eax
        mov     eax, dword ptr ss:[ebp-01ch]
        mov     ebx, dword ptr ss:[ebp-0ch]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-014h]
        mov     ecx, dword ptr ss:[ebp-018h]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-4]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-8]
        and     eax, dword ptr ss:[ebp-010h]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-018h]
        and     edx, dword ptr ss:[ebp-01ch]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-8]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-020h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+020h]
        lea     eax, dword ptr ds:[ecx+eax+06a267e96h]
        mov     dword ptr ss:[ebp-020h], eax
        mov     eax, dword ptr ss:[ebp-020h]
        mov     ebx, dword ptr ss:[ebp-010h]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-018h]
        mov     ecx, dword ptr ss:[ebp-01ch]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-8]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-0ch]
        and     eax, dword ptr ss:[ebp-014h]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-01ch]
        and     edx, dword ptr ss:[ebp-020h]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-0ch]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-4]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+078h]
        lea     eax, dword ptr ds:[ecx+eax+0ba7c9045h]
        mov     dword ptr ss:[ebp-4], eax
        mov     eax, dword ptr ss:[ebp-4]
        mov     ebx, dword ptr ss:[ebp-014h]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-01ch]
        mov     ecx, dword ptr ss:[ebp-020h]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-0ch]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-010h]
        and     eax, dword ptr ss:[ebp-018h]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-020h]
        and     edx, dword ptr ss:[ebp-4]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-010h]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-8]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+0ch]
        lea     eax, dword ptr ds:[ecx+eax+0f12c7f99h]
        mov     dword ptr ss:[ebp-8], eax
        mov     eax, dword ptr ss:[ebp-8]
        mov     ebx, dword ptr ss:[ebp-018h]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-020h]
        mov     ecx, dword ptr ss:[ebp-4]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-010h]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-014h]
        and     eax, dword ptr ss:[ebp-01ch]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-4]
        and     edx, dword ptr ss:[ebp-8]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-014h]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-0ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+054h]
        lea     eax, dword ptr ds:[ecx+eax+024a19947h]
        mov     dword ptr ss:[ebp-0ch], eax
        mov     eax, dword ptr ss:[ebp-0ch]
        mov     ebx, dword ptr ss:[ebp-01ch]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-4]
        mov     ecx, dword ptr ss:[ebp-8]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-014h]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-018h]
        and     eax, dword ptr ss:[ebp-020h]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-8]
        and     edx, dword ptr ss:[ebp-0ch]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-018h]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-010h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+024h]
        lea     eax, dword ptr ds:[ecx+eax+0b3916cf7h]
        mov     dword ptr ss:[ebp-010h], eax
        mov     eax, dword ptr ss:[ebp-010h]
        mov     ebx, dword ptr ss:[ebp-020h]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-8]
        mov     ecx, dword ptr ss:[ebp-0ch]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-018h]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-01ch]
        and     eax, dword ptr ss:[ebp-4]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-0ch]
        and     edx, dword ptr ss:[ebp-010h]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-01ch]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-014h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+044h]
        lea     eax, dword ptr ds:[ecx+eax+0801f2e2h]
        mov     dword ptr ss:[ebp-014h], eax
        mov     eax, dword ptr ss:[ebp-014h]
        mov     ebx, dword ptr ss:[ebp-4]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-0ch]
        mov     ecx, dword ptr ss:[ebp-010h]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-01ch]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-020h]
        and     eax, dword ptr ss:[ebp-8]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-010h]
        and     edx, dword ptr ss:[ebp-014h]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-020h]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-018h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+060h]
        lea     eax, dword ptr ds:[ecx+eax+0858efc16h]
        mov     dword ptr ss:[ebp-018h], eax
        mov     eax, dword ptr ss:[ebp-018h]
        mov     ebx, dword ptr ss:[ebp-8]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-010h]
        mov     ecx, dword ptr ss:[ebp-014h]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-020h]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-4]
        and     eax, dword ptr ss:[ebp-0ch]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-014h]
        and     edx, dword ptr ss:[ebp-018h]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-4]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-01ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+074h]
        lea     eax, dword ptr ds:[ecx+eax+0636920d8h]
        mov     dword ptr ss:[ebp-01ch], eax
        mov     eax, dword ptr ss:[ebp-01ch]
        mov     ebx, dword ptr ss:[ebp-0ch]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-014h]
        mov     ecx, dword ptr ss:[ebp-018h]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-4]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-8]
        and     eax, dword ptr ss:[ebp-010h]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-018h]
        and     edx, dword ptr ss:[ebp-01ch]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-8]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-020h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+018h]
        lea     eax, dword ptr ds:[ecx+eax+071574e69h]
        mov     dword ptr ss:[ebp-020h], eax
        mov     eax, dword ptr ss:[ebp-020h]
        mov     ebx, dword ptr ss:[ebp-010h]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-018h]
        mov     ecx, dword ptr ss:[ebp-01ch]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-8]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-0ch]
        and     eax, dword ptr ss:[ebp-014h]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-01ch]
        and     edx, dword ptr ss:[ebp-020h]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-0ch]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-4]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+04ch]
        lea     eax, dword ptr ds:[ecx+eax+0a458fea3h]
        mov     dword ptr ss:[ebp-4], eax
        mov     eax, dword ptr ss:[ebp-4]
        mov     ebx, dword ptr ss:[ebp-014h]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-01ch]
        mov     ecx, dword ptr ss:[ebp-020h]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-0ch]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-010h]
        and     eax, dword ptr ss:[ebp-018h]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-020h]
        and     edx, dword ptr ss:[ebp-4]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-010h]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-8]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+030h]
        lea     eax, dword ptr ds:[ecx+eax+0f4933d7eh]
        mov     dword ptr ss:[ebp-8], eax
        mov     eax, dword ptr ss:[ebp-8]
        mov     ebx, dword ptr ss:[ebp-018h]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-020h]
        mov     ecx, dword ptr ss:[ebp-4]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-010h]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-014h]
        and     eax, dword ptr ss:[ebp-01ch]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-4]
        and     edx, dword ptr ss:[ebp-8]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-014h]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-0ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+03ch]
        lea     eax, dword ptr ds:[ecx+eax+0d95748fh]
        mov     dword ptr ss:[ebp-0ch], eax
        mov     eax, dword ptr ss:[ebp-0ch]
        mov     ebx, dword ptr ss:[ebp-01ch]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-4]
        mov     ecx, dword ptr ss:[ebp-8]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-014h]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-018h]
        and     eax, dword ptr ss:[ebp-020h]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-8]
        and     edx, dword ptr ss:[ebp-0ch]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-018h]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-010h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+034h]
        lea     eax, dword ptr ds:[ecx+eax+0728eb658h]
        mov     dword ptr ss:[ebp-010h], eax
        mov     eax, dword ptr ss:[ebp-010h]
        mov     ebx, dword ptr ss:[ebp-020h]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-8]
        mov     ecx, dword ptr ss:[ebp-0ch]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-018h]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-01ch]
        and     eax, dword ptr ss:[ebp-4]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-0ch]
        and     edx, dword ptr ss:[ebp-010h]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-01ch]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-014h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+8]
        lea     eax, dword ptr ds:[ecx+eax+0718bcd58h]
        mov     dword ptr ss:[ebp-014h], eax
        mov     eax, dword ptr ss:[ebp-014h]
        mov     ebx, dword ptr ss:[ebp-4]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-0ch]
        mov     ecx, dword ptr ss:[ebp-010h]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-01ch]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-020h]
        and     eax, dword ptr ss:[ebp-8]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-010h]
        and     edx, dword ptr ss:[ebp-014h]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-020h]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-018h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+064h]
        lea     eax, dword ptr ds:[ecx+eax+082154aeeh]
        mov     dword ptr ss:[ebp-018h], eax
        mov     eax, dword ptr ss:[ebp-018h]
        mov     ebx, dword ptr ss:[ebp-8]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-010h]
        mov     ecx, dword ptr ss:[ebp-014h]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-020h]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-4]
        and     eax, dword ptr ss:[ebp-0ch]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-014h]
        and     edx, dword ptr ss:[ebp-018h]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-4]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-01ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+07ch]
        lea     eax, dword ptr ds:[ecx+eax+07b54a41dh]
        mov     dword ptr ss:[ebp-01ch], eax
        mov     eax, dword ptr ss:[ebp-01ch]
        mov     ebx, dword ptr ss:[ebp-0ch]
        xor     eax, 0ffffffffh
        mov     edx, dword ptr ss:[ebp-014h]
        mov     ecx, dword ptr ss:[ebp-018h]
        and     eax, ebx
        and     ecx, edx
        xor     eax, dword ptr ss:[ebp-4]
        xor     eax, ecx
        xor     eax, dword ptr ss:[ebp-8]
        and     eax, dword ptr ss:[ebp-010h]
        xor     ebx, edx
        and     ebx, dword ptr ss:[ebp-018h]
        and     edx, dword ptr ss:[ebp-01ch]
        xor     edx, ebx
        xor     eax, dword ptr ss:[ebp-8]
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-020h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+06ch]
        lea     eax, dword ptr ds:[ecx+eax+0c25a59b5h]
        mov     dword ptr ss:[ebp-020h], eax
        mov     eax, dword ptr ss:[ebp-014h]
        mov     ecx, dword ptr ss:[ebp-01ch]
        mov     edx, dword ptr ss:[ebp-0ch]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-018h]
        mov     ebx, dword ptr ss:[ebp-8]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-010h]
        and     ecx, dword ptr ss:[ebp-020h]
        and     ebx, dword ptr ss:[ebp-014h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-4]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+04ch]
        lea     eax, dword ptr ds:[ecx+eax+09c30d539h]
        mov     dword ptr ss:[ebp-4], eax
        mov     eax, dword ptr ss:[ebp-018h]
        mov     ecx, dword ptr ss:[ebp-020h]
        mov     edx, dword ptr ss:[ebp-010h]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-01ch]
        mov     ebx, dword ptr ss:[ebp-0ch]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-014h]
        and     ecx, dword ptr ss:[ebp-4]
        and     ebx, dword ptr ss:[ebp-018h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-8]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+024h]
        lea     eax, dword ptr ds:[ecx+eax+02af26013h]
        mov     dword ptr ss:[ebp-8], eax
        mov     eax, dword ptr ss:[ebp-01ch]
        mov     ecx, dword ptr ss:[ebp-4]
        mov     edx, dword ptr ss:[ebp-014h]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-020h]
        mov     ebx, dword ptr ss:[ebp-010h]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-018h]
        and     ecx, dword ptr ss:[ebp-8]
        and     ebx, dword ptr ss:[ebp-01ch]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-0ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+010h]
        lea     eax, dword ptr ds:[ecx+eax+0c5d1b023h]
        mov     dword ptr ss:[ebp-0ch], eax
        mov     eax, dword ptr ss:[ebp-020h]
        mov     ecx, dword ptr ss:[ebp-8]
        mov     edx, dword ptr ss:[ebp-018h]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-4]
        mov     ebx, dword ptr ss:[ebp-014h]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-01ch]
        and     ecx, dword ptr ss:[ebp-0ch]
        and     ebx, dword ptr ss:[ebp-020h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-010h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+050h]
        lea     eax, dword ptr ds:[ecx+eax+0286085f0h]
        mov     dword ptr ss:[ebp-010h], eax
        mov     eax, dword ptr ss:[ebp-4]
        mov     ecx, dword ptr ss:[ebp-0ch]
        mov     edx, dword ptr ss:[ebp-01ch]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-8]
        mov     ebx, dword ptr ss:[ebp-018h]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-020h]
        and     ecx, dword ptr ss:[ebp-010h]
        and     ebx, dword ptr ss:[ebp-4]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-014h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+070h]
        lea     eax, dword ptr ds:[ecx+eax+0ca417918h]
        mov     dword ptr ss:[ebp-014h], eax
        mov     eax, dword ptr ss:[ebp-8]
        mov     ecx, dword ptr ss:[ebp-010h]
        mov     edx, dword ptr ss:[ebp-020h]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-0ch]
        mov     ebx, dword ptr ss:[ebp-01ch]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-4]
        and     ecx, dword ptr ss:[ebp-014h]
        and     ebx, dword ptr ss:[ebp-8]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-018h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+044h]
        lea     eax, dword ptr ds:[ecx+eax+0b8db38efh]
        mov     dword ptr ss:[ebp-018h], eax
        mov     eax, dword ptr ss:[ebp-0ch]
        mov     ecx, dword ptr ss:[ebp-014h]
        mov     edx, dword ptr ss:[ebp-4]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-010h]
        mov     ebx, dword ptr ss:[ebp-020h]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-8]
        and     ecx, dword ptr ss:[ebp-018h]
        and     ebx, dword ptr ss:[ebp-0ch]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-01ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+020h]
        lea     eax, dword ptr ds:[ecx+eax+08e79dcb0h]
        mov     dword ptr ss:[ebp-01ch], eax
        mov     eax, dword ptr ss:[ebp-010h]
        mov     ecx, dword ptr ss:[ebp-018h]
        mov     edx, dword ptr ss:[ebp-8]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-014h]
        mov     ebx, dword ptr ss:[ebp-4]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-0ch]
        and     ecx, dword ptr ss:[ebp-01ch]
        and     ebx, dword ptr ss:[ebp-010h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-020h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+058h]
        lea     eax, dword ptr ds:[ecx+eax+0603a180eh]
        mov     dword ptr ss:[ebp-020h], eax
        mov     eax, dword ptr ss:[ebp-014h]
        mov     ecx, dword ptr ss:[ebp-01ch]
        mov     edx, dword ptr ss:[ebp-0ch]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-018h]
        mov     ebx, dword ptr ss:[ebp-8]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-010h]
        and     ecx, dword ptr ss:[ebp-020h]
        and     ebx, dword ptr ss:[ebp-014h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-4]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+074h]
        lea     eax, dword ptr ds:[ecx+eax+06c9e0e8bh]
        mov     dword ptr ss:[ebp-4], eax
        mov     eax, dword ptr ss:[ebp-018h]
        mov     ecx, dword ptr ss:[ebp-020h]
        mov     edx, dword ptr ss:[ebp-010h]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-01ch]
        mov     ebx, dword ptr ss:[ebp-0ch]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-014h]
        and     ecx, dword ptr ss:[ebp-4]
        and     ebx, dword ptr ss:[ebp-018h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-8]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+038h]
        lea     eax, dword ptr ds:[ecx+eax+0b01e8a3eh]
        mov     dword ptr ss:[ebp-8], eax
        mov     eax, dword ptr ss:[ebp-01ch]
        mov     ecx, dword ptr ss:[ebp-4]
        mov     edx, dword ptr ss:[ebp-014h]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-020h]
        mov     ebx, dword ptr ss:[ebp-010h]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-018h]
        and     ecx, dword ptr ss:[ebp-8]
        and     ebx, dword ptr ss:[ebp-01ch]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-0ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+064h]
        lea     eax, dword ptr ds:[ecx+eax+0d71577c1h]
        mov     dword ptr ss:[ebp-0ch], eax
        mov     eax, dword ptr ss:[ebp-020h]
        mov     ecx, dword ptr ss:[ebp-8]
        mov     edx, dword ptr ss:[ebp-018h]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-4]
        mov     ebx, dword ptr ss:[ebp-014h]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-01ch]
        and     ecx, dword ptr ss:[ebp-0ch]
        and     ebx, dword ptr ss:[ebp-020h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-010h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+030h]
        lea     eax, dword ptr ds:[ecx+eax+0bd314b27h]
        mov     dword ptr ss:[ebp-010h], eax
        mov     eax, dword ptr ss:[ebp-4]
        mov     ecx, dword ptr ss:[ebp-0ch]
        mov     edx, dword ptr ss:[ebp-01ch]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-8]
        mov     ebx, dword ptr ss:[ebp-018h]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-020h]
        and     ecx, dword ptr ss:[ebp-010h]
        and     ebx, dword ptr ss:[ebp-4]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-014h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+060h]
        lea     eax, dword ptr ds:[ecx+eax+078af2fdah]
        mov     dword ptr ss:[ebp-014h], eax
        mov     eax, dword ptr ss:[ebp-8]
        mov     ecx, dword ptr ss:[ebp-010h]
        mov     edx, dword ptr ss:[ebp-020h]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-0ch]
        mov     ebx, dword ptr ss:[ebp-01ch]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-4]
        and     ecx, dword ptr ss:[ebp-014h]
        and     ebx, dword ptr ss:[ebp-8]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-018h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+078h]
        lea     eax, dword ptr ds:[ecx+eax+055605c60h]
        mov     dword ptr ss:[ebp-018h], eax
        mov     eax, dword ptr ss:[ebp-0ch]
        mov     ecx, dword ptr ss:[ebp-014h]
        mov     edx, dword ptr ss:[ebp-4]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-010h]
        mov     ebx, dword ptr ss:[ebp-020h]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-8]
        and     ecx, dword ptr ss:[ebp-018h]
        and     ebx, dword ptr ss:[ebp-0ch]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-01ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+040h]
        lea     eax, dword ptr ds:[ecx+eax+0e65525f3h]
        mov     dword ptr ss:[ebp-01ch], eax
        mov     eax, dword ptr ss:[ebp-010h]
        mov     ecx, dword ptr ss:[ebp-018h]
        mov     edx, dword ptr ss:[ebp-8]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-014h]
        mov     ebx, dword ptr ss:[ebp-4]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-0ch]
        and     ecx, dword ptr ss:[ebp-01ch]
        and     ebx, dword ptr ss:[ebp-010h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-020h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+068h]
        lea     eax, dword ptr ds:[ecx+eax+0aa55ab94h]
        mov     dword ptr ss:[ebp-020h], eax
        mov     eax, dword ptr ss:[ebp-014h]
        mov     ecx, dword ptr ss:[ebp-01ch]
        mov     edx, dword ptr ss:[ebp-0ch]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-018h]
        mov     ebx, dword ptr ss:[ebp-8]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-010h]
        and     ecx, dword ptr ss:[ebp-020h]
        and     ebx, dword ptr ss:[ebp-014h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-4]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+07ch]
        lea     eax, dword ptr ds:[ecx+eax+057489862h]
        mov     dword ptr ss:[ebp-4], eax
        mov     eax, dword ptr ss:[ebp-018h]
        mov     ecx, dword ptr ss:[ebp-020h]
        mov     edx, dword ptr ss:[ebp-010h]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-01ch]
        mov     ebx, dword ptr ss:[ebp-0ch]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-014h]
        and     ecx, dword ptr ss:[ebp-4]
        and     ebx, dword ptr ss:[ebp-018h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-8]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+03ch]
        lea     eax, dword ptr ds:[ecx+eax+063e81440h]
        mov     dword ptr ss:[ebp-8], eax
        mov     eax, dword ptr ss:[ebp-01ch]
        mov     ecx, dword ptr ss:[ebp-4]
        mov     edx, dword ptr ss:[ebp-014h]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-020h]
        mov     ebx, dword ptr ss:[ebp-010h]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-018h]
        and     ecx, dword ptr ss:[ebp-8]
        and     ebx, dword ptr ss:[ebp-01ch]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-0ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+01ch]
        lea     eax, dword ptr ds:[ecx+eax+055ca396ah]
        mov     dword ptr ss:[ebp-0ch], eax
        mov     eax, dword ptr ss:[ebp-020h]
        mov     ecx, dword ptr ss:[ebp-8]
        mov     edx, dword ptr ss:[ebp-018h]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-4]
        mov     ebx, dword ptr ss:[ebp-014h]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-01ch]
        and     ecx, dword ptr ss:[ebp-0ch]
        and     ebx, dword ptr ss:[ebp-020h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-010h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+0ch]
        lea     eax, dword ptr ds:[ecx+eax+02aab10b6h]
        mov     dword ptr ss:[ebp-010h], eax
        mov     eax, dword ptr ss:[ebp-4]
        mov     ecx, dword ptr ss:[ebp-0ch]
        mov     edx, dword ptr ss:[ebp-01ch]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-8]
        mov     ebx, dword ptr ss:[ebp-018h]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-020h]
        and     ecx, dword ptr ss:[ebp-010h]
        and     ebx, dword ptr ss:[ebp-4]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-014h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+4]
        lea     eax, dword ptr ds:[ecx+eax+0b4cc5c34h]
        mov     dword ptr ss:[ebp-014h], eax
        mov     eax, dword ptr ss:[ebp-8]
        mov     ecx, dword ptr ss:[ebp-010h]
        mov     edx, dword ptr ss:[ebp-020h]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-0ch]
        mov     ebx, dword ptr ss:[ebp-01ch]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-4]
        and     ecx, dword ptr ss:[ebp-014h]
        and     ebx, dword ptr ss:[ebp-8]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-018h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi]
        lea     eax, dword ptr ds:[ecx+eax+01141e8ceh]
        mov     dword ptr ss:[ebp-018h], eax
        mov     eax, dword ptr ss:[ebp-0ch]
        mov     ecx, dword ptr ss:[ebp-014h]
        mov     edx, dword ptr ss:[ebp-4]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-010h]
        mov     ebx, dword ptr ss:[ebp-020h]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-8]
        and     ecx, dword ptr ss:[ebp-018h]
        and     ebx, dword ptr ss:[ebp-0ch]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-01ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+048h]
        lea     eax, dword ptr ds:[ecx+eax+0a15486afh]
        mov     dword ptr ss:[ebp-01ch], eax
        mov     eax, dword ptr ss:[ebp-010h]
        mov     ecx, dword ptr ss:[ebp-018h]
        mov     edx, dword ptr ss:[ebp-8]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-014h]
        mov     ebx, dword ptr ss:[ebp-4]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-0ch]
        and     ecx, dword ptr ss:[ebp-01ch]
        and     ebx, dword ptr ss:[ebp-010h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-020h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+06ch]
        lea     eax, dword ptr ds:[ecx+eax+07c72e993h]
        mov     dword ptr ss:[ebp-020h], eax
        mov     eax, dword ptr ss:[ebp-014h]
        mov     ecx, dword ptr ss:[ebp-01ch]
        mov     edx, dword ptr ss:[ebp-0ch]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-018h]
        mov     ebx, dword ptr ss:[ebp-8]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-010h]
        and     ecx, dword ptr ss:[ebp-020h]
        and     ebx, dword ptr ss:[ebp-014h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-4]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+034h]
        lea     eax, dword ptr ds:[ecx+eax+0b3ee1411h]
        mov     dword ptr ss:[ebp-4], eax
        mov     eax, dword ptr ss:[ebp-018h]
        mov     ecx, dword ptr ss:[ebp-020h]
        mov     edx, dword ptr ss:[ebp-010h]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-01ch]
        mov     ebx, dword ptr ss:[ebp-0ch]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-014h]
        and     ecx, dword ptr ss:[ebp-4]
        and     ebx, dword ptr ss:[ebp-018h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-8]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+018h]
        lea     eax, dword ptr ds:[ecx+eax+0636fbc2ah]
        mov     dword ptr ss:[ebp-8], eax
        mov     eax, dword ptr ss:[ebp-01ch]
        mov     ecx, dword ptr ss:[ebp-4]
        mov     edx, dword ptr ss:[ebp-014h]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-020h]
        mov     ebx, dword ptr ss:[ebp-010h]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-018h]
        and     ecx, dword ptr ss:[ebp-8]
        and     ebx, dword ptr ss:[ebp-01ch]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-0ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+054h]
        lea     eax, dword ptr ds:[ecx+eax+02ba9c55dh]
        mov     dword ptr ss:[ebp-0ch], eax
        mov     eax, dword ptr ss:[ebp-020h]
        mov     ecx, dword ptr ss:[ebp-8]
        mov     edx, dword ptr ss:[ebp-018h]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-4]
        mov     ebx, dword ptr ss:[ebp-014h]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-01ch]
        and     ecx, dword ptr ss:[ebp-0ch]
        and     ebx, dword ptr ss:[ebp-020h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-010h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+028h]
        lea     eax, dword ptr ds:[ecx+eax+0741831f6h]
        mov     dword ptr ss:[ebp-010h], eax
        mov     eax, dword ptr ss:[ebp-4]
        mov     ecx, dword ptr ss:[ebp-0ch]
        mov     edx, dword ptr ss:[ebp-01ch]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-8]
        mov     ebx, dword ptr ss:[ebp-018h]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-020h]
        and     ecx, dword ptr ss:[ebp-010h]
        and     ebx, dword ptr ss:[ebp-4]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-014h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+05ch]
        lea     eax, dword ptr ds:[ecx+eax+0ce5c3e16h]
        mov     dword ptr ss:[ebp-014h], eax
        mov     eax, dword ptr ss:[ebp-8]
        mov     ecx, dword ptr ss:[ebp-010h]
        mov     edx, dword ptr ss:[ebp-020h]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-0ch]
        mov     ebx, dword ptr ss:[ebp-01ch]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-4]
        and     ecx, dword ptr ss:[ebp-014h]
        and     ebx, dword ptr ss:[ebp-8]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-018h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+02ch]
        lea     eax, dword ptr ds:[ecx+eax+09b87931eh]
        mov     dword ptr ss:[ebp-018h], eax
        mov     eax, dword ptr ss:[ebp-0ch]
        mov     ecx, dword ptr ss:[ebp-014h]
        mov     edx, dword ptr ss:[ebp-4]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-010h]
        mov     ebx, dword ptr ss:[ebp-020h]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-8]
        and     ecx, dword ptr ss:[ebp-018h]
        and     ebx, dword ptr ss:[ebp-0ch]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-01ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+014h]
        lea     eax, dword ptr ds:[ecx+eax+0afd6ba33h]
        mov     dword ptr ss:[ebp-01ch], eax
        mov     eax, dword ptr ss:[ebp-010h]
        mov     ecx, dword ptr ss:[ebp-018h]
        mov     edx, dword ptr ss:[ebp-8]
        and     eax, ecx
        xor     eax, dword ptr ss:[ebp-014h]
        mov     ebx, dword ptr ss:[ebp-4]
        xor     eax, edx
        and     eax, dword ptr ss:[ebp-0ch]
        and     ecx, dword ptr ss:[ebp-01ch]
        and     ebx, dword ptr ss:[ebp-010h]
        xor     eax, ecx
        xor     eax, edx
        xor     eax, ebx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-020h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+8]
        lea     eax, dword ptr ds:[ecx+eax+06c24cf5ch]
        mov     dword ptr ss:[ebp-020h], eax
        mov     ecx, dword ptr ss:[ebp-0ch]
        mov     edx, dword ptr ss:[ebp-01ch]
        mov     eax, dword ptr ss:[ebp-020h]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-018h]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-010h]
        xor     eax, dword ptr ss:[ebp-8]
        and     eax, dword ptr ss:[ebp-014h]
        mov     ecx, dword ptr ss:[ebp-020h]
        and     ecx, dword ptr ss:[ebp-010h]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-0ch]
        and     ecx, dword ptr ss:[ebp-018h]
        and     edx, dword ptr ss:[ebp-020h]
        xor     edx, dword ptr ss:[ebp-8]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-4]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+060h]
        lea     eax, dword ptr ds:[ecx+eax+07a325381h]
        mov     dword ptr ss:[ebp-4], eax
        mov     ecx, dword ptr ss:[ebp-010h]
        mov     edx, dword ptr ss:[ebp-020h]
        mov     eax, dword ptr ss:[ebp-4]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-01ch]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-014h]
        xor     eax, dword ptr ss:[ebp-0ch]
        and     eax, dword ptr ss:[ebp-018h]
        mov     ecx, dword ptr ss:[ebp-4]
        and     ecx, dword ptr ss:[ebp-014h]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-010h]
        and     ecx, dword ptr ss:[ebp-01ch]
        and     edx, dword ptr ss:[ebp-4]
        xor     edx, dword ptr ss:[ebp-0ch]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-8]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+010h]
        lea     eax, dword ptr ds:[ecx+eax+028958677h]
        mov     dword ptr ss:[ebp-8], eax
        mov     ecx, dword ptr ss:[ebp-014h]
        mov     edx, dword ptr ss:[ebp-4]
        mov     eax, dword ptr ss:[ebp-8]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-020h]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-018h]
        xor     eax, dword ptr ss:[ebp-010h]
        and     eax, dword ptr ss:[ebp-01ch]
        mov     ecx, dword ptr ss:[ebp-8]
        and     ecx, dword ptr ss:[ebp-018h]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-014h]
        and     ecx, dword ptr ss:[ebp-020h]
        and     edx, dword ptr ss:[ebp-8]
        xor     edx, dword ptr ss:[ebp-010h]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-0ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi]
        lea     eax, dword ptr ds:[ecx+eax+03b8f4898h]
        mov     dword ptr ss:[ebp-0ch], eax
        mov     ecx, dword ptr ss:[ebp-018h]
        mov     edx, dword ptr ss:[ebp-8]
        mov     eax, dword ptr ss:[ebp-0ch]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-4]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-01ch]
        xor     eax, dword ptr ss:[ebp-014h]
        and     eax, dword ptr ss:[ebp-020h]
        mov     ecx, dword ptr ss:[ebp-0ch]
        and     ecx, dword ptr ss:[ebp-01ch]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-018h]
        and     ecx, dword ptr ss:[ebp-4]
        and     edx, dword ptr ss:[ebp-0ch]
        xor     edx, dword ptr ss:[ebp-014h]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-010h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+038h]
        lea     eax, dword ptr ds:[ecx+eax+06b4bb9afh]
        mov     dword ptr ss:[ebp-010h], eax
        mov     ecx, dword ptr ss:[ebp-01ch]
        mov     edx, dword ptr ss:[ebp-0ch]
        mov     eax, dword ptr ss:[ebp-010h]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-8]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-020h]
        xor     eax, dword ptr ss:[ebp-018h]
        and     eax, dword ptr ss:[ebp-4]
        mov     ecx, dword ptr ss:[ebp-010h]
        and     ecx, dword ptr ss:[ebp-020h]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-01ch]
        and     ecx, dword ptr ss:[ebp-8]
        and     edx, dword ptr ss:[ebp-010h]
        xor     edx, dword ptr ss:[ebp-018h]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-014h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+8]
        lea     eax, dword ptr ds:[ecx+eax+0c4bfe81bh]
        mov     dword ptr ss:[ebp-014h], eax
        mov     ecx, dword ptr ss:[ebp-020h]
        mov     edx, dword ptr ss:[ebp-010h]
        mov     eax, dword ptr ss:[ebp-014h]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-0ch]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-4]
        xor     eax, dword ptr ss:[ebp-01ch]
        and     eax, dword ptr ss:[ebp-8]
        mov     ecx, dword ptr ss:[ebp-014h]
        and     ecx, dword ptr ss:[ebp-4]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-020h]
        and     ecx, dword ptr ss:[ebp-0ch]
        and     edx, dword ptr ss:[ebp-014h]
        xor     edx, dword ptr ss:[ebp-01ch]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-018h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+01ch]
        lea     eax, dword ptr ds:[ecx+eax+066282193h]
        mov     dword ptr ss:[ebp-018h], eax
        mov     ecx, dword ptr ss:[ebp-4]
        mov     edx, dword ptr ss:[ebp-014h]
        mov     eax, dword ptr ss:[ebp-018h]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-010h]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-8]
        xor     eax, dword ptr ss:[ebp-020h]
        and     eax, dword ptr ss:[ebp-0ch]
        mov     ecx, dword ptr ss:[ebp-018h]
        and     ecx, dword ptr ss:[ebp-8]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-4]
        and     ecx, dword ptr ss:[ebp-010h]
        and     edx, dword ptr ss:[ebp-018h]
        xor     edx, dword ptr ss:[ebp-020h]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-01ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+070h]
        lea     eax, dword ptr ds:[ecx+eax+061d809cch]
        mov     dword ptr ss:[ebp-01ch], eax
        mov     ecx, dword ptr ss:[ebp-8]
        mov     edx, dword ptr ss:[ebp-018h]
        mov     eax, dword ptr ss:[ebp-01ch]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-014h]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-0ch]
        xor     eax, dword ptr ss:[ebp-4]
        and     eax, dword ptr ss:[ebp-010h]
        mov     ecx, dword ptr ss:[ebp-01ch]
        and     ecx, dword ptr ss:[ebp-0ch]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-8]
        and     ecx, dword ptr ss:[ebp-014h]
        and     edx, dword ptr ss:[ebp-01ch]
        xor     edx, dword ptr ss:[ebp-4]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-020h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+05ch]
        lea     eax, dword ptr ds:[ecx+eax+0fb21a991h]
        mov     dword ptr ss:[ebp-020h], eax
        mov     ecx, dword ptr ss:[ebp-0ch]
        mov     edx, dword ptr ss:[ebp-01ch]
        mov     eax, dword ptr ss:[ebp-020h]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-018h]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-010h]
        xor     eax, dword ptr ss:[ebp-8]
        and     eax, dword ptr ss:[ebp-014h]
        mov     ecx, dword ptr ss:[ebp-020h]
        and     ecx, dword ptr ss:[ebp-010h]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-0ch]
        and     ecx, dword ptr ss:[ebp-018h]
        and     edx, dword ptr ss:[ebp-020h]
        xor     edx, dword ptr ss:[ebp-8]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-4]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+068h]
        lea     eax, dword ptr ds:[ecx+eax+0487cac60h]
        mov     dword ptr ss:[ebp-4], eax
        mov     ecx, dword ptr ss:[ebp-010h]
        mov     edx, dword ptr ss:[ebp-020h]
        mov     eax, dword ptr ss:[ebp-4]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-01ch]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-014h]
        xor     eax, dword ptr ss:[ebp-0ch]
        and     eax, dword ptr ss:[ebp-018h]
        mov     ecx, dword ptr ss:[ebp-4]
        and     ecx, dword ptr ss:[ebp-014h]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-010h]
        and     ecx, dword ptr ss:[ebp-01ch]
        and     edx, dword ptr ss:[ebp-4]
        xor     edx, dword ptr ss:[ebp-0ch]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-8]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+018h]
        lea     eax, dword ptr ds:[ecx+eax+05dec8032h]
        mov     dword ptr ss:[ebp-8], eax
        mov     ecx, dword ptr ss:[ebp-014h]
        mov     edx, dword ptr ss:[ebp-4]
        mov     eax, dword ptr ss:[ebp-8]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-020h]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-018h]
        xor     eax, dword ptr ss:[ebp-010h]
        and     eax, dword ptr ss:[ebp-01ch]
        mov     ecx, dword ptr ss:[ebp-8]
        and     ecx, dword ptr ss:[ebp-018h]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-014h]
        and     ecx, dword ptr ss:[ebp-020h]
        and     edx, dword ptr ss:[ebp-8]
        xor     edx, dword ptr ss:[ebp-010h]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-0ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+078h]
        lea     eax, dword ptr ds:[ecx+eax+0ef845d5dh]
        mov     dword ptr ss:[ebp-0ch], eax
        mov     ecx, dword ptr ss:[ebp-018h]
        mov     edx, dword ptr ss:[ebp-8]
        mov     eax, dword ptr ss:[ebp-0ch]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-4]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-01ch]
        xor     eax, dword ptr ss:[ebp-014h]
        and     eax, dword ptr ss:[ebp-020h]
        mov     ecx, dword ptr ss:[ebp-0ch]
        and     ecx, dword ptr ss:[ebp-01ch]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-018h]
        and     ecx, dword ptr ss:[ebp-4]
        and     edx, dword ptr ss:[ebp-0ch]
        xor     edx, dword ptr ss:[ebp-014h]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-010h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+050h]
        lea     eax, dword ptr ds:[ecx+eax+0e98575b1h]
        mov     dword ptr ss:[ebp-010h], eax
        mov     ecx, dword ptr ss:[ebp-01ch]
        mov     edx, dword ptr ss:[ebp-0ch]
        mov     eax, dword ptr ss:[ebp-010h]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-8]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-020h]
        xor     eax, dword ptr ss:[ebp-018h]
        and     eax, dword ptr ss:[ebp-4]
        mov     ecx, dword ptr ss:[ebp-010h]
        and     ecx, dword ptr ss:[ebp-020h]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-01ch]
        and     ecx, dword ptr ss:[ebp-8]
        and     edx, dword ptr ss:[ebp-010h]
        xor     edx, dword ptr ss:[ebp-018h]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-014h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+048h]
        lea     eax, dword ptr ds:[ecx+eax+0dc262302h]
        mov     dword ptr ss:[ebp-014h], eax
        mov     ecx, dword ptr ss:[ebp-020h]
        mov     edx, dword ptr ss:[ebp-010h]
        mov     eax, dword ptr ss:[ebp-014h]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-0ch]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-4]
        xor     eax, dword ptr ss:[ebp-01ch]
        and     eax, dword ptr ss:[ebp-8]
        mov     ecx, dword ptr ss:[ebp-014h]
        and     ecx, dword ptr ss:[ebp-4]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-020h]
        and     ecx, dword ptr ss:[ebp-0ch]
        and     edx, dword ptr ss:[ebp-014h]
        xor     edx, dword ptr ss:[ebp-01ch]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-018h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+064h]
        lea     eax, dword ptr ds:[ecx+eax+0eb651b88h]
        mov     dword ptr ss:[ebp-018h], eax
        mov     ecx, dword ptr ss:[ebp-4]
        mov     edx, dword ptr ss:[ebp-014h]
        mov     eax, dword ptr ss:[ebp-018h]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-010h]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-8]
        xor     eax, dword ptr ss:[ebp-020h]
        and     eax, dword ptr ss:[ebp-0ch]
        mov     ecx, dword ptr ss:[ebp-018h]
        and     ecx, dword ptr ss:[ebp-8]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-4]
        and     ecx, dword ptr ss:[ebp-010h]
        and     edx, dword ptr ss:[ebp-018h]
        xor     edx, dword ptr ss:[ebp-020h]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-01ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+04ch]
        lea     eax, dword ptr ds:[ecx+eax+023893e81h]
        mov     dword ptr ss:[ebp-01ch], eax
        mov     ecx, dword ptr ss:[ebp-8]
        mov     edx, dword ptr ss:[ebp-018h]
        mov     eax, dword ptr ss:[ebp-01ch]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-014h]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-0ch]
        xor     eax, dword ptr ss:[ebp-4]
        and     eax, dword ptr ss:[ebp-010h]
        mov     ecx, dword ptr ss:[ebp-01ch]
        and     ecx, dword ptr ss:[ebp-0ch]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-8]
        and     ecx, dword ptr ss:[ebp-014h]
        and     edx, dword ptr ss:[ebp-01ch]
        xor     edx, dword ptr ss:[ebp-4]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-020h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+0ch]
        lea     eax, dword ptr ds:[ecx+eax+0d396acc5h]
        mov     dword ptr ss:[ebp-020h], eax
        mov     ecx, dword ptr ss:[ebp-0ch]
        mov     edx, dword ptr ss:[ebp-01ch]
        mov     eax, dword ptr ss:[ebp-020h]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-018h]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-010h]
        xor     eax, dword ptr ss:[ebp-8]
        and     eax, dword ptr ss:[ebp-014h]
        mov     ecx, dword ptr ss:[ebp-020h]
        and     ecx, dword ptr ss:[ebp-010h]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-0ch]
        and     ecx, dword ptr ss:[ebp-018h]
        and     edx, dword ptr ss:[ebp-020h]
        xor     edx, dword ptr ss:[ebp-8]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-4]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+058h]
        lea     eax, dword ptr ds:[ecx+eax+0f6d6ff3h]
        mov     dword ptr ss:[ebp-4], eax
        mov     ecx, dword ptr ss:[ebp-010h]
        mov     edx, dword ptr ss:[ebp-020h]
        mov     eax, dword ptr ss:[ebp-4]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-01ch]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-014h]
        xor     eax, dword ptr ss:[ebp-0ch]
        and     eax, dword ptr ss:[ebp-018h]
        mov     ecx, dword ptr ss:[ebp-4]
        and     ecx, dword ptr ss:[ebp-014h]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-010h]
        and     ecx, dword ptr ss:[ebp-01ch]
        and     edx, dword ptr ss:[ebp-4]
        xor     edx, dword ptr ss:[ebp-0ch]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-8]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+02ch]
        lea     eax, dword ptr ds:[ecx+eax+083f44239h]
        mov     dword ptr ss:[ebp-8], eax
        mov     ecx, dword ptr ss:[ebp-014h]
        mov     edx, dword ptr ss:[ebp-4]
        mov     eax, dword ptr ss:[ebp-8]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-020h]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-018h]
        xor     eax, dword ptr ss:[ebp-010h]
        and     eax, dword ptr ss:[ebp-01ch]
        mov     ecx, dword ptr ss:[ebp-8]
        and     ecx, dword ptr ss:[ebp-018h]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-014h]
        and     ecx, dword ptr ss:[ebp-020h]
        and     edx, dword ptr ss:[ebp-8]
        xor     edx, dword ptr ss:[ebp-010h]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-0ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+07ch]
        lea     eax, dword ptr ds:[ecx+eax+02e0b4482h]
        mov     dword ptr ss:[ebp-0ch], eax
        mov     ecx, dword ptr ss:[ebp-018h]
        mov     edx, dword ptr ss:[ebp-8]
        mov     eax, dword ptr ss:[ebp-0ch]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-4]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-01ch]
        xor     eax, dword ptr ss:[ebp-014h]
        and     eax, dword ptr ss:[ebp-020h]
        mov     ecx, dword ptr ss:[ebp-0ch]
        and     ecx, dword ptr ss:[ebp-01ch]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-018h]
        and     ecx, dword ptr ss:[ebp-4]
        and     edx, dword ptr ss:[ebp-0ch]
        xor     edx, dword ptr ss:[ebp-014h]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-010h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+054h]
        lea     eax, dword ptr ds:[ecx+eax+0a4842004h]
        mov     dword ptr ss:[ebp-010h], eax
        mov     ecx, dword ptr ss:[ebp-01ch]
        mov     edx, dword ptr ss:[ebp-0ch]
        mov     eax, dword ptr ss:[ebp-010h]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-8]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-020h]
        xor     eax, dword ptr ss:[ebp-018h]
        and     eax, dword ptr ss:[ebp-4]
        mov     ecx, dword ptr ss:[ebp-010h]
        and     ecx, dword ptr ss:[ebp-020h]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-01ch]
        and     ecx, dword ptr ss:[ebp-8]
        and     edx, dword ptr ss:[ebp-010h]
        xor     edx, dword ptr ss:[ebp-018h]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-014h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+020h]
        lea     eax, dword ptr ds:[ecx+eax+069c8f04ah]
        mov     dword ptr ss:[ebp-014h], eax
        mov     ecx, dword ptr ss:[ebp-020h]
        mov     edx, dword ptr ss:[ebp-010h]
        mov     eax, dword ptr ss:[ebp-014h]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-0ch]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-4]
        xor     eax, dword ptr ss:[ebp-01ch]
        and     eax, dword ptr ss:[ebp-8]
        mov     ecx, dword ptr ss:[ebp-014h]
        and     ecx, dword ptr ss:[ebp-4]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-020h]
        and     ecx, dword ptr ss:[ebp-0ch]
        and     edx, dword ptr ss:[ebp-014h]
        xor     edx, dword ptr ss:[ebp-01ch]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-018h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+06ch]
        lea     eax, dword ptr ds:[ecx+eax+09e1f9b5eh]
        mov     dword ptr ss:[ebp-018h], eax
        mov     ecx, dword ptr ss:[ebp-4]
        mov     edx, dword ptr ss:[ebp-014h]
        mov     eax, dword ptr ss:[ebp-018h]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-010h]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-8]
        xor     eax, dword ptr ss:[ebp-020h]
        and     eax, dword ptr ss:[ebp-0ch]
        mov     ecx, dword ptr ss:[ebp-018h]
        and     ecx, dword ptr ss:[ebp-8]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-4]
        and     ecx, dword ptr ss:[ebp-010h]
        and     edx, dword ptr ss:[ebp-018h]
        xor     edx, dword ptr ss:[ebp-020h]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-01ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+030h]
        lea     eax, dword ptr ds:[ecx+eax+021c66842h]
        mov     dword ptr ss:[ebp-01ch], eax
        mov     ecx, dword ptr ss:[ebp-8]
        mov     edx, dword ptr ss:[ebp-018h]
        mov     eax, dword ptr ss:[ebp-01ch]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-014h]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-0ch]
        xor     eax, dword ptr ss:[ebp-4]
        and     eax, dword ptr ss:[ebp-010h]
        mov     ecx, dword ptr ss:[ebp-01ch]
        and     ecx, dword ptr ss:[ebp-0ch]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-8]
        and     ecx, dword ptr ss:[ebp-014h]
        and     edx, dword ptr ss:[ebp-01ch]
        xor     edx, dword ptr ss:[ebp-4]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-020h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+024h]
        lea     eax, dword ptr ds:[ecx+eax+0f6e96c9ah]
        mov     dword ptr ss:[ebp-020h], eax
        mov     ecx, dword ptr ss:[ebp-0ch]
        mov     edx, dword ptr ss:[ebp-01ch]
        mov     eax, dword ptr ss:[ebp-020h]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-018h]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-010h]
        xor     eax, dword ptr ss:[ebp-8]
        and     eax, dword ptr ss:[ebp-014h]
        mov     ecx, dword ptr ss:[ebp-020h]
        and     ecx, dword ptr ss:[ebp-010h]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-0ch]
        and     ecx, dword ptr ss:[ebp-018h]
        and     edx, dword ptr ss:[ebp-020h]
        xor     edx, dword ptr ss:[ebp-8]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-4]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+4]
        lea     eax, dword ptr ds:[ecx+eax+0670c9c61h]
        mov     dword ptr ss:[ebp-4], eax
        mov     ecx, dword ptr ss:[ebp-010h]
        mov     edx, dword ptr ss:[ebp-020h]
        mov     eax, dword ptr ss:[ebp-4]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-01ch]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-014h]
        xor     eax, dword ptr ss:[ebp-0ch]
        and     eax, dword ptr ss:[ebp-018h]
        mov     ecx, dword ptr ss:[ebp-4]
        and     ecx, dword ptr ss:[ebp-014h]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-010h]
        and     ecx, dword ptr ss:[ebp-01ch]
        and     edx, dword ptr ss:[ebp-4]
        xor     edx, dword ptr ss:[ebp-0ch]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-8]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+074h]
        lea     eax, dword ptr ds:[ecx+eax+0abd388f0h]
        mov     dword ptr ss:[ebp-8], eax
        mov     ecx, dword ptr ss:[ebp-014h]
        mov     edx, dword ptr ss:[ebp-4]
        mov     eax, dword ptr ss:[ebp-8]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-020h]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-018h]
        xor     eax, dword ptr ss:[ebp-010h]
        and     eax, dword ptr ss:[ebp-01ch]
        mov     ecx, dword ptr ss:[ebp-8]
        and     ecx, dword ptr ss:[ebp-018h]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-014h]
        and     ecx, dword ptr ss:[ebp-020h]
        and     edx, dword ptr ss:[ebp-8]
        xor     edx, dword ptr ss:[ebp-010h]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-0ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+014h]
        lea     eax, dword ptr ds:[ecx+eax+06a51a0d2h]
        mov     dword ptr ss:[ebp-0ch], eax
        mov     ecx, dword ptr ss:[ebp-018h]
        mov     edx, dword ptr ss:[ebp-8]
        mov     eax, dword ptr ss:[ebp-0ch]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-4]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-01ch]
        xor     eax, dword ptr ss:[ebp-014h]
        and     eax, dword ptr ss:[ebp-020h]
        mov     ecx, dword ptr ss:[ebp-0ch]
        and     ecx, dword ptr ss:[ebp-01ch]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-018h]
        and     ecx, dword ptr ss:[ebp-4]
        and     edx, dword ptr ss:[ebp-0ch]
        xor     edx, dword ptr ss:[ebp-014h]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-010h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+03ch]
        lea     eax, dword ptr ds:[ecx+eax+0d8542f68h]
        mov     dword ptr ss:[ebp-010h], eax
        mov     ecx, dword ptr ss:[ebp-01ch]
        mov     edx, dword ptr ss:[ebp-0ch]
        mov     eax, dword ptr ss:[ebp-010h]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-8]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-020h]
        xor     eax, dword ptr ss:[ebp-018h]
        and     eax, dword ptr ss:[ebp-4]
        mov     ecx, dword ptr ss:[ebp-010h]
        and     ecx, dword ptr ss:[ebp-020h]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-01ch]
        and     ecx, dword ptr ss:[ebp-8]
        and     edx, dword ptr ss:[ebp-010h]
        xor     edx, dword ptr ss:[ebp-018h]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-014h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+044h]
        lea     eax, dword ptr ds:[ecx+eax+0960fa728h]
        mov     dword ptr ss:[ebp-014h], eax
        mov     ecx, dword ptr ss:[ebp-020h]
        mov     edx, dword ptr ss:[ebp-010h]
        mov     eax, dword ptr ss:[ebp-014h]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-0ch]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-4]
        xor     eax, dword ptr ss:[ebp-01ch]
        and     eax, dword ptr ss:[ebp-8]
        mov     ecx, dword ptr ss:[ebp-014h]
        and     ecx, dword ptr ss:[ebp-4]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-020h]
        and     ecx, dword ptr ss:[ebp-0ch]
        and     edx, dword ptr ss:[ebp-014h]
        xor     edx, dword ptr ss:[ebp-01ch]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-018h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+028h]
        lea     eax, dword ptr ds:[ecx+eax+0ab5133a3h]
        mov     dword ptr ss:[ebp-018h], eax
        mov     ecx, dword ptr ss:[ebp-4]
        mov     edx, dword ptr ss:[ebp-014h]
        mov     eax, dword ptr ss:[ebp-018h]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-010h]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-8]
        xor     eax, dword ptr ss:[ebp-020h]
        and     eax, dword ptr ss:[ebp-0ch]
        mov     ecx, dword ptr ss:[ebp-018h]
        and     ecx, dword ptr ss:[ebp-8]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-4]
        and     ecx, dword ptr ss:[ebp-010h]
        and     edx, dword ptr ss:[ebp-018h]
        xor     edx, dword ptr ss:[ebp-020h]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-01ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+040h]
        lea     eax, dword ptr ds:[ecx+eax+06eef0b6ch]
        mov     dword ptr ss:[ebp-01ch], eax
        mov     ecx, dword ptr ss:[ebp-8]
        mov     edx, dword ptr ss:[ebp-018h]
        mov     eax, dword ptr ss:[ebp-01ch]
        mov     ebx, edx
        xor     ebx, 0ffffffffh
        and     ebx, dword ptr ss:[ebp-014h]
        xor     eax, 0ffffffffh
        and     eax, ecx
        xor     eax, ebx
        xor     eax, edx
        xor     eax, dword ptr ss:[ebp-0ch]
        xor     eax, dword ptr ss:[ebp-4]
        and     eax, dword ptr ss:[ebp-010h]
        mov     ecx, dword ptr ss:[ebp-01ch]
        and     ecx, dword ptr ss:[ebp-0ch]
        xor     ecx, edx
        xor     ecx, dword ptr ss:[ebp-8]
        and     ecx, dword ptr ss:[ebp-014h]
        and     edx, dword ptr ss:[ebp-01ch]
        xor     edx, dword ptr ss:[ebp-4]
        xor     eax, ecx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-020h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+034h]
        lea     eax, dword ptr ds:[ecx+eax+0137a3be4h]
        mov     dword ptr ss:[ebp-020h], eax
        mov     eax, dword ptr ss:[ebp-014h]
        mov     ecx, dword ptr ss:[ebp-010h]
        mov     edx, dword ptr ss:[ebp-8]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-0ch]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-01ch]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-014h]
        mov     edx, dword ptr ss:[ebp-8]
        and     ebx, dword ptr ss:[ebp-020h]
        and     edx, dword ptr ss:[ebp-018h]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-4]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+06ch]
        lea     eax, dword ptr ds:[ecx+eax+0ba3bf050h]
        mov     dword ptr ss:[ebp-4], eax
        mov     eax, dword ptr ss:[ebp-018h]
        mov     ecx, dword ptr ss:[ebp-014h]
        mov     edx, dword ptr ss:[ebp-0ch]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-010h]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-020h]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-018h]
        mov     edx, dword ptr ss:[ebp-0ch]
        and     ebx, dword ptr ss:[ebp-4]
        and     edx, dword ptr ss:[ebp-01ch]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-8]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+0ch]
        lea     eax, dword ptr ds:[ecx+eax+07efb2a98h]
        mov     dword ptr ss:[ebp-8], eax
        mov     eax, dword ptr ss:[ebp-01ch]
        mov     ecx, dword ptr ss:[ebp-018h]
        mov     edx, dword ptr ss:[ebp-010h]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-014h]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-4]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-01ch]
        mov     edx, dword ptr ss:[ebp-010h]
        and     ebx, dword ptr ss:[ebp-8]
        and     edx, dword ptr ss:[ebp-020h]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-0ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+054h]
        lea     eax, dword ptr ds:[ecx+eax+0a1f1651dh]
        mov     dword ptr ss:[ebp-0ch], eax
        mov     eax, dword ptr ss:[ebp-020h]
        mov     ecx, dword ptr ss:[ebp-01ch]
        mov     edx, dword ptr ss:[ebp-014h]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-018h]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-8]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-020h]
        mov     edx, dword ptr ss:[ebp-014h]
        and     ebx, dword ptr ss:[ebp-0ch]
        and     edx, dword ptr ss:[ebp-4]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-010h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+068h]
        lea     eax, dword ptr ds:[ecx+eax+039af0176h]
        mov     dword ptr ss:[ebp-010h], eax
        mov     eax, dword ptr ss:[ebp-4]
        mov     ecx, dword ptr ss:[ebp-020h]
        mov     edx, dword ptr ss:[ebp-018h]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-01ch]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-0ch]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-4]
        mov     edx, dword ptr ss:[ebp-018h]
        and     ebx, dword ptr ss:[ebp-010h]
        and     edx, dword ptr ss:[ebp-8]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-014h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+044h]
        lea     eax, dword ptr ds:[ecx+eax+066ca593eh]
        mov     dword ptr ss:[ebp-014h], eax
        mov     eax, dword ptr ss:[ebp-8]
        mov     ecx, dword ptr ss:[ebp-4]
        mov     edx, dword ptr ss:[ebp-01ch]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-020h]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-010h]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-8]
        mov     edx, dword ptr ss:[ebp-01ch]
        and     ebx, dword ptr ss:[ebp-014h]
        and     edx, dword ptr ss:[ebp-0ch]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-018h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+02ch]
        lea     eax, dword ptr ds:[ecx+eax+082430e88h]
        mov     dword ptr ss:[ebp-018h], eax
        mov     eax, dword ptr ss:[ebp-0ch]
        mov     ecx, dword ptr ss:[ebp-8]
        mov     edx, dword ptr ss:[ebp-020h]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-4]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-014h]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-0ch]
        mov     edx, dword ptr ss:[ebp-020h]
        and     ebx, dword ptr ss:[ebp-018h]
        and     edx, dword ptr ss:[ebp-010h]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-01ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+050h]
        lea     eax, dword ptr ds:[ecx+eax+08cee8619h]
        mov     dword ptr ss:[ebp-01ch], eax
        mov     eax, dword ptr ss:[ebp-010h]
        mov     ecx, dword ptr ss:[ebp-0ch]
        mov     edx, dword ptr ss:[ebp-4]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-8]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-018h]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-010h]
        mov     edx, dword ptr ss:[ebp-4]
        and     ebx, dword ptr ss:[ebp-01ch]
        and     edx, dword ptr ss:[ebp-014h]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-020h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+074h]
        lea     eax, dword ptr ds:[ecx+eax+0456f9fb4h]
        mov     dword ptr ss:[ebp-020h], eax
        mov     eax, dword ptr ss:[ebp-014h]
        mov     ecx, dword ptr ss:[ebp-010h]
        mov     edx, dword ptr ss:[ebp-8]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-0ch]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-01ch]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-014h]
        mov     edx, dword ptr ss:[ebp-8]
        and     ebx, dword ptr ss:[ebp-020h]
        and     edx, dword ptr ss:[ebp-018h]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-4]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+04ch]
        lea     eax, dword ptr ds:[ecx+eax+07d84a5c3h]
        mov     dword ptr ss:[ebp-4], eax
        mov     eax, dword ptr ss:[ebp-018h]
        mov     ecx, dword ptr ss:[ebp-014h]
        mov     edx, dword ptr ss:[ebp-0ch]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-010h]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-020h]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-018h]
        mov     edx, dword ptr ss:[ebp-0ch]
        and     ebx, dword ptr ss:[ebp-4]
        and     edx, dword ptr ss:[ebp-01ch]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-8]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi]
        lea     eax, dword ptr ds:[ecx+eax+03b8b5ebeh]
        mov     dword ptr ss:[ebp-8], eax
        mov     eax, dword ptr ss:[ebp-01ch]
        mov     ecx, dword ptr ss:[ebp-018h]
        mov     edx, dword ptr ss:[ebp-010h]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-014h]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-4]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-01ch]
        mov     edx, dword ptr ss:[ebp-010h]
        and     ebx, dword ptr ss:[ebp-8]
        and     edx, dword ptr ss:[ebp-020h]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-0ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+030h]
        lea     eax, dword ptr ds:[ecx+eax+0e06f75d8h]
        mov     dword ptr ss:[ebp-0ch], eax
        mov     eax, dword ptr ss:[ebp-020h]
        mov     ecx, dword ptr ss:[ebp-01ch]
        mov     edx, dword ptr ss:[ebp-014h]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-018h]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-8]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-020h]
        mov     edx, dword ptr ss:[ebp-014h]
        and     ebx, dword ptr ss:[ebp-0ch]
        and     edx, dword ptr ss:[ebp-4]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-010h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+01ch]
        lea     eax, dword ptr ds:[ecx+eax+085c12073h]
        mov     dword ptr ss:[ebp-010h], eax
        mov     eax, dword ptr ss:[ebp-4]
        mov     ecx, dword ptr ss:[ebp-020h]
        mov     edx, dword ptr ss:[ebp-018h]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-01ch]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-0ch]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-4]
        mov     edx, dword ptr ss:[ebp-018h]
        and     ebx, dword ptr ss:[ebp-010h]
        and     edx, dword ptr ss:[ebp-8]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-014h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+034h]
        lea     eax, dword ptr ds:[ecx+eax+0401a449fh]
        mov     dword ptr ss:[ebp-014h], eax
        mov     eax, dword ptr ss:[ebp-8]
        mov     ecx, dword ptr ss:[ebp-4]
        mov     edx, dword ptr ss:[ebp-01ch]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-020h]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-010h]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-8]
        mov     edx, dword ptr ss:[ebp-01ch]
        and     ebx, dword ptr ss:[ebp-014h]
        and     edx, dword ptr ss:[ebp-0ch]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-018h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+020h]
        lea     eax, dword ptr ds:[ecx+eax+056c16aa6h]
        mov     dword ptr ss:[ebp-018h], eax
        mov     eax, dword ptr ss:[ebp-0ch]
        mov     ecx, dword ptr ss:[ebp-8]
        mov     edx, dword ptr ss:[ebp-020h]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-4]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-014h]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-0ch]
        mov     edx, dword ptr ss:[ebp-020h]
        and     ebx, dword ptr ss:[ebp-018h]
        and     edx, dword ptr ss:[ebp-010h]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-01ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+07ch]
        lea     eax, dword ptr ds:[ecx+eax+04ed3aa62h]
        mov     dword ptr ss:[ebp-01ch], eax
        mov     eax, dword ptr ss:[ebp-010h]
        mov     ecx, dword ptr ss:[ebp-0ch]
        mov     edx, dword ptr ss:[ebp-4]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-8]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-018h]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-010h]
        mov     edx, dword ptr ss:[ebp-4]
        and     ebx, dword ptr ss:[ebp-01ch]
        and     edx, dword ptr ss:[ebp-014h]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-020h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+028h]
        lea     eax, dword ptr ds:[ecx+eax+0363f7706h]
        mov     dword ptr ss:[ebp-020h], eax
        mov     eax, dword ptr ss:[ebp-014h]
        mov     ecx, dword ptr ss:[ebp-010h]
        mov     edx, dword ptr ss:[ebp-8]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-0ch]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-01ch]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-014h]
        mov     edx, dword ptr ss:[ebp-8]
        and     ebx, dword ptr ss:[ebp-020h]
        and     edx, dword ptr ss:[ebp-018h]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-4]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+014h]
        lea     eax, dword ptr ds:[ecx+eax+01bfedf72h]
        mov     dword ptr ss:[ebp-4], eax
        mov     eax, dword ptr ss:[ebp-018h]
        mov     ecx, dword ptr ss:[ebp-014h]
        mov     edx, dword ptr ss:[ebp-0ch]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-010h]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-020h]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-018h]
        mov     edx, dword ptr ss:[ebp-0ch]
        and     ebx, dword ptr ss:[ebp-4]
        and     edx, dword ptr ss:[ebp-01ch]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-8]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+024h]
        lea     eax, dword ptr ds:[ecx+eax+0429b023dh]
        mov     dword ptr ss:[ebp-8], eax
        mov     eax, dword ptr ss:[ebp-01ch]
        mov     ecx, dword ptr ss:[ebp-018h]
        mov     edx, dword ptr ss:[ebp-010h]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-014h]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-4]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-01ch]
        mov     edx, dword ptr ss:[ebp-010h]
        and     ebx, dword ptr ss:[ebp-8]
        and     edx, dword ptr ss:[ebp-020h]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-0ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+038h]
        lea     eax, dword ptr ds:[ecx+eax+037d0d724h]
        mov     dword ptr ss:[ebp-0ch], eax
        mov     eax, dword ptr ss:[ebp-020h]
        mov     ecx, dword ptr ss:[ebp-01ch]
        mov     edx, dword ptr ss:[ebp-014h]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-018h]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-8]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-020h]
        mov     edx, dword ptr ss:[ebp-014h]
        and     ebx, dword ptr ss:[ebp-0ch]
        and     edx, dword ptr ss:[ebp-4]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-010h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+078h]
        lea     eax, dword ptr ds:[ecx+eax+0d00a1248h]
        mov     dword ptr ss:[ebp-010h], eax
        mov     eax, dword ptr ss:[ebp-4]
        mov     ecx, dword ptr ss:[ebp-020h]
        mov     edx, dword ptr ss:[ebp-018h]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-01ch]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-0ch]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-4]
        mov     edx, dword ptr ss:[ebp-018h]
        and     ebx, dword ptr ss:[ebp-010h]
        and     edx, dword ptr ss:[ebp-8]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-014h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+048h]
        lea     eax, dword ptr ds:[ecx+eax+0db0fead3h]
        mov     dword ptr ss:[ebp-014h], eax
        mov     eax, dword ptr ss:[ebp-8]
        mov     ecx, dword ptr ss:[ebp-4]
        mov     edx, dword ptr ss:[ebp-01ch]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-020h]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-010h]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-8]
        mov     edx, dword ptr ss:[ebp-01ch]
        and     ebx, dword ptr ss:[ebp-014h]
        and     edx, dword ptr ss:[ebp-0ch]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-018h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+018h]
        lea     eax, dword ptr ds:[ecx+eax+049f1c09bh]
        mov     dword ptr ss:[ebp-018h], eax
        mov     eax, dword ptr ss:[ebp-0ch]
        mov     ecx, dword ptr ss:[ebp-8]
        mov     edx, dword ptr ss:[ebp-020h]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-4]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-014h]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-0ch]
        mov     edx, dword ptr ss:[ebp-020h]
        and     ebx, dword ptr ss:[ebp-018h]
        and     edx, dword ptr ss:[ebp-010h]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-01ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+070h]
        lea     eax, dword ptr ds:[ecx+eax+075372c9h]
        mov     dword ptr ss:[ebp-01ch], eax
        mov     eax, dword ptr ss:[ebp-010h]
        mov     ecx, dword ptr ss:[ebp-0ch]
        mov     edx, dword ptr ss:[ebp-4]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-8]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-018h]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-010h]
        mov     edx, dword ptr ss:[ebp-4]
        and     ebx, dword ptr ss:[ebp-01ch]
        and     edx, dword ptr ss:[ebp-014h]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-020h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+060h]
        lea     eax, dword ptr ds:[ecx+eax+080991b7bh]
        mov     dword ptr ss:[ebp-020h], eax
        mov     eax, dword ptr ss:[ebp-014h]
        mov     ecx, dword ptr ss:[ebp-010h]
        mov     edx, dword ptr ss:[ebp-8]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-0ch]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-01ch]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-014h]
        mov     edx, dword ptr ss:[ebp-8]
        and     ebx, dword ptr ss:[ebp-020h]
        and     edx, dword ptr ss:[ebp-018h]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-4]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+8]
        lea     eax, dword ptr ds:[ecx+eax+025d479d8h]
        mov     dword ptr ss:[ebp-4], eax
        mov     eax, dword ptr ss:[ebp-018h]
        mov     ecx, dword ptr ss:[ebp-014h]
        mov     edx, dword ptr ss:[ebp-0ch]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-010h]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-020h]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-018h]
        mov     edx, dword ptr ss:[ebp-0ch]
        and     ebx, dword ptr ss:[ebp-4]
        and     edx, dword ptr ss:[ebp-01ch]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-8]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+05ch]
        lea     eax, dword ptr ds:[ecx+eax+0f6e8def7h]
        mov     dword ptr ss:[ebp-8], eax
        mov     eax, dword ptr ss:[ebp-01ch]
        mov     ecx, dword ptr ss:[ebp-018h]
        mov     edx, dword ptr ss:[ebp-010h]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-014h]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-4]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-01ch]
        mov     edx, dword ptr ss:[ebp-010h]
        and     ebx, dword ptr ss:[ebp-8]
        and     edx, dword ptr ss:[ebp-020h]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-0ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+040h]
        lea     eax, dword ptr ds:[ecx+eax+0e3fe501ah]
        mov     dword ptr ss:[ebp-0ch], eax
        mov     eax, dword ptr ss:[ebp-020h]
        mov     ecx, dword ptr ss:[ebp-01ch]
        mov     edx, dword ptr ss:[ebp-014h]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-018h]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-8]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-020h]
        mov     edx, dword ptr ss:[ebp-014h]
        and     ebx, dword ptr ss:[ebp-0ch]
        and     edx, dword ptr ss:[ebp-4]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-010h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+058h]
        lea     eax, dword ptr ds:[ecx+eax+0b6794c3bh]
        mov     dword ptr ss:[ebp-010h], eax
        mov     eax, dword ptr ss:[ebp-4]
        mov     ecx, dword ptr ss:[ebp-020h]
        mov     edx, dword ptr ss:[ebp-018h]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-01ch]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-0ch]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-4]
        mov     edx, dword ptr ss:[ebp-018h]
        and     ebx, dword ptr ss:[ebp-010h]
        and     edx, dword ptr ss:[ebp-8]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-014h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+010h]
        lea     eax, dword ptr ds:[ecx+eax+0976ce0bdh]
        mov     dword ptr ss:[ebp-014h], eax
        mov     eax, dword ptr ss:[ebp-8]
        mov     ecx, dword ptr ss:[ebp-4]
        mov     edx, dword ptr ss:[ebp-01ch]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-020h]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-010h]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-8]
        mov     edx, dword ptr ss:[ebp-01ch]
        and     ebx, dword ptr ss:[ebp-014h]
        and     edx, dword ptr ss:[ebp-0ch]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-018h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+4]
        lea     eax, dword ptr ds:[ecx+eax+04c006bah]
        mov     dword ptr ss:[ebp-018h], eax
        mov     eax, dword ptr ss:[ebp-0ch]
        mov     ecx, dword ptr ss:[ebp-8]
        mov     edx, dword ptr ss:[ebp-020h]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-4]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-014h]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-0ch]
        mov     edx, dword ptr ss:[ebp-020h]
        and     ebx, dword ptr ss:[ebp-018h]
        and     edx, dword ptr ss:[ebp-010h]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-01ch]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+064h]
        lea     eax, dword ptr ds:[ecx+eax+0c1a94fb6h]
        mov     dword ptr ss:[ebp-01ch], eax
        mov     eax, dword ptr ss:[ebp-010h]
        mov     ecx, dword ptr ss:[ebp-0ch]
        mov     edx, dword ptr ss:[ebp-4]
        and     eax, ecx
        mov     ebx, dword ptr ss:[ebp-8]
        and     eax, edx
        xor     eax, 0ffffffffh
        xor     eax, ebx
        and     eax, dword ptr ss:[ebp-018h]
        and     ecx, ebx
        xor     eax, ecx
        mov     ebx, dword ptr ss:[ebp-010h]
        mov     edx, dword ptr ss:[ebp-4]
        and     ebx, dword ptr ss:[ebp-01ch]
        and     edx, dword ptr ss:[ebp-014h]
        xor     eax, ebx
        xor     eax, edx
        ror     eax, 7
        mov     ecx, dword ptr ss:[ebp-020h]
        ror     ecx, 0bh
        add     eax, dword ptr ds:[edi+03ch]
        lea     eax, dword ptr ds:[ecx+eax+0409f60c4h]
        mov     dword ptr ss:[ebp-020h], eax
        mov     eax, dword ptr ss:[ebp-020h]
        mov     ebx, dword ptr ss:[ebp-01ch]
        mov     ecx, dword ptr ss:[ebp-018h]
        mov     edx, dword ptr ss:[ebp-014h]
        add     dword ptr ds:[esi], eax
        add     dword ptr ds:[esi+4], ebx
        add     dword ptr ds:[esi+8], ecx
        add     dword ptr ds:[esi+0ch], edx
        mov     eax, dword ptr ss:[ebp-010h]
        mov     ebx, dword ptr ss:[ebp-0ch]
        mov     ecx, dword ptr ss:[ebp-8]
        mov     edx, dword ptr ss:[ebp-4]
        add     dword ptr ds:[esi+010h], eax
        add     dword ptr ds:[esi+014h], ebx
        add     dword ptr ds:[esi+018h], ecx
        add     dword ptr ds:[esi+01ch], edx
        popad
        leave
		pop edi
		pop esi
		pop ebx
        retn

}

	     
}

void HavalHash(char *p)
{
	BYTE HavalHasher[136]={0};
	int len = strlen(p);
	memcpy(HavalHasher,p,len);
	HavalHasher[len]=1;
	HavalHasher[132]=len;
	HavalHasher[128]=len;
	HavalHasher[118]=0x49;
	HavalHasher[119]=0x20;
	__asm
	{
		mov eax, len
		xor edx, edx
		shld edx, eax, 3
		shl eax, 3
		mov byte ptr ds:[HavalHasher + 120],al
	}
  
	HavalInit();
	__asm
	{
		lea		eax, HavalHasher
		call	HavalTransform
		lea		esi, havalints
		mov		ecx, len
		mov     eax, dword ptr ds:[esi+01Ch]
        mov     ebx, dword ptr ds:[esi+018h]
        mov     ecx, dword ptr ds:[esi+014h]
        mov     edx, dword ptr ds:[esi+010h]
        and     eax, 0FFh
        and     ebx, 0FF000000h
        and     ecx, 0FF0000h
        and     edx, 0FF00h
        or      eax, ebx
        or      eax, ecx
        or      eax, edx
        ror     eax, 8
        add     eax, dword ptr ds:[esi]
        mov     dword ptr ds:[esi], eax
        mov     eax, dword ptr ds:[esi+01Ch]
        mov     ebx, dword ptr ds:[esi+018h]
        mov     ecx, dword ptr ds:[esi+014h]
        mov     edx, dword ptr ds:[esi+010h]
        and     eax, 0FF00h
        and     ebx, 0FFh
        and     ecx, 0FF000000h
        and     edx, 0FF0000h
        or      eax, ebx
        or      eax, ecx
        or      eax, edx
        ror     eax, 010h
        add     eax, dword ptr ds:[esi+4]
        mov     dword ptr ds:[esi+4], eax
        mov     eax, dword ptr ds:[esi+01Ch]
        mov     ebx, dword ptr ds:[esi+018h]
        mov     ecx, dword ptr ds:[esi+014h]
        mov     edx, dword ptr ds:[esi+010h]
        and     eax, 0FF0000h
        and     ebx, 0FF00h
        and     ecx, 0FFh
        and     edx, 0FF000000h
        or      eax, ebx
        or      eax, ecx
        or      eax, edx
        ror     eax, 018h
        add     eax, dword ptr ds:[esi+8]
        mov     dword ptr ds:[esi+8], eax
        mov     eax, dword ptr ds:[esi+01Ch]
        mov     ebx, dword ptr ds:[esi+018h]
        mov     ecx, dword ptr ds:[esi+014h]
        mov     edx, dword ptr ds:[esi+010h]
        and     eax, 0FF000000h
        and     ebx, 0FF0000h
        and     ecx, 0FF00h
        and     edx, 0FFh
        or      eax, ebx
        or      eax, ecx
        or      eax, edx
        add     eax, dword ptr ds:[esi+0Ch]
        mov     dword ptr ds:[esi+0Ch], eax
	}
}
void Generate(HWND hWnd)
{
	char TigerPfx[]="%08X", MagicHash[100], name[50], magic[100], serial[1000];
	__int64 tiger_ctx[6];
	
	big h1, h2, m, d, n;

	h1 = mirvar(0);
	h2 = mirvar(0);
	m = mirvar(0);
	d = mirvar(0);
	n = mirvar(0);

	mip->IOBASE = 16;
	cinstr(d,"FEF87F6625796D9AF89600AD680720B91B2931974B49E1806B9D7F50AE10CC9F46F4F64FB7EE7");
	cinstr(n,"1CE1D8E67A633C882BDD8921B3BF266AAE4E24964DA6B6DB8D7FC7B5F0DA90A036BC91C62E15199");

	
	GetDlgItemText(hWnd,IDC_T1,name,50);
	GetDlgItemText(hWnd,IDC_T2,magic,50);

	tiger((unsigned char*)magic, strlen(magic), tiger_ctx);
	wsprintf(MagicHash, TigerPfx, bswap(tiger_ctx[0]));
	wsprintf(MagicHash + 8, TigerPfx, bswap(tiger_ctx[0] >> 32));
	wsprintf(MagicHash + 16, TigerPfx, bswap(tiger_ctx[1]));
	wsprintf(MagicHash + 24, TigerPfx, bswap(tiger_ctx[1] >> 32));

	cinstr(h1,MagicHash);

	HavalHash(name);
	wsprintf(MagicHash, TigerPfx, bswap(havalints[0]));
	wsprintf(MagicHash + 8, TigerPfx, bswap(havalints[1]));
	wsprintf(MagicHash + 16, TigerPfx, bswap(havalints[2]));
	wsprintf(MagicHash + 24, TigerPfx, bswap(havalints[3]));
	cinstr(h2,MagicHash);

	add(h1,h2,h1);
	powmod(h1,d,n,m);
	cotstr(m,serial);

	SetDlgItemText(hWnd,IDC_T3,serial);

	
	mirkill(h1);
	mirkill(h2);
	mirkill(m);
	mirkill(d);
	mirkill(n);
	
	
}

