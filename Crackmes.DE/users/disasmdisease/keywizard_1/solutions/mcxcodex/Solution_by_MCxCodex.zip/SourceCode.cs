using System;
using System.Text;
using System.Windows.Forms;

namespace DisasmDiseaseKW1
{
  public partial class DisasmDiseaseKW1 : Form
  {
    public DisasmDiseaseKW1()
    {
      InitializeComponent();
    }

  private void btnGenerate_Click(object sender, EventArgs e)
  {
    string sName = txtName.Text;
    string sSerial ="";
    int iVar0 = 0x41;
    int iVar2 = 0;
			
    if (txtName.TextLength < 6)
      txtSerial.Text = "Insert Name >= 6 chars";
    else if(txtName.TextLength > 5)
    {								
      do
      {
        sName = sName.Replace(Convert.ToString((Convert.ToChar(iVar0))),
                        Convert.ToString(Convert.ToChar(iVar0 - 0x13)));

        iVar0++;
        iVar2 = 0xff;
      }
      while (iVar0 <= iVar2);
								
      sName = sName.Replace("N", "7A(C(KAL");
      sName = sName.Replace("O", "AC(/3AVK");
      sName = sName.Replace("P", "9!?988DA");
      sName = sName.Replace("Q", "CAKEAJKH");
      sName = sName.Replace("R", "CAEK8462");
      sName = sName.Replace("S", "TUAIJKEW");
      sName = sName.Replace("T", "AMM(X/78");
      sName = sName.Replace("U", "RAPHHUXA");
      sName = sName.Replace("V", "D7A)(HAK");
      sName = sName.Replace("W", "ECMLEKKK");
      sName = sName.Replace("X", "AWEFHANN");
      sName = sName.Replace("Y", "EWJKANBX");
      sName = sName.Replace("Z", "NOCPWWXY");
      
      sSerial = sName.Substring(sName.Length - 8);
      txtSerial.Text = sSerial;
    }
}