// Eval_N4.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "windows.h"

char name[100]="ComputerAngel";
char tmp_array[100];
int calc_table[5];
int ipart0,ipart1,ipart2,ipart3,ipart4;


int _tmain(int argc, _TCHAR* argv[])
{
	int tmp=0;
	int i=0;

	printf("Enter user:");
	gets_s(name,99);
	ZeroMemory(&name[strlen(name)],16);
	if (strlen(name)<6) {
		printf("Username must > 5 characters!!!\n");
		return 0;
	}

	do
	{
		tmp_array[i] = name[i];
		//tmp = ((unsigned int)v7 < 1) + tmp - 1;
		++i;
	}
	while ( name[i] );

	tmp=i;
	i=0;
	while ( tmp <= 10 )
	{
		while ( name[i] )
		{
			tmp_array[tmp++] = name[i++];
		}
	}
	tmp_array[11] = 0;

	int j = 0;
	do
	{
		calc_table[j] = tmp_array[j] * 2 - tmp_array[j + 5];
		++j;
	}
	while ( j != 5 );

	ipart0 = tmp_array[0]*11 - 5 * (2 * tmp_array[0] - tmp_array[5]);
	ipart0+=calc_table[0];

	ipart1=tmp_array[1]*11 - 5 * (2 * tmp_array[1] - tmp_array[6]) + calc_table[1];

	ipart2= tmp_array[2]*11 - 5 * (2 * tmp_array[2] - tmp_array[7]) + calc_table[2];

	ipart3 = tmp_array[3]*11 - 5 * (2 * tmp_array[3] - tmp_array[8]) + calc_table[3];

	ipart4=tmp_array[4]*11 -(2 * tmp_array[4] - tmp_array[9]) * 5 + calc_table[4];

	printf("Serial = %d-%d-%d-%d-%d\n",ipart0,ipart1,ipart2,ipart3,ipart4);
	getchar();

	return 0;
}

