********************************
*	  Eval N�4	               *
*	     By	               *
*	  Ez�qui3l	               *
*		               *
*  www.Deezdynasty.xidr.org  *
********************************


Vous trouverez ici l'Eval N�4 destin�e � illustrer les cours de Dynasty.
Tous les coups sont permis.

Merci � tous ceux qui ont permis que l'Eval N�4 existe.

Dynasty, et tous ceux qui suivent les tuto propos�s.
Deamon sans qui rien n'aurait �t� possible.
Virtualabs.
Kaze "je pointe ou je tire ?!"
Baboon, mon b�ta....testeur.
Squallsurf, m�me si la plupart du temps il dit que des conneries.
Kaine.

Et bien d'autres encore.