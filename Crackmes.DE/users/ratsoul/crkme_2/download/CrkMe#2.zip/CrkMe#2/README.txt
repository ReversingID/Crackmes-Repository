CrkMe #2 by ratsoul
-------------------
e-mail: ratsoul at autistici.org
--------------------------------

Steps:
a) find the key (use brain)
b) find the serials
c) write a tutorial
x) no patching
x) no brute

I hope you enjoy :)
- ratsoul