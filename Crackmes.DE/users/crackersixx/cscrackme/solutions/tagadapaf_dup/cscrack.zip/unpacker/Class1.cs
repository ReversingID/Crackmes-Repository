using System;
using System.Reflection;
using System.IO;
using Sixxpack;

namespace unpacker
{
	class stub
	{
		static string path = "Sixxpack.dll";
		static int orig = 15872;

		[STAThread]
		static void Main(string[] args)
		{
			try
			{
				int num2;
				MemoryStream stream1 = new MemoryStream();
				Stream stream2 = new FileStream(path, FileMode.Open, FileAccess.Read);
				stream2.Position = stub.orig;
				byte[] buffer1 = new byte[ stream2.Length - stub.orig ];
				stream2.Read(buffer1, 0, Convert.ToInt32(buffer1.Length));
				stream1.Write(buffer1, 0, buffer1.Length);
				stream1.Seek(0, SeekOrigin.Begin);
				InflaterInputStream stream3 = new InflaterInputStream(stream1);
				byte[] buffer2 = new byte[4096];
				int num1 = 0;
			Label_0082:
				num2 = stream3.Read(buffer2, num1, 4096);
				if (num2 > 0)
				{
					num1 += num2;
					stub stub1 = new stub();
					buffer2 = ((byte[]) stub1.Redim(buffer2, (buffer2.Length + 4096)));
					goto Label_0082;
				}


				FileStream fs = new FileStream( "Unpacked.exe", FileMode.CreateNew, FileAccess.ReadWrite );
				fs.Write( buffer2, 0, buffer2.Length );
			}
			catch( Exception ex )
			{
				System.Console.WriteLine( "Error: " + ex.Message );
			}

		}

		public Array Redim(Array arrToResize, int length)
		{
			Type type1 = arrToResize.GetType().GetElementType();
			Array array1 = Array.CreateInstance(type1, length);
			Array.Copy(arrToResize, 0, array1, 0, Math.Min(arrToResize.Length, length));
			return array1;
		}
 

	}
}
