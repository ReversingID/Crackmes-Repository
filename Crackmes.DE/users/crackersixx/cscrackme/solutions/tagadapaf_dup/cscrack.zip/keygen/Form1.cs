using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Text;
using System.Reflection;

namespace keygen
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox tbName;
		private System.Windows.Forms.TextBox tbSerial;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.tbName = new System.Windows.Forms.TextBox();
			this.tbSerial = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// tbName
			// 
			this.tbName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tbName.Location = new System.Drawing.Point(32, 24);
			this.tbName.MaxLength = 32760;
			this.tbName.Name = "tbName";
			this.tbName.Size = new System.Drawing.Size(192, 20);
			this.tbName.TabIndex = 0;
			this.tbName.Text = "Enter your name";
			this.tbName.TextChanged += new System.EventHandler(this.tbName_TextChanged);
			// 
			// tbSerial
			// 
			this.tbSerial.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tbSerial.Location = new System.Drawing.Point(32, 56);
			this.tbSerial.Name = "tbSerial";
			this.tbSerial.Size = new System.Drawing.Size(192, 20);
			this.tbSerial.TabIndex = 0;
			this.tbSerial.Text = "";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(256, 99);
			this.Controls.Add(this.tbName);
			this.Controls.Add(this.tbSerial);
			this.Name = "Form1";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "CSCrackMe keygen";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void tbName_TextChanged(object sender, System.EventArgs e)
		{
				int num4;
				if (this.tbName.Text.Length <= 4)
				{
					tbSerial.Text = "Invalid name";
					return;
				}
				int num1 = 0;
				int num2 = 0;
				string text1 = "";
				Encoding encoding1 = Encoding.ASCII;
				byte[] buffer2 = encoding1.GetBytes(this.tbName.Text);
				for (num4 = 0; (num4 < buffer2.Length); ++num4)
				{
					byte num3 = buffer2[num4];
					//num1 = ((num3 * this.a.GetHashCode())  * 6);
					//num2 += (num1 * this.b.GetHashCode()) ;
					num1 = ((num3 * 18) * 6);
					num2 += (num1 * 19) ;
					text1 = num2.ToString();
				}
				this.tbSerial.Text = text1.Trim();
			}
		}
	}
