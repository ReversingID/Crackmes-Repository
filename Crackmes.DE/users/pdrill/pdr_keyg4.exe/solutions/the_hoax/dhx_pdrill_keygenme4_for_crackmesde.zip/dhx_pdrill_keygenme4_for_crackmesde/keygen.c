char name[50],serial[50],temp[50];
unsigned char progname[]="pDriLl's.KEYGENME.4-KEYGEN",protection[]="DSA, MD5";
int len,i;

extern void sha_(void);
extern void update_(void);
extern void done_(void);

SHS_INFO shsInfo;

void makeserial(HWND hWnd)
{

		big r,s,q,p,x,k,k1,g,m;
		miracl *mip=mirsys(256, 0);
		unsigned char hash[32];

		m=mirvar(0);
		g=mirvar(0);
		r=mirvar(0);
		s=mirvar(0);
		q=mirvar(0);
		p=mirvar(0);
		x=mirvar(0);
		k=mirvar(0);
		k1=mirvar(0);


again:
		len=GetDlgItemText(hWnd,IDC_NAME,name,50);
		if(len>40 || len<5){
			SetDlgItemText(hWnd,IDC_SERIAL,"Invalid input");
		return;}

		sha_(&shsInfo);
		update_(&shsInfo,name,len);
		done_(&shsInfo);

		mip->IOBASE=16;

// R = (G^K mod P) mod Q
// S = (K^-1*(SHA(M) + X*R)) mod Q

		cinstr(p,"AE2CCC8E5956DE7898143649944108EEFCA2C7EF909012BB");
		cinstr(q,"A7DD75045151");
		cinstr(x,"40A6C8A2464A891E99DDBFCFC967BAFD4BAFA67B3ECEDC43");
		cinstr(g,"8DFC33DF82EDEFF56ABD1AE161BE17FBC1F403D5DF133106");

		bytes_to_big(20,&shsInfo,m);

		irand(GetTickCount()%-1);

		copy(g,r);

		bigrand(p,k);

		powmod(g,k,p,r);

		divide(r,q,q);

		copy(k,k1);

		xgcd(k1,q,k1,k1,k1);

		mad(x,r,m,q,q,s);

		multiply(k1,s,s);

		divide(s,q,q);

		cotstr(s,temp);

		cotstr(r,name);

		lstrcpyn(serial,name,7);
		serial[6]=0x2d;
		lstrcpyn(serial+7,name+6,7);
		serial[13]=0x2d;
		lstrcpyn(serial+7+7,temp,7);
		serial[20]=0x2d;
		lstrcpyn(serial+7+7+7 ,temp+6,7);
		if(strlen(serial)!=27)
		goto again;

		SetDlgItemText(hWnd,IDC_SERIAL,serial);

		mirkill(m);
		mirkill(g);
		mirkill(r);
		mirkill(s);
		mirkill(q);
		mirkill(p);
		mirkill(x);
		mirkill(k);
		mirkill(k1);
		mirexit();
return;
}
