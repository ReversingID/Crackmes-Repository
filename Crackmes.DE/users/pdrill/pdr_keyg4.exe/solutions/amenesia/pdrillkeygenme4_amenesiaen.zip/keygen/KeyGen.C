/*
 *  
 *   Keygen pour le Crypto keygenMe #4 de pDriLl par Amenesia  ( compilation: bcc32/Tasm32 )
 *          
 */

#include <stdio.h>
#include <string.h>
#include <miracl.h>   


/*
 *  
 *   Hash extrait du keygenme
 *          
 */
    asm
    { 


	IniHash	proc near

		mov	eax, [esp+4]
		xor	ecx, ecx
		mov	dword ptr [eax], 67452301h
		mov	dword ptr [eax+4], 0EFCDAB89h
		mov	dword ptr [eax+8], 98BADCFEh
		mov	dword ptr [eax+0Ch], 10325476h
		mov	dword ptr [eax+10h], 0C3D2E1F0h
		mov	[eax+14h], ecx
		mov	[eax+18h], ecx
		retn
	IniHash	endp





	PrepareHash	proc near	

		mov	ecx, [esp+0Ch]
		push	ebx
		mov	ebx, [esp+8]
		push	ebp
		push	esi
		push	edi
		mov	eax, [ebx+14h]
		lea	edx, [eax+ecx*8]
		cmp	edx, eax
		jnb	short loc_0_4024D9
		inc	dword ptr [ebx+18h]

	loc_0_4024D9:				 
		mov	eax, ecx
		mov	[ebx+14h], edx
		mov	edx, [ebx+18h]
		shr	eax, 1Dh
		add	edx, eax
		cmp	ecx, 40h
		mov	[ebx+18h], edx
		jl	short loc_0_402545
		mov	eax, ecx
		mov	ebp, [esp+18h]
		shr	eax, 6
		mov	[esp+14h], eax
		neg	eax
		shl	eax, 6
		add	ecx, eax
		mov	[esp+1Ch], ecx

	loc_0_402506:				 
		mov	ecx, 10h
		mov	esi, ebp
		lea	edi, [ebx+1Ch]
		push	ebx
		repe movsd
		call	sub_0_402550
		mov	eax, [esp+18h]
		add	esp, 4
		add	ebp, 40h
		dec	eax
		mov	[esp+14h], eax
		jnz	short loc_0_402506
		mov	ecx, [esp+1Ch ]

	loc_0_40252D:				 
		mov	edx, ecx
		mov	esi, ebp
		lea	edi, [ebx+1Ch]
		shr	ecx, 2
		repe movsd
		mov	ecx, edx
		and	ecx, 3
		repe movsb
		pop	edi
		pop	esi
		pop	ebp
		pop	ebx
		retn

	loc_0_402545:				 
		mov	ebp, [esp+18h]
		jmp	short loc_0_40252D
	PrepareHash	endp



		sub_0_402550	proc near		 


		sub	esp, 14Ch
		mov	ecx, 10h
		lea	eax, [esp+14Ch-138h]
		push	ebx
		mov	ebx, [esp+150h+4]
		push	ebp
		push	esi
		push	edi
		lea	esi, [ebx+1Ch]
		lea	edi, [esp+15Ch-140h]
		repe movsd
		mov	ecx, 40h

	loc_0_402578:				 
		mov	edx, [eax+2Ch]
		mov	esi, [eax+18h]
		mov	ebp, [eax-8]
		mov	edi, [eax]
		xor	edx, esi
		add	eax, 4
		xor	edx, ebp
		xor	edx, edi
		dec	ecx
		mov	[eax+34h], edx
		jnz	short loc_0_402578
		mov	edi, [ebx]
		mov	eax, [ebx+4]
		mov	edx, [ebx+8]
		mov	esi, [ebx+0Ch]
		mov	ebx, [ebx+10h]
		lea	ecx, [esp+15Ch-140h]
		mov	[esp+15Ch-144h], ebx
		mov	[esp+15Ch-14Ch], ecx
		mov	dword ptr [esp+15Ch-148h], 14h

	loc_0_4025B4:				 
		mov	ecx, eax
		mov	ebx, edx
		not	ecx
		and	ecx, esi
		and	ebx, eax
		or	ecx, ebx
		mov	ebx, edi
		mov	ebp, edi
		shr	ebx, 1Bh
		shl	ebp, 5
		or	ebx, ebp
		mov	ebp, [esp+15Ch-14Ch]
		add	ecx, ebx
		mov	ebx, [ebp+0]
		add	ebp, 4
		add	ecx, ebx
		mov	ebx, [esp+15Ch-144h]
		mov	[esp+15Ch-14Ch], ebp
		mov	ebp, [esp+15Ch-148h]
		lea	ecx, [ecx+ebx+5A827999h]
		mov	ebx, esi
		mov	esi, edx
		mov	edx, eax
		shl	edx, 1Eh
		shr	eax, 2
		or	edx, eax
		dec	ebp
		mov	eax, edi
		mov	[esp+15Ch-144h], ebx
		mov	edi, ecx
		mov	[esp+15Ch-148h], ebp
		jnz	short loc_0_4025B4
		lea	ebp, [esp+15Ch-0F0h]
		mov	dword ptr [esp+15Ch-14Ch], 14h
		mov	[esp+15Ch-148h], ebp

	loc_0_40261A:				 
		mov	ebp, ecx
		shr	ebp, 1Bh
		shl	ecx, 5
		or	ebp, ecx
		mov	ecx, esi
		xor	ecx, edx
		xor	ecx, eax
		add	ebp, ecx
		mov	ecx, ebp
		mov	ebp, [esp+15Ch-148h]
		add	ecx, [ebp+0]
		add	ebp, 4
		mov	[esp+15Ch-148h], ebp
		mov	ebp, [esp+15Ch-14Ch]
		lea	ecx, [ecx+ebx+6ED9EBA1h]
		mov	ebx, esi
		mov	esi, edx
		mov	edx, eax
		shl	edx, 1Eh
		shr	eax, 2
		or	edx, eax
		dec	ebp
		mov	eax, edi
		mov	edi, ecx
		mov	[esp+15Ch-14Ch], ebp
		jnz	short loc_0_40261A
		mov	[esp+15Ch-144h], ebx
		lea	ebx, [esp+15Ch-0A0h]
		mov	[esp+15Ch-148h], ebx
		mov	dword ptr [esp+15Ch-14Ch], 14h

	loc_0_402677:				 
		mov	ebx, edx
		mov	ebp, edx
		or	ebx, eax
		and	ebp, eax
		and	ebx, esi
		or	ebx, ebp
		mov	ebp, ecx
		shr	ebp, 1Bh
		shl	ecx, 5
		or	ebp, ecx
		add	ebx, ebp
		mov	ebp, [esp+15Ch-148h]
		mov	ecx, [ebp+0]
		add	ebp, 4
		add	ebx, ecx
		mov	ecx, [esp+15Ch-144h]
		mov	[esp+15Ch+-148h], ebp
		mov	ebp, [esp+15Ch-14Ch]
		lea	ecx, [ebx+ecx-70E44324h]
		mov	ebx, esi
		mov	esi, edx
		mov	edx, eax
		shl	edx, 1Eh
		shr	eax, 2
		or	edx, eax
		dec	ebp
		mov	eax, edi
		mov	[esp+15Ch-144h], ebx
		mov	edi, ecx
		mov	[esp+15Ch-14Ch], ebp
		jnz	short loc_0_402677
		lea	ebp, [esp+15Ch-50h]
		mov	dword ptr [esp+15Ch-14Ch], 14h
		mov	[esp+15Ch-148h], ebp

	loc_0_4026DE:				 
		mov	ebp, ecx
		shr	ebp, 1Bh
		shl	ecx, 5
		or	ebp, ecx
		mov	ecx, esi
		xor	ecx, edx
		xor	ecx, eax
		add	ebp, ecx
		mov	ecx, ebp
		mov	ebp, [esp+15Ch-148h]
		add	ecx, [ebp+0]
		add	ebp, 4
		mov	[esp+15Ch-148h], ebp
		mov	ebp, [esp+15Ch-14Ch]
		lea	ecx, [ecx+ebx-359D3E2Ah]
		mov	ebx, esi
		mov	esi, edx
		mov	edx, eax
		shl	edx, 1Eh
		shr	eax, 2
		or	edx, eax
		dec	ebp
		mov	eax, edi
		mov	edi, ecx
		mov	[esp+15Ch-14Ch], ebp
		jnz	short loc_0_4026DE
		mov	edi, [esp+15Ch+4]
		mov	ebp, [edi]
		add	ebp, ecx
		mov	ecx, [edi+4]
		add	ecx, eax
		mov	eax, [edi+8]
		add	eax, edx
		mov	[edi], ebp
		mov	[edi+8], eax
		mov	eax, [edi+0Ch]
		add	eax, esi
		mov	[edi+4], ecx
		mov	[edi+0Ch], eax
		mov	eax, [edi+10h]
		add	eax, ebx
		mov	[edi+10h], eax
		pop	edi
		pop	esi
		pop	ebp
		pop	ebx
		add	esp, 14Ch
		retn
	sub_0_402550	endp





	Hashfct		proc near		 

		push	ebx
		push	ebp
		push	esi
		mov	esi, [esp+14h]
		push	edi
		mov	ebx, [esi+14h]
		mov	ebp, [esi+18h]
		mov	edx, ebx
		shr	edx, 3
		and	edx, 3Fh
		mov	byte ptr [edx+esi+1Ch],	80h
		inc	edx
		cmp	edx, 38h
		jle	short loc_0_4027B3
		mov	ecx, 40h
		lea	edi, [edx+esi+1Ch]
		sub	ecx, edx
		xor	eax, eax
		mov	edx, ecx
		push	esi
		shr	ecx, 2
		repe stosd
		mov	ecx, edx
		and	ecx, 3
		repe stosb
		call	sub_0_402550
		add	esp, 4
		mov	ecx, 0Eh
		xor	eax, eax
		lea	edi, [esi+1Ch]
		repe stosd
		jmp	short loc_0_4027CE

	loc_0_4027B3:				 
		mov	ecx, 38h
		lea	edi, [edx+esi+1Ch]
		sub	ecx, edx
		xor	eax, eax
		mov	edx, ecx
		shr	ecx, 2
		repe stosd
		mov	ecx, edx
		and	ecx, 3
		repe stosb

	loc_0_4027CE:				 
		push	esi
		mov	[esi+54h], ebp
		mov	[esi+58h], ebx
		call	sub_0_402550
		mov	eax, [esp+18h]
		mov	ecx, [esi]
		add	esp, 4
		mov	[eax], ecx
		mov	edx, [esi+4]
		mov	[eax+4], edx
		mov	ecx, [esi+8]
		mov	[eax+8], ecx
		mov	edx, [esi+0Ch]
		mov	[eax+0Ch], edx
		mov	ecx, [esi+10h]
		pop	edi
		pop	esi
		pop	ebp
		mov	[eax+10h], ecx
		pop	ebx
		retn
	Hashfct		endp
    }




/*
 *  
 *  [ DSA signature ]
 *      
 *    Choix d �un nombre al�atoire k < Q 
 *      R = (G^K mod P) mod Q 
 *      S = (K^-1*(HASH(M) + X*R)) mod Q
 * 
 *   Si K=1
 *      R = (G mod P) mod Q 
 *      S = (HASH(M) + X*R) mod Q
 *    
 *   Donc R est fixe ( ainsi que X*R )
 */

void main()
{  
    char R_DSA[13];
    char clef2[13]= "000000-000000";
    char Hash[96];
    char HashName[20];
    char nom[30];
    int i,nbreZero;
    int longNom;

    miracl *mip=mirsys(500,16);  /* base 0, 50 digits par big  */


    big XR       =mirvar(0);    // X*R mod Q
    big moduloQ  =mirvar(0);    // Q
    big hashMes  =mirvar(0);    // Hash(M)
    big resultat =mirvar(0);    // S

    mip->IOBASE=16;
    cinstr(XR,"3D95EC3920E3");
    cinstr(moduloQ,"A7DD75045151");


    printf("\t KeyGen [pDriLl KeygenMe #4] par Amenesia\n");
    printf("\t ---------------------------------------\n");

    printf("Nom: \t");
    scanf("%30s",&nom);

    longNom = strlen(nom);

    asm
    { 
		lea	ecx, [Hash]
		push	ecx
		call	IniHash
		add	esp, 4

		mov	edx, dword ptr longNom
		push	edx
		lea	eax, [nom]
		push	eax
		lea	eax, [Hash]
		push	eax
		call	PrepareHash
		add	esp, 0Ch

		lea	ecx, [Hash]
		push	ecx
		lea	edx, [HashName]
		push	edx
		call	Hashfct
                add     esp, 8
       } 

    bytes_to_big(20,HashName,hashMes);  
      
    add(hashMes,XR,resultat);
    fmodulo(resultat,moduloQ,resultat);

    mip->IOBASE=16;
    cotstr(resultat,R_DSA);


    nbreZero = 12-strlen(R_DSA);

    if (nbreZero < 6)  
    {  for (i = 0; i < (6-nbreZero); i++) { clef2[i+nbreZero] = R_DSA[i]; } }
    if (nbreZero < 12) 
    { for (i = (6-nbreZero); i < strlen(R_DSA); i++) { clef2[i+1+nbreZero] = R_DSA[i];} }
           
    printf("4A2B82-73F9AF-%s\n",clef2);  
 

}





