/*  pDriLI's crypto keygenme #5
    Protection: weak DLP/weak ECDLP
    Solution: Amenesia//TKM!
*/
#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <miracl.h>
	
 int generateur( char * lpName, char * license )
	{
   int  lgName, lgX1, lgX2,j, i1,i2,cj;
    char str_X1[40];
    char str_X2[40];
    char str_Serial[64];           
    char nameb[30] = "TMG-";
    
    miracl *mip=mirsys(200,0); 
    big bigName=mirvar(0);    
    big p=mirvar(0);
    big k=mirvar(0);
    big X1=mirvar(0);        
    big X2=mirvar(0); 
   
            
    big np=mirvar(0);
 
    big a=mirvar(0);
    big b=mirvar(0);    
    big xA=mirvar(0);         
    epoint* A = epoint_init();
    big xB=mirvar(0);         
    epoint* B = epoint_init(); 
    big xP=mirvar(0);    
    epoint* P = epoint_init();     
    big logAB=mirvar(0);

    /* -------------- Elliptic Curve ---------------  */
    mip->IOBASE=16;
    cinstr(a,"1"); 
    cinstr(b,"0"); 
    cinstr(p,"ACC00CF0775153B19E037CE879D332BB");       
    cinstr(np,"ACC00CF0775153B19E037CE879D332BC");
    
    cinstr(logAB,"1212121255555ABCDEFABCDEF9999999");               
    cinstr(xA,"18650A0922FC3EC0B778347B20EE6619"); 
    cinstr(xB,"0D85FA1C5BC8982485ACD9FA9B1BEBEC");        
    
    ecurve_init(a,b,p,MR_AFFINE);
    epoint_set(xA,xA,0,A);
    epoint_set(xB,xB,1,B);

    irand(GetTickCount());

    /* -------------- Interface ---------------  */

    strcpy(&(nameb[4]),lpName);
    lgName = strlen(nameb);
    bytes_to_big(lgName,nameb,bigName);


    /* -------------- Signature ---------------  */    
    bigrand(np,X1);
    bigrand(np,X2);
    ecurve_mult2(X1,A,X2,B,P);
    epoint_get(P,xP,xP);
    mad(X2,logAB,X1,np,np,k);
       
    add(bigName,xP,X2);
    divide(X2,np,np);

    multiply(X2,logAB,X1);
    subtract(k,X1,X1);
    divide(X1,np,np);
    if(size(X1)<0){add(X1,np,X1);}   

    
    /* -------------- Boring ---------------  */  
    mip->IOBASE=36;
    lgX1 = cotstr(X1,str_X1);
    lgX2 = cotstr(X2,str_X2);         
    
    i1=0;  i2=0;
    if(lgX2==25) {str_Serial[0]= str_X2[i1]; i1++;} 
    else { str_Serial[0] = '0'; }
    
    if(lgX1==25) {str_Serial[1]= str_X1[i2];i2++;} 
    else {str_Serial[1]='0'; }
    
    cj=1;          
    for(j=2;j<32;j++)
    {
      if( ((j-2)%5) == 0) {str_Serial[j]='-';}
      else
      { 
            cj++;
            if ((25-cj)>=lgX2) {str_Serial[j]='0';}
            else {str_Serial[j]=str_X2[i1];i1++;}
      }
      
    }

    cj=1;
    for(j=32;j<62;j++)
    {
      if( ((j-32)%5) == 0)
      {str_Serial[j]='-';}
      else
      { 
            cj++;
            if ((25-cj)>=lgX1) {str_Serial[j]='0';}
            else {str_Serial[j]=str_X1[i2];i2++;}
      }
      
    }
    

    
    /* -------------- Result ---------------  */ 
   
       
          
    str_Serial[62] = 0;
    strcpy(license,str_Serial);

				                  
		/* ---------------------------------------------------------------------------- */
		epoint_free(A);
		epoint_free(B);
		epoint_free(P);
		mirkill(bigName);
		mirkill(p);	
		mirkill(k);
		mirkill(X1);
		mirkill(X2);	
		mirkill(np);
		mirkill(a);
		mirkill(b);
		mirkill(xA);
		mirkill(xB);
		mirkill(xP);
		mirkill(logAB);      		
		mirexit();
		return 0;
		}


