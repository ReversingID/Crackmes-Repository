/**
 * @author wilq
 * solution:  adiorlc
 */


function func(a){
  return (a+1)*(a+1)+(a+2)*(a+4);
}

var ret={};

for (var i=1;i<30;i++)
{
  ret[i]={value:func(i), letter:String.fromCharCode(96+i)};
}

function f(s, C, m)
{
		if (ret[C]) s+=ret[C].letter;
	var value1=(!C && !s[m]);
	var value2=(C && s[m] && s[m++] == String.fromCharCode(96 + C) && f(s, ((++C * C++) + (C++ * ++C) >> ++m), --m));
        if (value1) {alert("Password is:"+s); }
    return  value1 || value2; 	
}

f("",1,0)

/*

Short explanation:
(x+1)(x+1) + (x+2)(x+4) 

this is a (++C * C++) + (C++ * ++C) written in more mathemathical way :)

So we use this to create proper table with given C as a parameter, then 
we modify a little our output function, and wuala - full automation :)

This solution is created to show a automatical way of solving it, not only
using simple alert(String.fromCharCode(96 + C) )  for every correct letter 
brute force :P huh :)

*/