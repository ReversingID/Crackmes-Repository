Hey jo guys!
Well this Crackme is my second C++ Crackme!

Hope you like it.. well shouldnt be that hard!

Rules:
1. Do not Patch
2. Sniff a serial for your name
3. write a keygen

Special thanx goes to d@b -> your my master ;)
this crackme is espacially for him (d@b), because he was pissed off sooooooo much of VB shit!

ThX LuCiFeR