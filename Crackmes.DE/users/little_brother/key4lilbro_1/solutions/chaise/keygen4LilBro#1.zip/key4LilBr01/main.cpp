#include <windows.h>
#include <stdlib.h>
#include "resource.h"
#include <string.h>

BOOL APIENTRY DlgProc(HWND Dlg,UINT message,WPARAM wParam,LPARAM lParam);

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                                                LPSTR lpCmdLine, int nCmdShow)
{
       DialogBox(hInstance,"DIALOG1",NULL,(DLGPROC)DlgProc);
       return 0;
}
//---------------------------------------------------------------------------

BOOL APIENTRY DlgProc(HWND hDlg,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
    switch (uMsg)
    {
      case WM_INITDIALOG:
         return TRUE;
      case WM_COMMAND:
         if (LOWORD(wParam) == IDOK)
              {
                char name[256]="",serial[]="";
                char b1[8] = "little_"; // beginning of the psw
                char b2[9] = "_brother"; // end of the psw
                char buff[20]="";
               char buf[13]="";
                long buf1[10];
                char msgerreur[]="user > 3 pos";
                char int1;
                int i,nb,mul,ind,j;
                GetDlgItemText(hDlg, IDE_EDIT1, name, 256);
        int len = strlen(name);  /* user = chaise ===> 6 */
    if(len < 4) {
        strcpy(serial,msgerreur);
        goto IMPRES;}
   ind = -1;
    for(int i = 0; i < 4; i++)   // reverse of the value of the 4 last carat. of the name
    {
        nb = int(name[len-1-i]); // i=0 ==> e(101), i=1 ==> s(115), i=2==> i(105), i=3 ==> a (97)

        while(nb)
            {                    // if i = 1 ==>
                j = (nb % 10);  // s = UNICODE 115 ==> j = 115%10 ==> 5
                ind +=1;        // ind = -1+1 = 0
                buf1[ind]=j;    // buf1[0]= j =5
                nb /= 10;       // 115/10 = 11
                                // j = 11%10 ==> 1
                                // ind = 0+1=1
                                // buf1[1]= 1
                                //11/10= 1
                                // j = 1%10==> 1
                                // ind = 1+1=2
                                // buf1[2]= 1
            }

        };
// after the loop ==> buf1 = 10151150179

nb = int(name[0]);          // search of the 2 last numbers of the psw
wsprintf(buff, "%X", nb);   // value of the 1st car. in HEXA ==> "c" ==> 63
int1 = buff[0];             // reverse the value
buff[0]= buff[1];
buff[1] = int1;             // buff = 36


if (ind ==11)
    {
    wsprintf(buf, "%d%d%d%d%d%d%d%d%d%d%d%d",buf1[0],buf1[1],buf1[2],buf1[3],buf1[4],buf1[5],buf1[6],buf1[7],buf1[8],buf1[9],buf1[10],buf1[11]);
    }
if (ind ==10)
    {
    wsprintf(buf, "%d%d%d%d%d%d%d%d%d%d%d",buf1[0],buf1[1],buf1[2],buf1[3],buf1[4],buf1[5],buf1[6],buf1[7],buf1[8],buf1[9],buf1[10]);
    }
if (ind ==9)
    {
    wsprintf(buf, "%d%d%d%d%d%d%d%d%d%d",buf1[0],buf1[1],buf1[2],buf1[3],buf1[4],buf1[5],buf1[6],buf1[7],buf1[8],buf1[9]);
    }

if (ind ==8)
    {
    wsprintf(buf, "%d%d%d%d%d%d%d%d%d",buf1[0],buf1[1],buf1[2],buf1[3],buf1[4],buf1[5],buf1[6],buf1[7],buf1[8]);
    }
if (ind ==7)
    {
    wsprintf(buf, "%d%d%d%d%d%d%d%d",buf1[0],buf1[1],buf1[2],buf1[3],buf1[4],buf1[5],buf1[6],buf1[7]);
    }
	   wsprintf(serial,"%s%s-%s%s",b1,buf,buff,b2);

 IMPRES:              SetDlgItemText(hDlg, IDE_EDIT2, serial) ;
              }
         if (LOWORD(wParam) == IDCANCEL)
                {
                   EndDialog(hDlg,0);
                   return TRUE;
                }
      default:
         return FALSE;
    }
}
