#define IDE_EDIT1 101
#define IDE_EDIT2 102
#define IDM_ABOUT 3
