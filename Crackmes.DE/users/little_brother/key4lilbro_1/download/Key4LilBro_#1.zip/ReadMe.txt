##################################
###      Key 4 Lil Bro #1      ###
##################################

Written By: Little_Brother
Written In: Visual Basic 6.0
Written For: crackmes.de

Since this is my first crackme for this site I decided to keep it simple and see how everyone responds. There is no protection/packing/anti-debugging of any kind. You may do whatever you have to to gather the information you need, but the keygen you must create HAS to work with the unmodified and unpatched original .exe.

So get to it and make me a keygen & tutorial. :)

Little_Brother

