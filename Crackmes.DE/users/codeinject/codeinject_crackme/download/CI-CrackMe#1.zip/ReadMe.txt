This is my very first CrackMe.
I doubt it's hard. It's been developed as a part of my Thesis.
All the normal rules apply, no patching etc.
Write a Keygen and a tutorial on how you've beaten me.

It's been developed with HxD, MSVC++ 2k10, ImmunityDBG a lot of manual crafting work.
When it's cracked I'll release the original source code for those interested.