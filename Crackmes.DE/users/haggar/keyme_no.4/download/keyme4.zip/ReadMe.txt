~~~~~~~~~~~~~~~~~~~~~~
 KeyMe no.4 by HAGGAR
~~~~~~~~~~~~~~~~~~~~~~


This keyme came up after reversing some games CD-key checks so you can take it as some practice. Your task is to create generic keygen. It is very easy, but hey, this kind of checks usualy are (from my experience).

Greets goes to all good people on crackmes.de, BIW reversing, ARTEAM, SnD and FHCF. Special gretings is for folks who solved my previous crackmes.