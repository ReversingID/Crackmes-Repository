using System;
using System.Globalization;
using System.Text;

namespace KeyGenMe
{
    class KeyGenMe
    {
        static void Main(string[] args)
        {
            Console.WriteLine("*              - KeyGen Solution to hagger's `clone` keygenme -");
            Console.WriteLine("*             Tutorial Written & KeyGen published by SKiLLa 2006");
            Console.WriteLine("********************************************************************************");

            string name   = String.Empty;
            string serial = String.Empty;
            uint   hash   = 0;
            
            while (name.Length < 5 || name.Length > 50)
            {
                Console.Write("* Name (5,50) chars: ");
                name = Console.ReadLine();
            }

            hash   = Name2Hash  (name);
            serial = Hash2Serial(hash);

            Console.WriteLine("* Name {0} = Serial {1}", name, serial);
            Console.WriteLine("********************************************************************************");
            Console.Write("Press any key to exit the program ...");
            Console.ReadKey(true);
        }


        static uint Name2Hash(string name)
        {
            uint eax = 0;
            uint ecx = 0;
            uint dl  = 0;

            char[] arrName = name.ToCharArray();

            // Read first 4 chars of serial into the 4 bytes of eax 
            for (int i = 0; i < 4; i++)
            {
                eax += ((uint) arrName[i]) << 8 * i;
            }

            // Read the rest of the serial as 'byte sum' in dl
            for (int i = 4; i < arrName.Length; i++)
            {
                dl += ((uint) arrName[i] & 0xFF);
            }

            // Now replicate dl into all the ecx bytes
            ecx = (dl << 24) + (dl << 16) + (dl << 8) + dl;

            ecx = ecx ^ eax;        // xor      ecx, eax
            ecx = Bswap(ecx);       // bswap    ecx

            ecx += 0x3022006;       // add      ecx, 0x03022006     ' 03-02-2006 (03 Feb 2006) is the creation date of the KeyGenMe ?
            ecx = Bswap(ecx);       // bswap    ecx

           	ecx -= 0xDEADC0DE;      // sub      ecx, 0xDEADC0DE
            ecx = Bswap(ecx);       // bswap    ecx

            ecx = (ecx & 0xFFFFFF00) + (((ecx & 0x000000FF) + 0x0001) & 0x000000FF); // inc  cl
            ecx = (ecx & 0xFFFF00FF) + (((ecx & 0x0000FF00) + 0x0100) & 0x0000FF00); // inc  ch
            ecx = Bswap(ecx);       // bswap    ecx

            ecx = (ecx & 0xFFFFFF00) + (((ecx & 0x000000FF) - 0x0001) & 0x000000FF); // dec  cl
            ecx = (ecx & 0xFFFF00FF) + (((ecx & 0x0000FF00) - 0x0100) & 0x0000FF00); // dec  ch
            ecx = Bswap(ecx);       // bswap    ecx


            ecx = ecx ^ 0xEDB88320; // xor      ecx, 0xEDB88320
            ecx = Bswap(ecx);       // bswap    ecx

            ecx += 0xD76AA478;      // add      ecx, 0xD76AA478
            ecx = Bswap(ecx);       // bswap    ecx

            ecx -= 0xB00BFACE;      // add      ecx, 0xB00BFACE
            ecx = Bswap(ecx);       // bswap    ecx

            ecx += 0x0BADBEEF;      // add      ecx, 0x0BADBEEF
            ecx = Bswap(ecx);       // bswap    ecx

        	ecx++;                  // inc      ecx
            ecx = Bswap(ecx);       // bswap    ecx

        	ecx--;                  // dec      ecx
            ecx = Bswap(ecx);       // bswap    ecx

            ecx += eax;             // add      ecx, eax
            ecx = Bswap(ecx);       // bswap    ecx

            ecx = (ecx & 0xFFFF0000) + (((ecx & 0x0000FFFF) + 1) & 0x0000FFFF); // inc  cx
            ecx = Bswap(ecx);       // bswap    ecx

            ecx = (ecx & 0xFFFF0000) + (((ecx & 0x0000FFFF) + 1) & 0x0000FFFF); // inc  cx
            ecx = Bswap(ecx);       // bswap    ecx

            return ecx;
        }


        static string Hash2Serial(uint hash)
        {
            uint eax = 0;
            uint ebx = 0;
            uint ecx = 0;

            eax = Bswap(hash);                  // bswap    eax
    
            ebx  = (eax & 0x000000FF);          // mov      ebx, al
            ebx  = (ebx - 0xEF) & 0xFF;         // sub      ebx, 0xEF : and     ebx, 0xFF
            ebx ^= 0xCD;                        // xor      ebx, 0xCD
            ecx  = ebx;                         // mov      ecx, ebx

            eax -= ebx;                         // sub      eax, ebx

            ebx  = (eax & 0x0000FF00) >> 8;     // mov      ebx, ah
            ebx  = (ebx - 0xAB) & 0xFF;         // sub      ebx, 0xAB : and     ebx, 0xFF
            ebx ^= 0x90;                        // xor      ebx, 0x90
            ecx += ebx << 8;                    // shl      ebx, 8    : add     ecx, ebx

            eax -= ebx;                         // sub      eax, ebx

            ebx  = (eax & 0x00FF0000) >> 16;    // bswap    eax       : mov     ebx, ah      : bswap    eax
            ebx  = (ebx - 0x78) & 0xFF;         // sub      ebx, 0x78 : and     ebx, 0xFF
            ebx ^= 0x56;                        // xor      ebx, 0x56
            ecx += ebx << 16;                   // shl      ebx, 16   : add     ecx, ebx

            eax -= ebx;                         // sub      eax, ebx

            ebx  = (eax & 0xFF000000) >> 24;    // bswap    eax       : mov     ebx, al
            ebx  = (ebx - 0x34) & 0xFF;         // sub      ebx, 0x34 : and     ebx, 0xFF
            ebx ^= 0x12;                        // xor      ebx, 0x12
            ecx += ebx << 24;                   // shl      ebx, 24   : add     ecx, ebx

            return String.Format("{0:X8}", ecx); // ToHexString (ecx)
        }


        static string Serial2Hash(string serial)
        {
            if (serial.Length != 8) throw new ApplicationException("Invalid serial length");

            uint   eax = 0;
            uint   ebx = 0;

            ebx = (uint) Convert.ToByte(serial.Substring(0, 2), 16);    // movzx    ebx, byte ptr [serial+0]  : shl     ebx, 4
                                                                        // movzx    edx, byte ptr [serial+1]  : add     ebx, edx
            ebx ^= 0x12;                                                // xor      ebx, 0x12
            ebx  = (ebx + 0x34) & 0xFF;                                 // add      ebx, 0x34                 : and     ebx, 0xFF
            eax  = ebx << 8;                                            // shl      ebx, 8                    : mov     eax, ebx

            ebx  = (uint) Convert.ToByte(serial.Substring(2, 2), 16);   // movzx    ebx, byte ptr [serial+2]  : shl     ebx, 4
                                                                        // movzx    edx, byte ptr [serial+3]  : add     ebx, edx
            ebx ^= 0x56;                                                // xor      ebx, 0x56
            ebx  = (ebx + 0x78) & 0xFF;                                 // add      ebx, 0x78                 : and     ebx, 0xFF
            eax += ebx;                                                 // add      eax, ebx
            eax  = eax << 8;                                            // shl      eax, 8

            ebx  = (uint) Convert.ToByte(serial.Substring(4, 2), 16);   // movzx    ebx, byte ptr [serial+4]  : shl     ebx, 4
                                                                        // movzx    edx, byte ptr [serial+1]  : add     ebx, edx
            ebx ^= 0x90;                                                // xor      ebx, 0x90
            ebx  = (ebx + 0xAB) & 0xFF;                                 // add      ebx, 0xAB                 : and     ebx, 0xFF
            eax += ebx;                                                 // add      eax, ebx
            eax  = eax << 8;                                            // shl      eax, 8

            ebx  = (uint) Convert.ToByte(serial.Substring(6, 2), 16);   // movzx    ebx, byte ptr [serial+6]  : shl     ebx, 4
                                                                        // movzx    edx, byte ptr [serial+1]  : add     ebx, edx
            ebx ^= 0xCD;                                                // xor      ebx, 0xCD
            ebx  = (ebx + 0xEF) & 0xFF;                                 // add      ebx, 0xEF                 : and     ebx, 0xFF
            eax += ebx;                                                 // add      eax, ebx

            eax = Bswap(eax);                                           // bswap    eax
            return String.Format("{0:X8}", eax);                         // toHexString (eax)
        }



        /// Emulate the ASM command: bswap   eax
        static uint Bswap(uint eax)
        {
            return ((eax & 0xFF) << 24) + (((eax >> 8) & 0xFF) << 16) + (((eax >> 16) & 0xFF) << 8) + (( eax >> 24) & 0xFF);
        }
    }
}
