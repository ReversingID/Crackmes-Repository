#include<stdio.h>
#include<windows.h>

main()
{
	char name[30];
	char arr[15];
	int t1=0;
	printf("\tKeyGen By Cyclops\n");
	printf("Enter a name:");
	scanf("%[^\n]",name);
	if(strlen(name)<5)
	{
		printf("The name should contain atleast 5 letters!!!.\n");
		exit(0);
	}
	_asm
	{
		lea eax, dword ptr [name]
		lea ecx,dword ptr [eax+4]
		xor edx,edx
loc:
		add dl, byte ptr [ecx]
		inc ecx
		cmp byte ptr [ecx], 0
		jnz loc

		xor ecx, ecx	
		mov cl, dl
		mov ch, dl
		bswap ecx
		mov cl, dl
	 	mov ch, dl
		mov eax, dword ptr [eax]
		xor ecx, eax
		bswap ecx
		add ecx, 03022006h
		bswap ecx
		sub ecx, 0DEADC0DEh
		bswap ecx
		inc cl
		inc ch
		bswap ecx
		dec cl
		dec ch
		bswap ecx
		xor ecx, 0EDB88320h
		bswap ecx
		add ecx, 0D76AA478h
		bswap ecx
		sub ecx, 0B00BFACEh
		bswap ecx
		add ecx, 0BADBEEFh
		bswap ecx
		inc ecx
		bswap ecx
		dec ecx
		bswap ecx
		add ecx, eax
		bswap ecx
		inc cx
		bswap ecx
		inc cx
		bswap ecx
		bswap ecx
		mov t1, ecx

		xor edx, edx
		mov ecx, t1
		sub cl, 0EFh	
		xor cl, 0CDh
		and ecx, 000000FFh
		mov edx, ecx
		shl edx, 8

		mov ecx, t1
		shr ecx, 8
		sub cl, 0ABh
		xor cl, 090h
		and ecx, 000000FFh	
		add edx, ecx
		shl edx, 8
	
		mov ecx, t1
		shr ecx, 8
		shr ecx, 8
		sub cl, 078h
		xor cl, 056h
		and ecx, 000000FFh	
		add edx, ecx
		shl edx, 8
	
	
		mov ecx, t1
		shr ecx, 8
		shr ecx, 8
		shr ecx, 8
		sub cl, 034h
		xor cl, 012h
		and ecx, 000000FFh	
		add edx, ecx
		bswap edx
		mov t1,edx

	}
	wsprintf(arr,"%8X",t1);
	printf("The serial:%s\n",arr);
	return 0;
}
