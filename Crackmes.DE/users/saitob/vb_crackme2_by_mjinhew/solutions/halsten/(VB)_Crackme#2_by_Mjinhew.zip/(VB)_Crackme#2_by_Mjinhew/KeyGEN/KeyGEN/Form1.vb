Imports System.Text
Imports System.Security.Cryptography
Imports System.IO
Imports System.Windows.Forms
Imports Microsoft.VisualBasic.CompilerServices
Imports Microsoft.Win32


Public Class Form1
    Private hash1 As Integer
    Private hash2 As Integer
    Public code As String
    Public lettercode As String


    Private Sub btnGenerate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGenerate.Click
        Dim str As String = CStr(xatu(CStr(hash1), CStr(hash2)))
        Dim plaintext As String = CStr(MD5(CStr(getID()))).Substring(5, 8)
        plaintext = CStr(SHA512(plaintext))
        plaintext = CStr(modify(CStr(MD5((plaintext & str))).Substring(8, &H10)))
        plaintext = CStr(RIP(plaintext))

        txtSerial.Text = plaintext
        txtUsername.Text = CStr(getID()).Replace("-", "")
    End Sub

    Private Sub btnAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAbout.Click
        MsgBox("halsten (C) 2007", MsgBoxStyle.Information)
    End Sub

    Public Shared Function Decrypt(ByVal cipherText As String, ByVal passPhrase As String, ByVal saltValue As String, ByVal hashAlgorithm As String, ByVal passwordIterations As Integer, ByVal initVector As String, ByVal keySize As Integer) As String
        Dim bytes As Byte() = Encoding.ASCII.GetBytes(initVector)
        Dim rgbSalt As Byte() = Encoding.ASCII.GetBytes(saltValue)
        Dim buffer As Byte() = Convert.FromBase64String(cipherText)
        Dim rgbKey As Byte() = New PasswordDeriveBytes(passPhrase, rgbSalt, hashAlgorithm, passwordIterations).GetBytes(CInt(Math.Round(CDbl((CDbl(keySize) / 8)))))
        Dim managed As New RijndaelManaged
        managed.Mode = CipherMode.CBC
        Dim transform As ICryptoTransform = managed.CreateDecryptor(rgbKey, bytes)
        Dim stream2 As New MemoryStream(buffer)
        Dim stream As New CryptoStream(stream2, transform, CryptoStreamMode.Read)
        Dim buffer4 As Byte() = New Byte((buffer.Length + 1) - 1) {}
        Dim count As Integer = stream.Read(buffer4, 0, buffer4.Length)
        stream2.Close()
        stream.Close()
        Return Encoding.UTF8.GetString(buffer4, 0, count)
    End Function

    Public Shared Function Encrypt(ByVal plainText As String, ByVal passPhrase As String, ByVal saltValue As String, ByVal hashAlgorithm As String, ByVal passwordIterations As Integer, ByVal initVector As String, ByVal keySize As Integer) As String
        Dim bytes As Byte() = Encoding.ASCII.GetBytes(initVector)
        Dim rgbSalt As Byte() = Encoding.ASCII.GetBytes(saltValue)
        Dim buffer4 As Byte() = Encoding.UTF8.GetBytes(plainText)
        Dim rgbKey As Byte() = New PasswordDeriveBytes(passPhrase, rgbSalt, hashAlgorithm, passwordIterations).GetBytes(CInt(Math.Round(CDbl((CDbl(keySize) / 8)))))
        Dim managed As New RijndaelManaged
        managed.Mode = CipherMode.CBC
        Dim transform As ICryptoTransform = managed.CreateEncryptor(rgbKey, bytes)
        Dim stream2 As New MemoryStream
        Dim stream As New CryptoStream(stream2, transform, CryptoStreamMode.Write)
        stream.Write(buffer4, 0, buffer4.Length)
        stream.FlushFinalBlock()
        Dim inArray As Byte() = stream2.ToArray
        stream2.Close()
        stream.Close()
        Return Convert.ToBase64String(inArray)
    End Function

    Public Shared Function GenerateCode() As Object
        Dim num3 As Integer
        Dim num4 As Integer
        Dim expression As String = "1234567890"
        Dim str As String = "ZYXWVUTSRQPONMLKJIHGFEDCBA"
        Dim num2 As Integer = 1
        Dim num As Integer = Strings.Len(expression)
        VBMath.Randomize()
        Dim str3 As String = ""
        Dim str4 As String = ""
        Dim num5 As Integer = num2
        num4 = 1
        Do While (num4 <= num5)
            num3 = CInt(Math.Round(CDbl(Conversion.Int(CSng(((num * VBMath.Rnd) + 1.0!))))))
            str3 = (str3 & Strings.Mid(expression, num3, 1))
            num4 += 1
        Loop
        Dim num6 As Integer = num2
        num4 = 1
        Do While (num4 <= num6)
            num3 = CInt(Math.Round(CDbl(Conversion.Int(CSng(((num * VBMath.Rnd) + 1.0!))))))
            str4 = (str4 & Strings.Mid(str, num3, 1))
            num4 += 1
        Loop
        Return (str3 & str4)
    End Function

    Public Function modify(ByVal [text] As String) As Object
        [text] = [text].Insert(4, "-")
        [text] = [text].Insert(9, "+")
        [text] = [text].Insert(14, "*")
        Dim startIndex As Integer = 0
        Dim expression As String = ""
        Dim str As String = ""
        Do While (startIndex < [text].Length)
            expression = [text].Substring(startIndex, 1)
            If Not Versioned.IsNumeric(expression) Then
                str = (str & Strings.Asc(expression).ToString.Substring(0, 1))
            Else
                str = (str & expression)
            End If
            startIndex += 1
        Loop
        Return (str.Insert(2, lettercode) & code)
    End Function

    Public Function xatu(ByVal a As String, ByVal b As String) As Object
        a = (b & a)
        b = CStr(CDbl((CDbl(a) - CDbl(b))))
        Return (a & "-" & b)
    End Function

    Public Function getID() As Object
        Return CStr(Registry.LocalMachine.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\", False).GetValue("ProductId"))
    End Function

    Public Function MD5(ByVal plaintext As String) As Object
        Dim obj2 As Object = New UnicodeEncoding
        Dim provider As New MD5CryptoServiceProvider
        Dim bytes As Byte() = Encoding.UTF8.GetBytes(plaintext)
        Return BitConverter.ToString(provider.ComputeHash(bytes)).Replace("-", Nothing)
    End Function

    Public Function RIP(ByVal plaintext As String) As Object
        Dim obj2 As Object = New UnicodeEncoding
        Dim managed As New RIPEMD160Managed
        Dim bytes As Byte() = Encoding.UTF8.GetBytes(plaintext)
        Return BitConverter.ToString(managed.ComputeHash(bytes)).Replace("-", Nothing).Substring(4, 20)
    End Function

    Public Function SHA512(ByVal plaintext As String) As Object
        Dim obj2 As Object = New UnicodeEncoding
        Dim managed As New SHA512Managed
        Dim bytes As Byte() = Encoding.UTF8.GetBytes(plaintext)
        Return BitConverter.ToString(managed.ComputeHash(bytes))
    End Function

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim obj2 As Object = txtUsername
        Dim obj3 As Object = txtSerial
        hash1 = obj2.GetHashCode
        hash2 = obj3.GetHashCode
        code = CStr(GenerateCode())
        Dim str As String = code.Substring(1, 1)
        code = code.Substring(0, 1)
        lettercode = str
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End
    End Sub
End Class


