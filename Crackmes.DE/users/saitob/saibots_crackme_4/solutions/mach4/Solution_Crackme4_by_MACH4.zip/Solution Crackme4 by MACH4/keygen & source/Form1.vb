Imports Microsoft.VisualBasic.compilerservices   ' for conversions
Imports System.Text                              ' for utf encoding
Imports System.Security.Cryptography             ' for MD5
Imports Microsoft.Win32                          ' for registry key

Public Class Form1

    Private Encoder As UTF8Encoding
    Private EncStringBytes As Byte()
    Private MD5Hasher As MD5CryptoServiceProvider

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim str5 As String
        Dim text As String = Me.TextBox1.Text 'get Name text
        Dim num As Integer = 0
        Dim length As Integer = [text].Length 'get Len(name)
        Dim sourceText As String = ""
        Dim str8 As String = ""
        Dim str9 As String = ""
        Dim str10 As String = ""
        Dim str11 As String = ""
        Dim str As String = ""
        Dim str2 As String = ""
        Dim str3 As String = ""
        Dim str4 As String = ""

        Try                                   'get processor speed
            Dim key2 As RegistryKey = Registry.LocalMachine.OpenSubKey("HARDWARE\DESCRIPTION\SYSTEM\CentralProcessor\0")
            str5 = Conversions.ToString(key2.GetValue("~Mhz"))
            key2.Close()
        Catch exception1 As Exception
            ProjectData.SetProjectError(exception1)
            Dim exception As Exception = exception1
            MessageBox.Show((exception.Message & " Please fix this problem to check your serial."), "Error found")
            ProjectData.ClearProjectError()
            Return
            ProjectData.ClearProjectError()
        End Try

        'convert Name to asc
        Do While (num < length)
            sourceText = (Conversions.ToString(Strings.Asc([text].Chars(num))) & sourceText)
            num += 1
        Loop

        ' Create the serial hash using MD5 and convert to base 64 string
        sourceText = GenerateHash(sourceText)
        'hash1 from asc name
        str = Conversions.ToString(CDbl((((Strings.Asc(sourceText.Substring((sourceText.Length - 15))) - 3) + 4.5) * 2)))
        'hash2 from asc name
        str2 = Conversions.ToString(CDbl((((Strings.Asc(sourceText.Substring((sourceText.Length - 10))) - 4) + 4) * 3)))
        'hash3 from asc name
        str3 = Conversions.ToString(CDbl((((Strings.Asc(sourceText.Substring((sourceText.Length - 20))) - 5) + 11) * 5)))
        'hash4 from asc name and previous hashes
        str4 = Conversions.ToString(CDbl(((Conversions.ToDouble(str5) + (Conversions.ToDouble(str3) - Conversions.ToDouble(str))) - 1000)))
        ' Insert some "_" into str4 hash
        sourceText = sourceText.Insert(4, ("-" & str2 & "-")).Insert(&H10, "-").Insert(&H19, ("-" & str3 & "-"))
        sourceText = sourceText.Insert(30, Conversions.ToString(sourceText.Length)).Insert(13, ("-" & str4 & "-"))
        ' extract sections of final sourceText hash
        str8 = sourceText.Substring(0, 9)
        str9 = sourceText.Substring(9, 9)
        str10 = sourceText.Substring(&H12, 8)
        str11 = sourceText.Substring(&H1A, (sourceText.Length - &H1A))
        ' add the resulting strings together
        Me.TextBox2.Text = (str8 & str9 & str11 & str10) ' Show serial

        str = Nothing     'zero registers
        str2 = Nothing
        str3 = Nothing
        str4 = Nothing
        sourceText = Nothing
        str5 = Nothing

    End Sub

    Public Function Encrypt(ByVal EncString As String) As String
        Dim random As New Random
        Dim str4 As String = ""
        Do While (str4.Length <= 3)
            str4 = (str4 & Conversions.ToString(random.Next(0, 9)))
        Loop
        Me.EncStringBytes = Me.Encoder.GetBytes((EncString & str4))
        Me.EncStringBytes = Me.MD5Hasher.ComputeHash(Me.EncStringBytes)
        Dim str2 As String = BitConverter.ToString(Me.EncStringBytes).Replace("-", Nothing)
        Dim str3 As String = Conversions.ToString(random.Next(4, str2.Length))
        str2 = str2.Insert(Conversions.ToInteger(str3), str4)
        If (Conversions.ToDouble(str3) < 10) Then
            str3 = ("0" & str3)
        End If
        Return str2.Insert(3, str3)
    End Function


    Public Function GenerateHash(ByVal SourceText As String) As String
        Dim bytes As Byte() = New UnicodeEncoding().GetBytes(SourceText)
        Dim provider As New MD5CryptoServiceProvider
        Return Convert.ToBase64String(provider.ComputeHash(bytes))
    End Function

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        MsgBox("Solution to Saibot's Crackme4 --- MACH4")
    End Sub
End Class
