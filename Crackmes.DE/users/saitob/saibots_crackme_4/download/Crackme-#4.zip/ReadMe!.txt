Well hello again! So I've been looking at some crackme's on this site and I came up with (well I hope) a little treat.
So let's get to the point!

Mission objectives:
-Find a valid serial
-Make a KeyGen
-And as always; Have fun! ;D

Rules:
-No patching

~ Enjoy