==============ABOUT==============
NAME. . . . . . : CD Key Check
LANGUAGE. . . . : Visual Basic 6.0
COMPILER OPTIONS: Compile to Native Code, No Optimization
MADE BY . . . . : Mjinhew (username saitob)
ANTI-DEBUG TRIX : None
PROTECTION. . . : Your job to find out
=================================

==============PLOT===============
Bob has been working all day long and on the way home from work he bought himself 
a nice software that he has been waiting for a while.
Glad and exited he runs home, turns on his computer, inserts the CD and runs the Setup.
The installation goes smoth and everything looks fine. He runs the program, but he gets
a prompt asking for a CD-Key, saying you'll find the CD Key on the back of your manual.

Well this is nothing unusual Bob thinks for himself while he looks on the back of his Manual.
But he can't find any serial or CD key. There is nothing there.
Frustrated, tierd and a bit angry, Bob decides to drive back to the store to get his money back.

So he goes out, gets into his car, only to discover that is left back wheel is flat.

Bob can feel that the anger is building up inside of him and that he must try out the new software
or else his whole day will be ruined.

As a last way out of this whole mess, Bob takes up his phone and calls his best friend, you. He
knows how skilled you are in cracking software and he beggs you to help him. And as the kind-hearted
person you are, you accept and decides to help Bob.

So now Bob's day lies in your hands and it's your job to help Bob out of this horrible situation.

- May the force be with you - 
=================================

==============RULES==============
NO PATHCING
NO SELFKEYGENING
NO BRUTEFORCING

Make a keygen that will make as many serials Bob may want and a tutorial that will explain Bob
how you cracked the program. You see, Bob want's to learn things to.
And upload your solution to hxxp://www.crackmes.de so that other may learn as much as Bob.
Then there is only one more thing left to do and that is to lean back, put your legs on your table
and smile, knowing that you have saved the day to your very best friend.
=================================