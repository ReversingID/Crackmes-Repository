CrackMe 1.0
Difficulty level = Very easy

Objectives:
- Find the valid activation serial
- Everything is allowed
- Enjoy!

Other notes:
If you are new to this shit you should start by getting an hex-editor. You can find allot of useful tools here:
http://freakwolfe.cheezyfilms.com/tools.html
(Site credit: Freakwolfe)

Open the program in the hex-editor and look after something that may come in handy! :)


Hope you liked it as much as I like all the other challenges!

~ Saitob 2007