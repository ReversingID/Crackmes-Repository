Mjinhew's keygenme #1
Written in VB6 ~ 07/08/07
Level: Don't know really, but would say a 3/10

What to do:
Simply make a keygen that works for every name

What NOT to do:
Patching
Self keygen
etc

Hint: Smartcheck may display a lot of shit, and shit it may be! 

Submit your solution to Crackmes.de or send it to tobberg@gmail.com