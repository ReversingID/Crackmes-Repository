Name: Atra
Language: C/C++
Difficulty: 2-3 / 10

Your job is to make a keygen that will generate some random, valid serials.

Selfkeygen, pathing, etc is not allowed (Patching is not allowed only if it affects the algo).

This is my first crackme made in C++, I used MFC as a tool.

Please submit a tutorial if you compleate the crackme.

Best of Regards;
	Mjinhew.