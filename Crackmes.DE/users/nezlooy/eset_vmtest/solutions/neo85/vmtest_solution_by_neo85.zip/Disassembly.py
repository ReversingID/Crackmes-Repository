STACK_SIZE = 1024
ERROR_CODE = "*** ERROR ERROR ERROR ***"
#####################################################################
class StackVM:
    # -------------------------------------
    
    
    # -------------------------------------
    def __init__(self):
        # Constructor
        self.pc = 0
        self.ins = [
            0x19, 0x19, 0x01, 0x31, 0x09, 0x01, 0x19, 0x11, 0x06, 0x31, 0x11, 0x04, 0x10, 0x0F, 0x19, 0x01, 
            0x31, 0x1E, 0x2B, 0x12, 0x1C, 0x0A, 0x04, 0x10, 0x04, 0x2B, 0x07, 0x19, 0x31, 0x14, 0x04, 0x27, 
            0x07, 0x19, 0x32, 0x0A, 0x04, 0x5E, 0x07, 0x35, 0x2B, 0x12, 0x1C, 0x5E, 0x12, 0x1C, 0x38, 0x5E, 
            0x12, 0x1C, 0x14, 0x3D, 0x07, 0x34, 0x2B, 0x12, 0x1C, 0x5E, 0x12, 0x1C, 0x34, 0x14, 0x60, 0x07, 
            0x19, 0x01, 0x60, 0x12, 0x1B, 0x0F, 0x04, 0x19, 0x01, 0x24, 0x07, 0x60, 0x12, 0x24, 0x12, 0x1E, 
            0x7D, 0x07, 0x24, 0x12, 0x18, 0x5E, 0x12, 0x1C, 0x24, 0x12, 0x03, 0x3D, 0x12, 0x0E, 0x24, 0x12, 
            0x1F, 0x09, 0x01, 0x19, 0x24, 0x12, 0x1A, 0x7D, 0x12, 0x18, 0x03, 0x17, 0x04, 0x10, 0x0F, 0x19, 
            0x34, 0x2B, 0x12, 0x1C, 0x5E, 0x12, 0x1C, 0x33, 0x2B, 0x12, 0x1C, 0x1E, 0x17, 0x04, 0x10, 0x31, 
            0x14, 0x04, 0x08, 0x04, 0x7B, 0x07, 0x30, 0x7B, 0x12, 0x1C, 0x00, 0x00, 0x8A, 0xA7, 0x88, 0xAB, 
            0x44, 0xD3, 0xCC, 0xCD, 0xE8, 0xEF, 0x4A, 0xF9, 0xD2, 0xE7, 0x4E, 0xE9, 0xD2, 0xDD, 0xD8, 0x53, 
            0xFA, 0xC5, 0xC4, 0xCF, 0xD2, 0x59, 0xF4, 0xC5, 0xF8, 0xCB, 0xCC, 0xC3, 0xEE, 0x79, 0x62, 0xC3, 
            0xFC, 0xE7, 0xD4, 0xF5, 0xF4, 0xE7, 0x72, 0x6B, 0xEE, 0xF1, 0xE6, 0x6F, 0xEA, 0xEF, 0xD6, 0xF9, 
            0x68, 0x00, 0x00, 0x00, 
        ]
        self.stack = [0] * (STACK_SIZE + 5)
        self.sp = 0
    # -------------------------------------
    def print_ins(self, ins, data = ""):
        print "%04x\t%02x \t%s\t%s" %(self.pc, self.ins[self.pc], ins, data)
    # -------------------------------------
        

#####################################################################
def Disasm_00(stackVM):
    stackVM.print_ins("dup")

def Disasm_01(stackVM):
    raise "Invalid Exception"

def Disasm_02(stackVM):
    stackVM.print_ins("xor")

def Disasm_03(stackVM):
    stackVM.print_ins("brc_s")
    
def Disasm_04(stackVM):
    stackVM.print_ins("and")
  
def Disasm_05(stackVM):
    stackVM.print_ins("pop")
    
def Disasm_06(stackVM):    
    stackVM.print_ins("pop", "[mem], sp[0]\t[mem] = sp[0]")

def Disasm_07(stackVM):
    stackVM.print_ins("brc_2")
    
def Disasm_08(stackVM):
    stackVM.print_ins("equ")

def Disasm_09(stackVM):
    stackVM.print_ins("imul")
       
def Disasm_11(stackVM):
    stackVM.print_ins("or")

def Disasm_12(stackVM):
    stackVM.print_ins("neg")

def Disasm_13(stackVM):
    stackVM.print_ins("imod")

def Disasm_14(stackVM):
    stackVM.print_ins("not")

def Disasm_15(stackVM):
    stackVM.print_ins("je", "sp[0]")
    
def Disasm_16(stackVM):
    stackVM.print_ins("swap")
        
def Disasm_17(stackVM):
    stackVM.print_ins("mov", "[sp], [mem]")
    
def Disasm_18(stackVM):
    stackVM.print_ins("idiv")
    
def Disasm_19(stackVM):
    stackVM.print_ins("add")
    
def Disasm_22(stackVM):
    stackVM.print_ins("save", "output")

def Disasm_23(stackVM):
    stackVM.print_ins("get", "input")
        
def Disasm_24(stackVM):
    #stackVM.print_ins("call", "%04x" %(stackVM.pc + 1))

    pc = stackVM.pc + 1
    counter = 1     
    while counter > 0:
        if stackVM.ins[pc] == 0x19:            
            counter = counter + 1
        elif stackVM.ins[pc] == 4:
            counter = counter - 1            
        pc = pc + 1
    stackVM.print_ins("call", "%04x" %pc)
            

def Disasm_25(stackVM):
    stackVM.print_ins("load", "qword CONST2[x]")
    
def Disasm_26(stackVM):
    stackVM.print_ins("gt")
    
def Disasm_27(stackVM):
    stackVM.print_ins("jmp", "sp[0]")
    
def Disasm_28(stackVM):
    stackVM.print_ins("triswap")

def Disasm_29(stackVM):
    stackVM.print_ins("sub")

def Disasm_30(stackVM):
    stackVM.print_ins("load", "qword CONST1[x]")
                   
#####################################################################
def Disasm_op(stackVM):
    opcode_tbl = [
        [0, Disasm_00],        
        [1, Disasm_01],
        [2, Disasm_02],
        [3, Disasm_03],
        [4, Disasm_04],
        [5, Disasm_05],
        [6, Disasm_06],
        [7, Disasm_07],
        [8, Disasm_08],
        [9, Disasm_09],
        [10, Disasm_01],
        [11, Disasm_11],
        [12, Disasm_12],
        [13, Disasm_13],
        [14, Disasm_14],
        [15, Disasm_15],
        [16, Disasm_16],
        [17, Disasm_17],
        [18, Disasm_18],
        [19, Disasm_19],
        [20, Disasm_01],
        [21, Disasm_01],
        [22, Disasm_22],
        [23, Disasm_23],
        [24, Disasm_24],
        [25, Disasm_25],
        [26, Disasm_26],
        [27, Disasm_27],
        [28, Disasm_28],
        [29, Disasm_29],
        [30, Disasm_30],
    ]
    
    opcode = stackVM.ins[stackVM.pc] - 1
    for op in opcode_tbl:
        if opcode == op[0]:            
            op[1](stackVM)
            return
    
    stackVM.print_ins("Unknown")
        
#####################################################################
# Disassembly
#####################################################################    
def Disasm():
    # Stack
    mem =[3] * 0x34
    mem[0] = mem[1]= 0
    stackVM = StackVM()
     
    # Temporary buffer
    ins1 = "{>%,-+(_$}!=`\\~']<|?*:;^&@"
    
    stackVM.pc = 0 # Program counter
       
    # Start the fetch instruction loop
    while stackVM.ins[stackVM.pc] != 0:
        #if stackVM.pc == 0x84:
        #    print "break"
        ch = chr(stackVM.ins[stackVM.pc])
        opcode = stackVM.ins[stackVM.pc]
        # Fetch instruction
        if (opcode - 0x30) & 0xFF <= 9:
            val = opcode - 0x30      
            if stackVM.ins[stackVM.pc + 1] > 0x30:                
                stop = False
                while not stop:
                    if stackVM.ins[stackVM.pc + 1] > 0x39:
                        break
                    stackVM.pc = stackVM.pc + 1
                    stop = (stackVM.ins[stackVM.pc + 1] >= 0x30)
            stackVM.print_ins("push", "qword %d" %val)
        else:
            try:
                idx = ins1.index(ch)
            except (ValueError):
                idx = -1
                
            if idx >= 0:                
                stackVM.print_ins("push", "mem + %d" %(idx * 2))
            else:
                if opcode - 1 > 0x1E:
                    print ERROR_CODE
                    return
                else:
                    try:
                        Disasm_op(stackVM)
                    except Exception, err:
                        stackVM.print_ins(str(err))
                        return
        stackVM.pc = stackVM.pc + 1
            

#####################################################################
def Main():
    Disasm()
#####################################################################

Main()