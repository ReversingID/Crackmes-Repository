Hi!

This crackme was written as a test-task when applying for a job in a company ESET.

Objective: need to find the key that would decrypted the hidden message.

PS. Message and a key composed of printable characters.
The algorithm is very simple, but the implementation is ... :)

Good luck.

Regards,
nezlooy