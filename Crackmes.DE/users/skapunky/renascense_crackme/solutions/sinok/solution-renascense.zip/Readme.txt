Solution by Sinok, if you don't deal well with the dimensions (1024x768, I use 1280x1024 so it fits my screen) you can change them, use notepad to open skapunky.htm file, edit it.

Enjoy :)
