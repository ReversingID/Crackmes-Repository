Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click


        Dim name As String = TextBox1.Text    
        If (name.Length < 8) Then
            TextBox2.Enabled = False
            TextBox2.Text = ""
            TextBox2.Text = "Name must be 8 character!"
        Else
            TextBox2.Enabled = True

            Dim a As Integer = 0
            Dim first As Integer = 0
            Dim second As Integer = 0
            Dim third As Integer = 0

            For a = 0 To 7
                first += Asc(name(a))
            Next a

            second = Asc(name(0)) * 3
            third = Asc(name(7)) * 5
            TextBox2.Text = "ska" + first.ToString + second.ToString + third.ToString

        End If


    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        End
    End Sub

    Private Sub TextBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.Click
        TextBox1.Text = ""
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBox1.Text = "Enter name..."
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Form2.Show()
    End Sub
End Class
