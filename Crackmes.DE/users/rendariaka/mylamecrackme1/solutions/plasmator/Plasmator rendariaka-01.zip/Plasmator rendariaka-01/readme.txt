This is just a lame crackme I coded on the fly.
I want to see if someone can crack it.

Good Luck

Rendari Aka