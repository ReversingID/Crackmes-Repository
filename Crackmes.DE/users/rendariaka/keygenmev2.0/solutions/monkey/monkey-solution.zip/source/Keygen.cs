using System;
using System.Drawing;
using System.Windows.Forms;
using System.Text;
using System.Security.Cryptography;

namespace Keygen
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.TextBox textBox2;
		
		public MainForm()
		{
			InitializeComponent();
		}
		
		[STAThread]
		public static void Main(string[] args)
		{
			Application.Run(new MainForm());
		}
		
		public string EncryptTripleDES(string sIn)
        {
              TripleDESCryptoServiceProvider provider1 = new TripleDESCryptoServiceProvider();
              MD5CryptoServiceProvider provider2 = new MD5CryptoServiceProvider();
              provider1.Key = provider2.ComputeHash(Encoding.ASCII.GetBytes("KeygenMe2 by Rendari Aka"));
              provider1.Mode = CipherMode.ECB;
              ICryptoTransform transform1 = provider1.CreateEncryptor();
              byte[] buffer1 = Encoding.ASCII.GetBytes(sIn);
              return Convert.ToBase64String(transform1.TransformFinalBlock(buffer1, 0, buffer1.Length));
        }
		
		#region Windows Forms Designer generated code
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent() {
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.button1 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// textBox2
			// 
			this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.textBox2.Location = new System.Drawing.Point(16, 53);
			this.textBox2.Name = "textBox2";
			this.textBox2.ReadOnly = true;
			this.textBox2.Size = new System.Drawing.Size(200, 20);
			this.textBox2.TabIndex = 1;
			this.textBox2.TabStop = false;
			this.textBox2.Text = "";
			// 
			// textBox1
			// 
			this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.textBox1.Location = new System.Drawing.Point(16, 16);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(200, 20);
			this.textBox1.TabIndex = 0;
			this.textBox1.TabStop = false;
			this.textBox1.Text = "monkey/mbe";
			// 
			// button1
			// 
			this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button1.Location = new System.Drawing.Point(80, 88);
			this.button1.Name = "button1";
			this.button1.TabIndex = 2;
			this.button1.TabStop = false;
			this.button1.Text = "Generate";
			this.button1.Click += new System.EventHandler(this.Button1Click);
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(232, 126);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.textBox2);
			this.Controls.Add(this.textBox1);
			this.Name = "MainForm";
			this.Text = "Keygen";
			this.ResumeLayout(false);
		}
		#endregion
		public void Button1Click(object sender, System.EventArgs e)
		{
			textBox2.Text = EncryptTripleDES(textBox1.Text);
		}
		
	}
}
