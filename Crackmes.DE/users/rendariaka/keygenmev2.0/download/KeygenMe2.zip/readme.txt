The objective is to create a functional Keygen.

Good Luck

Rendari Aka