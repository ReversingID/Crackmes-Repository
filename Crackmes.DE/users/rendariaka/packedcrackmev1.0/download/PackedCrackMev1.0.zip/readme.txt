This crackme should be easy to crack, once you've unpacked it...

Objective: Find the serial

Good Luck

Rendari Aka