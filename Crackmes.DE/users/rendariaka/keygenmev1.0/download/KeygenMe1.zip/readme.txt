This is a simple KeygenMe written in vb.net.

Objective: Create a functional Keygen.

Good Luck

Rendari Aka 