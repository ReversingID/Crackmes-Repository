// KG1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

int main(int argc, char* argv[])
{
	long s1, s2;
	printf( "enter any # for serial 1: " );
	scanf( "%i", &s1 );

	s2 = 26906 - s1;
	printf( "serial pair:\nserial 1: %i\nserial 2: %i\n", s1, s2 );
	system( "pause" );
	return 0;
}

