My second crackme (as you can tell by the numbers)

As with the first one, no patching, self keygenning, etc, just make a keygen for it.

You won't be able to just rip the assembly code out of this one :)

Good luck!

http://pineware.freehostia.com/