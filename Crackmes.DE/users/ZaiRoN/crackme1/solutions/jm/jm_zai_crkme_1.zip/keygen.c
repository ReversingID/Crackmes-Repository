/*

 j!m's keygen for ZaiRoN first crackme

 the second part of this crackme is very fun and tricky!
 good work ZaiRoN!!

*/

#include <stdio.h>
#include <conio.h>
#include <string.h>

void main() {
	unsigned int i,j,k;
	struct {
		unsigned int x;
		unsigned int y;
	} table[19];

	char name[32];
	char serial[19];
	char conv[15] = "0123456789ABCDE";

	/* 
	
	each ascii character C must be written in the form 
        C = k * 14 + r
	
	and then we have to find x and y such that
	f(x,y) = x + 3y + y^2 + x^2 + 2xy = 2k
	
	to do this we compute f(x,y) for 0<=x<=9 and 0<=y<=9
	if the result is even and <=36 (C max value = 255 so max(C/14) = 18) it means that we have found a valid couple (x,y)

	*/


	for (i=0; i<9; i++) {
		for (j=0; j<9; j++) {

			k = i+3*j+j*j+i*i+2*i*j;

			if (~(k & 0x1) && (k <= 36)) {

				/*
				the following line permits to verify that we have found a couple (x,y) for each value of
				k (0<= k <=18)
				*/

				//printf("\nfound f(%i,%i) = 2*%i",i,j,k/2);

				k >>=1;			//divide by 2
				table[k].x = i;		//put right x & y
				table[k].y = j;
			}
		}
	}

	printf("\nEnter your name (3 chars at least):");
	gets(name);

	if ( strlen(name) >= 3 ) {
		for (i=0; i<3; i++) {

			j = name[i];	//get ascii value C
			k = j;
			j = j/14;	//divide C by 14, this gives the target k computed above
			
			serial[i*3] = conv[ table[j].x ];
			serial[i*3 + 1] = conv[ table[j].y ]; //recover x and y
			serial[i*3 + 2] = conv [ k % 14 ]; //rest r 

			/*
			 the same thing but in reverse order!
			*/
			serial[17 - i*3] = serial[i*3];
			serial[16 - i*3] = serial[i*3 + 1];
			serial[15 - i*3] = serial[i*3 + 2];
		}
		serial[18] = '\0';
		printf("\nvalid serial = %s",serial);
		printf("\npress any key to quit..");
		getch();
	} else {
		printf("\ninvalid length, must be >= 3");
	}
	exit();
}