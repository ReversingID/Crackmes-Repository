crackme #1
-----------
features:
it's a classical crackme: if you find a right name/serial combination, a messagebox appear...

level:	
impossible!...i'm joking:)) 
sorry but i'm not able to give it a number; the ideas behind the crackme are very stupid so i don't think it's a difficult crackme;)

rules:
- NO pacthing
- NO brute forcing
- keygen it! 

finals:
send tutorial+keygen, questions, comments, bugs to zaironcrk@hotmail.com
also send the solution to the crackme site

thanks & greets to:
A.T. , my friends and you...

have fun!

	ZaiRoN

