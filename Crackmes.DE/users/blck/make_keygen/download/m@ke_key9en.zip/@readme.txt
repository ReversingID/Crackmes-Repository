Hi!
Your duty : Just make a keygen :)