#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
	
	
	char name[199],serial[199];
	int len,i;
	printf("*********************************************\n");
	printf("*** Keygen for Bl@ck's KeygenMe by br0ken ***\n");
	printf("*********************************************\n");
        start:printf("\n\nName (2 or more chars) = ");
	scanf("%s",name);
	len=strlen(name);
	if(len <2)
	{
		printf("\n\nUmm, you need to enter 2 or more chars :P\nPress any key to try again");
		getch();
		goto start;
        }           
	printf("\n\nSerial = ");
	i=0;
	do
	{
		serial[i] = name[i] - 4;
                serial[i+1] = name[i+1] + 6;
		serial[i+2] = name[i+2] + 1;
		serial[i+3] = name[i+3] + 7;
		serial[i+4] = name[i+4];
		serial[i+5] = name[i+5] + 2;
		i=i+6;
	}
        while(i<=len);
	serial[len]='\0';
        printf("%s\n",serial);
        getch();
}