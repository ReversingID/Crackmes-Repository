#!/usr/bin/env python
# -*- coding: utf8 -*-
#
# Keygen for:
# keygenme#1 by tamaroth
#
# Miguel
# 23.10.2010
#
#Funny keygenme by tamaroth
#The interesting part is the serial chars to numbers conversion or vice versa and
#to recognize the mathematical function used for the final comparison.
#
#The keygenme asks us for a user name (our system user name by default) and
#the corresponding serial.
#The serial is checked every time we input a new serial char.
#
#The general behaviour is:
#
#Get the user name.
#The length must be > 3 (but the keygenme doesn't warns us about that).
#It calculates two numbers from user name chars and store them.
#
#00401EF7  |.  68 FF000000               PUSH 0FF                                           ; /Count = FF (255.)
#00401EFC  |.  8D4424 58                 LEA EAX,DWORD PTR SS:[ESP+58]                      ; |
#00401F00  |.  50                        PUSH EAX                                           ; |Buffer
#00401F01  |.  68 E8030000               PUSH 3E8                                           ; |ControlID = 3E8 (1000.)
#00401F06  |.  56                        PUSH ESI                                           ; |hWnd
#00401F07  |.  FFD7                      CALL EDI                                           ; \GetDlgItemTextA
#00401F09  |.  85C0                      TEST EAX,EAX
#00401F0B  |.  0F84 F9000000             JE <bad_length>
#00401F11  |.  83F8 04                   CMP EAX,4                                          ;  user length > 3
#00401F14  |.  0F8C F0000000             JL <bad_length>
#00401F1A  |.  8D4C24 54                 LEA ECX,DWORD PTR SS:[ESP+54]                      ;  user name
#00401F1E  |.  E8 2DFCFFFF               CALL <first_number>
#00401F23  |.  DD5C24 14                 FSTP QWORD PTR SS:[ESP+14]
#00401F27  |.  8D4C24 54                 LEA ECX,DWORD PTR SS:[ESP+54]
#00401F2B  |.  E8 20FDFFFF               CALL <second_number>
#00401F30  |.  DD5C24 0C                 FSTP QWORD PTR SS:[ESP+C]
#
#You can see the algorithm used in my keygen.
#
#Then it gets the serial.
#The length must be > 3.
#The serial is transformed at 0x401F83.
#This algorithm divides the serial in chunks of 4 chars and for each char it gets its position into the charset:
#"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
#The 4 positions (abcd) are used to calculate 3 numbers using this generators:
#     n1 = ((a * 4) % 0x100) + ((b >> 4) & 0x3)
#     n2 = ((c >> 2) & 0xf) ^ ((b << 4) % 0x100)
#     n3 = ((c << 6) % 0x100) + d
#
#0040116F   .  8B4C24 14                 MOV ECX,DWORD PTR SS:[ESP+14]                      ;  load into ecx char positions
#00401173   .  8AD1                      MOV DL,CL                                          ;  a
#00401175   .  02D2                      ADD DL,DL                                          ;  (a * 2) % 0x100
#00401177   .  02D2                      ADD DL,DL                                          ;  (a * 4) % 0x100
#00401179   .  8AC5                      MOV AL,CH                                          ;  b
#0040117B   .  C0E8 04                   SHR AL,4                                           ;  b >> 4
#0040117E   .  24 03                     AND AL,3                                           ;  b >> 4 & 0x03
#00401180   .  02C2                      ADD AL,DL                                          ;  ((a * 4) % 0x100) + ((b >> 4) & 0x03)
#00401182   .  884424 18                 MOV BYTE PTR SS:[ESP+18],AL                        ;  store n1
#00401186   .  8A4424 16                 MOV AL,BYTE PTR SS:[ESP+16]                        ;  c
#0040118A   .  8AD0                      MOV DL,AL                                          ;  c
#0040118C   .  C0EA 02                   SHR DL,2                                           ;  c >> 2
#0040118F   .  8ACD                      MOV CL,CH                                          ;  b
#00401191   .  80E2 0F                   AND DL,0F                                          ;  (c >> 2) & 0xf
#00401194   .  C0E1 04                   SHL CL,4                                           ;  (b << 4) % 0x100
#00401197   .  C0E0 06                   SHL AL,6                                           ;  (c << 6) % 0x100
#0040119A   .  024424 17                 ADD AL,BYTE PTR SS:[ESP+17]                        ;  ((c << 6) % 0x100)  + d
#0040119E   .  32D1                      XOR DL,CL                                          ;  ((c >> 2) & 0xf) ^ ((b << 4) % 0x100)
#004011A0   .  33ED                      XOR EBP,EBP                                        ;  store n2
#004011A2   .  885424 19                 MOV BYTE PTR SS:[ESP+19],DL                        ;  store n3
#004011A6   .  884424 1A                 MOV BYTE PTR SS:[ESP+1A],AL
#
#The resulting 3 chars in length string is concatenated with the previous ones.
#Next step is to validate this new string at 0x401F91
#Valid chars are: '|', '-', '.' and numbers from '0' to '9'
#
#00401A75  |> /8A0419                    /MOV AL,BYTE PTR DS:[ECX+EBX]
#00401A78  |. |3C 7C                     |CMP AL,7C                                         ;  '|'
#00401A7A  |. |75 03                     |JNZ SHORT 00401A7F
#00401A7C  |. |46                        |INC ESI
#00401A7D  |. |EB 18                     |JMP SHORT 00401A97
#00401A7F  |> |3C 2D                     |CMP AL,2D                                         ;  '-'
#00401A81  |. |74 14                     |JE SHORT 00401A97
#00401A83  |. |3C 2E                     |CMP AL,2E                                         ;  '.'
#00401A85  |. |74 10                     |JE SHORT 00401A97
#00401A87  |. |3C 30                     |CMP AL,30                                         ;  '0'
#00401A89  |. |0F8C A7000000             |JL <bad>
#00401A8F  |. |3C 39                     |CMP AL,39                                         ;  '9'
#00401A91  |. |0F8F 9F000000             |JG <bad>
#00401A97  |> |41                        |INC ECX
#00401A98  |. |3BCD                      |CMP ECX,EBP
#00401A9A  |.^\7C D9                     \JL SHORT 00401A75
#00401A9C  |.  83FE 01                   CMP ESI,1                                          ;  must be an unique | char
#00401A9F  |.  0F85 91000000             JNZ <bad>
#
#If the chars are ok then it checks if the string adapts to this pattern: n1|n2
#where n1 and n2 are numbers formed with '-','.', and '0' to '9' chars and separated with an unique '|' char
#If so, then it loads each number into the fpu and stores them for later use and sets AL to 1 to indicate succeed.
#
#00401AC3  |> /803C1E 7C                 /CMP BYTE PTR DS:[ESI+EBX],7C                      ;  '|'
#00401AC7  |. |75 23                     |JNZ SHORT 00401AEC
#00401AC9  |. |8D4C24 0C                 |LEA ECX,DWORD PTR SS:[ESP+C]
#00401ACD  |. |51                        |PUSH ECX
#00401ACE  |. |E8 98120000               |CALL <load_number>
#00401AD3  |. |DD1F                      |FSTP QWORD PTR DS:[EDI]
#00401AD5  |. |6A 32                     |PUSH 32
#00401AD7  |. |8D5424 14                 |LEA EDX,DWORD PTR SS:[ESP+14]
#00401ADB  |. |6A 00                     |PUSH 0
#00401ADD  |. |52                        |PUSH EDX
#00401ADE  |. |83C7 08                   |ADD EDI,8
#00401AE1  |. |E8 9A1C0000               |CALL 00403780
#00401AE6  |. |83C4 10                   |ADD ESP,10
#00401AE9  |. |46                        |INC ESI
#00401AEA  |. |33C0                      |XOR EAX,EAX
#00401AEC  |> |8A0C1E                    |MOV CL,BYTE PTR DS:[ESI+EBX]
#00401AEF  |. |84C9                      |TEST CL,CL
#00401AF1  |. |75 25                     |JNZ SHORT 00401B18
#00401AF3  |. |8D4424 0C                 |LEA EAX,DWORD PTR SS:[ESP+C]
#00401AF7  |. |50                        |PUSH EAX
#00401AF8  |. |E8 6E120000               |CALL <load_number>
#00401AFD  |. |DD1F                      |FSTP QWORD PTR DS:[EDI]
#00401AFF  |. |6A 32                     |PUSH 32
#00401B01  |. |8D4C24 14                 |LEA ECX,DWORD PTR SS:[ESP+14]
#00401B05  |. |6A 00                     |PUSH 0
#00401B07  |. |51                        |PUSH ECX
#00401B08  |. |83C7 08                   |ADD EDI,8
#00401B0B  |. |E8 701C0000               |CALL 00403780
#00401B10  |. |83C4 10                   |ADD ESP,10
#00401B13  |. |46                        |INC ESI
#00401B14  |. |33C0                      |XOR EAX,EAX
#00401B16  |. |EB 06                     |JMP SHORT 00401B1E
#00401B18  |> |884C04 0C                 |MOV BYTE PTR SS:[ESP+EAX+C],CL
#00401B1C  |. |40                        |INC EAX
#00401B1D  |. |46                        |INC ESI
#00401B1E  |> |3BF5                      |CMP ESI,EBP
#00401B20  |.^\7E A1                     \JLE SHORT 00401AC3
#00401B22  |.  5F                        POP EDI
#00401B23  |.  5E                        POP ESI
#00401B24  |.  B0 01                     MOV AL,1                                           ;  succeed
#
#Next step is to calculate the expression: e ^ n1
#The function is calculated as a sequence:
#summation from n=0 to 20 of:
#n1^n / n!
#
#00401D60 >/$  D9EE                      FLDZ
#00401D62  |.  83EC 0C                   SUB ESP,0C
#00401D65  |.  DD4424 10                 FLD QWORD PTR SS:[ESP+10]
#00401D69  |.  56                        PUSH ESI
#00401D6A  |.  D9E8                      FLD1
#00401D6C  |.  57                        PUSH EDI
#00401D6D  |.  33FF                      XOR EDI,EDI
#00401D6F  |>  D9C0                      /FLD ST
#00401D71  |.  8BC7                      |MOV EAX,EDI
#00401D73  |.  85FF                      |TEST EDI,EDI
#00401D75  |.  75 06                     |JNZ SHORT 00401D7D
#00401D77  |.  DDD8                      |FSTP ST
#00401D79  |.  D9C0                      |FLD ST
#00401D7B  |.  EB 17                     |JMP SHORT 00401D94
#00401D7D  |>  7D 04                     |JGE SHORT 00401D83
#00401D7F  |.  8BC7                      |MOV EAX,EDI
#00401D81  |.  F7D8                      |NEG EAX
#00401D83  |>  85C0                      |TEST EAX,EAX
#00401D85  |.  74 07                     |JE SHORT 00401D8E
#00401D87  |>  83E8 01                   |/SUB EAX,1
#00401D8A  |.  D8CA                      ||FMUL ST,ST(2)                                    ;  n1 ^ n
#00401D8C  |.^ 75 F9                     |\JNZ SHORT 00401D87
#00401D8E  |>  85FF                      |TEST EDI,EDI
#00401D90  |.  7D 02                     |JGE SHORT 00401D94
#00401D92  |.  D8F9                      |FDIVR ST,ST(1)
#00401D94  |>  33D2                      |XOR EDX,EDX
#00401D96  |.  8BF7                      |MOV ESI,EDI
#00401D98  |.  B8 01000000               |MOV EAX,1
#00401D9D  |.  85FF                      |TEST EDI,EDI
#00401D9F  |.  75 06                     |JNZ SHORT 00401DA7
#00401DA1  |.  895424 0C                 |MOV DWORD PTR SS:[ESP+C],EDX
#00401DA5  |.  EB 13                     |JMP SHORT 00401DBA
#00401DA7  |>  52                        |/PUSH EDX
#00401DA8  |.  50                        ||PUSH EAX
#00401DA9  |.  6A 00                     ||PUSH 0
#00401DAB  |.  56                        ||PUSH ESI
#00401DAC  |.  E8 9F9A0000               ||CALL <mul>                                       ;  n!
#00401DB1  |.  83EE 01                   ||SUB ESI,1
#00401DB4  |.^ 75 F1                     |\JNZ SHORT 00401DA7
#00401DB6  |.  895424 0C                 |MOV DWORD PTR SS:[ESP+C],EDX
#00401DBA  |>  894424 08                 |MOV DWORD PTR SS:[ESP+8],EAX
#00401DBE  |.  DF6C24 08                 |FILD QWORD PTR SS:[ESP+8]
#00401DC2  |.  47                        |INC EDI
#00401DC3  |.  83FF 14                   |CMP EDI,14
#00401DC6  |.  DEF9                      |FDIVP ST(1),ST                                    ;  n1^n / n!
#00401DC8  |.  DEC3                      |FADDP ST(3),ST                                    ;  summation
#00401DCA  |.^ 7E A3                     \JLE SHORT 00401D6F
#
#and then compared with the first of the two numbers calculated from user name.
#They must be equals with a permitted error of 1.0e-14
#
#The final step is to calculate the expression: e ^ -n2
#The function is calculated as a sequence:
#summation from n=0 to 20 of:
#(-1)^n * n2^n / n!
#
#00401DE0 >/$  D9EE                      FLDZ
#00401DE2  |.  83EC 0C                   SUB ESP,0C
#00401DE5  |.  DD4424 10                 FLD QWORD PTR SS:[ESP+10]
#00401DE9  |.  56                        PUSH ESI
#00401DEA  |.  D9E8                      FLD1
#00401DEC  |.  57                        PUSH EDI
#00401DED  |.  DD05 A0FB4000             FLD QWORD PTR DS:[40FBA0]
#00401DF3  |.  33F6                      XOR ESI,ESI
#00401DF5  |>  D9C1                      /FLD ST(1)
#00401DF7  |.  8BC6                      |MOV EAX,ESI
#00401DF9  |.  85F6                      |TEST ESI,ESI
#00401DFB  |.  75 06                     |JNZ SHORT 00401E03
#00401DFD  |.  DDD8                      |FSTP ST
#00401DFF  |.  D9C1                      |FLD ST(1)
#00401E01  |.  EB 17                     |JMP SHORT 00401E1A
#00401E03  |>  7D 04                     |JGE SHORT 00401E09
#00401E05  |.  8BC6                      |MOV EAX,ESI
#00401E07  |.  F7D8                      |NEG EAX
#00401E09  |>  85C0                      |TEST EAX,EAX
#00401E0B  |.  74 07                     |JE SHORT 00401E14
#00401E0D  |>  83E8 01                   |/SUB EAX,1
#00401E10  |.  D8C9                      ||FMUL ST,ST(1)                                    ;  (-1)^n
#00401E12  |.^ 75 F9                     |\JNZ SHORT 00401E0D
#00401E14  |>  85F6                      |TEST ESI,ESI
#00401E16  |.  7D 02                     |JGE SHORT 00401E1A
#00401E18  |.  D8FA                      |FDIVR ST,ST(2)
#00401E1A  |>  33D2                      |XOR EDX,EDX
#00401E1C  |.  8BFE                      |MOV EDI,ESI
#00401E1E  |.  B8 01000000               |MOV EAX,1
#00401E23  |.  85F6                      |TEST ESI,ESI
#00401E25  |.  75 06                     |JNZ SHORT 00401E2D
#00401E27  |.  895424 0C                 |MOV DWORD PTR SS:[ESP+C],EDX
#00401E2B  |.  EB 13                     |JMP SHORT 00401E40
#00401E2D  |>  52                        |/PUSH EDX
#00401E2E  |.  50                        ||PUSH EAX
#00401E2F  |.  6A 00                     ||PUSH 0
#00401E31  |.  57                        ||PUSH EDI
#00401E32  |.  E8 199A0000               ||CALL <mul>                                       ;  n!
#00401E37  |.  83EF 01                   ||SUB EDI,1
#00401E3A  |.^ 75 F1                     |\JNZ SHORT 00401E2D
#00401E3C  |.  895424 0C                 |MOV DWORD PTR SS:[ESP+C],EDX
#00401E40  |>  894424 08                 |MOV DWORD PTR SS:[ESP+8],EAX
#00401E44  |.  D9C2                      |FLD ST(2)
#00401E46  |.  8BC6                      |MOV EAX,ESI
#00401E48  |.  85F6                      |TEST ESI,ESI
#00401E4A  |.  75 06                     |JNZ SHORT 00401E52
#00401E4C  |.  DDD8                      |FSTP ST
#00401E4E  |.  D9C2                      |FLD ST(2)
#00401E50  |.  EB 17                     |JMP SHORT 00401E69
#00401E52  |>  7D 04                     |JGE SHORT 00401E58
#00401E54  |.  8BC6                      |MOV EAX,ESI
#00401E56  |.  F7D8                      |NEG EAX
#00401E58  |>  85C0                      |TEST EAX,EAX
#00401E5A  |.  74 07                     |JE SHORT 00401E63
#00401E5C  |>  83E8 01                   |/SUB EAX,1
#00401E5F  |.  D8CC                      ||FMUL ST,ST(4)                                    ;  n2^n
#00401E61  |.^ 75 F9                     |\JNZ SHORT 00401E5C
#00401E63  |>  85F6                      |TEST ESI,ESI
#00401E65  |.  7D 02                     |JGE SHORT 00401E69
#00401E67  |.  D8FB                      |FDIVR ST,ST(3)
#00401E69  |>  DF6C24 08                 |FILD QWORD PTR SS:[ESP+8]
#00401E6D  |.  46                        |INC ESI
#00401E6E  |.  83FE 14                   |CMP ESI,14
#00401E71  |.  DEFA                      |FDIVP ST(2),ST                                    ;  n2^n / n!
#00401E73  |.  DEC9                      |FMULP ST(1),ST                                    ;  (-1)^n * n2^n / n!
#00401E75  |.  DEC4                      |FADDP ST(4),ST                                    ;  summation
#00401E77  |.^ 0F8E 78FFFFFF             \JLE 00401DF5
#
#and then compared with the second of the two numbers calculated from user name.
#Again, they must be equals with a permitted error of 1.0e-14
#
#If all is ok you'll see the "Good Job!" message.
#
#This is the main serial check routine:
#
#00401F34  |.  68 FF000000               PUSH 0FF
#00401F39  |.  8D4C24 58                 LEA ECX,DWORD PTR SS:[ESP+58]
#00401F3D  |.  51                        PUSH ECX
#00401F3E  |.  68 E9030000               PUSH 3E9
#00401F43  |.  56                        PUSH ESI
#00401F44  |.  FFD7                      CALL EDI
#00401F46  |.  85C0                      TEST EAX,EAX
#00401F48  |.  0F84 BC000000             JE <bad_length>
#00401F4E  |.  83F8 04                   CMP EAX,4                                          ;  serial length > 3
#00401F51  |.  0F8C B3000000             JL <bad_length>
#00401F57  |.  8D5424 54                 LEA EDX,DWORD PTR SS:[ESP+54]                      ;  serial
#00401F5B  |.  52                        PUSH EDX
#00401F5C  |.  8D4C24 3C                 LEA ECX,DWORD PTR SS:[ESP+3C]
#00401F60  |.  E8 3BF4FFFF               CALL 004013A0
#00401F65  |.  83EC 1C                   SUB ESP,1C
#00401F68  |.  8D4424 54                 LEA EAX,DWORD PTR SS:[ESP+54]
#00401F6C  |.  8BCC                      MOV ECX,ESP
#00401F6E  |.  896424 3C                 MOV DWORD PTR SS:[ESP+3C],ESP
#00401F72  |.  50                        PUSH EAX
#00401F73  |.  C78424 80010000 00000000  MOV DWORD PTR SS:[ESP+180],0
#00401F7E  |.  E8 5DF4FFFF               CALL 004013E0
#00401F83  |.  E8 D8F9FFFF               CALL <convert_serial_to_numbers>                   ;  n1 | n2
#00401F88  |.  83C4 1C                   ADD ESP,1C
#00401F8B  |.  8BD8                      MOV EBX,EAX
#00401F8D  |.  8D4C24 24                 LEA ECX,DWORD PTR SS:[ESP+24]
#00401F91  |.  E8 AAFAFFFF               CALL <check_numbers>
#00401F96  |.  84C0                      TEST AL,AL
#00401F98  |.  74 5E                     JE SHORT <bad_serial>
#00401F9A  |.  DD4424 24                 FLD QWORD PTR SS:[ESP+24]
#00401F9E  |.  83EC 08                   SUB ESP,8
#00401FA1  |.  DD1C24                    FSTP QWORD PTR SS:[ESP]
#00401FA4  |.  E8 B7FDFFFF               CALL <calc_function_1>                             ;  calculate e^(n1)
#00401FA9  |.  DC6C24 1C                 FSUBR QWORD PTR SS:[ESP+1C]                        ;  compare result with first_number
#00401FAD  |.  83C4 08                   ADD ESP,8
#00401FB0  |.  D9E1                      FABS
#00401FB2  |.  DC1D A8FB4000             FCOMP QWORD PTR DS:[40FBA8]                        ;  1.0e-14
#00401FB8  |.  DFE0                      FSTSW AX
#00401FBA  |.  F6C4 05                   TEST AH,5
#00401FBD  |.  7A 39                     JPE SHORT <bad_serial>
#00401FBF  |.  DD4424 2C                 FLD QWORD PTR SS:[ESP+2C]
#00401FC3  |.  83EC 08                   SUB ESP,8
#00401FC6  |.  DD1C24                    FSTP QWORD PTR SS:[ESP]
#00401FC9  |.  E8 12FEFFFF               CALL <calc_function_2>                             ;  calculate e^(- n2)
#00401FCE  |.  DC6C24 14                 FSUBR QWORD PTR SS:[ESP+14]                        ;  compare result with second_number
#00401FD2  |.  83C4 08                   ADD ESP,8
#00401FD5  |.  D9E1                      FABS
#00401FD7  |.  DC1D A8FB4000             FCOMP QWORD PTR DS:[40FBA8]                        ;  1.0e-14
#00401FDD  |.  DFE0                      FSTSW AX
#00401FDF  |.  F6C4 05                   TEST AH,5
#00401FE2  |.  7A 14                     JPE SHORT <bad_serial>
#00401FE4  |.  6A 00                     PUSH 0                                             ; /Style = MB_OK|MB_APPLMODAL
#00401FE6  |.  68 54FB4000               PUSH 0040FB54                                      ; |Title = "Good Job!"
#00401FEB  |.  68 60FB4000               PUSH 0040FB60                                      ; |Text = "YAY! You've done it!"
#00401FF0  |.  6A 00                     PUSH 0                                             ; |hOwner = NULL
#00401FF2  |.  FF15 2CE14000             CALL DWORD PTR DS:[<&USER32.MessageBoxA>]          ; \MessageBoxA
#00401FF8 >|>  53                        PUSH EBX                                           ;  bad serial
#
#The keygenme has two calls to IsDebuggerPresent which checks for the presence of a debugger and terminates the process but
#are never called (?)
#
# Keygen follows...
#
import string, sys, math

# Calculate a number from user name
# Subroutines at:
# 0x401B50 for first number
# 0x401C50 for second number
# into keygenme#1 code
def calc_number_from_user(user,f):
  lu = len(user)
  uhash = 0
  for cu in range(lu):
    t1 = ord(user[cu]) + f
    t2 = ord(user[cu]) - f
    uhash += t1 / t2
  return uhash / (lu + f)

# Get valid pairs of serial chars
# using keygenme#1 generators
# Expressions at:
# 0x40116F
def calc_abcd(n):
  r_ab = []
  r_bc = []
  r_cd = []
  for x in range(0,64):
    for y in range(0,64):
      ab = ((x * 4) % 0x100) + ((y >> 4) & 0x3)
      bc = ((y >> 2) & 0xf) ^ ((x << 4) % 0x100)
      cd = ((x << 6) % 0x100) + y
      if ab == n:
        r_ab.append([charset[x],charset[y]])
      if bc == n:
        r_bc.append([charset[x],charset[y]])
      if cd == n:
        r_cd.append([charset[x],charset[y]])
  return r_ab, r_bc, r_cd

# Calculate 4 chars of serial
# from 3 chars chunk
def calc_chunk(ch):
  a = b = c = d = ""
  for ab in d_ab[ch[0]]:
    # try fixed ab
    a,b = ab
    for bc in d_bc[ch[1]]:
      # b must be equal for both
      if b == bc[0]:
        b,c = bc
        for cd in d_cd[ch[2]]:
          # c must be equal for both
          if c == cd[0]:
            c,d = cd
            return a+b+c+d
  # If no available combination return ERROR
  # this shouldn't happen
  return "ERROR"

# Calc serial from
# compound two numbers: n1|n2
def calc_serial(s):
  serial = ""
  ls = len(s)
  # make 3 chars groups
  for i in range(0,ls,3):
    chunk = s[i:i+3]
    serial += calc_chunk(chunk)
  return serial

# Print valid pairs of serial chars
# for testing purposes
def print_dic(dic):
  indexes = [chr(0x7c),chr(0x2d),chr(0x2e),'0','1','2','3','4','5','6','7','8','9']
  for i in indexes:
    print i,"->",dic[i]
  return

# The charset of valid serial chars
charset = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

# create dictionaries for each valid digit/char
d_ab = {}
d_bc = {}
d_cd = {}
d_ab[chr(0x7c)],d_bc[chr(0x7c)],d_cd[chr(0x7c)] = calc_abcd(0x7c)
d_ab[chr(0x2d)],d_bc[chr(0x2d)],d_cd[chr(0x2d)] = calc_abcd(0x2d)
d_ab[chr(0x2e)],d_bc[chr(0x2e)],d_cd[chr(0x2e)] = calc_abcd(0x2e)
for i in range(0x30,0x3a):
  d_ab[chr(i)],d_bc[chr(i)],d_cd[chr(i)] = calc_abcd(i)

# Input username
username = raw_input('User name: ')

# Calc two numbers from user name
u1 = calc_number_from_user(username,1.0)
u2 = calc_number_from_user(username,2.0)
print "%.14f" % u1,"%.14f" % u2

# First number
# u1 must be equal to e^s1
# with a precision less than 1.0e-14
# s1 = ln(u1)
s1 = "%.14f" % math.log(u1)

# Second number
# u2 must be equal to e^(-s2)
# with a precision less than 1.0e-14
# s2 = ln(1/u2)
s2 = "%.14f" % math.log(1/u2)

# Two numbers must be separated by '|' char
ss = s1 + '|' + s2
# Check if length is a multiple of 3
# due to we need to calculate chunks of 3 chars each
lss = len(ss) % 3
if lss != 0:
  #if it isn't adjust length adding 0s to the right
  ss = ss +  "0" * (3-lss)
# Calculate serial
print ss, calc_serial(ss)
