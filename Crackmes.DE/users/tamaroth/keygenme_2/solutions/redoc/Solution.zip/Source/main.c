#undef UNICODE
#undef _UNICODE
#include <windows.h>
#include <TlHelp32.h>
#include "./MIRACL/miracl.h"

#define APP_NAME		"tamaroth's KeygenMe #2 Keygen"

BOOL ComputeDLP (IN char* szHash, OUT char* szSerial);

HWND g_hCrackmeDlg;

//----------------------------------------
BOOL APIENTRY DllMain (HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
	return TRUE;
}
//----------------------------------------
BOOL GetSerial (unsigned char hash_value[32])
{
	miracl *mip;
	big hash_big, result_big;
	HWND hDlg, hDlgItem;
	char szHash[512]={0}, szSerial[512]={0};

	hDlg = FindWindow (0, APP_NAME);
	if (hDlg == 0) return FALSE;
	hDlgItem = GetDlgItem (hDlg, 1001);	// Textbox_Serial

	// Initialize MIRACL library, only used to convert decimal<->hex
	mip = mirsys (0x500, 0x10);
	if (mip == 0) return FALSE;
	hash_big = mirvar(0); result_big = mirvar(0);
	mip->IOBASE = 16;

	bytes_to_big (32, (char*)hash_value, hash_big);
	cotstr (hash_big, szHash);

	if (ComputeDLP (szHash, szSerial)) {
		mip->IOBASE = 10;
 		cinstr (result_big, szSerial);
		mip->IOBASE = 16;			// convert to hex
		cotstr (result_big, szSerial);
	}
	mirexit ();

	SendMessage (hDlgItem, WM_SETTEXT, 0, (LPARAM)szSerial);	// output serial

	return TRUE;
}
//----------------------------------------
__declspec(dllexport) BOOL ComputeSerial (unsigned char hash_value[32])
{
	BOOL bRet = GetSerial (hash_value);
	if (!bRet)
		MessageBox (0, "Error occured", APP_NAME, 0);
	return bRet;
}