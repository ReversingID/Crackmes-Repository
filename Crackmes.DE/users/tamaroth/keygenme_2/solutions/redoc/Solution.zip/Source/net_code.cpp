#undef UNICODE
#undef _UNICODE
#define _CRT_SECURE_NO_WARNINGS
#include <windows.h>

//----------------------------------------
__inline bool IsNumber (char c)
{
	return (c >= '0' && c <= '9');
}
//----------------------------------------
extern "C" BOOL ComputeDLP (IN char* szHash, OUT char* szSerial)
{
	DWORD dwSize, dwContentLenght;
	int intRet;
	SOCKET s = INVALID_SOCKET;
	char szBuf[1024]={0}, szScript[512]={0};

/*
	POST /xml/calculator.xml HTTP/1.1
	Host: magma.maths.usyd.edu.au
	Accept: application/xml
	Connection: close
	Content-Type: application/x-www-form-urlencoded; charset=UTF-8
	Content-Length: xxx

	N := 0xE7C1D538F09CCC070A63A95B;
	K := GF(N);
	M := K ! 0x841423D9A83309F81F0069AB;
	Y := K ! 0xFINAL_HASH_VALUE;
	X := Log(M, Y);
	X;
*/
	// ...costruct http request

	wsprintf (szScript, "input=N%%20:=%%200xE7C1D538F09CCC070A63A95B;%%0AK%%20:=%%20GF(N);%%0A"
							"M%%20:=%%20K%%20!%%200x841423D9A83309F81F0069AB;%%0AY%%20:=%%20K%%20!%%200x"
							"%s;%%0AX%%20:=%%20Log(M,%%20Y);%%0AX;", szHash);
	dwContentLenght = lstrlen (szScript);
	wsprintf (szBuf, "POST /xml/calculator.xml HTTP/1.1\r\n"
								"Host: magma.maths.usyd.edu.au\r\n"
								"Accept: application/xml\r\n"
								"Connection: close\r\n"
								"Content-Type: application/x-www-form-urlencoded; charset=UTF-8\r\n"
								"Content-Length: %u\r\n\r\n%s\r\n\r\n", dwContentLenght, szScript);

	// starting sockets communication
	WSADATA wsadata;
	if (WSAStartup (0x0002, &wsadata))
		return FALSE;

	hostent *host = gethostbyname ("magma.maths.usyd.edu.au");
	SOCKADDR_IN target;
	target.sin_family = AF_INET;
	target.sin_port = htons (80);	// http
	target.sin_addr.s_addr = *(ULONG*)host->h_addr_list[0];

	s = socket (AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (s == INVALID_SOCKET)
		goto err_handler;

	if (connect (s, (sockaddr*)&target, sizeof(target)))
		goto err_handler;
	// connected, send data
	if ( SOCKET_ERROR == send (s, szBuf, lstrlen(szBuf), 0))
		goto err_handler;
	// receive data
	memset (szBuf, 0, sizeof(szBuf));
	intRet = 0; dwSize = 0;
	do {
		intRet = recv (s, &szBuf[dwSize], sizeof(szBuf)-dwSize-1, 0);
		dwSize += intRet;
	}while ((intRet > 0) && (dwSize < sizeof(szBuf)));
	// clen up sockets
	closesocket (s);
	WSACleanup ();

	// get result from received data
	char *pNum = NULL;
	char *pStart = strstr (szBuf, "<results>");
	if (pStart == NULL) return FALSE;
	pStart += 9;
	char *pEnd = strstr (szBuf, "</results>");
	if (pEnd == NULL) return FALSE;
	*pEnd = 0;

	for ( ; pStart < pEnd; pStart++) {
		if ((pNum == NULL) && IsNumber(*pStart))
			pNum = pStart;
		if ((pNum != NULL) && (!IsNumber(*pStart)))
			{*pStart = 0; break;}
	}

	strcpy (szSerial, pNum);
	return TRUE;

err_handler:
	MessageBeep (MB_ICONEXCLAMATION);
	if (s != INVALID_SOCKET) closesocket (s);
	WSACleanup ();
	return FALSE;
}
