﻿Imports System.Math

Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Floor(10^16 * sin(floor(serial1)) * sin(floor(serial2))) = 0 
        Dim Random As New Random()
        Dim numero As Integer
        Dim n1, n2 As Integer
        'Dim result As Boolean
        n1 = txtn1.Text
        n2 = txtn2.Text
        n2 = 411557987
        'Radianes
        Dim rad As Double
        rad = Atan(1) * 4 / 180
        'n1 = n1 * rad
        'n2 = 411557987
        For i = 1 To 10000
            numero = Random.Next(111111111, 999999999)
            If Floor(10 ^ 16 * Sin(n1) * Sin(n2)) = 0 Then
                'txtn2.Text = numero
                lbln.Text = "Correcto"
                GoTo fin
            End If
            lbln.Text = i
        Next
fin:
        Me.Update()
    End Sub
End Class
