﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtn1 = New System.Windows.Forms.TextBox()
        Me.txtn2 = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.lbln = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'txtn1
        '
        Me.txtn1.Location = New System.Drawing.Point(22, 16)
        Me.txtn1.Name = "txtn1"
        Me.txtn1.Size = New System.Drawing.Size(134, 20)
        Me.txtn1.TabIndex = 0
        Me.txtn1.Text = "245850922"
        '
        'txtn2
        '
        Me.txtn2.Location = New System.Drawing.Point(22, 42)
        Me.txtn2.Name = "txtn2"
        Me.txtn2.Size = New System.Drawing.Size(134, 20)
        Me.txtn2.TabIndex = 1
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(162, 16)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(111, 46)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'lbln
        '
        Me.lbln.AutoSize = True
        Me.lbln.Location = New System.Drawing.Point(19, 65)
        Me.lbln.Name = "lbln"
        Me.lbln.Size = New System.Drawing.Size(58, 13)
        Me.lbln.TabIndex = 3
        Me.lbln.Text = "-----------------"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(297, 153)
        Me.Controls.Add(Me.lbln)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.txtn2)
        Me.Controls.Add(Me.txtn1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtn1 As System.Windows.Forms.TextBox
    Friend WithEvents txtn2 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents lbln As System.Windows.Forms.Label

End Class
