﻿Imports System.Math

Public Class Form1
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        ListView1.Items.Clear()
        Dim ruta As String
        ruta = Application.StartupPath & "\serials.txt"
        Dim TextLine As String
        If System.IO.File.Exists(ruta) = True Then
            Dim objReader As New System.IO.StreamReader(ruta)
            Do While objReader.Peek() <> -1
                TextLine = objReader.ReadLine() & vbNewLine
                ListView1.Items.Add(New ListViewItem(New String() {TextLine}))
            Loop
        Else
            MsgBox("Serials.txt no encontrado")
        End If
    End Sub
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim x1, x2, result As Integer
        For i = 0 To ListView1.Items.Count - 1
            x1 = ListView1.Items.Item(i).Text
            For z = 0 To ListView1.Items.Count - 1
                x2 = ListView1.Items.Item(z).Text
                result = Floor(10 ^ 16 * Sin(x1) * Sin(x2))
                If result = 0 And x1 <> x2 Then
                    ListView2.Items.Add(New ListViewItem(New String() {x1, x2}))
                End If
            Next
        Next
    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        With ListView1
            .View = View.Details
            .FullRowSelect = True
            .MultiSelect = False
            .HideSelection = False
            .LabelEdit = False
            .Columns.Add("Serial", 110)
            '.Columns.Add("x2", 110)
        End With
        With ListView2
            .View = View.Details
            .FullRowSelect = True
            .MultiSelect = False
            .HideSelection = False
            .LabelEdit = False
            .Columns.Add("x1", 110)
            .Columns.Add("x2", 110)
        End With
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ListView1.Items.Clear()
        End
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Try
            Dim ruta As String = Application.StartupPath & "\serials_correctos.txt"
            Dim sw As New System.IO.StreamWriter(ruta, True)
            For i = 0 To ListView2.Items.Count - 1
                sw.WriteLine(ListView2.Items(i).SubItems(0).Text & " - " & ListView2.Items(i).SubItems(1).Text)
            Next
            MsgBox("Serials_correctos.txt guardado correctamente")
            sw.Close()
        Catch ex As Exception
            MsgBox("Error: " & ex.ToString)
        End Try
    End Sub
End Class

'Dim fic As String = ruta
'Dim sw As New System.IO.StreamWriter(fic, True)
''
'Dim seno As Double
'Dim numero As Integer
'Dim Random As New Random()
'If chkalea.Checked = True Then
'    For i = 1 To 5000
'        numero = Random.Next(111111111, 999999999)
'        seno = Sin(CDbl(numero))
'        'ListBox1.Items.Add(numero & " - " & seno)
'        sw.WriteLine(numero & "     -     " & seno)
'        ListView1.Items.Add(New ListViewItem(New String() {numero, seno}))
'        Application.DoEvents()
'    Next i
'Else
'    For i = CUInt(txtn1.Text) To CUInt(txtn2.Text)
'        seno = Sin(CDbl(i))
'        'ListBox1.Items.Add(numero & " - " & seno)
'        'ListView1.Items.Add(New ListViewItem(New String() {i, seno}))
'        'sw.WriteLine(i & "     -     " & seno)
'        If seno.ToString.Contains("E-") Then
'            sw.WriteLine(i & " - " & seno)
'            ListView1.Items.Add(New ListViewItem(New String() {i, seno}))
'            '245850922
'        End If
'        'txtn3.Text = i
'        Application.DoEvents()
'    Next i
'End If
'sw.Close()