﻿using System;
using System.Text;
using System.Windows.Forms;

namespace mikkchlFlamioh
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Text = "* FlamingPoop Keygen *";
            label3.Text = "mikkchl's FlamingPoop Keygen\ndraww @ crackmes.de // 2012";
            button1_Click(null,null);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            make_key();
            encode_serial();
        }

        private void make_key()
        {
            Random rnd = new Random();
            int num2  = rnd.Next(6,10);
            int num3  = rnd.Next(4,6);
            int num4  = rnd.Next(5,10);
            int num7  = rnd.Next(6, 10);
            int num8  = rnd.Next(5,7);
            int num12 = rnd.Next(4,9);
            int num13 = rnd.Next(5,8);
            int num14 = rnd.Next(7,10);
            int num16 = rnd.Next(6,9);
            int num18 = rnd.Next(7, 10);
            int num21 = rnd.Next(5,9);
            int num22 = rnd.Next(5,7);
            StringBuilder sb = new StringBuilder();
            sb.Append((20 - num7 * 2)).Append(num2).Append(num3).Append(num4).Append((27 - num2 * 3))
              .Append((18 - num4 * 2)).Append(num7).Append(num8).Append((29 - num3 * 5)).Append((26 - num8 * 4))
              .Append((29 - num18 * 3)).Append(num12).Append(num13).Append(num14).Append((17 - num12 * 2))
              .Append(num16).Append((26 - num16 * 3)).Append(num18).Append((22 - num14 * 2)).Append((23 - num13 * 3))
              .Append(num21).Append(num22).Append((27 - num22 * 4)).Append((24 - num21 * 3)).Append('5');
            textBox1.Text = sb.ToString();
        }

        private void encode_serial()
        {
            string encser = string.Empty;
            switch (textBox1.Text.Substring(0, 1))
            {
                case "2": //1 W	2 X	3 Y	4 U	5 &	6 ?	7 =	8 B	9 >
                    encser = textBox1.Text.Replace("1", "W").Replace("2", "X").Replace("3", "Y")
                        .Replace("4", "U").Replace("5", "&").Replace("6", "?").Replace("7", "=")
                        .Replace("8", "B").Replace("9", ">"); break;
                case "4": //1 H	2 L	3 T	4 Q	5 )	6 (	7 /	8 *	9 _
                    encser = textBox1.Text.Replace("1", "H").Replace("2", "L").Replace("3", "T")
                        .Replace("4", "Q").Replace("5", ")").Replace("6", "(").Replace("7", "/")
                        .Replace("8", "*").Replace("9", "_"); break;
                case "6": //1 M	2 S	3 C	4 K	5 £	6 $	7 ]	8 [	9 -
                    encser = textBox1.Text.Replace("1", "M").Replace("2", "S").Replace("3", "C")
                        .Replace("4", "K").Replace("5", "£").Replace("6", "$").Replace("7", "]")
                        .Replace("8", "[").Replace("9", "-"); break;
                case "8": //1 E	2 D	3 J	4 I	5 ^	6 '	7 ´	8 |	9 +
                    encser = textBox1.Text.Replace("1", "E").Replace("2", "D").Replace("3", "J")
                        .Replace("4", "I").Replace("5", "^").Replace("6", "'").Replace("7", "´")
                        .Replace("8", "|").Replace("9", "+"); break;
            }
            textBox2.Text = encser;
        }
    }
}
