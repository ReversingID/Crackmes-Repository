// CrackMe 10 by WiteG
// www.witeg.prv.pl, witeg@mail.com

#include <windows.h>
#include "resource.h"
#include "miracl.h"

unsigned char	szName[0x80];
unsigned char	szSNX[0x40];
unsigned char	szSNR[0x40];
unsigned char	szSNS[0x40];
unsigned char	szTag[]= ", you just cracked my 10th crackme.. congrats!";

big secp160r1_a, secp160r1_b, secp160r1_p, secp160r1_n, secp160r1_x, secp160r1_y;

void hashing(unsigned char *dataIn, int lenIn, big hash)
{
	unsigned char h[20];
	sha sh;

	shs_init(&sh);
	for (int i=0;i<lenIn;i++)
		shs_process(&sh,dataIn[i]);

	shs_hash(&sh,h);
	bytes_to_big(20,h,hash);
}

void CheckCode(HWND hDlg)
{
	unsigned long	lName,lSNX,lSNR,lSNS,snLSB,i,j;

	lName = GetDlgItemTextA(hDlg, EDIT_NAME, szName, 0x40);

	lSNX = GetDlgItemTextA(hDlg, EDIT_X, szSNX, 0x40);
	lSNR = GetDlgItemTextA(hDlg, EDIT_R, szSNR, 0x40);
	lSNS = GetDlgItemTextA(hDlg, EDIT_S, szSNS, 0x40);
	
	if	((lName >= 4) && (lSNX != 0) && (lSNR != 0) && (lSNS !=0))
	{
		j=FALSE;

		for(i=0;i<lSNX;i++)
		{
			if ((szSNX[i] < 0x30) || (szSNX[i]>0x46)) j=TRUE;
			if ((szSNX[i] > 0x39) && (szSNX[i]<0x41)) j=TRUE;
		}

		for(i=0;i<lSNR;i++)
		{
			if ((szSNR[i] < 0x30) || (szSNR[i]>0x46)) j=TRUE;
			if ((szSNR[i] > 0x39) && (szSNR[i]<0x41)) j=TRUE;
		}

		for(i=0;i<lSNS;i++)
		{
			if ((szSNS[i] < 0x30) || (szSNS[i]>0x46)) j=TRUE;
			if ((szSNS[i] > 0x39) && (szSNS[i]<0x41)) j=TRUE;
		}

		if (j==FALSE)
		{
			big x=mirvar(0);
			big r=mirvar(0);
			big s=mirvar(0);
			big z=mirvar(0);
			big e1=mirvar(0);
			big e2=mirvar(0);
			big u1=mirvar(0);
			big u2=mirvar(0);

			ecurve_init(secp160r1_a,secp160r1_b,secp160r1_p,MR_PROJECTIVE);

			epoint* pointG = epoint_init();
			epoint* pointH = epoint_init();
			epoint* pointJ = epoint_init();

			epoint_set(secp160r1_x,secp160r1_y,0,pointG);

			hashing(szName, lName, e1);

			lstrcat(szName, szTag);
			lName = lstrlen(szName);

			hashing(szName, lName, e2);

			cinstr(x, szSNX);
			cinstr(r, szSNR);
			cinstr(s, szSNS);

			snLSB = remain(r,2);

			if ((compare(r,secp160r1_n)<0) && (compare(s,secp160r1_n)<0) && (epoint_set(x,x,snLSB, pointH) == TRUE))
			{
				if (point_at_infinity(pointH)==FALSE)
				{
					xgcd(s,secp160r1_n,s,s,s);					// s = s^(-1) mod secp160r1_n

					mad(e1,s,s,secp160r1_n,secp160r1_n,u1);				// u1= s*e1 mod secp160r1_n
					mad(r,s,s,secp160r1_n,secp160r1_n,u2);				// u2= s*r mod secp160r1_n

					ecurve_mult2(u2,pointH,u1,pointG,pointJ);			// J = u1*G + u2*H

					if (point_at_infinity(pointJ)==FALSE)
					{
						epoint_get(pointJ,x,x);					// x = J.x

						if ((compare(x,z)!=0) && (compare(x,r)==0))
						{
							mad(e2,s,s,secp160r1_n,secp160r1_n,u1);		// u1= s*e2 mod secp160r1_n
							mad(r,s,s,secp160r1_n,secp160r1_n,u2);		// u2= s*r mod secp160r1_n
							ecurve_mult2(u2,pointH,u1,pointG,pointJ);	// J = u1*G + u2*H

							if (point_at_infinity(pointJ)==FALSE)
							{
								epoint_get(pointJ,x,x);			// x = J.x

								if ((compare(x,z)!=0) && (compare(x,r)==0))
								{
									MessageBox(hDlg, szName, "Done!", (MB_OK | MB_ICONEXCLAMATION));
								}
							}
						}
					}
				}
			}

			mirkill(x);
			mirkill(r);
			mirkill(s);
			mirkill(z);
			mirkill(e1);
			mirkill(e2);
			mirkill(u1);
			mirkill(u2);

			epoint_free(pointG);
			epoint_free(pointH);
			epoint_free(pointJ);

		}
	}
}

BOOL CALLBACK DlgP (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG :
			SendDlgItemMessageA(hDlg, EDIT_NAME, EM_SETLIMITTEXT, (WPARAM) 0x32, 0);
			SendDlgItemMessageA(hDlg, EDIT_X, EM_SETLIMITTEXT, (WPARAM) 0x32, 0);
			SendDlgItemMessageA(hDlg, EDIT_R, EM_SETLIMITTEXT, (WPARAM) 0x32, 0);
			SendDlgItemMessageA(hDlg, EDIT_S, EM_SETLIMITTEXT, (WPARAM) 0x32, 0);

			miracl *mip;

			mip = mirsys(100,10);
			mip->IOBASE=16;

			secp160r1_a=mirvar(0);
			secp160r1_b=mirvar(0);
			secp160r1_p=mirvar(0);
			secp160r1_n=mirvar(0);
			secp160r1_x=mirvar(0);
			secp160r1_y=mirvar(0);

			cinstr(secp160r1_a, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7FFFFFFC");
			cinstr(secp160r1_b, "1C97BEFC54BD7A8B65ACF89F81D4D4ADC565FA45");
			cinstr(secp160r1_p, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7FFFFFFF");

			cinstr(secp160r1_n, "100000000000000000001F4C8F927AED3CA752257");
			cinstr(secp160r1_x, "4A96B5688EF573284664698968C38BB913CBFC82");
			cinstr(secp160r1_y, "23A628553168947D59DCC912042351377AC5FB32");

			return TRUE;

		case WM_COMMAND :
			switch (LOWORD (wParam))
			{
				case BTN_CHECK :
					CheckCode(hDlg);			
					break;

				case IDCANCEL :
					mirkill(secp160r1_a);
					mirkill(secp160r1_b);
					mirkill(secp160r1_p);
					mirkill(secp160r1_n);
					mirkill(secp160r1_x);
					mirkill(secp160r1_y);

					mirexit();
					EndDialog (hDlg, 0);
					break;
			}
			break;
     }
     return FALSE;
}

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{
	DialogBoxA(hInstance, MAKEINTRESOURCE(DLG_MAIN), 0, DlgP);
	return 0;
}
