static unsigned char tempbuffer[50]={0};
void  wHash(unsigned char *x, unsigned long y, unsigned char *z)
{
	static unsigned long dw1, dw2, dw3, dw4, dw5, dw6;
	__asm
	{
			pushad
			mov  esi, x
			mov  ecx, z
			push ecx
			mov	  ecx, dword ptr ds:[y]
		  


			mov     dword ptr ds:[dw1], ecx
			mov     byte ptr ds:[dw2], 1
			mov     dword ptr ds:[dw3], ecx
			mov     dword ptr ds:[dw4], esp
			mov     dword ptr ds:[dw5], esi
			xor     edx, edx
			xor     ebp, ebp
L010:
			mov     esi, dword ptr ds:[dw5]
			cmp     dword ptr ds:[dw3], 8
			jb L080
			mov     eax, dword ptr ds:[esi]
			mov     ebx, dword ptr ds:[esi+4]
			mov     dword ptr ds:[dw6], 20h
L016:
			mov     ecx, ebp
			mov     edi, eax
			rol     edi, cl
			mov     esp, ebx
			mov     ecx, edx
			shr     ecx, 1Bh
			rol     esp, cl
			add     edi, esp
			mov     esp, ebp
			mov     ecx, eax
			shr     ecx, 1Bh
			rol     esp, cl
			mov     ecx, ebx
			mov     esi, edx
			rol     esi, cl
			add     esi, esp
			xor     edi, esi
			mov     eax, edi
			add     eax, 456C6091h
			xchg    eax, ebx
			xchg    edx, ebx
			xchg    ebp, edx
			mov     ecx, edx
			mov     edi, eax
			rol     edi, cl
			mov     esp, ebx
			mov     ecx, ebp
			shr     ecx, 1Bh
			rol     esp, cl
			xor     edi, esp
			mov     ecx, eax
			mov     esp, edx
			rol     esp, cl
			add     edi, esp
			mov     esp, ebp
			mov     ecx, ebx
			shr     ecx, 1Bh
			rol     esp, cl
			add     edi, esp
			mov     eax, edi
			imul    eax, eax, 0AA7110C3h
			xchg    eax, ebx
			xchg    edx, ebx
			xchg    ebp, edx
			dec     dword ptr ds:[dw6]
			jnz L016
			mov     ecx, ebp
			mov     esp, eax
			rol     esp, cl
			mov     ecx, edx
			shr     ecx, 1Bh
			mov     esi, ebx
			rol     esi, cl
			add     esp, esi
			mov     ecx, eax
			shr     ecx, 1Bh
			rol     edx, cl
			mov     ecx, ebx
			rol     ebp, cl
			xor     ebp, edx
			mov     edx, esp
			sub     dword ptr ds:[dw3], 8
			add     dword ptr ds:[dw5], 8
			jmp L010
L080:
			cmp     byte ptr ds:[dw2], 0
			je L109
			mov     ecx, dword ptr ds:[dw3]
			and     byte ptr ds:[dw2], 0
			mov     dword ptr ds:[dw3], 8
			mov     eax, ecx
			lea	  edi, tempbuffer
			test    eax, eax
			je L094
L089:
			mov     bl, byte ptr ds:[ecx+esi-1]
			mov     byte ptr ds:[ecx+edi-1], bl
			dec     ecx
			jnz L089
			add     edi, eax
L094:
			mov     ecx, dword ptr ds:[dw1]
			mov     dword ptr ds:[edi], ecx
			mov     ecx, eax
			add     edi, 4
			sub     ecx, 4
			neg     ecx
			je L107
			jns L104
			add     dword ptr ds:[dw3], 8
			add     ecx, 8
L104:
			dec     ecx
			mov     byte ptr ds:[ecx+edi], 0FFh
			jnz L104
L107:
			lea	  esi, tempbuffer
			mov     dword ptr ds:[dw5], esi
			jmp L010
L109:
			mov     esp, dword ptr ds:[dw4]
			pop     eax

  
			mov     dword ptr ds:[eax], edx
			mov     dword ptr ds:[eax+4], ebp
			mov     edi, dw1
			xor     eax, eax
			mov     dword ptr ds:[dw1], eax
			mov     dword ptr ds:[dw2], eax
			mov     dword ptr ds:[dw3], eax
			mov     dword ptr ds:[dw4], eax
			mov     dword ptr ds:[dw5], eax
			mov     dword ptr ds:[dw6], eax
			popad
  
	}
}


#define MOD 0xFFFFFFFF;
typedef unsigned __int64 QWORD;

unsigned long mulkey[4] = {0, 0, 0, 0};
unsigned long inv[4] = {0x0DAD4694, 0x06D6A34A, 0x81B5A8D2, 0x281B5A8D};

void mcinv(unsigned long &ax, unsigned long &bx, unsigned long &cx, unsigned long &dx)
{
	unsigned long v[4];

	v[1] = dx ^ bx ^ ax;
	v[3] = dx ^ bx ^ cx;
	v[0] = cx ^ ax ^ bx;
	v[2] = cx ^ ax ^ dx;

	if( !(v[3] & 1))
		v[0] ^= 0x2AAAAAAA;

	if( v[0] & 1)
		v[0] ^= 0x2AAAAAAA;

	for (int i = 0; i < 4; i++)
	{
		v[i] = ((QWORD)inv[i] * v[i]) % MOD;
	}

	ax = v[1];
	bx = v[0];
	cx = v[3];
	dx = v[2];
}

void encrypt_blk(unsigned long *v)
{

	unsigned long temp;
	
	temp = v[0];
	v[0] = v[1];
	v[1] = temp;

	temp = v[2];
	v[2] = v[3];
	v[3] = temp;


	v[0] ^= mulkey[3];
	v[1] ^= mulkey[2]; 
	v[2] ^= mulkey[1];
	v[3] ^= mulkey[0];
	mcinv(v[0],v[1],v[2],v[3]);

	v[0] ^= mulkey[2];
	v[1] ^= mulkey[1]; 
	v[3] ^= mulkey[3];
	v[2] ^= mulkey[0];
	mcinv(v[0],v[1],v[2],v[3]);

	v[0] ^= mulkey[1];
	v[1] ^= mulkey[0]; 
	v[2] ^= mulkey[3];
	v[3] ^= mulkey[2];
	mcinv(v[0],v[1],v[2],v[3]);

	v[0] ^= mulkey[0];
	v[1] ^= mulkey[3]; 
	v[2] ^= mulkey[2];
	v[3] ^= mulkey[1];
	mcinv(v[0],v[1],v[2],v[3]);

	v[0] ^= mulkey[3];
	v[1] ^= mulkey[2]; 
	v[2] ^= mulkey[1];
	v[3] ^= mulkey[0];
	mcinv(v[0],v[1],v[2],v[3]);

	v[0] ^= mulkey[2];
	v[1] ^= mulkey[1]; 
	v[2] ^= mulkey[0];
	v[3] ^= mulkey[3];
	mcinv(v[0],v[1],v[2],v[3]);

	v[0] ^= mulkey[1];
	v[1] ^= mulkey[0]; 
	v[2] ^= mulkey[3];
	v[3] ^= mulkey[2];

	temp = v[0];
	v[0] = v[1];
	v[1] = temp;

	temp = v[2];
	v[2] = v[3];
	v[3] = temp;

}
DWORD bsw(DWORD in)
{
	return (((in & 0x000000FF) << 24)
	+ ((in & 0x0000FF00) << 8)
	+ ((in & 0x00FF0000) >> 8)
	+ ((in & 0xFF000000) >> 24));
}

void Generate(HWND hWnd)
{
	int i;
	mip = mirsys(2048, 16);
	mip->IOBASE = 16;

	big p_, q_, n_, x0_, u_, v_, xp_, xq_, a_, z, xx[3];
	big g, k, p, r, s, x;

	char n2mstr[MAX_PATH];

	unsigned char keys[8] = {0};
	unsigned char hash_buf[512]={0};

	unsigned char temp_out[64], buf[64];
	unsigned long data[8] ={0}, data2[8] ={0}, data3[32]={0};


	char name[50];

	int len = GetDlgItemText(hWnd,IDC_EDIT2,name,50);
	if(len < 6){ return;}
	memcpy(hash_buf,name,len);

	for (i = 0; i < 0x1A; i++)
	{
		wHash(hash_buf,len+i,keys);
		hash_buf[i+len]=keys[0];
		wsprintf(n2mstr+i*2,"%02X",hash_buf[i+len]);
	}

	mulkey[0] = bsw(*(DWORD*)(hash_buf+0x1a+len-4));
	mulkey[1] = bsw(*(DWORD*)(hash_buf+0x1a+len-8));
	mulkey[2] = bsw(*(DWORD*)(hash_buf+0x1a+len-12));
	mulkey[3] = bsw(*(DWORD*)(hash_buf+0x1a+len-16));

	for(i = 0; i < 3; i++){
		xx[i] = mirvar(0);}

	a_ = mirvar(0);
	cinstr(a_, n2mstr);

	p_ = mirvar(0);
	q_ = mirvar(0);

	cinstr(p_, "654DA59F5E1B70B1FE728D2B55BB");
	cinstr(q_, "262EFCE70A313E69AD32ECBB081F");
	n_ = mirvar(0);

	x0_ = mirvar(0);
	u_ = mirvar(0);
	v_ = mirvar(0);

	xp_ = mirvar(0);
	xq_ = mirvar(0);

	z = mirvar(0);
        //Start solve quadratic equation

	for (i = 0; i < 32; i++)
	{
		sqroot(a_, p_, xp_);
		sqroot(a_, q_, xq_);

		if(compare(xp_,z) != 0 && compare(xq_,z) != 0)
			break;
		else
			decr(a_,1,a_);
	}
	multiply(p_, q_, n_);
	xgcd(p_, q_, u_, v_, x0_);

	multiply(u_, p_, u_);
	multiply(u_, xq_, u_);
	multiply(v_, q_, v_);
	multiply(v_, xp_, v_);
	add (u_, v_, x0_);
	power(x0_, 1, n_, xx[0]);
	

	if(compare(xx[0], z) == -1)
		negify(xx[0],xx[0]);

	subtract(u_, v_, xx[1]);

	power(xx[1], 1, n_, xx[1]);
	if(compare(xx[1], z) == -1)
		negify(xx[1],xx[1]);

	subtract(n_, xx[1], xx[2]);

	len = big_to_bytes(32, xx[0], (char*)temp_out, FALSE);

	int j;
	ZeroMemory(buf, 64);
	for (i = len - 1, j = 0; i >= 0; i--, j++)
	{
		buf[j] = temp_out[i];

	}
	memcpy(data2,buf,32);

	cinstr(n_, "1BEBE779447C86DBC870A9ECFE0044893A8A95C1FC350D71DF0DE8B31");
	cinstr(u_, "984390BC304F24B707AE19DC8516C070F935DD82D48AC546263DF011");

	powmod(xx[0],u_,n_,n_);

	len = big_to_bytes(32, n_, (char*)temp_out, FALSE);

	ZeroMemory(buf, 64);
	for (i = len - 1, j = 0; i >= 0; i--, j++)
	{
		buf[j] = temp_out[i];
	}
	memcpy(data,buf,32);
	
	encrypt_blk(data);
	encrypt_blk(data+4);

	encrypt_blk(data2);
	encrypt_blk(data2+4);

	memcpy(data3,data,8*4);
	memcpy(data3+8,data2,8*4);

	wHash((unsigned char*)data3,64,keys);

	wsprintf(n2mstr,"%08X",*(DWORD*)(keys + 4));
	wsprintf(n2mstr+8,"%08X",*(DWORD*)(keys + 0));

	cinstr(a_,n2mstr);

	char test[500];


	g = mirvar(0);
	k = mirvar(0);
	p = mirvar(0);
	r = mirvar(0);
	s = mirvar(0);
	x = mirvar(0);

	irand(GetTickCount());

	cinstr(g, "5");
	cinstr(p, "F31CB7BBDF75FA650113"); //p
	cinstr(x, "F1CB7BBDF75FA6501101");


	incr(z,1,z);
	decr(p,1,p); //p-1


	do{
		bigdig(19,16,k);
		egcd(k,p,u_);
	}while(compare(u_,z)!=0);


	incr(p,1,p);
	powmod(g,k,p,r);
	decr(p,1,p);

	cotstr(r,test);

	if(strlen(test)!=20){
		strrev(test);
		while(strlen(test) < 20){
			strcat(test,"0");
		}
		strrev(test);
	}
		
	ZeroMemory(temp_out,64);
	for(i=18,j=0;i>=0;i-=2,j+=2){
		temp_out[j] = test[i];
		temp_out[j+1] = test[i+1];}


	xgcd(k,p,k,k,k);


	multiply(x,r,x);
	subtract(a_,x,a_);
	multiply(k,a_,k);
	power(k,1,p,s);
	add(s,p,s);

	cotstr(s,test);

	if(strlen(test)!=20){
		strrev(test);
		while(strlen(test) < 20){
			strcat(test,"0");
		}
		strrev(test);
	}
		
	for(i=18,j=0;i>=0;i-=2,j+=2){
		temp_out[20+j] = test[i];
		temp_out[20+j+1] = test[i+1];}

	char string[500];


	for (i = 0; i < 8; i++){
		wsprintf(string+i*8,"%08X",bsw(data[i]));}

	strcat(string,"-");
	len = strlen(string);

	for (i = 0; i < 8; i++){
		wsprintf(string+i*8+len,"%08X",bsw(data2[i]));}
	strcat(string,"-");
	strcat(string,(char*)temp_out);

	mirkill(g);
	mirkill(k);
	mirkill(p);
	mirkill(r);
	mirkill(s);
	mirkill(x);

	mirkill(z);
	mirkill(a_);
	mirkill(p_);
	mirkill(q_);
	mirkill(n_);
	mirkill(x0_);
	mirkill(u_);
	mirkill(v_);
	mirkill(xp_);
	mirkill(xq_);

	for(i = 0; i < 3; i++){
		mirkill(xx[i]);}

	SetDlgItemText(hWnd,IDC_EDIT1,string);
}