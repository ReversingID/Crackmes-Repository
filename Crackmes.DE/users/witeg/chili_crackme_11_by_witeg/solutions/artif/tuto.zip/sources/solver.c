// on impl�mente l'algo de Pollard pour GF(p^3)
// pour comprendre l'algo => Guide to Elliptic Curve Cryptography-Menezes
// et la source de jB sur GF(p)
// Crackme WiteG #11

#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include "miracl.h"

#define ROUND 16

typedef unsigned long DWORD;

typedef struct Poly Poly;

struct Poly
{
    DWORD pBool;
    DWORD poly_x[3];
	DWORD poly_y[3];
};

// on v�rifie si la solution trouv� est bien valide (return 1 si valide)
int verifKey(big s);

// les fonctions tir�s du crackme de witeG
extern void ecurvep_mult(char *k, Poly *P1, Poly *P2);
extern void ecurvep_add2(Poly *P1,Poly *P2);
extern void FieldElementToInt(Poly *P1,char *x_int);

// fonction d'initialisation des polys
void initPolyZero(Poly* p);
void initPolyG(Poly* p);
void initPolyW(Poly* p);

// fonction pour afficher les coeffs du poly (debug purpose)
void printPoly(Poly *p);

// comparaison de poly
int equalPoly(Poly *p1, Poly *p2);

// fonction de copie des polynomes
void copyPoly(Poly *source, Poly *destination);

// compute p3 = a*p1 + b*p2
void ecurvep_mult2(char *a, Poly *p1, char *b, Poly *p2, Poly *p3);

// fonction de gestion de la convention buffer -> bignum du witeG#11
void reverse_byte(unsigned char *strReverse, int nLen);
unsigned char* reverse_byte_bignum(big a);


int main(int argc, char *argv[])
{
	FILE *fp = NULL;
	
	miracl *mip = mirsys(200,0);
	big a[ROUND],b[ROUND];
	big c1,c2,d1,d2,r,xc,s;

	Poly G,W,X,Y;
	Poly *R = NULL;

	unsigned char *strC1 = NULL,*strD1 = NULL, *stra = NULL, *strb = NULL, *x_coord = NULL;
	
	int i,index;

	unsigned long start_time,diff_ms,diff_s,min,hour;

	r = mirvar(0);
	c1 = mirvar(0);
	c2 = mirvar(0);
	d1 = mirvar(0);
	d2 = mirvar(0);
	xc = mirvar(0);
	s = mirvar(0);

	// initialisation d'un tableau de poly
	R = (Poly *) malloc(ROUND * sizeof(Poly));

	
	for(i=0;i<ROUND;i++) {
		a[i] = mirvar(0);
		b[i] = mirvar(0);
		initPolyZero(&R[i]);
	}


	mip->IOBASE=16; // base 16
	cinstr(r,"FFFCCDE18D3CA8AB"); // order

	// initialisation du timer
	start_time = GetTickCount();

	// on initialise notre g�n�rateur al�atoire
	irand(start_time);

	// on g�nere c1 et d1 < r
	bigrand(r,c1);
	bigrand(r,d1);

	strC1 = (unsigned char*) calloc(12,sizeof(unsigned char));
	strD1 = (unsigned char*) calloc(12,sizeof(unsigned char));

	// initialisation des polynomes principaux G et W
	initPolyG(&G);
	initPolyW(&W);
	initPolyZero(&X);

	// convention witeG
	strC1 = reverse_byte_bignum(c1);
	strD1 = reverse_byte_bignum(d1);

	// X = c1*G + d1*W
	ecurvep_mult2(strC1,&G,strD1,&W,&X);

	free(strC1); strC1 = NULL;
	free(strD1); strD1 = NULL;

	// copy X -> Y
	initPolyZero(&Y);
	copyPoly(&X,&Y);

	copy(c1, c2);
	copy(d1, d2);

	// initialisation du tableau a,b et R(poly)
	for(i=0;i<ROUND;i++) {
		bigrand(r,a[i]);
		bigrand(r,b[i]);

		// il faut calculer R[j] = a[i] * G + b[i] * W
		stra = (unsigned char *)malloc(12 * sizeof(unsigned char));
		strb = (unsigned char *)malloc(12 * sizeof(unsigned char));

		stra = reverse_byte_bignum(a[i]);
		strb = reverse_byte_bignum(b[i]);

		// R[i] = a[i] * G + b[i] * W
		ecurvep_mult2(stra,&G,strb,&W,&R[i]);

		// on free tout ca
		free(stra); stra = NULL;
		free(strb); strb = NULL;
	}

	x_coord = (unsigned char *)malloc(16 * sizeof(unsigned char));

	do 
	{

		// get the x coordinate of X
		FieldElementToInt(&X,x_coord);

		// reverse x_coord
		reverse_byte(x_coord,16);
		bytes_to_big(16,x_coord,xc);
		index = remain(xc, ROUND);

		//X = X + R[index]
		ecurvep_add2(&R[index],&X);

		add(c1, a[index], c1);
		add(d1, b[index], d1);
		if(compare(c1, r) >= 0) subtract(c1, r, c1);	
		if(compare(d1, r) >= 0) subtract(d1, r, d1);	

		// on avance de 2 pas : algo du lievre et de la tortue (Floyd)
		for(i=0;i<2;i++) {
			// get the y coordinate
			FieldElementToInt(&Y,x_coord);
			reverse_byte(x_coord,16);
			bytes_to_big(16,x_coord,xc);
			index = remain(xc,ROUND);

			// Y = R[index] + Y
			ecurvep_add2(&R[index],&Y);

			add(c2, a[index], c2);
			if(compare(c2, r) >= 0) subtract(c2, r, c2);

			add(d2, b[index], d2);			
			if(compare(d2, r) >= 0) subtract(d2, r, d2);
		}

	}
	while(!equalPoly(&X,&Y));

	free(x_coord); x_coord = NULL;

	// compute s = (c1 - c2) * (d2 - d1)^(-1) mod r 

	subtract(c1, c2, c1);
	if(size(c1) < 0) add(c1, r, c1);

	subtract(d2, d1, d1);
	if(size(d1) < 0) add(d1, r, d1);

	xgcd(d1, r, d1, d1, d1); 
	mad(c1, d1, d1, r, r, s);

	// conversion ms en sec
	diff_ms = GetTickCount() - start_time; // en ms
	diff_s  = diff_ms / 1000;    // en s

	// nombre d'heures
	hour = (int) (diff_s / 3600);

	// nouvelle difference en seconde
	diff_s = diff_s - hour*3600;

	min = (int) (diff_s / 60);

	
	printf("DLP Solved d=");
	cotnum(s,stdout);
	printf("\n");
	printf("Verification solution %d\n",verifKey(s)); // 1 si valide
	printf("computation time : %luh %lumin\n", hour, min);

	// enregistrement ds un fichier de la solution en cas de plantage
	fp = fopen("dlp.dat","a+");
	cotnum(s,fp);
	fclose(fp);


	free(R);	
	mirkill(r);
	mirkill(c1);
	mirkill(c2);
	mirkill(d1);
	mirkill(d2);
	mirkill(xc);
	mirkill(s);

	for(i=0;i<ROUND;i++) {
		mirkill(a[i]);
		mirkill(b[i]);
	}

	mirexit();
}

// renvoie un nombre de 96bits correspondants au bignum correspondant
unsigned char* reverse_byte_bignum(big a)
{
	unsigned char *tReverse = (unsigned char *)calloc(8,sizeof(unsigned char));

	unsigned char *strReverse = (unsigned char *)calloc(12,sizeof(unsigned char));
	int i, nLen = 0;

	nLen = big_to_bytes(8,a,tReverse,0);

	for(i=0;i<nLen;i++)
		strReverse[i] = tReverse[nLen-i-1];

	free(tReverse); tReverse = NULL;

	return strReverse;

}

void reverse_byte(unsigned char *strReverse, int nLen)
{
	int i;
	unsigned char *tmp = (unsigned char*) malloc(nLen * sizeof(unsigned char));

	for(i=0;i<nLen;i++)
		tmp[i] = strReverse[nLen-i-1];

	for(i=0;i<nLen;i++)
		strReverse[i] = tmp[i];

	free(tmp);
	tmp = NULL;
}


void initPolyW(Poly* p)
{
	p->pBool = 1;

	p->poly_x[0] = 0x1AA1DD;
	p->poly_x[1] = 0x11D935;
	p->poly_x[2] = 0x12CBFC;

	p->poly_y[0] = 0x9C69B;
	p->poly_y[1] = 0x0E91C;
	p->poly_y[2] = 0x5E285;
}

void initPolyG(Poly* p)
{
	p->pBool = 1;
	p->poly_x[0] = 0x272D02;
	p->poly_x[1] = 0x3EE82;
	p->poly_x[2] = 0x62585;

	p->poly_y[0] = 0x112619;
	p->poly_y[1] = 0x1E112A;
	p->poly_y[2] = 0x280082;
}


void initPolyZero(Poly* p)
{
	int i;

	p->pBool = 0;

	for(i=0;i<3;i++) {
		p->poly_x[i] = 0;
		p->poly_y[i] = 0;
	}
}

void printPoly(Poly *p)
{
	int i;
	printf("Boolean : %X\n",p->pBool);

	for(i=0;i<3;i++) 
		printf("%X\n",p->poly_x[i]);

	for(i=0;i<3;i++) 
		printf("%X\n",p->poly_y[i]);
}

void copyPoly(Poly *source, Poly *destination)
{
	int i;

	destination->pBool=source->pBool;

	for(i=0;i<3;i++) {
		destination->poly_x[i]=source->poly_x[i];
		destination->poly_y[i]=source->poly_y[i];
	}
}

int equalPoly(Poly *p1, Poly *p2)
{
	int i;

	if(p1->pBool != p2->pBool) return 0;

	for(i=0;i<3;i++) {
		if(p1->poly_x[i] != p2->poly_x[i]) return 0;
		if(p1->poly_y[i] != p2->poly_y[i]) return 0;
	}

	return 1;
}

// ecurve_mult2(a[j], P, b[j], Q, R[j]);
// R[j] = a[j]*P + b[j]*Q
// coder une fonction similaire
// p3 = a*P1 + b*P2
void ecurvep_mult2(char *a, Poly *p1, char *b, Poly *p2, Poly *p3)
{
	Poly t,x;
	initPolyZero(&t);
	initPolyZero(&x);

	// t = a*p1
	ecurvep_mult(a,p1,&t); 
	// x = b*p2
	ecurvep_mult(b,p2,&x);

	// x = x+t = a*P1 + b*P2
	ecurvep_add2(&t,&x);

	copyPoly(&x,p3);
}

// verif W = sG
int verifKey(big s)
{
	Poly W,G,t;
	unsigned char *buf = NULL;

	initPolyW(&W);
	initPolyG(&G);
	initPolyZero(&t);

	buf = (unsigned char *)malloc(12 * sizeof(unsigned char));
	buf = reverse_byte_bignum(s);

	// calcul de sG
	ecurvep_mult(buf,&G,&t);

	return equalPoly(&t,&W);
}