#include <windows.h>
#include <stdio.h>
#include "md5.h"
#include "miracl.h"
#include "resource.h"

typedef unsigned long DWORD;

typedef struct Poly Poly;

struct Poly
{
    DWORD pBool;
    DWORD poly_x[3];
	DWORD poly_y[3];
};

extern void B64encode(char*,char*,long);
extern void ecurvep_mult(char *k, Poly *P1, Poly *P2);
extern void FieldElementToInt(Poly *P1,char *x_int);

unsigned char* reverse_byte_bignum(big a);
void reverse_byte(unsigned char *strReverse, int nLen);
void initPolyG(Poly* p);
void initPolyZero(Poly* p);

void concatString(unsigned char *serial1, unsigned char *serial2);


LRESULT CALLBACK DialogProc(HWND hWnd,UINT Message,WPARAM wParam,LPARAM lParam);


miracl *mip;
big h,k,r,xc,d,part1,part2;
Poly G,X;
unsigned char szName[100];
unsigned char digest[16];
unsigned char big_hash[8];
unsigned char *k_buf = NULL;
unsigned char *x_coord = NULL;
unsigned char serial[16] = {0};


int i,lenB64;
unsigned char serial1[8],serial2[8];
unsigned char b64_serial[50];


static const unsigned char base64_table[64] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";


unsigned char *szAbout = "Keygen WiteG kgnme11 by artif\n\nProtection : ECNR 64 bits over GF(p^3)\n\n Greetz to _ed, Baboon, fuss";

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	DialogBoxParam(hInstance,MAKEINTRESOURCE(IDD_DIALOG1),NULL,(DLGPROC)DialogProc,0);
}

LRESULT CALLBACK DialogProc(HWND hWnd,UINT message,WPARAM wParam,LPARAM lParam)
{
	switch(message)
	{
		case WM_INITDIALOG:
			SetWindowTextA(hWnd,"Template Keygen");
			SetDlgItemTextA(hWnd,IDC_EDIT1,"Enter your name ...");
			break;

		case WM_CLOSE:
			EndDialog(hWnd,0);
			break;

		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case IDGEN:
					memset(szName,0,100);
					GetDlgItemTextA(hWnd,IDC_EDIT1,szName,100);

					

					if(strlen(szName) > 4) {

					mip = mirsys(100,0);
					h = mirvar(0);
					k = mirvar(0);
					r = mirvar(0);
					xc = mirvar(0);
					d = mirvar(0);
					part1 = mirvar(0);
					part2 = mirvar(0);
					mip->IOBASE=16;

					cinstr(r,"FFFCCDE18D3CA8AB");
					cinstr(d,"1F1B2BB3135CFB06");

					// compute d = d^(-1) mod r
					xgcd(d,r,d,d,d);


					md5(szName,strlen((char *)szName),digest);

					// compute (hash - r) mod r
					__asm {
						mov eax, dword ptr[digest]
						mov ecx, dword ptr[digest+8]
						xor eax, ecx
						mov ebx, dword ptr[digest+4]
						mov edx, dword ptr[digest+12]
						xor ebx,edx

						sub eax, 8D3CA8ABh
						sbb ebx, 0FFFCCDE1h
						jnb notMod
						add eax, 8D3CA8ABh
						adc ebx, 0FFFCCDE1h

					notMod:
						mov dword ptr[big_hash], eax
						mov dword ptr[big_hash+4], ebx
					}

					reverse_byte(big_hash,8);
					bytes_to_big(8,big_hash,h);


					irand(GetTickCount());

					initPolyG(&G);

					for(;;) {
					// random k
					bigrand(r,k);

					// polynomial initialisation
					initPolyZero(&X);
					
					k_buf = (unsigned char *) malloc(12*sizeof(unsigned char));
					k_buf = reverse_byte_bignum(k);

					// compute X = kG warning k = 96bits
					ecurvep_mult(k_buf,&G,&X);

					// on free k_buf
					free(k_buf); k_buf = NULL;

					x_coord = (unsigned char *)malloc(16 * sizeof(unsigned char));

					// get the x coordinate
					FieldElementToInt(&X,x_coord);
					reverse_byte(x_coord,16);
					bytes_to_big(16,x_coord,xc);

					free(x_coord); x_coord = NULL;

					// compute part1 = h + xc mod r
					add(h,xc,h); // h = h+xc
					divide(h,r,r);
					copy(h,part1);

					// compute part2 = d^(-1) * (k - part1) mod r
					// part2 = d * (k-part1) mod r
					subtract(k,part1,k); // k = k - part1
					if(size(k)<0) add(k,r,k);

					// part2 = d * (k-part1) mod r
					
					mad(d,k,d,r,r,part2);
					
					big_to_bytes(8,part2,serial2,0);
					reverse_byte(serial2,8);

					big_to_bytes(8,part1,serial1,0);
					reverse_byte(serial1,8);


					concatString(serial1,serial2);


					memset(b64_serial,0,50);

					B64encode(b64_serial,serial,16);
					if( strlen(b64_serial) == 0x18 ) break;
				}


					mirkill(h);
					mirkill(k);
					mirkill(r);
					mirkill(xc);
					mirkill(part1);
					mirkill(part2);
					mirkill(d);
					mirexit();
					
					SetDlgItemTextA(hWnd,IDC_EDIT2,b64_serial);
					}
					else {
						SetDlgItemTextA(hWnd,IDC_EDIT2,"nom trop court ...");
					}
					break;
				case IDABOUT:
					MessageBoxA(hWnd,szAbout, "About",MB_OK);
					break;
			}
			break;
	}
	return FALSE;
}

void reverse_byte(unsigned char *strReverse, int nLen)
{
	int i;
	unsigned char *tmp = (unsigned char*) malloc(nLen * sizeof(unsigned char));

	for(i=0;i<nLen;i++)
		tmp[i] = strReverse[nLen-i-1];

	for(i=0;i<nLen;i++)
		strReverse[i] = tmp[i];

	free(tmp);
	tmp = NULL;
}

void initPolyG(Poly* p)
{
	p->pBool = 1;
	p->poly_x[0] = 0x272D02;
	p->poly_x[1] = 0x3EE82;
	p->poly_x[2] = 0x62585;

	p->poly_y[0] = 0x112619;
	p->poly_y[1] = 0x1E112A;
	p->poly_y[2] = 0x280082;
}

void initPolyZero(Poly* p)
{
	int i;

	p->pBool = 0;

	for(i=0;i<3;i++) {
		p->poly_x[i] = 0;
		p->poly_y[i] = 0;
	}
}


unsigned char* reverse_byte_bignum(big a)
{
	unsigned char *tReverse = (unsigned char *)calloc(8,sizeof(unsigned char));

	unsigned char *strReverse = (unsigned char *)calloc(12,sizeof(unsigned char));
	int i, nLen = 0;

	nLen = big_to_bytes(8,a,tReverse,0);

	for(i=0;i<nLen;i++)
		strReverse[i] = tReverse[nLen-i-1];

	free(tReverse); tReverse = NULL;

	return strReverse;

}




void concatString(unsigned char *serial1, unsigned char *serial2)
{
	int i;
	
	for(i=0;i<8;i++)
		serial[i] = serial1[i];

	for(i=8;i<16;i++)
		serial[i] = serial2[i-8];
}