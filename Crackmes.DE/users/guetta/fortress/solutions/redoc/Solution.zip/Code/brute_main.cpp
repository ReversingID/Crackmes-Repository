
#include "main.h"

// definitions
#define	APP_NAME		"Guetta's Fortress bruteforcer"
//#define	NAME_MAX		30
// prototypes
BOOL CALLBACK DialogProc(HWND  hwndDlg, UINT  uMsg, WPARAM  wParam, LPARAM  lParam );
bool Generate (HWND hDlg);

// prototypy
bool Func_TestActCode_401148();
DWORD Func_GetIndex_401269 (WORD wNum);
bool Func_Test_4011E4 (DWORD AX, DWORD CX);
void Func_401516 (DWORD EAX, DWORD ECX);
bool Func_401536();

// global vars
BYTE g_ActCode[20] = {0};

char g_KeyTable[64] = {
	//	0xF5,0xF3,0xF4,0xF9,0xFF,0xF4,0xF3,0xF5, 0xF1,0xF1,0xF1,0xF1,0xF1,0xF1,0xF1,0xF1,
	-11,-13,-12,-7,-1,-12,-13,-11,-15,-15,-15,-15,-15,-15,-15,-15,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	1,1,1,1,1,1,1,1,5,3,4,9,15,4,3,5
};
char g_KeyTable_backup[64]; // pomocne pole
const char g_KeyTable_Const[64] = {
	0xF5,0xF3,0xF4,0xF9,0xFF,0xF4,0xF3,0xF5, 0xF1,0xF1,0xF1,0xF1,0xF1,0xF1,0xF1,0xF1,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	1,1,1,1,1,1,1,1,5,3,4,9,15,4,3,5
};

#define GROUP1_SIZE	25
#define GROUP2_SIZE	31
#define GROUP3_SIZE	41
#define GROUP4_SIZE	42
DWORD g_dwResults1[GROUP1_SIZE] ={0};
DWORD g_dwResults2[GROUP1_SIZE][GROUP2_SIZE] ={0};
DWORD g_dwResults3[GROUP1_SIZE][GROUP2_SIZE][GROUP3_SIZE] ={0};
DWORD g_dwResults4[GROUP1_SIZE][GROUP2_SIZE][GROUP3_SIZE][GROUP4_SIZE] ={0};

//----------------------------------------
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	InitCommonControls ();
	DialogBoxParam (hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, DialogProc, 0);
	return (0);
}

//----------------------------------------
BOOL CALLBACK DialogProc(HWND  hwndDlg, UINT  uMsg, WPARAM  wParam, LPARAM  lParam )
{
	switch (uMsg)
	{
		case WM_INITDIALOG:
		#ifdef NAME_MAX
			SendDlgItemMessage (hwndDlg, IDC_EDIT_NAME, EM_SETLIMITTEXT, NAME_MAX, 0);
		#endif
			return TRUE;

		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
				case IDC_BUTTON_GENERATE:
					Generate (hwndDlg);
					return TRUE;
				case IDCANCEL:
					EndDialog (hwndDlg, 0);
					return TRUE;
			}
			break;
	}
	return FALSE;
}
//----------------------------------------
DWORD Bruteforce_Group (DWORD dwResults[], short EAX = 0)
{
	DWORD dwCounter = 0;
	myShort AX, CX;

	for (AX.bHigh=1; AX.bHigh<=2; AX.bHigh++)
		for (AX.bLow=1; AX.bLow<=8; AX.bLow++)
			for (CX.bHigh=3; CX.bHigh<=8; CX.bHigh++)
				for (CX.bLow=1; CX.bLow<=8; CX.bLow++)
				{
					memcpy (g_KeyTable, g_KeyTable_backup, sizeof(g_KeyTable));
					if (Func_Test_4011E4 (AX.val, CX.val))
						dwResults[dwCounter++] = (AX.val << 16) | CX.val;
				}
	if (EAX) {
		AX.val = EAX;
		for (CX.bHigh=3; CX.bHigh<=8; CX.bHigh++)
			for (CX.bLow=1; CX.bLow<=8; CX.bLow++)
			{
				memcpy (g_KeyTable, g_KeyTable_backup, sizeof(g_KeyTable));
				if (Func_Test_4011E4 (AX.val, CX.val))
					dwResults[dwCounter++] = (AX.val << 16) | CX.val;
			}
	}
	return dwCounter;
}
//----------------------------------------
void DoBruteforce()
{
	DWORD dwIdx1, dwIdx2, dwBuf, dwRet, i,j,k, dwMax=0;
	myShort AX, CX;

	// bruteforce first group
	memcpy (g_KeyTable_backup, g_KeyTable_Const, sizeof(g_KeyTable_Const));
	//**************************************
	dwRet = Bruteforce_Group (g_dwResults1);
	//**************************************
	if (dwRet > GROUP1_SIZE) MessageBox (0, "Error", "", 0);	// DEBUG

	// bruteforce second group
	for (i=0; i<GROUP1_SIZE; i++)
	{
		memcpy (g_KeyTable_backup, g_KeyTable_Const, sizeof(g_KeyTable_Const));
		dwBuf = (g_dwResults1[i] >> 24) | ((g_dwResults1[i] >> 8) & 0xFF00);	// byte swap
		dwIdx1 = Func_GetIndex_401269 (dwBuf);
		dwBuf = (LOWORD(g_dwResults1[i]) << 8) | (LOWORD(g_dwResults1[i]) >> 8);	// byte swap
		dwBuf &= 0xFFFF;
		dwIdx2 = Func_GetIndex_401269 (dwBuf);
		g_KeyTable_backup[dwIdx2] = g_KeyTable_backup[dwIdx1];	// change values
		g_KeyTable_backup[dwIdx1] = 0;

		g_KeyTable_backup[0x1C] = g_KeyTable_backup[0xC]; g_KeyTable_backup[0xC] = 0;	// made by Fortress.exe
		//**************************************
		dwRet = Bruteforce_Group (g_dwResults2[i], g_dwResults1[i] & 0xFFFF);
		//**************************************
		if (dwRet > GROUP2_SIZE) MessageBox (0, "Error", "", 0);	// DEBUG
	}


	// bruteforce third group
	for (i=0; i<GROUP1_SIZE; i++)
		for (j=0; j<GROUP2_SIZE && g_dwResults2[i][j]; j++)
		{
			memcpy (g_KeyTable_backup, g_KeyTable_Const, sizeof(g_KeyTable_Const));

			dwBuf = (g_dwResults1[i] >> 24) | ((g_dwResults1[i] >> 8) & 0xFF00);	// byte swap
			dwIdx1 = Func_GetIndex_401269 (dwBuf);
			dwBuf = (LOWORD(g_dwResults1[i]) << 8) | (LOWORD(g_dwResults1[i]) >> 8);	// byte swap
			dwBuf &= 0xFFFF;
			dwIdx2 = Func_GetIndex_401269 (dwBuf);
			g_KeyTable_backup[dwIdx2] = g_KeyTable_backup[dwIdx1];	// change values
			g_KeyTable_backup[dwIdx1] = 0;
			// 0xC -> 0x1C :: made by Fortress.exe
			g_KeyTable_backup[0x1C] = g_KeyTable_backup[0xC]; g_KeyTable_backup[0xC] = 0;
			//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
			dwBuf = (g_dwResults2[i][j] >> 24) | ((g_dwResults2[i][j] >> 8) & 0xFF00);	// byte swap
			dwIdx1 = Func_GetIndex_401269 (dwBuf);
			dwBuf = (LOWORD(g_dwResults2[i][j]) << 8) | (LOWORD(g_dwResults2[i][j]) >> 8);	// byte swap
			dwBuf &= 0xFFFF;
			dwIdx2 = Func_GetIndex_401269 (dwBuf);
			g_KeyTable_backup[dwIdx2] = g_KeyTable_backup[dwIdx1];	// change values
			g_KeyTable_backup[dwIdx1] = 0;
			// 1 -> 0x12 :: made by Fortress.exe
			g_KeyTable_backup[0x12] = g_KeyTable_backup[1]; g_KeyTable_backup[1] = 0;

			//**************************************
			dwRet = Bruteforce_Group (g_dwResults3[i][j], g_dwResults2[i][j] & 0xFFFF);
			//**************************************
			if (dwRet > GROUP3_SIZE) MessageBox (0, "Error", "", 0);	// DEBUG
		}
		

	// bruteforce fourth group
	for (i=0; i<GROUP1_SIZE; i++)
		for (j=0; j<GROUP2_SIZE && g_dwResults2[i][j]; j++)
			for (k=0; k<GROUP3_SIZE && g_dwResults3[i][j][k]; k++)
			{
				memcpy (g_KeyTable_backup, g_KeyTable_Const, sizeof(g_KeyTable_Const));

				dwBuf = (g_dwResults1[i] >> 24) | ((g_dwResults1[i] >> 8) & 0xFF00);	// byte swap
				dwIdx1 = Func_GetIndex_401269 (dwBuf);
				dwBuf = (LOWORD(g_dwResults1[i]) << 8) | (LOWORD(g_dwResults1[i]) >> 8);	// byte swap
				dwBuf &= 0xFFFF;
				dwIdx2 = Func_GetIndex_401269 (dwBuf);
				g_KeyTable_backup[dwIdx2] = g_KeyTable_backup[dwIdx1];	// change values
				g_KeyTable_backup[dwIdx1] = 0;
				// 0xC -> 0x1C :: made by Fortress.exe
				g_KeyTable_backup[0x1C] = g_KeyTable_backup[0xC]; g_KeyTable_backup[0xC] = 0;
				//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
				dwBuf = (g_dwResults2[i][j] >> 24) | ((g_dwResults2[i][j] >> 8) & 0xFF00);	// byte swap
				dwIdx1 = Func_GetIndex_401269 (dwBuf);
				dwBuf = (LOWORD(g_dwResults2[i][j]) << 8) | (LOWORD(g_dwResults2[i][j]) >> 8);	// byte swap
				dwBuf &= 0xFFFF;
				dwIdx2 = Func_GetIndex_401269 (dwBuf);
				g_KeyTable_backup[dwIdx2] = g_KeyTable_backup[dwIdx1];	// change values
				g_KeyTable_backup[dwIdx1] = 0;
				// 1 -> 0x12 :: made by Fortress.exe
				g_KeyTable_backup[0x12] = g_KeyTable_backup[1]; g_KeyTable_backup[1] = 0;
				//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
				dwBuf = (g_dwResults3[i][j][k] >> 24) | ((g_dwResults3[i][j][k] >> 8) & 0xFF00);	// byte swap
				dwIdx1 = Func_GetIndex_401269 (dwBuf);
				dwBuf = (LOWORD(g_dwResults3[i][j][k]) << 8) | (LOWORD(g_dwResults3[i][j][k]) >> 8);	// byte swap
				dwBuf &= 0xFFFF;
				dwIdx2 = Func_GetIndex_401269 (dwBuf);
				g_KeyTable_backup[dwIdx2] = g_KeyTable_backup[dwIdx1];	// change values
				g_KeyTable_backup[dwIdx1] = 0;
				// 6 -> 0x15 :: made by Fortress.exe
				g_KeyTable_backup[0x15] = g_KeyTable_backup[6]; g_KeyTable_backup[6] = 0;

				//**************************************
				dwRet = Bruteforce_Group (g_dwResults4[i][j][k], g_dwResults3[i][j][k] & 0xFFFF);
				//**************************************
				if (dwRet > GROUP4_SIZE) MessageBox (0, "Error", "", 0);	// DEBUG

				if (Func_401536())
					dwMax++;
			}

	return;
}
//----------------------------------------
bool Generate (HWND hDlg)
{
	DoBruteforce();
	////////////////////////////////////////

	DWORD i,j,k,l, dwDummy, x, dwCount = 0, dwSuccess = 0;
	myInt Num1, Num2, Num3, Num4;
	char szFile[256]={0};

	GetModuleFileName (0, szFile, sizeof(szFile));
	char *pStr = strrchr (szFile, '\\');
	if (pStr == NULL) return false;
	strcpy (++pStr, "ActCodes.txt");
	HANDLE hFile = CreateFile (szFile, GENERIC_WRITE, FILE_SHARE_READ, 0, CREATE_ALWAYS, 0, 0);

	for (i=0; i<GROUP1_SIZE; i++)
		for (j=0; j<GROUP2_SIZE && g_dwResults2[i][j]; j++)
			for (k=0; k<GROUP3_SIZE && g_dwResults3[i][j][k]; k++)
				for (l=0; l<GROUP4_SIZE && g_dwResults4[i][j][k][l]; l++)
				{
					Num1.val = (int)g_dwResults1[i];
					Num2.val = (int)g_dwResults2[i][j];
					Num3.val = (int)g_dwResults3[i][j][k];
					Num4.val = (int)g_dwResults4[i][j][k][l];

					g_ActCode[0] = Num1.wHigh.bLow;
					g_ActCode[1] = Num1.wHigh.bHigh;
					g_ActCode[2] = Num1.wLow.bLow;
					g_ActCode[3] = Num1.wLow.bHigh;
					g_ActCode[4] = Num2.wHigh.bLow;
					g_ActCode[5] = Num2.wHigh.bHigh;
					g_ActCode[6] = Num2.wLow.bLow;
					g_ActCode[7] = Num2.wLow.bHigh;
					g_ActCode[8] = Num3.wHigh.bLow;
					g_ActCode[9] = Num3.wHigh.bHigh;
					g_ActCode[10] = Num3.wLow.bLow;
					g_ActCode[11] = Num3.wLow.bHigh;
					g_ActCode[12] = Num4.wHigh.bLow;
					g_ActCode[13] = Num4.wHigh.bHigh;
					g_ActCode[14] = Num4.wLow.bLow;
					g_ActCode[15] = Num4.wLow.bHigh;

					dwCount++;	// in final 344191, 473 of which pass through TestActCode_401148()

					memcpy (g_KeyTable, g_KeyTable_Const, sizeof(g_KeyTable));
					if (Func_TestActCode_401148())
					{
						dwSuccess++;
						if (hFile != INVALID_HANDLE_VALUE) {
							// write proper actCode to the file
							char szOut[32] = "xxxx-xxxx-xxxx-xxxx-xxxx\r\n";
							for (x=0; x<16; x++) {
								g_ActCode[x] += '1' - 1;
								if (x % 2 == 0)
									g_ActCode[x] += 'A' - '1';
							}
							memcpy (szOut, g_ActCode, 4);
							memcpy (&szOut[5], &g_ActCode[4], 4);
							memcpy (&szOut[10], &g_ActCode[8], 4);
							memcpy (&szOut[15], &g_ActCode[12], 4);
							WriteFile (hFile, szOut, lstrlen(szOut), &dwDummy, 0);
						}
					}
				}

	if (hFile != INVALID_HANDLE_VALUE) CloseHandle (hFile);
	return true;
}
//------------------------------------------
bool Func_TestActCode_401148()
{
	WORD AX, CX;

	AX = *(WORD*)&g_ActCode[0];
	CX = *(WORD*)&g_ActCode[2];
	if (!Func_Test_4011E4 (AX, CX)) return false;
	g_KeyTable[0x1C] = g_KeyTable[0xC]; g_KeyTable[0xC] = 0;		// Func_401516 (0x507, 0x505);
	//=======================
	AX = *(WORD*)&g_ActCode[4];
	CX = *(WORD*)&g_ActCode[6];
	if (!Func_Test_4011E4 (AX, CX)) return false;
	g_KeyTable[0x12] = g_KeyTable[1]; g_KeyTable[1] = 0;		// Func_401516 (0x208, 0x306);
	//=======================
	AX = *(WORD*)&g_ActCode[8];
	CX = *(WORD*)&g_ActCode[10];
	if (!Func_Test_4011E4 (AX, CX)) return false;
	g_KeyTable[0x15] = g_KeyTable[6]; g_KeyTable[6] = 0;		// Func_401516 (0x708, 0x606);
	//=======================
	AX = *(WORD*)&g_ActCode[12];
	CX = *(WORD*)&g_ActCode[14];
	if (!Func_Test_4011E4 (AX, CX)) return false;

	if (!Func_401536()) return false;

	return true;
}
/*
// INFO: input params are always constant:
// for 0x507,0x505 is Index 0xC and 0x1C
// for 0x208,0x306 is Index 1 and 0x12
// for 0x708,0x606 is Index 6 and 0x15
//------------------------------------------
void Func_401516 (DWORD EAX, DWORD ECX)
{
	DWORD dwIdx;
	dwIdx = Func_GetIndex_401269 (EAX);
	char AL = g_KeyTable[dwIdx];
	g_KeyTable[dwIdx] = 0;

	dwIdx = Func_GetIndex_401269 (ECX);
	g_KeyTable[dwIdx] = AL;
}
*/

// tests data in KeyTable[]
//------------------------------------------
bool Func_401536()
{
	int eax=0, ebx=0, ecx=0, edx=0, esi=0;
	BYTE buf;

	esi = 5; ebx = 4;

	if ((BYTE)g_KeyTable[ebx] != 0xFF) return false;

	for (;;)
	{
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		ebx--;
		if (g_KeyTable[edx + ebx] == 0) {
			for (;;) {
				ebx--;
				if (ebx + edx == -1)	goto _00401598;
				if ((BYTE)g_KeyTable[ebx + edx] > 0) break;		//unsigned
			}
		}
		//_00401572:
		buf = (BYTE)g_KeyTable[edx + ebx];
		if (buf == 5) goto _004016C1;
		if (buf == 9) goto _004016C1;
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
_00401598:
		ebx = 5;
		if (g_KeyTable[edx + ebx] == 0) {
			for (;;) {
				ebx++;
				if (ebx + edx == 8)	goto _004015E3;
				if ((BYTE)g_KeyTable[ebx + edx] > 0) break;		//unsigned
			}
		}
		buf = (BYTE)g_KeyTable[edx + ebx];
		if (buf == 5) goto _004016C1;
		if (buf == 9) goto _004016C1;
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
_004015E3:
		ebx = 0xC;
		if (g_KeyTable[edx + ebx] == 0) {
			for (;;) {
				ebx += 8;
				if (ebx + edx > 0x3F)	goto _00401630;
				if ((BYTE)g_KeyTable[ebx + edx] > 0) break;		//unsigned
			}
		}
		buf = (BYTE)g_KeyTable[edx + ebx];
		if (buf == 5) goto _004016C1;
		if (buf == 9) goto _004016C1;
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
_00401630:
		ebx = 0xB;
		if (g_KeyTable[edx + ebx] == 0) {
			for (;;) {
				ebx += 7;
				esi --;
				if (esi == 1)	goto _00401672;
				if ((BYTE)g_KeyTable[ebx + edx] > 0) break;		//unsigned
			}
		}
		buf = (BYTE)g_KeyTable[edx + ebx];
		if (buf == 4) goto _004016C1;
		if (buf == 9) goto _004016C1;
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
_00401672:
		ebx = 0xD;
		if (g_KeyTable[edx + ebx] == 0) {
			for (;;) {
				ebx += 9;
				esi ++;
				if (esi == 8)	return false;
				if ((BYTE)g_KeyTable[ebx + edx] > 0) break;		//unsigned
			}
		}
		buf = (BYTE)g_KeyTable[edx + ebx];
		if (buf > 0xF0)	//unsigned
			return false;
		if (buf == 4) goto _004016C1;
		if (buf == 9) goto _004016C1;

		return false;

		//#########################################################
_004016C1:
		if ((DWORD)ecx > 0) return true;						//	SUCCESS: one return(true) in whole function

		ecx++;
		if ((BYTE)g_KeyTable[3] <= 0xF0) {		// unsigned
			g_KeyTable[4] = 0;
			g_KeyTable[3] = 0xFF;
			ebx = 4; edx = -1;
			continue;	// TOP for-cycle
		}
		//_004016F1:
		ecx++;
		if ((BYTE)g_KeyTable[5] <= 0xF0) {		// unsigned
			g_KeyTable[4] = 0;
			g_KeyTable[5] = 0xFF;
			ebx = 4; edx = 1;
			continue;	// TOP for-cycle
		}
		//_00401718:
		ecx++;
		if ((BYTE)g_KeyTable[0xB] <= 0xF0) {		// unsigned
			g_KeyTable[4] = 0;
			g_KeyTable[0xB] = 0xFF;
			ebx = 4; edx = 7; esi = 4;
			continue;	// TOP for-cycle
		}
		//_00401744:
		ecx++;
		if ((BYTE)g_KeyTable[0xD] <= 0xF0) {		// unsigned
			g_KeyTable[4] = 0;
			g_KeyTable[0xD] = 0xFF;
			ebx = 4; edx = 9; esi = 6;
			continue;	// TOP for-cycle
		}
		//_00401770:
		ecx++;
		if ((BYTE)g_KeyTable[0xC] > 0xF0) return false;		// unsigned
		g_KeyTable[4] = 0;
		g_KeyTable[0xC] = 0xFF;
		ebx = 4; edx = 8;
		continue;	// TOP for-cycle
	}
	return true;	// program should never going here
}
// input BH probably always in range 1-15
// actualy determine indices that will be changed in KeyTable[]
//------------------------------------------
bool Func_0040128F (myShort AX, myShort CX, char BH)
{
	DWORD dwIdx;

	if (BH == 1)
	{
		if (AX.bHigh != CX.bHigh) return false;
		if (AX.bLow == 2) {
			AX.val += 2;
			if (AX.val >= CX.val)	return true;	// succeed
			return false;
		}
		else {
			AX.val++;
			if (AX.val == CX.val)	return true;	// succeed
			return false;
		}
	}
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	//_004012C4:
	else if (BH == 3)
	{
		if ((WORD)CX.bHigh > (WORD)AX.bHigh)	// unsigned
		{
			AX.bHigh++;
			if (AX.bHigh == CX.bHigh) {
				AX.bLow += 2;
				if (AX.bLow == CX.bLow)	return true;	// succeed
				return false;
			}
			//_004012E3:
			else {
				AX.bHigh++;
				if (AX.bHigh != CX.bHigh) return false;
				AX.bLow++;
				if (AX.bLow == CX.bLow)	return true;	// succeed
				return false;
			}
		}	// if ((WORD)CX.bHigh > (WORD)AX.bHigh)
		//_004012FD:
		else {
			AX.bHigh--;
			if (AX.bHigh == CX.bHigh) {
				AX.bLow += 2;
				if (AX.bLow == CX.bLow)	return true;	// succeed
				return false;
			}
			//_00401313:
			else {
				AX.bHigh--;
				if (AX.bHigh != CX.bHigh) return false;
				AX.bLow++;
				if (AX.bLow == CX.bLow)	return true;	// succeed
				return false;
			}
		}
	} // if (BH == 3)
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	//_0040132D:
	else if (BH == 4)
	{
		if ((WORD)CX.bHigh > (WORD)AX.bHigh)	// unsigned
		{
			CX.bHigh -= AX.bHigh;
			CX.bHigh += AX.bLow;
			if (CX.bLow != CX.bHigh) return false;
			CX.bHigh -= AX.bLow;
			CX.bHigh += AX.bHigh;
			//_00401346:
			for (;;) {
				CX.bHigh--;
				CX.bLow--;
				if (AX.val == CX.val)	return true;	// succeed
				dwIdx = Func_GetIndex_401269 (CX.val);
				if (g_KeyTable[dwIdx] != 0) return false;
			}
		}
		else {
			AX.bHigh -= CX.bHigh;
			AX.bHigh += AX.bLow;
			if (AX.bHigh != CX.bLow) return false;
			AX.bHigh -= AX.bLow;
			AX.bHigh += CX.bHigh;
			//_0040137A:
			for (;;) {
				CX.bHigh++;
				CX.bLow--;
				if (AX.val == CX.val)	return true;	// succeed
				dwIdx = Func_GetIndex_401269 (CX.val);
				if (g_KeyTable[dwIdx] != 0) return false;
			}
		}
	}	// if (BH == 4)
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	//_0040139E:
	else if (BH == 5)
	{
		if (AX.bHigh != CX.bHigh)
		{
			if (AX.bLow != CX.bLow) return false;
			for (;;) {
				if ((BYTE)AX.bHigh > (BYTE)CX.bHigh)	//unsigned
					CX.bHigh++;
				else
					CX.bHigh--;
				if (AX.val == CX.val)	return true;	// succeed
				dwIdx = Func_GetIndex_401269 (CX.val);
				if (g_KeyTable[dwIdx] != 0) return false;
			}
		}
		else {
			//_004013D9:
			if (AX.bLow == CX.bLow) return false;
			for (;;) {
				CX.bLow--;
				if (AX.val == CX.val)	return true;	// succeed
				dwIdx = Func_GetIndex_401269 (CX.val);
				if (g_KeyTable[dwIdx] != 0) return false;
			}
		}
	}
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	//_00401402:
	else if (BH == 9)
	{
		if (AX.bHigh != CX.bHigh)
		{
			if (AX.bLow == CX.bLow)
			{
				for (;;) {
					if ((BYTE)AX.bHigh > (BYTE)CX.bHigh)	//unsigned
						CX.bHigh++;
					else
						CX.bHigh--;
					if (AX.val == CX.val)	return true;	// succeed
					dwIdx = Func_GetIndex_401269 (CX.val);
					if (g_KeyTable[dwIdx] != 0) return false;
				}
			}
			//_00401441:
			else {
				if ((BYTE)AX.bHigh < (BYTE)CX.bHigh)	//unsigned
				{
					CX.bHigh -= AX.bHigh;
					CX.bHigh += AX.bLow;
					if (CX.bHigh != CX.bLow) return false;
					CX.bHigh -= AX.bLow;
					CX.bHigh += AX.bHigh;
					for (;;) {
						CX.bHigh--; CX.bLow--;
						if (AX.val == CX.val)	return true;	// succeed
						dwIdx = Func_GetIndex_401269 (CX.val);
						if (g_KeyTable[dwIdx] != 0) return false;
					}
				}
				//_00401479:
				else
				{
					AX.bHigh -= CX.bHigh;
					AX.bHigh += AX.bLow;
					if (AX.bHigh != CX.bLow) return false;
					AX.bHigh -= AX.bLow;
					AX.bHigh += CX.bHigh;
					for (;;) {
						CX.bHigh++; CX.bLow--;
						if (AX.val == CX.val)	return true;	// succeed
						dwIdx = Func_GetIndex_401269 (CX.val);
						if (g_KeyTable[dwIdx] != 0) return false;
					}
				}
			}
		}	// if (AX.bHigh != CX.bHigh)
		//_004014A5:
		else
		{
			if (AX.bLow == CX.bLow) return false;
			for (;;) {
				CX.bLow--;
				if (AX.val == CX.val)	return true;	// succeed
				dwIdx = Func_GetIndex_401269 (CX.val);
				if (g_KeyTable[dwIdx] != 0) return false;
			}
		}
	}	// if (BH == 9)
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	//_004014C2:
	else if (BH == 0xF)
	{
		if (AX.bHigh == CX.bHigh) {
			CX.val++;
			if (AX.val == CX.val)	return true;	// succeed
			return false;
		}
		else if (AX.bHigh >= CX.bHigh) {		//signed
			if (AX.bLow >= CX.bLow) {			//signed
				AX.bHigh -= CX.bHigh;
				if (AX.bHigh == 1)	return true;	// succeed
				return false;
			}
			else {
				AX.bHigh -= CX.bHigh;
				AX.bHigh += AX.bLow;
				if (AX.bHigh == CX.bLow)	return true;	// succeed
				return false;
			}
		}	// if (AX.bHigh >= CX.bHigh)
		else {
			if (AX.bLow >= CX.bLow) {
				CX.bHigh -= AX.bHigh;
				if (CX.bHigh == 1)	return true;	// succeed
				return false;
			}
			else {
				CX.bHigh -= AX.bHigh;
				CX.bHigh += AX.bLow;
				if (CX.bHigh == CX.bLow)	return true;	// succeed
				return false;
			}
		}
	}

	return true;
}
// return number from range 0-63
//------------------------------------------
DWORD Func_GetIndex_401269 (WORD wNum)
{
	DWORD EAX = LOBYTE(wNum) * 8;
	DWORD EDX = 63 - EAX;
	EDX += wNum >> 8;
	return EDX;
}
//------------------------------------------
bool Func_Test_4011E4 (DWORD dwEAX, DWORD dwECX)
{
	DWORD dwEDI;

	__asm {
		MOV EAX, DWORD PTR[dwEAX]
		MOV ECX, DWORD PTR[dwECX]
		BSWAP EAX			// byte swap and shift >> 16   ... (word byte swap)
		SHR EAX, 0x10
		BSWAP ECX
		SHR ECX, 0x10
		MOV DWORD PTR[dwEAX], EAX
		MOV DWORD PTR[dwECX], ECX
	}
	if (dwEAX == dwECX) return false;
	if (LOBYTE(dwEAX) > LOBYTE(dwECX)) return false;

	DWORD dwIdx = Func_GetIndex_401269 (dwEAX);
	if (g_KeyTable[dwIdx] < 1) return false;
	if (g_KeyTable[dwIdx] > 15) return false;
	//_0040120E:
	char BH = g_KeyTable[dwIdx];	// BH is used in function 0040128F

	dwIdx = Func_GetIndex_401269 (dwECX);
	if (g_KeyTable[dwIdx] != 0) 	{	// -7 <= value >= -15 ...first line of g_KeyTable (except index 4)
		if ((BYTE)g_KeyTable[dwIdx] < 0xF1/*-15*/) return false;	//unsigned
		if (g_KeyTable[dwIdx] > 0xF9/*-7*/) return false;
	}
	//_00401237:
	myShort myEAX, myECX;
	myEAX.val = dwEAX; myECX.val = dwECX;
	if (!Func_0040128F (myEAX, myECX, BH)) return false;

	dwIdx = Func_GetIndex_401269 (dwEAX);	// INFO: cracme uses EDI register
	char AL = g_KeyTable[dwIdx];
	g_KeyTable[dwIdx] = 0;

	dwIdx = Func_GetIndex_401269 (dwECX);
	g_KeyTable[dwIdx] = AL;

	return true;
}
