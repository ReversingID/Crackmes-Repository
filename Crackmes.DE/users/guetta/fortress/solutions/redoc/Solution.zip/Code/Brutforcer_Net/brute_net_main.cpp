#define _CRT_SECURE_NO_WARNINGS

#undef UNICODE
#undef _UNICODE
#include <windows.h>
#include <commctrl.h>
#include "resource.h"

// prototypes
typedef void (__stdcall *SERVER_FUNC) (void);
// variables
char	g_szActCode[32] = "B1A3-C2C3-D1B3-B3E6-xxxx";
DWORD	g_FuncTable[0x20];
BYTE	g_DummyData_redir[0x1000] = {1};
char	g_SocketBuf[5000];

DWORD g_dwCount, g_dwActualCode, g_dwResult = 0xFFFFFFFF;
bool g_bRun;

// INFO: success check can by probably done more easily by checking size of returned data
//----------------------------------------
int MessageBox_redir (HWND hWnd, LPCTSTR lpText, LPCTSTR lpCaption, UINT uType)
{
	if (lstrcmpi (lpText, "Invalid activation code."))		// invalid code
		g_dwCount++;
	return IDOK;
}
//----------------------------------------
int GenericFunc_redir ()
{
	g_bRun = false;
	g_dwCount++;														// valid code
	g_dwResult = g_dwActualCode;
	return 0;
}
//----------------------------------------
DWORD WINAPI Start_thread (PVOID pParam)
{
	DWORD i, dwBuf, dwSize, dwDiff, dwTime;
	SOCKET s = INVALID_SOCKET;
	int intRet;
	char szBuf[256]={0};

	HWND hDlg = (HWND)pParam;
	SetDlgItemText (hDlg, IDC_EDIT_RESULT, "");
	// init FuncTable (redirected)
	g_FuncTable[0] = (DWORD)MessageBox_redir;
	for (i=1; i<13; i++)
		g_FuncTable[i] = (DWORD)GenericFunc_redir;
	for (i=13; i<32; i++)
		g_FuncTable[i] = (DWORD)g_DummyData_redir;

	BOOL bRet = VirtualProtect ((LPVOID)g_SocketBuf, sizeof(g_SocketBuf), PAGE_EXECUTE_READWRITE, &dwBuf);

	// starting sockets communication
	WSADATA wsadata;
	if (WSAStartup (0x0002, &wsadata)) {
		MessageBox (hDlg, "WSAStartup error.", "brutus", 0);
		goto err_handler;
	}

	hostent *host = gethostbyname ("fortress.re");
	SOCKADDR_IN target;
	target.sin_family = AF_INET;
	target.sin_port = htons (80);	// http
	target.sin_addr.s_addr = *(ULONG*)host->h_addr_list[0];

	g_dwResult = 0xFFFFFFFF; g_dwCount = 0; dwTime = 0;
	//************************************************************************************
	DWORD dwStart = GetDlgItemInt (hDlg, IDC_EDIT_START_SEQ, 0, FALSE);
	for (g_dwActualCode=dwStart; g_bRun && g_dwActualCode<9999; g_dwActualCode++)
	{
		if (s != INVALID_SOCKET) closesocket (s);
		s = socket (AF_INET, SOCK_STREAM, IPPROTO_TCP);
		if (s == INVALID_SOCKET)
			goto err_handler;

		dwDiff = GetTickCount ();
		if (connect (s, (sockaddr*)&target, sizeof(target)))
			goto err_handler;
		// connected, send data
		wsprintf (&g_szActCode[20], "%04d", g_dwActualCode);
		wsprintf (szBuf, "GET /server.php?key=%s HTTP/1.1\r\nHost: fortress.re\r\nUser-agent: Fortress\r\n" \
			"Connection: close\r\n\r\n", g_szActCode);
		if ( SOCKET_ERROR == send (s, szBuf, lstrlen(szBuf), 0))
			goto err_handler;
		// receive data
		intRet = 0; dwSize = 0;
		do {
			dwSize += intRet;
			intRet = recv (s, &g_SocketBuf[dwSize], sizeof(g_SocketBuf), 0);
		}while (intRet > 0);
		dwTime += GetTickCount() - dwDiff;

		// data received, process it
		HWND hwndDlg = hDlg;
		SERVER_FUNC	Entry_Func = 0;	// entry point to server function
		char *szStrBuf = 0;	// pointer to output string in socket data
		//first find 0xDEADC0DE
		for (i=0; i<dwSize; i++)
			if (0xDEADC0DE == *(DWORD*)&g_SocketBuf[i])
				{Entry_Func = (SERVER_FUNC) &g_SocketBuf[i+4]; break;}
		if (Entry_Func == 0)
			continue;
		//find 0xDEADBEEF
		for (i=0; i<dwSize; i++)
			if (0xDEADBEEF == *(DWORD*)&g_SocketBuf[i])
				{szStrBuf = &g_SocketBuf[i+4]; break;}
		if (szStrBuf == 0)
			continue;

		// we can now call Entry_Func, prepare input params
		__try{		// exception is highly possible
			_asm {
				mov EBX, DWORD PTR[szStrBuf]
				mov EAX, EBX
				lea EDX, DWORD PTR[g_FuncTable]
				mov ECX, DWORD PTR[hwndDlg]
				call Entry_Func
			}
		}__except(EXCEPTION_EXECUTE_HANDLER) {}
	} // for (g_dwActualCode)

	if (g_dwResult != 0xFFFFFFFF)
		SetDlgItemInt (hDlg, IDC_EDIT_RESULT, g_dwResult, FALSE);

err_handler:
	MessageBeep (MB_ICONEXCLAMATION);
	g_bRun = false;
	SetDlgItemText (hDlg, IDC_BUTTON_START, "Start");
	if (s != INVALID_SOCKET) closesocket (s);
	WSACleanup ();
	return 0;
}
//----------------------------------------
BOOL CALLBACK DialogProc(HWND  hwndDlg, UINT  uMsg, WPARAM  wParam, LPARAM  lParam )
{
	DWORD dwTID;
	HANDLE hThread;

	switch (uMsg)
	{
	case WM_INITDIALOG:
		SendDlgItemMessage (hwndDlg, IDC_EDIT_START_SEQ, EM_SETLIMITTEXT, 4, 0);
		SetDlgItemText (hwndDlg, IDC_EDIT_START_SEQ, "0000");
		return TRUE;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDC_BUTTON_START:
			if (g_bRun) {
				g_bRun = false;
				SetDlgItemText (hwndDlg, IDC_BUTTON_START, "Start");
				Sleep (250);
			}
			else {
				hThread = CreateThread (0, 0, Start_thread, hwndDlg, 0, &dwTID);
				if (hThread) {
					g_bRun = true;
					SetDlgItemText (hwndDlg, IDC_BUTTON_START, "Stop");
					Sleep (100);
					CloseHandle (hThread);
				}
			}
			return TRUE;
		case IDCANCEL:
			g_bRun = false;
			Sleep (250);
			EndDialog (hwndDlg, 0);
			return TRUE;
		}
		break;
	}
	return FALSE;
}
//----------------------------------------
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	InitCommonControls();
	DialogBoxParam (hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, DialogProc, 0);
	return (0);
}
