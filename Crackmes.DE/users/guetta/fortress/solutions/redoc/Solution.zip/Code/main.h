#define _CRT_SECURE_NO_WARNINGS

#undef UNICODE
#undef _UNICODE
#include <windows.h>
#include <CommCtrl.h>
#include "resource.h"


union myShort {
	short		val;
	struct	{
		char	bLow;
		char	bHigh;
	};
};
union myInt {
	int		val;
	struct	{
		myShort wLow;
		myShort wHigh;
	};
};
