
void Create16bytesMd5(char *arg1, char *arg2)
{
	unsigned char digest[16];
	md5_context ctx;
	md5_starts(&ctx);
	md5_update(&ctx, (unsigned char *)arg1, strlen(arg1));
	md5_finish(&ctx, digest);
	for (int i = 0; i < 8; i++)
	{
		wsprintf(arg2 + i * 2, "%02X",digest[i]);
	}
}
void Generate(HWND hWnd)
{
	mip = mirsys(1024, 16); 

	char name[255], grp[50], email[50], serial[500];
	char p1[17], p2[17], p3[17];
	char q1[50], q2[50], q3[50];


	int len1 = GetDlgItemText(hWnd,IDC_NAME,name,50);
	int len2 = GetDlgItemText(hWnd,IDC_GRP,grp,50);
	int len3 = GetDlgItemText(hWnd,IDC_EMAIL,email,50);

	Create16bytesMd5(name,p1);
	Create16bytesMd5(grp,p2);
	Create16bytesMd5(email,p3);
	p1[15] = '\0';
	p2[15] = '\0';
	p3[15] = '\0';


    
	
	big n,  d,  c,  m;
	n = mirvar(0);
	d = mirvar(0);
	m = mirvar(0);
	c = mirvar(0);
	mip->IOBASE = 16;
	
	cinstr(n, "C2D6D2FFA7BA10D9");
    cinstr(d, "E1FE2B5D380D65D");
	cinstr(c, p1);
    powmod(c, d, n, m);
	cotstr(m, q1);

	cinstr(n, "DC8058C0540D1B89");
    cinstr(d, "9678D396AFB2F8CD");
    cinstr(c, p2);
	powmod(c, d, n, m);
	cotstr(m, q2);

	cinstr(n, "956A4A6E977251D1");
    cinstr(d, "6C668806A1B389FD");
    cinstr(c, p3);
	powmod(c, d, n, m);
	cotstr(m, q3);
	
	
	mirkill(n);
	mirkill(d);
	mirkill(m);
	mirkill(c);

	wsprintf(serial,"%s-%s-%s.",q1,q2,q3);

    SetDlgItemText(hWnd,IDC_SERIAL,serial);
}


