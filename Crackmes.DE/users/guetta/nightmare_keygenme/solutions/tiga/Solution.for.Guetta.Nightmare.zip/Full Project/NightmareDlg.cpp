// NightmareDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Nightmare.h"
#include "NightmareDlg.h"
#include "Crc32Static.h"
#include "Common.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNightmareDlg dialog

CNightmareDlg::CNightmareDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CNightmareDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNightmareDlg)
	m_sName = _T("");
	m_sSerial = _T("");
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CNightmareDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNightmareDlg)
	DDX_Control(pDX, IDC_BGENERATE, m_ctlBgenerate);
	DDX_Text(pDX, IDC_ENAME, m_sName);
	DDV_MaxChars(pDX, m_sName, 64);
	DDX_Text(pDX, IDC_ESERIAL, m_sSerial);
	DDV_MaxChars(pDX, m_sSerial, 64);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CNightmareDlg, CDialog)
	//{{AFX_MSG_MAP(CNightmareDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BGENERATE, OnBgenerate)
	ON_EN_CHANGE(IDC_ENAME, OnChangeEname)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNightmareDlg message handlers

BOOL CNightmareDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CNightmareDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CNightmareDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CNightmareDlg::OnChangeEname() 
{
	UpdateData(true);

	if (m_sName.GetLength() < 2)
		m_ctlBgenerate.EnableWindow(false);
	else
		m_ctlBgenerate.EnableWindow(true);

	UpdateData(false);
}

unsigned long CNightmareDlg::bswap(unsigned long iDWORD)
{
	__asm
	{
		mov eax,iDWORD
		bswap eax
		mov iDWORD,eax
	}

	return iDWORD;
}

void CNightmareDlg::OnBgenerate() 
{
	unsigned long iHash = 0, iCode = 0x900AEB90;

	CCrc32Static::StringCrc32((LPCSTR)m_sName, iHash);
	iHash = bswap(iHash);

	m_sSerial.Format("[%X][WTF?]", iHash^iCode);

	UpdateData(false);
}
