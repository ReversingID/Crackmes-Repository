// NightmareDlg.h : header file
//

#if !defined(AFX_NIGHTMAREDLG_H__E91E5020_5020_4CEE_A6E7_90EC1F08ED0D__INCLUDED_)
#define AFX_NIGHTMAREDLG_H__E91E5020_5020_4CEE_A6E7_90EC1F08ED0D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CNightmareDlg dialog

class CNightmareDlg : public CDialog
{
// Construction
public:
	unsigned long bswap(unsigned long iDWORD);
	CNightmareDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CNightmareDlg)
	enum { IDD = IDD_NIGHTMARE_DIALOG };
	CButton	m_ctlBgenerate;
	CString	m_sName;
	CString	m_sSerial;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNightmareDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CNightmareDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBgenerate();
	afx_msg void OnChangeEname();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NIGHTMAREDLG_H__E91E5020_5020_4CEE_A6E7_90EC1F08ED0D__INCLUDED_)
