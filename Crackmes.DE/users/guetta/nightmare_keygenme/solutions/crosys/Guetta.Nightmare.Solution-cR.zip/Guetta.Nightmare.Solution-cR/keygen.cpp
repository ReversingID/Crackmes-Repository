DWORD CRC(char *buff, int len)
{
	DWORD crc = 0xFFFFFFFF;
	DWORD tmp;
	for(int i = 0; i < len; i++)
	{
		tmp = buff[i];
		tmp ^= (crc & 0xFF);
		for(int j = 0; j < 8; j++)
		{
			if(tmp & 1)
			{
				tmp >>= 1;
				tmp ^= 0xEDB88320;
			}
			else
				tmp >>= 1;
		}
		crc >>= 8;
		crc ^= tmp;
	}
	return ~crc;
}

void Generate(HWND hWnd)
{
	unsigned long crc = 0, s[2] = {0};
	char name[50], serial[50];
	int len = GetDlgItemText(hWnd,IDC_NAME,name,50);
	crc = CRC(name,len);
	__asm
	{
		mov eax, dword ptr ds:[crc]
		bswap eax
		mov dword ptr ds:[crc], eax
	}
	s[0] = crc ^ 0x0BEB;
	wsprintf(serial,"[%08X][WTF?]",s[0]);
	SetDlgItemText(hWnd,IDC_SERIAL,serial);
	s[1] = crc ^ 0x90900BEB;
	wsprintf(serial,"[%08X][WTF?]",s[1]);
	SetDlgItemText(hWnd,IDC_SERIAL2,serial);
}