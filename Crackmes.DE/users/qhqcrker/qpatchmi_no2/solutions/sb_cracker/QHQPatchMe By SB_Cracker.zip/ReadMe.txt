Patched By SB_Cracker
SBCracker@hotmail.com

:P

Address Changed: 

0040101C                      FILL WITH NOP's
00403197		      "MESSAGGE CHANGED BY SB_CRACKER !!"
0040103E                      FILL WITH NOP's
004013E7                      MOV DWORD PTR DS:[EDI], 50000000
00401021 - 0040102F           FILL WITH NOP's

Comments:

80% easy :)









