#!/usr/bin/perl
##-- kbp - 20080925 --##

use strict;


##-- vars --##
my ($name, $nickname, $age, $nameLength, $nicknameLength, $ageLength, $serial);
my $fieldsSummed = 0;
my $fieldsMultiplied = 0;


##-- subs --##
sub atoi {
  my $t;
  foreach my $d (split(//, shift())) {
    $t = $t * 10 + $d;
  }
  return $t;
}

sub generateSerial {

  $serial = $serial . $fieldsMultiplied;
  $serial = $serial . "-";
  $serial = $serial . reverse(substr($name, 1, 3));
  $serial = $serial . substr($nickname, 2, 2);
  $serial = $serial . $fieldsSummed;
  $serial = $serial . "-";
  $serial = $serial . substr($age, 1, 1);
  $serial = $serial . $nameLength;
  
}


##-- main --##
print "-= This is a keygen for Breakers crackme 3 from www.crackmes.de =-\n";
print "Please enter your name: ";
$name = <STDIN>;
chomp $name;
$nameLength = length($name);
print "Please enter your nickname: ";
$nickname = <STDIN>;
chomp $nickname;
$nicknameLength = length($nickname);
print "Please enter your age: ";
$age = <STDIN>;
chomp $age;
$ageLength = length($age);

$fieldsSummed = ( $nameLength + $nicknameLength + $ageLength);
$fieldsMultiplied = ( $nameLength * $nicknameLength * $ageLength);

&generateSerial;

print "Name:\t\t\t$name\n";
print "Nickname:\t\t$nickname\n";
print "Age:\t\t\t$age\n";
print "Your serial is:\t\t$serial\n";

