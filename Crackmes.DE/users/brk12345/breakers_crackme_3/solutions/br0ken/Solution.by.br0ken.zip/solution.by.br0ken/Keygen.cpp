#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
	// I know this is not the best way to code, but it works :P
    int nlen,nnlen,alen;
	char nickname[255],name[255],age[255];
	printf("**************************************************\n");
	printf("*** Keygen for Breaker's Crackme # 3 by br0ken ***\n");
    printf("**************************************************\n");
	printf("\n\nName : ");
	scanf("%s",name);
	printf("Nickname : ");
	scanf("%s",nickname);
    nlen=strlen(name);
	printf("Age : ");
    scanf("%s",age);
    nnlen=strlen(name);
	nnlen=strlen(nickname);
	alen=strlen(age);
	printf("\n\nSerial : %d-",nlen*nnlen*alen);
	if(nlen==2)
	{
		printf("%c",name[1]);
	}
	if(nlen==3)
	{
		printf("%c%c",name[2],name[1]);
	}
	if(nlen>=4)
	{
		printf("%c%c%c",name[3],name[2],name[1]);
	}
	
	if(nnlen==3)
	{
		printf("%c",nickname[2]);
	}
	if(nnlen>=4)
	{
		printf("%c%c",nickname[2],nickname[3]);
	}
	
	
	printf("%d-",nlen+nnlen+alen);
	if(alen>=2)
	{
		printf("%c",age[1]);
	}
	printf("%d\n",nlen);
	


		getch();
}