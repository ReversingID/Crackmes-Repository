#include<stdio.h>
#include<string.h>
#include<conio.h>
void main()
{
	long int len;
	char name[255];
	printf("********************************************\n");
	printf("*** Keygen for CRACKME(KeyGen) by br0ken ***\n");
    printf("********************************************\n");
	printf("\n\nName: ");
	scanf("%s",name);
	len=strlen(name);
	printf("Serial : %ld\n",(len*81)+19350);
	getch();
}