Video Solution to CrackMe #4 by BRK12345
Solved by MACH4

Tools:
Reflector
Visual Studio


If you have problems with the flash video size, Google for "SWF Opener" by UnH Solutions, I wouldn't be without it!

Greetz to Breaker, Crackmes.de and all crackers!

MACH4.