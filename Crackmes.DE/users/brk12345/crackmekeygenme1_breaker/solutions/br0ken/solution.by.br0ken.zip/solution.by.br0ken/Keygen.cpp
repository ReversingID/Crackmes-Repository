#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
	// I know this is not the best way to code, but it works :P
        int len;
	char name[255];
	printf("**********************************************\n");
	printf("*** Keygen for Crackme/KeyGenme1 by br0ken ***\n");
        printf("**********************************************\n");
	printf("\n\nName : ");
	scanf("%s",name);
        len=strlen(name);
	printf("Serial : %d-",len*0x55);
	if(len==2)
	{
		printf("%c",name[1]);
	}
	if(len==3)
	{
		printf("%c%c",name[2],name[1]);
	}
	if(len>=4)
	{
		printf("%c%c%c",name[3],name[2],name[1]);
	}
	printf("ata-%d\n",(80*len)+100);
	getch();
}