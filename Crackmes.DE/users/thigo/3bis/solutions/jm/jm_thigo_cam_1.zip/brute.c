/* 
   brute force attack on thigo's 1st Cryptanalyze Me (1st part)

   there are 256*256 possible keys
   we will work with 40 bytes of crypted text
   and we will release a candidate key when 75% of the decrypted text contains characters 
   after some attempts a valid key found is : 0xAD9E

   by j!m

*/

#include <stdio.h>
#include <conio.h>

int main() {
	FILE *f;
	unsigned int x[40], y[40], k[2], i, j, l, p;
	
	if ((f = fopen("data.bin", "r")) == NULL) {
   		printf ("\nfile not present\n");
   		return 1;
  	}
	/* read 40 bytes */
	for (i = 0; i < 40; i++) {
		x[i] = fgetc(f);
		printf("%x", x[i]);
	}
	
	printf("\n");
	fclose(f);
	getch();

	/* uncipher */
	for (k[0] = 1; k[0] < 256; k[0]++) {
		for (k[1] = 1; k[1] < 256; k[1]++) {

			printf("\nprocessing key %x%x",k[0], k[1]);
			
			p = 0;
			
			/* decrypt algo */
			for (i = 39; i > 0; i--) {
				j = x[i-1] & 0xFF;
				l = ~i & 0xFF;
				j ^= l;
				j ^= x[i];
				j = j * k[0] + k[1];
				j &= 0xFF;

				y[i] = j;

				j |= 0x20; //we remove lower/upper case distinction (bit n�5)

				if ( ((j < 0x7b) && (j > 0x60)) ) p++; //statistics
  
			}
			
			if ( p >= 30 ) {
				printf("\nCandidate key %x%x\n",k[0],k[1]);
				for (i = 1; i < 40; i++) {
					printf("%c",y[i]); //print text
				}
			getch();
			}
		}
	}
	getch();
	return 0;					

}
