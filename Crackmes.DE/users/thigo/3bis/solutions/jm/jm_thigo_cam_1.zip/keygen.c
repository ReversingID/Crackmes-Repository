/* 
  convert MD5('evening') from base 16 to base 60
  and print the final keygen for thigo's 1st Cryptanalyze Me!

  by j!m  

  valid key is : AD9E-EPUtdBUrqF8ZTC1Jd8HUt6

*/

#include <stdio.h>
#include <miracl.h>

void main() {

	big md5;
	int l;
	FILE *f;
	
	//inits
	miracl *mip = mirsys(600,0);

	md5 = mirvar(0);
	
	mip->IOBASE = 16;

	printf("Reading md5\n");
	f = fopen("evening_md5","r");
	l = cinnum(md5,f);	
	fclose(f);

	mip->IOBASE = 60;
	printf("serial = AD9E-");
	cotnum(md5,stdout);
	getchar();
	mirexit();
}

	
