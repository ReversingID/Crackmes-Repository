/* 
  RSA Low exponent Attack 
  on Thigo 1st cryptanalyze Me (2nd Part)

  we use MIRACL Chinese Remainder Theorem functions to solve the problem,
  so you need a copy of the MIRACL library to compile this !

  by j!m 01-30-2002

  enjoy
*/

#include <stdio.h>
#include <miracl.h>

void main() {

	big n[3];
	big c[3];
	int l;
	FILE *f;
	big x,z;

	big_chinese pbc;

	//inits
	miracl *mip = mirsys(600,0);

	n[0] = mirvar(0);
	n[1] = mirvar(0);
	n[2] = mirvar(0);

	c[0] = mirvar(0);
	c[1] = mirvar(0);
	c[2] = mirvar(0);

	x = mirvar(0);
	z = mirvar(0);

	//read the three moduli
	mip->IOBASE = 60;

	printf("Reading tony modulus\n");
	f = fopen("tony_mod","r");
	l = cinnum(n[0],f);	
	fclose(f);
	
	printf("Reading Paul modulus\n");
	f = fopen("paul_mod","r");
	l = cinnum(n[1],f);	
	fclose(f);

	printf("Reading thomas modulus\n");
	f = fopen("thomas_mod","r");
	l = cinnum(n[2],f);	
	fclose(f);

	//read the three messages encrypted with the low exponent

	printf("Reading tony encrypted message\n");
	f = fopen("tony_mess","r");
	l = cinnum(c[0],f);	
	fclose(f);

	printf("Reading paul encrypted message\n");	
	f = fopen("paul_mess","r");
	l = cinnum(c[1],f);	
	fclose(f);

	printf("Reading thomas encrypted message\n");
	f = fopen("thomas_mess","r");
	l = cinnum(c[2],f);	
	fclose(f);

	/* ok we are ready to use the chinese remainder theorem to compute a number
           c = c(i) mod n(i)
        */

	printf("Ok we start now\n");

	if ( crt_init(&pbc,3,n) ) {
		printf("computing C...please wait\n");
		crt(&pbc,c,x);
		printf("found C = ");
		mip->IOBASE = 16;
		cotnum(x,stdout);
		crt_end(&pbc);

		// m = x^(1/3)
		printf("Extracting third root of C...\n");
		nroot(x,3,z);
		mip->IOBASE = 256;
		printf("M = ");
		cotnum(z,stdout);
		getchar();
	} else {
		printf("Something went wrong in the init!\n");
		getchar();
	}

	mirexit();
}
