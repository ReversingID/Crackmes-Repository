Thigo's *little* crackme v1.1

Just a few words:
Try to make a keygen for it... If you can't, try to crack it...

Good Luck (You'll need it...)

Thigo [TMG]
thigo@caramail.com