#include <stdio.h>
#include <windows.h>
#include <commctrl.h> 
#include "resource.h"
#include "md5c.c"
#include "global.h"
#include <miracl.h>
#pragma comment(lib,"md5.lib")
#pragma comment(lib, "comctl32.lib")

HINSTANCE	hInst;
unsigned char szName[100] = {0};
unsigned char szHash[41] = {0};
long dtLength;
MD5_CTX context;
int lsb;
char nb[10];
char serial[41]="";
big x1,y1,x2,y2,p,a,b,m,dv,x;
epoint *p1,*p2,*p3;

extern void _MD5Init(MD5_CTX*);
extern void _MD5Hash(MD5_CTX*, char*, int);
extern void _MD5Finish(char*,MD5_CTX*);

BOOL CALLBACK DialogProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{	
	miracl *mip=mirsys(300,16);
	switch (message)
	{    
	case WM_CLOSE:
		EndDialog(hWnd,0);
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{ 
		case IDC_GENERATE:
			dtLength=GetDlgItemText(hWnd,IDC_USER_ID, szName, 65);
			if (dtLength<5) {
				MessageBox(hWnd,"Length of User ID is invalid",NULL,MB_ICONSTOP);
				break;
			}
			_MD5Init(&context);
			_MD5Hash(&context, szName, dtLength);
			_MD5Finish(szHash, &context);
			mip->IOBASE=16;
			x1=mirvar(0);
			y1=mirvar(0);
			x2=mirvar(0);
			y2=mirvar(0);
			p=mirvar(0);
			b=mirvar(0);
			m=mirvar(0);
			dv=mirvar(0);
			x=mirvar(0);
			a=mirvar(-3);
			cinstr(x1,"1C341C34E32D5EC8F3DC83E7DA1A9DAC84E26624");
			cinstr(y1,"902166CCF366300FAF8B1CCA939C1280E5450F40");
			cinstr(x2,"5A3884AF3E676F49470F441CBEEBE7C0B1D9DF66");
			cinstr(y2,"12C34484F6C34BB886EEE052ACC6247098BEDC3C");
			cinstr(p,"C90FDAA22168C234C4C6628B80DC1CD129024E1F");
			cinstr(b,"ADF85458A2BB4A9AAFDC5620273D3CF1D8B9C841");
			cinstr(dv,"AB6853BDD1100F57");
			bytes_to_big(16,&szHash,m);
			power(m,3,dv,m);
			ecurve_init(a,b,p,1);
			p1=epoint_init();
			p2=epoint_init();
			p3=epoint_init();
			epoint_set(x1,y1,0,p1);
			epoint_set(x2,y2,0,p2);
			ecurve_mult(m,p1,p3);
			ecurve_sub(p2,p3);
			ecurve_add(p1,p1);
			ecurve_sub(p1,p3);
			lsb=epoint_get(p3,x,x);
			SetDlgItemText(hWnd,IDC_V_CODE,itoa(lsb,nb,10));
			otstr(x,serial);
			SetDlgItemTextA(hWnd,IDC_REG_CODE,serial);
			mirkill(x1);
			mirkill(y1);
			mirkill(x2);
			mirkill(y2);			
			mirkill(p);
			mirkill(a);
			mirkill(b);
			mirkill(m);
			mirkill(x);
			mirkill(dv);
			epoint_free(p1);
			epoint_free(p2);
			epoint_free(p3);
			mirexit();
			break;
		case IDC_ABOUT:
			MessageBox(hWnd, "Keygenerator for TMG official keygenme 4\nprotection: ECC-160 and modified md5", "bLaCk-eye PRESENTS:", MB_ICONINFORMATION);
			break;
		}
		break;
	case WM_INITDIALOG:
		SendMessageA(hWnd,WM_SETICON,(WPARAM) 1,(LPARAM) LoadIconA(hInst,MAKEINTRESOURCE(IDI_ICON)));
		break;
	}
     return 0;
}

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{
	hInst=hInstance;
	InitCommonControls();
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, (DLGPROC)DialogProc,0);
	return 0;
}
