#pragma comment(lib, "miracl.lib")
// Windows Header Files:
#include <windows.h>

// windows internal
#include <winternl.h>

// C RunTime Header Files
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>
#include <time.h>
#include "crc32.h"
#include "resource.h"
extern "C"{
	#include "md5.h"
	#include "miracl.h"
}

char charset[] = "QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890";
int base;
#define TAB_SIZE 1<<20
DWORD tab[TAB_SIZE];

INT_PTR CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	newSnProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK	newFeatProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK	newExpProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
HINSTANCE hInst;

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	hInst = hInstance;
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DIALOG), NULL, (DLGPROC)WndProc, NULL);
	return 0;
}
unsigned char conv(unsigned char ch){
	unsigned char outt = ch + 0x30;
	if(outt > 0x39)
		outt += 7;
	return outt;
}

char *hexstr2ascii(unsigned char *instr, unsigned int inlen)
{
	char *outstr = new char[inlen*2+1];
	unsigned int c = 0;
	for(unsigned int i=0; i<inlen; i++){
		outstr[c++] = conv((instr[i]&0xF0)>>4);
		outstr[c++] = conv(instr[i]&0xF);
		outstr[c] = 0;
	}
	return outstr;
}

int CheckCharacters(DWORD sol){
	int i;
	unsigned int c;

	for(i=0;i<4;i++){
		c = sol&0xff;      
		if(c==0 || strchr(charset, c) == NULL){
			return 0;
		}
		sol >>= 8;
	}

	return 1;
}

void GenerateBinary(char *out){
	int i;

	i=8;
	while(i>=0){
		out[i] = 0x30 + (rand()%2);
		i--;
	}
	out[9]=0;
}

void GeneratePermutation(char *out){
	int i;

	i=3;
	while(i>=0){
		out[i] = charset[rand()%base];
		i--;
	}
	out[8]=0;
}

char *GenRevCRC()
{
	char *ser = new char[9];
	char perm[9];
	unsigned int crc, crc2;

	

	base = strlen(charset);
	memset(perm, 0, 9);

	while(1)
	{
		GeneratePermutation(perm);
		crc = crc32((unsigned char *)perm, 4);
		crc2 = rev_crc(~crc, ~0x40236373);
		if(CheckCharacters(crc2))
		{
			*(DWORD *)&perm[4] = crc2;
			strcpy(ser, perm);
			return ser;
		}

	}
	delete [] ser;
	return NULL;
}

char *GenerateFirst()
{
	char *serial = new char[255];
	char p1[] = "MAG";
	char p2[] = "CLOSER";
	char p3[10];
	char p4[] = "A132F51F2B8E261B";

	memset(serial, 0, 255);
	srand((unsigned int)time(NULL));
	serial[0] = p1[rand()%3];
	serial[1] = p2[rand()%6];
	strcat(serial, rand()%2 ? "AH" : "HA");
	strcat(serial, "Rx");
	GenerateBinary(p3);
	p3[1] = '0';
	p3[4] = '1';
	p3[6] = '1';
	strcat(serial, p3);

	char *crcr = GenRevCRC();
	if(crcr == NULL)
		return crcr;
	strcat(serial,crcr);
	strcat(serial,p4);

	return serial;
}

char *GenerateThird()
{
	char *ser = new char[0x1000];
	char *nmd5;
	char username[255];
	DWORD lpLen;
	unsigned char md5out[16];
	MD5_CTX ctx;
	lpLen = 255;

	GetUserName(username, &lpLen);
	MD5Init(&ctx);
	MD5Update(&ctx, (unsigned char *)username, lpLen-1);
	MD5Final(md5out, &ctx);
	nmd5 = hexstr2ascii(md5out,16);

	big m,n1,d1,n2,d2,c1,c2;
	miracl *mip;
	mip = mirsys(500, 16);
	m  = mirvar(0);
	n1 = mirvar(0);
	d1 = mirvar(0);
	n2 = mirvar(0);
	d2 = mirvar(0);
	c1 = mirvar(0);
	c2 = mirvar(0);

	mip->IOBASE = 16;

	cinstr(m, nmd5);
	delete [] nmd5;
	cinstr(n1, "B2E88BD13B213871CFFCC666E118A7C47D587A608431C0A15329E9E18BBE5A57D1D24D4B06A0002F14D8C00992351F7AD9CD3F050C48AC68E7A2F0C62D50A8FFBFA4ADD97F9C442BC89F431383E0A31AC1197EFDA52EF930FF8E4F63ED5F51825C25884F6F0009418512805C7EB5611A8EEB96D7C2242536A3640C1ED3B1AC71");
	cinstr(d1, "15");
	cinstr(n2, "E53F3E9868EA12456236D313EF527469026F649C724E4F0C083BDD40BCD78DE61DA568D8FEDBFB6601B4BCFC6E02AA794D8780D779007BE92869EB407091D00A1BB3D69C7732C3CBB37C757C0F0CC4F3A0CF1179E64E4B15F010D33BDC778D4BBB89B764184D9ADD478F16009A92F32494E2E879D938E775C981E8D5B6746EE7");
	cinstr(d2, "C9325E8F88D496408AD82F1CB9D8160EEB72344D120D24571D0ADD3E29FECCACFFABE27F3FFE757FAB53A2E1B0F36A069842AA9371C138FF02D722FF254CF3D5A20B38E62631C40D42F6226C94A3B5C3A3D2DD154933BE8BC60CFA06370A0DB81B3E5ADE5CA072258A509D6E497883A5A52519A30E1EF5801C2C4C3AA04217D1");
	powmod(m,d1,n1,c1);
	powmod(c1,d2,n2,c2);
	cotstr(c2, ser);

	return ser;
}


void DrawBorder(HWND hWnd, int IDENT, PAINTSTRUCT ps)
{
	POINT pt;
	RECT rc;

	GetWindowRect(GetDlgItem(hWnd, IDENT), &rc);
	pt.x = rc.left;
	pt.y = rc.top;
	ScreenToClient(hWnd, &pt);
	rc.left = pt.x;
	rc.top = pt.y;
	pt.x = rc.right;
	pt.y = rc.bottom;
	ScreenToClient(hWnd, &pt);
	rc.right = pt.x;
	rc.bottom = pt.y;
	Rectangle(ps.hdc, rc.left-1,rc.top-1,rc.right+1,rc.bottom+1);

	return;
}

INT_PTR CALLBACK WndProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	PAINTSTRUCT ps;
	HFONT hFont;
	DWORD lpnSize = 255;

	switch (message)
	{
	case WM_INITDIALOG:
		{

			// set fonts
			hFont = CreateFont(12,0,0,0,FW_BOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_OUTLINE_PRECIS,
				CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY, FF_DONTCARE,TEXT("Verdana"));
			SendDlgItemMessage(hDlg, IDC_NAME, WM_SETFONT, (WPARAM)hFont, TRUE);
			SendDlgItemMessage(hDlg, IDC_SERIAL, WM_SETFONT, (WPARAM)hFont, TRUE);
			SendDlgItemMessage(hDlg, IDC_SN, WM_SETFONT, (WPARAM)hFont, TRUE);

			SetDlgItemText(hDlg, IDC_SERIAL, "UUUULLLLLLDDLLUUUUUULLDDLLUUUURRUURRRRRRDDDDDDRRUUUURRUUUULLLLLLLLLLLLDDLLDDDDDDDDRRDDDDLLLLUUUUUUUUUUUUUUUUUURRRRUUUUUULLLLUUUURRRRUUUUUURRDDRRDDRRDDRRDDDDDDLLLLDDLLDDDDRRUURRDDRRUURRUURRUUUUUUUUUUUULLUURRRRDDDDRRRRRRUURRRRDDDDRRDDDDLLDDLLLLLLUUUUUULLDDDDLLDDDDRRRDDRRUURRDDRRRUURRUURRUUUURRDDDDDDDDDDLLLLDDDDDDRRDDLLLLLLDDRRDDLLLLUULLUUUUUURRRRRRUULLLLUULLLLDDDDDDDDLLDDDDDDRRDDRRRRUURRRRDDRRUUUURRRRDDDDLLUU");
			char *s1;
			s1 = GenerateFirst();
			SetDlgItemText(hDlg, IDC_NAME, s1);
			delete [] s1;
			s1 = GenerateThird();
			SetDlgItemText(hDlg, IDC_SN, s1);
			delete [] s1;

			return (INT_PTR)TRUE;
		}



	case WM_NCPAINT:
		BeginPaint(hDlg, &ps);
		DrawBorder(hDlg, IDC_NAME, ps);
		DrawBorder(hDlg, IDC_SERIAL, ps);
		DrawBorder(hDlg, IDC_SN, ps);
		EndPaint(hDlg, &ps);
		return (INT_PTR)0;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}
