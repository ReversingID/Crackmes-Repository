Hello,

Included in this package:

-tutorial (requires Acrobat reader 5.1 minimum)
-Keygen
-Keygen sources (+radasm project)


WARNING: Due to fact that sometimes, serial for PART 2 has strange characters, you'll not be able in certain case to enter your serial in edit box, but the serial given by Keygen IS VALID!!! See tutorial for more information.

Neitsa.