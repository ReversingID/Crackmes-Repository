1. Open crackme in OllyDbg. Search for all intemodular calls GetDlgItemTextA. Found at 4010F7.

Part 1:
004010E7   > 68 FF000000    PUSH 0FF                                 ; /Count = FF (255.); Case 3EA of switch 004010BD
004010EC   . 8D4424 0C      LEA EAX,DWORD PTR SS:[ESP+C]             ; |
004010F0   . 50             PUSH EAX                                 ; |Buffer
004010F1   . 68 E9030000    PUSH 3E9                                 ; |ControlID = 3E9 (1001.)
004010F6   . 57             PUSH EDI                                 ; |hWnd
004010F7   . FF15 F0804000  CALL DWORD PTR DS:[<&USER32.GetDlgItemTe>; \GetDlgItemTextA
004010FD   . 8D4424 08      LEA EAX,DWORD PTR SS:[ESP+8]
00401101   . 8D50 01        LEA EDX,DWORD PTR DS:[EAX+1]
00401104   > 8A08           MOV CL,BYTE PTR DS:[EAX]
00401106   . 40             INC EAX
00401107   . 84C9           TEST CL,CL
00401109   .^75 F9          JNZ SHORT KeyGenMe.00401104
0040110B   . 2BC2           SUB EAX,EDX
0040110D   . 8BC8           MOV ECX,EAX
0040110F   . 80F9 08        CMP CL,8
00401112   . 73 15          JNB SHORT KeyGenMe.00401129
00401114   . 6A 00          PUSH 0                                   ; /Style = MB_OK|MB_APPLMODAL
00401116   . 68 98974000    PUSH KeyGenMe.00409798                   ; |Title = "Failure!"
0040111B   . 68 A4974000    PUSH KeyGenMe.004097A4                   ; |Text = "Input should be at least 8 characters long!"
00401120   . 57             PUSH EDI                                 ; |hOwner
00401121   . FF15 E8804000  CALL DWORD PTR DS:[<&USER32.MessageBoxA>>; \MessageBoxA
00401127   . EB 75          JMP SHORT KeyGenMe.0040119E

What Part 1 does:
Reads input, checks if length is at least 8, if it is goes further
After Part 1 CL is length of entered text

Part 2:
00401129   > C74424 04 0000>MOV DWORD PTR SS:[ESP+4],0
00401131   . 84C9           TEST CL,CL
00401133   . 76 25          JBE SHORT KeyGenMe.0040115A
00401135   . 56             PUSH ESI
00401136   . 33C0           XOR EAX,EAX
00401138   . 0FB6F1         MOVZX ESI,CL
0040113B   . EB 03          JMP SHORT KeyGenMe.00401140
0040113D     8D49 00        LEA ECX,DWORD PTR DS:[ECX]
00401140   > 8A5404 0C      MOV DL,BYTE PTR SS:[ESP+EAX+C]
00401144   . 8BC8           MOV ECX,EAX
00401146   . D1E9           SHR ECX,1
00401148   . 83E1 03        AND ECX,3
0040114B   . 30540C 08      XOR BYTE PTR SS:[ESP+ECX+8],DL
0040114F   . 8D4C0C 08      LEA ECX,DWORD PTR SS:[ESP+ECX+8]
00401153   . 40             INC EAX
00401154   . 83EE 01        SUB ESI,1
00401157   .^75 E7          JNZ SHORT KeyGenMe.00401140
00401159   . 5E             POP ESI
0040115A   > 8B4424 04      MOV EAX,DWORD PTR SS:[ESP+4]

What Part2 does:
Calculates 32-bit input key for entered text (Algorithm is quitely simple)
After Part2 EAX is input key

Part 3:
0040115E   . 50             PUSH EAX
0040115F   . E8 9CFEFFFF    CALL KeyGenMe.00401000

What Part 3 does:
Calls procedure converting input key to output key
After Part 3 EAX is output key

Part 4:
00401164   . 83C4 04        ADD ESP,4
00401167   . 6A 00          PUSH 0                                   ; /Style = MB_OK|MB_APPLMODAL
00401169   . 3D EFBEADDE    CMP EAX,DEADBEEF                         ; |
0040116E   . 75 13          JNZ SHORT KeyGenMe.00401183              ; |
00401170   . 68 D0974000    PUSH KeyGenMe.004097D0                   ; |Title = "Success!"
00401175   . 68 DC974000    PUSH KeyGenMe.004097DC                   ; |Text = "Congratulations!"
0040117A   . 57             PUSH EDI                                 ; |hOwner
0040117B   . FF15 E8804000  CALL DWORD PTR DS:[<&USER32.MessageBoxA>>; \MessageBoxA
00401181   . EB 1B          JMP SHORT KeyGenMe.0040119E
00401183   > 68 98974000    PUSH KeyGenMe.00409798                   ; |Title = "Failure!"
00401188   . 68 F0974000    PUSH KeyGenMe.004097F0                   ; |Text = "You suck!"
0040118D   . 57             PUSH EDI                                 ; |hOwner
0040118E   . FF15 E8804000  CALL DWORD PTR DS:[<&USER32.MessageBoxA>>; \MessageBoxA
00401194   . EB 08          JMP SHORT KeyGenMe.0040119E

Checks output key (must be DEADBEEF for good message), shows good or bad message depending how good we are.

2. In begin I used brute-forcing to find right input key for original output key.
I used assemble in OllyDbg to change program:

00401129   > 90             NOP
....................... NOPs here
00401157   . 90             NOP
00401158   . B8 00000000    MOV EAX,0
0040115D   . 50             PUSH EAX     ; remember what input key is tested
0040115E   . 50             PUSH EAX
0040115F   . E8 9CFEFFFF    CALL cr3.00401000
00401164   . 83C4 04        ADD ESP,4
00401167   . 3D EFBEADDE    CMP EAX,DEADBEEF
0040116C   . 75 15          JNZ SHORT cr3.00401183
0040116E   . 6A 00          PUSH 0                                   ; /Style = MB_OK|MB_APPLMODAL
00401170   . 68 D0974000    PUSH cr3.004097D0                        ; |Title = "Success!"
00401175   . 68 DC974000    PUSH cr3.004097DC                        ; |Text = "Congratulations!"
0040117A   . 57             PUSH EDI                                 ; |hOwner
0040117B   . FF15 E8804000  CALL DWORD PTR DS:[<&USER32.MessageBoxA>>; \MessageBoxA
00401181   . EB 1B          JMP SHORT cr3.0040119E
00401183   > 58             POP EAX
00401184     40             INC EAX
00401185    ^EB D6          JMP SHORT cr3.0040115D

I set breakpoint at 40116e, runned and waited. Then I see to stack to know input key that gives output key DEADBEEF
This Input Key is 21E9BA8F
It was not too easy to find adequate entered text, because of necessity using symbols from second part of ANSI table.
Example of such string is
G�r�Y�A`
(Charcodes 71, 0200, 114, 0200, 89, 0176, 65, 96).

3. To write keygen (brute-force takes too long) let's see at coding procedure

00401012  |. 894424 04      MOV DWORD PTR SS:[ESP+4],EAX
put input key at address esp+4

00401016  |. C70424 32E755B>MOV DWORD PTR SS:[ESP],BA55E732
put some magic word at address esp
magic word is initial value for output key

0040101D  |. B2 04          MOV DL,4
pass counter

0040101F  |. 8D4424 03      LEA EAX,DWORD PTR SS:[ESP+3]
initial position of eax (i=3 in zero based notation)

00401023  |. 56             PUSH ESI
remember esi

00401024  |> 0FB648 04      /MOVZX ECX,BYTE PTR DS:[EAX+4]
reads byte from input key at position i

00401028  |. 8A89 98964000  |MOV CL,BYTE PTR DS:[ECX+409698]
0040102E  |. 3008           |XOR BYTE PTR DS:[EAX],CL
uses array of 256 bytes for xoring i-th byte of output key

00401030  |. 0FB6F1         |MOVZX ESI,CL
00401033  |. 8B34B5 9892400>|MOV ESI,DWORD PTR DS:[ESI*4+409298]
0040103A  |. F7D6           |NOT ESI
0040103C  |. 3170 01        |XOR DWORD PTR DS:[EAX+1],ESI
uses array of 256 dwords for xoring from (i+1)-st byte till end of output key, and from 0-st till i-th byte of input key

0040103F  |. FECA           |DEC DL
00401041  |. 48             |DEC EAX
change position i=i-1

00401042  |. 84D2           |TEST DL,DL
00401044  |.^77 DE          \JA SHORT cr3.00401024
test pass counter

00401046  |. 8B4C24 0C      MOV ECX,DWORD PTR SS:[ESP+C]
0040104A  |. 8B4424 04      MOV EAX,DWORD PTR SS:[ESP+4]
remember output key

0040104E  |. 5E             POP ESI
recover esi

I have noticed that dword at position SS:[ESP+4] after this is allways zero.
This can be used for reversing coding process.

4. Decoding procedure:

eax before procedure contains output key

        push esi
        push 0BA55E732h
        push 0
        push eax
        mov dl,4
        mov eax,esp
   .loop1:
        movzx ecx,byte [eax]
        xor cl, byte [eax+8]
        mov esi,dword [ecx*4+arr2]
        not esi
        xor dword [eax+1],esi
        dec dl
        inc eax
        test dl,dl
        ja .loop1
        pop eax
        pop ecx
        pop eax
        pop esi

ecx after procedure contains input key
arr2 is array of 256 dwords (copy of array located at 409298 in original crackme)

I write simple keygen which uses decimal unsigned integer representation of keys
DEADBEEF is 3735928559
Keygen gives 568965775 which is 21E9BA8F

