CrackMe2in1 - Synok
-------------------
This is a patch n keyme in 1. Patch it first, then find the key.
A valid license file is required.

Worthless info:
Code in C++
Released on 2013-09-22
Not packed

----------
Enjoy - Synok@2013