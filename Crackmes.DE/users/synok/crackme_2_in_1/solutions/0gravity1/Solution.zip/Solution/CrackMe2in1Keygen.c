#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{  
  char name[100];
  int serial = 0;
  int nameLength = 0;
  
  FILE *f = fopen("license.dat", "w");
  if(f == NULL)
  {
      printf("Error opening file!\n");
      system("PAUSE");
      return 0;
  }
  
  printf("Enter you Name: ");
  scanf("%s", name);

  nameLength = strlen(name);
  serial = nameLength * 666;
  serial = serial * 666;
  serial = serial * nameLength;
  serial = serial * 28;
  serial = serial * 2;
  
  fprintf(f, "%d", serial);
  printf("License file created!\n");  
  
  system("PAUSE");	
  return 0;
}
