#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <conio.h>

int main() {
    char name[256]={};
    int serial=0;
    int buff=0;
    printf("Name: ");
    scanf("%s", &name);
    buff = strlen(name) + strlen(name);
    serial = buff + buff;
    printf("Serial: %d", serial);
    getch();
    return 0;
}
