
Target : Synok's CrackMe/KeygenMe #1.
Size : 395KB (Not Packed)
Coded in : C++.

Rules:
1. Main thing is to find a valid Key.
2. Patching is also allowed.
3. No cheating, pure beating. ;)

Keygen or solution included : Yes.

- Synok @ LRG -