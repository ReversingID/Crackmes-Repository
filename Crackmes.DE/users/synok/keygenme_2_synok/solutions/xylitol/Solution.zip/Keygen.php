<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Keygen for Synok's KeyGenMe #2 - By Xyl...</title>
<style type="text/css">
<!--
body,td,th {
	color: #FFF;
}
body {
	background-color: #000;
}
-->
</style></head>

<body>
<p>Yep i'm back...</p>
<form action="Keygen.php" method="get">
<table>
	<tr><td>Name : </td><td><input type="text" name="name" value="Xylitol" /></td></tr>
    <tr><td><input type="submit" value="Gen" /></td><td></td></tr>
</table>
</form>
<?php
	if(isset($_GET['name']))
	{
		$longueur = strlen($_GET['name']);
		echo "<p>Length of the name : $longueur</p>";
		echo '<p>Length*120000 : ' . ($longueur * 120000) . '</p>';
		echo '<p>Length*120000 + Length : ' . ($longueur * 120000 + $longueur) . '</p>';
		echo '<p>Your serial is : ' . ($longueur * 120000 + $longueur) . '</p>';
	}
?>
</body>
</html>
