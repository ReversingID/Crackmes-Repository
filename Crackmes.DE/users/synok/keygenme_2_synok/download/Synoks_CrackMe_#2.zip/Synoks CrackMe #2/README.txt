Synoks CrackME/KeygenME #2

Target : Synok's CrackMe/KeygenMe #2.
Size : 260KB (Not Packed)
Coded in : C++.

Rules:
1. No Patching allowed.
2. Find valid serial.
3. Make KeyGen.

Keygen or solution included : Yes.

Have fun. :)

- Synok @ LRG -