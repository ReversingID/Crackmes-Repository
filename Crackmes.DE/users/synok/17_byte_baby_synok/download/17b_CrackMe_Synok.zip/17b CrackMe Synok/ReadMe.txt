---------------------------------------------------------------

Simple PatchMe By Synok.

What? - Patch the CrackMe.
How?  - No strings only to reduce size. If crash, try again.
Goal? - Patch it so it wont crash.
Size? - 17 bytes only and it's NOT Packed.
Encr? - WONT work with Olly. Need W32Dasm, and a hex editor. ;)
Hard? - Because of the debuggable disfunctions, and hex editing
	I would say this is for the cracker who wants a
	challenge, but it still can be done with just some 
	bytechanges.

Have fun :)

- Synok - 

---------------------------------------------------------------