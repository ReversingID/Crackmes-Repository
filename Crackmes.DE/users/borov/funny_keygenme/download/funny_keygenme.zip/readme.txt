It funny simple keygenme.

Make to demonstrate and teach the work of the processor.

Solution only keygen. One name have many serials.