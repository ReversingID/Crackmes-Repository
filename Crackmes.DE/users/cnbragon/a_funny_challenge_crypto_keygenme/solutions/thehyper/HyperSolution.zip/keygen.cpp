#include "stdafx.h"
#include "big.h"
#ifdef MR_STATIC
#include <string.h>
#endif

int _tmain(int argc, _TCHAR* argv[])
{
	char szName[16],szSerial[240];
    big D,N,E,Name,Serial;
	#ifndef MR_STATIC
		miracl *mip=mirsys(50,0);         /* if allocating from the heap, specify size of bigs here */        
		char *mem=(char*)memalloc(6);            /* allocate and clear memory from the heap for 6 bigs     */
	#else
		miracl *mip=mirsys(MR_STATIC,0);  /* If allocating from the stack, size of bigs is pre-defined */
		char mem[MR_BIG_RESERVE(6)];      /* reserve space on the stack for 6 bigs ...  */
		memset(mem,0,MR_BIG_RESERVE(6));  /* ... and clear this memory */
	#endif
	mip->IOBASE=16;
                /* 7 bigs have index from 0-6  */
	D=mirvar_mem(mem,0);				/* d=8A422E3A08A81F45185A5DEBBE77D81CB40C822AA0ECA663F3E84EA5EFD46FFF858C71F2D5FB3137D13B93532570F36D772356C23FEA51D39A1E7EEB0BB7E208A614526EDCB094B9CF6E260ADE687C01	*/
	N=mirvar_mem(mem,1);				/* n=AE5BB4F266003259CF9A6F521C3C03410176CF16DF53953476EAE3B21EDE6C3C7B03BDCA20B31C0067FFA797E4E910597873EEF113A60FECCD95DEB5B2BF10066BE2224ACE29D532DC0B5A74D2D006F1  */
	Name=mirvar_mem(mem,2);
	Serial=mirvar_mem(mem,3);
	E=mirvar_mem(mem,4);
	
	cinstr(D,"8A422E3A08A81F45185A5DEBBE77D81CB40C822AA0ECA663F3E84EA5EFD46FFF858C71F2D5FB3137D13B93532570F36D772356C23FEA51D39A1E7EEB0BB7E208A614526EDCB094B9CF6E260ADE687C01");
	cinstr(N,"AE5BB4F266003259CF9A6F521C3C03410176CF16DF53953476EAE3B21EDE6C3C7B03BDCA20B31C0067FFA797E4E910597873EEF113A60FECCD95DEB5B2BF10066BE2224ACE29D532DC0B5A74D2D006F1");
	cinstr(E,"10001");
	printf("Name: ");
	scanf("%15s",szName);
	bytes_to_big((int)strlen(szName),szName,Name);
	powmod(Name,D,N,Serial);
	cotstr(Serial,szSerial);
	printf("\nSerial: %s",szSerial);
	OpenClipboard(NULL);
	EmptyClipboard();
	HGLOBAL hglbuffer=GlobalAlloc(GHND,240);
	char* lpBuffer=(char*)GlobalLock(hglbuffer);
	strncpy((char*)lpBuffer,szSerial,239);
	GlobalUnlock(hglbuffer);
	SetClipboardData(CF_TEXT,hglbuffer);
	CloseClipboard();
	printf("\n\nSerial has been copied to clipboard!\n");
	#ifndef MR_STATIC
	    memkill(mem,6);                  /* delete all 6 bigs */
	#else
		memset(mem,0,MR_BIG_RESERVE(6)); /* clear memory used for bigs */
	#endif
	_getch();
	return 0;
}


