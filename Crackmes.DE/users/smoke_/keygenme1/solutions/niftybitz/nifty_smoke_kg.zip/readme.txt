Niftybitz presents:

Fully working key-generator for KeyGenME N1 bY SMoKE [CAiNE '01]

Executable (not encrypted or packed) and assembly sourcecode included.

Ciao,

Niftybitz: niftybitz@yahoo.com