// Keygen for SMoKE KeyGenME N1 by TSCube 17/07/2001

#include <stdio.h>
#include <string.h>


int main(void)
{
	char szName[50];
	char magic1[12] = "B1A4F6920C8";
	char magic2[5] = "KPLT";
	char szTmpSerial[26] = "A0YTR765JUY3KD76DMH3FDJ4M";
	char szSerial[26];
	unsigned int ebpm14=0;
	unsigned int ebpm18=0;
	unsigned int ebpm1C=0;

	printf("Keygen for SMoKE KeyGenME N1 by TSCube 17/07/2001\n\n");
	printf("Name (at least 5 letters) : ");
	gets(szName);
	
	int nameLen = strlen(szName);

	if (nameLen < 5)
	{
		printf("At least 5 letters please !");
		return 1;
	}

	__asm
	{
	mov esi, nameLen
	mov ebx,1
	xor edi,edi
loop1:
	lea     eax, szName
	movzx   eax, byte ptr [eax+ebx-1]
	add		dword ptr [ebpm14], eax
	inc     ebx
	dec     esi
	jnz     short loop1

//end_loop1:
	mov     ebx, 1
	jmp     short loop2_1

loop2:
	lea     eax, szName
	movzx   eax, byte ptr [eax+ebx-1]
	add     edi, eax
	add     ebx, 2
 
loop2_1:
	mov		eax, nameLen
	cmp     ebx, eax
	jle     short loop2
	mov     ebx, 2
	jmp     short loop3_1

loop3:
	lea     eax, szName
	movzx   eax, byte ptr [eax+ebx-1]
	add     dword ptr [ebpm18], eax
	add     ebx, 2
 
loop3_1:
	mov		eax, nameLen
	cmp     ebx, eax
	jle     short loop3

	mov     eax, edi
	imul    dword ptr [ebpm18]
	mov     dword ptr [ebpm1C], eax
	mov     ebx, 1
	jmp     short loop4_1

loop4:
	mov     eax, dword ptr [ebpm1C]
	mov     ecx, 0Bh
	cdq
	idiv    ecx
	mov     dword ptr [ebpm1C], eax
	mov     eax, dword ptr [ebpm1C]
	mov     ecx, 0Bh
	cdq
	idiv    ecx
	mov     esi, edx
	lea     eax, szTmpSerial
	mov     edx, 0Bh
	sub     edx, esi
	mov dl, byte ptr magic1[edx-1]
	mov     [eax+ebx-1], dl
	add     ebx, 2

loop4_1:
	cmp     dword ptr [ebpm1C], 0
	jz      short end_loop4
	cmp     ebx, 19h
	jle     short loop4

end_loop4:
	mov     ebx, 19h
	jmp     short loop5_1

loop5:
	mov     eax, edi
	mov     ecx, 0Bh
	cdq
	idiv    ecx
	mov     edi, eax
	mov     eax, edi
	mov     ecx, 0Bh
	cdq
	idiv    ecx
	mov     esi, edx
	lea     eax, szTmpSerial
	mov     edx, 0Bh
	sub     edx, esi
	mov dl, byte ptr magic1[edx-1]
	mov     [eax+ebx-1], dl
	dec     ebx

loop5_1:
	test    edi, edi
	jz      short end_loop5
	cmp     ebx, 1
	jg      short loop5

end_loop5:
	mov     ebx, 1
	jmp     short loop6_3
 
loop6:
	mov     eax, dword ptr [ebpm18]
	test    eax, eax
	jns     short loop6_1
	add     eax, 3

loop6_1:
	sar     eax, 2
	mov     dword ptr [ebpm18], eax
	mov     esi, dword ptr [ebpm18]
	and     esi, 80000003h
	jns     short loop6_2
	dec     esi
	or      esi, 0FFFFFFFCh
	inc     esi

loop6_2:
	lea     eax, szTmpSerial
	mov     edx, 4
	sub     edx, esi
	mov     dl, byte ptr magic2[edx-1]
	mov     [eax+ebx-1], dl
	add     ebx, 2
 
loop6_3:
	cmp     dword ptr [ebpm18], 0
	jz      short end_loop6
	cmp     ebx, 19h
	jle     short loop6

end_loop6:
	mov		eax,nameLen
	mov     esi, eax
	test    esi, esi
	jle     short end_loop7
	mov     ebx, 1
 
loop7:
	lea     eax, szName
	movzx   edi, byte ptr [eax+ebx-1]
	mov     eax, edi
	mov     ecx, 0Bh
	cdq
	idiv    ecx
	mov     edi, edx
	lea     eax, szTmpSerial
	mov     edx, 0Bh
	sub     edx, edi
	mov dl, byte ptr magic1[edx-1]
	mov     [eax+ebx-1], dl
	inc     ebx
	dec     esi
	jnz     short loop7
 
end_loop7:
	mov		eax, nameLen
	mov     ebx, eax
	cmp     ebx, 1
	jl      short end_loop8

loop8:
	lea     eax,szName
	movzx   edi, byte ptr [eax+ebx-1]
	and     edi, 80000003h
	jns     short loop8_1
	dec     edi
	or      edi, 0FFFFFFFCh
	inc     edi

loop8_1:
	lea     eax, szTmpSerial
	mov     edx, ebx
	sar     edx, 1
	jns     short loop8_2
	adc     edx, 0

loop8_2:
	mov     ecx, 0Ch
	sub     ecx, edx
	mov     edx, 4
	sub     edx, edi
	mov dl, byte ptr magic2[edx-1]
	mov     [eax+ecx-1], dl
	dec     ebx
	test    ebx, ebx
	jnz     short loop8
 
end_loop8:
	mov		eax, nameLen
	mov     esi, eax
	test    esi, esi
	jle     short end_loop9
	mov     ebx, 1

loop9:
	lea     eax, szTmpSerial
	lea		edx, szName
	movzx   edx, byte ptr [edx+ebx-1]
	mov     ecx, dword ptr [ebpm14]
	sub     ecx, edx
	and     ecx, 80000003h
	jns     short loop9_1
	dec     ecx
	or      ecx, 0FFFFFFFCh
	inc     ecx

loop9_1:
	mov     edx, 4
	sub     edx, ecx
	mov dl, byte ptr magic2[edx-1]
	mov     [eax+ebx-1], dl
	inc     ebx
	dec     esi
	jnz     short loop9

end_loop9:
	mov     ebx, 0Dh
	jmp     short loop10_2

loop10:
	lea     eax, szTmpSerial
	lea     eax, [eax+ebx-1]
	push    eax
	mov     eax, dword ptr [ebpm14]
	mov     ecx, 0Bh
	cdq
	idiv    ecx
	
	mov al, byte ptr magic1[edx-1]
	
	pop     edx
	mov     byte ptr [edx], al
	mov     eax, dword ptr [ebpm14]
	sar     eax, 1
	jns     short loop10_1
	adc     eax, 0

loop10_1:
	mov     dword ptr [ebpm14], eax
	inc     ebx

loop10_2:
	cmp     dword ptr [ebpm14], 0
	jz      short end_loop10
	cmp     ebx, 19h
	jle     short loop10

end_loop10:
	mov		eax,nameLen
	mov     esi, eax
	sar     esi, 1
	jns     short loc_45C22B
	adc     esi, 0

loc_45C22B:
	sub     esi, 0Dh
	jg      short end_loop11
	dec     esi
	mov     ebx, 0Dh

loop11:
	lea     eax, szTmpSerial
	lea     eax, [eax+ebx-1]
	push    eax
	lea     eax, szTmpSerial
	movzx   eax, byte ptr [eax+ebx-1]
	mov     ecx, 0Bh
	xor     edx, edx
	div     ecx
	
	mov al, byte ptr magic1[edx-1]
	pop     edx
	mov     byte ptr [edx], al
	dec     ebx
	inc     esi
	jnz     short loop11

end_loop11:
	}

	// Remove useless 0x00 bytes from serial
	for (int index1=0,index2=0;index1<26;index1++)
	{
		if (szTmpSerial[index1] != 0x00) szSerial[index2++] = szTmpSerial[index1];
	}
	szSerial[index2]=0x00;


	printf("Serial = %s",szSerial);
	getchar();
	return 0;
}
