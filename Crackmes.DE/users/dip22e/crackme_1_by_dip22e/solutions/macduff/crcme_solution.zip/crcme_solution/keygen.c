#include <stdio.h>

int main() {
	int length = 8;
	int start = 97;
	int i = 0;
	for (i=0; i<8; i++) {
		int temp = start;
		while (temp % length != 0 && temp <= 122) {
			temp++;
		}
		printf("%c", temp);
		length--;
	}
	printf("\n");
}
	