void print_random()
{
	int i, c = 8, n;

	for (i=1; i<ITERATIONS ; i++) {
		n = (0x61 + 0x19 * rand() / (RAND_MAX + 1));

		if (n % c == 0) {
			printf("%c", n);
			c == 1 ? c = 8, printf("\n") : c--;
		}
	}
}