#pragma comment(linker, "\"/manifestdependency:type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='X86' publicKeyToken='6595b64144ccf1df' language='*'\"")

#include <fstream>
#include <iostream>
#include <ctime>
#include <tchar.h>
#include <windows.h>
#include "resource.h"

void OnRandom(HWND dialog)
{
	TCHAR serial[9];
	serial[0] = 104 + (rand() %  3) * 8;
	serial[1] = 98  + (rand() %  4) * 7;
	serial[2] = 102 + (rand() %  4) * 6;
	serial[3] = 100 + (rand() %  5) * 5;
	serial[4] = 100 + (rand() %  6) * 4;
	serial[5] = 99  + (rand() %  8) * 3;
	serial[6] = 98  + (rand() % 13) * 2;
	serial[7] = 97  + (rand() % 26);
	serial[8] = '\0';

	SetDlgItemText(dialog, IDC_SERIAL, serial);

	if (OpenClipboard(dialog))
	{
		HANDLE hMem = GlobalAlloc(GMEM_MOVEABLE, 9 * sizeof(TCHAR));
		LPTSTR data = reinterpret_cast<LPTSTR>(GlobalLock(hMem));
		_tcscpy_s(data, 9, serial);
		GlobalUnlock(hMem);
		
		EmptyClipboard();
		SetClipboardData(CF_UNICODETEXT, hMem);
		CloseClipboard();
	}
	else
	{
		MessageBox(dialog, _T("Clipboard cannot be opened!"), _T("Warning!"), MB_ICONEXCLAMATION | MB_OK);
	}
}

LRESULT CALLBACK DlgProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM)
{
    switch(msg)
    {
	case WM_COMMAND:
		switch(wparam)
		{
		case IDC_RANDOM:
			OnRandom(hwnd);
			break;
		case IDCANCEL:
			EndDialog(hwnd, 0);
		}
		return TRUE;

	case WM_CLOSE:
		EndDialog(hwnd, 0);
		return true;

	default:
		return FALSE;
    }
}

INT WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
	srand(static_cast<unsigned int>(time(NULL)));
	DialogBoxParam(NULL, MAKEINTRESOURCE(IDD_DIALOG), NULL, (DLGPROC)DlgProc, NULL);

	return 0;
}