Oh crap...
Guys on crackmes.de already rejected two of my crackmes.
They said they were too easy to solve.Well, I hope they'll like this one.

Anyway,this is a Crypto Name/Company/Serial keygenme.It uses a combination of several encryption algos.

Your task:
1)Make a Keygen(I know it'll be tough, but try anyway)
2)Write a tut and post it on crackmes.de

Good luck. You will need some.
;-P


C0deHaz4rd