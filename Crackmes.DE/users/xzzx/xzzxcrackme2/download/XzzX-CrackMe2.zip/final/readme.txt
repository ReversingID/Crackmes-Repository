*******************************************
************** XzzX#CrackMe2 **************
*******************************************

author    : XzzX
created   : 02/06/2007
language  : Assembler / MASM

difficulty: 4/10
goal      : write a keygen (has to work with patched and unpatched CrackMe)
	    patch the advertisement

info      : no fake code
	    straight algo

I know I could have made it harder but my goal was to make an interesting CrackMe not an impossible one.

If you encounter a problem/bug/question/etc feel free to write a comment or send me a pm.

Please send me your solution when you've solved it. ;-)

gl&hf
XzzX