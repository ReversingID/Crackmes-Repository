*******************************************
************** XzzX#CrackMe4 **************
*******************************************

author    : XzzX
created   : 19/07/2007
language  : Assembler / MASM

difficulty: 5/10

goal      : write a keygen, which works for EVERY name

rules     : absolutly no patching ;-)

info      : CrackMe is solvable ;-)

You have to solve a first problem to get the CrackMe running!!!

If you encounter a problem/bug/question/etc feel free to write a comment or send me a pm.

Please send me your solution when you've solved it. ;-)

gl&hf
XzzX

Music     : "Sun Symbolizing Song" by nitzer