// XzzX3.h : main header file for the XZZX3 application
//

#if !defined(AFX_XZZX3_H__83513F31_C1F7_4302_9B10_FDE2377018A3__INCLUDED_)
#define AFX_XZZX3_H__83513F31_C1F7_4302_9B10_FDE2377018A3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CXzzX3App:
// See XzzX3.cpp for the implementation of this class
//

class CXzzX3App : public CWinApp
{
public:
	CXzzX3App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CXzzX3App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CXzzX3App)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_XZZX3_H__83513F31_C1F7_4302_9B10_FDE2377018A3__INCLUDED_)
