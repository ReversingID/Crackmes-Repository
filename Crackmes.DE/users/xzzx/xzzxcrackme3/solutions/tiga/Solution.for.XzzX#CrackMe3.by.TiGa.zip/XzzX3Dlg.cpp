// XzzX3Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "XzzX3.h"
#include "XzzX3Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CXzzX3Dlg dialog

CXzzX3Dlg::CXzzX3Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CXzzX3Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CXzzX3Dlg)
	m_sName = _T("");
	m_sUserName = _T("");
	m_sSerial = _T("");
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CXzzX3Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CXzzX3Dlg)
	DDX_Control(pDX, IDC_BGENERATE, m_ctlBgenerate);
	DDX_Text(pDX, IDC_ENAME, m_sName);
	DDX_Text(pDX, IDC_EUSERNAME, m_sUserName);
	DDX_Text(pDX, IDC_ECMDLINE, m_sSerial);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CXzzX3Dlg, CDialog)
	//{{AFX_MSG_MAP(CXzzX3Dlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_EN_CHANGE(IDC_ENAME, OnChangeEname)
	ON_BN_CLICKED(IDC_BGENERATE, OnBgenerate)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CXzzX3Dlg message handlers

BOOL CXzzX3Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	char cUserName[32767];
	DWORD iCharCount = sizeof(cUserName);

	GetUserName(cUserName, &iCharCount);
	m_sUserName = cUserName;

	UpdateData(false);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CXzzX3Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CXzzX3Dlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CXzzX3Dlg::OnChangeEname() 
{
	UpdateData(true);

	if (m_sName.GetLength() < 8)
		m_ctlBgenerate.EnableWindow(false);
	else
		m_ctlBgenerate.EnableWindow(true);

	m_sSerial.Empty();

	UpdateData(false);	
}

void CXzzX3Dlg::OnBgenerate() 
{
	//Declaring Variables
	CString sName(m_sName), sUserName(m_sUserName), sSerial(""), sTable("C456.,NO0jUVR:Axyz;vwB)klm!?(1duDEILMSTfi a78J3KbceHo2qrgphstPQnFGWXYZ9");
	int iTemp1 = -1, iTemp2 = -1, iTemp3 = -1;

	//Calculating Serial
	for (int i = 0, j = 0; i < sName.GetLength(); i++)
	{
		iTemp1 = sTable.Find(sName[i]);

		//If Char is found in String
		if (iTemp1 != -1)
		{
			//Reset UserName CharCounter
			if (j >= sUserName.GetLength())
				j = 0;

			iTemp2 = sTable.Find(sUserName[j++]);

			//Reverse Modulo
			if (iTemp1 < iTemp2)
				iTemp1 += 0x47;

			iTemp3 = iTemp1 - iTemp2;

			sSerial += sTable[iTemp3];
		}
		else
			sSerial += sName[i];
	}

	//Output as Command Line
	m_sSerial = "XzzX#CrackMe3.exe \"" + sName + "\" \"" + sSerial+ "\"";
	UpdateData(false);
}
