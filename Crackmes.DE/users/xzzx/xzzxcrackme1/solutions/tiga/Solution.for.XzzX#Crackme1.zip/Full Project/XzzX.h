// XzzX.h : main header file for the XZZX application
//

#if !defined(AFX_XZZX_H__E0D6F5CD_6113_4478_BD7F_1FCA499A7CA9__INCLUDED_)
#define AFX_XZZX_H__E0D6F5CD_6113_4478_BD7F_1FCA499A7CA9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CXzzXApp:
// See XzzX.cpp for the implementation of this class
//

class CXzzXApp : public CWinApp
{
public:
	CXzzXApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CXzzXApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CXzzXApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_XZZX_H__E0D6F5CD_6113_4478_BD7F_1FCA499A7CA9__INCLUDED_)
