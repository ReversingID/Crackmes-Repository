﻿Imports Microsoft.VisualBasic.CompilerServices
Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim chArray As Char() = New Char() {"i"c, "w"c, "a"c, "n"c, "t"c, "i"c, "n"c}
        Dim chArray2 As Char() = New Char() {"2"c, "0"c, "0"c, "7"c}
        Dim str As String = Strings.StrConv(New String(Conversions.ToCharArrayRankOne((New String(chArray2) & New String(chArray)))), VbStrConv.Uppercase, 0)

        TextBox1.Text = str
    End Sub
End Class
