#include <iostream>
#include <string>

using std::string;
using std::cout;
using std::cin;
using std::endl;

void GetSerial(string &name, string &ret) {
	int temp[5] = { 0 };
	int len = name.length();
	//------

	if(len >= 4) {
		ret.clear();
		ret.resize(6);

		for(int i = 0; i < len; i++) {
			/*
			004018A8    .  	0185 60FDFFFF     	ADD DWORD PTR SS:[EBP-2A0],EAX  <- char 1
			004018AE    .  	89CA              	MOV EDX,ECX
			004018B0    .  	0FAFD0            	IMUL EDX,EAX
			004018B3    .  	0195 5CFDFFFF     	ADD DWORD PTR SS:[EBP-2A4],EDX 	<- char 2
			004018B9    .  	89CA              	MOV EDX,ECX
			004018BB    .  	31C2              	XOR EDX,EAX
			004018BD    .  	0195 58FDFFFF     	ADD DWORD PTR SS:[EBP-2A8],EDX 	<- char 3
			004018C3    .  	89C2              	MOV EDX,EAX
			004018C5    .  	81CA 01010101     	OR EDX,1010101
			004018CB    .  	0195 54FDFFFF     	ADD DWORD PTR SS:[EBP-2AC],EDX 	<- char 4
			004018D1    .  	31D2             	XOR EDX,EDX
			004018D3    .  	F7F1              	DIV ECX
			004018D5    .  	0FB685 4FFDFFFF   	MOVZX EAX,BYTE PTR SS:[EBP-2B1] <- char 5
			004018DC    .  	0195 50FDFFFF     	ADD DWORD PTR SS:[EBP-2B0],EDX
			*/
			temp[0] += name[i];
			temp[1] += name[i] * len;
			temp[2] += name[i] ^ len;
			temp[3] += name[i] | 0x1010101;
			temp[4] += name[i] % len;
		}
		for(int i = 0; i < 5; i++) {
			// Ensure each character is printable.
			int temp2;
			if(temp[i] < 0) {
				temp2 = temp[i] + 63;
			} else {
				temp2 = temp[i];
			}
			temp2 = temp[i] - (temp2 & 0xFFFFFFC0);
			if( temp2 > 0x19) {
				if((temp2 - 26) > 0x19) {
					if((temp2 - 52) <= 9) {
						ret[i] = temp2 - 4;
					} else {
						ret[i] = 45;
						if(temp2 != 62) {
							ret[i] = 95;
						}
					}
				} else {
					ret[i] = temp2 + 39;
				}
			} else {
				ret[i] = temp2 + 97;
			}
		}
	} else {
		ret = "Name must be at least 4 characters in length!";
	}
}

int main()
{
	string name, serial;
	//-------

	for(;;) {
		cout << "Name: ";
		cin >> name;
		GetSerial(name, serial);
		cout << "Serial: " << serial << endl;
	}
	cin.sync();
	cin.ignore();
	return 0;
}

