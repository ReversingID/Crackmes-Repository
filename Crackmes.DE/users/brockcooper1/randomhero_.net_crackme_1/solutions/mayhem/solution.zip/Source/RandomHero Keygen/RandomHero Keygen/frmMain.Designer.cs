﻿namespace RandomHero_Keygen
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.p = new System.Windows.Forms.Panel();
            this.lTitle = new System.Windows.Forms.Label();
            this.lMinimize = new System.Windows.Forms.Label();
            this.lClose = new System.Windows.Forms.Label();
            this.lName = new System.Windows.Forms.Label();
            this.lSerial = new System.Windows.Forms.Label();
            this.tName = new System.Windows.Forms.TextBox();
            this.tSerial = new System.Windows.Forms.TextBox();
            this.p.SuspendLayout();
            this.SuspendLayout();
            // 
            // p
            // 
            this.p.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(70)))));
            this.p.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p.Controls.Add(this.lTitle);
            this.p.Controls.Add(this.lMinimize);
            this.p.Controls.Add(this.lClose);
            this.p.Location = new System.Drawing.Point(-1, -1);
            this.p.Name = "p";
            this.p.Size = new System.Drawing.Size(347, 23);
            this.p.TabIndex = 0;
            this.p.MouseDown += new System.Windows.Forms.MouseEventHandler(this.p_MouseDown);
            // 
            // lTitle
            // 
            this.lTitle.AutoSize = true;
            this.lTitle.Font = new System.Drawing.Font("Comfortaa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(234)))), ((int)(((byte)(234)))));
            this.lTitle.Location = new System.Drawing.Point(71, 2);
            this.lTitle.Name = "lTitle";
            this.lTitle.Size = new System.Drawing.Size(155, 19);
            this.lTitle.TabIndex = 5;
            this.lTitle.Text = "RandomHero Keygen";
            this.lTitle.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lTitle_MouseDown);
            // 
            // lMinimize
            // 
            this.lMinimize.AutoSize = true;
            this.lMinimize.BackColor = System.Drawing.Color.Transparent;
            this.lMinimize.Font = new System.Drawing.Font("Comfortaa", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lMinimize.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(234)))), ((int)(((byte)(234)))));
            this.lMinimize.Location = new System.Drawing.Point(308, -3);
            this.lMinimize.Name = "lMinimize";
            this.lMinimize.Size = new System.Drawing.Size(19, 23);
            this.lMinimize.TabIndex = 4;
            this.lMinimize.Text = "_";
            this.lMinimize.Click += new System.EventHandler(this.lMinimize_Click);
            this.lMinimize.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lMinimize_MouseDown);
            this.lMinimize.MouseUp += new System.Windows.Forms.MouseEventHandler(this.lMinimize_MouseUp);
            // 
            // lClose
            // 
            this.lClose.AutoSize = true;
            this.lClose.Font = new System.Drawing.Font("Comfortaa", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lClose.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(234)))), ((int)(((byte)(234)))));
            this.lClose.Location = new System.Drawing.Point(326, -3);
            this.lClose.Name = "lClose";
            this.lClose.Size = new System.Drawing.Size(22, 25);
            this.lClose.TabIndex = 0;
            this.lClose.Text = "x";
            this.lClose.Click += new System.EventHandler(this.lClose_Click);
            this.lClose.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lClose_MouseDown);
            this.lClose.MouseUp += new System.Windows.Forms.MouseEventHandler(this.lClose_MouseUp);
            // 
            // lName
            // 
            this.lName.AutoSize = true;
            this.lName.Font = new System.Drawing.Font("Mini Kaliber S TT BRK", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.lName.Location = new System.Drawing.Point(12, 56);
            this.lName.Name = "lName";
            this.lName.Size = new System.Drawing.Size(53, 19);
            this.lName.TabIndex = 0;
            this.lName.Text = "Name:";
            // 
            // lSerial
            // 
            this.lSerial.AutoSize = true;
            this.lSerial.Font = new System.Drawing.Font("Mini Kaliber S TT BRK", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lSerial.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.lSerial.Location = new System.Drawing.Point(12, 88);
            this.lSerial.Name = "lSerial";
            this.lSerial.Size = new System.Drawing.Size(57, 19);
            this.lSerial.TabIndex = 1;
            this.lSerial.Text = "Serial:";
            // 
            // tName
            // 
            this.tName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(70)))));
            this.tName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tName.Font = new System.Drawing.Font("Arial Rounded MT Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(234)))), ((int)(((byte)(234)))));
            this.tName.Location = new System.Drawing.Point(71, 57);
            this.tName.Multiline = true;
            this.tName.Name = "tName";
            this.tName.Size = new System.Drawing.Size(263, 22);
            this.tName.TabIndex = 2;
            this.tName.Text = "Mayhem";
            this.tName.TextChanged += new System.EventHandler(this.tName_TextChanged);
            // 
            // tSerial
            // 
            this.tSerial.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(70)))));
            this.tSerial.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tSerial.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tSerial.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tSerial.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(234)))), ((int)(((byte)(234)))));
            this.tSerial.Location = new System.Drawing.Point(71, 89);
            this.tSerial.Multiline = true;
            this.tSerial.Name = "tSerial";
            this.tSerial.ReadOnly = true;
            this.tSerial.Size = new System.Drawing.Size(263, 22);
            this.tSerial.TabIndex = 3;
            this.tSerial.Click += new System.EventHandler(this.tSerial_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(346, 133);
            this.Controls.Add(this.tSerial);
            this.Controls.Add(this.tName);
            this.Controls.Add(this.lSerial);
            this.Controls.Add(this.lName);
            this.Controls.Add(this.p);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RandomHero KeyGen";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.p.ResumeLayout(false);
            this.p.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel p;
        private System.Windows.Forms.Label lName;
        private System.Windows.Forms.Label lSerial;
        private System.Windows.Forms.TextBox tName;
        private System.Windows.Forms.TextBox tSerial;
        private System.Windows.Forms.Label lClose;
        private System.Windows.Forms.Label lMinimize;
        private System.Windows.Forms.Label lTitle;
    }
}

