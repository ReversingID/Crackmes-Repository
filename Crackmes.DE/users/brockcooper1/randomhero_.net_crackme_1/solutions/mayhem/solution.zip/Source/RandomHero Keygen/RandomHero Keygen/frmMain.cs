﻿using System;
using System.IO;
using System.Text;
using System.Drawing;
using System.Reflection;
using System.Drawing.Text;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Runtime.InteropServices;

namespace RandomHero_Keygen
{
    public partial class frmMain : Form
    {
        // Some DLL imports.
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = false)]
        static extern IntPtr SendMessage(IntPtr hWnd, uint Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll", CharSet = CharSet.Auto, SetLastError = false)]
        public static extern bool ReleaseCapture();
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(int nLeftRect, int nTopRect, int nRightRect, int nBottomRect, int nWidthEllipse, int nHeightEllipse);

        PrivateFontCollection private_fonts = new PrivateFontCollection();
        private void LoadFont(string name)
        {
            // Load the specified font.
            string resource = name;
            // Recieve the resource stream.
            Stream fontStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resource);
            // Create mem block for the data.
            System.IntPtr data = Marshal.AllocCoTaskMem((int)fontStream.Length);
            // Create read buffer
            byte[] fontdata = new byte[fontStream.Length];
            // Read data
            fontStream.Read(fontdata, 0, (int)fontStream.Length);
            // Copy bytes to unsafe mem block
            Marshal.Copy(fontdata, 0, data, (int)fontStream.Length);
            // Pass font to the collection
            private_fonts.AddMemoryFont(data, (int)fontStream.Length);
            // Close the stream
            fontStream.Close();
            // Free the memory
            Marshal.FreeCoTaskMem(data);
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams p = base.CreateParams;
                p.ClassStyle |= 0x00020000;
                return p;
            }
        }

        public string GetMD5Hash(string input)
        {
            byte[] buffer = MD5.Create().ComputeHash(Encoding.Default.GetBytes(input));
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < buffer.Length; i++)
            {
                builder.Append(buffer[i].ToString("x2"));
            }
            return builder.ToString();
        }

        public string getSerial(string name)
        {
            string str = "iPA";
            string input = name.ToString();
            string str7 = this.GetMD5Hash(input).Insert(2, " ").Insert(4, " ").Replace(" ", "Z").ToUpper();
            string str8 = str + str7;
            string str9 = this.GetMD5Hash(str8);

            return str9;
        }

        public frmMain()
        {
            InitializeComponent();
            // Draw a rounded form.
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width - 0, Height - 0, 6, 6));

            // Load fonts..
            LoadFont("RandomHero_Keygen.ComfortaaBold.ttf");
            LoadFont("RandomHero_Keygen.ARLRDBD.TTF");
            LoadFont("RandomHero_Keygen.minikstt.ttf");

            lTitle.Font = new Font(private_fonts.Families[1], 12, FontStyle.Bold);
            lMinimize.Font = new Font(private_fonts.Families[1], 14, FontStyle.Bold);
            lClose.Font = new Font(private_fonts.Families[1], 16, FontStyle.Bold);
            lName.Font = new Font(private_fonts.Families[2], 15);
            lSerial.Font = new Font(private_fonts.Families[2], 15);
            tName.Font = new Font(private_fonts.Families[0], 11, FontStyle.Regular);
            tSerial.Font = new Font(private_fonts.Families[0], 10, FontStyle.Regular);

            lTitle.UseCompatibleTextRendering = true;
            lMinimize.UseCompatibleTextRendering = true;
            lClose.UseCompatibleTextRendering = true;
            lName.UseCompatibleTextRendering = true;
            lSerial.UseCompatibleTextRendering = true;
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            // Panel width.
            p.Width = this.Width + 1;
            // Center title.
            lTitle.Location = new Point(((this.Width - lTitle.Width) / 2), 1);
            // Set default serial.
            tSerial.Text = getSerial("Mayhem");
            // Set something other than the textbox to start..
            lTitle.Select();
        }

        private void lClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void lClose_MouseDown(object sender, MouseEventArgs e)
        {
            lClose.ForeColor = Color.FromArgb(50, 50, 50);
        }

        private void lClose_MouseUp(object sender, MouseEventArgs e)
        {
            lClose.ForeColor = Color.FromArgb(234, 234, 234);
        }

        private void lMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void lMinimize_MouseDown(object sender, MouseEventArgs e)
        {
            lMinimize.ForeColor = Color.FromArgb(50, 50, 50);
        }

        private void lMinimize_MouseUp(object sender, MouseEventArgs e)
        {
            lMinimize.ForeColor = Color.FromArgb(234, 234, 234);
        }

        private void p_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(this.Handle, 0xa1, 0x2, 0);
            }
        }

        private void lTitle_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(this.Handle, 0xa1, 0x2, 0);
            }
        }

        private void tName_TextChanged(object sender, EventArgs e)
        {
            if (tName.Text != "")
            {
                tSerial.Text = getSerial(tName.Text);
            }
            else
            {
                tSerial.Text = "Name too short..";
            }
        }

        private void tSerial_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(tSerial.Text);
        }
    }
}
