_Nordic_'s 2nd crackme (keygenme...)

This crackme is a bit harder than the first,
but it should be well within "newbie-level".
No crypto, no packing, no debugger protection,
just plain byte-flipping in asm.
The keys are machine-dependent, as will be
immediately obvious as soon as you disasm it :-)

Write a keygen, fishing a serial or patching 
is just too easy (or maybe not  :-)

You can contact me in #tmg2001, and maybe #c4n

_Nordic_/TMG 