﻿using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Windows;
using System.Windows.Controls;

namespace KeyGen {
	
	public partial class MainWindow : Window {

		public MainWindow () {
			InitializeComponent();
			this.tbName.Text = "Name";
		}

		private void GetSerial (object sender, TextChangedEventArgs e) {
			// Get hash of name (hash = moddedSerial)
			MD5 md5 = MD5.Create();
			byte[] hash = md5.ComputeHash(Encoding.Default.GetBytes(this.tbName.Text));

			// Re-mod serial
			byte[] serial = new byte[16];
			byte[] serialMods = new byte[] { 15, 58, 143, 50, 67, 61, 164, 53, 35, 244, 178, 60, 88, 93, 77, 23 };

			for (int n = 0; n < serial.Length; n++) {
				serial[n] = (byte)(hash[n] ^ serialMods[n]);
			}

			this.tbSerial.Text = string.Join("", serial
				.Select((byte b) => b.ToString("X2"))
				.ToArray());
		}
	}
}
