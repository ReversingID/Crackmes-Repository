public class KeyGen1
{
	public static void Main()
	{
		System.Console.WriteLine("Password: " + System.Environment.MachineName + "-" + System.DateTime.Now.Year.ToString() + System.DateTime.Now.Hour.ToString() + "-" + System.Environment.UserName.ToUpper());
	}
}