=======================
- CrackMe2 by timeleg -
=======================
Hi crackmes.de community,
This is my second crackme. It's easy. 

Difficulty: 1 - Very easy, for newbies
Goal:       1. Understand how program and verification algorithm works.
               Don't patch verification algorithm.
            2. Find a valid password.
            3. Write a tutorial and keygen.

have fun and enjoy !
timeleg86@gmail.com

{Slovak}
Zdravim Vas, crackme2 je jednoduche. Patri do celku mojej diplomovej prace, tak Vas prosim pozrite a okometujte. Dakujem.
timeleg