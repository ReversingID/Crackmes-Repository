=======================
- CrackMe5 by timeleg -
=======================
Hi crackmes.de community,
This is my fifth crackme. It's moderately difficult. 

Difficulty: 2 -Needs a little brain (or luck) 
Goal:       1. Understand how program and verification algorithm works.
               Don't patch verification algorithm.
            2. Find a valid password.
            3. Write tutorial and keygen.

have fun and enjoy !
timeleg86@gmail.com

{Slovak}
Zdravim Vas, crackme5 je mierne zlozitejsie. Patri do celku mojej diplomovej prace, tak Vas prosim pozrite a okometujte. Dakujem.
timeleg