Hey, 

This keygenme is now around seven years old, but I 
still dont think it's too easy. But if you figure 
out what is going on, it shouldnt be hard. 

The point is to figure out what kindof sortof
algo this is using and reproduce it, prefered is 
a tutorial and source in alot nicer language. 

Next challenge is very interesting, but I will 
not update until this one is soved... 

Good luck!