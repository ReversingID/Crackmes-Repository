

	Hey...! 

	This is a very nice little crackme, it's not ment for the leet 
	  crypto geniuses, but it's not for the totally newbie either. 

	It's not packed, there is no tricks, no anti debugging and it's 
	  written in assembly languange, so it should be easy to read.

	No patching! It's a keygenme, what do you u expect?




	Best regards, 

	Trevil // FHCF!
