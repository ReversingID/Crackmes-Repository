Hello everybody,

this is the solution for this http://www.crackmes.de/users/trevil/trevils_keyegnme_2/ Keygenme.


Solution:

First I opened the Keygenme in OllyDbg. I searched for the API call to GetDlgItemText and found some calls.
And voila there was the function which checked the Key. I found out, that the keygenme first checks the Input Boxes A and B.
The String in this Input Boxes should be 10 CHaracters long and can only contain numbers, otherwise the Programm would break with an error message.
After the Check the Programm generates a "checksum" for both numbers. The formula for this "checksum" is:
checksum = ((checksum * 4 + checksum) * 2 + (Ascii character - 0x30))
Checksum is at first 0 and increases with every Character of the String.

After this the Keygenme transforms the Key in another Format so that every character is represented by one nibble (4 Bit).
The formula for this calculation is:
result = (Ascii character - 0x57) & 0x0F
or if the Ascii value is below 0x57:
result = (Ascii character - 0x30) & 0x0F

From the resulting eight DWORDs the Keygenme generates the Username for the Key. Then the Keygenme compares the given Username to check whether
the key is right or not. The calculated Username has 32 Characters but it's a string which means that it ends at the first zero byte.
The rest of the calculated Username doesn't matter.
The Username is calculated with four independent blocks. The max length of the Username is 24 Characters which means that the
last block of the key (the last 16 bytes) are only used if the user uses a 24 Character Username (because the 25th character have to be a zero byte and would be in the last block).

The username from user and the generated username are compared with a strinf compare.