/*
This file includes only the function which generates the Key. All Other functions (like creating the dialog) are not included.

The Keygenme for this Keygen is copyright by Trevil and available at http://www.crackmes.de/users/trevil/trevils_keyegnme_2/.

Solution Copyright 2010 by The-God-of-all
*/

void generateKey(HWND hDlg){
	char name[32]; //Var for the Username
	unsigned int namel[8]; //Needed in Step 2, copy of the name but has 8 DWORDs.
	char astr[11]; //Var for String with Number A
	unsigned int az; //The Keygenme calculates a "checksum" from number A which is stored here.
	char bstr[11]; //same for B
	unsigned int bz;
	unsigned int hash[8]; //Here is stored the result of step 1 (8 DWORDs)
	unsigned int magic[4]; //4 Constant Bytes used for Calculation, Initialization see later.
	char key[65]; //The ready calculated 0 terminated String
	UINT retVal; //For the return Value of the Win API Calls

	retVal = GetDlgItemTextA(hDlg, IDC_USERNAME, name, sizeof(name)); //Get the name from the Textbox

	if(retVal > 21){//If the name is to long...
		MessageBoxA(hDlg, "Username must not exceed 21 chars.\nUse first 21 characters.", "Keygen - Error", 0); 
		name[21] = 0;//Set the length of the name...
		SetDlgItemTextA(hDlg, IDC_USERNAME, name);
	}

	srand(GetTickCount());//Initialize the Random Number Generator

	for(int i = retVal + 1; i<sizeof(name); i++){
		name[i] = rand() & 0xFF;//Fill the rest of the Name String with random Numbers. Otherwise the end of the Key would be all the same char.
	}
	
	srand(GetTickCount());//Initialize the Random Number Generator
	az = 0; //Initialize the "Checksums"
	bz = 0;
	
	for(int i = 0; i < 10; i++){
		astr[i] = (rand()%10)+0x30;//Initialize the STring for A with random Numbers (Numbers have the Ascii Codes from 0x30 to 0x39).
		az = ((az * 4 + az) * 2 + (astr[i] - 0x30)); //Calculate the "Checksum" for A
		bstr[i] = (rand()%10)+0x30; //Do the Same for B
		bz = ((bz * 4 + bz) * 2 + (bstr[i] - 0x30));
	}

	astr[10] = 0;//Make A a zero terminated String
	bstr[10] = 0;//Do the same for B
	
	memcpy(namel, name, sizeof(namel));//Initialize the Copy of name (8 DWORDs), 4 Chars per DWORD.
	
	magic[0] = 0x69796C46;//Initialize the static DWORDs used for calculation
	magic[1] = 0x2E2E676E;//Converted to Ascii Chars this would be the String Flying.....Horse
	magic[2] = 0x482E2E2E;
	magic[3] = 0x6573726F;

	for(int i = 0; i<8; i+=2){//Step one: Iterate through the DWORD Array of the name,
		//in every Step are two DWORDs for the final Step out of two DWORDs from the name calculated, thats why the stepwidth is 2.
		unsigned int ina = namel[i];//Load the first DWORD which is used from the name
		unsigned int inb = namel[i + 1]; //Second DWORD.

		unsigned int number = az - 0x20*bz;//The Keygenme uses in the calculation for the Username a number which is first initialized whith
		//the "checksum" of a. Then it loops 0x20 (32) times and subtracts every time the "checksum" of B.
		//Because we do the reverse of the Keygenme (calculate the Key from the name instead of the name from the key)
		//we have to calculate the value how it is after the loop. In the loop there is added each loop B to the number.
		//At the end of the loop number has the value of A.

		for(int j = 0; j<0x20; j++){//The new DWORD is calculated in a loop which loops 0x20 (32) times.
			number += bz;//As said before, the number will be increased by B.
			ina += ((number + inb) ^ ((inb<<4) + magic[0]) ^ ((inb>>5) + magic[1]));//The Calculation of the new DWORD which is returned to the final Step.
			//Add to the first DWORD the second DWORD increased by the number xored with the second DWORD 4 bit shift left (*16) and added the first constant DWORD xored by the second DWORD 5 bit shift right (divided by 32) and added the second constant DWORD
			inb += ((number + ina) ^ ((ina<<4) + magic[2]) ^ ((ina>>5) + magic[3])); //Do the same for the second DWORD
			
		}

		hash[i] = ina;//Save the ready calculated DWORDs for the final Step...
		hash[i + 1] = inb;
	}

	//The final step...
	for(int i = 0; i<8; i++){//Iterate through the DWORD Array returned from step one
		for(int j = 0; j<8; j++){//Every DWORD consists of 8 Nibbles. Each Nibble represent one Character of the Key.
			//The Keygenme subtracts 0x57 from each Ascii char in the key and then use the last nibble for further calculation.
			//Notice: Whether you subtract 0x57 or 0x07 is irrelevant because only the last char is used!
			//so we have to add some number which ends with 0x7.
			//Second Notice: There are many possibilities for Characters but I wanted the beginning of the uppercase alphabet
			//The Uppercase alphabet starts at 0x41 so we have to decide wether the number is over 0xA (0x37 + 0xA = 0x41) or below 0xA to avoid
			//special chars.
			char c = hash[i] & 0xF;//filter the last nibble of the DWORD and save into the char...
			if(c >= 0xA){//Add the Offset
				c += 0x37;
			}else{
				c += 0x47;
			}
			key[(i*8) + (7 - j)] = c;//Add the calculated Char to the String. we begib with the last char --> index 7-j
			hash[i] = hash[i] >> 4; //next nibble...
		}
	}

	key[64] = 0;//make the key a zero terminated String
	
	SetDlgItemTextA(hDlg, IDC_A, astr);//Output of the ready key...
	SetDlgItemTextA(hDlg, IDC_B, bstr);
	SetDlgItemTextA(hDlg, IDC_KEY, key);
}