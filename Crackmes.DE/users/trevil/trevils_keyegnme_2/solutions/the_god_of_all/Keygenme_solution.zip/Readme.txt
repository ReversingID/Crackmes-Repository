Keygen for Trevils Keygenme (http://www.crackmes.de/users/trevil/trevils_keyegnme_2/)

The Keygen is copyright by The-God-of-all.

Sorry for my bad englisch, I hope you can understand everything.

Files:
Keygen: My Keygen (.exe) and the source (source.c) and a little explanation.