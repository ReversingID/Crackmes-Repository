j!m keygenMe #2

all you have to do is to write a tutorial and a generic keygen for this prog.
send your solutions to zejim@netcourrier.com and to the crackmes website.

one rule:
you can use all the tools and the technics you want as soon as your keygen works with the
original (not patched!) target.

difficulty:
This is not very difficult, no crypto, no anti-debug, i would say level 3/10.

Trick:
there are two ways to defeat this keygen, the first one is to devise a bruteforcer, for the second one it would be 
useful to get one valid serial and to know how to compute pi with as many decimals as you want...
good luck

see u soon!

j!m 02-2002
