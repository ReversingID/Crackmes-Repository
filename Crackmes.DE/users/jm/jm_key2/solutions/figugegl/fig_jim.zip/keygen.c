/*************************************************************************

 Filename:		Keygen.c
 Purpose:		Keygen for Jim Crackme #2
 Author:		figugegl
 Version:		1.0
 Date:			24.2.2001

*************************************************************************/


/*------------------------------------------------------------------------
	Include files
------------------------------------------------------------------------*/
#include <windows.h>
#include <stdio.h>
#include "keygenres.h"


/*------------------------------------------------------------------------
	Prototypes
------------------------------------------------------------------------*/
LRESULT CALLBACK MainDlgProc	(HWND, UINT, WPARAM, LPARAM) ;


/*------------------------------------------------------------------------
	Global variables
------------------------------------------------------------------------*/


/*------------------------------------------------------------------------
 Procedure:     WinMain
 Purpose:       Application entry point. Registers a class of the same
                type than the dialog class,calls DialogBox and then exits
 Input:         Standard
 Output:        None
 Errors:        None
------------------------------------------------------------------------*/
int WINAPI WinMain (HINSTANCE hInst, HINSTANCE hPrevInst, PSTR szCmdLine, int CmdShow)
{
	static TCHAR	szAppName[] = TEXT ("keygen") ;
	WNDCLASS		wc ;

	memset (&wc, 0, sizeof (wc));				// empty structure wc

	wc.lpfnWndProc		= MainDlgProc ;			// callback procedure
	wc.cbWndExtra		= DLGWINDOWEXTRA ;
	wc.hInstance		= hInst ;
	wc.hIcon			= LoadIcon (hInst, MAKEINTRESOURCE (ICO_FIGU)) ;
	wc.hCursor			= LoadCursor (NULL, IDC_ARROW) ;
	wc.hbrBackground	= (HBRUSH) (COLOR_BTNFACE + 1) ;
	wc.lpszClassName	= szAppName ;

	if (!RegisterClass (&wc))
		return 0;

	return DialogBoxParamA (hInst, MAKEINTRESOURCE (DLG_MAIN), NULL, (DLGPROC) MainDlgProc, 0);
}


/*------------------------------------------------------------------------
 Procedure:     CalculateSerial
 Purpose:       Calculate a valid serial
 Input:         hWnd:	Handle of the Dialogbox
 Output:        None
 Errors:        None
------------------------------------------------------------------------*/
void CalculateSerial (HWND hWnd)
{
	char			szName[32], szSerial[6] = "";
	int				i, j, iSerial, iNameLen;
	unsigned char	cVarB;
	unsigned long	lVarA, lVarC, lVarD, lTmp;
	long	lTable1[256] = {
				0x00000000, 0x96300777, 0x2C610EEE, 0xBA510999, 0x19C46D07, 0x8FF46A70, 0x35A563E9, 0xA395649E,
			    0x3288DB0E, 0xA4B8DC79, 0x1EE9D5E0, 0x88D9D297, 0x2B4CB609, 0xBD7CB17E, 0x072DB8E7, 0x911DBF90,
			    0x6410B71D, 0xF220B06A, 0x4871B9F3, 0xDE41BE84, 0x7DD4DA1A, 0xEBE4DD6D, 0x51B5D4F4, 0xC785D383,
			    0x56986C13, 0xC0A86B64, 0x7AF962FD, 0xECC9658A, 0x4F5C0114, 0xD96C0663, 0x633D0FFA, 0xF50D088D,
			    0xC8206E3B, 0x5E10694C, 0xE44160D5, 0x727167A2, 0xD1E4033C, 0x47D4044B, 0xFD850DD2, 0x6BB50AA5,
			    0xFAA8B535, 0x6C98B242, 0xD6C9BBDB, 0x40F9BCAC, 0xE36CD832, 0x755CDF45, 0xCF0DD6DC, 0x593DD1AB,
			    0xAC30D926, 0x3A00DE51, 0x8051D7C8, 0x1661D0BF, 0xB5F4B421, 0x23C4B356, 0x9995BACF, 0x0FA5BDB8,
			    0x9EB80228, 0x0888055F, 0xB2D90CC6, 0x24E90BB1, 0x877C6F2F, 0x114C6858, 0xAB1D61C1, 0x3D2D66B6,
			    0x9041DC76, 0x0671DB01, 0xBC20D298, 0x2A10D5EF, 0x8985B171, 0x1FB5B606, 0xA5E4BF9F, 0x33D4B8E8,
			    0xA2C90778, 0x34F9000F, 0x8EA80996, 0x18980EE1, 0xBB0D6A7F, 0x2D3D6D08, 0x976C6491, 0x015C63E6,
			    0xF4516B6B, 0x62616C1C, 0xD8306585, 0x4E0062F2, 0xED95066C, 0x7BA5011B, 0xC1F40882, 0x57C40FF5,
			    0xC6D9B065, 0x50E9B712, 0xEAB8BE8B, 0x7C88B9FC, 0xDF1DDD62, 0x492DDA15, 0xF37CD38C, 0x654CD4FB,
			    0x5861B24D, 0xCE51B53A, 0x7400BCA3, 0xE230BBD4, 0x41A5DF4A, 0xD795D83D, 0x6DC4D1A4, 0xFBF4D6D3,
			    0x6AE96943, 0xFCD96E34, 0x468867AD, 0xD0B860DA, 0x732D0444, 0xE51D0333, 0x5F4C0AAA, 0xC97C0DDD,
			    0x3C710550, 0xAA410227, 0x10100BBE, 0x86200CC9, 0x25B56857, 0xB3856F20, 0x09D466B9, 0x9FE461CE,
			    0x0EF9DE5E, 0x98C9D929, 0x2298D0B0, 0xB4A8D7C7, 0x173DB359, 0x810DB42E, 0x3B5CBDB7, 0xAD6CBAC0,
			    0x2083B8ED, 0xB6B3BF9A, 0x0CE2B603, 0x9AD2B174, 0x3947D5EA, 0xAF77D29D, 0x1526DB04, 0x8316DC73,
			    0x120B63E3, 0x843B6494, 0x3E6A6D0D, 0xA85A6A7A, 0x0BCF0EE4, 0x9DFF0993, 0x27AE000A, 0xB19E077D,
			    0x44930FF0, 0xD2A30887, 0x68F2011E, 0xFEC20669, 0x5D5762F7, 0xCB676580, 0x71366C19, 0xE7066B6E,
			    0x761BD4FE, 0xE02BD389, 0x5A7ADA10, 0xCC4ADD67, 0x6FDFB9F9, 0xF9EFBE8E, 0x43BEB717, 0xD58EB060,
			    0xE8A3D6D6, 0x7E93D1A1, 0xC4C2D838, 0x52F2DF4F, 0xF167BBD1, 0x6757BCA6, 0xDD06B53F, 0x4B36B248,
			    0xDA2B0DD8, 0x4C1B0AAF, 0xF64A0336, 0x607A0441, 0xC3EF60DF, 0x55DF67A8, 0xEF8E6E31, 0x79BE6946,
			    0x8CB361CB, 0x1A8366BC, 0xA0D26F25, 0x36E26852, 0x95770CCC, 0x03470BBB, 0xB9160222, 0x2F260555,
			    0xBE3BBAC5, 0x280BBDB2, 0x925AB42B, 0x046AB35C, 0xA7FFD7C2, 0x31CFD0B5, 0x8B9ED92C, 0x1DAEDE5B,
			    0xB0C2649B, 0x26F263EC, 0x9CA36A75, 0x0A936D02, 0xA906099C, 0x3F360EEB, 0x85670772, 0x13570005,
			    0x824ABF95, 0x147AB8E2, 0xAE2BB17B, 0x381BB60C, 0x9B8ED292, 0x0DBED5E5, 0xB7EFDC7C, 0x21DFDB0B,
			    0xD4D2D386, 0x42E2D4F1, 0xF8B3DD68, 0x6E83DA1F, 0xCD16BE81, 0x5B26B9F6, 0xE177B06F, 0x7747B718,
			    0xE65A0888, 0x706A0FFF, 0xCA3B0666, 0x5C0B0111, 0xFF9E658F, 0x69AE62F8, 0xD3FF6B61, 0x45CF6C16,
			    0x78E20AA0, 0xEED20DD7, 0x5483044E, 0xC2B30339, 0x612667A7, 0xF71660D0, 0x4D476949, 0xDB776E3E,
			    0x4A6AD1AE, 0xDC5AD6D9, 0x660BDF40, 0xF03BD837, 0x53AEBCA9, 0xC59EBBDE, 0x7FCFB247, 0xE9FFB530,
			    0x1CF2BDBD, 0x8AC2BACA, 0x3093B353, 0xA6A3B424, 0x0536D0BA, 0x9306D7CD, 0x2957DE54, 0xBF67D923,
			    0x2E7A66B3, 0xB84A61C4, 0x021B685D, 0x942B6F2A, 0x37BE0BB4, 0xA18E0CC3, 0x1BDF055A, 0x8DEF022D};

	long	lTable2[256] = {
			    0x19000000, 0x25000000, 0xA6000000, 0x78000000, 0x40000000, 0x42010000, 0xC6000000, 0x22030000,
			    0x36010000, 0x28000000, 0xCC010000, 0xE9070000, 0x4C000000, 0x1E0A0000, 0xE8050000, 0x8C0A0000,
			    0x1D000000, 0x26000000, 0x1F000000, 0x4A000000, 0x4F000000, 0x62000000, 0xC1000000, 0xFD000000,
			    0x78000000, 0x14010000, 0x99000000, 0x60000000, 0x20030000, 0x29010000, 0x70000000, 0xD0020000,
			    0x14000000, 0x18000000, 0x31000000, 0x34000000, 0x7A000000, 0x45010000, 0xB9010000, 0xD7020000,
			    0xC6000000, 0x78000000, 0x78010000, 0xD6000000, 0x30030000, 0x10020000, 0xA0170000, 0xD00B0000,
			    0x11000000, 0x21000000, 0x5B000000, 0x33010000, 0x14000000, 0x69000000, 0xDF000000, 0xA0080000,
			    0x50000000, 0x7E000000, 0x3C000000, 0x98000000, 0x60030000, 0xB9010000, 0x80010000, 0x601E0000,
			    0x1F000000, 0x11000000, 0x3F000000, 0xBA000000, 0x2E000000, 0x8B000000, 0x04020000, 0x19010000,
			    0x24000000, 0x42000000, 0x81000000, 0xF1020000, 0x96000000, 0x1C020000, 0x68010000, 0xBC020000,
			    0x17000000, 0x24000000, 0x64000000, 0xD2000000, 0x25000000, 0x84000000, 0xBB010000, 0xEA000000,
			    0x1A000000, 0x05010000, 0x5E010000, 0x24040000, 0x84030000, 0xB0040000, 0x90120000, 0x70080000,
			    0x1B000000, 0x5F000000, 0x11000000, 0xF9010000, 0x63000000, 0xFF000000, 0x4C000000, 0xD5030000,
			    0x28000000, 0x13010000, 0x5C010000, 0xE0030000, 0x68000000, 0xEC040000, 0x40060000, 0x00060000,
			    0x18000000, 0x21000000, 0x3E000000, 0x57010000, 0xAD000000, 0x8E000000, 0x1F040000, 0x33000000,
			    0x3F000000, 0x3A000000, 0xA0000000, 0x99000000, 0xB0040000, 0x2C010000, 0x801F0000, 0x78050000,
			    0x1F000000, 0x24000000, 0x3F000000, 0x35000000, 0x74000000, 0x1A000000, 0x72010000, 0x18050000,
			    0x50000000, 0x9A010000, 0xD2030000, 0x6C060000, 0xB4000000, 0x0C010000, 0x96000000, 0xA4010000,
			    0x1A000000, 0x26000000, 0x96000000, 0xE2000000, 0x2E000000, 0x8D000000, 0x41020000, 0x64000000,
			    0x5E010000, 0x88030000, 0x71000000, 0xF4030000, 0x20020000, 0x1C020000, 0x76020000, 0xE0100000,
			    0x14000000, 0x4D000000, 0x4A000000, 0x2E000000, 0x2D000000, 0x2D000000, 0xCF000000, 0xDE000000,
			    0x58000000, 0x2C000000, 0x0C000000, 0x18000000, 0xE8050000, 0xA5060000, 0x400B0000, 0xB0010000,
			    0x14000000, 0x20000000, 0x75000000, 0xA5000000, 0x51000000, 0x23000000, 0x46020000, 0xDC090000,
			    0x78000000, 0x94000000, 0x5C010000, 0xF0060000, 0x08010000, 0x20130000, 0x80100000, 0x88020000,
			    0x12000000, 0x4E000000, 0x09000000, 0x01010000, 0x22000000, 0x50000000, 0xB2000000, 0xBE000000,
			    0x90000000, 0x1D000000, 0x87000000, 0xB4070000, 0xEC040000, 0x80030000, 0xD0020000, 0x103B0000,
			    0x15000000, 0x15000000, 0x23000000, 0x79000000, 0x0A010000, 0xDF010000, 0x89030000, 0xD2020000,
			    0x4E000000, 0x5A000000, 0xDA020000, 0x2C000000, 0x84030000, 0xFD020000, 0x94020000, 0x68100000,
			    0x1D000000, 0x20000000, 0x7A000000, 0xE4000000, 0x24000000, 0x94000000, 0x15020000, 0x67040000,
			    0x74000000, 0xAE000000, 0x0D000000, 0x30010000, 0xA0000000, 0x12000000, 0x0F1E0000, 0x5A000000,
			    0x23000000, 0x19000000, 0x61000000, 0x34000000, 0x11000000, 0x8F000000, 0x4A020000, 0xF6040000,
			    0xD8000000, 0xF5000000, 0xFC000000, 0xF0050000, 0xF8010000, 0x40040000, 0xF0000000, 0x68100000};

	iNameLen = GetDlgItemTextA (hWnd, EDF_NAME, szName, 32);

	if (iNameLen == 0)
		SetDlgItemTextA (hWnd, EDF_SERIAL, NULL);
	else
	{
		// calc value from name
		for (lVarA = 0xFFFFFFFF, cVarB = 0, i = 0; i < iNameLen; i++)
		{
			cVarB = szName[i] ^ lVarA;

			// bswap table1
			lTmp = lTable1[cVarB];
			for (lVarC = 0, j = 0; j < 4; j++)
			{
				lVarC = (lVarC << 8) | (lTmp & 0xFF);
				lTmp >>= 8;
			}
			lVarA = (lVarA >> 8) ^ lVarC;
		}
		lVarA ^= -1;

		// index for table2
		if ((lVarA & 0xFF) < 0x55)
			lVarA >>= 0x18;
		else if ((lVarA & 0xFF) < 0xAA)
			lVarA = (lVarA >> 0x10) & 0xFF;
		else
			lVarA = (lVarA >> 8) & 0xFF;

		// bswap table2
		lTmp = lTable2[lVarA];
		for (lVarC = 0, j = 0; j < 4; j++)
		{
			lVarC = (lVarC << 8) | (lTmp & 0xFF);
			lTmp >>= 8;
		}

		// bruteforce serial
		iSerial = 0;
		while (iSerial++ < 100000)
		{
			wsprintfA (szSerial, "%0.5d", iSerial);
			for (lTmp = szSerial[0] - 0x2F, lVarD = lVarA, i = 1; i < 5; i++)
			{
				if (lVarD & 1)
					lTmp *= (szSerial[i] - 0x2F);
				else
					lTmp += szSerial[i] - 0x2F;

				lVarD >>= 1;

				if (lTmp == lVarC)
				{
					SetDlgItemTextA (hWnd, EDF_SERIAL, szSerial);
					return;
				}
			}
		}
	}
	return;
}


/*------------------------------------------------------------------------
 Procedure:     AboutDlgProc
 Purpose:       Handles the messages of the about dialog
 Input:         Standard
 Output:        TRUE if the message was processed
 Errors:        None
------------------------------------------------------------------------*/
LRESULT CALLBACK AboutDlgProc (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
     switch (uMsg)
     {
     case WM_INITDIALOG:
          return 0;

     case WM_COMMAND:
          if (LOWORD (wParam) == BUT_OK)
          {
   EndDialog (hWnd, 0) ;
   return 0;
          }
          break ;
     }
     return FALSE ;
}


/*------------------------------------------------------------------------
 Procedure:     MainDialogProc
 Purpose:       It handles all messages of the main dialog
 Input:         Standard
 Output:        TRUE if the message was processed
 Errors:        None
------------------------------------------------------------------------*/
LRESULT CALLBACK MainDlgProc (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_INITDIALOG:
		SendDlgItemMessageA (hWnd, EDF_NAME, EM_LIMITTEXT, 31, 0);
		SetDlgItemTextA (hWnd, EDF_NAME, "figugegl");
		return 0 ;

	case WM_COMMAND:
		switch (LOWORD (wParam))
		{
		case EDF_NAME:			// Namefield
			if (HIWORD (wParam) == EN_CHANGE)
			{
				CalculateSerial (hWnd);
		 		return 0;
			}
			break;

		case BUT_ABOUT:			// About
			DialogBox (NULL, MAKEINTRESOURCE (DLG_ABOUT), hWnd, (DLGPROC) AboutDlgProc);
			return 0;
		}
		break;

	case WM_CLOSE:
		PostQuitMessage (0) ;
		return 0 ;
	}
	return DefWindowProc (hWnd, uMsg, wParam, lParam) ;
}

