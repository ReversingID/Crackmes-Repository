Hi

here comes my very first keygenMe, all you have to do
is to write a valid keygenerator for this program.
You can use all the tools you want but a working brain will
be very usefull!!
There is no packing, anti-debug or crypto code inside
only a few ASM instructions to reverse...

Good luck ;-) 

Send your solutions to zejim@netcourrier.com
j!m
