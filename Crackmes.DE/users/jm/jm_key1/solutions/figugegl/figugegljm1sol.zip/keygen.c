/*************************************************************************

 Filename:		Keygen.c
 Purpose:		Keygen for Jim Crackme #1
 Author:		figugegl
 Version:		1.0
 Date:			23.1.2001

*************************************************************************/


/*------------------------------------------------------------------------
	Include files
------------------------------------------------------------------------*/
#include <windows.h>
#include <stdio.h>
#include "keygenres.h"


/*------------------------------------------------------------------------
	Prototypes
------------------------------------------------------------------------*/
LRESULT CALLBACK MainDlgProc	(HWND, UINT, WPARAM, LPARAM) ;


/*------------------------------------------------------------------------
	Global variables
------------------------------------------------------------------------*/


/*------------------------------------------------------------------------
 Procedure:     WinMain
 Purpose:       Application entry point. Registers a class of the same
                type than the dialog class,calls DialogBox and then exits
 Input:         Standard
 Output:        None
 Errors:        None
------------------------------------------------------------------------*/
int WINAPI WinMain (HINSTANCE hInst, HINSTANCE hPrevInst, PSTR szCmdLine, int CmdShow)
{
	static TCHAR	szAppName[] = TEXT ("keygen") ;
	WNDCLASS		wc ;

	memset (&wc, 0, sizeof (wc));				// empty structure wc

	wc.lpfnWndProc		= MainDlgProc ;			// callback procedure
	wc.cbWndExtra		= DLGWINDOWEXTRA ;
	wc.hInstance		= hInst ;
	wc.hIcon			= LoadIcon (hInst, MAKEINTRESOURCE (ICO_FIGU)) ;
	wc.hCursor			= LoadCursor (NULL, IDC_ARROW) ;
	wc.hbrBackground	= (HBRUSH) (COLOR_BTNFACE + 1) ;
	wc.lpszClassName	= szAppName ;

	if (!RegisterClass (&wc))
		return 0;

	return DialogBoxParamA (hInst, MAKEINTRESOURCE (DLG_MAIN), NULL, (DLGPROC) MainDlgProc, 0);
}


/*------------------------------------------------------------------------
 Procedure:     CalculateSerial
 Purpose:       Calculate a valid serial
 Input:         hWnd:	Handle of the Dialogbox
 Output:        None
 Errors:        None
------------------------------------------------------------------------*/
void CalculateSerial (HWND hWnd)
{
	int		i, j, iPos, iNameLen, iCa, iCb, iVarN;
	char	szName[16], szSerial[48] = "";
	char	cTable1[54] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz";
	char	cTable2[54] = {0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x25, 0x26, 0x27, 0x28, 0x29,
			               0x2A, 0x2B, 0x2C, 0x2D, 0x2E, 0x2F, 0x35, 0x38, 0x39, 0x3A, 0x3B,
			               0x3C, 0x3E, 0x3F, 0x47, 0x4A, 0x4B, 0x4C, 0x4E, 0x4F, 0x59, 0x5C,
			               0x5E, 0x5F, 0x6A, 0x6B, 0x6F, 0x7C, 0x7D, 0x8E, 0x8F, 0x9F, 0x13,
			               0x14, 0x15, 0x16, 0x17, 0x18, 0x25, 0x26, 0x27, 0x28, 0x08};

	iNameLen = GetDlgItemTextA (hWnd, EDF_NAME, szName, 15);

	if (iNameLen == 0)
		SetDlgItemTextA (hWnd, EDF_SERIAL, NULL);
	else
	{
		for (i = 0; i < iNameLen; i++)
		{
			iPos = 0;
			while (szName[i] != cTable1[iPos])
			{
				iPos++;
			}

			// leave proc if bad char found
			if (iPos >= 54)
			{
				SetDlgItemTextA (hWnd, EDF_NAME, NULL);
				SetDlgItemTextA (hWnd, EDF_SERIAL, NULL);
				return;
			}

			// bruteforce part serial for char
			iCa = cTable2[iPos] & 0xF;
			iCb = (cTable2[iPos] >> 4) & 0xF;

			for (j = 1; j < 0x50; j++)
			{
				// check for division 0
				if (j * iCb != iCa)
				{
					if ((j * iCa) % (j * iCb - iCa) == 0)
					{
						iVarN = (j * iCa) / (j * iCb - iCa);
						szSerial[3*i] = j + 0x30;
						szSerial[3*i+1] = iVarN / 10 + 0x30;
						szSerial[3*i+2] = iVarN % 10 + 0x30;
						break;
					}
				}
				else
				{
					j++;
				}
			}
		}

		SetDlgItemTextA (hWnd, EDF_SERIAL, szSerial);
	}
}


/*------------------------------------------------------------------------
 Procedure:     AboutDlgProc
 Purpose:       Handles the messages of the about dialog
 Input:         Standard
 Output:        TRUE if the message was processed
 Errors:        None
------------------------------------------------------------------------*/
LRESULT CALLBACK AboutDlgProc (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
     switch (uMsg)
     {
     case WM_INITDIALOG:
          return 0;

     case WM_COMMAND:
          if (LOWORD (wParam) == BUT_OK)
          {
               EndDialog (hWnd, 0) ;
               return 0;
          }
          break ;
     }
     return FALSE ;
}


/*------------------------------------------------------------------------
 Procedure:     MainDialogProc
 Purpose:       It handles all messages of the main dialog
 Input:         Standard
 Output:        TRUE if the message was processed
 Errors:        None
------------------------------------------------------------------------*/
LRESULT CALLBACK MainDlgProc (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_INITDIALOG:
		SendDlgItemMessageA (hWnd, EDF_NAME, EM_LIMITTEXT, 31, 0);
		SetDlgItemTextA (hWnd, EDF_NAME, "figugegl");
		return 0 ;

	case WM_COMMAND:
		switch (LOWORD (wParam))
		{
		case EDF_NAME:			// Namefield
			if (HIWORD (wParam) == EN_CHANGE)
			{
				CalculateSerial (hWnd);
		 		return 0;
			}
			break;

		case BUT_ABOUT:			// About
			DialogBox (NULL, MAKEINTRESOURCE (DLG_ABOUT), hWnd, (DLGPROC) AboutDlgProc);
			return 0;
		}
		break;

	case WM_CLOSE:
		PostQuitMessage (0) ;
		return 0 ;
	}
	return DefWindowProc (hWnd, uMsg, wParam, lParam) ;
}

