#include <iostream.h>

#define SIZE 5 //Represents the size of the name

void main()
{
  int p1,p2,p3,aux1,aux2,found;
  int enc_name[]={0x27,0x4B,0x14,0x8F,0x8E};//The encrypted string of 'yaron'
  //to get ur name put a bpx on :401230 and watch ds:64F9E0.


  int cont=0;
  cout<<"A brute-forcer for j!m's first keygenme - coded by yar0n7"<<endl;
  cout<<"========================================================="<<endl;
  cout<<"Serial:";

//p1 - stands for the first password character
//p2 - stands for the second password character*10
//p3 - stands for the third password character
//enc_name[i] - the Ith character of the encrypted name

//  aux1 = enc_name[cont]&0x0F - aux1 has the value of the rightmost bits of the byte
//  aux2 = (enc_name[cont]>>4)&0x0F - aux2 has the value of the leftmost bits of the byte

//We have to solve the equation:
//==============================
//aux*(p2+p3+p1)=p1*(p2+p3)*aux2 such as the result has to be diffrent than 0.

//The password length is 3 times the length of the name and
// each character of the encrypted name(which has the same length of the
// original name) is accomplished by the equation above and each
//3 password chars are involved to the current name char
//a comment if u enter the character '1' in the calculation the value is
//not 0x31, its 1 because we decrease 0x30 from each password character.

//BTW I'M NOT SURE A BRUTE-FORCER IS REQUIRED j!m's SAID THE ALGO IS
//REVERSIBLE SO I GUESS MY SOLUTION ISN'T WHAT HE HAD IN MIND WHEN
//HE WROTE THIS KEYGENME!

while(cont<SIZE)
{
  found=0;
  for(int i=0;i<=0x4A && !found;i++) //While not found
    {
	p2=i*10;
	aux1=enc_name[cont]&0x0F;
	aux2=(enc_name[cont]>>4)&0x0F;
	for(p1=0;p1<=0x4A && !found;p1++)
	  for(p3=0;p3<=0x4A && !found;p3++)
	    {
		if ((aux1*(p2+p3+p1))==((p2+p3)*p1*aux2) && (p2*p1*2)!=0)
		  {
		    found=1;// found a solution to the equation we are
		    //moving to to brute-force the next character name
		    cout<<(char)(p1+0x30)<<(char)(p2/10+0x30)<<(char)(p3+0x30);
		    //prints the 3 chars that fit to the current
		    //character name
		  }
	    }
    }
  cont++;
}


}