KeygenMe1 by qwertydid
---------------------
Rules:
Make a working keygen. No patching, serial fishing or selfkeygenning.
When you've made the keygen, submit tutorial, source & binary to crackmes.de

Difficulty:
3/10

Language:
Assembly

Author:
qwertydid