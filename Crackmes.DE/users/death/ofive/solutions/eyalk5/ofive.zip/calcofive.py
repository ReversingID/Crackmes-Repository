
from collections import defaultdict
currentset=set(range(256))
allvalsdic=defaultdict(lambda :set(range(256)))
import random
def removeone(src,elem):
    if elem in src:
        src.remove(elem)
def pickone(pos):    
    moveset=currentset.intersection(allvalsdic[pos])
    pick=random.choice(list(moveset)) #throw indexerror
    currentset.remove(pick)
    for i in range(0,256-pos): #all the next
        removeone(allvalsdic[pos+i],(pick+i))
        removeone(allvalsdic[pos+i],(pick-i))
    for j in range(1,pos+1):
        removeone(allvalsdic[pos-i],(pick+i))
        removeone(allvalsdic[pos-i],(pick-i))
    return pick
def getseq():
    for j in xrange(10000):
        time.sleep(0.1)
        global currentset,allvalsdic
        seq=[]
        currentset=set(range(256))
        allvalsdic=defaultdict(lambda :set(range(256)))
        try:
            for i in xrange(256):
                seq+=[pickone(i)]
            return seq
            break
        except IndexError:
            pass
        print "Trying %d time" % j
    return None