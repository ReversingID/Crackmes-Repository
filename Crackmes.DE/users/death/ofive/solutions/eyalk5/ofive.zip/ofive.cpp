// calcofive.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

char __fastcall thirdcalc();

int _tmain(int argc, _TCHAR* argv[])
{
	thirdcalc();
	return 0;
}
void reversefirstcalc(unsigned int * arr,unsigned int* outarr)
{
	unsigned int k=0;
	int n=0;
	for(int i=0;i<0x100;i++)
	{
		for(k=0;k<8;k++)
		{
			n=0;
			for(unsigned int j=1;j<=0x80000000;j=j<<1)//x
			{
				n++;
				if (arr[i*8+k]==j)
					break;
			}
			if (n!=33) // n<32
			{
				break;
			}
		}
		outarr[i] = (k<<5) | (n-1);
	}
}
int constarr1[4]={-1,1,-1,1};
int constarr2[4]={-1,-1,1,1};
char __fastcall thirdcalc()
{
  signed int countto16jump4; // edi@3
  unsigned int counterplus; // edx@4
  signed int shouldbe1or0; // ebx@4
  unsigned int innercounterto256plus; // esi@4
  unsigned int c; // eax@9
  char v7; // cf@13
  char v8; // cf@14
  int endofstring; // [sp+18h] [bp-8h]@1
  unsigned int counterto256; // [sp+14h] [bp-Ch]@1
  unsigned int innercounterto256; // [sp+10h] [bp-10h]@2
  const int len=0x800;
  unsigned int out[len]={0};
  unsigned int in[0x100]={0};
  FILE* f;
  f=fopen("c:\\ofive.txt","w");
  counterto256 = 0;
  while ( 2 )
  {
    innercounterto256 = 0;
    do
    {
      countto16jump4 = 0;
      while ( 2 )
      {
        counterplus = counterto256;
        innercounterto256plus = innercounterto256;
        shouldbe1or0 = 0;
		for(int j=0;j<len;j++)
		{
			out[j]=0;
		}
		for(int j=0;j<0x100;j++)
		{
			in[j]=0;
		}
        while ( (signed int)innercounterto256plus >= 0
             && innercounterto256plus < 0x100
             && (signed int)counterplus >= 0
             && counterplus < 0x100 )
        {
          c = innercounterto256plus + (counterplus << 8); 
          if ( c >= 0x10000 )
            return 0;
          counterplus += constarr1[countto16jump4/4]; // -

		  out[c>>5]=(1 << (innercounterto256plus & 0x1F));

		  //printf("pos %x shouldn't be val %x \n",(c >> 5),(1 << (innercounterto256plus & 0x0F)));
//          shouldbe1or0 += ((1 << (innercounterto256plus & 0x0F)) & *(_DWORD *)(endofstring + 4 * (c >> 5))) != 0;
          innercounterto256plus += constarr2[countto16jump4/4];
        }
		if ((countto16jump4==4)||(countto16jump4==12)) //So it won't print tables that has one element.
		{
			reversefirstcalc((unsigned int*)out,in);
		
			fprintf(f,"\ntable\n","");

			  for(int i=0;i<0x100;i++)
				{
				  fprintf(f,"%02x,",in[i]);
				}
		}

		//getchar();
		//printf("up to one mistake\n");
//        if ( shouldbe1or0 > 1 )
//          return 0;
        countto16jump4 += 4;
        if ( countto16jump4 < 16 )
          continue;
        break;
      }
      v7 = innercounterto256++ + 1 < 0x100;
    }
    while ( v7 );
    v8 = counterto256++ + 1 < 0x100;
    if ( v8 )
      continue;
    break;
  }
  fclose(f);
  return 1;
}
