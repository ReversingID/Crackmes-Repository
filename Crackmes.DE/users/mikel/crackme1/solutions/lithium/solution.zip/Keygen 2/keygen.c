#include <windows.h>
#include <Tlhelp32.h>
#include "resource.h"

#define MAX_NAME 32
#define HASH_SIZ 17
#define BLOCK_SIZ 0xB0

BYTE buf[HASH_SIZ];

const BYTE block1[14] = "\x03\x03\x01\x03\x06\x0A\x0F\xFC\x03\x0B\xFF\x04\x24";
const BYTE block2[6] = "\x00\x0B\xFE\x0B\x00\x0F";

BYTE block3[BLOCK_SIZ];
const BYTE block4[8] = "\x55\x55\x55\x55\x55\x55\x55\x55";
const BYTE block5[8] = "\x33\x33\x33\x33\x33\x33\x33\x33";
const BYTE block6[8] = "\x0F\x0F\x0F\x0F\x0F\x0F\x0F\x0F";

BYTE serial[14];
BYTE name[MAX_NAME];
BYTE name_buf[8];

const BYTE block7[80] =  \
"\xD3\x08\xA3\x85\x88\x6A\x3F\x24\x45\x73\x70\x03\x2E\x8A\x19\x13" \
"\xD1\x31\x9F\x29\x22\x38\x09\xA4\x89\x6C\x4E\xEC\x98\xFA\x2E\x08" \
"\x77\x13\xD0\x38\xE6\x21\x28\x45\x6C\x0C\xE9\x34\xCF\x66\x54\xBE" \
"\xDD\x50\x7C\xC9\xB7\x29\xAC\xC0\x17\x09\x47\xB5\xB5\xD5\x84\x3F" \
"\x1B\xFB\x79\x89\xD9\xD5\x16\x92\xAC\xB5\xDF\x98\xA6\x0B\x31\xD1"; 

const BYTE block8[25] = \
"\x66\xC7\x05\x9E\x1C\x40\x00\x90\x90\xEB\xD0\xE9\x67\xFC\xFF\xFF" \
"\x54\x4C\x18\x02\x05\x0E\x1B\x09\xCC";

DWORD ebx_value;
						
BOOL CALLBACK genProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam);

void asciify();
void transform64();
void mega_transform();
void tea_encrypt();
void md4();

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, 
		LPSTR lpCmdLine, int nCmdShow)
{ 
	DialogBox(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_DLG1), NULL, genProc);
	return 0;
}

BOOL CALLBACK genProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam)
{
	UINT bRead;
	UINT i, j, k;

	switch(Message)
	{
		case WM_INITDIALOG:
			return TRUE;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case IDC_BTN1:

					bRead = GetDlgItemText(hwnd, IDC_EDT1, name, MAX_NAME-1);
					if (bRead < 4) {
						MessageBox(NULL, "Name 4 chars min!", "Moron", MB_OK);
						return TRUE;
					}

					__asm {
						push ebp
						mov	ebp, esp

						push 0x20
						push offset name
						push offset block8;

						loc_401B31:
						mov	eax, offset name_buf
						mov	ebx, dword ptr [name]
						push	eax
						mov	[eax], ebx
						mov	esi, offset name
						push	esi
						mov	edi, [esp]
						lodsd
						rol	al, 2
						xor	eax, 5E485442h
						stosd
						mov	[ebp-0xC], ebx
						;inc	dword ptr ds:loc_401CBB+1
						push	[ebp-8]
						mov	edx, 4
						push	edx
						shl	edx, 1
						mov	[esp-34h], edx
						pop	dword ptr [esp+4]
						push	offset buf
						call	md4

						loc_401B78:
						add	[esp-0x1C],	6
						sub	esp, 1Ch
						;xor	dword ptr ds:loc_401CC3, 68000000h
						;mov	ecx, offset loc_401987
						;mov	byte ptr ds:loc_401B78,	0E9h
						;mov	eax, 0FFFFFE0Ah
						;mov	dword ptr ds:loc_401B78+1, eax
						;mov	ax, 0E1FFh
						;mov	word ptr ds:loc_401CC7,	ax
						jmp	short loc_401BB8

						;qword_401BAC dq	1D524D1C411C0013h
						;leave
						;retn	10h

						loc_401BB8:
						push	offset buf
						call	mega_transform
						xor		ecx, ecx
						lea		esi, name
						
						loc_401BCA:
						mov	edi, [ecx+esi]
						test	edi, edi
						jz	short loc_401BDE
						add	[esi], edi
						xor	[ecx+esi], edi
						add	ecx, 4
						cmp	ecx, 20h
						jnz	short loc_401BCA
						
						loc_401BDE:
						mov	eax, offset buf
						call	tea_encrypt
						mov	dword ptr [esp+100b], 401B78h
						mov	eax, dword ptr [name]
						lea	edi, buf+8
						call	asciify

						push	offset buf+8
						push	offset block3+168
						call	transform64
						push	edi
						movq	mm0, block3+168
						movd	mm1, dword ptr block3+172
						pxor	mm0, mm1
						lea		edi, buf
						movq	mm2, qword ptr [edi]
						por	mm0, mm2
						psrlw	mm0, 3
						movd	eax, mm0
						call	asciify

						xor	ecx, ecx
						inc	ecx
						shl	ecx, 3
						xor	edx, edx
						xor	ebx, ebx
						inc	edx
						lea	esi, buf
						
						loc_401A27:
						lodsb
						bswap	ebx
						mov	bl, [ecx+esi]
						sub	ax, bx
						xor	bx, bx
						bswap	ebx
						not	ax
						cmp	al, 19h
						ja	short loc_401A3E
						add	ebx, edx
						
						loc_401A3E:
						rol	edx, 1
						xor	ah, ah
						dec	ecx
						jnz	short loc_401A27
						inc	ecx
						xor	edx, edx
						pop	esi
						add	esi, 5

						mov	ebx_value, ebx
						emms

						add esp, 0xC
						popad
						pop ebp
					}

					serial[13] = 0;
					serial [4] = '-';

					j = 0;
					for (i = 4; i > 0; i--) {
						k = buf[8+j]-0x30;
						if (k > 0x9) {
							k -= 0x11;
							serial[i-1] = k + block2[k] + 0x41 +1;
						}
						else 
							serial[i-1] = k + block1[k] + 0x41 - (i-1);
						j++;
					}

					j = 5;
					k = 1;
					for (i = 0; i < 8; i++) {
						if ((k & ebx_value) != 0)
							serial[j] = 0x41 - (buf[i] - buf[8+i]);
						else
							serial[j] = 0x41 - (buf[8+i] - buf[i]);
						j++;
						k = k << 1;
					}

					SetDlgItemText(hwnd, IDC_EDT2, serial);
					ZeroMemory(block3, BLOCK_SIZ);
					ZeroMemory(serial, 14);
					ZeroMemory(name, MAX_NAME);
					ZeroMemory(name_buf, 8);

					break;
				default:
					break;
			}
			break;

		case WM_CLOSE:
			EndDialog(hwnd, 0);
			return TRUE;

		default:
			return FALSE;
	}
	return TRUE;
}
