#include <windows.h>
#include <Tlhelp32.h>
#include "resource.h"

#define MAX_NAME 32
#define HASH_SIZ 17
#define BLOCK_SIZ 0xB0

BYTE buf[HASH_SIZ];

const BYTE block1[14] = "\x03\x03\x01\x03\x06\x0A\x0F\xFC\x03\x0B\xFF\x04\x24";
const BYTE block2[6] = "\x00\x0B\xFE\x0B\x00\x0F";

BYTE block3[BLOCK_SIZ];
const BYTE block4[8] = "\x55\x55\x55\x55\x55\x55\x55\x55";
const BYTE block5[8] = "\x33\x33\x33\x33\x33\x33\x33\x33";
const BYTE block6[8] = "\x0F\x0F\x0F\x0F\x0F\x0F\x0F\x0F";

BYTE serial[14];

BOOL CALLBACK genProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam);
void asciify();
void transform64(LPVOID buf1, LPVOID buf2);

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, 
		LPSTR lpCmdLine, int nCmdShow)
{ 
	DialogBox(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_DLG1), NULL, genProc);
	return 0;
}

BOOL CALLBACK genProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam)
{
	LPSTR name;	
	UINT bRead;

	BYTE* baseAddr;
	DWORD cmID, ebx_value;
	HANDLE snap, cm;
	PROCESSENTRY32 proc;
	MODULEENTRY32 module;
	SIZE_T szMem;
	UINT i, j, k;

	switch(Message)
	{
		case WM_INITDIALOG:
			return TRUE;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case IDC_BTN1:
					cmID = 0;
					buf[HASH_SIZ-1] = 0x00;

					snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
					proc.dwSize = sizeof(PROCESSENTRY32);

					while(Process32Next(snap, &proc)) {
						if (_tcsncmp(proc.szExeFile, "cm.exe", 7) == 0) {
								cmID = proc.th32ProcessID;
								snap = CreateToolhelp32Snapshot(
												TH32CS_SNAPMODULE, cmID);
								while (Module32Next(snap, &module)) {
										if (_tcsncmp(module.szModule, "cm.exe")
														== 0) {
												baseAddr = module.modBaseAddr;
												break;
										}
								}
								break;
						}
					}

					if (cmID == 0) {
						MessageBox(NULL, "Run cm.exe", "Error", MB_OK);
						break;
					}

					cm = OpenProcess(PROCESS_VM_READ, FALSE, cmID);
					if (cm == NULL) {
						MessageBox(NULL, "Can't open proc", "Error", MB_OK);
						break;
					}



					if (ReadProcessMemory(cm, baseAddr+0x1C89, buf, 
											HASH_SIZ-1, &bRead) == 0) {
						MessageBox(NULL, "Can't read mem", "Error", MB_OK);
						break;
					}

					if (ReadProcessMemory(cm, baseAddr+0x30F0, block3, 
											BLOCK_SIZ, &bRead) == 0) {
						MessageBox(NULL, "Can't read mem", "Error", MB_OK);
						break;
					}

					if (buf[0] == 0 && block3[0] == 0) {
						MessageBox(NULL, "Click OK in the crackme!", 
										"Error", MB_OK);
						break;
					}

					__asm {
						push	offset buf+8
						push	offset block3+168
						call	transform64
						push	edi
						movq	mm0, block3+168
						movd	mm1, dword ptr block3+172
						pxor	mm0, mm1
						lea		edi, buf
						movq	mm2, qword ptr [edi]
						por	mm0, mm2
						psrlw	mm0, 3
						movd	eax, mm0
						call	asciify

						xor	ecx, ecx
						inc	ecx
						shl	ecx, 3
						xor	edx, edx
						xor	ebx, ebx
						inc	edx
						lea	esi, buf
						
						loc_401A27:
						lodsb
						bswap	ebx
						mov	bl, [ecx+esi]
						sub	ax, bx
						xor	bx, bx
						bswap	ebx
						not	ax
						cmp	al, 19h
						ja	short loc_401A3E
						add	ebx, edx
						
						loc_401A3E:
						rol	edx, 1
						xor	ah, ah
						dec	ecx
						jnz	short loc_401A27
						inc	ecx
						xor	edx, edx
						pop	esi
						add	esi, 5

						mov	ebx_value, ebx
						emms
					}

					serial[13] = 0;
					serial [4] = '-';

					j = 0;
					for (i = 4; i > 0; i--) {
						k = buf[8+j]-0x30;
						if (k > 0x9) {
							k -= 0x11;
							serial[i-1] = k + block2[k] + 0x41 +1;
						}
						else 
							serial[i-1] = k + block1[k] + 0x41 - (i-1);
						j++;
					}

					j = 5;
					k = 1;
					for (i = 0; i < 8; i++) {
						if ((k & ebx_value) != 0)
							serial[j] = 0x41 - (buf[i] - buf[8+i]);
						else
							serial[j] = 0x41 - (buf[8+i] - buf[i]);
						j++;
						k = k << 1;
					}

					SetDlgItemText(hwnd, IDC_EDT2, serial);

					break;
				default:
					break;
			}
			break;

		case WM_CLOSE:
			EndDialog(hwnd, 0);
			return TRUE;

		default:
			return FALSE;
	}
	return TRUE;
}
