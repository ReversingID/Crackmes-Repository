#ifndef RESOURCE_H
#define RESOURCE_H

#define IDD_DLG1                1000
#define IDC_EDT2                1003
#define IDC_STC2                1004
#define IDC_BTN1                1005
#define IDC_EDT1                1001

#endif
