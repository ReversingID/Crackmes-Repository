Welcome to tNO Trial Crackme,

This crackme isnt supposed to be hard, but its very interesting, there are no anti-[insert tool name here] tricks, you just need to think a bit :)

A valid keygen is a solution, not a crack, if you solve it, and you are willing to join tNO come and talk to us in #tno2001 @ efnet.

Please do not publish solutions to this keygenme until it get expired.

Greets.

Ousir