#define 		WIN32_LEAN_&_MEAN
#include 		<stdio.h>
#include 		<stdlib.h>
#include 		<math.h>
#include 		<time.h>
#include 		<windows.h>
#include 		<commctrl.h>
#include 		<commdlg.h>
#include			<windowsx.h>
#include 		<wincrypt.h>
#include			<objbase.h>


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	DEFINITIONS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


typedef struct
{
	BYTE xx[88];
}MD5_CONTEXT,*PMD5_CONTEXT;
typedef DWORD MD5_DIGEST[4],*PMD5_DIGEST;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	FUNCTION PROTOTYPES
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int main(void);
int MD5_Hash(PMD5_CONTEXT pContext,PMD5_DIGEST pDigest,char* pData, int len);


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	GLOBAL VARIABLES
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
LPSTR lpszTitle = 	" ===============================================\n"
					"   vic4key's Keygene #2 - Keygen  \n"
					" ===============================================\n";

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	CODE
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int main(void)
{
	static char szName[100] = "";
	static char szTmp[10] = "";
	static char sz20DigitKeyString[50] = "";
	static LPSTR TMultiReadExclusives = "TMultiReadExclusives";
	static MD5_CONTEXT md5;
	static MD5_DIGEST hash;
	int i,x,len,lenName;

	puts(lpszTitle);	
	printf("Name:");
	gets(szName);
	lenName = strlen(szName);
	
	x = 0;
	for ( i=0; i < 20; i++ ) 
	{
		if (x > lenName-1)
			x =0;
		_ltoa(szName[x] ^ TMultiReadExclusives[i], szTmp,10);
		len = strlen(szTmp);
		if (len > 1)
			strncat(sz20DigitKeyString,&szTmp[1],1);
		else
			strncat(sz20DigitKeyString,&szTmp[0],1);
		x++;
	}

	MD5_Hash(&md5,hash,sz20DigitKeyString,20);
	
	printf	(	"Serial: %.8x%.8x%.8x%.8x\n",
				_bswap(hash[0]),
				_bswap(hash[1]),
				_bswap(hash[2]),
				_bswap(hash[3])
			);

	puts("Press any key to continue");
	getchar();
}
