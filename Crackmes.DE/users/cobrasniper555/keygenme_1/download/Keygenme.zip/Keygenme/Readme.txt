Hello, I am cobrasniper555. I hope this keygenme will work out great for those beginners. If something is wrong, please leave a comment on it and I'll do my best to make something better. Please keep low on the hateful remarks on this, this is my first keygenme/crackme. If/when you find a solution and/or make a keygen, please send it to me at: cobrasniper555@gmail.com!

~~~~~~~~~~~~
NOTE:
If you want to take a look at the C++ source, you get the password when you've successfully completed the mission, please don't brute-force it, that would be cheating, let's have some fun out of this!
~~~~~~~~~~~~

Rules:
~~~~~~~~~~~~
1)No patching! <- Stay close to this rule for most crackmes
2)Find your serial and find the algorithm used
3)Make a keygen >:D
~~~~~~~~~~~~
~~~~~~~~~~~~
Thanks to:
Crackmes.de - I love doing the crackmes on there! They're awesome!
Reversing.be - Great tutorials and everything :D
You, and especially you - Thank you for trying out my keygenme! I hope you have fun!




























~~~~~~~~~~~~
HINT:
Althought in most cases, you want to find the whole serial, well for this, maybe I was too lazy to make a function to check all the characters to see if they're right.
Hope this helps for those lost souls. >:D
~~~~~~~~~~~~