	This crackme is my second crackme. It requires the use of registry keys so please, don't think it's a virus and delete it, if you don't want it, delete it, but if you want to work with this crackme, note this! So with that said, watch out with those adaware blockers and other little interesting programs. I don't think you'll run into anything like this in the field, but let's see how good your skills are with disassembling!
	No packer was used in the production of this crackme. This was however programmed in C++ (I wish I fully understood assembler...). I don't feel like giving out any other clues other than these because it's for you guys to test and see what it's like. Anyhow now, I will see you guys soon with keygens and solutions!

Good luck!
Cobra

P.S-Thanks to Crackmes.de for hosting everything ever needed to learn to crack and everything about exploiting PEs and such. Thanks to boonz, who made me  my first crackme ever solved just about by myself and I keygenned it too, XD. Adios amigos!