#include <stdio.h>

main(){
       
    do{
    
    system ("color 0C");
    system ("title keygen by [misunderstood]");
	char name[24];
	int EAX = 0;
	int EDX = 0;
	int ECX = 0;
	int help = 0;
	int i = 0;
       
    printf("\n*~*~*~*~ Keygen for starlight's continue winkengenme ~*~*~*~*");
	printf("\n~*~*~*~*~*~*~*~*~*~ by [misunderstood] *~*~*~*~*~*~*~*~*~*~*~");
	printf("\n\nEnter your name (must be between 4 and 15 letters):> ");

       fgets(name,30, stdin);
        		  
	if ( (strlen(name)-1) < 4 ) { // not less than 4
		printf("\nMore than 3 Characters needed!\n");
		system("PAUSE");
		break;
	}
    
	if ((strlen(name)-1) > 22) { // not more than 22
		printf("\nNo more than 22 Characters!\n");
		system("PAUSE");
		break;
	}
    
    if (strchr(name,' ')){ //search for SPACE�s (not allowed)
        printf("\nInvalid name!\n");
        system("PAUSE");
        break;
    }
    
      printf("Your serial :> ");
       
       while (i < (strlen(name) - 2)){
             
       EAX = name[i];
       EDX = name[i];
       ECX = name[i+1]; 
       
       help = EAX;
       
       while(ECX > 0){
                 if (EAX <= ECX){
                         EDX = EAX;
                         EAX = ECX;
                         ECX = EDX;                      
                         }
                 
                 EDX = EAX % ECX; 
                 EAX = EAX / ECX;
                 EAX = ECX;
                 ECX = EDX;
                 
                 }
                 
         EAX = EAX + help;
         ECX = 0xA;
         EDX = EAX % ECX;
         EAX = EAX / ECX;
         EDX += 0x30;
         i += 1;
         
         printf("%c",EDX);
         
         }
         printf("\n");
         system("pause");
         system("cls");  
         
         }while(1);
         
       }              
