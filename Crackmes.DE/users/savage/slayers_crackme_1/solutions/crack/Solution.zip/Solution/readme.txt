keygen does:
	- copy the computername to clipboard
	- create reg.key with needed key

-------------------------------------------------

1. start the crackme
2. start the keygen
3. press doit-button
4. copy reg.key in the workdirectory of crackme

