Hi this is my first keygenme so it is not supposed to be hard :)
So there is one golden rule.. as you can guess "don't patch it" hehe..
Just i will accept keygens/Keymakers..

Yep.. I think this little Keyme will not take your much time.. but who knows :)

PS : All accepted solutions will be rewarded with source code..

Enjoy
Best Regards
Slayer < slayeronthefly@yahoo.com >