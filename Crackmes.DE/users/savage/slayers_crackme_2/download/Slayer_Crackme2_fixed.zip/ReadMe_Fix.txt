This crackme was rejected because of packed + crypted so these are original forms..
Sorry :)