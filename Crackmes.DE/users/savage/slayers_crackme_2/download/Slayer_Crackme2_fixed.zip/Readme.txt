My second crackme,
I hope you will like it. (Details in About Section)

Slayer // OTF
18.11.2k6