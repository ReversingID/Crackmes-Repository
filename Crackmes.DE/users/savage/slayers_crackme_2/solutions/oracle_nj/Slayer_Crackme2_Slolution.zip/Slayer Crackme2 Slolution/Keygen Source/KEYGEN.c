#include<stdio.h>
#include<string.h>
#include<conio.h>

#include"miracl.h"

#pragma comment (lib, "miracl.lib")
#pragma comment (linker, "/NODEFAULTLIB:LIBC.lib")

typedef unsigned long int dword;

dword NameHash(char *);

void main()
{
	FILE *f;
	dword i,l,addrev,r;
	char name[50]={0};
	char t[4]={0},ciphertext[513]={0},plaintext[150]={0},tmp[10]={0};
	big d,n,pt,ct;

	miracl *mip = mirsys(2048, 0);
	mip->IOBASE = 16;

	n = mirvar(0);
	d = mirvar(0);
	pt= mirvar(0);
	ct= mirvar(0);

	//Initialize Modulus, N & Private Key, D
	cinstr(n,"8396A3806D9022BA3F636BFB4A310DEF15FF9A092289A2AC0312EBE7CD5B28438275EAEF3F74225201EA9DF584148A8BFF8382023AD508BBED7118CDA863B97E10B7938FEC257F13596D7B43E506674E1AC37EC60E62FB94FF4198417EE43B9ABF4870AC7F245AD905E55CFD856DB112A9C04A94E1670CF2B19706D15DF7EA2B7193E8A185BFB5E67E9D272F83B2861B050328892F96827D90072CE20DD71F5D24A7AEA3ECF18502AC6832E459D80E90705A24A64CF4313638480F2B8587A7D7941BEC394E3AE532749911DF3E1304EFB2B78C6F783763F1E87CB5BA0DBBDF8513E5B0A3128F503A174E7CDE9269F05DF3BA4B411B2B0755C12EA12B73DB1AB9");
	cinstr(d, "10001");

	printf("\nSlayer Crackme2 Keyfile generator by ORacLE_nJ\n+++++++++++++++++++++++++++++++++++++++++++++++\n");

	printf("\n\nName (Max 25 Chars please..) : ");
	gets(name);
	l=strlen(name);

	//Convert name to hex
	for(i=0;(i<l&&i<25);i++)
	{
		sprintf(t,"%.02X",name[i]);
		strcat(plaintext,t);
	}

	strcat(plaintext,"002C");			//Terminate

	r = NameHash(name);					//Compute NameHash

	l=sprintf(tmp,"%lX",r);
	
	for(i=0;i<l;i++)
	{
		if(tmp[i] == '0')
			strcat(plaintext,"10");
		else
		{
			sprintf(t,"0%c",tmp[i]);
			strcat(plaintext,t);
		}
	}

	strcat(plaintext,"2C");				//Terminate


	//Enabling the Important button to become The King !!
	addrev = 0x4012E1 ^ 0x19821982;

	l=sprintf(tmp,"%lX",addrev);
	
	for(i=0;i<l;i++)
	{
		if(tmp[i] == '0')
			strcat(plaintext,"10");
		else
		{
			sprintf(t,"0%c",tmp[i]);
			strcat(plaintext,t);
		}
	}

	strcat(plaintext,"2400");			//Terminate

	cinstr(pt, plaintext);				//Initialize plaintext

	f=fopen("s2License.key","w");

	powmod(pt, d, n, ct);				//Serial = pt ^ d mod N
	cotstr(ct, ciphertext);				//Convert ciphertext to string

	fprintf(f,"%s",ciphertext);			//Write to file

	printf("\nDone . . . . !!\n\n");

	fclose(f);
	mirkill(n);
	mirkill(d);
	mirkill(pt);
	mirkill(ct);
	mirexit();
}


dword NameHash(char *n)
{

	int l;
	dword s=0;
	l = strlen(n);


	_asm{
		MOV     ECX, l
		MOV		ESI, n
		XOR     EDX, EDX
	a:
		XOR     EAX, EAX
		MOV     AL, BYTE PTR DS:[ESI]
		SHL     EAX, CL
		ROL     EAX, 1
		SHR     EAX, 2
		ADD     EDX, EAX
		SUB     EDX, ECX
		ADD     EAX, EAX
		ADD     EDX, EAX
		ADD     EDX, ECX
		ROL     EDX, 2
		INC     ESI
		DEC     ECX
		JNZ     SHORT	a
		MOV		s, EDX
	}

	return s;

}


