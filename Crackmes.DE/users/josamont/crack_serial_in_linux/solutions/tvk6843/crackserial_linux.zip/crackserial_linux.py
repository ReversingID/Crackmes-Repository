user_name = input('User? <for example"David">')
password = 0
temp = 0
for c in user_name:
  temp = (temp ^ ord(c)) * 7
  password = password + temp

print "user name =", user_name
print "password =", password

