def genpasswd(username):
	accum = mult = 0

	for c in username:
		mult = 7 * (ord(c) ^ mult)
		accum += mult

	return accum

if __name__ == "__main__":
	
	""" 
	replace "porcodio" with any username of your choice
	note that it must be at most 30 chars to be valid
	"""

	print genpasswd("porcodio")
