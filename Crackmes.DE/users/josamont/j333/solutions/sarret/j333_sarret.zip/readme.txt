5 files:
- solution.txt :	solution
- dis :			objdump in AT&T syntax
- dis_intel :		objdump in Intel syntax
- he :			hexdump
- readme.txt :		this file

