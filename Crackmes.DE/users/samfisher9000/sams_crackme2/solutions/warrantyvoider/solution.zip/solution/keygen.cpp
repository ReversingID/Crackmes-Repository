#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>

#define ENOUGH (128)

// Concatenate the decimal representation of all ascii-values of the source string
// and return as result string
void stringToDecimalString(char * result,char * source){
	*result = '\0';
	char buffer[ENOUGH];
	char *p = source;
	while (*p){
		sprintf(buffer,"%d",*p);
		strcat(result,buffer);
		p++;
	}
}

void main(){
	char username[ENOUGH];
	printf("Username: ");
	gets(username);

	//loop over username
	unsigned int ESI = 0;
	unsigned int loopTemp = 0;
	for (unsigned int ii=0; ii<strlen(username); ii++){
		unsigned char ch = (unsigned char) username[ii];

		if (ch < 110) ch+=11;
		if (ch > 110)	ch -= 13;
		if (ch == 110)	ch += 20;
		ch += 11;

		ESI += ch;
		loopTemp += (ESI - 63);
	}
	unsigned int firstComponent =	loopTemp+ESI;
	printf("firstComponent: %d \n",firstComponent);

	//Convert Result to String
	char loopResultAsString[ENOUGH];
	sprintf(loopResultAsString,"%d",firstComponent);

	// ASCII-to-Decimal
	char decimalString[ENOUGH];
	stringToDecimalString(decimalString,loopResultAsString);
	printf("decimalString: %s \n",decimalString);

	//Sliding window
	char serialWithDashes[ENOUGH]; serialWithDashes[0] = '\0';
	for (unsigned int ii=0; ii<strlen(loopResultAsString); ii++){
		strcat(serialWithDashes,"-");
		strncat(serialWithDashes,decimalString+ii,4);
	}
	printf("serialWithDashes: %s \n",serialWithDashes);

	// strlen(serialWithDashes) und "13" anf�gen
	char correctSerialAsString[ENOUGH];
	sprintf(correctSerialAsString,"%d",strlen(serialWithDashes));
	strcat(correctSerialAsString,"13");
	strcat(correctSerialAsString,serialWithDashes);

	printf("\nFinal serial: %s \n",correctSerialAsString);
	getchar();
}



