Public Class frmKeygen
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(32, 32)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(240, 22)
        Me.TextBox1.TabIndex = 0
        Me.TextBox1.Text = ""
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(32, 120)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.Size = New System.Drawing.Size(240, 22)
        Me.TextBox2.TabIndex = 1
        Me.TextBox2.Text = ""
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(88, 64)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(120, 24)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Generate"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(152, 16)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Nom (Name) :"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(24, 104)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(88, 16)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Serial"
        '
        'frmKeygen
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        Me.ClientSize = New System.Drawing.Size(296, 160)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmKeygen"
        Me.Text = "Keygen for CrackMe#1 from Lunatic.NET"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim num As Integer
        Dim exception1 As Exception
        Dim num5 As Integer
        Dim num6 As Integer

        Dim i As Integer
        Dim Serial As String


        If Len(TextBox1.Text) < 4 Then
            MsgBox("Min 4 chars")
            Exit Sub
        End If

Label_0001:



        Try
            num6 = 1
Label_0009:
            num = 1
            Me.TextBox2.Text = ""



Label_0017:
            num = 2
            Dim num2 As Integer = 0
Label_001C:
            num = 3
            Dim num3 As Integer = 0
Label_0022:
            num = 4
            Dim text2 As String = ""


Label_002B:
            num = 5
            Dim text3 As String = ""



Label_0035:
            num = 6

            Dim sText As String = Strings.UCase(Me.TextBox1.Text)
Label_0049:
            num = 7
            If (sText = "") Then
                GoTo Label_0269
            End If
Label_0061:
            num = 9
            Dim num8 As Integer = Len(sText)
            i = 1
            GoTo Label_00CE

Label_0076:
            num = 10
            text2 = CStr(Asc(Strings.Mid(sText, i, 1)))
Label_0092:
            num = 11
            text2 = CStr((CDbl(text2) + (i - 48)))
Label_00AD:
            num = 12
            text3 = (text3 & text2)
Label_00BC:
            num = 13
            i += 1
Label_00CE:
            If (i <= num8) Then
                GoTo Label_0076
            End If
Label_00D8:
            num = 14
            If (i = 1) Then
                GoTo Label_0269
            End If
Label_00EB:
            num = 16
            Dim num7 As Integer = Strings.Len(text3)
            Dim num1 As Integer = 1
            GoTo Label_0186
Label_00FF:
            num = 17
            num2 = CStr(Mid(text3, num1, 1))
Label_0112:
            num = 18
            num3 = CStr(Mid(text3, (num1 + 1), 1))
Label_0128:
            num = 19
            If (num1 <> 3) Then
                GoTo Label_0159
            End If
Label_0130:
            num = 20
            Serial = (Serial & " - OEM - " & CStr(num2 + num3))
Label_0153:
            num = 21
            GoTo Label_017C
Label_0159:
            num = 22
Label_015E:
            num = 23
            Serial = (Serial & CStr(num2 + num3))
Label_017C:
Label_017E:
            num = 25
            num1 = (num1 + 2)
Label_0186:
            If (num1 <= num7) Then
                GoTo Label_00FF
            End If
Label_018E:
            num = 26



            GoTo Label_0269


Label_019E:
            num5 = 0
            Select Case (num5 + 1)
                Case 0
                    GoTo Label_0001
                Case 1
                    GoTo Label_0009
                Case 2
                    GoTo Label_0017
                Case 3
                    GoTo Label_001C
                Case 4
                    GoTo Label_0022
                Case 5
                    GoTo Label_002B
                Case 6
                    GoTo Label_0035
                Case 7
                    GoTo Label_0049
                Case 8, 15, 27
                    GoTo Label_0269
                Case 9
                    GoTo Label_0061
                Case 10
                    GoTo Label_0076
                Case 11
                    GoTo Label_0092
                Case 12
                    GoTo Label_00AD
                Case 13
                    GoTo Label_00BC
                Case 14
                    GoTo Label_00D8
                Case 16
                    GoTo Label_00EB
                Case 17
                    GoTo Label_00FF
                Case 18
                    GoTo Label_0112
                Case 19
                    GoTo Label_0128
                Case 20
                    GoTo Label_0130
                Case 21
                    GoTo Label_0153
                Case 22
                    GoTo Label_0159
                Case 23
                    GoTo Label_015E
                Case 24
                    GoTo Label_017C
                Case 25
                    GoTo Label_017E
                Case 26
                    GoTo Label_018E
            End Select


        Catch obj1 As Exception
            Dim exception2 As Exception = CType(obj1, Exception)

            exception1 = exception2
            If (num5 = 0) Then
                num5 = num
                Select Case num6
                    Case 1
                        GoTo Label_019E
                End Select
                Throw
            End If
        End Try
        Throw exception1
Label_0269:

        TextBox2.Text = Serial


    End Sub
End Class
