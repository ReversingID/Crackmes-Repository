#include <iostream>

using namespace std;


int main()
{
  int id;
  int serial;

  int flag=0;
  do{

    cout <<"Enter ID :";
    cin >> id;
    if (9999<id && id <100000) flag=1;

  }while(flag==0);

  for (serial=99;serial<1000;serial++){
    int d = (id*serial)/(id+serial);
    if (849 < d && d < 900) break; // we have correct serial code
  }

  cout << "Serial code : "<<serial<<endl;
  cout << "Activation code : "<<(id-serial-99)<<endl;

  return 0;
}
