Hola!

KLiZMA wrote another crackme for you.

Rulz:

1. Find the correct Name/Serial combination
   to register .:: The KLiZMA'a ASCII Table::.
2. Write tutorial about it...
3. No patching and selfkeygenning.


Phanx:
- Ox87k, Kerberos, Ank83, HMX0101, CP3
- crackmes.de
- AHTeam and xt
- my girlfriend


                                     KLiZMA
                         -==fR0M RuSSiA WiTh l0VE=--