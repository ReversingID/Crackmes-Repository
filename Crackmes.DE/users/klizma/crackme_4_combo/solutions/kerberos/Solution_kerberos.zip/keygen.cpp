#include <iomanip>
#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>
#include <sstream>

using namespace std;

void badBoy()
{
  cerr << "Error :-/"<<endl;
  exit(1);
}

// Returns 1 if number in eV will pass stage #1 check in CME
int firstStage(string eV);

// Function is looking for value which can pass stage #1 check in CME and is greater than min
// return 1 if there was an error, else 0

int findFS(unsigned long int min,unsigned long int &r)
{
  if (min >=99999999) return 1;

  unsigned long int i=min+1;

  while(i < 99999999){
    ostringstream st;
    st<<dec<<setw(8)<<setfill('0')<<i;
    if (1==firstStage(st.str())) break;
    i++;
  }

  //error ... you need to have higher A :)
  if (i > 99999999) return 1;

  r = i;
  return 0;
}

int firstStage(string eV)
{
  unsigned char rB[8];
  unsigned long int v1,v4;

  for (int i=0;i<8;i++){
    rB[7-i] = eV[i]-'0';
  }

  v1 = rB[0]*rB[1]+rB[2]*rB[3];
  v4 = rB[5]*rB[7]+rB[4]*rB[6];

  if (v1 == v4) return 1;
  return 0;
}

/// Main function :)
void Brute()
{
  unsigned long int ID=0;
  unsigned long int i;

  long int a,b,c,d,e,h;

  a = 99999;

  // Read ID
  while(ID < 99999 || ID > 196288){
    cout <<"Enter ID : ";
    cin >>ID;
  }

  do{
    c = ID + 1;
    c <<=0x0A; // C = (b+i)/1024; =>  B+I = C (B = I+(A-0x400)) => 2I + (A-1024) = C => (C+1024-A)/2 =.= I

    int res =1;
    do{
      h = (c+1024-a)/2;
      a++;
      res = findFS(h,i);
      if (a > 999999) badBoy();
    }while (res != 0);

    b = i+ a - 0x400;
    c = (b+i)>>0x0A;
    d = i - a + b - c;
    int t=0;

    if (i<0) t=0xFF;
    e = (i+t)/256;
    if (e<0) t= 0x7F;
    e += ((a+t)/128);
    if (b<0) t=0x3F;
    e+= ((b+t)/64);
  }while (e<999999);

  cout << "======  FIRST  STAGE ======================"<<endl;
  cout << "First stage     : "<<i <<endl;
  cout << "==========================================="<<endl;

 cout <<endl<< "======= SECOND STAGE ======================"<<endl;
  cout << "Serial key   /1 : "<<a<<endl;
  cout << "Serial key   /2 : "<<b<<endl;
  cout << "Serial key   /3 : "<<c<<endl;
  cout << "Serial key   /4 : "<<d<<endl;
  cout << "Serial key   /5 : "<<e<<endl;
  cout << "==========================================="<<endl;

  cout <<endl<<  "====== THIRD STAGE ========================"<<endl;
  cout <<"ID               : "<<ID<<endl;
  cout <<"Serial           : "<<e<<endl;
  cout << "==========================================="<<endl;
}


int main()
{
  Brute();
  return 0;
}
