CrackMe #4 [Combo]

Hola!
KLiZMA made another crackme for you!
Algo combined from 1st, 2nd and 3rd crackmes. 

Rulz:

1. unpack it
2. complete 3 stages with success
3. write tutorial and make keygen
4. no self-keygenning and 'all accept' patching

Phanx:

-crackmes.de
-Ox87k, Ank83, HMX0101, CP3, Kerberos
-my girlfriend