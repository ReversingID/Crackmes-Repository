Hola!

KLiZMA wrote another stupid crackme for you.

Rulz:
-unpack it carefully
-patch 1 byte (or 2 byte) of this crackme <-- it changed "Not patched!" to "Patched!"
-write good tutorial about...

Phanx:
- Ox87k, Kerberos, Ank83, HMX0101, CP3
- crackmes.de
- AHTeam and xt
- my girlfriend


                                     KLiZMA
                         -==fR0M RuSSiA WiTh l0VE=--