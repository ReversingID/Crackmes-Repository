// Keygen for Logik crackme #3 by TSCube 12/07/2001

#include <stdio.h>
#include <string.h>


/////////////////////////////////////////////////
// Converts a 64bit number (__int64) to a string //
/////////////////////////////////////////////////
void int64tostring(const __int64 bignum,	// 64bit number to convert to string
				   char* buffer)			// buffer for converted number
{
	__int64 tmp = bignum;
	int index=0;

	while (tmp)
	{
		buffer[index++]=(char) (tmp%10)+'0';
		tmp = tmp/10;
	}

	buffer[index]=0x00;
	strrev(buffer);
}



int main(void)
{
	char szName[100];
	__int64 serial=0;
	char szSerial[100];

	// These are the names given by IDA : I was too lazy to change them ;)
	unsigned int var_30=0; // will contain sum of ASCII values
	unsigned int var_2C=0;
	unsigned int var_34=0;
	unsigned int var_10,var_C,var_20,var_1C,var_18,var_14;

	printf("Keygen for Logik crackme #3 by TSCube 12/07/2001\n\n");
	printf("Name : ");
	gets(szName);

	if (strlen(szName)<4)
	{
		printf("At least 4 letters please !");
		return 1;
	}

	unsigned int var_38=strlen(szName);

	// Get sum of name ASCII values
	for (unsigned int i=0;i<strlen(szName);i++) var_30 += szName[i];


	// Ripped from crackme :
	__asm
	{
	push    [var_34]
	push    [var_38]
	push    [var_34]
	push    [var_38]
	mov     eax, 0FFAh
	cdq
	call    __LLMUL
	push    edx
	push    eax
	push    [var_34]
	push    [var_38]
	mov     eax, 0FFAh
	cdq
	call    __LLMUL
	call    __LLMUL
	call    __LLDIV
	mov     [var_10], eax
	mov     [var_C], edx
	mov     eax, [var_30]
	mov     edx, [var_2C]
	shld    edx, eax, 0Ah
	shl     eax, 0Ah
	mov     [var_30], eax
	mov     [var_2C], edx
	push    [var_2C]
	push    [var_30]
	mov     eax, [var_10]
	mov     edx, [var_C]
	call    __LLMUL
	xor     edx, edx
	mov     [var_10], eax
	mov     [var_C], edx
	mov     eax, [var_10]
	mov     edx, [var_C]
	xor     eax, [var_38]
	xor     edx, [var_34]
	mov     [var_10], eax
	mov	    [var_C], edx
	mov     eax, [var_10]
	mov     edx, [var_C]
	and     eax, [var_38]
	and     edx, [var_34]
	mov     [var_10], eax
	mov     [var_C], edx
	mov     eax, [var_10]
	mov     edx, [var_C]
	shld    edx, eax, 0Ah
	shl     eax, 0Ah
	mov     [var_10], eax
	mov     [var_C], edx
	push    [var_2C]
	push    [var_30]
	push    [var_C]
	push    [var_10]
	mov     eax, [var_10]
	mov     edx, [var_C]
	call    __LLMUL
	call    __LLMUL
	mov     [var_10], eax
	mov     [var_C], edx
	push    [var_34]
	push    [var_38]
	mov     eax, [var_30]
	mov     edx, [var_2C]
	call    __LLMUL
	mov     [var_20], eax
	mov     [var_1C], edx
	mov     eax, [var_10]
	mov     edx, [var_C]
	shrd    eax, edx, 4
	shr     edx, 4
	mov     [var_18], eax
	mov     [var_14], edx
	mov     eax, [var_18]
	mov     edx, [var_14]
	xor     eax, [var_38]
	xor     edx, [var_34]
	mov     [var_18], eax
	mov     [var_14], edx
	jmp endasm

__LLMUL:
	push    edx
	push    eax
	mov     eax, dword ptr [esp+10h]
	mul     dword ptr [esp+0]
	mov     ecx, eax
	mov     eax, [esp+4]
	mul     dword ptr [esp+0Ch]
	add     ecx, eax
	mov     eax, [esp+0]
	mul     dword ptr [esp+0Ch]
	add     edx, ecx
	pop     ecx
	pop     ecx
	retn    8


__LLDIV:
	push    ebp
	push    ebx
	push    esi
	push    edi
	xor     edi, edi
	mov     ebx, dword ptr [esp+14h]
	mov     ecx, dword ptr [esp+18h]
	or      ecx, ecx
	jnz     short LLDIV_1
	or      edx, edx
	jz      short LLDIV_8
	or      ebx, ebx
	jz      short LLDIV_8

LLDIV_1:
	or      edx, edx
	jns     short LLDIV_2
	neg     edx
	neg     eax
	sbb     edx, 0
	or      edi, 1
 
LLDIV_2:
	or      ecx, ecx
	jns     short LLDIV_3
	neg     ecx
	neg     ebx
	sbb     ecx, 0
	xor     edi, 1
 
LLDIV_3:
	mov     ebp, ecx
	mov     ecx, 40h
	push    edi
	xor     edi, edi
	xor     esi, esi

LLDIV_4:
	shl     eax, 1
	rcl     edx, 1
	rcl     esi, 1
	rcl     edi, 1
	cmp     edi, ebp
	jb      short LLDIV_6
	ja      short LLDIV_5
	cmp     esi, ebx
	jb      short LLDIV_6

LLDIV_5:
	sub     esi, ebx
	sbb     edi, ebp
	inc     eax

LLDIV_6:
	loop    LLDIV_4
	pop     ebx
	test    ebx, 1
	jz      short LLDIV_7
	neg     edx
	neg     eax
	sbb     edx, 0

LLDIV_7:
	pop     edi
	pop     esi
	pop     ebx
	pop     ebp
	retn    8

LLDIV_8:
	div     ebx
	xor     edx, edx
	jmp     short LLDIV_7


endasm:
	}

	// Converts var_14 and var_18 to a 64bit number :
	serial = var_14;
	serial = serial << 32;
	serial += var_18;

	serial ^= strlen(szName);

	serial *= 16;

	int64tostring(serial,szSerial);

	printf("Serial = %s",szSerial);
	getchar();

	return 0;
}