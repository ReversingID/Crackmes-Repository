#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

int SomeMass[0x100];

int CheckName(char* s)
{
	char* ch = s;
    for (int i = 0; i < 8; i++)
    {		
        if (*ch < 'A' || (*ch > 'Z' && *ch < 'a') || *ch > 'z')
			return 0;
		ch++;
    }
    return 1;
}

int SortMass()
{
	int i = 0, j, n = 0, m;
    
    while (i < 254)
    {
		j = i;
		while (++j < 256)
        {
			m = SomeMass[i];
			if (m > SomeMass[j])
            {
				++n;
				SomeMass[i] = SomeMass[j];
				SomeMass[j] = m;
            }
		}
        i++;
	}
    return n + 1; // I dont know how to explain it, but <n> always at a lower on 1
}

int main()
{
    char szName[9];
    int i, n, n1, SomeVal;
    memset(&szName, 0, 9);
    printf("Keygen for <KeyGenMe#2 bu BuKo> by BoRoV\n\nName: ");
    scanf("%s", szName);
    if (lstrlen(szName) == 8)
    {
          if (CheckName((char *)szName))
          {
             n = *(int *)szName;
             n1 = *(int *)&szName[4];
             n += n1;
             for (i = 0; i < 0x100; i++)
             {
                 SomeMass[i] = n;
                 n *= 0x13;
             }
             n = SortMass();
             
             printf("Serial: %d\n", n);
          }
          else
              printf("Error: Name must be consist only a-z, A-Z\n");
    }
    else
        printf("Error: Name length must be 8 chars\n");
        
    system("pause");
    return 0;
}
