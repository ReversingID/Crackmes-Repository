﻿Imports System
Imports System.IO
Imports System.Windows.Forms
Imports System.Collections
Imports System.Text.RegularExpressions

Public Class Form1
    Dim config As String = ""
    Dim config_array As New ArrayList()
    Dim filejkf As String
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim serial, a9, a8, po1, po2, po3 As String
        'Read from file
        If TextBox1.Text = "" And File.Exists(Environment.SystemDirectory & "\hack.jkf") = True Then
            filejkf = Environment.SystemDirectory & "\hack.jkf"
            readfile(filejkf)
            TextBox1.Text = config
        End If
        '-----------------------------------
        If TextBox1.Text = "" Then
            TextBox2.Text = "Serial not entered"
        Else
            serial = TextBox1.Text
            a9 = Mid(serial, 2, 1)
            a8 = Mid(serial, 2, 2)
            po1 = Mid(serial, 13, 1)
            po2 = Mid(serial, 6, 1)
            po3 = Mid(serial, 8, 1)
            If Mid(serial, 2, 1) = 1 Then
                TextBox2.Text = "ar" & po3 & "ntar" & po3 & "oi" & a9
            ElseIf Mid(serial, 2, 1) = 2 Then
                TextBox2.Text = "n" & po3 & "nt" & po2 & "aroi" & po1 & a9
            ElseIf Mid(serial, 2, 1) = 3 Then
                TextBox2.Text = "n" & po2 & "nt" & po1 & "aroi" & po3 & a9
            ElseIf Mid(serial, 2, 1) = 4 Then
                TextBox2.Text = "a" & po3 & "af" & po3 & "hl" & "br" & po1 & a9
            ElseIf Mid(serial, 2, 1) = 5 Then
                TextBox2.Text = "w" & po3 & "wf" & po1 & "afae" & a9 & po2
            ElseIf Mid(serial, 2, 1) = 6 Then
                TextBox2.Text = "n" & po1 & "nt" & po2 & "af" & "oi" & po3
            ElseIf Mid(serial, 2, 1) = 7 Then
                TextBox2.Text = "o" & po2 & "on" & "za" & po3 & "im" & a9 & po1
            ElseIf Mid(serial, 2, 1) = 8 Then
                TextBox2.Text = "r" & po2 & "re" & po1 & "wlnd" & a9 & po3
            ElseIf Mid(serial, 2, 1) = 9 Then
                TextBox2.Text = "f" & "fwef" & "ae" & a9 & po1 & po3 & po2
            End If
            Button2.Enabled = True
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim serial, po1, po2, po3 As String
        Dim serial2, b9, b8, po5, po6, po7 As String
        'Read from file
        If TextBox4.Text = "" And File.Exists(Environment.SystemDirectory & "\hack2.jkf") = True Then
            filejkf = Environment.SystemDirectory & "\hack2.jkf"
            config = ""
            readfile(filejkf)
            TextBox4.Text = config
        End If
        If TextBox4.Text = "" Then
            TextBox3.Text = "Serial not entered"
        Else
            '-----------------------------------
            '-----------------------------------
            serial = TextBox1.Text
            po1 = Mid(serial, 13, 1)
            po2 = Mid(serial, 6, 1)
            po3 = Mid(serial, 8, 1)
            '----------------------------
            serial2 = TextBox4.Text
            b9 = Mid(serial2, 4, 1)
            b8 = Mid(serial2, 7, 1)
            po5 = Mid(serial2, 6, 6)
            po6 = Mid(serial2, 8, 3)
            po7 = Mid(serial2, 10, 2)
            If Mid(serial2, 4, 1) = 0 Then
                TextBox3.Text = "r" & b9 & po3 & "ck" & po5 & "oc" & b8 & "oc"
            ElseIf Mid(serial2, 4, 1) = 1 Then
                TextBox3.Text = "r" & b9 & po3 & "ck" & po5 & "oc" & b8 & "oc"
            ElseIf Mid(serial2, 4, 1) = 2 Then
                TextBox3.Text = "t" & po6 & b9 & po7 & "aaha" & b8 & po5 & "ha"
            ElseIf Mid(serial2, 4, 1) = 3 Then
                TextBox3.Text = "e" & po2 & b9 & po3 & "ra" & po7 & "of" & b8 & po7 & "of"
            ElseIf Mid(serial2, 4, 1) = 4 Then
                TextBox3.Text = "c" & po7 & b9 & po5 & "dsac" & b8 & "raac" & po3
            ElseIf Mid(serial2, 4, 1) = 5 Then
                TextBox3.Text = "c" & po7 & b9 & "in" & po3 & "ra" & b8 & "ra" & po5 & po6
            ElseIf Mid(serial2, 4, 1) = 6 Then
                TextBox3.Text = po1 & po5 & po2 & po6 & "i" & b9 & "gaac" & b8 & "ac"
            ElseIf Mid(serial2, 4, 1) = 7 Then
                TextBox3.Text = "r" & po6 & b9 & po6 & "wl" & po1 & "nd" & b8 & "nd" & po1
            ElseIf Mid(serial2, 4, 1) = 8 Then
                TextBox3.Text = "e" & po2 & b9 & "oDr." & po2 & b8 & po6 & "r."
            ElseIf Mid(serial2, 4, 1) = 9 Then
                TextBox3.Text = "o" & po5 & po3 & po7 & po2 & po6 & b9 & "zaim" & b8 & "im"
            End If
        End If
    End Sub
    '--
    Sub readfile(ByVal file As String)
        On Error Resume Next
        Dim objReader As New StreamReader(filejkf, System.Text.Encoding.GetEncoding(1252))
        config = objReader.ReadLine()
        objReader.Close()
    End Sub
End Class
