﻿Public Class Form1

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        On Error Resume Next
        If Len(TextBox1.Text) < 5 Then
            TextBox2.Text = "min 5 chars"
            TextBox3.Text = "min 5 chars"
            TextBox4.Text = "min 5 chars"
        Else
            Dim name, serial, regcode, id As String
            'SERIAL--------------------------------
            Dim i As Integer
            serial = ""
            For i = Len(TextBox1.Text) To 1 Step -1
                serial = serial & Hex(Asc(Mid(TextBox1.Text, i, 1)))
            Next
            TextBox2.Text = serial
            'RegCode----------------------------
            TextBox3.Text = "210579ioO-avB-pM"
            'ID----------------------------------
            TextBox4.Text = "ua921N" & serial & "pnqVTm"
        End If
    End Sub
End Class