This is my First Crackme Written in Visual Basic. You've To find serial and reg With Id for your name.
Mission:
Patch those nags
write A keygen.
no selfkeygen.
Write a nice solution

Easy Crackme...

It's Packed
