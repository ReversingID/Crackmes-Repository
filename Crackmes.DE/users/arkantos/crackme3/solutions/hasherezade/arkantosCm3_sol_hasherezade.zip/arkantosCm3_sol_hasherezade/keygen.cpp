#include <cstdlib>
#include <iostream>
/*
 *keygen for Arkantos's Crackme3
 *coded by hasherezade
 * */
using namespace std;

int main(int argc, char *argv[])
{
    string name;
    string serial1;

    static char key[10];
    int eax,edx,ecx;
    int f,n;
    cout<<"enter the username: ";
    cin>>name;
    if(name.length()<6){
    	cout<<"name should be at least 6 characters long"<<endl;
	return EXIT_FAILURE;
    }
    cout<<"enter the serial1: ";
    cin>>serial1;
    if(serial1.length()<7){
    	cout<<"serial1 should be at least 7 characters long"<<endl;
	return EXIT_FAILURE;
    }

    printf("---\n");

    printf("serial2: %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n",
		    serial1[5],name[5],serial1[0],name[0],serial1[3],name[5],name[1],serial1[4],
		    serial1[5],name[0],name[3],name[5],serial1[0],name[0],serial1[1],name[1],
		    name[5],name[5],name[1],serial1[4],serial1[5],name[0],serial1[0],name[0],
		    name[5],serial1[0],name[0],serial1[5],name[3],name[5],name[1],serial1[4],
		    serial1[5],name[0],name[5],serial1[3],serial1[0]);

    printf("serial3: %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n",
		    name[5],name[1],serial1[4],serial1[5],name[0],name[5],name[5],name[1],
		    serial1[4],serial1[5],name[0],name[5],name[1],serial1[4],serial1[5],
		    name[0],serial1[0],name[0],name[5],serial1[3],serial1[0],serial1[5],
		    name[5],serial1[0],name[0],serial1[3],name[5],serial1[0],name[0],
		    name[3],serial1[1],name[1],serial1[5],name[3]);
    printf("---\n");

    system("PAUSE");
    return EXIT_SUCCESS;
}

