﻿Public Class Form1

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        On Error Resume Next
        If Len(TextBox1.Text) < 5 Then
            TextBox2.Text = "min 5 chars"
            TextBox3.Text = "min 5 chars"
            TextBox4.Text = "min 5 chars"
            TextBox5.Text = "min 5 chars"
        Else
            Dim name, lastname, organization, serial, id As String
            'LASTNAME---------------
            name = TextBox1.Text
            name = name.ToUpper
            lastname = Mid(name, 2, 1) & Mid(name, 3, 1) & "F" & Mid(name, 5, 1) & Mid(name, 1, 1) & "TJ" & Mid(name, 4, 1)
            TextBox2.Text = lastname
            'ORGANIZATION-----------
            organization = Mid(lastname, 3, 1) & Mid(lastname, 2, 1) & Mid(lastname, 5, 1) & Mid(lastname, 4, 1) & Mid(lastname, 1, 1) & Mid(lastname, 3, 1) & Mid(lastname, 4, 1) & Mid(lastname, 1, 1) & "25I"
            TextBox3.Text = organization
            'SERIAL-----------------
            Dim i As Integer
            Dim temp As String
            For i = Len(TextBox1.Text) To 1 Step -1
                temp = temp & Hex(Asc(Mid(TextBox1.Text, i, 1)))
            Next
            serial = "s15tauo" & temp & "zmN"
            TextBox4.Text = serial
            'ID---------------------
            id = Hex(Asc(Mid(organization, 2, 1))) & Hex(Asc(Mid(organization, 4, 1))) & Hex(Asc(Mid(organization, 3, 1))) & Hex(Asc(Mid(TextBox1.Text, 1, 1)))
            TextBox5.Text = id
        End If
    End Sub
End Class

'Name: deurus
'Lastname: EUFUDTJR					(with name in upercasse 2º-3º+F-5º-1º+TJ-4º)
'Organization: FUDUEFUE25I			(with lasname 3º-2º-5º-4º-1º-3º-4º-1º+25I)
'Serial: s15tauo737572756564zmN		(s15tauo+reverse ascii hex values of name+zmN)
'ID: 55554464						(UUDd) = (with organization 2º-4º-3º in ascii)+(with name 1º in ascii)

'Name: ojete
'Lastname: JEFEOTJT					(with name in upercasse 2º-3º+F-5º-1º+TJ-4º)
'Organization: FEOEJFEJ25I			(with lasname 3º-2º-5º-4º-1º-3º-4º-1º+25i)
'Serial: s15tauo6574656A6FzmN		(s15tauo+reverse ascii values of name+zmN)
'ID: 45454F6F						(EEOo) = (with organization 2º-4º-3º in ascii)+(with name 1º in ascii)
'
'Name: crackmes.de
'Lastname: RAFKCTJC							(with name in upercasse 2º-3º+F-5º-1º+TJ-4º)
'Organization: FACKRFKR25I					(with lasname 3º-2º-5º-4º-1º-3º-4º-1º+25i)
'Serial: s15tauo65642E73656D6B63617263zmN	(s15tauo+reverse ascii values of name+zmN)
'ID: 414B4363								(AKCc) = (with organization 2º-4º-3º in ascii)+(with name 1º in ascii)