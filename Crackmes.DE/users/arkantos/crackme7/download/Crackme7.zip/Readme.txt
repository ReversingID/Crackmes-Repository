This is my Second Crackme Written in Visual Basic. You've To find serial and reg With Id for your name.
Mission:
Enable Check Button.
Patch those nags
write A keygen.
no selfkeygen.
Write a nice solution

Easy Crackme...
