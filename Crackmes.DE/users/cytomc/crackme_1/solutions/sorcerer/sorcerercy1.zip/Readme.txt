C++ keygen made with C++ Builder 5.0 Enterprise Suit.
By:*Sorcerer*