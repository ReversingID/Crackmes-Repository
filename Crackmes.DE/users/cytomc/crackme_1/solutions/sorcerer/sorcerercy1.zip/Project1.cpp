//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USERC("extra.rc");
//---------------------------------------------------------------------------
#define WINDOW_NAME "SimpleWindow"
#define WINDOW_CAPTION "cyTOm!c #1 Keygen BY: *Sorcerer*"
#define EditID1   1
#define EditID2   2
#define ButtonID1 3
#define ButtonID2 4
//---------------------------------------------------------------------------
HINSTANCE hInstance;

HWND hWndEdit;
HWND hWndEdit2;
/*==============================================================================

       WndProc

==============================================================================*/
LRESULT CALLBACK _export WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  switch (message)
  {
    case WM_CREATE:
    {
     hWndEdit = CreateWindowEx(WS_EX_CLIENTEDGE, "Edit", "",
            WS_CHILD | WS_VISIBLE | WS_BORDER | ES_LEFT | ES_AUTOHSCROLL,
            20, 15, 245, 25, hWnd,(VOID*) EditID1, hInstance, NULL);

     hWndEdit2 = CreateWindowEx(WS_EX_CLIENTEDGE, "Edit", "",
            WS_CHILD | WS_VISIBLE | WS_BORDER | ES_LEFT | ES_AUTOHSCROLL | ES_READONLY,
            20, 40, 245, 25, hWnd,(VOID*) EditID2, hInstance, NULL);

     CreateWindowEx(WS_EX_CLIENTEDGE, "Button", "&Quit",
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_TEXT,
            20, 75, 75, 25, hWnd,(VOID*) ButtonID1, hInstance, NULL);

     CreateWindowEx(WS_EX_CLIENTEDGE, "Button", "&About",
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_TEXT,
            190, 75, 75, 25, hWnd,(VOID*) ButtonID2, hInstance, NULL);

            SetWindowText(hWndEdit, "*Sorcerer*");
    }
      return 0L;
    case WM_COMMAND:
{
  switch (wParam)
  {
    case ButtonID1:
       SendMessage(hWnd,WM_CLOSE,0,0);
      return 0L;

    case ButtonID2:
       MessageBox(hWnd, "KeyGenerator for cyTOm!c`s CrackMe #1\nMade by: *Sorcerer*", "About", MB_OK);
      return 0L;
  }
  switch (LOWORD (wParam))
  {
    case EditID1:
    {

      char finalserial[255];
      int serial = 1;
      char *Buffer = new char[255];

      GetDlgItemText(hWnd, EditID1, Buffer, 255);

      int Size = lstrlen(Buffer);

      if (Size > 0)
                {

      for (int i = 0; i < Size; i++)
             {

      serial = serial * Buffer[i];

             }
      serial = serial & 0x0FFFFFFF;

      wsprintf(finalserial,"%lu", serial);

      SetDlgItemText(hWnd, EditID2, finalserial);
                }
      else
      SetDlgItemText(hWnd, EditID2, "Enter at least one char");

    }
  }
}
      return 0L;
    case WM_CLOSE:
      DestroyWindow(hWnd); // perform wm_destroy
      return 0L;
    case WM_DESTROY:
      PostQuitMessage( 0 );
      return 0L;
  }
  return DefWindowProc (hWnd, message, wParam, lParam) ;
}
/*==============================================================================

       WinMain

==============================================================================*/
int WINAPI WinMain( HINSTANCE hInstance,     // handle to current instance
                    HINSTANCE hPrevInstance, // handle to previous instance
                    LPSTR lpCmdLine,         // pointer to command line
                    int nCmdShow  )          // show state of window
{
  MSG      msg ;
  WNDCLASS wndclass ;
  // set up window
  wndclass.style         = CS_HREDRAW | CS_VREDRAW ;
  wndclass.lpfnWndProc   = WndProc ;
  wndclass.cbClsExtra    = 0 ;
  wndclass.cbWndExtra    = 0 ;
  wndclass.hInstance     = hInstance ;
  wndclass.hIcon         = NULL;
  wndclass.hIcon         = LoadIcon (hInstance,TEXT("PROGRAM_ICON"));
  wndclass.hCursor       = LoadCursor (NULL, IDC_ARROW);
  wndclass.hbrBackground = (HBRUSH) COLOR_WINDOW;
  wndclass.lpszMenuName  = NULL ;
  wndclass.lpszClassName = WINDOW_NAME; // window name
  RegisterClass (&wndclass) ;
  // now create main window

  HWND hWnd = CreateWindowEx(NULL,
         WINDOW_NAME, WINDOW_CAPTION,
         WS_BORDER | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
         200,
         200,
         290,
         130,
         NULL,
         NULL,
         hInstance,
         NULL);

  // display window and process messages
  ShowWindow( hWnd, SW_SHOW ) ;
  while (GetMessage(&msg,NULL,0,0))
  {
    TranslateMessage(&msg) ;
    DispatchMessage(&msg) ;
  }
  return msg.wParam;
}
//------------------------------------------------------------------------

