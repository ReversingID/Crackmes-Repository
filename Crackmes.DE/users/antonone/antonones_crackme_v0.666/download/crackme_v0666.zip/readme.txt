Crackme v0.666 by antonone_
Big thanks and greets goes to chendler/uCF :)

Hi :]. This is my second crackme I decided 
to release. It's free of cryptographic stuff
of any kind, just a few math tricks that
everybody should handle ;). Everything can
be reversed (i made a working keygen myself).

The goal is to make a working keygen.

There's no anti-disasm nor anti-debug stuff,
so patching won't be necessary.

Greets:
chendler, DarkL0rd, Liquid, pReJkEr, haxmen

-- 
antonone_
antonone@gmail.com
