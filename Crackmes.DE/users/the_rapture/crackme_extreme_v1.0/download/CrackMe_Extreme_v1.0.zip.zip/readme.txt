CRACKME EXTREME V1.0 WAS DESIGNED BY RAPTURE,

RULES ARE IN THE EXE CONTACT ME AT rapture@easypeasy.com IF YOU HAVE ANY                                  CONCERNS.

BY A CRACKER FOR CRACKERS.  I HOPE YOU LEARNT SOMETHING FROM THIS CRACKME.
THIS CRACKME IS THE FIRST OF A POSSIBLE CRACKME EXTREME SERIES.  AS I LEARN NEW PROTECTION METHODS I WILL EMPLOY THEM IN FUTURE VERSIONS OF CRACKME EXTREME.  ANYONE WISHING TO CONTRIBUTE TO THIS ONGOING PROJECT E-MAIL ME AT: rapture@easypeasy.com
                         __                          
_______ _____   ______ _/  |_  __ __ _______   ____  
\_  __ \\__  \  \____ \\   __\|  |  \\_  __ \_/ __ \ 
 |  | \/ / __ \_|  |_> >|  |  |  |  / |  | \/\  ___/ 
 |__|   (____  /|   __/ |__|  |____/  |__|    \___  >
             \/ |__|                              \/ 
"By A Cracker, For Crackers"