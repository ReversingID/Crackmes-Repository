Name:						qfqe's crackme 0x01
Author:						qfqe
Date:						2008-12-14
Type:						crackme
Programming Language:		Python
Comment:
It compiled with py2exe.

enjoy :-P