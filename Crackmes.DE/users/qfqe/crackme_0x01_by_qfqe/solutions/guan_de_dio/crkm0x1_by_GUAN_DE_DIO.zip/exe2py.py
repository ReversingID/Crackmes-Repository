import dis, imp, struct, os, sys
import marshal
import win32api

def exe2py(ifi):
# py2exe stores the main script (among other things) as resource
# in the image. This script prints some information, and extracts
# the code objects into the current directory."""

    handle = win32api.LoadLibrary(ifi)
    data = win32api.LoadResource(handle, "PYTHONSCRIPT", 1, 0)

    # The resource data has 3 parts:
    # 1. header: magic number (0x78563412), optimize flag, unbuffered flag,
    # script length in bytes
    magic, optimize, unbuffered, script_len = struct.unpack("iiii", data[:4*4])
    print "HEADER:", hex(magic), optimize, unbuffered, script_len
    if magic != 0x78563412:
        print "Warning: magic number incompatible"

    data = data[4*4:]
    # 2. name of the zip-archive (relative path, NUL terminated)
    zipname, data = data.split("\0", 1)
    print "ZipArchive:", zipname

    # 3. a sequence of marshaled code objects. Typically, the boot
    # script plus the main script; but there may be more.
    code_objects = marshal.loads(data + "foo bar spam")
    for co in code_objects:
        print "Found code object:", co.co_filename
        fname = os.path.basename(co.co_filename)
        if os.path.splitext(fname)[1]:
            if optimize:
                fname = fname + 'o'
            else:
                fname = fname + 'c'
            print "\tExtracting to:", fname
            # a .pyc or .pyo file is a magic number, a timestamp, plus the
            # marshaled code object
            open(fname, "wb").write(imp.get_magic() + "\0\0\0\0" + marshal.dumps(co))
        else:
            print "\tDisassembly:"
            dis.dis(co)
            continue

if __name__ == "__main__":
    exe2py(sys.argv[1])