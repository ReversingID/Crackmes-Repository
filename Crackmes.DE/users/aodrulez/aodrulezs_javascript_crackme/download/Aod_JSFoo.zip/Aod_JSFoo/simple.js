/* 
	+---------------------------+
	| Custom Javascript Crackme |
	+---------------------------+

[+] Tested on : Safari, Google-Chrome, Opera, Firefox. (IE ?? O..puhleez!)
[+] No obfuscation, nothing. Just plain code for you convenience :) 
[?] Should be an easy one, eh? ;) 
[+] Only a valid key should give an output that makes some sense ;)
[+] Best of luck!
(c) Aodrulez

Twitter : @Aodrulez

*/

var key=[];
var code=[901,340,505,140,305,461,901,722,340,539,723,241,339,540,238,142,342,901,722,901,722,606,000,542,243,243,244,340,830,653,553,140,145,353,546,140,653,000,17,10,000,001,000,400,60,459,41,22,76,76,75,75,37,417,560,140,145,360,547,140,417,567,140,145,367,548,140,417,574,140,145,374,549,140,417,581,140,145,381,550,140,417,588,140,145,388,551,140,417,595,140,145,395,552,140,417,423];
var output=[];

function msg()
{
var message=output.toString().replace(/\,/gi,"");;
document.getElementById("key").value=message;
}

function LMC()
{
	var accumulator=0;
	var inp_counter=0;	
	var code_counter=0;
	var pc=code[code_counter];
	while(code[code_counter]>0)
	{
		pc=code[code_counter];
		var mailbox=parseInt(pc%100);
		var opcode=parseInt(pc/100);
		switch(opcode)
		{
			case 1:
  						accumulator=accumulator+code[mailbox];
  						code_counter++;
  						break;
			case 2:
  						accumulator=accumulator-code[mailbox];
  						code_counter++;
  						break;
			case 3:
  						code[mailbox]=accumulator;
  						code_counter++;
  						break;
			case 5:
  						accumulator=code[mailbox];
  						code_counter++;
  						break;
			case 6:
  						code_counter=mailbox;
  						break;
			case 7:
  						if(accumulator==0)
  							{code_counter=mailbox;}
  						else{code_counter++;}
  						break;
			case 8:
  						if(accumulator>=0)
  							{code_counter=mailbox;}
  						else{code_counter++;}
  						break;
			case 9:
  						if(pc==901)
  						{
  							if(inp_counter<key.length)
  							{
  								accumulator=key[inp_counter];
  							 	inp_counter++;
  							 }
  							 else
  							 {
  							 	accumulator=0;
  							 }
  						}
  						else if(pc== 902)
  						{
  							output.push(String.fromCharCode(accumulator));
   						}
  						code_counter++;
  						break;
  		case 0:
  						code[0]=0;
  						code_counter=0;
  						break;
    	default:
  						code[0]=0;
              code_counter=0;
              break;
		}
	}
}

function setup()
{
	 var temp=document.getElementById("key").value;
	 for(var i=0; i<temp.length; ++i)
	 {
	 	key.push(temp.charCodeAt(i));
	 }
	 LMC();
	 msg();
}
