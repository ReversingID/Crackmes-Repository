#include <stdio.h>
#include <string.h>

int main( int argc, char* argv[] )
{	
	printf( "SacredLamat's SacredCrackme 5.0 Key Generator\nAuthor: Cthulhu\n\n" );

	printf( "UserName: " );
	char UserName[100] = "";
	scanf( "%s", &UserName );

	int NameLen = strlen( UserName );

	if ( NameLen > 1 )
	{
		strncat( UserName, "Sorry, wrong!", sizeof( UserName ) );		
		strupr( UserName );		
		int Serial = 0x15D;
		int i = 0;

		while ( UserName[i] != '\0' )
		{
			int x = UserName[i];
			x += Serial;
			x += 0x381;
			Serial = x;
			i++;
		}		

		printf( "Serial  : %i\n", Serial );
	}
	else
	{
		printf( "UserName must have more than 1 character\n" );
	}

	return 0;
}