/* 	keygen for [Xorolc]'s crackme #3 aka Terra
 *	coded by ZaiRoN
 ************************************************/

#include <windows.h>
#include <stdio.h>
#include <conio.h>

void main()
{
 	char 		*name = "";
	unsigned long	serial;
	unsigned long 	a;
	int		i;

	printf("keygen for [Xorolc]'s crackme #3 aka Terra\ncoded by ZaiRoN\n\n");

	printf("name (atleast 4 chars): ");
	scanf("%s", name);

	serial = 0;
	for(i = 0; i<strlen(name); i++)
	{
		a = name[i] * name[strlen(name)-i-1] * 0xFF;
		serial += a;
		serial += (a * 0x100) ^ (a * 0x10);
	}

	printf("\nthe serial is: %u",serial);
	printf("\n\n\nhit a key...");
	getch();
}
