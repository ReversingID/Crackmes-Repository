/* 
   Keygen for Xorolc's 'Jelly'
   Copycross (x) 2001 by zyn\ker
*/

#include <stdio.h>
#include <string.h>

#define DWORD long int

DWORD CalcCsum1(char *serial);
DWORD CalcCsum2(char *name);
int FinalCheck();
void CryptName(char *name);
void FinalHard();

char key[] = "8D2A6W0P9G7$1N3@";

DWORD csum1, csum2, check, tmpcsum, mustBe4;
char name[255];
char serial[255];
char cryptedName[255];

int main() {
  int i;

  printf("Keygen for Xorolc's 'Jelly'\nCopycross (x) 2001 by zyn\\ker\n\n");

  printf("Please enter name: ");
  scanf("%s", name);

  printf("Please enter serial: ");
  scanf("%s", serial);

  printf("\n\nEasy mode:\n");
  csum1 = CalcCsum1(serial);
  printf("CheckSum1: %x (%u)\n", csum1, csum1);

  csum2 = CalcCsum2(name);
  printf("CheckSum2: %x (%u)\n", csum2, csum2);

  check = FinalCheck();
  printf("Check: %x (%u)\n", check, check);
  printf("Correct CheckSum1: %x (%u)\n", tmpcsum, tmpcsum);
  printf("\nThat means the correct serial is:\n%u\n", tmpcsum);

  printf("\n\n\nHard mode:\n");
  tolower(name);

  CryptName(name);
  printf("Crypted name: %s\n", cryptedName);

  FinalHard();
  printf("MustBe4: %x (%u)\n", mustBe4, mustBe4);

  printf("\nThe correct serial is:\n");
  for(i = 0x0f; i != 0; i--)
    if ((cryptedName[i] & 4) == 0) {
      cryptedName[i] += 4;
      break;
    }
  for(i = 0x0f; i >= 0; i--) printf("%c", cryptedName[i]);
  printf("\n");

  getch();

  return 0;
}

DWORD CalcCsum1(char *serial) {
  DWORD csum = 0;
  int i;
  DWORD eax = 0;
  DWORD ecx;
  DWORD edx;
  
  for(i = 0; i != strlen(serial); i++) {
    __asm__ __volatile__ ("movl %1, %2\n\t"
			  "xor %3, %3\n\t"
			  "movb (%4,%2), %3\n\t"
			  "movl %0, %5\n\t"
			  "addl %5, %0\n\t"
			  "movl %0, %2\n\t"
			  "shl $2, %2\n\t"
			  "addl %2, %0\n\t"
			  "addl %3, %0\n\t"
			  "subl $0x30, %0\n\t"
			  : "=m" (csum)
			  : "r" (i), "r" (ecx), "r" (eax),
			  "r" (serial), "r" (edx)
			  );
  }

  return csum;
}

DWORD CalcCsum2(char *name) {
  __asm__ ("push %esi\n\t"
	   "push %edi\n\t"
	   "movl $_name, %eax\n\t"
	   "xor %edi, %edi\n\t"
	   "0:\n\t"
	   "xor %ecx, %ecx\n\t"
	   "1:\n\t"
	   "movzx (%eax,%ecx), %edx\n\t"
	   "mov %edx, %esi\n\t"
	   "inc %ecx\n\t"
	   "movzx (%eax,%ecx), %edx\n\t"
	   "xor %edx, %esi\n\t"
	   "add %esi, %edi\n\t"
	   "imul $2, %edi\n\t"
	   "rol %cl, %edi\n\t"
	   "adc %esi, %edi\n\t"
	   "test %edx, %edx\n\t"
	   "jnz 1b\n\t"
	   "cmp $0x3B9ACA00, %edi\n\t"
	   "jb 0b\n\t"
	   "mov %edi, %eax\n\t"
	   "pop %edi\n\t"
	   "pop %esi\n\t"
	   );
}

int FinalCheck() {
  __asm__ ("push %esi\n\t"
	   "push %edi\n\t"
	   "push %ebx\n\t"
	   "mov (_csum2), %edi\n\t"
	   "xor %eax, %eax\n\t"
	   "xor %esi, %esi\n\t"
	   "shr $0x10, %edi\n\t"
	   "mov %edi, %eax\n\t"
	   "xor %al, %ah\n\t"
	   "xchg %al, %ah\n\t"
	   "mov (_csum2), %edx\n\t"
	   "xchg %dl, %dh\n\t"
	   "shl $0x10, %edx\n\t"
	   "xor %edx, %eax\n\t"
	   "add %eax, %eax\n\t"
	   "mov %eax, (_tmpcsum)\n\t"
	   "mov (_csum1), %ebx\n\t"
	   "xor %ebx, %eax\n\t"
	   "pop %ebx\n\t"
	   "pop %edi\n\t"
	   "pop %esi\n\t"
	   );
}

DWORD safety;
DWORD tmp;

void CryptName(char *name) {
  int dummy;
  int i;
  int length = strlen(name);

  for(i = 0; i < 0x10; i++) {
    __asm__ __volatile__ ("mov %1, %%ecx\n\t"
			  "xor %%edx, %%edx\n\t"
			  "mov %%ecx, %%eax\n\t"
			  "divl %2\n\t"
			  "mov $_name, %%ecx\n\t"
			  "mov (%%ecx,%%edx), %%cl\n\t"
			  "mov %1, %%eax\n\t"
			  "mov $_key, %%edx\n\t"
			  "xor (%%edx, %%eax), %%cl\n\t"
			  "mov %1, %%edx\n\t"
			  "mov $_cryptedName, %%eax\n\t"
			  "mov %%cl, (%%eax,%%edx)\n\t"
			  : "=r" (dummy)
			  : "m" (i), "m" (length)
			  );
  }
  cryptedName[0x10] = 0;

  __asm__ ("push %ebx\n\t"
	   "push %esi\n\t"
	   "push %edi\n\t"
	   "mov $_tmp, %esi\n\t"
	   "mov $_cryptedName, %edi\n\t"
	   "xor %ebx, %ebx\n\t"
	   "0:\n\t"
	   "cmp $0x10, %ebx\n\t"
	   "jnb 1f\n\t"
	   "mov %ebx, %edx\n\t"
	   "xor %ecx, %ecx\n\t"
	   "mov (%edi,%edx), %cl\n\t"
	   "and $0x0f, %ecx\n\t"
	   "add $0x30, %ecx\n\t"
	   "mov %ecx, (%esi)\n\t"
	   "mov %ebx, %eax\n\t"
	   "mov (%esi), %dl\n\t"
	   "mov %dl, (%edi,%eax)\n\t"
	   "inc %ebx\n\t"
	   "mov %ebx, %ecx\n\t"
	   "xor %eax, %eax\n\t"
	   "mov (%edi,%ecx), %al\n\t"
	   "and $0x0f, %eax\n\t"
	   "add $0x41, %eax\n\t"
	   "mov %eax, (%esi)\n\t"
	   "mov %ebx, %edx\n\t"
	   "mov (%esi), %cl\n\t"
	   "mov %cl, (%edi,%edx)\n\t"
	   "inc %ebx\n\t"
	   "jmp 0b\n\t"
	   "1:\n\t"
	   "pop %edi\n\t"
	   "pop %edi\n\t"
	   "pop %ebx\n\t"
	   );
}

void FinalHard() {
  tmp = strlen(serial);

  __asm__ ("push %ebx\n\t"
	   "push %edi\n\t"
	   "push %esi\n\t"
	   "mov $_serial, %edi\n\t"
	   "dec %edi\n\t"
	   "mov $_cryptedName, %esi\n\t"
	   "xor %eax, %eax\n\t"
	   "xor %ebx, %ebx\n\t"
	   "0:\n\t"
	   "mov %ebx, %eax\n\t"
	   "cmp $0x10, %ebx\n\t"
	   "jnb 1f\n\t"
	   "mov %ebx, %edx\n\t"
	   "mov (%esi,%edx), %cl\n\t"
	   "mov (_tmp), %edx\n\t"
	   "sub %eax, %edx\n\t"
	   "xor (%edi,%edx), %cl\n\t"
	   "xor %eax, %eax\n\t"
	   "mov %cl, %al\n\t"
	   "add %eax, (_mustBe4)\n\t"
	   "inc %ebx\n\t"
	   "jmp 0b\n\t"
	   "1:\n\t"
	   "pop %esi\n\t"
	   "pop %edi\n\t"
	   "pop %ebx\n\t"
	   );
}
