Sunshine's Crackme #1:
----------------------

Level	: 	1
OS	: 	Windows XP
Goal	: 	Register the crackme. Write a keygen and a solution.
Rules	:	No patching allowed - that would be far too easy...
		YOu have to find a valid key for your name.

Hope some beginner will like it ;-)