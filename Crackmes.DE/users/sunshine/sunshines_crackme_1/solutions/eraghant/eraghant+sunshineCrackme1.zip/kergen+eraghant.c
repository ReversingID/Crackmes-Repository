#include <stdio.h>
main() {

    char username[20];
    int i;
    int total=0;
    int serial;
    char serialHex[8];
    FILE * keyFile;

    keyFile=fopen("data.key", "w");

    fputs ("11111111111",keyFile);

    printf("Coded by eraghant\n");
    printf("eraghant@gmail.com\n");
    printf("What's your username?\n");
    scanf("%s", username);

    for(i=0; i<strlen(username); i++) {
        total+=(int)username[i];

    }
    total +=44;
    serial = 4198576- total;
    sprintf(serialHex,"%X", serial);
    printf("%s\n", serialHex);
    fclose(keyFile);
}
