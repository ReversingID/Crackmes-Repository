	
				Crackme1 By Unicorn

	Hi all,
		This is my first crackme.
		It just need one serial number as input.
		Its very easy. It is only for newbies.



		Best Regards

			Unicorn