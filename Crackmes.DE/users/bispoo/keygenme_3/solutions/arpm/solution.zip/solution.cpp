#include <stdio.h>
#include <string>

#define MAX_STRING_LENTH (200)

int main()
{
	char encodeStr[] = "KYPZAXSFCSNGRQTNWD8592VQWRKH";
	int encodeStrLength = strlen(encodeStr);
	int encodeStrIndex;
	char name[MAX_STRING_LENTH];
	int nameLength;
	int nameIndex;
	char buf[MAX_STRING_LENTH];
	char serial[MAX_STRING_LENTH];
	int serialIndex;
	int temp;

	printf("Name: ");
	gets_s(name, MAX_STRING_LENTH);

	// 1, 2
	nameLength = strlen(name);
	nameIndex = 0;
	for (int i = 0; i < nameLength; ++ i)
	{
		name[i] = toupper(name[i]);
		if (strchr(encodeStr, name[i]) != NULL)
		{
			buf[nameIndex ++] = name[i];
		}
	}
	buf[nameIndex] = '\0';
	strcpy_s(name, MAX_STRING_LENTH, buf);
	nameLength = strlen(name);

	// 3
	if (nameLength < 24)
	{
		for (encodeStrIndex = 0; encodeStrIndex < 4 * ((24 - nameLength) >> 2); ++ encodeStrIndex)
		{
			name[nameLength + encodeStrIndex] = encodeStr[encodeStrIndex];
		}
		temp = ((24 - nameLength) & 3) + encodeStrIndex;
		for (; encodeStrIndex < temp; ++ encodeStrIndex)
		{
			name[nameLength + encodeStrIndex] = encodeStr[encodeStrIndex];
		}
		name[nameLength + encodeStrIndex] = '\0';
	}

	// 4
	nameIndex = 0;
	serialIndex = 0;
	temp = 0;
	while (nameIndex < 24)
	{
		encodeStrIndex = strchr(encodeStr, name[nameIndex]) - encodeStr + 1;
		encodeStrIndex *= (encodeStrIndex - 1);
		encodeStrIndex += temp;
		encodeStrIndex %= encodeStrLength;
		temp = encodeStrIndex + 1;
		
		serial[serialIndex] = encodeStr[encodeStrIndex];
		if (0 == ((nameIndex + 1) % 6))
		{
			serial[++ serialIndex] = '-';
		}

		++ nameIndex;
		++ serialIndex;
	}
	serial[serialIndex - 1] = '\0';

	printf("Serial: %s\n", serial);

	return 0;
}
