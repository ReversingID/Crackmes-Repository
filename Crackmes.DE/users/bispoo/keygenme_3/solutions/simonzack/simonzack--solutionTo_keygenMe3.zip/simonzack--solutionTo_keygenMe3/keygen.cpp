#include <stdio.h>
#include <fstream>
#include <string.h>

int main(){
    char *constStr;
    constStr="KYPZAXSFCSNGRQTNWD8592VQWRKH";
    char *name;
    name=(char*)malloc(30);
    char *nameStr;
    nameStr=(char*)malloc(30);
    char *pass;
    pass=(char*)malloc(30);
    scanf("%s",name);
    
    int i,j;
    int count=0;
    for(i=0;i<strlen(name);i++){
        if(name[i]>0x60) name[i]-=0x20;
    }
    for(i=0;i<strlen(name);i++){
        for(j=0;j<strlen(constStr);j++){
            if(name[i]==constStr[j]){
                nameStr[count]=constStr[j];
                count++;
                break;
            }
        }
    }
    int tmp=count;
    for(i=0;i<strlen(constStr)-tmp;i++){
        nameStr[count++]=constStr[i];
    }
    int pos;
    tmp=0;
    nameStr[count]=0;
    for(i=0;i<0x18;i++){
        for(j=0;j<0x18;j++){
            if(nameStr[i]==constStr[j]){
                break;
            }
        }
        pos=j;
        tmp=(pos*(pos+1)+tmp)%0x1c+1;
        pass[i]=constStr[tmp-1];
    }
    for(i=0;i<4;i++){
        for(j=0;j<6;j++){
            printf("%c",pass[i*6+j]);
        }
        if(i!=4) printf("-");
    }
    system("break");
    return 0;
}
            
        
                                
    

