#include <cstdlib>
#include <iostream>
#include <sstream>
#include <string>

using namespace std;

/**
 * An always re-evaluated string whose first 4 characters are used during the
 * creation of a serial. Its other parts are absolutely unimportant.
 */
const string SALT = "6789:;<=>?@ABCD";

/** Constant postfix appended to each serial. */
const string POSTFIX = "-LEET";

//------------------------------------------------------------------------------

/** Description. */
inline void hi(void)
{
	cout << "Keygen for Bispoo Crackme#2 by e1xis                " << endl;
	cout << "http://www.crackmes.de/users/bispoo/bispoo_crackme2/" << endl;
	cout << "Type in usernames, or ^C to exit.                   " << endl;
	cout << "----------------------------------------------------" << endl;
	cout << endl;
}

/**
 * Performs a little modification on the calculated serial depending on its
 * encrypted value.
 */
const string checkEncryptedValues(const int &key)
{
    stringstream ss;
    string ret;
    ss << key;
    ss >> ret;
    
    cout << "Calculated key: " << key << endl;
    cout << "Encryption:" << endl;
    for (unsigned int i=0; i<ret.length(); ++i)
    {
        // checking the encrypted value (see Function 2 in the solution)
        unsigned char actEnc = ret[i] ^ 0xBE;
        
        cout << "Base: " << ret[i] << '\t' << dec << (int) ret[i]
                << hex << '\t' << (int) ret[i] << '\t' 
             << "Encr: " << actEnc << '\t' << dec << (int) actEnc
                << hex << '\t' << (int) actEnc << endl;
        
        if ( ((unsigned char) 0x8F) >= actEnc  )
        {
             continue;
        }
        else if ( ((unsigned char) 0x93) == actEnc )
        {
             ret[i] = 0x8D ^ 0xBE; // The '-' char if the result is negative
        }
        else
        {
            ret[i] = ( actEnc - 1 ) ^ 0xBE; // Could it ever happen?
        }
    }
    
    return ret;
}// const string checkEncryptedValues(const &int)

/** Returns the generated password for the specified username. */
const string getSerial(const string &user)
{
    signed int key = 0;
    
    // i.e. constructing SALT ;-)
    for (unsigned int i=0; i<user.length(); ++i)
    {
        unsigned int act = (int) user[i];
        
        act *= i+1;
        act += i+1;
        act <<= 0xDE;
        act >>= 0xAD;
        act ^= i+1;
        act += 0x35;     // AL is SALT[i]
        
        key += act;
    }
    
    key *= 0x39383736;   // integer made from the first 4 characters of SALT
                         // "6789" (don't forget low-endian order)
    
    key = ~(key);

    return checkEncryptedValues(key) + POSTFIX ;
}// const string getSerial(const &string)

/** Just for debugging. */
void checkCodedPass(void)
{
    char pass[] = { 0x8D, 0x86, 0x88, 0x8B, 0x8C, 0x8E, 0x87, 0x88, 0x8A, 0x8D,
                    0x93, 0xF2, 0xFB, 0xFB, 0xEA };
    
    for (unsigned int i=0; i< sizeof(pass) / sizeof(char) ; ++i)
    {
        cout << (char) ( pass[i] ^ 0xBE );
    }
}

//------------------------------------------------------------------------------

/**
 * Notifies NASA about the giant hedgehogs living on the sunny side of the Moon.
 */
int main(void)
{
    hi();
    string user;
    
    while (cin >> user)
    {
          if ( user.length() < 4 || 15 < user.length() )
          {
               cout << "[Invalid username] A valid username contains 4 to 15 characters." << endl;
               continue;
          }
          
          cout << "Serial: " << getSerial(user) << endl;
    }
    
    cout << endl;
    cout << "kthxbai!" << endl;
    return 0;
}
