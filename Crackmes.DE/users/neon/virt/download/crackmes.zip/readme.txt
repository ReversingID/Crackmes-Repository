Crackme's by NeoN
Written specially for $CC07, but now it's over and you can try it by yourself :)

Based on Virtual Machine, you will need trace it in simple case, or fully disassamble it.

Contact me at icq: 7773993 or mail: lq.neon@gmail.com
