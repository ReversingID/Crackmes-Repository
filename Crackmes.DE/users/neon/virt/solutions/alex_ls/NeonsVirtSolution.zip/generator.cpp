//----------------------------------------------
// Crt2Base - extract text from Dino2's hlam!!!
//----------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

//----------------------
//Name: Main()
//----------------------
int main(int argc,char *argv[])
{
	char p_name[0xC];
	
	DWORD word1,word2,word3;
	
	word1=0xb75ede4e-0x23432342-0x98304283-0x82740921;
	word2=0x46bb1982-0x34283203-0xa92e7210;
	word3=0x453ab788-0xd3a329e2-0x32232442;

	strncpy(p_name+0,(char*)&word1,4);
	strncpy(p_name+4,(char*)&word2,4);
	strncpy(p_name+8,(char*)&word3,4);
	
	p_name[0xc]=0;
	printf("Serial Key is:   %s\n", p_name);
	
	word1+=0xc0fbf1e8;
	word2+=0x0904e0b1;
	word3+=0x2ced0c10;
	
	strncpy(p_name+0,(char*)&word1,4);
	strncpy(p_name+4,(char*)&word2,4);
	strncpy(p_name+8,(char*)&word3,4);
	
	p_name[0xc]=0;
	printf("Final String is: %s\n",p_name);
	
	printf("\npress any key for exit!\n");
	getchar();

	return 0;
}


