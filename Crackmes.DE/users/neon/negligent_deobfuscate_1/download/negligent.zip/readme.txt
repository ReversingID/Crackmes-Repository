  Negligent deobfuscate #1

  Hello everybody!

  I'm writing some kind of exe obfuscator, and this exe is output result of obfuscating by
my program. It contains some trash instructions (very few) and code is "breaked" on small
parts, putted in random parts of exe and connected with jumps :)

  Tasks:

  - for newbies:
     just remove trash and stuff and get source code for this exe
  - for pro's:
     write a programm for automated deobfuscation of this exe

  With regards, NeoN.
  icq: 7773993
