  192 bits | Crackme by NeoN

  In this crack me need find a valid pair - name and serial. Accepted only pair or
keygen. No patching allowed.

Contact me at icq: 7773993 or email: lq.neon@gmail.com