
#undef UNICODE
#undef _UNICODE
#include <windows.h>

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	char szName[20] = "REcodeD";
	int i, j, intFirstPart, intSecondPart, intBuf;
	DWORD dwSerial[4];

	intSecondPart = 0x401284;	// init value

	for (i=3; i>=0; i--)
	{
		intFirstPart = 0;
		for (j=0; j<strlen(szName); j++)
		{
			if (szName[j] == ' ') continue;	// ignore spaces
			intBuf = szName[j] * intSecondPart;
			__asm {ror dword ptr [intBuf], 0x13}	//ROR intBuf, 0x13;
			intFirstPart += intBuf;
		}
		dwSerial[i] = intSecondPart = intFirstPart;
	}

	char szSerial[36] = {0};
	wsprintf (szSerial, "%08X-%08X-%08X-%08X", dwSerial[0],dwSerial[1],dwSerial[2],dwSerial[3]);

	return (0);
}
