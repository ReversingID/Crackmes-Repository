#define _CRT_SECURE_NO_DEPRECATE 1

#include <stdio.h>
#include <string.h>
#include <windows.h>
#include <stdlib.h>
#include "resource.h"

#define MAX_NAME 0x20
#define OK_EXCL	 MB_OK | MB_ICONEXCLAMATION

void Asciify(void* data, unsigned int length, unsigned char* buf);
void Transform(DWORD data, void* buf);
void Base64(void* data, unsigned int length, unsigned char* buf);
void MD5(unsigned char* name, unsigned int length, void* buf); 

BOOL CALLBACK keygenProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam);

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	DialogBox(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_DLG1), NULL, keygenProc);
	return 0;
}

BOOL CALLBACK keygenProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam)
{
	LPSTR name, name2, serial, B64Result, B64Cat;	
	UINT bytesRead, B64CatSiz;
	unsigned char *MD5Buf, *AscMD5Result;

	name = GlobalAlloc(GPTR, MAX_NAME);
	name2 = GlobalAlloc(GPTR, 6);
	B64Result = GlobalAlloc(GPTR, MAX_NAME*2);
	MD5Buf = GlobalAlloc(GPTR, 16);
	AscMD5Result = GlobalAlloc(GPTR, 32);
	serial = GlobalAlloc(GPTR, 36);

	switch(Message)
	{
		case WM_INITDIALOG:
			return TRUE;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case IDC_BTN1:
					if ((bytesRead = GetDlgItemText(hwnd, IDC_EDT1, name, MAX_NAME)) == 0)
					{
						MessageBox(hwnd, "Enter a fucking name!", "Moron", OK_EXCL);
						return TRUE;
					}
					if (bytesRead < 4)
					{
						MessageBox(hwnd, "Name must be between 4 and 32 characters.", "Moron", OK_EXCL);
						return TRUE;
					}
					strncpy(name2, name, 6);
					name2[4] = 'i';
					name2[5] = '4';
					Base64(name2, 4, B64Result);
					B64CatSiz = strlen(name)+strlen(B64Result)+1;
					B64Cat = GlobalAlloc(GPTR, B64CatSiz+41);
					strncpy(B64Cat, B64Result, B64CatSiz);
					strncat(B64Cat, name, B64CatSiz);
					MD5(B64Cat, B64CatSiz-1, MD5Buf);

					Transform(*((DWORD*)MD5Buf), MD5Buf);
					Transform(*((DWORD*)MD5Buf+1), MD5Buf+4);
					Transform(*((DWORD*)MD5Buf+2), MD5Buf+8);
					Transform(*((DWORD*)MD5Buf+3), MD5Buf+12);

					Asciify(MD5Buf, 16, AscMD5Result);
					strncpy(serial, "D31-", 36);
					strncat(serial, AscMD5Result, 36);
					serial[13] = '-';
					serial[24] = '-';

					SetDlgItemText(hwnd, IDC_EDT2, serial);
					break;
				default:
					break;
			}
			break;

		case WM_CLOSE:
			EndDialog(hwnd, 0);
			return TRUE;

		default:
			return FALSE;
	}
	return TRUE;
}
