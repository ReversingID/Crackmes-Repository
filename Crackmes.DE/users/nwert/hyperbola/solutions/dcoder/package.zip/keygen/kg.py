import sys
from hashlib import sha1
from random import randint

p = 0xE9965E13A7066DA5
d = 0x5D6B2EA7DBEEC228

P = (0xB2BE68B04CF8E2BB, 0xA11D77944E4A2826)
Q = (0x35486D2A7D42D13E, 0x7E4D65153B319860)
n = 0x74CB2F09D38336D3
x = 4300377673800084310

def point_add(P, Q):
  x1, y1 = P
  x2, y2 = Q
  return ((x1*x2 + d*y1*y2)%p, (x1*y2 + x2*y1)%p)

def point_mul(P, e):
  R = (1, 0)
  m = 1 << 64
  while m != 0:
    R = point_add(R, R)
    if m & e != 0:
      R = point_add(R, P)
    m >>= 1
  return R

def verify(name, signature):
  h = int(sha1(name).hexdigest()[0:16], 16)
  c = int(signature[0:16], 16)
  d = int(signature[17:], 16)
  x, _ = point_add(point_mul(P, d), point_mul(Q, c))
  return h % n == (c - x) % n

def sign(name):
  h = int(sha1(name).hexdigest()[0:16], 16)
  while True:
    u = randint(1, n-1)
    c = (point_mul(P, u)[0] + h) % n
    d = (u - x*c)%n
    if point_mul(P, (d + x*c)%n)[0] < n: # work around bug
      break
  return "%016X-%016X" % (c, d)

if len(sys.argv) != 2:
  print "Usage: %s <name>" % sys.argv[0]
  sys.exit(1)

s = sign(sys.argv[1])
assert( verify(sys.argv[1], s) )
print s
