hyperbola (2014 by nwert)

This task is about (hopefully) interesting crypto/math and some reversing.
Don't let yourself fool by the size of the executable,
that's just because the runtime is statically compiled into it.
Valid solution is a working keygen only!

Some working serials:
asd 4311BB3FABC1F375-12E963D4E0F5E3AA
nwert 23D6A3DBDC8D82B9-006BE82477987D21
lulzboat 65453E28B461171D-3059BD500F6FDABA
