#include<stdio.h>
#include<string.h>
main()
{
	char name[0x21];
	char company[0x41];
	char cat[0x20+0x41];
	char serial[0x10];
	char c,c1,c2,c3;
	int len=0;
	unsigned char op=8,j=0,k=0x20,l=0x27;
	int cnt=0,st1=4,st2=2;
	printf("\t\t***KeyGen***\n\t\t   ------\n");
	printf("Target     : KeyGenMe_1 By Wizzardz \n");
	printf("Cracked By : Cyclops\n");

	printf("Mail       : cyclops1428@yahoo.com\n\n");
	printf("Enter ur name:");
	fgets(name,0x20,stdin);
	printf("Enter ur comapny name:");
	fgets(company,0x40,stdin);
	if(!strcmp(name,"\n")||!strcmp(company,"\n"))
	{
		printf("Please enter the info.!!!");
		return -1;
	}
	name[strlen(name)-1]=0x00;
	company[strlen(company)-1]=0x00;
	strcpy(cat,name);
	strcat(cat,company);
	len=strlen(cat);
	__asm
	{
		XOR EAX,EAX
		XOR EBX,EBX
		XOR ECX,ECX
		XOR EDX,EDX
	}
	while(cnt!=len)
	{
		if(st1<0)
			st1=len-1;
		if(st2>=len)
			st2=0;
		c=cat[cnt];
		c1=cat[st2];
		c2=cat[cnt+1];
		c3=cat[st1];
		__asm
		{
			MOV BL,op
			MOV DL,c
			MOV AL,j
			MOV CL,k
			ADD AL,DL
			MOV j,AL
			MOV AL,c1
			IMUL DL
			ADD CL,AL
			MOV AL,c2
			MOV k,CL
			MOV CL,c3
			IMUL CL
			SUB BL,AL
			MOV AL,c1
			OR CL,DL
			MOV DL,l
			AND CL,AL
			ADD DL,CL
			MOV l,DL
			MOV op,BL
		}
		st2++;
		st1--;
		cnt++;
	}
	sprintf(serial,"%3.3d-%3.3d-%3.3d-%3.3d",j,op,l,k);
	printf("Serial:%s\n",serial);
	getchar();
}