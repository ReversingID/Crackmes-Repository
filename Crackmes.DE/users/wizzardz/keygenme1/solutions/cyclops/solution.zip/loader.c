#include<stdio.h>
#include<windows.h>

main()
{
	int ok=0;
	char name[0x21];
	char company[0x41];
	char serial[0x21+0x41];
	char *n,*c,*s;
	HMODULE h;
	FARPROC f;
	h=LoadLibrary("keygenme_1.dll");
	f=GetProcAddress(h,"VerifyInfo");
	printf("\t\t***Loader***\n\t\t   ------\n");
	printf("Target   : KeyGenMe_1.dll (VerifyInfo())\n");
	printf("Coded By : Cyclops\n\n");
	printf("Enter the name:");
	fgets(name,0x20,stdin);
	printf("Enter the company name:");
	fgets(company,0x40,stdin);
	printf("Enter the serial no:");
	scanf("%s",serial);
	name[strlen(name)-1]=0x00;
	company[strlen(company)-1]=0x00;
	n=name;
	c=company;
	s=serial;
	__asm
	{
		push s
		push c
		push n
	}
	if(f())
		printf("Right serial!!!");
	else
		printf("Wrong serial!!!");
	getchar();
	
}

