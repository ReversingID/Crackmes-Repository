#include <stdio.h>
#include "md5.h"
#include "stdint.h"

#define ITERATION_LIMIT 50000

void PrintArray(uint8 * pArray, uint8 nNumBytes)
{
	uint8 i;
	
	for (i=0; i<nNumBytes; i++)
		printf("%02X",pArray[i]);
	
	printf("\n");
}

__forceinline void DoMD5(uint8 * pData, uint8 * pOutput)
{
	md5_state_t md5State;
	
	md5_init(&md5State);
	md5_append(&md5State,pData,16);
	md5_finish(&md5State,pOutput);
}

__forceinline uint32 CheckResult(uint32 * pData)
{
	if (pData[0] == 0x600EB38C && 
		pData[1] == 0x674EDD36 && 
		pData[2] == 0xA9B95BFF && 
		pData[3] == 0x1A9B743B)
		return 1;
	else
		return 0;
}
		
int main(void)
{
	uint8 aContext[16] = {0x0, 0xB6, 0x91, 0xC3, 0x49, 0xAD, 0x75, 0x39, 
		0x12, 0xBC, 0x9E, 0x1F, 0x9F, 0x15, 0x87, 0x0};
	uint8 aDigest[16];
	uint16 i=0;
	
	for (;;)
	{	
		int k;
		
		/* Setup context */
		aContext[0] = (uint8)(i & 0xFF);
		aContext[15] = (uint8)((i >> 8) & 0xFF);
		
		/* Load context into the digest */
		memcpy(aDigest,aContext,16);
		
		/* Do MD5 iterations */
		for (k=0; k<ITERATION_LIMIT; k++)
		{
			DoMD5(aDigest,aDigest);
			
			if (CheckResult((uint32 *)aDigest))
			{
				/* Output context */
				printf("(%d, %d) Valid input found after %d iterations! Input is: ",
					(i & 0xFF),(i >> 8), k+1);
				PrintArray(aContext,16);
				return 0;
			}
		}
		
		/* Iteration limit reached */
		printf("(%d,%d) Invalid pair ...\n",(i & 0xFF),(i >> 8));
		
		if (i < 0xFFFF)
			i++;
		else
			break;
	}
	
	printf("All (i,j) combinations tried for iteration limit of %d ...\n",ITERATION_LIMIT);
	
	return 0;
}
	
	