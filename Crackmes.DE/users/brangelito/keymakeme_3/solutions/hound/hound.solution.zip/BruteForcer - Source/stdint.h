#ifndef STDINT_H
#define STDINT_H

typedef unsigned char uint8;
typedef unsigned long uint32;
typedef unsigned short uint16;

#endif