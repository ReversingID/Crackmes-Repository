#include <stdio.h>
#include "md5.h"
#include "stdint.h"
#include <windows.h>

#define ITERATION_LIMIT 50000

void PrintArrayToBuffer(char * szBuffer, uint8 * pArray, uint8 nNumBytes)
{
	uint8 i;
	char szInt[16];
	
	/* Terminate buffer */
	szBuffer[0] = '\0';
	
	/* Add each array byte to the buffer */
	for (i=0; i<nNumBytes; i++)
	{
		sprintf(szInt,"%02X",pArray[i]);
		strcat(szBuffer,szInt);
	}
}

__forceinline void DoMD5(uint8 * pData, uint8 * pOutput)
{
	md5_state_t md5State;
	
	md5_init(&md5State);
	md5_append(&md5State,pData,16);
	md5_finish(&md5State,pOutput);
}

__forceinline uint32 CheckResult(uint32 * pData)
{
	if (pData[0] == 0x600EB38C && 
		pData[1] == 0x674EDD36 && 
		pData[2] == 0xA9B95BFF && 
		pData[3] == 0x1A9B743B)
		return 1;
	else
		return 0;
}
		
int main(void)
{
	/* Valid serial is 8AB691C349AD753912BC9E1F9F1587BA */
	uint8 aContext[16] = {0x8A, 0xB6, 0x91, 0xC3, 0x49, 0xAD, 0x75, 0x39, 
		0x12, 0xBC, 0x9E, 0x1F, 0x9F, 0x15, 0x87, 0xBA};
	uint8 aDigest[16];
	HANDLE hFile;
	DWORD dwBytesWritten;
	int k;
	
	/* Load context into the digest */
	memcpy(aDigest,aContext,16);
	
	/* Open output file */
	hFile = CreateFile("serials.txt",
		GENERIC_WRITE,
		0,
		NULL,
		CREATE_ALWAYS,
		FILE_ATTRIBUTE_NORMAL,
		NULL);
		
	
	/* Do MD5 iterations */
	for (k=0; k<ITERATION_LIMIT; k++)
	{
		char szOutputBuffer[128];
		char szSerialBuffer[64];
		
		/* Output the digest before each iteration */
		sprintf(szOutputBuffer,"[%d]: ", k+1); 
		PrintArrayToBuffer(szSerialBuffer,aDigest,16);
		strcat(szOutputBuffer,szSerialBuffer);
		strcat(szOutputBuffer,"\r\n");
		
		WriteFile(hFile, 
			szOutputBuffer, 
			strlen(szOutputBuffer),
			&dwBytesWritten,
			NULL);
			
		/* Do MD5 */
		DoMD5(aDigest,aDigest);
		
		/* Check result */
		if (CheckResult((uint32 *)aDigest))
		{	
			CloseHandle(hFile);
			return 0;
		}
		
		
	}
	
	CloseHandle(hFile);
	
	return 0;
}
	
	