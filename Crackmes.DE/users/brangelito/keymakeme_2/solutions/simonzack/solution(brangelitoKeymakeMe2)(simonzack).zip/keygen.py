
import random

def genKey(n):
	'''
	args:
		n: final sum
	'''
	while True:
		res_1=n>>8
		v13_1=random.randrange(0x200)
		v10_1=((res_1^v13_1^(v13_1>>1))-v13_1)&0xFF
		v10_0=v10_1
		res_0=n&0xFF
		v13_0=(res_0-v10_0)&0xFF
		v10=(v10_0<<11)|random.randrange(0x800)
		if v10&0x55555555==0:
			break
	v13=(v13_1<<9)|(random.randrange(2)<<8)|v13_0
	return str(v13)+':'+str(v10)
	

def main():
	print(genKey(0x1337))

if __name__=='__main__':
	main()
