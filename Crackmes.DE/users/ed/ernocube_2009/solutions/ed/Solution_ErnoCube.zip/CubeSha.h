#ifndef __CUBESHA_H__
#define __CUBESHA_H__

#include <windows.h>
#include <stdio.h>

typedef struct sha_256_s {
    unsigned long state[8], length, curlen;
    unsigned char buf[64];
} sha_256_t;

#define SHA_256_CH(x,y,z) ((x & y) ^ (~x & z))
#define SHA_256_MAJ(x,y,z) ((x & y) ^ (x & z) ^ (y & z))
#define SHA_256_S(x, n) (((x) >> ((n) & 31)) | \
                                  ((x) << (32 - ((n) & 31))))
#define SHA_256_R(x, n) ((x) >> (n))

#define Sigma0(x) (SHA_256_S(x, 2) ^ \
                   SHA_256_S(x, 13) ^ \
                   SHA_256_S(x, 22))

#define Sigma1(x) (SHA_256_S(x, 6) ^ \
                   SHA_256_S(x, 11) ^ \
                   SHA_256_S(x, 25))

#define Gamma0(x) (SHA_256_S(x, 7) ^ \
                   SHA_256_S(x, 18) ^ \
                   SHA_256_R(x, 3))

#define Gamma1(x) (SHA_256_S(x, 17) ^ \
                   SHA_256_S(x, 19) ^ \
                   SHA_256_R(x, 10))

void sha_256_compress(sha_256_t * md);
void sha_256_init(sha_256_t * md);
void sha_256_process(sha_256_t * md, unsigned char *buf, int len);
void sha_256_done(sha_256_t * md, unsigned char *hash);
unsigned char * sha_256_string(unsigned char * datas, unsigned int len);

#endif /* __CUBESHA_H__ */
