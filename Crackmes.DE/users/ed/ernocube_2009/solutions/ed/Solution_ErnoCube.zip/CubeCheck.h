#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>

/**

          [X][X][X]
          [X][X][X]
          [X][X][X]
[X][X][X] [X][X][X] [X][X][X] [X][X][X]
[X][X][X] [X][X][X] [X][X][X] [X][X][X]
[X][X][X] [X][X][X] [X][X][X] [X][X][X]
          [X][X][X]
          [X][X][X]
          [X][X][X]
3*3*3:
each face looks like this:
[1][2][3][4][5][6][7][8][9]

[1][2][3]
[4][5][6]
[7][8][9]

and after a simple rotate:
[7][4][1][8][5][2][9][6][3]

[7][4][1]
[8][5][2]
[9][6][3]

[0][0] -> [0][2]
[0][1] -> [1][2]
[0][2] -> [2][2]

[1][0] -> [0][1]
[1][1] -> [1][1]
[1][2] -> [2][1]

[2][0] -> [0][0]
[2][1] -> [1][0]
[2][2] -> [2][0]

5*5*5:
each face looks like this:
[ 1][ 2][ 3][ 4][ 5][ 6][ 7][ 8][ 9][10][11][12][13][14][15][16][17][18][19][20][21][22][23][24][25]

[ 1][ 2][ 3][ 4][ 5]
[ 6][ 7][ 8][ 9][10]
[11][12][13][14][15]
[16][17][18][19][20]
[21][22][23][24][25]

and after a simple rotate:
[21][16][11][ 6][ 1][22][17][12][ 7][ 2][23][18][13][ 8][ 3][24][19][14][ 9][ 4][25][20][15][10][ 5]

[21][16][11][ 6][ 1]
[22][17][12][ 7][ 2]
[23][18][13][ 8][ 3]
[24][19][14][ 9][ 4]
[25][20][15][10][ 5]

[0][0] -> [0][4]
[0][1] -> [1][4]
[0][2] -> [2][4]
[0][3] -> [3][4]
[0][4] -> [4][4]

[1][0] -> [0][3]
[1][1] -> [1][3]
[1][2] -> [2][3]
[1][3] -> [3][3]
[1][4] -> [4][3]

[2][0] -> [0][2]
[2][1] -> [1][2]
[2][2] -> [2][2]
[2][3] -> [3][2]
[2][4] -> [4][2]

[3][0] -> [0][1]
[3][1] -> [1][1]
[3][2] -> [2][1]
[3][3] -> [3][1]
[3][4] -> [4][1]

[4][0] -> [0][0]
[4][1] -> [1][0]
[4][2] -> [2][0]
[4][3] -> [3][0]
[4][4] -> [4][0]

-> [x][y] -> [y][(size-1)-x]

*/

/*
// DEBUG STUFF
void FillZeroCube(Cube * c)
{
    int i, j, k, mult;

    for(i=0, mult=(c->Size * c->Size), k=0; i<c->Size; i++)
    {
        for(j=0; j<c->Size; j++, k++)
        {
            c->Blue   [i][j] = 0;
            c->Red    [i][j] = 0;
            c->Yellow [i][j] = 0;
            c->Orange [i][j] = 0;
            c->White  [i][j] = 0;
            c->Green  [i][j] = 0;
        }
    }

    return;
}*/

/*void FillCube(Cube * c)
{
    int i, j, k, mult;

    for(i=0, mult=(c->Size * c->Size), k=0; i<c->Size; i++)
    {
        for(j=0; j<c->Size; j++, k++)
        {
            c->Blue   [i][j] = k + mult * 0;
            c->Red    [i][j] = k + mult * 1;
            c->Yellow [i][j] = k + mult * 2;
            c->Orange [i][j] = k + mult * 3;
            c->White  [i][j] = k + mult * 4;
            c->Green  [i][j] = k + mult * 5;
        }
    }

    return;
}

void PrintCubeChar(Cube * c)
{
    int i, j, k;

    for(i=0; i<c->Size; i++)
    {
        for(k=0; k<c->Size; k++) printf("   ");
        for(j=0; j<c->Size; j++)
        {
            printf("[%c]", c->Blue[i][j]);
        }

        printf("\n");
    }

    for(i=0; i<c->Size; i++)
    {
        for(j=0; j<c->Size; j++)
        {
            printf("[%c]", c->Red[i][j]);
        }
        for(j=0; j<c->Size; j++)
        {
            printf("[%c]", c->Yellow[i][j]);
        }
        for(j=0; j<c->Size; j++)
        {
            printf("[%c]", c->Orange[i][j]);
        }
        for(j=0; j<c->Size; j++)
        {
            printf("[%c]", c->White[i][j]);
        }

        printf("\n");
    }

    for(i=0; i<c->Size; i++)
    {
        for(k=0; k<c->Size; k++) printf("   ");
        for(j=0; j<c->Size; j++)
        {
            printf("[%c]", c->Green[i][j]);
        }

        printf("\n");
    }

    printf("Yellow:\n");
    for(i=0; i<c->Size; i++)
    {
        for(j=0; j<c->Size; j++)
        {
            printf("[%c]", c->Yellow[i][j]);
        }
        printf("\n");
    }

    printf("\nOrange:\n");
    for(i=0; i<c->Size; i++)
    {
        for(j=0; j<c->Size; j++)
        {
            printf("[%c]", c->Orange[i][j]);
        }
        printf("\n");
    }

    printf("\nBlue:\n");
    for(i=0; i<c->Size; i++)
    {
        for(j=0; j<c->Size; j++)
        {
            printf("[%c]", c->Blue[i][j]);
        }
        printf("\n");
    }

    printf("\nRed:\n");
    for(i=0; i<c->Size; i++)
    {
        for(j=0; j<c->Size; j++)
        {
            printf("[%c]", c->Red[i][j]);
        }
        printf("\n");
    }

    printf("\nWhite:\n");
    for(i=0; i<c->Size; i++)
    {
        for(j=0; j<c->Size; j++)
        {
            printf("[%c]", c->White[i][j]);
        }
        printf("\n");
    }

    printf("\nGreen:\n");
    for(i=0; i<c->Size; i++)
    {
        for(j=0; j<c->Size; j++)
        {
            printf("[%c]", c->Green[i][j]);
        }
        printf("\n");
    }

    return;
}

void PrintCube(Cube * c)
{
    int i, j, k;

    for(i=0; i<c->Size; i++)
    {
        for(k=0; k<c->Size; k++) printf("    ");
        for(j=0; j<c->Size; j++)
        {
            printf("[%.2d]", c->Blue[i][j]);
        }

        printf("\n");
    }

    for(i=0; i<c->Size; i++)
    {
        for(j=0; j<c->Size; j++)
        {
            printf("[%.2d]", c->Red[i][j]);
        }
        for(j=0; j<c->Size; j++)
        {
            printf("[%.2d]", c->Yellow[i][j]);
        }
        for(j=0; j<c->Size; j++)
        {
            printf("[%.2d]", c->Orange[i][j]);
        }
        for(j=0; j<c->Size; j++)
        {
            printf("[%.2d]", c->White[i][j]);
        }

        printf("\n");
    }

    for(i=0; i<c->Size; i++)
    {
        for(k=0; k<c->Size; k++) printf("    ");
        for(j=0; j<c->Size; j++)
        {
            printf("[%.2d]", c->Green[i][j]);
        }

        printf("\n");
    }

    printf("Yellow:\n");
    for(i=0; i<c->Size; i++)
    {
        for(j=0; j<c->Size; j++)
        {
            printf("[%.2d]", c->Yellow[i][j]);
        }
        printf("\n");
    }

    printf("\nOrange:\n");
    for(i=0; i<c->Size; i++)
    {
        for(j=0; j<c->Size; j++)
        {
            printf("[%.2d]", c->Orange[i][j]);
        }
        printf("\n");
    }

    printf("\nBlue:\n");
    for(i=0; i<c->Size; i++)
    {
        for(j=0; j<c->Size; j++)
        {
            printf("[%.2d]", c->Blue[i][j]);
        }
        printf("\n");
    }

    printf("\nRed:\n");
    for(i=0; i<c->Size; i++)
    {
        for(j=0; j<c->Size; j++)
        {
            printf("[%.2d]", c->Red[i][j]);
        }
        printf("\n");
    }

    printf("\nWhite:\n");
    for(i=0; i<c->Size; i++)
    {
        for(j=0; j<c->Size; j++)
        {
            printf("[%.2d]", c->White[i][j]);
        }
        printf("\n");
    }

    printf("\nGreen:\n");
    for(i=0; i<c->Size; i++)
    {
        for(j=0; j<c->Size; j++)
        {
            printf("[%.2d]", c->Green[i][j]);
        }
        printf("\n");
    }

    return;
}
*/

#define C_YELLOW 0
#define C_ORANGE 1
#define C_BLUE   2
#define C_RED    3
#define C_WHITE  4
#define C_GREEN  5

#define AXE_X 0
#define AXE_Y 1
#define AXE_Z 2

typedef struct _Cube
{
    int Size;
    unsigned char ** Yellow;
    unsigned char ** Blue  ;
    unsigned char ** Green ;
    unsigned char ** White ;
    unsigned char ** Red   ;
    unsigned char ** Orange;
} Cube;

typedef struct _Hit
{
    unsigned Front :3;
    unsigned Right :3;
    unsigned Count :2;
    unsigned Axe   :2;
    unsigned Row   :22;
} Hit;

unsigned char * ReverseSequence(unsigned char * str, int len);
int Check(unsigned char * Name, unsigned char * Serial);
