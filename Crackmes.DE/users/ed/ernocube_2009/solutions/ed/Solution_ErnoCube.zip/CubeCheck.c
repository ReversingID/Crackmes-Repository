#include "CubeCheck.h"
#include "CubeSha.h"

unsigned char ** tmpAreaXY = NULL;
unsigned char *  tmpAreaX = NULL;

Cube * Init(int Size)
{
    int i;
    Cube * c;

    if(tmpAreaXY == NULL)
    {
        tmpAreaXY = (unsigned char **)GlobalAlloc(GPTR, sizeof(unsigned char *) * Size);

        for(i=0; i<Size; i++)
        {
            tmpAreaXY[i] = (unsigned char *)GlobalAlloc(GPTR, sizeof(unsigned char) * Size);
        }
    }

    if(tmpAreaX == NULL)
    {
        tmpAreaX = (unsigned char *)GlobalAlloc(GPTR, sizeof(unsigned char) * Size);
    }

    c = (Cube *)GlobalAlloc(GPTR, sizeof(Cube));
    c->Size = Size;

    c->Yellow = (unsigned char **)GlobalAlloc(GPTR, sizeof(unsigned char *) * Size);
    c->White  = (unsigned char **)GlobalAlloc(GPTR, sizeof(unsigned char *) * Size);
    c->Green  = (unsigned char **)GlobalAlloc(GPTR, sizeof(unsigned char *) * Size);
    c->Blue   = (unsigned char **)GlobalAlloc(GPTR, sizeof(unsigned char *) * Size);
    c->Red    = (unsigned char **)GlobalAlloc(GPTR, sizeof(unsigned char *) * Size);
    c->Orange = (unsigned char **)GlobalAlloc(GPTR, sizeof(unsigned char *) * Size);

    for(i=0; i<Size; i++)
    {
        c->Yellow[i] = (unsigned char *)GlobalAlloc(GPTR, sizeof(unsigned char) * Size);
        c->White[i]  = (unsigned char *)GlobalAlloc(GPTR, sizeof(unsigned char) * Size);
        c->Green[i]  = (unsigned char *)GlobalAlloc(GPTR, sizeof(unsigned char) * Size);
        c->Blue[i]   = (unsigned char *)GlobalAlloc(GPTR, sizeof(unsigned char) * Size);
        c->Red[i]    = (unsigned char *)GlobalAlloc(GPTR, sizeof(unsigned char) * Size);
        c->Orange[i] = (unsigned char *)GlobalAlloc(GPTR, sizeof(unsigned char) * Size);
    }

    return c;
}

Cube * CopyCube(Cube * c)
{
    Cube * ret = Init(c->Size);
    int i, j;

    for(i=0; i<c->Size; i++)
    {
        for(j=0; j<ret->Size; j++)
        {
            ret->Blue   [i][j] = c->Blue   [i][j];
            ret->Red    [i][j] = c->Red    [i][j];
            ret->Yellow [i][j] = c->Yellow [i][j];
            ret->Orange [i][j] = c->Orange [i][j];
            ret->White  [i][j] = c->White  [i][j];
            ret->Green  [i][j] = c->Green  [i][j];
        }
    }

    return ret;
}

void FreeCube(Cube * c)
{
    int j;

    for(j=0; j<c->Size; j++)
        GlobalFree(c->Blue[j]);
    GlobalFree(c->Blue);

    for(j=0; j<c->Size; j++)
        GlobalFree(c->Red[j]);
    GlobalFree(c->Red);

    for(j=0; j<c->Size; j++)
        GlobalFree(c->Yellow[j]);
    GlobalFree(c->Yellow);

    for(j=0; j<c->Size; j++)
        GlobalFree(c->Orange[j]);
    GlobalFree(c->Orange);

    for(j=0; j<c->Size; j++)
        GlobalFree(c->White[j]);
    GlobalFree(c->White);

    for(j=0; j<c->Size; j++)
        GlobalFree(c->Green[j]);
    GlobalFree(c->Green);

    GlobalFree(c);
    return;
}

Cube * BuiltRandomCube(int Size)
{
    Cube * ret = Init(Size);
    int i, j, MaxElt = Size * Size * 6, tmp;
    unsigned char * Comp = (unsigned char *)GlobalAlloc(GPTR, sizeof(unsigned char) * MaxElt);

    for(i=0; i<MaxElt; i++)
    {
        Comp[i] = 0;
    }

    for(i=0; i<ret->Size; i++)
    {
        for(j=0; j<ret->Size; j++)
        {
            rand_blue:
            if(Comp[(tmp = rand() % MaxElt)] == 0)
            {
                Comp[tmp] = 1;
                ret->Blue[i][j] = tmp;
            }
            else
            {
                goto rand_blue;
            }

            rand_red:
            if(Comp[(tmp = rand() % MaxElt)] == 0)
            {
                Comp[tmp] = 1;
                ret->Red[i][j] = tmp;
            }
            else
            {
                goto rand_red;
            }

            rand_yellow:
            if(Comp[(tmp = rand() % MaxElt)] == 0)
            {
                Comp[tmp] = 1;
                ret->Yellow[i][j] = tmp;
            }
            else
            {
                goto rand_yellow;
            }

            rand_orange:
            if(Comp[(tmp = rand() % MaxElt)] == 0)
            {
                Comp[tmp] = 1;
                ret->Orange[i][j] = tmp;
            }
            else
            {
                goto rand_orange;
            }

            rand_white:
            if(Comp[(tmp = rand() % MaxElt)] == 0)
            {
                Comp[tmp] = 1;
                ret->White[i][j] = tmp;
            }
            else
            {
                goto rand_white;
            }

            rand_green:
            if(Comp[(tmp = rand() % MaxElt)] == 0)
            {
                Comp[tmp] = 1;
                ret->Green[i][j] = tmp;
            }
            else
            {
                goto rand_green;
            }
        }
    }

    GlobalFree(Comp);
    return ret;
}

int CompareCube(Cube * a, Cube * b)
{
    int i, j;

    if(a->Size != b->Size)
    {
        return 1;
    }

    for(i=0; i<a->Size; i++)
    {
        for(j=0; j<a->Size; j++)
        {
            if(a->Blue[i][j] != b->Blue[i][j])
            {
                return 1;
            }

            if(a->Red[i][j] != b->Red[i][j])
            {
                return 1;
            }

            if(a->Yellow[i][j] != b->Yellow[i][j])
            {
                return 1;
            }

            if(a->Orange[i][j] != b->Orange[i][j])
            {
                return 1;
            }

            if(a->White[i][j] != b->White[i][j])
            {
                return 1;
            }

            if(a->Green[i][j] != b->Green[i][j])
            {
                return 1;
            }
        }
    }

    return 0;
}

char ToChar(int a)
{
    if(a >= 0 && a <= 9)
        return a + '0';

    if(a >= 10 && a <= 16)
        return (a - 10) + 'A';

    return 0;
}

int FromChar(char a)
{
    if(a >= '0' && a <= '9')
        return a - '0';

    if(a >= 'A' && a <= 'F')
        return a - 'A' + 10;

    if(a >= 'a' && a <= 'f')
        return a - 'a' + 10;

    return 0;
}

void FlatRotate(unsigned char ** Area, int Count, int Size)
{
    int x, y, i;

    for(i=0; i<Count; i++)
    {
        for(x=0; x<Size; x++)
        {
            for(y=0; y<Size; y++)
            {
                tmpAreaXY[y][(Size - 1) - x] = Area[x][y];
            }
        }

        for(x=0; x<Size; x++)
        {
            for(y=0; y<Size; y++)
            {
                Area[x][y] = tmpAreaXY[x][y];
            }
        }
    }

    return;
}

void FlatRotateR(unsigned char ** Area, int Count, int Size)
{
    int x, y, i;

    for(i=0; i<Count; i++)
    {
        for(x=0; x<Size; x++)
        {
            for(y=0; y<Size; y++)
            {
                tmpAreaXY[x][y] = Area[y][(Size - 1) - x];
            }
        }

        for(x=0; x<Size; x++)
        {
            for(y=0; y<Size; y++)
            {
                Area[x][y] = tmpAreaXY[x][y];
            }
        }
    }

    return;
}

void SideRotate(unsigned char ** AreaT, unsigned char ** AreaR, unsigned char ** AreaD, unsigned char ** AreaL,
    int Row, int Count, int Size)
{
    int i, j, cRow = (Size - 1) - Row;

    for(i=0; i<Count; i++)
    {
        for(j=0; j<Size; j++)
            tmpAreaX[j] = AreaR[j][Row];

        for(j=0; j<Size; j++)
            AreaR[j][Row] = AreaT[cRow][j];

        for(j=0; j<Size; j++)
            AreaT[cRow][j] = AreaL[(Size - 1) - j][cRow];

        for(j=0; j<Size; j++)
            AreaL[j][cRow] = AreaD[Row][j];

        for(j=0; j<Size; j++)
            AreaD[Row][j] = tmpAreaX[(Size - 1) - j];
    }

    return;
}

void RFX(Cube * c, int Count)
{
    int i;

    FlatRotate(c->Orange, Count, c->Size);
    FlatRotate(c->Red   , Count, c->Size);

    for(i=0; i<c->Size; i++)
        SideRotate(c->Yellow, c->Blue, c->White, c->Green, i, Count, c->Size);

    return;
}

void RFY(Cube * c, int Count)
{
    int i;

    FlatRotate(c->Blue , Count, c->Size);
    FlatRotate(c->Green, Count, c->Size);

    for(i=0; i<c->Size; i++)
        SideRotate(c->Yellow, c->Orange, c->White, c->Red, i, Count, c->Size);

    return;
}

void RFZ(Cube * c, int Count)
{
    int i;

    FlatRotate(c->Yellow, Count, c->Size);
    FlatRotate(c->White , Count, c->Size);

    for(i=0; i<c->Size; i++)
        SideRotate(c->Blue, c->Red, c->Green, c->Orange, i, Count, c->Size);

    return;
}

void RRFX(Cube * c, int Count)
{
    RFX(c, Count);
    RFX(c, Count);
    RFX(c, Count);

    return;
}

void RRFY(Cube * c, int Count)
{
    RFY(c, Count);
    RFY(c, Count);
    RFY(c, Count);

    return;
}

void RRFZ(Cube * c, int Count)
{
    RFZ(c, Count);
    RFZ(c, Count);
    RFZ(c, Count);

    return;
}

void RX(Cube * c, int Deep)
{
    if(Deep == (c->Size - 1) || Deep == 0)
    {
        FlatRotate(c->Orange, 1, c->Size);
        FlatRotate(c->Red   , 1, c->Size);
    }
    SideRotate(c->Yellow, c->Blue, c->White, c->Green, Deep, 1, c->Size);

    return;
}

void RY(Cube * c, int Deep)
{
    if(Deep == (c->Size - 1) || Deep == 0)
    {
        FlatRotate(c->Blue , 1, c->Size);
        FlatRotate(c->Green, 1, c->Size);
    }
    SideRotate(c->Yellow, c->Orange, c->White, c->Red, Deep, 1, c->Size);

    return;
}

void RZ(Cube * c, int Deep)
{
    if(Deep == (c->Size - 1) || Deep == 0)
    {
        FlatRotate(c->Yellow, 1, c->Size);
        FlatRotate(c->White , 1, c->Size);
    }
    SideRotate(c->Blue, c->Red, c->Green, c->Orange, Deep, 1, c->Size);

    return;
}

void RRX(Cube * c, int Deep)
{
    RX(c, Deep);
    RX(c, Deep);
    RX(c, Deep);

    return;
}

void RRY(Cube * c, int Deep)
{
    RY(c, Deep);
    RY(c, Deep);
    RY(c, Deep);

    return;
}

void RRZ(Cube * c, int Deep)
{
    RZ(c, Deep);
    RZ(c, Deep);
    RZ(c, Deep);

    return;
}

void ProcessHashOnCube(Cube * c, unsigned char * Permutations, int pLen)
{
    int i;

    for(i=0; i<pLen; i++)
    {
        //printf("Action: %c%c\n", Permutations[i], Permutations[i + 1]);
        switch(Permutations[i])
        {
            case '0':
                RFX(c, FromChar(Permutations[i + 1])); // v
                //RFX(c, (c->Size - 1) - FromChar(Permutations[i + 1]));
                i++;
                break;
            case '1':
                RFY(c, FromChar(Permutations[i + 1])); // v
                //RFY(c, (c->Size - 1) - FromChar(Permutations[i + 1]));
                i++;
                break;
            case '2':
                RFZ(c, FromChar(Permutations[i + 1])); // v
                //RFZ(c, (c->Size - 1) - FromChar(Permutations[i + 1]));
                i++;
                break;
            case '3':
                RRFX(c, FromChar(Permutations[i + 1])); // v
                //RRFX(c, (c->Size - 1) - FromChar(Permutations[i + 1]));
                i++;
                break;
            case '4':
                RRFY(c, FromChar(Permutations[i + 1])); // v
                //RRFY(c, (c->Size - 1) - FromChar(Permutations[i + 1]));
                i++;
                break;
            case '5':
                RRFZ(c, FromChar(Permutations[i + 1])); // v
                //RRFZ(c, (c->Size - 1) - FromChar(Permutations[i + 1]));
                i++;
                break;
            case '6':
                RX(c, FromChar(Permutations[i + 1])); // v

                //for(j=0; j<3; j++)
                //    RX(c, FromChar(Permutations[i + 1]));
                i++;
                break;
            case '7':
                RY(c, FromChar(Permutations[i + 1])); // v

                //for(j=0; j<3; j++)
                //    RY(c, FromChar(Permutations[i + 1]));
                i++;
                break;
            case '8':
                RZ(c, FromChar(Permutations[i + 1])); // v

                //for(j=0; j<3; j++)
                //    RZ(c, FromChar(Permutations[i + 1]));
                i++;
                break;
            case '9':
                RRX(c, FromChar(Permutations[i + 1])); // v

                //for(j=0; j<3; j++)
                //    RRX(c, FromChar(Permutations[i + 1]));
                i++;
                break;
            case 'A':
                RRY(c, FromChar(Permutations[i + 1])); // v

                //for(j=0; j<3; j++)
                //    RRY(c, FromChar(Permutations[i + 1]));
                i++;
                break;
            case 'B':
                RRZ(c, FromChar(Permutations[i + 1])); // v

                //for(j=0; j<3; j++)
                //    RRZ(c, FromChar(Permutations[i + 1]));
                i++;
                break;
            case 'C':
                RX(c, FromChar(Permutations[i + 1]));
                RZ(c, FromChar(Permutations[i + 1]));

                //for(j=0; j<3; j++)
                //    RZ(c, FromChar(Permutations[i + 1]));

                //for(j=0; j<3; j++)
                //    RX(c, FromChar(Permutations[i + 1]));
                i++;
                break;
            case 'D':
                RRFY(c, FromChar(Permutations[i + 1]));
                RFX(c, FromChar(Permutations[i + 1]));

                //RFX(c, (c->Size - 1) - FromChar(Permutations[i + 1]));
                //RRFY(c, (c->Size - 1) - FromChar(Permutations[i + 1]));

                i++;
                break;
            case 'E':
                RRFZ(c, FromChar(Permutations[i + 1]));
                RRFX(c, FromChar(Permutations[i + 1]));

                //RRFX(c, (c->Size - 1) - FromChar(Permutations[i + 1]));
                //RRFZ(c, (c->Size - 1) - FromChar(Permutations[i + 1]));

                i++;
                break;
            case 'F':
                RFZ(c, FromChar(Permutations[i + 1]));
                RRZ(c, FromChar(Permutations[i + 1]));

                //for(j=0; j<3; j++)
                //    RRZ(c, FromChar(Permutations[i + 1]));

                //RFZ(c, (c->Size - 1) - FromChar(Permutations[i + 1]));
                i++;
                break;
            default:
                break;
        }
    }

    return;
}

int EdStrCmp(unsigned char * a, unsigned char * b)
{
    int i;

    for(i=0; a[i] != '\0' || b[i] != '\0'; i++)
    {
        if(a[i] != b[i])
        {
            return 1;
        }
    }

    return 0;
}

__declspec(naked) DWORD __fastcall EdStrLen(BYTE * Dest)
{
    __asm
    {
        push ebx
        push ecx

    ALIGN 16
    next32bits:
        mov eax, [ecx]
        mov ebx, eax
        and eax, 07F7F7F7Fh
        add ecx, 4
        add eax, 07F7F7F7Fh
        or eax, ebx
        and eax, 080808080h
        xor eax, 080808080h
        jz next32bits

        sub ecx, 4

    ALIGN 16
    nextbyte:
        cmp BYTE ptr[ecx], 0
        je end
            inc ecx
        jmp nextbyte
    end:

        mov ebx, ecx
        pop ecx
        sub ebx, ecx
        mov eax, ebx

        pop ebx
        ret
    }
}

int CheckSerialValidity(unsigned char * Serial)
{
    int len = EdStrLen(Serial);
    int i;
    int tmp;

    if((len % 2) != 0)
    {
        return 0;
    }

    for(i=0; i<len; i++)
    {
        tmp = Serial[i];
        if(!((tmp >= '0' && tmp <= '9') ||
           (tmp >= 'A' && tmp <= 'F')))
        {
            return 0;
        }
    }

    return len;
}

int Check(unsigned char * Name, unsigned char * Serial)
{
    Cube * cCube;
    Cube * _cCube;
    unsigned char * Perms;
    unsigned char * Fake;
    int ret = 1;

    cCube = BuiltRandomCube(61);
    _cCube = CopyCube(cCube);

    Perms = sha_256_string(Name, EdStrLen(Name));

    Fake = ReverseSequence(Perms, EdStrLen(Perms));
    if(EdStrCmp(Serial, Fake) == 0)
    {
        FreeCube(cCube);
        FreeCube(_cCube);
        GlobalFree(Perms);
        GlobalFree(Fake);
        return 1;
    }

    ProcessHashOnCube(cCube, Perms, EdStrLen(Perms));
    if(CheckSerialValidity(Serial) != 0)
    {
        ProcessHashOnCube(cCube, Serial, EdStrLen(Serial));
    }
    else
    {
        FreeCube(cCube);
        FreeCube(_cCube);
        GlobalFree(Perms);
        GlobalFree(Fake);
        return 1;
    }

    ret = CompareCube(_cCube, cCube);

    FreeCube(cCube);
    FreeCube(_cCube);
    GlobalFree(Perms);
    GlobalFree(Fake);
    return ret;
}
