#include "CubeGeneration.h"

unsigned char * ReverseSequence(unsigned char * str, int len)
{
    int i;
    unsigned char tmp;
    unsigned char * ret = GlobalAlloc(GPTR, (len * 2) + 1);

    for(i=0; i<len; i++)
    {
        ret[i] = str[len - (i+1)];
        ret[i+1] = str[len-i];
    }
    ret[len] = 0;

    for(i=0; i<len; i+=2)
    {
        tmp = ret[i+1];
        ret[i+1] = ret[i];
        ret[i] = tmp;
    }

    return ret;
}

unsigned char * ReplaceInString(unsigned char * str, int index, int size, unsigned char * to)
{
    unsigned char tmp[100];
    int len = strlen(str);
    int len2 = strlen(to);
    int len3, i, j;

    memset(tmp, 0, 100);

    for(i=index, j=0; i<len; i++, j++)
    {
        tmp[j] = str[i];
    }

    for(i=index, j=0; i<(len2 + len); i++, j++)
    {
        str[i] = to[j];
    }

    len3 = strlen(tmp);

    for(i=0; i<len3; i++)
    {
        str[index + len2 + i] = tmp[i + size];
    }
    str[len + len2] = 0;

    return str;
}

unsigned char * ReverseProcessOnCube(unsigned char * Permutations)
{
    unsigned int i;
    unsigned char * ret = ReverseSequence(Permutations, strlen(Permutations));
    unsigned char tmp[10];
    memset(tmp, 0, 10);

    for(i=0; i<strlen(ret); i++)
    {
        switch(ret[i])
        {
            case '0':
                // 07 -> 37
                ret[i] = '3';
                i++;
                break;
            case '1':
                // 18 -> 48
                ret[i] = '4';
                i++;
                break;
            case '2':
                // 27 -> 57
                ret[i] = '5';
                i++;
                break;
            case '3':
                // 34 -> 04
                ret[i] = '0';
                i++;
                break;
            case '4':
                // 45 -> 15
                ret[i] = '1';
                i++;
                break;
            case '5':
                // 57 -> 27
                ret[i] = '2';
                i++;
                break;
            case '6':
                // 64 -> 94
                ret[i] = '9';
                i++;
                break;
            case '7':
                // 72 -> A2
                ret[i] = 'A';
                i++;
                break;
            case '8':
                // 83 -> B3
                ret[i] = 'B';
                i++;
                break;
            case '9':
                // 98 -> 68
                ret[i] = '6';
                i++;
                break;
            case 'A':
                // A5 -> 75
                ret[i] = '7';
                i++;
                break;
            case 'B':
                // B4 -> 84
                ret[i] = '8';
                i++;
                break;
            case 'C':
                // C5 -> B595
                tmp[0] = 'B';
                tmp[1] = ret[i + 1];
                tmp[2] = '9';
                tmp[3] = ret[i + 1];

                ret = ReplaceInString(ret, i, 2, tmp);
                i+=3;
                break;
            case 'D':
                // D7 -> 3717
                tmp[0] = '3';
                tmp[1] = ret[i + 1];
                tmp[2] = '1';
                tmp[3] = ret[i + 1];

                ret = ReplaceInString(ret, i, 2, tmp);
                i+=3;
                break;
            case 'E':
                // E9 -> 0929
                tmp[0] = '0';
                tmp[1] = ret[i + 1];
                tmp[2] = '2';
                tmp[3] = ret[i + 1];

                ret = ReplaceInString(ret, i, 2, tmp);
                i+=3;
                break;
            case 'F':
                // FB -> 8B5B
                tmp[0] = '8';
                tmp[1] = ret[i + 1];
                tmp[2] = '5';
                tmp[3] = ret[i + 1];

                ret = ReplaceInString(ret, i, 2, tmp);
                i+=3;
                break;
            default:
                break;
        }
    }

    return ret;
}


unsigned char * GenerateSerial(unsigned char * Name)
{
    unsigned char * md = sha_256_string(Name, strlen(Name));
    unsigned char * ret = ReverseProcessOnCube(md);
    GlobalFree(md);
    return ret;
}
