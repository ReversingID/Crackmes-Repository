#include "CubeGeneration.h"
#include "CubeCheck.h"

int main(int argc, char * argv[])
{
    unsigned char Name[100];
    unsigned char Serial[500];

    printf("Enter your name: ");
    scanf_s("%s", &Name, 100);

    printf("Serial: %s\n", GenerateSerial(Name));
    system("PAUSE");

    printf("Enter the serial: ");
    scanf_s("%s", &Serial, 500);

    printf("%s !\n", Check(Name, Serial) == 0 ? "GOOD BOY" : "BAD BOY");
    system("PAUSE");

    return 0;
}
