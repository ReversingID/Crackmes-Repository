#include "CubeSha.h"

unsigned char * GenerateSerial(unsigned char * Name);
