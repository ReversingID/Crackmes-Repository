
#include <windows.h>
#include <stdio.h>

char mapch (char ch)
{
    if ((ch >= '0') && (ch <= '9')) {
        return ch - '0';
    } else if ((ch >= 'A') && (ch <= 'F')) {
        return ch - 0x37;
    } else {
        return 0;
    }
}

char mapa (char x)
{
    return '0' + 4 - (mapch (x) & 3);
}

char mapb (char x)
{
    return x;
}

char mapc (char x)
{
    return '0' + 4 - ((3 * mapch (x)) & 3);
}

typedef char (* symmap) (char);

#define CUBE_MAX 16

char * alpha[] = {
    "0", "1", "2", "0",
    "1", "2", "9", "A",
    "B", "6", "7", "8",
    "B9", "01", "02", "82"
};

symmap funcmap[CUBE_MAX][CUBE_MAX] = {
    {mapa, 0, 0, mapc, 0, 0, 0, 0, 0, 0, 0, 0, 0, mapa, mapc, 0}, /* from * -> '0' */
    {0, mapa, 0, 0, mapc, 0, 0, 0, 0, 0, 0, 0, 0, mapc, 0, 0}, /* from * -> '1' */
    {0, 0, mapa, 0, 0, mapc, 0, 0, 0, 0, 0, 0, 0, 0, mapc, mapa}, /* '2' */
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, /* '3' */
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, /* '4' */
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, /* '5' */
    {0, 0, 0, 0, 0, 0, 0, 0, 0, mapb, 0, 0, 0, 0, 0, 0}, /* '6' */
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, mapb, 0, 0, 0, 0, 0}, /* '7' */
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, mapb, 0, 0, 0, mapb}, /* '8' */
    {0, 0, 0, 0, 0, 0, mapb, 0, 0, 0, 0, 0, mapb, 0, 0, 0}, /* '9' */
    {0, 0, 0, 0, 0, 0, 0, mapb, 0, 0, 0, 0, 0, 0, 0, 0}, /* 'A' */
    {0, 0, 0, 0, 0, 0, 0, 0, mapb, 0, 0, 0, mapb, 0, 0, 0}, /* 'B' */
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
};

typedef struct _transition {
    char string[CUBE_MAX];
    symmap func[CUBE_MAX];
    int len;
} transition;

transition betta[256];

void bettafill (transition * pbetta, char ** palpha)
{
    int ix, jx, t;
    
    for (ix = '0', jx = 0; ix <= '9'; ix ++, jx ++) {
        strcpy (pbetta[ix].string, palpha[jx]);
        t = pbetta[ix].len = strlen (palpha[jx]);
    }
    
    for (ix = 'A'; ix <= 'F'; ix ++, jx ++) {
        strcpy (pbetta[ix].string, palpha[jx]);
        t = pbetta[ix].len = strlen (palpha[jx]);
    }
}

void invert (char * hash, char * result)
{
    int ix, jx, kx = 0, len = strlen (hash);
    transition * ptrans;
    char sym, syma, symb, symc;
    for (ix = 0; ix < len / 2; ix ++) {
        sym = hash [len - 2 * (ix + 1)];
        ptrans = & betta[sym];
        syma = hash [len - 2 * ix - 1];
        for (jx = 0; jx < ptrans->len; jx ++) {
            symb = ptrans->string[jx];
            symc = funcmap [mapch (symb)][mapch (sym)] (syma) ; /* funcmap [to] [from]*/
            result[kx] = symb;
            result[kx + 1] = symc;
            kx += 2;
        }
    }
}

char test_hash[] = "018014E6E071BF828C60B3AFA4C40FA4"
                   "650E4B8DF237F711B46FCF5E9F12942D";
/*  */

typedef struct _hash_ctx {
    unsigned long m0; // +0
    unsigned long m1; // +4
    unsigned long m2; // +8
    unsigned long m3; // +c
    unsigned long m4; // +10
    unsigned long m5; // +14
    unsigned long m6; // +18
    unsigned long m7; // +1c
    unsigned long x;  // +20
    unsigned long nextofs; // +24
    unsigned char buffer[0x40]; //+28
}hash_ctx;

void hash_init (hash_ctx * p)
{
    memset (p, 0, sizeof (*p));
    p->m0 = 0x6A09E667;
    p->m1 = 0xBB67AE85;
    p->m2 = 0x3C6EF372;
    p->m3 = 0xA54FF53A;
    p->m4 = 0x510E527F;
    p->m5 = 0x9B05688C;
    p->m6 = 0x1F83D9AB;
    p->m7 = 0x5BE0CD19;
}

void __fastcall make_hash (hash_ctx * p_ctx, char * name, int len);
void __fastcall make_hash1 (hash_ctx * p_ctx, char * result);

void name_to_hash (hash_ctx * p_ctx, char * name, char * hash)
{
    int ix, iy = 0, len = strlen (name);
    char result [256];
    hash_init (p_ctx);
    make_hash (p_ctx, name, len);
    make_hash1 (p_ctx, (char *)result);
    for (ix = 0; ix < 32; ix ++) {
        iy += sprintf (hash + iy, "%02X", result[ix] & 0xff);
    }
}

void main ()
{
    char buffer[256];
    hash_ctx hash;
    char hash_res[256];
    char name[256];
    printf ("your name : ");
    scanf ("%256s", name);
    memset (buffer, 0, sizeof (buffer));
    bettafill ((transition *)betta, (char **)alpha);
    name_to_hash (&hash, name, (char *)hash_res);
    printf ("name_hash : %s\n", hash_res);
    invert (hash_res, buffer);
    printf (buffer);
}

/*

*/