A Crackme By kemicza
-----------------------
Crackme 5 I think this is I dont know if you guys can crack it I hope so :p , But I think you can
I think Everything is Crackable , Beacause I think good , I think allot hehe ye I know Actually I'm 
thinking right now so cool hihiihiii.

Help!!
-----------------------
Ask me on Forums www.gameditions.com/forums   or others , or email me

Thanks!
-----------------------
I would like to thank everybody who helped me with gamehacking and programming 
And Thanx to Magna for Explaining me stuff about VB :D

Linkszzzzzzzz!
-----------------------
http://kemicza.zapto.org
http://www.gameditions.com
http://www.dvshacking.com
http://www.extalia.com
http://www.gamehacking.com

And all i forgot ,,...

Email 
-------------------------
Email: kemal_bad@hotmail.com
Email me if you cant crack it ask on forums for help and stuff,, I can crack it because I know the 
passwords!!!!, If you cant crack it I will send ya the Source code and stuff, I will post the source code 
on Gameditions if someone cracks it :D... 

Other things
-------------------------
Size of "A Crackme": 36.0 KB
Made on            :20-04-2004 19:37
