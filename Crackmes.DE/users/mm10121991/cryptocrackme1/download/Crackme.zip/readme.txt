hello

your task in this target is to make a keygen

rules: as always no patching only a keygen is a good solution