//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by rsrc.rc
//
#define IDB_BITMAP1                     102
#define IDC_GEN                         1000
#define IDC_EXIT                        1001
#define IDC_NAME                        1002
#define IDC_COMPANY                     1003
#define IDC_SERIAL                      1004
#define IDC_DEFULT                      1005
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
