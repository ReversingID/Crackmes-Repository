All the source was compiled with MASM 6, but to compile you need MS Visual C++ 6.0 because you need all the librarys and stuff, there's alot of them so i dont wana include them all.  later

rage9
realcool23@yahoo.com