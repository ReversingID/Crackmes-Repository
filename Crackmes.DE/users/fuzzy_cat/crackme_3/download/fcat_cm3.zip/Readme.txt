 -The III CrackMe-

Hi there mate!! :)
Another crackme released by FuzzyCat!!! (it's me?) :)
This should be harder but i don't know...??..
Maybe it is maybe it isn't, can u tell me??

Ok lets get to the stuff..
There are 2 goals in this crackme, and they can be joined, in to
one, if ya do them both! :)
1� Goal:
 Find the correct key for your name/company

2� Goal:
 Make a keygen for your name/company

Hope u succeed!!

If know another GOAL (?), crack it to, (maybe its a bug..)
ok, when you've done 1 or more GOALS email me, with the cracked file,
or patcher (.exe) or the sourcecode, and with a brief tut or a real
tut...

FuzzyCat@gmx.net

Cu!!

STUFF:
iNNU3NDo, Duelist, DYCUS, R!SC,Northpole, bM[tfgx], tKC, NU|<EM
Prof.X, LaZaRuS, amokk, DarkShadow, SiR_DawG, Acid Cool 178, TSCube &
all i've forgotten, and my friends..

FuzzyCat
'Remember, NO ONE WAS BORN L33T.'

Da Breaker Crew 2000