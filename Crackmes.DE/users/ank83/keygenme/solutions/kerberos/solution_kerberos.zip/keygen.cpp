#include <iostream>
#include <string>

using namespace std;

int keyGen (int n){
	return 2+n*(1+n)/2;
}

int main()
{
    int ID;

    cout <<"Enter ID : ";
    cin>>ID;

    cout <<"Serial code : "<<keyGen(ID)<<endl;
  return 0;
}
