#include <iostream.h>

int main(){

 int IDvalue=0;

 cout << "\nKeygen for 'Ank83's KeyGenMe #2' by NexusC\n";
 cout << "\nEnter an valid ID between 0-999: ";
 cin >> IDvalue;

 IDvalue += 1;
 IDvalue += IDvalue;
 IDvalue -= 1;
 IDvalue *= IDvalue;
 IDvalue -= 190;

 cout << "Serial: " << IDvalue;

 return 0;
}