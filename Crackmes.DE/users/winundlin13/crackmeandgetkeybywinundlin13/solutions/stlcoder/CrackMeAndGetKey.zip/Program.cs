﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrackMeAndGetKeyKeyGen
{
    class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            string lastPW = "";

            while (true)
            {
                string newPW = GetCurrentPassword();
                if (lastPW != newPW)
                {
                    Console.WriteLine("Current password is: {0}", newPW);
                    lastPW = newPW;
                }
                System.Threading.Thread.Sleep(5000);
            }
        }

        private static string GetCurrentPassword()
        {
            return string.Format("{0}{1}{2}{3}", Environment.MachineName, (int)Environment.MachineName.ToCharArray()[0],
                DateTime.Now.Minute.ToString(), System.Windows.Forms.Clipboard.GetText());
        }
    }
}
