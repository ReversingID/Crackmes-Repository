My first crackme!

No patch, make a keygen!