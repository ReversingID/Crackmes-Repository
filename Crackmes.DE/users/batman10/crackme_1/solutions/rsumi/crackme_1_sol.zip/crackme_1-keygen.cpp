#include <iostream>
#include <string>

using namespace std;

int main(){
	cout << "Enter name: " << endl;
	string name;
	cin >> name;
	int sum = 0;
	for(size_t i = 0; i != name.length(); ++i){
		sum += name[i] ^ 0x47;
		name[i] ^= 0x47;
		name[i] ^= 0x42;
	}
	cout << name << endl;
}
