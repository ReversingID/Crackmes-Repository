/*************************************************************************

 Filename:		Keygen.c
 Purpose:		Keygen for Cronos Crackme #1
 Author:		figugegl
 Version:		1.0
 Date:			13.10.2001

*************************************************************************/


/*------------------------------------------------------------------------
	Include files
------------------------------------------------------------------------*/
#include <windows.h>
#include <stdio.h>
#include "keygenres.h"


/*------------------------------------------------------------------------
	Prototypes
------------------------------------------------------------------------*/
LRESULT CALLBACK MainDlgProc	(HWND, UINT, WPARAM, LPARAM) ;


/*------------------------------------------------------------------------
	Global variables
------------------------------------------------------------------------*/


/*------------------------------------------------------------------------
 Procedure:     WinMain
 Purpose:       Application entry point. Registers a class of the same
                type than the dialog class,calls DialogBox and then exits
 Input:         Standard
 Output:        None
 Errors:        None
------------------------------------------------------------------------*/
int WINAPI WinMain (HINSTANCE hInst, HINSTANCE hPrevInst, PSTR szCmdLine, int CmdShow)
{
	static TCHAR	szAppName[] = TEXT ("keygen") ;
	WNDCLASS		wc ;

	memset (&wc, 0, sizeof (wc));				// empty structure wc

	wc.lpfnWndProc		= MainDlgProc ;			// callback procedure
	wc.cbWndExtra		= DLGWINDOWEXTRA ;
	wc.hInstance		= hInst ;
	wc.hIcon			= LoadIcon (hInst, MAKEINTRESOURCE (ICO_FIGU)) ;
	wc.hCursor			= LoadCursor (NULL, IDC_ARROW) ;
	wc.hbrBackground	= (HBRUSH) (COLOR_BTNFACE + 1) ;
	wc.lpszClassName	= szAppName ;

	if (!RegisterClass (&wc))
		return 0;

	return DialogBoxParamA (hInst, MAKEINTRESOURCE (DLG_MAIN), NULL, (DLGPROC) MainDlgProc, 0);
}


/*------------------------------------------------------------------------
 Procedure:     CalculateSerial
 Purpose:       Calculate a valid serial
 Input:         hWnd:	Handle of the Dialogbox
 Output:        None
 Errors:        None
------------------------------------------------------------------------*/
void CalculateSerial (HWND hWnd)
{
	char	szName[32];
	char	szSerial[16]	= "";
	char	szString[16];
	int		iNameLen;
	char	i, j, k, l, m, n;

	iNameLen = GetDlgItemTextA (hWnd, EDF_NAME, szName, 32);
	if (iNameLen < 6)
	{
		SetDlgItemTextA (hWnd, EDF_SERIAL, NULL);
		SetDlgItemTextA (hWnd, EDF_STRING, NULL);
	}
	else
	{
		for (i = 0; i < 6; i++)
		{
			for (szSerial[i+6] = 0x21; szSerial[i+6] <= 0xFF; szSerial[i+6]++)
			{
				szSerial[i] = (0x20 - szName[i] * szName[i] - szSerial[i+6] * 0x1A);
				if (szSerial[i] > 0x20)
					break;
			}
		}
		SetDlgItemTextA (hWnd, EDF_SERIAL, szSerial);

		for (i = 0x40; i <= 0x60; i++)
		{
			for (j = 0x40; j <= 0x60; j++)
			{
				for (k = 0x40; k <= 0x60; k++)
				{
					for (l = 0x40; l <= 0x60; l++)
					{
						if ((((i << 0x18) + (j << 0x10) + (k << 8) + l) * 0xDA7949) == 0x6E8E9964)
						{
							for (m = 0x40; m <= 0x60; m++)
							{
								for (n = 0x40; n <= 0x60; n++)
								{
									if ((((m << 8) + n) * 0x2262AD4D) == 0x55DE1729)
									{
										szString[0] = l;
										szString[1] = k;
										szString[2] = j;
										szString[3] = i;
										szString[4] = n;
										szString[5] = m;
										szString[6] = '=';
										szString[7] = l;
										szString[8] = i;
										szString[9] = k;
										szString[10] = j;
										szString[11] = m;
										szString[12] = 0;
										SetDlgItemTextA (hWnd, EDF_STRING, szString);
									}
								}
							}
						}
					}
				}
			}
		}
	}
}


/*------------------------------------------------------------------------/*------------------------------------------------------------------------
 Procedure:     AboutDlgProc
 Purpose:       Handles the messages of the about dialog
 Input:         Standard
 Output:        TRUE if the message was processed
 Errors:        None
------------------------------------------------------------------------*/
LRESULT CALLBACK AboutDlgProc (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
     switch (uMsg)
     {
     case WM_INITDIALOG:
          return 0;

     case WM_COMMAND:
          if (LOWORD (wParam) == BUT_OK)
          {
               EndDialog (hWnd, 0) ;
               return 0;
          }
          break ;
     }
     return FALSE ;
}


/*------------------------------------------------------------------------
 Procedure:     MainDialogProc
 Purpose:       It handles all messages of the main dialog
 Input:         Standard
 Output:        TRUE if the message was processed
 Errors:        None
------------------------------------------------------------------------*/
LRESULT CALLBACK MainDlgProc (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static TCHAR	szFigugegl[]	= TEXT ("figugegl");

	switch (uMsg)
	{
	case WM_INITDIALOG:
		SendDlgItemMessageA (hWnd, EDF_NAME, EM_LIMITTEXT, 32, 0);
		SetDlgItemTextA (hWnd, EDF_NAME, szFigugegl);
		return 0 ;

	case WM_COMMAND:
		switch (LOWORD (wParam))
		{
		case EDF_NAME:			// Namefield
			if (HIWORD (wParam) == EN_CHANGE)
			{
				CalculateSerial (hWnd);
		 		return 0;
			}
			break;

		case BUT_ABOUT:			// About
			DialogBox (NULL, MAKEINTRESOURCE (DLG_ABOUT), hWnd, (DLGPROC) AboutDlgProc);
			return 0;
		}
		break;

	case WM_CLOSE:
		PostQuitMessage (0) ;
		return 0 ;
	}
	return DefWindowProc (hWnd, uMsg, wParam, lParam) ;
}
