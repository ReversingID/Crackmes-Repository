
#undef	UNICODE
#undef	_UNICODE
#include <windows.h>
#include "resource.h"

//#define NOT_RANDOMIZE

//prototypy
BOOL CALLBACK DialogProc(HWND  hwndDlg, UINT  uMsg, WPARAM  wParam, LPARAM  lParam );
void GenerateSerial (HWND hDlg);

//------------------------------------------
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	DialogBoxParam (hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, DialogProc, 0);
	return 0;
}

//------------------------------------------
BOOL CALLBACK DialogProc(HWND  hwndDlg, UINT  uMsg, WPARAM  wParam, LPARAM  lParam )
{
	switch (uMsg)
	{
	case WM_INITDIALOG:
		SendDlgItemMessage (hwndDlg, IDC_EDIT_NAME, EM_SETLIMITTEXT, 16, 0);
		return TRUE;

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDC_BUTTON_GENERATE:
			GenerateSerial (hwndDlg);
			return TRUE;
		case IDCANCEL:
			EndDialog (hwndDlg, 0);
			return TRUE;
		}
	}
	return FALSE;
}

//------------------------------------------
void GenerateSerial (HWND hDlg)
{
#ifndef _DEBUG		//obsluha v�nimiek
	__try{
#endif

	DWORD i;
	char szName[20] = {0}, szSerial[33] = {0};

	DWORD dwNameLen = GetDlgItemText (hDlg, IDC_EDIT_NAME, szName, 20);
	if (dwNameLen == 0)
	{
		SetFocus (GetDlgItem (hDlg, IDC_EDIT_NAME));
		return;
	}

	bool fValidName = true;
	for (i=0; i<dwNameLen; i++)
		if ((szName[i]<'0' || szName[i]>'9') && (szName[i]<'A' || szName[i]>'Z') && \
			(szName[i]<'a' || szName[i]>'z'))
				{fValidName = false; break;}

	if (!fValidName)
	{
		MessageBox (hDlg, "Only letters (A-Z, a-z) or numbers (0-9) please", "FuncMaze v1.0.0.2 Keygen", 0);
		SetFocus (GetDlgItem (hDlg, IDC_EDIT_NAME));
		return;
	}
	// uprava Name
	_strupr_s (szName);
	for (i=dwNameLen; i<16; i++)
		szName[i] = szName[(i-dwNameLen) % dwNameLen];
	szName[16] = 0;

	/*
	ESI*4 + 4 == ...

	Postupnost volani:
	S: F64
	U: 66c, 870, 8C0, D64
	C: 990, D98
	C: 150, 418, 5F0, 8A0, FA0
	E: 410, 45C, 538, BF0
	S: 758, F2C
	S: 2C, 6A0, AB0, CFC, D1C, F24
	- dalsich 8 lubovolnych 'neskodnych' volani:
	5A4, 5E0, 74, 1F8, 264, 860, A58, D44, F7C
	- zaverecne 'prepinajuce' volanie:
	C28
	*/
	
	DWORD dwNecessaryTargets[7] = {0xF64 ,0x66C ,0x990 ,0x150 ,0x410 ,0x758 ,0x2C};
	DWORD dwArbitraryTargets[8] = {0x5A4 ,0x5E0 ,0x74 ,0x1F8 ,0x264 ,0x860 ,0xA58 ,0xD44};
	DWORD dw10thTarget = 0xD44;
	DWORD dwTrailingTarget = 0xC28;

	srand (GetTickCount ());
	DWORD dwGoal, dwIdx, dwPart1, dwPart2;
	BOOL bFilledTargets[8] = {FALSE};

	//////////////////////////////////////////////////////////////////////////
	for (i=0; i<16; i++)
	{
		if (i<7)
		{
#ifdef NOT_RANDOMIZE
			dwIdx = i;
			dwGoal = dwNecessaryTargets[dwIdx];
#else
			do {
				dwIdx = rand() % 7;
			} while (bFilledTargets [dwIdx]);
			bFilledTargets [dwIdx] = TRUE;
			dwGoal = dwNecessaryTargets[dwIdx];
#endif
		}
		else if (i<15)
		{
			dwIdx = rand() % 8;
			dwGoal = (i==9) ? dw10thTarget : dwArbitraryTargets[dwIdx];
		}
		else
			dwGoal = dwTrailingTarget;

		dwGoal = (dwGoal - 4) / 4;
		dwGoal = dwGoal % 100;

		if (szName[i] >= '0' && szName[i] <= '9')			// IsNumber (Name[i])
			dwPart1 = 50 + (szName[i] % 10);
		else
			dwPart1 = 50 - (szName[i] % 10);					// IsNotNumber (Name[i])

		bool fHighSerialIsNumber;
		if (dwGoal < dwPart1)
		{
			dwPart2 = dwPart1 - dwGoal;
			fHighSerialIsNumber = false;
		}
		else
		{
			dwPart2 = dwGoal - dwPart1;
			fHighSerialIsNumber = true;
		}

		// urcenie 'Low Serial'
		if (dwPart2 >= 0 && dwPart2 <= 9)			// interval 0..9
			szSerial[i] = (char)dwPart2 + '0';
		else if (dwPart2 >= 10 && dwPart2 <= 35)	// interval A..Z
			szSerial[i] = (char)dwPart2 + '7';
		else if (dwPart2 >= 36 && dwPart2 <= 61)	// interval a..z
			szSerial[i] = (char)dwPart2 + '=';

		// urcenie 'High Serial'
		if (i<7)
			dwGoal = dwNecessaryTargets[dwIdx];
		else if (i<15)
			dwGoal = (i==9) ? dw10thTarget : dwArbitraryTargets[dwIdx];
		else
			dwGoal = dwTrailingTarget;

		dwGoal = (dwGoal - 4) / 4;
		dwGoal = dwGoal / 100;

		if (fHighSerialIsNumber)
			szSerial[i+16] = (char) (dwGoal<8 ? dwGoal + '2' : dwGoal - 8 + '0');
		else
			szSerial[i+16] = 100 + (char)dwGoal;
	}

	//////////////////////////////////////////////////////////////////////////
	szSerial[32] = 0;
	SetDlgItemText (hDlg, IDC_EDIT_SERIAL, szSerial);

	return;

#ifndef _DEBUG		//koniec obsluhy v�nimiek
}__except(EXCEPTION_EXECUTE_HANDLER)
{
	MessageBox (hDlg, "Unspecified error occured", "Error", MB_ICONINFORMATION);
	return;
}
#endif
}
