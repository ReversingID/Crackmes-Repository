﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace dolem_pkgen_keygen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void pbGenerate_Click(object sender, EventArgs e)
        {
            dfSerial.Text = GenerateSN(dfName.Text);
        }

        private void pbExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private string GenerateSN(string name)
        {
            List<string> data = new List<string>
                                    {
                                        "FJJG-NHKK-JJIH-GGGH", 
                                        "CJJG-NEKK-JEIH-HGHH",
                                        "JJJG-NLKK-JJIH-IGIH",
                                        "GJJG-NIKK-JEIH-JGJH",
                                        "DJJG-NFKK-JJIH-AGKH",
                                        "AJJG-NCKK-JEIH-BGBH",
                                        "HJJG-NJKK-JJIH-CGCH",
                                        "EJJG-NGKK-JEIH-DGDH",
                                        "BJJG-NDKK-JJIH-EGEH",
                                        "IJJG-NKKK-JEIH-FGFH"
                                    };

            string serial = "";
            if (name.Length < 1)
            {
                return serial;
            }
            serial = data[Convert.ToChar(name.Substring(0, 1)) % 10];
                        
            return serial;
        }
        
    }
}
