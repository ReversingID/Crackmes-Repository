﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace dolem_cme01_keygen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void pbGenerate_Click(object sender, EventArgs e)
        {
            dfSerial.Text = GenerateSN(dfName.Text);
        }

        private void pbExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private string GenerateSN(string name)
        {
            string serial = "";
            if (name.Length <= 0)
            {
                return serial;
            }
            
            
            string p1 = (CharDec(name.Substring(name.Length - 1, 1))).ToString() + (CharDec(name.Substring(0, 1))*0x2D);
            string h = p1 + ((Convert.ToDouble(p1) * 50) + 970);
            Double i = Convert.ToDouble(h) + ((h.Length*5) - 10);
            string j = i + "19";
            int k = (j.Length - 17);
            if (k.ToString().Length == 1)
            {
                j += " ";
            }
            serial = j + k;

            return serial;
        }

        private int CharDec (string c)
        {
            switch (c)
            {
                case "a":
                    return 0x5A;
                case "b":
                    return 0x2D;
                case  "c":
                    return 0x64;
                case "d":
                    return 0x41;
                case "e":
                    return 0x33;
                case "f":
                    return 0x0A;
                case "g":
                    return 0x7;
                case "h":
                    return 0x3;
                case "i":
                    return 0x1;
                case "j":
                    return 0x4E;
                case "k":
                    return 0x29;
                case "l":
                    return 0x9;
                case "m":
                    return 0x14;
                case "n":
                    return 0x13;
                case "o":
                    return 0x0E;
                case "p":
                    return 0x1F;
                case "q":
                    return 0x45;
                case "r":
                    return 0x63;
                case "s":
                    return 0x78;
                case "t":
                    return 0xC8;
                default:
                    return 0x1F4;
            }
        }
    }
}
