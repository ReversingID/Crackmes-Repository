// Serial.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>

int _tmain(int argc, _TCHAR* argv[])
{

	// 1. Get modified VSN
	DWORD VSN;
	char crap[2][128];
	GetVolumeInformationA("C:\\", crap[0], 0x80, &VSN, 0, 0, crap[1], 0x80);
	VSN=VSN>>16;
	while(VSN>=0x270F) VSN-=0x3E8;
	
	unsigned long numbers[2]; 
	GetSystemTimeAsFileTime((LPFILETIME) numbers);

	numbers[0] += 0x2AC18000;
	numbers[1] += 0x0FE624E21;

	// 2. Get modified TIME
	int TIME;
	__asm {
	mov eax, dword ptr ds:[numbers+4]
	mov ecx, 989680h
	xor edx, edx
	div ecx
	mov ebx, eax
	mov eax, dword ptr ds:[numbers]
	div ecx
	mov edx, ebx
	mov ecx, 0C22E4507h
	mul ecx
	shr edx, 10h
	mov TIME, edx
	}

	unsigned long cipher = TIME*10000 + VSN; // VSN is maximum a 4 decimal digit numbers, and TIME variable usually 5
	cipher = cipher*8;

	// 3. RSA
	/*
	N: FFFFFFFD 
	PRIME FACTOR: 2419
	PRIME FACTOR: 71785
	Public exponent: 13B0ACA5
	Private exponent: 1/13B0ACA5 mod 2418*71784 (FFF8C460) ===== D    (yes, 0xD)
	*/
	unsigned long plaintext;

	/*
	This the is the implementation in C of the code below, I don't use this because 
	We are playing with integers greater than 32 bit
	for(int i=0x0D; i>0; i>>1)
	{
		if(i&1!=0)
		{
			a = a*g % 0xFFFFFFFD;
		}
		
		g = g*g % 0xFFFFFFFD;
	}
	*/
	__asm {
  XOR EAX,EAX
  INC EAX
  MOV EBX,0FFFFFFFDh
  MOV ECX,0Dh
  MOV EDX, cipher
L007:
  TEST ECX,1
  JE L016
  PUSH ECX
  MOV ECX,EDX
  MUL ECX
  DIV EBX
  MOV EAX,EDX
  MOV EDX,ECX
  POP ECX
L016:
  PUSH EAX
  MOV EAX,EDX
  MUL EDX
  DIV EBX
  POP EAX
  OR ECX,ECX
  JE END
  SHR ECX,1
  JMP L007
END:
  mov plaintext, eax
}

	printf("%u\n\r", plaintext);
	return 0;
}

