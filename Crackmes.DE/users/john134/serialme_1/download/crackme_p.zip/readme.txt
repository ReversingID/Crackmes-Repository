rULeS:
1) nO patChIng
2) fInD any SuitabLe Serial NumbEr
3*) Make A keygeN

gooD lucK.

* optioNal