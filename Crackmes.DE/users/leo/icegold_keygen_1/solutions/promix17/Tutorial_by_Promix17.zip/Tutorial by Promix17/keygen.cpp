#include<iostream>
#include <conio.h>
using namespace std;

void main()
{
	char name[64];
	char buffer[64];
	char result[64];
	gets(name);
	for(int i=1; i<strlen(name); i++)
	{
		char c=name[i];
		strcat(result, itoa(c+i, buffer, 10));
	}
	result[10]=0;
	cout << result;
	while(!kbhit());	
}