﻿namespace LEOIceGold_keygen
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbGenerate = new System.Windows.Forms.Button();
            this.pbExit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dfName = new System.Windows.Forms.TextBox();
            this.dfSerial = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // pbGenerate
            // 
            this.pbGenerate.Location = new System.Drawing.Point(101, 64);
            this.pbGenerate.Name = "pbGenerate";
            this.pbGenerate.Size = new System.Drawing.Size(75, 23);
            this.pbGenerate.TabIndex = 1;
            this.pbGenerate.Text = "Generate";
            this.pbGenerate.UseVisualStyleBackColor = true;
            this.pbGenerate.Click += new System.EventHandler(this.pbGenerate_Click);
            // 
            // pbExit
            // 
            this.pbExit.Location = new System.Drawing.Point(182, 64);
            this.pbExit.Name = "pbExit";
            this.pbExit.Size = new System.Drawing.Size(75, 23);
            this.pbExit.TabIndex = 3;
            this.pbExit.Text = "Exit";
            this.pbExit.UseVisualStyleBackColor = true;
            this.pbExit.Click += new System.EventHandler(this.pbExit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Serial:";
            // 
            // dfName
            // 
            this.dfName.Location = new System.Drawing.Point(60, 12);
            this.dfName.Name = "dfName";
            this.dfName.Size = new System.Drawing.Size(198, 20);
            this.dfName.TabIndex = 0;
            // 
            // dfSerial
            // 
            this.dfSerial.Location = new System.Drawing.Point(60, 38);
            this.dfSerial.Name = "dfSerial";
            this.dfSerial.Size = new System.Drawing.Size(198, 20);
            this.dfSerial.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.DarkBlue;
            this.label3.Location = new System.Drawing.Point(12, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "©2011 Zephy";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(265, 97);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dfSerial);
            this.Controls.Add(this.dfName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pbExit);
            this.Controls.Add(this.pbGenerate);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "--=LEO=--  ICEGOLD keygen #1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button pbGenerate;
        private System.Windows.Forms.Button pbExit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox dfName;
        private System.Windows.Forms.TextBox dfSerial;
        private System.Windows.Forms.Label label3;
    }
}

