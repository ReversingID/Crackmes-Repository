﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace LEOIceGold_keygen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pbExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pbGenerate_Click(object sender, EventArgs e)
        {
            dfSerial.Text = GenerateSN(dfName.Text);
        }

        private string GenerateSN(string _name) {
            string _serial="";
            if (_name.Length <= 3 | _name.Length >= 10) {
                MessageBox.Show("Name lenght must be between 4 and 9 characters ");
                return _serial;
            }

            int _index=1;
            while (_index < _name.Length)
            {
                _serial += (_name[_index] + _index);
                _index++;
            }
            _serial = _serial.Substring(0, 10);

            return _serial;
        }
    }
}
