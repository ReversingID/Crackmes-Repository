// KeyGen for errorskeygenme: 
// http://www.crackmes.de/users/bearchik/errors_keygenme/
// (c) Demoth 2012
//////////////////////////////////////////////////////////

#include <stdio.h>
#include <Windows.h> // for sysyem("pause");

static inline void swapDWord(unsigned int *value)
{
	*value = 
		((*value & 0x000000FF) << 24) |
		((*value & 0x0000FF00) <<  8) |
		((*value & 0x00FF0000) >>  8) |
		((*value & 0xFF000000) >> 24);
}

static inline unsigned dwRol(unsigned int a, unsigned int n)
{
    unsigned int t1, t2;
    n = n % (sizeof(a) * 8);   
    t1 = a << n;               
    t2 = a >> (sizeof(a) * 8 - n);
    return t1 | t2;               
}

static inline unsigned dwRor(unsigned int a, unsigned int n)
{
    unsigned int t1, t2;
    n = n % (sizeof(a) * 8);       
    t1 = a >> n;                   
    t2 = a << (sizeof(a) * 8 - n); 
    return t1 | t2;                
}

static void initName(unsigned char *newName, const unsigned char *name)
{
	unsigned char length;
	unsigned int *dwNewName = (unsigned *)newName;

	for (int i = 0; i < 64 + 80*4; ++i) newName[i] = 0;
	for (length = 0; name[length]; ++length)
		newName[length] = name[length];
	
	newName[length] = 0x80;
	newName[63] = length << 3;
	
	for (int i = 0; i < 16; ++i)
		swapDWord(dwNewName + i);

	unsigned int k;
	for (int i = 16; i < 16 + 80; ++i)
	{
		k = dwNewName[i - 3];
		k ^= dwNewName[i - 8];
		k ^= dwNewName[i - 14];
		k ^= dwNewName[i - 16];
		dwNewName[i] = dwRol(k, 1);
	}

}

static unsigned char *genKey(unsigned char *name, unsigned char *key)
{
	unsigned char newName[64 + 80*4];
	unsigned int *dwNewName = (unsigned *)newName;
	initName(newName, name);

	unsigned int resultArr[5] = {0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476, 0xC3D2E1F0};
	unsigned int tempArr[5];
	const unsigned int consts[4] = {0x5A827999, 0x6ED9EBA1, 0x8F1BBCDC, 0x0CA62C1D6};
	unsigned int someValue;
	unsigned int k;
	for (int i = 0; i < 5; ++i) tempArr[i] = resultArr[i];
	for (int i = 0; i < 80; ++i)
	{
		if (i < 20)
		{
			k = tempArr[1] & tempArr[2] | ~tempArr[1] & tempArr[3];
			someValue = consts[0];
		}
		else if (i < 40) 
		{
			k = tempArr[1] ^ tempArr[2] ^ tempArr[3];
			someValue = consts[1];
		}
		else if (i < 60) 
		{
			k = (tempArr[1] & tempArr[2]) | (tempArr[1] & tempArr[3]) | (tempArr[2] & tempArr[3]);
			someValue = consts[2];
		}
		else 
		{
			k = tempArr[1] ^ tempArr[2] ^ tempArr[3];
			someValue = consts[3];
		}

		k += dwRol(tempArr[0], 5);
		k += tempArr[4];
		k += someValue;
		k += dwNewName[i];

		tempArr[4] = tempArr[3];
		tempArr[3] = tempArr[2];
		tempArr[2] = dwRor(tempArr[1], 2);
		tempArr[1] = tempArr[0];
		tempArr[0] = k;
	}
	
	for (int i = 0; i < 5; ++i) 
		resultArr[i] += tempArr[i];

	for (int i = 0; i < 20; ++i)
	{
		unsigned char c = ((unsigned char *)resultArr)[i] & 0x0F;
		key[i] = (c <= 9) ? c + '0' : c - 1 + 'A';
	}
	key[20] = 0;
	return key;
}

int main(int argc, char *argv[])
{
	unsigned char name[56];
	unsigned char key[21];
	printf("Name: ");
	gets((char *)name); //scanf("%55s", name);
	printf("Yours key: %s\n", genKey(name, key));
	system("pause");
	return 0;
}