Time:

5:20 PM 11/24/05

1. To unlock the button and text box you must have to type the correct serial to unlock... :lol:

2. no any patching... :lol:

3. you can't enable the button by patching... :lol:

4. the special thing of this crackme is "You can find it your self because it have many      features"... :lol:

5. Find the correct serial... :lol:

6. After that write how you did it... :lol:

7. the crackmes.dll is nessessary for the program... :lol:



									have a nice day,,,
									Bye
									thank you
