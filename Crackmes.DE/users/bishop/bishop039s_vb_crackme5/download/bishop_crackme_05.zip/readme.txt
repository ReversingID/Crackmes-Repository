BiSHoP's VB Crackme#5

Protection:
Name/Serial/Nag

Your goal:
Finding the serial takes less than 5 seconds but
you have to solve the algo and make a key generator.
And oh yeah, patch the nag.

If you cracked it,
send your solution to diablo337@hotmail.com
and include a tutorial or description on how
you cracked it.  Good luck :)

About...
This is the first crackme coded in VB6 and I compiled
it in Native Code so you can use SmartCheck to debug
it, also I put labels in there to reveal the values
and that makes it 100% crackable using SmartCheck.
All you need is a brain!

Greetz:  LaZaRuS, Dark_Wolf, Falcon, [AC_178], Mercution,
Ac|dFusion, C_DKnight, Dead-Mike, JACKnIRON, SoleSurvivor,
ArKiS, Neo|mAn and everyone in #cracking4newbies and
#cracking.uk on EFNet.

-BiSHoP- BiSHoP_dRE@gmx.net