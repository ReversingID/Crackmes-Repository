//
// a fair remake of BiSHoP's Crackme v4.0 in C by kRio (C) 2004
//

#include <windows.h>

#define MAX_BUFFER 260

HINSTANCE hInstance;

int ascii2hex10(char *number)
{
	int i, hex;

	hex=0;
	for (i=0;i<lstrlen(number);i++)
	{
		if (number[i] >= 0x30)
		{
			if (number[i] <= 0x39)
			{
				hex=hex*10+(number[i]-0x30);
			}
		}
	}

	return hex;
}

LRESULT CALLBACK WndProc(HANDLE hWin, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	HICON hIcon;
	char Buffer[MAX_BUFFER], Serial[MAX_BUFFER], Year[30];
	int i, month, day, year, name_sum, part2, part3;

	switch(uMsg)
	{
	case WM_INITDIALOG:
		hIcon=LoadIcon(hInstance,(char *)100);
		SendMessage(hWin,WM_SETICON,ICON_BIG,(DWORD)hIcon);
		SendMessage(hWin,WM_SETICON,ICON_SMALL,(DWORD)hIcon);
		SendDlgItemMessage(hWin,1,EM_SETLIMITTEXT,30,0);
		SendDlgItemMessage(hWin,2,EM_SETLIMITTEXT,255,0);
		break;
	case WM_COMMAND:
		switch (wParam)
		{
		case 10:
			

			if (GetDlgItemText(hWin,1,Buffer,-1) == 0)
			{
				MessageBeep(0);
				return 0;
			}

			lstrcpy(Serial,"CRK-ME-");

			GetDateFormat(0,0,0,"M",Year,30);
			month=ascii2hex10(Year);

			GetDateFormat(0,0,0,"d",Year,30);
			day=ascii2hex10(Year);

			GetDateFormat(0,0,0,"yyyy",Year,30);
			year=ascii2hex10(Year);

			name_sum=0;
			for (i=0;i<lstrlen(Buffer);i++)
			{
				name_sum+=Buffer[i];
			}

			part2=0;
			for (i=0;i<month;i++)
			{
				part2+=(day*name_sum)+year;
			}

			wsprintf(Buffer,"%u",part2);
			lstrcat(Serial,Buffer);

			for (i=0;i<lstrlen(Buffer);i++)
			{
				Year[lstrlen(Buffer)-i-1]=Buffer[i];
			}

			part3=ascii2hex10(Year);
			part3-=90;

			wsprintf(Buffer,"%u",part3);
			lstrcat(Serial,Buffer);

			GetDateFormat(0,0,0,"yyyy",Year,10);
			lstrcat(Serial,"-");
			lstrcat(Serial,Year);

			if (GetDlgItemText(hWin,2,Buffer,-1) == 0)
			{
				MessageBeep(0);
				return 0;
			}

			if (lstrcmp(Serial,Buffer) == 0)
			{
				MessageBox(hWin,"Good work!\nYou entered the correct code for your name!","Good job!",0);
			}
			else
			{
				MessageBox(hWin,"The code you entered for your name is not valid!\nTry again!","Bad Serial...",MB_ICONERROR);
			}

			break;
		case 11:
			MessageBox(hWin,"kRio's Remake of BiSHoP's VB Crackme#4\nFind the code for your name,\nMake a keygenerator for it\nand send it to me with a tutorial\non how you cracked this crackme.\n-kRio- krio@abv.bg","BiSHoP's VB Crackme#4 *REMAKE*",0);
			break;
		case 12:
			EndDialog(hWin,0);
			break;
		}
		break;
	case WM_CLOSE:
		EndDialog(hWin,-1);
	default:
		return 0;
	}

	return 0;
}

int __stdcall WinMain(HINSTANCE hInst, HINSTANCE hPrevInst, LPSTR lpCommand, int nCommand)
{
	hInstance=hInst;

	DialogBoxParam(hInstance,(char *)1000,0,WndProc,0);
	return 0;
}