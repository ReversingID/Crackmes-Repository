BiSHoP's VB Crackme#2

Protection:
Serial

Your goal:
Make a keygenerator

Send it to diablo337@hotmail.com and tell me
how you cracked.


About...
Another crackme made in VB4.
Similar to my first crackme, but has a different
code generation process (hope it's harder!).
-BiSHoP