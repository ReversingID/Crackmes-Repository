No patching. Only KeyGen is acceptable.

Is this a meaningful CrackMe?

HappyTown
from China
[2oo6-11-o9]