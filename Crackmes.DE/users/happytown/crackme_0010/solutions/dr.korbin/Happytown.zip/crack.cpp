#include <stdio.h>
#include <string.h>
#include "md5.cpp"

typedef unsigned long	DWORD;

DWORD		crc_table[256];

void crc_init()
{
	DWORD CRCPOLY = 0xEDB88320;
	DWORD		t;
	for (int i = 0; i < 256; i++)
	{
		t = i;
		for (int j = 8; j > 0; j--)
		{
			if (t & 1)
				t = (t >> 1) ^ CRCPOLY;
			else
				t >>= 1;
		}
		crc_table[i] = t;
	}
}

DWORD crc_hash(char* s)
{
	DWORD		crc32 = 0xFFFFFFFF;
	for (DWORD i = 0; i < strlen(s); i++)
	{
		crc32 = crc_table[(crc32 ^ (s[i])) & 0xFF] ^ (crc32 >> 8);
	}
	return ~crc32;
}

unsigned char char2int(unsigned char c)
{
	if (c >= '0') if (c <= '9') return c - 48;
	return c - 'a' + 10;
}

int main()
{
	unsigned char	login[400], buf[400], buf2[400];

	printf("Enter login: ");
	gets(login);

	crc_init();
	DWORD		crc = crc_hash(login);
	long		i;
	sprintf(buf, "%08X", crc);
	GetMD5(buf, strlen(buf), buf2);
	//printf("%s\n", buf2);

	DWORD		ch1 = 0, ch2 = 0, ch3 = 0, ch4 = 0;
	DWORD		pass1, pass2, pass3, pass4;
	for (i = 3; i >= 0; i--)
	{
		ch1 <<= 8;
		ch1 |= (char2int(buf2[2 * i]) << 4) | char2int(buf2[2 * i + 1]);
	}
	for (i = 7; i >= 4; i--)
	{
		ch2 <<= 8;
		ch2 |= (char2int(buf2[2 * i]) << 4) | char2int(buf2[2 * i + 1]);
	}
	for (i = 11; i >= 8; i--)
	{
		ch3 <<= 8;
		ch3 |= (char2int(buf2[2 * i]) << 4) | char2int(buf2[2 * i + 1]);
	}
	for (i = 15; i >= 12; i--)
	{
		ch4 <<= 8;
		ch4 |= (char2int(buf2[2 * i]) << 4) | char2int(buf2[2 * i + 1]);
	}

	//printf("%08X %08X %08X %08X\n", ch1, ch2, ch3, ch4);

	DWORD		t1, t2, t3, t4;
	pass1 = ch1 ^ crc;
	pass2 = ch2;
	t1 = pass1 >> 24;
	t2 = pass2 >> 24;
	pass1 = (pass1 << 8) | t2;
	pass2 = (pass2 << 8) | t1;

	t1 = pass1 >> 28;
	t2 = (pass1 >> 24) & 15;
	t3 = (pass1 >> 20) & 15;
	t4 = (pass1 >> 16) & 15;
	pass1 = (pass1 & 0xffff) | (t4 << 28) | (t3 << 24) | (t2 << 20) | (t1 << 16);

	t1 = (pass2 >> 12) & 15;
	t2 = (pass2 >> 8) & 15;
	t3 = (pass2 >> 4) & 15;
	t4 = pass2 & 15;
	pass2 = (pass2 & 0xffff0000) | (t4 << 12) | (t3 << 8) | (t2 << 4) | t1;

	pass1 ^= 0x452821E6;
	pass2 ^= 0x38D01377;

	pass3 = ch3;
	t1 = pass3 & 0xf;
	t2 = (pass3 >> 4) & 0xfff;
	pass3 = (pass3 & 0xffff0000) + (t1 << 12) + t2;
	pass3 ^= 0x37D0D724;

	pass4 = ch4 ^ 0x34E90C6C;

	printf("%08X%08X%08X%08X\n", pass1, pass2, pass3, pass4);
}