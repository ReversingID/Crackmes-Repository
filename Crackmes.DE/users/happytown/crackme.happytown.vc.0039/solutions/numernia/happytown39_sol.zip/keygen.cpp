void __declspec(naked) sub_00401B40()
{
	__asm
	{
		mov	edx, [esp + 4]
		push	esi
		mov	esi, [esp+4+8]
		mov	ecx, 20h
		sub	ecx, esi
		mov	eax, edx
		shr	eax, cl
		mov	ecx, esi
		pop	esi
		shl	edx, cl
		or	eax, edx
		retn
	}
}
void __declspec(naked) sub_00401B60()
{
	__asm
	{
		mov	eax, [esp + 4]
		mov	ecx, [esp + 8]
		mov	edx, [esp + 10h]
		xor	eax, ecx
		mov	ecx, [esp + 0Ch]
		xor	ecx, edx
		or	eax, ecx
		retn
	}
}
void __declspec(naked) sub_00401B80()
{
	__asm
	{

		mov	eax, [esp + 10h]
		mov	ecx, [esp + 8]
		not	eax
		and	eax, ecx
		mov	ecx, [esp + 0Ch]
		not	ecx
		or	eax, ecx
		mov	ecx, [esp + 4]
		or	eax, ecx
		retn
	}
}
void __declspec(naked) sub_00401BA0()
{
	__asm
	{
		mov	eax, [esp + 10h]
		mov	ecx, [esp + 4]
		mov	edx, [esp + 8]
		not	eax
		and	eax, ecx
		mov	ecx, [esp + 0Ch]
		not	ecx
		and	ecx, edx
		xor	eax, ecx
		retn
	}
}
void __declspec(naked) sub_00401BC0()
{
	__asm
	{
		mov	eax, [esp + 4]
		mov	ecx, [esp + 8]
		mov	edx, [esp + 0Ch]
		not	eax
		xor	eax, ecx
		mov	ecx, [esp + 10h]
		not	ecx
		xor	ecx, edx
		or	eax, ecx
		retn
	}
}
 void __declspec(naked) ht_hash()
{
	__asm
	{
        sub     esp, 024h
        mov     eax, dword ptr ss:[esp+02ch]
        push    ebx
        push    ebp
        push    esi
        mov     esi, dword ptr ds:[eax+4]
        mov     ebp, dword ptr ds:[eax+8]
        mov     ebx, dword ptr ds:[eax+0ch]
        push    edi
        mov     edi, dword ptr ds:[eax]
        mov     eax, dword ptr ss:[esp+038h]
        mov     ecx, dword ptr ds:[eax+4]
        mov     edx, dword ptr ds:[eax+8]
        mov     eax, dword ptr ds:[eax+0ch]
        mov     dword ptr ss:[esp+028h], ecx
        mov     dword ptr ss:[esp+030h], eax
        xor     eax, eax
        mov     dword ptr ss:[esp+02ch], edx
        mov     dword ptr ss:[esp+03ch], eax
        jmp     sub_0040188B

sub_00401887:

        mov     eax, dword ptr ss:[esp+03ch]

sub_0040188b:

        mov     ecx, eax
        and     eax, edi
        and     ecx, 018h
        and     eax, 5
        push    ecx
        push    eax
        push    esi
        call    sub_00401B40
        mov     ecx, dword ptr ss:[esp+038h]
        mov     edx, eax
        mov     eax, ebp
        add     edx, edi
        not     eax
        add     eax, ecx
        lea     ecx, dword ptr ds:[esi+edi]
        add     eax, ebx
        push    ebx
        and     eax, ecx
        push    ebp
        xor     edx, eax
        push    esi
        push    edi
        mov     dword ptr ss:[esp+02ch], edx
        call    sub_00401B60
        mov     edx, dword ptr ss:[esp+02ch]
        add     eax, ebp
        or      edx, eax
        mov     eax, dword ptr ss:[esp+04ch]
        add     esp, 018h
        xor     edx, eax
        push    edx
        call    sub_00401B40
        mov     edi, eax
        lea     eax, dword ptr ds:[ebx+ebp]
        add     eax, esi
        xor     edx, edx
        mov     ecx, 5
        add     esp, 8
        lea     eax, dword ptr ds:[eax+edi+032f1e4bh]
        xor     eax, edi
        mov     dword ptr ss:[esp+024h], eax
        lea     eax, dword ptr ds:[edi+2]
        div     ecx
        test    edx, edx
        jbe     sub_00401992
        mov     eax, dword ptr ss:[esp+03ch]
        mov     ecx, ebx
        not     ecx
        add     ecx, dword ptr ss:[esp+024h]
        and     eax, 0ah
        mov     dword ptr ss:[esp+014h], eax
        mov     dword ptr ss:[esp+010h], edx
        add     ecx, edi
        mov     dword ptr ss:[esp+018h], ecx
        lea     ecx, dword ptr ds:[ebx+ebp]
        lea     ecx, dword ptr ds:[ecx+edi+0596807cdh]
        mov     dword ptr ss:[esp+020h], ecx
        jmp     sub_00401934

sub_00401930:

        mov     eax, dword ptr ss:[esp+014h]

sub_00401934:

        mov     edx, dword ptr ss:[esp+03ch]
        push    eax
        and     edx, esi
        and     edx, 013h
        push    edx
        push    ebp
        call    sub_00401B40
        mov     ecx, dword ptr ss:[esp+024h]
        mov     edx, eax
        lea     eax, dword ptr ds:[esi+ebp]
        add     edx, esi
        and     eax, ecx
        push    ebx
        push    ebp
        xor     edx, eax
        push    esi
        push    edi
        mov     dword ptr ss:[esp+038h], edx
        call    sub_00401B80
        mov     ecx, dword ptr ss:[esp+038h]
        mov     esi, dword ptr ss:[esp+044h]
        add     eax, ebx
        add     esp, 018h
        or      ecx, eax
        xor     ecx, esi
        push    ecx
        call    sub_00401B40
        mov     edx, dword ptr ss:[esp+028h]
        mov     esi, eax
        mov     eax, dword ptr ss:[esp+018h]
        add     esp, 8
        add     edx, esi
        dec     eax
        mov     dword ptr ss:[esp+028h], edx
        mov     dword ptr ss:[esp+010h], eax
        jnz     sub_00401930

sub_00401992:

        lea     eax, dword ptr ds:[esi+3]
        xor     edx, edx
        mov     ecx, 7
        div     ecx
        test    edx, edx
        jbe     sub_00401A2F
        mov     eax, dword ptr ss:[esp+03ch]
        mov     ecx, edi
        not     ecx
        add     ecx, dword ptr ss:[esp+028h]
        and     eax, 0bh
        mov     dword ptr ss:[esp+020h], eax
        mov     dword ptr ss:[esp+010h], edx
        add     ecx, esi
        mov     dword ptr ss:[esp+01ch], ecx
        jmp     sub_004019C9

sub_004019c5:

        mov     eax, dword ptr ss:[esp+020h]

sub_004019c9:

        mov     edx, dword ptr ss:[esp+03ch]
        push    eax
        and     edx, ebp
        and     edx, 0dh
        push    edx
        push    ebx
        call    sub_00401B40
        mov     ecx, dword ptr ss:[esp+028h]
        mov     edx, eax
        lea     eax, dword ptr ds:[ebx+ebp]
        add     edx, ebp
        and     ecx, eax
        push    ebx
        push    ebp
        xor     edx, ecx
        push    esi
        push    edi
        mov     dword ptr ss:[esp+034h], edx
        call    sub_00401BA0
        mov     edx, dword ptr ss:[esp+034h]
        add     eax, edi
        or      edx, eax
        mov     eax, dword ptr ss:[esp+040h]
        add     esp, 018h
        xor     edx, eax
        push    edx
        call    sub_00401B40
        mov     ecx, dword ptr ss:[esp+018h]
        mov     ebp, eax
        add     esp, 8
        lea     eax, dword ptr ds:[ebx+ebp]
        add     eax, esi
        dec     ecx
        mov     dword ptr ss:[esp+010h], ecx
        lea     eax, dword ptr ds:[eax+edi+0de6f723ah]
        mov     dword ptr ss:[esp+02ch], eax
        jnz     sub_004019C5
        jmp     sub_00401A33

sub_00401a2f:

        mov     eax, dword ptr ss:[esp+02ch]

sub_00401a33:

        lea     ecx, dword ptr ss:[ebp-4]
        and     ecx, 7
        mov     dword ptr ss:[esp+020h], ecx
        jbe     sub_00401AD0
        mov     ecx, dword ptr ss:[esp+03ch]
        mov     edx, esi
        not     edx
        add     edx, eax
        mov     eax, dword ptr ss:[esp+020h]
        and     ecx, 3
        add     edx, ebp
        mov     dword ptr ss:[esp+01ch], ecx
        mov     dword ptr ss:[esp+018h], edx
        mov     dword ptr ss:[esp+010h], eax
        jmp     sub_00401A68

sub_00401a64:

        mov     ecx, dword ptr ss:[esp+01ch]

sub_00401a68:

        push    ecx
        mov     ecx, dword ptr ss:[esp+040h]
        and     ecx, ebx
        and     ecx, 8
        push    ecx
        push    edi
        call    sub_00401B40
        mov     ecx, dword ptr ss:[esp+024h]
        mov     edx, eax
        lea     eax, dword ptr ds:[ebx+edi]
        add     edx, ebx
        and     eax, ecx
        push    ebx
        push    ebp
        xor     edx, eax
        push    esi
        push    edi
        mov     dword ptr ss:[esp+03ch], edx
        call    sub_00401BC0
        mov     ecx, dword ptr ss:[esp+03ch]
        add     eax, esi
        or      ecx, eax
        mov     eax, dword ptr ss:[esp+048h]
        add     esp, 018h
        xor     ecx, eax
        push    ecx
        call    sub_00401B40
        mov     ebx, eax
        add     esp, 8
        lea     edx, dword ptr ds:[ebx+ebp]
        add     edx, esi
        lea     eax, dword ptr ds:[edx+edi+0a18945bch]
        mov     dword ptr ss:[esp+030h], eax
        mov     eax, dword ptr ss:[esp+010h]
        dec     eax
        mov     dword ptr ss:[esp+010h], eax
        jnz     sub_00401A64
        mov     eax, dword ptr ss:[esp+02ch]

sub_00401ad0:

        mov     ecx, dword ptr ss:[esp+030h]
        mov     edx, dword ptr ss:[esp+028h]
        add     ecx, eax
        add     ecx, edx
        lea     edx, dword ptr ds:[eax+ecx]
        mov     eax, dword ptr ss:[esp+028h]
        add     eax, edx
        mov     edx, dword ptr ss:[esp+030h]
        add     edx, eax
        mov     dword ptr ss:[esp+028h], eax
        add     edx, ecx
        mov     dword ptr ss:[esp+02ch], edx
        add     edx, eax
        mov     eax, dword ptr ss:[esp+03ch]
        add     edx, ecx
        inc     eax
        mov     dword ptr ss:[esp+030h], edx
        cmp     eax, 0fh
        mov     dword ptr ss:[esp+03ch], eax
        jl      sub_00401887
        mov     eax, dword ptr ss:[esp+038h]
        mov     edx, dword ptr ss:[esp+02ch]
        pop     edi
        pop     esi
        mov     dword ptr ds:[eax], ecx
        mov     ecx, dword ptr ss:[esp+020h]
        mov     dword ptr ds:[eax+4], ecx
        mov     ecx, dword ptr ss:[esp+028h]
        mov     dword ptr ds:[eax+8], edx
        mov     dword ptr ds:[eax+0ch], ecx
        pop     ebp
        mov     eax, 1
        pop     ebx
        add     esp, 024h
        retn
	}
}
void Generate(HWND hWnd)
{
	EN_BigInt g,p,y,q,x,k,m,r,s;

	unsigned long hash_cons[4] = {0x23016745, 0xAB89EFCD, 0x9832BA01, 0x76DCFE54};
	char name[16]={0}, tmpsz[50];
	
	int len = GetDlgItemText(hWnd,IDC_EDIT2,name,16);
	if(len < 1 || len > 16){
		return;}

	char parameters[5][50] =  {"3FAF265328715370501B09597543BAF1B42455D283DEC78B",  // g
							   "C9C794FF125DC1CA546E797E9486F62D78D83A8E2A6D8D4B",  // p
							   "6EDD84F08B6C308F5727EEC13F5D87AC03D3FB7476654D2F",  // y
							   "D96F7B8483E94DC1F6291AB7395B",					    // q (p-1) largest factor
							   "B63623165D76854BE9896F2B3"};						// x
	__asm
	{
		lea eax, name
		push eax
		lea eax, hash_cons
		push eax
		call ht_hash
	}
	unsigned char *tmp = (unsigned char*)hash_cons;
	for (int i = 0; i < 10; i++){
		wsprintf(tmpsz+i*2,"%02X",tmp[i]);}

	g = EN_BigNew(0);
	p = EN_BigNew(0);
	y = EN_BigNew(0);
	q = EN_BigNew(0);
	x = EN_BigNew(0);
	k = EN_BigNew(0);
	r = EN_BigNew(0);
	s = EN_BigNew(0);
	m = EN_BigNew(0);

	EN_BigIn(parameters[0],g);
	EN_BigIn(parameters[1],p);
	EN_BigIn(parameters[2],y);
	EN_BigIn(parameters[3],q);
	EN_BigIn(parameters[4],x);

	EN_Rand(100,k);
	EN_BigIn(tmpsz,m);

	// Calculate (g^k (mod p) mod q) = r
	EN_PowMod(g,k,p,r);
	EN_Mod(r,q,r);

	// Calculate (x*r + H(m))
	EN_Mul(x,r,s);
	EN_Add(s,m,s);

	// Calculate (k^-1 * (x*r + H(m))) (mod q)
	EN_Inverse(k,q,k);
	EN_Mul(k,s,s);
	EN_Mod(s,q,s);

	// Finish the last step, actually part of the vertification
	EN_Inverse(s,q,s);

	EN_BigOut(r,tmpsz);
	SetDlgItemText(hWnd,IDC_EDIT1,tmpsz);

	EN_BigOut(s,tmpsz);
	SetDlgItemText(hWnd,IDC_EDIT3,tmpsz);

	// Clear up memory
	EN_BigKill(g);
	EN_BigKill(p);
	EN_BigKill(y);
	EN_BigKill(q);
	EN_BigKill(x);
	EN_BigKill(k);
	EN_BigKill(r);
	EN_BigKill(s);
}