Hi, this is my another crypto CrackMe(KeyGenMe). Just to find the right way to solve it.
As usual, ONLY KeyGen is acceptable.

HappyTown[from China]
wxr277@163.com