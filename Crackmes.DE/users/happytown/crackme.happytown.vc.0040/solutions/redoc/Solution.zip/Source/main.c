#undef UNICODE
#undef _UNICODE
#include <windows.h>
#include "./MIRACL/miracl.h"

#define APP_NAME		"HappyTown's CrackMe.0040 Keygen"
#define CRACKME_NAME	"Coded by [HappyTown]"

//----------------------------------------
BOOL APIENTRY DllMain (HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
	return TRUE;
}
//----------------------------------------
void Test (HWND hKeygenDlg)
{
	HWND hCrackmeDlg, hDlgItem;
	char szBuf[512]={0};

	hCrackmeDlg = FindWindow (NULL, CRACKME_NAME);
	if (hCrackmeDlg == 0)
	{
		if (32 < (int)ShellExecute (NULL, NULL, "CrackMe_0040.exe", NULL, NULL, SW_SHOW))
			Sleep (250);
		hCrackmeDlg = FindWindow (NULL, CRACKME_NAME);
	}
	if (hCrackmeDlg == 0)
		{MessageBox (hKeygenDlg, "Please start CrackMe_0040.exe first\r\nor place keygen to same folder as crackme.", APP_NAME, 0); return;}

	hDlgItem = GetDlgItem (hKeygenDlg, 1005);
	SendMessage (hDlgItem, WM_GETTEXT, sizeof(szBuf), (LPARAM)szBuf);
	hDlgItem = GetDlgItem (hCrackmeDlg, 1005);
	SendMessage (hDlgItem, WM_SETTEXT, 0, (LPARAM)szBuf);

	hDlgItem = GetDlgItem (hKeygenDlg, 1006);
	SendMessage (hDlgItem, WM_GETTEXT, sizeof(szBuf), (LPARAM)szBuf);
	hDlgItem = GetDlgItem (hCrackmeDlg, 1006);
	SendMessage (hDlgItem, WM_SETTEXT, 0, (LPARAM)szBuf);

	hDlgItem = GetDlgItem (hKeygenDlg, 1007);
	SendMessage (hDlgItem, WM_GETTEXT, sizeof(szBuf), (LPARAM)szBuf);
	hDlgItem = GetDlgItem (hCrackmeDlg, 1007);
	SendMessage (hDlgItem, WM_SETTEXT, 0, (LPARAM)szBuf);

	if (hDlgItem = GetDlgItem (hCrackmeDlg, 1008))
		PostMessage (hCrackmeDlg, WM_COMMAND, 1008, (LPARAM)hDlgItem);
}
//----------------------------------------
BOOL GetSerial (unsigned char hash_value[16])
{
	miracl *mip;
	big C, D, N;
	HWND hDlg, hDlgItem;
	char szSerial[512]={0};

	hDlg = FindWindow (0, APP_NAME);
	if (hDlg == 0) return FALSE;
	hDlgItem = GetDlgItem (hDlg, 1006);
	SendMessage (hDlgItem, WM_SETTEXT, 0, (LPARAM)"10001");	// set Magic string

	mip = mirsys (0x500, 0x10);		// Initialize MIRACL library
	if (mip == 0) return FALSE;
	C = mirvar(0); D = mirvar(0); N = mirvar(0);
	mip->IOBASE = 16;

	cinstr (D, "10001");	// private exponent
	cinstr (N, "6F907AAA920DAF37AD19DD6974540903FBC772FE38F314F4B058076B097911FEA8E7BE75254BDB6536F96C1A2F5BDB8C69EF81C61E369837F3B9CBC188BDCFB9");	// modulus
	bytes_to_big (16, (char*)hash_value, C);
	powmod (C, D, N, C);				// C = pow(C,D) mod N
	cotstr (C, szSerial);
	mirexit ();

	hDlgItem = GetDlgItem (hDlg, 1007);
	SendMessage (hDlgItem, WM_SETTEXT, 0, (LPARAM)szSerial);	// output serial

	// want to test it?
	if (IDYES == MessageBox (hDlg, "Done. Want to test the serial?", APP_NAME, MB_YESNO))
		Test (hDlg);

	return TRUE;
}
//----------------------------------------
__declspec(dllexport) BOOL ComputeSerial (unsigned char hash_value[16])
{
	BOOL bRet = GetSerial (hash_value);
	if (!bRet)
		MessageBox (0, "Error occured", APP_NAME, 0);
	return bRet;
}