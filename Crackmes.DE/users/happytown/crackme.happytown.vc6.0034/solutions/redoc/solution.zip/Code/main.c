#undef UNICODE
#undef _UNICODE
#include <windows.h>
#include "./MIRACL/miracl.h"

#define APP_NAME		"HappyTown's CrackMe_0034 Keygen"
#define CRACKME_NAME	"Coded by HappyTown                     [2006-11-19]"
// proto
int base64_encode(unsigned char *source, size_t sourcelen, char *target, size_t targetlen);

//----------------------------------------
BOOL APIENTRY DllMain (HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
	return TRUE;
}
//----------------------------------------
void Test (HWND hKeygenDlg)
{
	HWND hCrackmeDlg, hDlgItem;
	char szBuf[512]={0};

	hCrackmeDlg = FindWindow (NULL, CRACKME_NAME);
	if (hCrackmeDlg == 0)
	{
		if (32 < (int)ShellExecute (NULL, NULL, "CrackMe.HappyTown.VC6.0034.exe", NULL, NULL, SW_SHOW))
			Sleep (250);
		hCrackmeDlg = FindWindow (NULL, CRACKME_NAME);
	}
	if (hCrackmeDlg == 0)
		{MessageBox (hKeygenDlg, "Please start CrackMe.HappyTown.VC6.0034.exe first\r\nor place keygen to same folder as crackme.", APP_NAME, 0); return;}

	hDlgItem = GetDlgItem (hKeygenDlg, 1001);
	SendMessage (hDlgItem, WM_GETTEXT, sizeof(szBuf), (LPARAM)szBuf);
	hDlgItem = GetDlgItem (hCrackmeDlg, 1001);
	SendMessage (hDlgItem, WM_SETTEXT, 0, (LPARAM)szBuf);

	hDlgItem = GetDlgItem (hKeygenDlg, 1003);
	SendMessage (hDlgItem, WM_GETTEXT, sizeof(szBuf), (LPARAM)szBuf);
	hDlgItem = GetDlgItem (hCrackmeDlg, 1003);
	SendMessage (hDlgItem, WM_SETTEXT, 0, (LPARAM)szBuf);

	hDlgItem = GetDlgItem (hKeygenDlg, 1002);
	SendMessage (hDlgItem, WM_GETTEXT, sizeof(szBuf), (LPARAM)szBuf);
	hDlgItem = GetDlgItem (hCrackmeDlg, 1002);
	SendMessage (hDlgItem, WM_SETTEXT, 0, (LPARAM)szBuf);

	if (hDlgItem = GetDlgItem (hCrackmeDlg, 1))
		PostMessage (hCrackmeDlg, WM_COMMAND, 1, (LPARAM)hDlgItem);
}
//----------------------------------------
BOOL GetSerial (unsigned char final_hash[16])
{
	miracl *mip;
	big C, D, N;
	HWND hDlg, hDlgItem;
	int intGroupLen;
	char szBuf[512]={0}, szSerial[512]={0};

	hDlg = FindWindow (0, APP_NAME);
	if (hDlg == 0) return FALSE;
	hDlgItem = GetDlgItem (hDlg, 1003);
	intGroupLen = SendMessage (hDlgItem, WM_GETTEXT, sizeof(szBuf), (LPARAM)szBuf);

	mip = mirsys (0x500, 0x10);		// Initialize MIRACL library
	if (mip == 0) return FALSE;
	C = mirvar(0); D = mirvar(0); N = mirvar(0);
	mip->IOBASE = 16;

	cinstr (D, "7C3E3E86EAB1C67C288D6B4E01CD7C11196B29622F848985");	// private exponent
	cinstr (N, "886A71F603197C430E9C473BB6991BE95B45AB519F57ADB9");	// modulus
	bytes_to_big (16, (char*)final_hash, C);
	powmod (C, D, N, C);				// C = pow(C,D) mod N
	cotstr (C, &szBuf[intGroupLen]);	// second part of serial
	mirexit ();

	// now convert it to base64
	if (!base64_encode (szBuf, lstrlen(szBuf), szSerial, sizeof(szSerial)))
		return FALSE;

	hDlgItem = GetDlgItem (hDlg, 1002);
	SendMessage (hDlgItem, WM_SETTEXT, 0, (LPARAM)szSerial);	// output serial

	// want to test it?
	if (IDYES == MessageBox (hDlg, "Done. Want to test the serial?", APP_NAME, MB_YESNO))
		Test (hDlg);

	return TRUE;
}
//----------------------------------------
__declspec(dllexport) BOOL ComputeSerial (unsigned char final_hash[16])
{
	BOOL bRet = GetSerial (final_hash);
	if (!bRet)
		MessageBox (0, "Error occured", APP_NAME, 0);
	return bRet;
}