CrackMe #1 (C++)
----------------
by NBS

Description
========================================================================================
Difficulty:             -1/10 (This crackme is mainly for people who see assembly for
                               the first time, or dont have ANY experience with reverse
                               engineering. In this crackme there is one VERY stupid
                               thing that shouldnot be there. Youll see.)
Packed:                 Of course no
Anti-debug:             nope
Beginner-friendly:      Yes, VERY
========================================================================================

Goal: Make the program to become registered by ANY way. You dont have to write a keygen,
for obvious reasons.


I hope you will like this, althrough of its difficulty.

More crackmes will be coming, harder, and, without the integrated "feature" - that will
be your task.

NBS 2004