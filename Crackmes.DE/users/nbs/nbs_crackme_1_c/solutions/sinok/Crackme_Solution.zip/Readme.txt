crackme.htm -> 1280x1024
crackme.exe -> fit to your screen


Video by Sinok