Not really my first KeygenMe ever.

Rules:
No patching! A stand-alone Keygen is the only valid solution!

I hope you like it. :)