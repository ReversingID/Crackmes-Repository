#include <Python.h>
#include "panama.h"

static PyObject *panamaError;

static PyObject *
panama_hash(PyObject *self, PyObject *args)
{
	char *output;
	PyObject *value;
	char *test;
	unsigned int length;
	PyBytesObject	*input;
	
	if (!PyArg_ParseTuple(args, "Si", &input, &length))
		return NULL;
	Py_INCREF(input);
	output = PyMem_Malloc(32);
	test = (char *)PyBytes_AsString((PyObject*) input);
	panama(output, test, length);
	Py_DECREF(input);
	value = Py_BuildValue("y#", output, 32);
	PyMem_Free(output);
	
	return value;
}

static PyMethodDef panamaMethods[] = {
	{ "hash", panama_hash, METH_VARARGS, "Compute hash from input." },
	{ NULL, NULL, 0, NULL }
};

#if PY_MAJOR_VERSION >= 3

static struct PyModuleDef panamaModule = {
	PyModuleDef_HEAD_INIT,
	"panama",
	"...",
	-1,
	panamaMethods
};

PyMODINIT_FUNC
PyInit_panama(void)
{
	PyObject *m;
	
	m = PyModule_Create(&panamaModule);
	if (m == NULL)
		return NULL;
		
	panamaError = PyErr_NewException("panama.error", NULL, NULL);
	Py_INCREF(panamaError);
	PyModule_AddObject(m, "error", panamaError);
	return m;
}

#else
PyMODINIT_FUNC
initpanama(void)
{
	(void)Py_InitModule("panama", panamaMethods);
}
#endif
