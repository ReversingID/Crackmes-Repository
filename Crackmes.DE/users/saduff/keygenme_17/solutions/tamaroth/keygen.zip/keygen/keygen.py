# The crackme has been written in Delphi. It's routines can be either blackboxed, which is rather tedious, or recognised using signatures, which deals with majority of problems with the crackme.
# There's no magic in the crackme, it employs PANAMA as a hash function and Paillier system to check whether the entered data is correct.
# The algorithm used is the same as decrypting with Paillier but it's using its digital signature scheme. The difference is that with signatures s2 cannot be random and instead must be computed.
#
# All the necessary data and information about the scheme can be found in the original paper that is available at:
# http://www.cs.tau.ac.il/~fiat/crypt07/papers/Pai99pai.pdf
#
# Knowing the scheme, it's trivial to implement a keygen. The only problem was a lack of PANAMA hashing function as a module in Python, so I've included sources to its implementation (requires Python 3.x, won't work with earlier ones)
#
# Overall an OK keygenme!
# sample keys:
# tamaroth
# 204b6fbccfb4c0e661f82f43092e1ff1-e330def4e96844bcaf2df9c91927c2b4-6ffdc756494f6e5b75ecd2be46ab1eba-db115e5e84c7c9b83aa27353b27e25ca
#
# crackmes.de
# 44cd56e2acf5b805754457807a55de4b-f16d35494ac7937022b564735665bafe-4cb16de404867191627aea2469eb886c-391804080950ea9b883991af28fde797
#
# Saduff
# 9033796a853193bba09b5f1f665b5deb-999904e0be91e45482a0780df25e8ed4-7a813e4f378b0c5bb0404068a4b07f5b-9bea77ed9457747bb5f3c43108a8c499

import sys, gmpy2, panama, binascii

def compute(name):
	n2 = gmpy2.mpz("0x5A2CA7F4E6CDF2CA496DD866139F04CDEC8EBA61C3C3187152FB2A1093BFC15A0ECC07A62089CC7CBBB9064EE6207FAC3875FC94277F3FF9BDFC1E555D799D19")
	g = gmpy2.mpz("0x9C0928664535BA873094A7EDA0F4E831BE92E00B895171E99CA67CA0A7B5534C301371E79EB85B4DA250B77A4495A7523ACB0BAD2BEA6129B")
	n = gmpy2.mpz("0x97EFB4FC28B5B6FD5F99D7116164B5839932A076D1FE8D0863BBD02981F7BC85")
	l = gmpy2.mpz("0x25FBED3F0A2D6DBF57E675C458592D6081A396234C6C956E2047CB29A9AC7C98")
	
	hname = binascii.hexlify(panama.hash(bytes(name, 'UTF-8'), len(name))).decode('utf-8')
	h = gmpy2.mpz("0x" + binascii.hexlify(panama.hash(bytes(name, 'UTF-8'), len(name))).decode('utf-8'))
	
	x = gmpy2.c_div((gmpy2.powmod(h, l, n2)-1), n)
	y = gmpy2.c_div((gmpy2.powmod(g, l, n2)-1), n)
	s1 = (x * gmpy2.invert(y, n)) % n
	x = gmpy2.powmod(gmpy2.invert(g, n), s1, n)
	s2 = gmpy2.powmod(h * x, gmpy2.invert(n, l), n)

	return (hex(s1)[2:34] + "-" + hex(s1)[34:] + "-" + hex(s2)[2:34] + "-" + hex(s2)[34:])

if __name__ == "__main__":
	if (len(sys.argv) < 2):
		print("Usage:\n\tkeygen.py <name>")
	else:
		print(compute(sys.argv[1]))
		
