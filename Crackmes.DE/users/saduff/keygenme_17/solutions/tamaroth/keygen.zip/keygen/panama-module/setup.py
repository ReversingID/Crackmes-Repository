from distutils.core import setup, Extension

panama_module = Extension('panama',
    sources = ['panamamodule.c', 'panama.c'],
              include_dirs=['.'])

setup (name = 'panama',
       version = '1.0',
       description = 'Bindings for PANAMA hash',
       ext_modules = [panama_module])
