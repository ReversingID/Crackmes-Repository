#include <stdio.h>
#include <string.h>
#include <math.h>

#define A 247*162
#define B 54*834
#define calcY(x) (834*x - a2)/162

typedef struct QESpair {
	double x1;
	double x2;
} QESpair;

QESpair solveQE(double a, double b, double c){
	QESpair qsp;
	double numerator;
	qsp.x1 = 0;
	qsp.x2 = 0;
	numerator = sqrt( (b*b - (4*a*c)) );

	if(!a) {
		printf("error, denominator is equal 0, division by zero error");
		return qsp;
	}
	qsp.x1 = (-b + numerator) / (2*a);
	qsp.x2 = (-b - numerator) / (2*a);
	return qsp;
}

void findAndReplace(char *string, char find, char replace){
	int len = strlen(string);
	int i;
	for (i=0; i<len; i++)	{
		if(string[i] == find)
			string[i] = replace;
	}
	return;
}

int GetSum(char *name){
	int sum;
	int len = strlen(name);
	int i;

	sum = 0;
	for(i=0; i<len; i++){
		sum += name[i];
	}
	return sum;
}

int reverseInt(int input){
	int revVal;

	revVal = 0;
	while(input){
		revVal *= 10;
		revVal += input%10;
		input  /= 10;
	}
	return revVal;
}

int main(){
	QESpair	qspp;
	int		a1,a2;
	char	serial[50];
	char	name[255];
	int		namelen;
	int		repeat;

	repeat = 1;
	printf("type 'exit' as a name to quit...\n");
	while(repeat){
		printf("name: ");
		gets(name);
		namelen = strlen(name);
		if (namelen >= 255){
			printf("errorneous name\n");
			repeat = 0;
			continue;
		}
		if(name[0] == 'e' && name[1] == 'x' && name[2] == 'i' && name[3] == 't' && name[4] == 0){
			printf("bye bye!\n");
			repeat = 0;
			continue;
		}

		a1 = GetSum(name);
		a2 = reverseInt(a1);

		qspp = solveQE(A, B, 0 - 54*a2 - 162*a1);
		sprintf(serial, "%f*%f*%f*%f", qspp.x1, calcY(qspp.x1), qspp.x2, calcY(qspp.x2));
		findAndReplace(serial, '.', 'P');
		findAndReplace(serial, '-', 'N');
		findAndReplace(serial, '*', '-');
		printf("serial: %s\n", serial);
	}

	return 0;
}


