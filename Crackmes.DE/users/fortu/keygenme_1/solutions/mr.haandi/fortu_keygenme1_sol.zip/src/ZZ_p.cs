﻿using System;
using System.Collections.Generic;
using System.Text;

class ZZ_p
{
    public static BigInteger modulus;
    public BigInteger rep;
    public static void init(BigInteger modulus)
    {
        ZZ_p.modulus = modulus;
    }
    public ZZ_p()
    {
        this.rep = 0;
    }
    public ZZ_p(BigInteger op1)
    {
        this.rep = op1;
    }
    public ZZ_p(String op1, int op2)
    {
        this.rep = new BigInteger(op1, op2);
    }
    public ZZ_p(byte[] op1, int op2)
    {
        this.rep = new BigInteger(op1, op2);
    }
    public static implicit operator ZZ_p(long value)
    {
        return (new ZZ_p(value));
    }

    public static implicit operator ZZ_p(ulong value)
    {
        return (new ZZ_p(value));
    }

    public static implicit operator ZZ_p(int value)
    {
        return (new ZZ_p((long)value));
    }

    public static implicit operator ZZ_p(uint value)
    {
        return (new ZZ_p((ulong)value));
    }
    public static implicit operator ZZ_p(BigInteger value)
    {
        return (new ZZ_p((BigInteger)value));
    }
    public static ZZ_p operator +(ZZ_p op1, ZZ_p op2)
    {
        ZZ_p rop = new ZZ_p();
        add(rop, op1, op2);
        return rop;
    }
    public static void add(ZZ_p rop, ZZ_p op1, ZZ_p op2)
    {
        rop.rep = (op1.rep + op2.rep);
        if (rop.rep >= ZZ_p.modulus) rop.rep -= ZZ_p.modulus;
    }
    public static ZZ_p operator -(ZZ_p op1, ZZ_p op2)
    {
        ZZ_p rop = new ZZ_p();
        sub(rop, op1, op2);
        return rop;
    }
    public static void sub(ZZ_p rop, ZZ_p op1, ZZ_p op2)
    {
        if (op1.rep < op2.rep) rop.rep = (ZZ_p.modulus + op1.rep - op2.rep);
        else rop.rep = op1.rep - op2.rep;
    }
    public static ZZ_p operator *(ZZ_p op1, ZZ_p op2)
    {
        ZZ_p rop = new ZZ_p();
        mul(rop, op1, op2);
        return rop;
    }
    public static void mul(ZZ_p rop, ZZ_p op1, ZZ_p op2)
    {
        rop.rep = (op1.rep * op2.rep) % ZZ_p.modulus;
    }
    public static ZZ_p operator /(ZZ_p op1, ZZ_p op2)
    {
        ZZ_p rop = new ZZ_p();
        div(rop, op1, op2);
        return rop;
    }
    public static void div(ZZ_p rop, ZZ_p op1, ZZ_p op2)
    {
        rop.rep = (op1.rep * op2.rep.modInverse(ZZ_p.modulus)) % ZZ_p.modulus;
    }
    public static ZZ_p operator ^(ZZ_p op1, ZZ_p op2)
    {
        ZZ_p rop = new ZZ_p();
        pow(rop, op1, op2);
        return rop;
    }
    public static void pow(ZZ_p rop, ZZ_p op1, ZZ_p op2)
    {
        rop.rep = op1.rep.modPow(op2.rep, ZZ_p.modulus);
    }
    public static Int32 legendre(ZZ_p op1)
    {
        if (op1.rep == 0) return 0;
        if ((op1 ^ ((ZZ_p.modulus - 1) / 2)).rep == 1) return 1;
        else return -1;
    }
    public ZZ_p getgenerator()
    {
        List<ZZ_p> factors=new List<ZZ_p>();
        BigInteger n = ZZ_p.modulus - 1;
        while (n % 2 == 0)
        {
            factors.Add(2);
            n /= 2;
        }
        factors.Add(n);
        Random rnd = new Random();
        bool isgenerator = true;
        BigInteger r = new BigInteger();
        do
        {
            r.genRandomBits(150, rnd);
            isgenerator = true;
            foreach (ZZ_p f in factors)
            {
                if (((new ZZ_p(r)) ^ ((ZZ_p.modulus - 1) / f.rep)).rep == 1) isgenerator = false;
            }
        } while (isgenerator == false);
        return r;
    }
    public ZZ_p discretelog(ZZ_p x)
    {
        ZZ_p t = 1;
        for (int i = 0; i != 0x7FFFFFFF; i++)
            if (t.rep == x.rep) return i;
            else t *= this;
        throw new System.Exception("no discrete logarithm found!");
    }
    public static ZZ_p sqrt(ZZ_p op1)
    {
        if (ZZ_p.legendre(op1) == 1)
        {
            ZZ_p h = (ZZ_p.modulus - 1) / 2;
            while (h.rep % 2 == 0)
                h.rep /= 2;
            ZZ_p z = h;
            ZZ_p x = ((1 + z) / 2);
            ZZ_p v = op1 ^ x;
            ZZ_p g = op1.getgenerator();
            ZZ_p sh = op1 ^ h;
            ZZ_p g2 = g ^ (h * 2);
            ZZ_p t = g2.discretelog(sh);
            ZZ_p test = g2 ^ t;
            ZZ_p root = v / (g ^ (z * t));
            return root;
        }
        else
        {
            throw new System.Exception("sqrt does not exists!");
        }
    }
}
