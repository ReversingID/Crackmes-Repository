﻿namespace keygen
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rbMethod1 = new System.Windows.Forms.RadioButton();
            this.rbMethod2 = new System.Windows.Forms.RadioButton();
            this.btnAction = new System.Windows.Forms.Button();
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.txtSignature = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // rbMethod1
            // 
            this.rbMethod1.AutoSize = true;
            this.rbMethod1.Checked = true;
            this.rbMethod1.Location = new System.Drawing.Point(286, 41);
            this.rbMethod1.Name = "rbMethod1";
            this.rbMethod1.Size = new System.Drawing.Size(70, 17);
            this.rbMethod1.TabIndex = 0;
            this.rbMethod1.TabStop = true;
            this.rbMethod1.Text = "Method 1";
            this.rbMethod1.UseVisualStyleBackColor = true;
            // 
            // rbMethod2
            // 
            this.rbMethod2.AutoSize = true;
            this.rbMethod2.Location = new System.Drawing.Point(362, 41);
            this.rbMethod2.Name = "rbMethod2";
            this.rbMethod2.Size = new System.Drawing.Size(70, 17);
            this.rbMethod2.TabIndex = 1;
            this.rbMethod2.Text = "Method 2";
            this.rbMethod2.UseVisualStyleBackColor = true;
            // 
            // btnAction
            // 
            this.btnAction.Location = new System.Drawing.Point(438, 38);
            this.btnAction.Name = "btnAction";
            this.btnAction.Size = new System.Drawing.Size(75, 23);
            this.btnAction.TabIndex = 2;
            this.btnAction.Text = "Action";
            this.btnAction.UseVisualStyleBackColor = true;
            this.btnAction.Click += new System.EventHandler(this.btnAction_Click);
            // 
            // txtMessage
            // 
            this.txtMessage.Location = new System.Drawing.Point(74, 12);
            this.txtMessage.MaxLength = 19;
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.Size = new System.Drawing.Size(439, 20);
            this.txtMessage.TabIndex = 3;
            this.txtMessage.Text = "t0tally pwn3d";
            // 
            // txtSignature
            // 
            this.txtSignature.Location = new System.Drawing.Point(74, 67);
            this.txtSignature.Name = "txtSignature";
            this.txtSignature.Size = new System.Drawing.Size(439, 20);
            this.txtSignature.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Message:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Signature:";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(521, 95);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtSignature);
            this.Controls.Add(this.txtMessage);
            this.Controls.Add(this.btnAction);
            this.Controls.Add(this.rbMethod2);
            this.Controls.Add(this.rbMethod1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmMain";
            this.Text = "fortu\'s KeyGenMe keygen";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton rbMethod1;
        private System.Windows.Forms.RadioButton rbMethod2;
        private System.Windows.Forms.Button btnAction;
        private System.Windows.Forms.TextBox txtMessage;
        private System.Windows.Forms.TextBox txtSignature;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

