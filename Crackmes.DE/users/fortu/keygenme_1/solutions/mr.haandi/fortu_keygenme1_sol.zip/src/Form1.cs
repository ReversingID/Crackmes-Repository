﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace keygen
{

    public partial class frmMain : Form
    {
        [DllImport("user32.dll")]
        public static extern int FindWindow(string c, string t);
        [DllImport("user32.dll")]
        public static extern bool EnumChildWindows(int h, MulticastDelegate c, int p);
        [DllImport("User32.dll")]
        public static extern int SendMessage(int h, int m, int w, string s);

        public delegate bool CallbackDelegate(int h,int p);
        private Random rnd = new Random();
        public frmMain()
        {
            
            InitializeComponent();
        }

        private void btnAction_Click(object sender, EventArgs e)
        {
            if (txtMessage.Text == "") return;
            Byte[] Message=new Byte[19];
            Encoding.ASCII.GetBytes(txtMessage.Text.ToCharArray(), 0, txtMessage.Text.Length, Message, 0);
            ZZ_p.init(new BigInteger("45671926166590716193865151022382929832958822497", 10));
            ZZ_p result = new ZZ_p(Message, 19);
            ZZ_p s2=new ZZ_p(),s1=new ZZ_p();
            ZZ_p c1 = new ZZ_p("62CD44CA51958460CDCB6ECBD1FAB7D77C6BD1A", 16);
            ZZ_p c2 = new ZZ_p("23821E6F4BC329ADE499EAA8D07AFFD98283B92", 16);
            if (rbMethod1.Checked)
            {
                s2 = new ZZ_p(rnd.Next(3, 2147483647));
                s1 = (result * (s2 * s2 - 3 * s2 + 2) - (((2 * c1 - c2) * s2 * s2) + (c2 - 4 * c1) * s2)) / 2;
            }
            else
            {
                Boolean SolutionFound = false;
                while (SolutionFound==false)
                {
                    try
                    {
                        s1 = new ZZ_p(rnd.Next(3, 2147483647));
                        ZZ_p c3 = 0 - (2 * c1 - c2) / result;
                        ZZ_p c4 = 0 - (c2 - 4 * c1) / result;
                        ZZ_p c5 = 0 - (2 * s1) / result;
                        ZZ_p P = (c4 - 3) / (1 + c3);
                        ZZ_p Q = (2 + c5) / (1 + c3);
                        s2 = 0 - (P / 2) + ZZ_p.sqrt(((P / 2) ^ 2) - Q);
                        SolutionFound = true;
                    }
                    catch (Exception Ex)
                    {
                        if (Ex.Message == "sqrt does not exists!") continue;
                    }
                }
            }
            String Alphabet = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            BigInteger part1=s2.rep, part2=s1.rep;
            txtSignature.Text="";
            for (int i = 0; i != 30; i++)
            {
                if ((i % 6 == 0) && (i!=0)) txtSignature.Text = "-" + txtSignature.Text;
                txtSignature.Text = Alphabet[(part2 % 36).IntValue()] + txtSignature.Text;
                part2 /= 36;
            }
            
            for (int i = 0; i != 6; i++)
            {
                if (i % 6 == 0) txtSignature.Text = "-" + txtSignature.Text;
                txtSignature.Text = Alphabet[(part1 % 36).IntValue()] + txtSignature.Text;
                part1 /= 36;
            }
            while (part1 != 0)
            {
                txtSignature.Text = Alphabet[(part1 % 36).IntValue()] + txtSignature.Text;
                part1 /= 36;
            }
            int hwnd=FindWindow("TForm1","KeyGenMe v1.0");
            CallbackDelegate del = new CallbackDelegate(Callback);
            callbacknumber = 5;
            EnumChildWindows(hwnd, del, 0);

        }
        int callbacknumber;
        private bool Callback(int h,int p)
        {
            SendMessage(h, 0x000C, 0, txtSignature.Text.Split('-')[callbacknumber--]);
            if (callbacknumber<0) return false;
            else return true;
        }
    }
}
