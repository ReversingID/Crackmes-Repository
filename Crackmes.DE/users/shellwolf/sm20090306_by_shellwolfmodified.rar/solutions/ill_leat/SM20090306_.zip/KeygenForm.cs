﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SM20090306key
{
    public partial class KeygenForm : Form
    {
        private static int[] mask = new int[] { 6, 6, 4, 5, 2, 4, 0, 3, 1, 1, 2, 3, 0, 2, 1, 0, 2, 2, 0, 1, 1, 3, 0, 5, 1, 7, 2, 5, 0, 4, 1, 2, 0, 0, 2, 1, 3, 3, 1, 4, 0, 6, 1, 8, 2, 6, 0, 7, 1, 5, 2, 7, 0, 8, 1, 6, 2, 8, 3, 6, 4, 4, 6, 3, 7, 1, 5, 0, 3, 1, 4, 3, 6, 4, 5, 2, 6, 0, 4, 1, 2, 0, 3, 2, 4, 0, 6, 1, 4, 2, 3, 0, 5, 1, 7, 0, 6, 2, 5, 4, 3, 5, 4, 7, 5, 5, 3, 4, 5, 3, 6, 5, 5, 7, 3, 8, 4, 6, 5, 8, 3, 7, 5, 6, 4, 8, 6, 7, 7, 5 };
        private static int even;
        private static int odd;
        public KeygenForm()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text.Length > 3)
            {
                calcVals();
                textBox2.Text = getSerial();
            }
            else
            {
                textBox2.Text = "";
            }
        }
        private void calcVals()
        {
            string name = textBox1.Text;
            int temp = 0;
            for (int i = 0; i < name.Length; i++)
            {
                temp = temp * 131;
                temp = temp + name[i];
            }

            even = temp & 7;
            odd = (temp >> 8) & 7;
        }
        private string getSerial()
        {
            int size = mask.Length/2;
            int temp;
            string str = "";

            for (int i = 0; i < size; i++)
            {
                temp = mask[2 * i] + even;
                if (temp > 16)
                    return "";
                str += (mask[2 * i] + even).ToString("X");
                temp = mask[2 * i + 1] + even;
                if (temp > 16)
                    return "";
                str += (mask[2 * i + 1] + odd).ToString("X");
            }

            return str;
        }

    }
}
