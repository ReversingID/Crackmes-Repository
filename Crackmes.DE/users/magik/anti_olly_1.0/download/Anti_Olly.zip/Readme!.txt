
use 7-Zip to extract the crackme :

http://www.7-zip.org/