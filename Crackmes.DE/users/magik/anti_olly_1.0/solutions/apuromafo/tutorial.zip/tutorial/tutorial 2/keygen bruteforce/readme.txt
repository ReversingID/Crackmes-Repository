how use the keygen for not do the pc slow..






for use this must be an inteligent men

now put an leng of 4 numbers or letters in serial~

when is done that


now go to name..

and when finished that write an 0 in the serial ...for evitate...errors 

or bruteforcing that do slow your pc

other trik can write better write
4 letters
and you see the first code

this works whit bruteforcing.

example 

if code is 0
this go to increase to 1,,post check ..2..3...4...5..etc..to serial ..

this find the 1rst serial correct.

but can be used for find serial for some lengs diferents or other numers

how do this?


now write the correct number

and was fully naged whit serials corrects..

are as 100 or more..not was write because are many..
alt+ctr+supr and kill the process that was creating many serials..

for that is better that use this with an olly

ok?
well is all



if was 0 enter was as 2 min? in this pc for create the number..

if was an error..was the olly that not was fixed good..well..but all can see in olly too


bruteforcing+nag? was created by apuromafo and code bruteforcing was created by
GUAN DE DIO [cracklatinos]

but if wana optimized, MUST CHANGE SOME PLACES
00479170            MOV EAX,DWORD PTR SS:[EBP-28]  this change the place and a 0000000 zone..
this is good but some days can be slow..because need many space and do exeptions littles..
for the bruteforce..


//////general///

use name~any
pass:a
post use this

any
pass:aa

and when is "aaaa"
see the correct serial..was bruteforced

wen use now that serial in the bruteforce..
you see the others corrects keys
kill the program for exit when are in this..because you was see all..all!..


only do this with the olly~exit the olly and was exited with this:)






