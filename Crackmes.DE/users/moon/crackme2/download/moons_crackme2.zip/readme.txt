Hi,

This is my second CrackMe, the first was realy easy, but good for newbiews ;)!

So this CrackMe is not so easy, I think it's nearly imposible to solve it, so good luck!

Oh i nearly forgot the rulez:
Do what ever you want to find the password (I think there is only one ;)

Now good luck, you'll need it!

Greetz to all hackers and crackers in this world!

moon