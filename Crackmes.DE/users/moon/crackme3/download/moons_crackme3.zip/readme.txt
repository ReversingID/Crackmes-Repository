Hi,

this is my third CrackMe, it is a bit more difficult than my first one, but it's posible (not as my second one h3h3).

It's again written in Delphi, but not packed this time so can start cracking just now =).

This CrackMe has 4 Levels:

1) Nag
Just remove the Nag!

2) CD-Check
Patch the Proggy that it tells u the CD-Check was succesfull!

3) Password
In this level u have 3 jobs:
3.1) Make the Button to check the Password enabled (very easy)
3.2) Patch the Proggy that it shoes the entered Numbers (!) not these fucking "*"!
3.2) Find the Password to get in Level 4

4) Name/Serial
Now "only" 2 jobs:
4.1) Enable the button
4.2) Create a keygen

If u should have any problems or questions with the CrackMe u can ask me: 
moon.86@gmx.de or ICQ#171206015

Ok, now u know what to do, have fun with that CrackMe!

Greetz to all crackers in this world!

moon.