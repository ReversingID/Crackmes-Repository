moon's KGme #1
~~~~~~~~~~~~~~

Hi there,

This is my first CrackMe, so don't expect too much!!

The rulez:
1) Don't patch
2) Create a KeyGen or find out a serial
3) Send ur solution to moon.86@gmx.de

Have fun ^^