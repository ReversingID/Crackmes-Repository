Keygen this and submit your solution to crackmes.de

Have phun...

- kiTo / SCA
- http://sca.crk.se (for swedish crackers :)
- kito.leet <A T> gmail.com