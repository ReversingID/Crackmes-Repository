
    Greetings Cracker!

    Here is my 1st CrackMe!  I have been a Cracking fan for years now
    but had never considered protection code until recently.  I am an
    Assembler programmer of about 8 years now and in an attempt to
    prove that Dos still lives I have come up with a CrackMe I think
    will puzzle even some of the better Crackers out there!

    The protection is for a Serial number, the level is a tough call
    since I am new but I would think it is not for Newbies, unless
    I am out of touch with todays quality programmers and Crackers
    alike!

    a word of caution, SOFT-ICE, TURBO-DEBUG, and DEBUG all caused my
    system to hang during Tracing!!!!

    I will accept the proper Serial number, a Patch I suppose but with
    a working knowledge of the code, and I have left the Brute force
    option available but that would defeat the purpose of these
    CrackMes..

    Happy Cracking!

      __
      (�!�)  AsSemBLur!
       ���

