#include <stdio.h>
#include <string.h>

int main(){

unsigned char Name[15]={0};
unsigned char Code[15]={0};
unsigned char tmp[2]={0};
unsigned int s1,s2,i;

printf("Please enter your name: ");
gets(Name);
if(strlen(Name) < 4){
printf("/nAt least 4 characters please");
return 0;
}
s1=0;
s2=0;
for(i=0;i<strlen(Name);i++){
s2+=Name[i];
s1=(Name[i] ^ 0x9) % 0xa;
Code[i]=s1 + 0x30;
}
strcat(Code,"-");
s2 &= 0xff;
s2 = (s2 % 0x1a) + 0x61;
sprintf(tmp,"%c",s2);
strcat(Code,tmp);
printf("%s",Code);

return 0;
}