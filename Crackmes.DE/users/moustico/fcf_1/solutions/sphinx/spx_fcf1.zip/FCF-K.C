/*** French Cracking Force CrackMe v1 Keygen *******************************/

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

void main()
{
 char Name[18];
 int i,al,ah;

 puts("\nFCF CrackMe v1 Keygen by Sphinx [05/30/2001]\n");

 Name[0] = 17;
 printf("Enter your name: ");
 cgets(Name);
 if (Name[1] < 4) {
    printf("\nError: Name should be >= 4 characters.\n");
    exit(0);
 }

 printf("\nRegistration no: ");

 for (i=2; i < Name[1]+2; i++) {
  al = Name[i];
  if (al==0x20) Name[i] = Name[i+1];
 }

 for (i=2; i < Name[1]+2; i++) {
  al = (Name[i] ^ 0x09);
  ah = (al % 0x0A) + 0x30;
  putch(ah);
 }

 printf("-");
 al = 0;
 for (i=2; i < Name[1]+2; i++)
 al += Name[i];
 ah = ((al & 0xFF) % 0x1A) + 0x61;
 putch(ah);
 puts("");
}
