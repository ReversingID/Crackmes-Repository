#include <windows.h>
#include <stdio.h>

int main()
{
	char			Name[256] = "Lightning";
	char			Serial[256];
	long			NameLen;
	long			Counter;
	long			Counter2;
	unsigned char	Val;

	printf("Keygen for Moustico's FCF #1\n");
	printf("Name: ");

	scanf("%[^\n\0]s", Name);

	NameLen = strlen(Name);
	if(NameLen < 4)
	{
		printf("\nName too short");
	}
	else
	{
		//setup the name correctly
		for(Counter = 0; Counter < NameLen; Counter++)
		{
			//found a space, set the space to the next char in the name
			if(Name[Counter] == 0x20)
			{
				for(Counter2 = Counter+1; Counter2 < NameLen; Counter2++)
				{
					if((Name[Counter2] != 0x20) && (Name[Counter2] != 0x00))
						break;
				}

				//make sure we found a char
				if(Counter2 == NameLen)
					break;

				//set the space to the char found
				Name[Counter] = Name[Counter2];
			}
		}

		//make sure we got to the end of the name
		if(Counter != NameLen)
		{
			printf("\nSpaces at end of name not allowed");
		}
		else
		{
			//create a serial
			Val = 0x00;
			for(Counter = 0; Counter < NameLen; Counter++)
			{
				Serial[Counter] = ((Name[Counter] ^ 9) % 0x0A) + 0x30;
				Val = Val + Name[Counter];
			}

			//get the last char to add on
			Val = (Val % 0x1A) + 0x61;

			//update the serial and print it out
			Serial[Counter] = 0x2D;
			Serial[Counter+1] = Val;
			Serial[Counter+2] = 0x00;

			printf("\nSerial: %s", Serial);
		}
	}

	printf("\n\nCtrl+C to close");
	while(1)
		Counter++;

	return 0;
}