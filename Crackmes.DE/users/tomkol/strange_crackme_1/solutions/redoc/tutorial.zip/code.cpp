
#undef UNICODE
#undef _UNICODE
#include <windows.h>

DWORD Hash1 (char *szString);
DWORD BruteHash2Proc (DWORD dwFinalValue);

//--------------------------------
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	#define USERNAME	"redoC"
	#define COMPANY	"Big Company Inc."

	DWORD dwRet = Hash1 (USERNAME COMPANY);
	dwRet = BruteHash2Proc (dwRet);
	// dwRet => write to file strange.key (in byte reverse order)
	return (0);
}

//--------------------------------
DWORD Hash1 (char *szString)
{
	if (szString == NULL) return (0);

	char szBuf[128]={0};
	lstrcpy (szBuf, szString);
	DWORD dwLen = lstrlen(szBuf);
	DWORD i, dwIdx, dwEBX = 0, dwHash = 0;

	dwIdx = dwLen;
	for (i=0; i<dwLen; i++, dwIdx--)
	{
		dwHash &= 0xFFFFFF00;
		dwHash |= szString[i];
		__asm {
			mov cl, byte ptr [dwIdx]
			rol dword ptr [dwHash], cl
		}
		dwEBX += dwHash;
	}

	__asm{
		LEA EAX, dword ptr [szBuf]
		MOV ECX, dword ptr [dwLen]
		MOV EBX, dword ptr [dwEBX]
loop_adr:
		MOV EDX,DWORD PTR DS:[EAX]
		XOR EDX,EBX
		BSWAP EDX
		XCHG DH,DL
		XOR DX,BX
		RCR EDX,CL
		ADD EDX,EBX
		XOR EDX,EBX
		RCR EDX,CL
		XOR EDX, 0xEBDEAD12
		ROL EDX, 0x16
		SUB EDX,EBX
		INC EAX
		LOOP loop_adr

		MOV dword ptr [dwHash], EDX
	}
	return (dwHash);
}

//--------------------------------
DWORD BruteHash2Proc (DWORD dwFinalValue)
{
	DWORD dwHash = 0, dwFileData = 0;
	char szDate[16]={0};
	SYSTEMTIME systime;

	GetLocalTime (&systime);
	wsprintf (szDate, "%02u-%02u-%u", systime.wDay, systime.wMonth, systime.wYear);

	for (dwFileData=0; (dwFileData<0xFFFFFFFF) && (dwHash != dwFinalValue); dwFileData++)
	{
		__asm{
			MOV EAX, dword ptr [dwFileData]
			MOV ECX, 0x0000000C	// cycle counter
			MOV EBX, EAX
			MOV EDX, 0xB2A916C4
			LEA ESI, dword ptr [szDate]

loop_adr:
			BSWAP EBX
			XOR EAX,EBX
			ADD AX,BX
			XOR AH,BL
			XOR AL,BH
			XCHG AX,BX
			BSWAP EBX
			ROL EBX,CL
			ADD EAX,EBX
			RCL EAX, 0x10
			SUB EAX,EBX
			BSWAP EBX
			XOR AX,WORD PTR DS:[ESI+3]		// month
			RCR EAX,CL
			XOR EBX,EDX		// 0xB2A916C4
			SUB EAX,EDX		// 0xB2A916C4
			ROR EBX, 0x0C
			ROR EAX,CL
			ADD EAX,EBX
			XOR EAX,EDX		// 0xB2A916C4
			SUB EBX,EDX		// 0xB2A916C4
			XCHG AX,BX
			BSWAP EBX
			ADD EBX,DWORD PTR DS:[ESI+6]	// year
			RCR EBX,CL
			XOR EAX,EBX
			SUB AX,WORD PTR DS:[ESI]		// day
			ADD AL,CL
			SUB AH,CL
			ROR EAX,CL
			ADD EAX,EDX		// 0xB2A916C4
			XOR EAX,EBX
			RCL EBX,CL
			ADD EAX,EBX
			XOR EAX,EBX
			LOOP loop_adr

				MOV dword ptr [dwHash], EAX
		}
	}

	if (dwHash == dwFinalValue)
		return (dwFileData - 1);

	return (0);
}
