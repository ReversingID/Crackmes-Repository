#include "stdafx.h"


__int64 addmod(__int64 a, __int64 b, __int64 n)
{
	__uint64 r;
	if(!a) return b%n;
	if(!b) return a%n;
	if(n<0) return -1; 

	if(a<0) a+=n;
	if(b<0) b+=n;

	r = (__uint64)a+(__uint64)b;
	r = r%n;
	return (__int64)r;
}

__int64 mulmod(__int64 a, __int64 b, __int64 n)
{
	__int64 r;
	if(!n) return -1;

	a %= n;
	b %= n;
	if (!b||!a) return 0;
	if (a<0) a += n;
	if (b<0) b += n;

	r = 0;

	while(b)
	{
		if(b&1) r = addmod(r,a,n);
		b>>=1;
		a = addmod(a,a,n);
	}
	return r;
}

__int64 powmod(__int64 b, __int64 p, __int64 n)
{
	__int64 val;
	if(!n) return -1;
	p = p % n;
	if(p==0) return 1;
	if(p<0) p += n-1;

	val = 1;

	while(p)
	{
		if(p&1) val = mulmod(val,b,n);
		p = p>>1;
		b = mulmod(b,b,n);
	}
	return val;
}
