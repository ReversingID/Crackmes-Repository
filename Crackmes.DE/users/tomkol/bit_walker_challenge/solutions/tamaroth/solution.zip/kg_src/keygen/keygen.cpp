// keygen.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "keygen.h"

#define NAME "tamaroth"
#define ROL32(x,b) (x << b) | (x >> (32 - b))
#define ROR32(x,b) (x >> b) | (x << (32 - b))

INT_PTR CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
BOOL	CALLBACK	EnumWindowsProc(HWND, LPARAM);

// globals
DWORD (*g_Functions[16])(register DWORD value);
DWORD	g_dwNameHash[3];
DWORD	g_dwMagicValues[3];
BYTE	g_RotAmount;
ATOM	g_name,g_serial;
CHAR	g_lpName[0xFF];
HWND	g_hWnd, g_hDlg;

const BYTE g_inv_sbox[] = {
	0x53, 0x02, 0x15, 0x6E, 0x74, 0xA7, 0x5A, 0xDC, 0x0F, 0x61, 0x25, 0xA0, 0x85, 0x3B, 0x2A, 0xA1,
	0xA9, 0x67, 0xCD, 0xE0, 0x34, 0xFC, 0xE9, 0xC0, 0xE1, 0x94, 0xC6, 0x7C, 0x8F, 0x31, 0xF9, 0x49,
	0xBC, 0x29, 0xA5, 0x87, 0xAB, 0x0E, 0xAA, 0x8A, 0x5D, 0x70, 0xB0, 0x2D, 0x44, 0xD3, 0x98, 0xD6,
	0x4A, 0xCE, 0x93, 0xB9, 0x45, 0x9D, 0x5B, 0xDD, 0x1D, 0xF2, 0x8E, 0xE5, 0x9C, 0xEF, 0x28, 0xCF,
	0x21, 0x58, 0x7A, 0x97, 0x3D, 0x35, 0x32, 0xBF, 0xA4, 0xCC, 0x81, 0xDE, 0x24, 0x66, 0xDA, 0xF3,
	0x76, 0xA3, 0xC1, 0xEA, 0xC7, 0x82, 0xEC, 0x38, 0x6A, 0x57, 0x88, 0x07, 0xA6, 0x63, 0x68, 0xC3,
	0xBD, 0xC9, 0xD0, 0xB5, 0x9A, 0x1F, 0xB7, 0x5E, 0x55, 0xD4, 0x47, 0xFE, 0xB4, 0x03, 0x48, 0xE6,
	0x04, 0xB8, 0x2C, 0xF8, 0x41, 0x86, 0x4C, 0xAC, 0x5C, 0x8C, 0x13, 0x7D, 0x23, 0xBA, 0xCA, 0x64,
	0xF0, 0xBB, 0xC2, 0x96, 0x00, 0x3C, 0xD1, 0xFF, 0x52, 0xDF, 0x20, 0x14, 0xB1, 0x91, 0x7F, 0xF6,
	0xAD, 0xEB, 0x7B, 0x72, 0x1A, 0xAF, 0xF4, 0x95, 0x54, 0x12, 0x73, 0x0B, 0xCB, 0x0A, 0x11, 0x80,
	0x26, 0x83, 0x51, 0x16, 0x36, 0xD8, 0xB6, 0x06, 0x08, 0x2B, 0x79, 0xD2, 0xEE, 0x19, 0x17, 0xE2,
	0x56, 0x89, 0xFB, 0x05, 0xA2, 0x60, 0x0D, 0xA8, 0x2E, 0x1E, 0x59, 0x2F, 0x43, 0x6D, 0x84, 0x10,
	0xD5, 0x71, 0x90, 0x18, 0x65, 0xE4, 0xFD, 0xC4, 0x0C, 0x39, 0x75, 0x22, 0x9B, 0x77, 0x4D, 0x4F,
	0x01, 0x1B, 0x8B, 0x69, 0xD9, 0x4B, 0x3A, 0x7E, 0x37, 0x30, 0xE8, 0x3E, 0x6C, 0xDB, 0xF5, 0x1C,
	0xE3, 0x9F, 0x9E, 0xC5, 0x33, 0xED, 0x5F, 0x40, 0xBE, 0x09, 0xC8, 0xAE, 0x46, 0x27, 0xB2, 0x4E,
	0xE7, 0x6F, 0x6B, 0x50, 0xF7, 0x78, 0x3F, 0x8D, 0x92, 0xD7, 0x62, 0xF1, 0xB3, 0x99, 0xFA, 0x42
};


DWORD sub_m1(DWORD value)
{
	return value - g_dwMagicValues[0];
}
DWORD sub_m2(DWORD value)
{
	return value - g_dwMagicValues[1];
}
DWORD sub_m3(DWORD value)
{
	return value - g_dwMagicValues[2];
}
DWORD xor_m1(DWORD value)
{
	return value ^ g_dwMagicValues[0];
}
DWORD xor_m2(DWORD value)
{
	return value ^ g_dwMagicValues[1];
}
DWORD xor_m3(DWORD value)
{
	return value ^ g_dwMagicValues[2];
}
DWORD bswap(DWORD value)
{
	return (value & 0x000000ff) << 24 | (value & 0x0000ff00) << 8 | (value & 0x00ff0000) >> 8 | (value & 0xff000000) >> 24;
}
DWORD not(DWORD value){
	return ~value;
}
DWORD neg(DWORD value)
{
	return ~value + 1;
}
DWORD byte_repl_rev(DWORD value)
{
	DWORD result = 0;
	value = ROR32(value, 8);
	result |= g_inv_sbox[value & 0xFF];
	result |= (g_inv_sbox[(value & 0xFF00) >> 8]) << 8;
	result |= (g_inv_sbox[(value & 0xFF0000) >> 16]) << 16;
	result |= (g_inv_sbox[(value & 0xFF000000) >> 24]) << 24;
	return result;
}
DWORD rol(DWORD value)
{
	return (value << g_RotAmount) | (value >> (32 - g_RotAmount));
}
DWORD ror(DWORD value)
{
	return (value >> g_RotAmount) | (value << (32 - g_RotAmount));
}
DWORD reverse(DWORD x)
{
	x = (((x & 0xaaaaaaaa) >> 1) | ((x & 0x55555555) << 1));
	x = (((x & 0xcccccccc) >> 2) | ((x & 0x33333333) << 2));
	x = (((x & 0xf0f0f0f0) >> 4) | ((x & 0x0f0f0f0f) << 4));
	x = (((x & 0xff00ff00) >> 8) | ((x & 0x00ff00ff) << 8));
	return((x >> 16) | (x << 16));
}
UINT64 xordecode(UINT64 x)
{
	UINT64 result = x & 0x8000000000000000LL;
	register UINT64 bit_curr,bit_left,bit_res;
	for (int i = 0; i < 63; i++) {
		bit_curr = x & (1LL << i);
		bit_left = (x & (1LL << (i + 1))) >> 1;
		bit_res = bit_curr ^ bit_left;
		result |= bit_res;
	}
	return result;
}
DWORD negs_m1(DWORD value)
{
	return value - neg(g_dwMagicValues[0]);
}
DWORD negs_m2(DWORD value)
{
	return value - neg(g_dwMagicValues[1]);
}
DWORD negs_m3(DWORD value)
{
	return value - neg(g_dwMagicValues[2]);
}
UINT64 revert(UINT64 value)
{
	UINT64 high_bit = (value & 0x8000000000000000LL) >> 63;
	value = (value << 1) | high_bit;
	UINT64 mask = ((value & 4) >> 2) ^ ((value & 0x2000) >> 13) ^ ((value & 0x80000000) >> 31);
	return ((value ^ (mask << 32)));
}

DWORD (*g_origRevFunctions[16])(DWORD value) = {
	sub_m1,
	negs_m2,
	xor_m3,
	bswap,
	negs_m3,
	xor_m1,
	sub_m2,
	neg,
	xor_m2,
	sub_m3,
	negs_m1,
	not,
	byte_repl_rev,
	ror,
	reverse,
	rol
};
void SetupVM(char *name, size_t len)
{
	DWORD sum = 0;
	while (len--)
	{
		sum += name[len];
	}

	// copy first part
	DWORD last = sum & 0x0F;
	DWORD first = (0x10 - last);
	memcpy(g_Functions, &g_origRevFunctions[last], first * sizeof(DWORD));
	// copy second part
	if (last)
	{
		memcpy(&g_Functions[first], g_origRevFunctions, last * sizeof(DWORD));
	}
}
void HashName(char *name, size_t len)
{
	DWORD part = 0;
	DWORD part2;
	size_t i = 0;
	while (i < len)
	{
		part += name[i];
		__asm { rol part, 3 }
		part ^= name[i];
		__asm { rol part, 5 }
		part += (BYTE)(~name[i]);
		i++;
	}
	g_dwNameHash[0] = part;
	g_dwNameHash[1] = part2 = ~part;

	i = 0;
	// part2 = eax
	// part  = edx
	__asm {
		mov		ecx, 10h
			mov		eax, part2
			mov		edx, part
			xor		ebx, ebx

_start:
		shl		eax, 1
			rcl		ebx, 1
			shr		edx, 1
			rcl		ebx, 1
			loop	_start
			mov		part, ebx
	}
	g_dwNameHash[2] = part;
	return;
}

DWORD WINAPI GenerateSerialThread( LPVOID lParam )
{
	DWORD loops;
	DWORD serial_val[3];
	UINT64 value;
	// setup
	g_name = GlobalAddAtom(g_lpName);
	HashName(g_lpName, strlen(g_lpName));
	SetupVM(g_lpName, strlen(g_lpName));

	// compute inversion modulo
	serial_val[0] = (DWORD)powmod(g_dwNameHash[0], 4294967277, 4294967279);
	serial_val[1] = (DWORD)powmod(g_dwNameHash[1], 4294967277, 4294967279);
	serial_val[2] = (DWORD)powmod(g_dwNameHash[2], 4294967277, 4294967279);

	// first loop
	loops = (g_dwNameHash[1] ^ g_dwNameHash[2]) & 0x3FFFFF;
	value = *(UINT64 *)&serial_val[0];
	do 
	{
		value = revert(value);
	} while (--loops);
	*(UINT64 *)&serial_val[0] = value;

	// second loop
	loops = (g_dwNameHash[0] ^ g_dwNameHash[2]) & 0x3FFFFF;

	value = *(UINT64 *)&serial_val[1];
	do 
	{
		value = revert(value);
	} while (--loops);

	//first xor
	loops =(g_dwNameHash[1] ^ g_dwNameHash[2]) & 0x3FFFFF;
	while (loops--)
	{
		value = xordecode(value);
	}
	*(UINT64 *)&serial_val[1] = value;

	// second xor
	loops = (g_dwNameHash[0] ^ g_dwNameHash[2]) & 0x3FFFFF;
	value = *(UINT64 *)&serial_val[0];
	while (loops--)
	{
		value = xordecode(value);
	}
	*(UINT64 *)&serial_val[0] = value;

	for (int i = 0; i < 3; i++)
	{
		BYTE *nHash = (BYTE *)g_dwNameHash;
		for (int j = 11; j >= 0; j--)
		{
			g_RotAmount =(BYTE) (nHash[j] % 32);
			serial_val[i] = g_Functions[nHash[j] & 0x0F](serial_val[i]);
			serial_val[i] = g_Functions[nHash[j] >> 4](serial_val[i]);
		}
	}
	char serial_str[0xFF];
	wsprintfA(serial_str, "%08X#%08X#%08X",serial_val[0], serial_val[1], serial_val[2]);
	g_serial = GlobalAddAtom(serial_str);
	PostMessage(g_hWnd, 0x401, (WPARAM)g_serial, (LPARAM)g_name);
	PostMessage(g_hWnd, WM_COMMAND, 0x0B, NULL);
	return 0;
}

int APIENTRY _tWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPTSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);
	UNREFERENCED_PARAMETER(nCmdShow);
	// find a window
	g_hWnd = 0;
	DialogBox(hInstance, MAKEINTRESOURCE(IDD_ABOUTBOX), NULL, WndProc);
	return 0;
}

BOOL CALLBACK EnumWindowsProc(HWND hWnd, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	char wndtext[256];
	int length = GetWindowText(hWnd, wndtext, 256);
	if (length < 5)
		return TRUE;
	CharUpperBuff(wndtext, (DWORD)length);

	if (!strcmp(wndtext, "BIT WALKER CHALLENGE BY TOMKOL [C4U]"))
	{
		g_hWnd = hWnd;
		return FALSE;
	}
	return TRUE;
}

INT_PTR CALLBACK WndProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UINT_PTR pTimer;
	HANDLE hThread;
	char wndtext[256];
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		EnumWindows(EnumWindowsProc, NULL);
		if (g_hWnd != 0) // window was found
		{
			SendDlgItemMessage(g_hWnd, 0x0E, WM_GETTEXT, 256, (LPARAM)wndtext);
			SendDlgItemMessage(hDlg, IDC_EDIT2, WM_SETTEXT, NULL, (LPARAM)wndtext);
			if (sscanf_s(wndtext,"%X-%X-%X", &g_dwMagicValues[0], &g_dwMagicValues[1], &g_dwMagicValues[2]) != 3)
			{
				SetDlgItemText(hDlg, IDC_EDIT2, "Couldn't locate magic value!");
			}
		} else {
			SetDlgItemText(hDlg, IDC_EDIT2, "Couldn't locate tomkol's keygenme!");
		}
		pTimer = SetTimer(hDlg, 0x10, 80, NULL);
		return (INT_PTR)TRUE;

	case WM_TIMER:
		{
			g_hWnd = 0;
			EnumWindows(EnumWindowsProc, NULL);
			if (g_hWnd != 0)
			{
				SendDlgItemMessage(g_hWnd, 0x0E, WM_GETTEXT, 256, (LPARAM)wndtext);
				if (sscanf_s(wndtext,"%X-%X-%X", &g_dwMagicValues[0], &g_dwMagicValues[1], &g_dwMagicValues[2]) != 3)
				{
					SetDlgItemText(hDlg, IDC_EDIT2, "Couldn't locate magic value!");
				}
				SetDlgItemText(hDlg, IDC_EDIT2, wndtext);
			} else {
				SetDlgItemText(hDlg, IDC_EDIT2, "Couldn't locate tomkol's keygenme!");
			}
			return (INT_PTR)FALSE;
		}

	case WM_COMMAND:
		if (LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		} else if (LOWORD(wParam) == IDOK)
		{
			UINT nLen;
			if ((nLen = GetDlgItemText(hDlg, IDC_EDIT1, wndtext, 256)) < 4)
			{
				SetDlgItemText(hDlg, IDC_EDIT1, "Too short name! must be > 4 characters long!");
				break;
			}
			if (g_hWnd != 0)
			{
				memset(g_lpName, 0, sizeof(g_lpName));
				memcpy(g_lpName, wndtext, nLen);
				hThread = CreateThread(NULL, NULL, GenerateSerialThread, &wndtext, NULL, NULL);
			}
		}
		break;
	case WM_DESTROY:
	case WM_CLOSE:
		KillTimer(hDlg,0x100);
	}
	return (INT_PTR)FALSE;
}
