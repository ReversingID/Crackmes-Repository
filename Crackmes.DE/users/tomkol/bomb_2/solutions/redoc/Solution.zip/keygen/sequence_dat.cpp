#include "main.h"

// prototypes
void Sequence_dat_Test (BYTE szSerial[16], REG_INFO &OutValues);

// global vars
const BYTE g_AllowedChars[26] = ALLOWED_CHARS;
BYTE g_szSerials[4000][16];
DWORD g_dwSerials;


//----------------------------------
bool SerialNonRepetitiveTest (BYTE szSerial[16])
{
	for (DWORD i=0; i<15; i++)
		for (DWORD j=i+1; j<16; j++)
			if (szSerial[i] == szSerial[j])
				return false;
	return true;
}

// bruteforce last 4 bytes, required sum == 0x3E4
//----------------------------------
void BruteEDX (DWORD dwEAX, DWORD dwEBX, DWORD dwECX)
{
	DWORD i, a, b, c, d, dwEDX, dwReqSum = 0;

	for (i=0; i<32; i+=8)		// partial sum (EAX + EBX + ECX)
		dwReqSum += ((dwEAX >> i) & 0xFF) + ((dwEBX >> i) & 0xFF) + ((dwECX >> i) & 0xFF);
	dwReqSum = SEQUENCE_DAT_SUM - dwReqSum;

	for (a=0; a<ALLOWED_CHARS_LEN; a++)
		for (b=a+1; b<ALLOWED_CHARS_LEN; b++)
			for (c=b+1; c<ALLOWED_CHARS_LEN; c++)
				for (d=c+1; d<ALLOWED_CHARS_LEN; d++)
					if (dwReqSum == (g_AllowedChars[a] + g_AllowedChars[b] + g_AllowedChars[c] + g_AllowedChars[d]))
					{
						dwEDX = (g_AllowedChars[a] << 24) | (g_AllowedChars[b] << 16) | (g_AllowedChars[c] << 8) | g_AllowedChars[d];
						memcpy (g_szSerials[g_dwSerials], &dwEDX, 4);
						memcpy (&g_szSerials[g_dwSerials][4], &dwECX, 4);
						memcpy (&g_szSerials[g_dwSerials][8], &dwEBX, 4);
						memcpy (&g_szSerials[g_dwSerials][12], &dwEAX, 4);
						g_dwSerials++;
					}
}

// bruteforce EAX (4x24-chars), EBX and ECX are known, EDX is ignored for now
//----------------------------------
void BruteEAX (DWORD dwEBX, DWORD dwECX)
{
	DWORD dwEAX;
	DWORD a, b, c, d;
	REG_INFO reg_info;
	BYTE szSerial[16];

	memcpy (&szSerial[4], &dwECX, 4);
	memcpy (&szSerial[8], &dwEBX, 4);

	for (a=0; a<ALLOWED_CHARS_LEN; a++)
		for (b=0; b<ALLOWED_CHARS_LEN; b++)
			for (c=0; c<ALLOWED_CHARS_LEN; c++)
				for (d=0; d<ALLOWED_CHARS_LEN; d++)
				{
					dwEAX = (g_AllowedChars[a] << 24) | (g_AllowedChars[b] << 16) | (g_AllowedChars[c] << 8) | g_AllowedChars[d];
					memcpy (&szSerial[12], &dwEAX, 4);
					Sequence_dat_Test (szSerial, reg_info);

					if ((reg_info.eax == 0x7E1618D8) && (reg_info.ebx == 0x18CCE9FD) && \
						(reg_info.ecx == 0xCC533F7B) && (reg_info.edx == 0xFCE8CE16))
							BruteEDX (dwEAX, dwEBX, dwECX);
				}
}
// tries all 'proper EDI' and reconstruct the rest, EAX and EDX
//----------------------------------
void CompleteSerial (DWORD dwProperEDI[], DWORD dwEDICount)
{
	DWORD dwEAX, dwEBX, dwECX, dwEDX, dwEDI;
	DWORD i, j, k;

	for (i=0; i<dwEDICount; i++)
	{
		dwEDI = dwProperEDI[i];
		dwEAX = 0x7E1618D8;
		dwEBX = 0x18CCE9FD;
		dwECX = 0xCC533F7B;
		dwEDX = 0xFCE8CE16;

		dwEAX -= dwEDI; dwEBX -= dwEDI; dwECX -= dwEDI; dwEDX -= dwEDI;
		dwEAX ^= dwEDI; dwEBX ^= dwEDI; dwECX ^= dwEDI; dwEDX ^= dwEDI;
		dwEAX += dwEDI; dwEBX += dwEDI; dwECX += dwEDI; dwEDX += dwEDI;

		__asm {		// byte swap
			mov eax, dword ptr [dwEAX]
			bswap eax
			mov dword ptr [dwEAX], eax
			mov eax, dword ptr [dwEBX]
			bswap eax
			mov dword ptr [dwEBX], eax
			mov eax, dword ptr [dwECX]
			bswap eax
			mov dword ptr [dwECX], eax
			mov eax, dword ptr [dwEDX]
			bswap eax
			mov dword ptr [dwEDX], eax
		}

		dwEDX ^= dwEDI;
		dwEAX += dwEDI;
		dwEBX ^= dwEDI;
		dwECX -= dwEDI;
		dwEDX ^= dwEAX;
		dwEBX += dwECX;
		dwEAX -= dwEBX;
		dwECX ^= dwEDX;

		dwEBX ^= dwECX;

		//////////////////////////////////////////////////////////////////////////
		BYTE cVal_EBX, cVal_ECX;

		if ((dwEBX & 0x0F) || (dwECX & 0x0F))
			continue;

		dwEBX = int(dwEBX) >> 4;		// divide 16
		dwECX = int(dwECX) >> 4;

		// byte reversing - EBX, ECX
		__asm{
			mov eax, dword ptr[dwEBX]
			bswap eax
			mov dword ptr[dwEBX], eax
			mov eax, dword ptr[dwECX]
			bswap eax
			mov dword ptr[dwECX], eax
		}

		cVal_EBX = dwEBX & 0x0F;
		for (j=0; j<ALLOWED_CHARS_LEN; j++)
			if (cVal_EBX == (g_AllowedChars[j] & 0x0F))		// try all plausible chars
			{
				dwEBX = (dwEBX & 0xFFFFFF00) | g_AllowedChars[j];
				
				cVal_ECX = dwECX & 0x0F;
				for (k=0; k<ALLOWED_CHARS_LEN; k++)
					if (cVal_ECX == (g_AllowedChars[k] & 0x0F))		// try all plausible chars
					{
						dwECX = (dwECX & 0xFFFFFF00) | g_AllowedChars[k];
						// try bruteforce EAX
						BruteEAX (dwEBX, dwECX);
					}
			}
	}
}
// testing EBX and ECX
//----------------------------------
bool Check_Register (int intReg)
{
	bool bOK, bFound;
	BYTE cVal;
	DWORD i, j, dwNum;

	if (intReg & 0x0F)
		return false;

	dwNum = intReg >> 4;		// divide 16 (SEQUENCE_DAT_FILE_LEN)

	bFound = true;
	for (j=0; j<24; j+=8)		// test lower 3 bytes
	{
		cVal = (dwNum >> j) & 0xFF;
		if ((cVal > '~') || (cVal < '!'))
			{bFound = false; break;}
		bOK = false;
		for (i=0; i<ALLOWED_CHARS_LEN; i++)
			if (cVal == g_AllowedChars[i])
				{bOK = true; break;}
		if (!bOK)
			{bFound = false; break;}
	}

	if (bFound)
	{
		bOK = false;		// test lower 4 bits of highest byte
		cVal = (dwNum >> 24) & 0x0F;
		for (i=0; i<ALLOWED_CHARS_LEN; i++)
			if (cVal == (g_AllowedChars[i] & 0x0F))
				{bOK = true; break;}
		if (bOK)
			return true;	// success !!!
	}
	return false;
}
// concentrate on ECX and EBX
//----------------------------------
void Resolve_Sequence_dat ()
{
	DWORD dwEAX, dwEBX, dwECX, dwEDX, dwEDI, dwEDICount = 0;
	DWORD dwProperEDI[256] = {0};

	for (dwEDI=2; dwEDI<0xFFFFFFFF; dwEDI++)	// bruteforce EDI
	{
		dwEAX = 0x7E1618D8;
		dwEBX = 0x18CCE9FD;
		dwECX = 0xCC533F7B;
		dwEDX = 0xFCE8CE16;

		dwEAX -= dwEDI; dwEBX -= dwEDI; dwECX -= dwEDI; dwEDX -= dwEDI;
		dwEAX ^= dwEDI; dwEBX ^= dwEDI; dwECX ^= dwEDI; dwEDX ^= dwEDI;
		dwEAX += dwEDI; dwEBX += dwEDI; dwECX += dwEDI; dwEDX += dwEDI;

		__asm {		// byte swap
			mov eax, dword ptr [dwEAX]
			bswap eax
			mov dword ptr [dwEAX], eax
			mov eax, dword ptr [dwEBX]
			bswap eax
			mov dword ptr [dwEBX], eax
			mov eax, dword ptr [dwECX]
			bswap eax
			mov dword ptr [dwECX], eax
			mov eax, dword ptr [dwEDX]
			bswap eax
			mov dword ptr [dwEDX], eax
		}

		dwEDX ^= dwEDI;
		dwEAX += dwEDI;
		dwEBX ^= dwEDI;
		dwECX -= dwEDI;
		dwEDX ^= dwEAX;
		dwEBX += dwECX;
		dwEAX -= dwEBX;
		dwECX ^= dwEDX;

		if (Check_Register (dwECX))
			if (Check_Register (dwEBX ^ dwECX))
				dwProperEDI[dwEDICount++] = dwEDI;
	}

	CompleteSerial (dwProperEDI, dwEDICount);

	// g_szSerials now contains g_dwSerials valid serials


/*
	// >>>>>>>>>>> DEBUG - tests
	REG_INFO reg_info;
	DWORD i, dwSumErrors = 0, dwRepetitiveChars = 0, dwChecksumErrors = 0;
	for (i=0; i<g_dwSerials; i++)
	{
		if (!SerialNonRepetitiveTest (g_szSerials[i]))
			dwRepetitiveChars++;

		Sequence_dat_Test (g_szSerials[i], reg_info);

		if (reg_info.dwSum != SEQUENCE_DAT_SUM)
			dwSumErrors++;
		if ((reg_info.eax != 0x7E1618D8) || (reg_info.ebx != 0x18CCE9FD) || \
			(reg_info.ecx != 0xCC533F7B) || (reg_info.edx != 0xFCE8CE16))
			dwChecksumErrors++;
	}
	// <<<<<<<<<< DEBUG
*/
}
