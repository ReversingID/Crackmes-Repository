#include "main.h"

// enabling Disarm button, address: 00401AF2
//----------------------------------
void Sequence_dat_Test (BYTE szSerial[16], REG_INFO &OutValues)
{
	DWORD *dwPtr = (DWORD*)szSerial;
	DWORD dwSum = 0;
	DWORD dwEAX, dwEBX, dwECX, dwEDX, dwEDI;
	ULONG64 uLong;

	for (DWORD i=0; i<16; i++)
		dwSum += szSerial[i]; // dwSum should == 0x3E4

	//dwEDX = *dwPtr;		// first 4 bytes not used
	dwPtr++;
	dwECX = *dwPtr; dwPtr++;
	dwEBX = *dwPtr; dwPtr++;
	dwEAX = *dwPtr;
	// byte reversing - EAX, EBX, ECX
	__asm{
		mov eax, dword ptr[dwEAX]
		bswap eax
		mov dword ptr[dwEAX], eax
		mov eax, dword ptr[dwEBX]
		bswap eax
		mov dword ptr[dwEBX], eax
		mov eax, dword ptr[dwECX]
		bswap eax
		mov dword ptr[dwECX], eax
	}

	dwEAX *= SEQUENCE_DAT_FILE_LEN; dwEBX *= SEQUENCE_DAT_FILE_LEN; dwECX *= SEQUENCE_DAT_FILE_LEN;		// IMUL

	dwEBX ^= dwECX;
	dwEAX ^= dwECX;
	dwEAX ^= dwEBX;

	dwEAX *= dwECX;	// MUL

	// dwEDX:dwEAX = dwEAX * dwEAX;		// MUL
	uLong = (ULONG64)dwEAX * (ULONG64)dwEAX;
	dwEAX = uLong & 0xFFFFFFFF;
	dwEDX = uLong >> 32;

	// dwEDI = dwEAX % dwEBX;	// IDIV
	__asm {
		mov eax, dword ptr[dwEAX]
		mov ebx, dword ptr[dwEBX]
		xor edx, edx
		idiv ebx
		mov dword ptr[dwEDI], edx
	}

	// dwEDX:dwEAX = dwEAX * dwEDX;
	uLong = (ULONG64)dwEAX * (ULONG64)dwEDX; // MUL, here is reversing problem?
	dwEAX = uLong & 0xFFFFFFFF;
	dwEDX = uLong >> 32;

	dwECX ^= dwEDX;
	dwEAX += dwEBX;
	dwEBX -= dwECX;
	dwEDX ^= dwEAX;
	dwECX += dwEDI;
	dwEBX ^= dwEDI;
	dwEAX -= dwEDI;
	dwEDX ^= dwEDI;

	// byte reversing - EAX, EBX, ECX, EDX
	__asm{
		mov eax, dword ptr[dwEAX]
		bswap eax
		mov dword ptr[dwEAX], eax
		mov eax, dword ptr[dwEBX]
		bswap eax
		mov dword ptr[dwEBX], eax
		mov eax, dword ptr[dwECX]
		bswap eax
		mov dword ptr[dwECX], eax
		mov eax, dword ptr[dwEDX]
		bswap eax
		mov dword ptr[dwEDX], eax
	}

	dwEAX -= dwEDI;
	dwEBX -= dwEDI;
	dwECX -= dwEDI;
	dwEDX -= dwEDI;

	dwEAX ^= dwEDI;
	dwEBX ^= dwEDI;
	dwECX ^= dwEDI;
	dwEDX ^= dwEDI;

	dwEAX += dwEDI;
	dwEBX += dwEDI;
	dwECX += dwEDI;
	dwEDX += dwEDI;

	// set output values
	OutValues.eax = dwEAX;
	OutValues.ebx = dwEBX;
	OutValues.ecx = dwECX;
	OutValues.edx = dwEDX;
	OutValues.dwSum = dwSum;

	// final values:
	// dwEAX == 0x7E1618D8
	// dwEBX == 0x18CCE9FD
	// dwECX == 0xCC533F7B
	// dwEDX == 0xFCE8CE16
	// dwSum == 0x3E4
}

// Disarm button, address: 00401101
//----------------------------------
void SequenceTest (BYTE szSerial[16], REG_INFO &OutValues)
{
	DWORD *dwPtr = (DWORD*)szSerial;
	DWORD dwSum = 0;
	DWORD dwEAX, dwEBX, dwECX, dwEDX, dwEDI, dwESI;
	ULONG64 uLong;

__try{

_00401112:
	for (DWORD i=0; i<16; i++)
		dwSum += szSerial[i]; // dwSum should be 0x400

	dwEDX = *dwPtr++;
	dwECX = *dwPtr++;
	dwEBX = *dwPtr++;
	dwEAX = *dwPtr;

	__asm {		// byte swap
		mov eax, dword ptr [dwEAX]
		bswap eax
		mov dword ptr [dwEAX], eax
		mov eax, dword ptr [dwEBX]
		bswap eax
		mov dword ptr [dwEBX], eax
		mov eax, dword ptr [dwECX]
		bswap eax
		mov dword ptr [dwECX], eax
		mov eax, dword ptr [dwEDX]
		bswap eax
		mov dword ptr [dwEDX], eax
	}

_00401139:
	dwEAX += dwEBX + dwECX + dwEDX;
	dwEBX ^= dwEAX ^ dwECX ^ dwEDX;

	dwECX -= dwEAX;
_00401149:
	// dwEDX:dwEAX = dwEAX * dwECX;
	uLong = (ULONG64)dwEAX * (ULONG64)dwECX; // MUL
	dwEAX = uLong & 0xFFFFFFFF;
	dwEDX = uLong >> 32;

	dwEAX ^= dwEDX;
	dwEDX += dwECX;
_00401153:
	dwESI = dwEAX % dwEBX;	// DIV
	dwEDI = dwESI * 3;
	dwEAX += dwESI;
	dwEBX -= dwESI;
	dwECX ^= dwEDX;
	dwEDX ^= dwESI;
_00401164:
	// dwEDX:dwEAX = dwEAX * dwEDX;
	uLong = (ULONG64)dwEAX * (ULONG64)dwEDX; // MUL
	dwEAX = uLong & 0xFFFFFFFF;
	dwEDX = uLong >> 32;

	dwEDX += dwEAX;
	dwECX ^= dwEDI;
	dwECX += dwESI;
_00401170:
	//dwEDI = dwEAX % dwECX;	// IDIV
	__asm {
		mov eax, dword ptr[dwEAX]
		mov ecx, dword ptr[dwECX]
		xor edx, edx
		idiv ecx
		mov dword ptr[dwEDI], edx
	}

	dwEAX ^= dwEBX;
	dwECX ^= dwEDX;
	dwEBX += dwEDX;
	dwEAX += dwECX;
	dwEDX -= dwEAX;
	dwECX -= dwEBX;
_00401186:
	dwESI = dwEDI * 0xC;	// IMUL
	dwEAX ^= dwEBX ^ dwEDX;
	dwECX += dwEDX - dwEAX;
_0040119B:
	dwEDI = dwEAX % dwECX;	// DIV
	dwEAX = dwEDI * 0x11;	// IMUL
	dwEBX = dwEDI * 0xA;		// IMUL
	dwECX = dwESI * 0x13;	// IMUL

_004011AD:
	// dwEDX:dwEAX = dwEAX * dwECX;
	uLong = (ULONG64)dwEAX * (ULONG64)dwECX; // MUL
	dwEAX = uLong & 0xFFFFFFFF;
	dwEDX = uLong >> 32;

	dwEDX ^= dwEBX;
	dwEAX -= dwECX;

	// set output values
	OutValues.eax = dwEAX;
	OutValues.ebx = dwEBX;
	OutValues.ecx = dwECX;
	OutValues.edx = dwEDX;
	OutValues.dwSum = dwSum;

}__except(EXCEPTION_EXECUTE_HANDLER)
{memset (&OutValues, 0, sizeof(OutValues));}

	// expected final values:
	// dwEAX == 0x906F7F8C
	// dwEBX == 0x772127E8
	// dwECX == 0xAD249F04
	// dwEDX == 0x563717AA
	// dwSum == 0x400
}
// shortened function (for performance reason), test only ECX
//----------------------------------
DWORD QuickSequenceTest_ECX (BYTE szSerial[16])
{
	DWORD *dwPtr = (DWORD*)szSerial;
	DWORD dwSum = 0;
	DWORD dwEAX, dwEBX, dwECX, dwEDX, dwEDI, dwESI;
	ULONG64 uLong;

	dwEDX = *dwPtr++;
	dwECX = *dwPtr++;
	dwEBX = *dwPtr++;
	dwEAX = *dwPtr;
	__asm {		// byte swap
		mov eax, dword ptr [dwEAX]
		bswap eax
		mov dword ptr [dwEAX], eax
		mov eax, dword ptr [dwEBX]
		bswap eax
		mov dword ptr [dwEBX], eax
		mov eax, dword ptr [dwECX]
		bswap eax
		mov dword ptr [dwECX], eax
		mov eax, dword ptr [dwEDX]
		bswap eax
		mov dword ptr [dwEDX], eax
	}

	dwEAX += dwEBX + dwECX + dwEDX;
	dwEBX ^= dwEAX ^ dwECX ^ dwEDX;
	if (dwEBX == 0) return 0;		// zero division

	dwECX -= dwEAX;
_00401149:
	// dwEDX:dwEAX = dwEAX * dwECX;
	uLong = (ULONG64)dwEAX * (ULONG64)dwECX; // MUL
	dwEAX = uLong & 0xFFFFFFFF;
	dwEDX = uLong >> 32;

	dwEAX ^= dwEDX;
	dwEDX += dwECX;
_00401153:
	dwESI = dwEAX % dwEBX;	// DIV
	dwEDI = dwESI * 3;
	dwEAX += dwESI;
	dwECX ^= dwEDX;
	dwEDX ^= dwESI;

	dwEAX = dwEAX * dwEDX;	// MUL
	dwECX ^= dwEDI;
	dwECX += dwESI;
	if (dwECX == 0)	return 0;		// zero division

	//dwEDI = dwEAX % dwECX;	// IDIV
	__asm {
		mov eax, dword ptr[dwEAX]
		mov ecx, dword ptr[dwECX]
		xor edx, edx
		idiv ecx
		mov dword ptr[dwEDI], edx
	}

	dwECX = dwEDI * 0xE4;	// IMUL	0xC*0x13
	return dwECX;

	// final values:
	// dwEAX == 0x906F7F8C
	// dwEBX == 0x772127E8
	// dwECX == 0xAD249F04
	// dwEDX == 0x563717AA
	// dwSum == 0x400
}
