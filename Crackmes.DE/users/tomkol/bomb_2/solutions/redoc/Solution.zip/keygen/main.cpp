#include "main.h"
#include <CommCtrl.h>
#include "resource.h"

// prototypes
void Resolve_Sequence_dat ();

//----------------------------------
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	Resolve_Sequence_dat ();
	return 0;
}
