#undef UNICODE
#undef _UNICODE
#include <windows.h>

#define	SEQUENCE_DAT_SUM		0x3E4		// 996
#define	SEQUENCE_DAT_FILE_LEN	16
#define	SEQUENCE_SUM			0x400			// 1024

#define	ALLOWED_CHARS			"~!@#$%^*()-_=+[]{},.<>/?"
#define ALLOWED_CHARS_LEN	24

struct REG_INFO {
	DWORD	eax;
	DWORD	ebx;
	DWORD	ecx;
	DWORD	edx;
	DWORD	dwSum;
};