Crackme 7 - sonkite
--------------------
Well your task is to find a valid serial.
The rules are simple no patching, good luck.

Greetz to all i know - sonkite@gmx.net