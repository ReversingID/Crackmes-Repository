Crackme #5 - sonkite
--------------------
hello here is a little easy crackme i coded with masm one boring evening 
your goal is to (at least) find a valid serial for your name

please mail me your solution @ sonkite@gmx.net

NO PATCHING!