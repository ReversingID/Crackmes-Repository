#include <stdio.h>
#include <windows.h>
#include <string.h>
#include "resource.h"


BOOL CALLBACK DlgProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{	
	switch (message)
	{    
	case WM_CLOSE:
		EndDialog(hWnd,0);
		break;
	case WM_COMMAND:
		{
			switch (LOWORD(wParam))
				{
					case ID_GENERATE:
						{
						 unsigned char tbl[]={0x0,0x48,0x65,0x79,0x20,
							 0x43,0x72,0x61,0x63,0x6b};
										

						  char name[50]={NULL};
						  char str[50]={0x0};
						  char pswd[8]={0x0};
						  DWORD ebp_8=1,ebp_10=0,ebp_14=0,edi=0;
							
						  int NameLen=GetDlgItemText(hWnd,ID_NAME,name,50);
						  SetDlgItemText(hWnd,ID_PSWD,name);
						  strupr(name);


						  for(int i=0;i<NameLen;i++)
							{	
						      ebp_10+=(name[i]*2-2);
							  str[i]=tbl[ (name[i]%10)];
							  ebp_14+=ebp_10;

							  
							  for(int j=0;j<=i;j++)
							  {	
									edi+=(str[j]+name[i]);
							  }
						  }
							  edi+=ebp_14;	
							  edi=edi*(name[NameLen-1]%10)*name[NameLen-1];
							  wsprintf(pswd,"%X",edi);
							  SetDlgItemText(hWnd,ID_PSWD,pswd);
						}
				}

						
		}
	}

return 0;
}


int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nCmdShow)
{
 DialogBox(hInstance,MAKEINTRESOURCE(IDD_DIALOG1),NULL,(DLGPROC)DlgProc);
return 0;
}