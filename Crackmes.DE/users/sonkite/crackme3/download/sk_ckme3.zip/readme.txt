Sonkite's Crackme #3 - Readme
=============================
 there is only 1 rule thats keygen only i dont care how u make it :)
 its packed with upx and made in delphi 6 so dont mind the size heh
 please send all your solutions to sonkite@hotpop.com
 greetz to everybody i know and know me, and you of course :))