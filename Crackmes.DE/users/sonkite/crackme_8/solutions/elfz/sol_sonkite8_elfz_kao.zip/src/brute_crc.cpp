// brute force text-with-given-crc finder for sonkite crackme #8
// 2003, elfZ & Kao
// takes about 2 minutes on P4/2.16 to give the possibility "13 0a 98 7a"

#include <stdio.h>
#include <conio.h>

typedef unsigned long ulong;

void main() {

   printf("\n\
CRC-text brute-finder for sonkite crackme by elfZ & Kao\n\
\n\
This will take about 2 minutes on P4/2.13");

   ulong crc;
   ulong i;
   ulong iptr = (unsigned long)&i;
   for (i = 0; i < 0xffffffff; i++) {
      if (i % 0x500000 == 0) printf(".");
      __asm {
        mov esi, iptr
        xor eax, eax
        xor edx, edx

        lodsb
        add     edx, eax
        xor     dh, dl
        xchg    dl, dh
        ror     edx, 8

        lodsb
        add     edx, eax
        xor     dh, dl
        xchg    dl, dh
        ror     edx, 8

        lodsb
        add     edx, eax
        xor     dh, dl
        xchg    dl, dh
        ror     edx, 8

        lodsb
        add     edx, eax
        xor     dh, dl
        xchg    dl, dh
        ror     edx, 8

        mov crc, edx
      }

      if (crc == 0x3bb51d2f) {
        printf("\n[%08x] (byte order reversed)", i);
        break;
      }
   
   
   }
   printf("\npress any key...");
   getch();


}
