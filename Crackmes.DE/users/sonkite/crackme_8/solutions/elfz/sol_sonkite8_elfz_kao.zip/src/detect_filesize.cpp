// debuggery-stuff to detect the correct length of the keyfile for sonkite crackme #8
// 2003, elfZ & Kao

#include <windows.h>
#include <stdio.h>
#include <conio.h>

typedef unsigned long ulong;

// this is the address of jmp ReadFile
// the proggie will break on this, when the size will be correct
const unsigned long ADDR = 0x4011FC;

void term() {
  printf("\n  press any key...");
  getch();
  exit(0);
}


void main() {

    printf("\
Sonkite crackme-8 keyfile size detector\n\
2003, elfZ & Kao\n");
    for ( ulong i = 0 ; i < 0x1000; i++ ) {


        // make keyfile of i-length
        FILE* f = fopen("son.key", "wb");
        for ( ulong j = 0 ; j < i; j++ ) {
            fputs(" ", f);
        }
        fclose(f);


        // exec the stuff
        STARTUPINFO si; GetStartupInfo( &si );
        PROCESS_INFORMATION pi;
        DEBUG_EVENT dbe;

        BOOL createProcessResult = CreateProcess(
                                                "sk-cm8.exe", // lpApplicationName
                                                NULL, // lpCommandLine
                                                NULL, // lpProcessAttributes
                                                NULL, // lpThreadAttributes
                                                FALSE, // bInheritHandles
                                                CREATE_SUSPENDED | DEBUG_PROCESS | DEBUG_ONLY_THIS_PROCESS, // dwCreationFlags
                                                NULL, // lpEnvironment
                                                NULL, // lpCurrentDirectory
                                                &si,  // lpStartupInfo
                                                &pi   // lpProcessInformation
                                                );

        if (FALSE == createProcessResult) {
          printf("\nCannot exec the sk-cm8.exe (do you have that file?)");
          term();
        }

        // set a breakpoint
        // screw the error handling
        WriteProcessMemory( pi.hProcess, (FARPROC)ADDR, "\xcc", 1, NULL );

        // exec crackme
        ResumeThread( pi.hThread );

        bool processTerminated = false; // we have killed the process

        bool kernelExceptionPassed = false;

        while ( !processTerminated ) {
            
            if ((WaitForDebugEvent( &dbe, 1000 )) == FALSE) {
              // the process has hang up, so kill it
              TerminateProcess( pi.hProcess, 0 );
            }
            
            switch ( dbe.dwDebugEventCode ) {
                case EXCEPTION_DEBUG_EVENT: {
                        if ( dbe.u.Exception.ExceptionRecord.ExceptionCode == EXCEPTION_BREAKPOINT ) {

                            CONTEXT ctx; ctx.ContextFlags = CONTEXT_SEGMENTS | CONTEXT_INTEGER | CONTEXT_CONTROL;
                            GetThreadContext( pi.hThread, &ctx );

                            // exception on ReadFile
                            if (ctx.Eip == ADDR + 1) {
                                printf( "\nCorrect keyfile size detected: [%d]", i );
                                // not too polite, but let the OS handle our unterminated proggie
                                term();

                            }

                            if (!kernelExceptionPassed) {
                              // the first breakpoint exception always is the kernel's exception
                              // signalizing that target has loaded
                              kernelExceptionPassed = true;
                            } else {
                              // weirdo breakpoint, we don't know it
                              TerminateProcess( pi.hProcess, 0 );
                            }

                        } else {
                            // some wrong exception
                            TerminateProcess( pi.hProcess, 0 );
                        }
                        break;
                    }
                case EXIT_PROCESS_DEBUG_EVENT: // debugee has terminated
                    processTerminated = true;
                    break;
            }
            ContinueDebugEvent( dbe.dwProcessId, dbe.dwThreadId, DBG_CONTINUE );
            if (processTerminated) break;
        }

        printf( "." );
    }


}