Crackme 8 - sonkite
================================================
Well your task is to find a valid keyfile, that properly displays your nick name in the messagebox.
The rules are simple no patching, good luck.

Greetz to all i know - sonkite@gmx.net