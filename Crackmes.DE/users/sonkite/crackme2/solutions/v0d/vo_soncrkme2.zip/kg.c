#include <stdio.h>
#include <string.h>
#include <conio.h>

int main(void)
 {
   char name[40];
   unsigned long code= 0 ,i;

   clrscr();
   printf("Crackme 1# - by Sonkite - Keymaker - by [v0!d]\n\n");
   printf("Name   : ");
   gets(name);

   for(i=0; i < strlen(name); ++i) code += name[i];

   printf("Serial : 0800002%lu", code * 666);
   getche();
   return 0 ;
   }


