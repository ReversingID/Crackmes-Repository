#include <stdio.h>
#include <stdlib.h>

void main(void)
{ char pass[]="abcdefghijklmnopqrstuv";
  unsigned int i,m,p=0,f;
  while(1)
  { m=0xc039c4;
    f=0;
    for(i=0;i<22;i++)
    { f+=5;
      m=(m+pass[i])*f;
    }
    m=(m^0x6a451efb)&0xc3506f2;
    if(m==0x83004e0)
    { printf("%s\n",pass);
      if(p==10) exit(0);
      p++;
    }
    i=random(22);
    pass[i]++;
    while(pass[i]>'z')
    { pass[i]='a';
      i++;
      if(pass[i]==0)
        i=0;
      pass[i]++;
    }
  }
}