/*
@Author _InSaNe_
@Jun 30 th 2007
*/
#include<conio.h>
#include<stdio.h>
void main()
{
	int  j,i,count;
	char ch[100],chrev[100],serial[15];
label1:	clrscr();
	for(i=0;i<=14;i++)
		serial[i]=NULL;
	printf("Enter the name to generate serial : ");
	printf("\nName: ");
	scanf("%s",ch);
	i=0;
	while(ch[i]!=NULL)
		i++;
	i--;
	if(i<=1)
	{
		printf("\nERROR:Atleast enter three letters for name !");
		printf("\nPress a key to continue !");
		getch();
		goto label1;
	}
	for(j=0;i>=0;i--)
		chrev[j++]=ch[i];
	i=j=0;             	  //    012345	 	012345

	while(i<=5)       //ch  insane   chrev 	enasni
	{
		serial[i]=chrev[j];
		serial[i+1]=ch[j];
		i=i+2;
		j++;
	}
	strcat(serial,"-easy");
	printf("Serial: %s\nPress a key to exit !",serial);
	getch();
}



