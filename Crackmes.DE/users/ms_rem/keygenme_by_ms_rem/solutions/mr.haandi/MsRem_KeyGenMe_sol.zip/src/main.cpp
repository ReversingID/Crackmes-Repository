#include <windows.h>
#include <windowsX.h>
#include <stdio.h>
#include "resource.h" 

HWND		hWnd;

__forceinline void Action()
{
	unsigned char szName[11]="";
	
	GetDlgItemTextA(hWnd,IDC_DATA,(char *)szName, 11);
	if (!strlen((char *)szName)) {
		SetDlgItemTextA(hWnd,IDC_SIGNATURE,"Invalid data length!");
		return;
	}
	char szSerial[21]="";
	strcat(szSerial,"0A");
	unsigned char bValue;
	bValue=szName[0]+szName[1]+0x16; sprintf(szSerial+2,"%02X",bValue);
	strcat(szSerial,"6B0D16");
	bValue=szName[8]+szName[4]-szName[2]; sprintf(szSerial+10,"%02X",bValue);
	strcat(szSerial,"01");
	bValue=0;
	for (int i=0;i!=10;i++)
		bValue+=szName[i];
	sprintf(szSerial+14,"%02X%02X%02X",(unsigned char)(bValue+0x34),bValue,(unsigned char)(bValue+0x48));
	SetDlgItemTextA(hWnd,IDC_SIGNATURE,szSerial);
	return;
}

__forceinline void Initialization()
{
	SetDlgItemTextA(hWnd,IDC_DATA,"MR.HAANDI");
	return;
}

__forceinline void ShowInfo(){
	char AboutMsg[400]="Made by MR.HAANDI";
	MessageBoxA(hWnd,AboutMsg,"Info",MB_OK);
	return;
}

BOOL CALLBACK DlgProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam)
{
	switch(Message)
	{
	case WM_INITDIALOG:
		hWnd=hwnd;
		Initialization();
		break;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
			case IDC_DATA: if (HIWORD(wParam)==EN_CHANGE) Action(); break;
			case IDC_ACTION: Action(); break;
			case IDC_INFO: ShowInfo(); break;
			case IDC_EXIT: EndDialog(hwnd, 0); break;
		}
		break;
	case WM_CLOSE: EndDialog(hwnd, 0); break;
	default: return FALSE;
	}
	return TRUE;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	DialogBox(::GetModuleHandle(0), MAKEINTRESOURCE(IDD_DLGMAIN), NULL, DlgProc);
	::ExitProcess(0);
	return 0;
}