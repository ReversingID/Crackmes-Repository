//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Skeleton.rc
//

#define IDD_DLGMAIN                     101

#define IDC_ACTION                      1001
#define IDC_INFO                        1002
#define IDC_DATA                        1003
#define IDC_EXIT                        1004
#define IDC_SIGNATURE                   1005

#define IDI_ADMIN                       105
#define IDI_APP							106
#define IDI_INFO                        107
#define IDI_LOCK                        108
#define IDI_UNLOCK                      109


// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
