#!/usr/bin/python
# -*- coding: utf-8 -*-

c = 'ie`o%#!eF@FYLQ1'		#kfdj#$)lLKJTB^!
cont = 2
rdo = range(len(c))

for i in range(len(c)):
  rdo[(cont-2)] = chr(ord(c[cont-2]) ^ cont)
  cont += 1

print rdo

#	A&PBAae{m8((9=:(
#	@%YM@bl|l;178>#/
#	ie`o%#!eF@FYLQ1		ok
#	F#[ONln~j=35& !-
#	H,SFLobs|*#$,+58
#	I&PJIaecu8(0!=: 
#	C ^HC
