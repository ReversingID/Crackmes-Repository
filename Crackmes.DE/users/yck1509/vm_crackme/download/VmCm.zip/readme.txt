Simple Crackme of .NET using VM Protection
Used my own protector, try to solve it.
Three aspect of solving it:
1. Crack: Make it accept all keys.
2. Unpack: Remove dependency on runtime
3. Keygen: Write a keygen

Try it!