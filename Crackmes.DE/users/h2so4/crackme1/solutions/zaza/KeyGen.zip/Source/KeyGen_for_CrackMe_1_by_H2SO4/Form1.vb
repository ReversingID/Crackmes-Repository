﻿Public Class frmMain

    Private Sub btnGenerate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGenerate.Click
        Generate()
    End Sub

    Private Sub Generate()
        Dim Name As String = txtName.Text

        If Name <> "" Then

            Dim Serial As String = ""
            Dim num3 As SByte
            Dim NextChar As SByte = CSByte(Asc(Name.Chars((Name.Length - 1))))
            Dim num4 As Integer = &H3B ';

            For I = 0 To 15
                If (I < Name.Length) Then
                    num3 = CSByte(Asc(Name.Chars(I)))
                Else
                    num3 = CSByte((Asc(Name.Chars((I Mod Name.Length))) + (I Mod 9)))
                End If

                Dim num As Integer = (((((CInt((num3 * CInt(NextChar))) Mod 106) + num4) - 1) Or 68) Xor 170)
                num = If((num >= 0), num, -num)
                Do While (num < 32)
                    num = (num + &H5E)
                Loop

                Do While (num > 126)
                    num = (num - &H5E)
                Loop

                Serial = Serial & Chr(num)

                num4 = (num4 + num)
                NextChar = num3
            Next

            txtSerial.Text = Serial
        Else
            MsgBox("Input your name, please!", MsgBoxStyle.Critical, "Error")
        End If
    End Sub

    Private Sub txtName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtName.TextChanged
        Generate()
    End Sub

    Private Sub lnkZaZa_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkZaZa.LinkClicked
        System.Diagnostics.Process.Start("http://crackmes.de/users/zaza")
    End Sub
End Class
