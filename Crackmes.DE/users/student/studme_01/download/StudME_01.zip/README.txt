This is my first CrackME, that are written in win 32 Assembler.

Please find a correct serial numer and send it to me <lucaz@go2.pl>. Please do not modify code.