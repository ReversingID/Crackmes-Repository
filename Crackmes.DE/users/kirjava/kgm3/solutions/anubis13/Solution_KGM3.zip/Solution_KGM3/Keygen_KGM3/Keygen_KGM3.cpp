#include <iostream>
#include <cstdio>
#include <string>

using namespace std;

int main()
{
	unsigned int sum = 0;
	unsigned int res;
	unsigned int quotient;
	unsigned int remainder;
	
	string usen;							// 4+
	string pass = "Password";				// 8

	beg:
	cout << "Enter your username (4+ symbols) or \"no\" for exit:" << "\n";
	cin >> usen;
	
	if (usen == "no")
	{
		return 0;
	}
	else
	{
		if (usen.size() < 4)
		{
			usen.clear();
			goto beg;
		}
		else
		{
			//------------------------------ Create CHECKSUM ------------------------------//
			
			sum = 0;

			for (int i = 0; i < usen.size(); ++i)
			{
				sum = sum + (unsigned int)usen[i];
			}

			//cout << hex << sum << "\n";

			res = 56492 * sum;			// 0000DCACh = 56492d
			res = res ^ 1432778632;		// 55667788h = 1432778632d
			quotient = res / 21;		// 15h = 21d
			remainder = res % 21;
			res = quotient * remainder;
			res = usen.size() * res;

			//cout << hex << res << " = " << quotient << " = " << remainder << "\n";

			//------------------------------ Create PASSWORD ------------------------------//

			unsigned int dw_1234 = res;
			unsigned int dw_1238 = res;
			unsigned int dw_1248 = res;
			unsigned int dw_124C = 0;
			
			for (int i = 0; i < 8; ++i)
			{
				dw_1248 = dw_1234 / 60;			// Case 14, 60d = 3Ch
				dw_124C = dw_1234 % 60;			// Case 14
				dw_1234 = dw_124C;				// Case 60
				dw_1248 = dw_1234 + 65;			// Case 11, 65d = 41h = "A"
				dw_1234 = dw_1248;				// Case 60

				pass[i] = dw_1234;				// Case 63

				dw_1248 = dw_1238 * dw_1234;	// Case 03
				dw_1234 = dw_1248;				// Case 60
				dw_1248 = dw_1238 ^ dw_1234;	// Case 07
				dw_1234 = dw_1248;				// Case 60
				dw_1248 = dw_1234 * usen.size();// Case 03
				dw_1234 = dw_1248;				// Case 60
				dw_1248 = dw_124C ^ dw_1234;	// Case 07
				dw_1234 = dw_1248;				// Case 60
				dw_1248 = dw_1234 ^ 3707812608;	// Case 17, DD00BB00h = 3707812608d
				dw_1238 = dw_1248;				// Case 60
			}

			cout << "Your password: " << pass << "\n\n";
			goto beg;
		}
	}
	
	return 0;
}