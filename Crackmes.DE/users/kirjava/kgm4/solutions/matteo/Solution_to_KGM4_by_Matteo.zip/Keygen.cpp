#include <Windows.h>
#include <stdio.h>

unsigned int num1=0xDDEEEEFF,num2=0x000000FF,num3=0x0B4DF00D;
unsigned int userHash=0x00000ABC;

unsigned int MakePw()
{
	num2=(userHash%num1)+(num3*num2);
	return num2;
}

//used to init the array to decrypt strings but here only to set num2=0x8B4CA7AF;
void InitNum2()
{
	for (int i=0; i<=0x800; i++)
	{
		MakePw();
	}
}

void MakeUserHash(char * user)
{
	__asm
	{
		mov ecx,[user]
		XOR EAX,EAX
		XOR EBX,EBX
		XOR EDX,EDX
		again:
		MOV BL,BYTE PTR DS:[ECX]
		MOV AL,BL
		SHL EAX,3
		XOR EAX,EDX
		INC ECX
		MUL EAX
		ADD EDX,EAX
		CMP BL,0
		JNZ again
		MOV DWORD PTR DS:[userHash],EDX
	}
}

//used to remove chars from stdin (only if they are present!)
void FlushStdin()
{
	FILE * s=stdin;
	char c;
	while(s->_cnt > 0)
	{
		scanf_s("%c",&c);
	}
}

//read from stdin without problems: clean input, space and symbols allowed, no chars left on stdin
unsigned int GetInput(char * buf, unsigned int bufSize)
{
	FlushStdin();
	fgets(buf,bufSize,stdin);
	FlushStdin();
	unsigned int len;
	for (len=0; buf[len]!=10 && len<bufSize-1; len++)//"strlen"
		continue;
	ZeroMemory(buf+len,bufSize-len);
	return len;
}

int main()
{
	char inputUser[17];//buffer size is 16 bytes +1 null
	char inputPassword[17];//16 + null

	printf("Give user name (between 5 and 14 chars): ");
	unsigned int userLen;
	do 
	{
		userLen=GetInput(inputUser,17);//chars da leggere, no a capo, null compreso
		if (userLen<5)
			printf("Name too short, input again: ");
		if (userLen>14)
			printf("Name too long, input again: ");
	} while (userLen<5 || userLen>14);//program check if len is >=5; it read 0x10 chars so max length is 0x10-2 = 0xE = 14 (because of \r\n, 0xD 0xA)
	inputUser[userLen]=0xD;
	inputUser[userLen+1]=0xA;//add "enter" as ReadConsoleA doesn't remove it while i have "a clean input"

	InitNum2();//at the start of the program there is a loop that change num2 in MakePw call; if you change num2 declaration this is not needed
	MakeUserHash(inputUser);//keygen part one: "hash" the user

	for (unsigned int i=0; i<14; i++)//keygen part two: loop to generate password (MakePw uses hashed user inside)
	{
		inputPassword[i]=(MakePw()%0x19)+0x41;
		for (unsigned int j=(MakePw()%0x40)+2; j>0; j--)
			MakePw();
	}
	inputPassword[14]='M';//at 00101178 ADD EDX,0F; DEC EDX; CMP BYTE PTR DS:[EDX],4D (0x4D='M')
	inputPassword[15]='Z';//at 0010117B MOV BH,BYTE PTR DS:[EDX] (BH = last letter); SUB BH,2; SUB BYTE PTR DS:[EAX],BH (decrypt); MZ = dos magic word--> 0xB8 - (X-2) = 0x60 (pushad) --> X = 0xB8 - 0x60 + 2 = 0x5A = 'Z'
	inputPassword[16]=0;//null terminated

	printf("Password: %s\n",inputPassword);
	system("PAUSE");
	return 0;
}