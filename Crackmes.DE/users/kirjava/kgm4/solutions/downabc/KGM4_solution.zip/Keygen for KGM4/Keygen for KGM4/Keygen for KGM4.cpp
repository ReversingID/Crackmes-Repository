// Keygen for KGM4.cpp : �������̨Ӧ�ó������ڵ㡣
//
#include "stdafx.h"
#include <Windows.h>
#include <wincon.h>
#include <stdio.h>
int _tmain(int argc,char* argv[])
{
	puts("Keygen for KGM4\ncompiled by downabc, 2015-04-25 12:25 UTC\nMessage: debug 2 hour, code in C 1.5 days failed, mixed with asm, finished after 1 hour...\nusername please?(Min 5 chars, MAX 16 chars)\n");
	char usn[17];
	char pwd[25];
	ZeroMemory(usn,17);
	ZeroMemory(pwd,25);
	gets(usn);
	int i,j,k;
	i=0;
	while(usn[i]) i++;
	usn[i]=0x0d;
	usn[i+1]=0x0a;
	static DWORD sum;
	__asm{
		push esi
		lea esi,usn
		xor eax,eax
		xor edx,edx
	loop1:
		lodsb
		mov bl,al
		shl eax,3
		xor eax,edx
		mul eax
		add edx,eax
		cmp bl,0
		jnz loop1
		mov sum,edx
		pop esi
	}
	puts("\nYour PassWord is");
	static DWORD f=0x8b4ca7af;
	for (i=0;i<14;i++)
	{
		f=f*0x0b4df00d+sum%0xddeeeeff;
		pwd[i]=f%0x19+0x41;
		f=f*0x0b4df00d+sum%0xddeeeeff;
		j=f%0x40+2;
		while (j>0)
		{
			f=f*0x0b4df00d+sum%0xddeeeeff;
			j--;
		}
	}
	pwd[14]='M';
	pwd[15]='Z';
	puts(pwd);
	puts("\nDONOT try to copy & paste, the KGM dose not support this way...");
	getchar();
}
