/***********************************************/
/*		      poof		       */
/***********************************************/

Hey there! Thanks for trying my crackme!

Once again, a simple goal:
Figure out a valid password. Bonus points
for a "keygen".

You are free to do whatever with the binary
to achieve the goal.

I have attached a image of what the crackme
looks like when solved.

Debugging may result in crashes.

[EDIT]I added some clues. ;)

Greetz,
Kirjava.