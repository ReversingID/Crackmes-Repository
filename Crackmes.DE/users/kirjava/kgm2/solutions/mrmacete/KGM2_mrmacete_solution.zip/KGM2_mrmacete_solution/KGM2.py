
def gen_serial_in_array(username):
	
	# save original length, before adding 0s
	tl = len(username)

	

	# length checking
	if 8 <= tl < 12:

		# add 0s to make it 12-chars long
		username += [0] * (12 - tl)

		# add "out of bounds" byte
		username += [ 0xcc ] 

		# first char initialization
		username[0] = (username[tl-1] * tl) & 0xff

		"""
		first 8 chars are obtained by simply xoring each byte with its
		predecessor, with the special initialization of the first byte
		"""
		count = 0
		while count < 8:
			if count == 0:
				# initialization of the first byte
				multiplier = (((tl ** 2) & 0xff) << 2) ^ tl
				username[count] = (multiplier * username[count]) & 0xff
			else:
				# all other bytes are simply xored
				username[count] = (username[count] ^ username[count-1]) & 0xff

			"""
			restrict possible output values in the range [0,26]
			"""
			username[count] = (username[count] % 0x1a) & 0xff
			count += 1


		"""
		the remaining four bytes are a dash ('-') followed
		by three bytes obtained as below:
		"""
		# constant dash char '-'
		username[8] = 0x2d 

		username[9] = (((username[6] * tl) ^ username[7]) & 0xff) % 0xa
		
		"""
		following list index can go to -1, that's why there's
		the "out of bounds" padding on the tail ()
		"""
		username[10] = username[  9 - 1 - username[9] ] 
		
		username[9] += 0x30
		username[10] = ((username[10] ^ username[9]) % 0xa) + 0x30
		username[11] = ((username[4] ^ username[3]) % 0xa) + 0x30

		username.pop() # remove out of bounds padding
	
	else:
		
		# wrong length case, cannot compute serial
		username[:] = [ord(c)-0x41 for c in "WRONGLEN"] + list([ord(c) for c in "GTH!"])


def gen_serial(username):
	# convert the string to an int array
	arr = [ord(c) for c in username]

	# generate the serial in place
	gen_serial_in_array(arr)

	# add 0x41 to first 8 bytes, to make it ASCII
	arr = [c+0x41 for c in arr[0:8]] + arr[8:];

	# let's make a string out of it
	return "".join([chr(c) for c in arr])

# decrypt the "hidden" success message, just for fun
def decrypt_success_message():
	encrypted = [0x0, 0x28, 0x28, 0x1d, 0xd9, 0x30, 0x28, 0x2b, 0x24, 0xda ]
	return "".join([chr((c+0x47) & 0xff) for c in encrypted])

if __name__ == "__main__":

	"""
	replace "porcodio" with your username, provided that
	it has a length between 8 and 11
	"""
	print gen_serial("porcodio")
	print decrypt_success_message()


	
