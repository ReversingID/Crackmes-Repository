
/*	KGM2 - by Kirjava	*/

Difficulty: 
1 - Easy

Goal: 
Create a keygen! Self-keygenning/patching is allowed, but discouraged.

Details:
KGM2 was written in C/C++. Size: 3072 bytes.

SHA 256: 6111b79b63886efc1af6720ce39485203d632b2cb1b356f9a8e1b0fa2a56cac9
MD5: 8713373e315b342a05f1ee9e01072104