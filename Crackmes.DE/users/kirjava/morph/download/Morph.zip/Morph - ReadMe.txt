/***********************************************/
/*		      MORPH		       */
/***********************************************/

Hello and thanks for trying to beat my crackme. :)

The goal is simple: Figure out my secret word.
Displaying "Nicely done" is also acceptable.
Feel free to use any means necessary for the task.

I supplied a image of what the crackme looks like
when it is solved.

Wrong passwords may result in expected crashes!

Greetz,
Kirjava.