

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "gmp.h"

#include "nessie.h"

typedef unsigned char u8;
typedef unsigned int u32;
typedef unsigned __int64 u64;

const char dictionary[] = "gMyiabQPt8AWsjTx3cNBq20hXeLu5SoO7zZpCRrmIEDnKdVv1FJl6UfG4wHYk9/*";

const char *constants[] = 
{
  "1012AB7CF09F56881948DA28E94C9F304309500CC995E485C7D011B0C0791984A23785B9CAD",
  "17752D9401CE3C78991BEB22A8F0C4DE44FA92C5D65983599709E17C74C9A18CE56049C89ED",
  "3CBAF2280B97FCE3B4C453C28B84F078E43C046C08D72D4368F8464C382F986140DF63999D9", 
  "9A99DEBD00F00F62BBB3F2B1D3FD4DFE0010BFC93D14144BCF0EB00CF9309B8718E9E06D55", 
  "6B8386B363C60FB11775D8ADDF7F380CC3ADE40E5EFC251D8514B60D713F9D95C152EC73163", 
  "667EB7984D3F2554B855F5A2C94065F148D8D248B227A220335735AE429601E0EF1CDD333AC", 
  "79890DAD46EABE85B3141A0F83D7C93C2165652456260EE2B132590912A8129750F83EA579B", 
  "472F268AC5B66DB7D40FB1FC916D817F6B2A1ABEDE95B5723C134C071FDCA1927507297232D", 
  "3F397D52379189C846D9FCB0B14A0ECB189F7A5A7F2C9B06BF5C5DE5B25E0818A579CE04DDA",
  "75E007843A23FD76E0A5870289F592681E9D2FC0FD1893A3C35A08CE9497A4838EBA42DCFF6",
  "7D49000E1C92070BFE81E510C18733D1AAF67F34D0301EA2E784DE167B12B0CCA5EA4AE4618",
  "8915FF5716473711F41060E86FAFC7EB8638A839F35FBD7F68BF754FC645F5A76BF087FB2D",
  "701EDE9E3EC4AD42B21DA83B996CE3142D1C682467F55C413D7BE6EBB2B74E564A6C392E05F"
};

const char *N = "80905EE5CF3B32209AB2269E8B931BE7AE095015EF4DD7E53DD0C5EB17C7E6D2E4C4050D1A1";
const char *P = "910158210856461747725414804496012924518089379";
const char *Q = "1123986365521089408372317294139893016225063659";

u8 MDS[8][8] =
{
  {2,127,4,7,211,179,12,79},
  {79,2,127,4,7,211,179,12},
  {12,79,2,127,4,7,211,179},
  {179,12,79,2,127,4,7,211},
  {211,179,12,79,2,127,4,7},
  {7,211,179,12,79,2,127,4},
  {4,7,211,179,12,79,2,127},
  {127,4,7,211,179,12,79,2}
};

const u8 iMDS[8][8] = 
{
  {188, 114,   3, 126,  11, 149, 248,  21},
  { 21, 188, 114,   3, 126,  11, 149, 248},
  {248,  21, 188, 114,   3, 126,  11, 149},
  {149, 248,  21, 188, 114,   3, 126,  11},
  { 11, 149, 248 , 21 ,188 ,114,   3, 126},
  {126,  11, 149, 248,  21, 188, 114,   3},
  {  3, 126,  11, 149, 248,  21, 188, 114},
  {114,   3, 126,  11, 149, 248,  21, 188}
};

// Base64
void mpz_to_string(char *str, mpz_t op)
{
  char *ptr = str;
  mpz_t n;
  long l,i;
  
  mpz_init_set(n, op);
  l = mpz_sizeinbase(n, 64);
  
  for(i=l-1; i >= 0; --i)
    str[i] = dictionary[mpz_tdiv_q_ui(n, n, 64)];
  
  mpz_clear(n);
}

// Multiplication over F_2[x]/m
u8 gmul(u8 a, u8 b, u8 m)
{
  u8 t=0,s;
  while(b)
  {
    if(b&1) t^=a;
    b >>= 1;
    s = a&0x80;
    a <<= 1;    
    if(s) a ^= m; 
  }
  return t;
}

u8 gpow(u8 a, u8 e, u8 m)
{
  u8 s = a;
  u8 b = 0x80;
  while(b>1)
  {
    b >>= 1;
    s = gmul(s, s, m);
    if( e & b ) s = gmul(s, a, m);
  }
  return s;
}

u8 ginv(u8 a, u8 m)
{
  return gpow(a, 254, m);
}

// Matrix-vector multiplication in F_2[x]/0x1A9
void MDS_multiply(u8 b[8])
{
  u8 r,v[8];
  u32 i,j;
  
  for(i=0; i < 8; ++i)
  {
    r=0;
    for(j=0; j < 8; ++j)
      r ^= gmul(b[j], iMDS[i][j], 0xA9);
    v[i] = r;
  }
  
  for(i=0; i < 8; ++i)
    b[i] = v[i];
}

int gaussj(u8 c[4][4], u8 in[4][4])
{
  u8 b[4][4] = {{1,0,0,0},{0,1,0,0},{0,0,1,0},{0,0,0,1}};
  u8 a[4][4];
  u8 p[4], q;
  u32 i,j,col,n;
  
  for(i=0; i < 4; ++i)
    for(j=0; j < 4; ++j)
      a[i][j] = in[i][j];
  
  for(col=0; col < 4; ++col)
  {
    q=a[col][col];
    for(i=0;i < 4;++i)
      p[i]=a[i][col];
    for(i=0;i < 4;++i)
    {
      if(i!=col)
      {
        for(j=0;j < 4;++j)
        {
            a[i][j] = gmul(q,a[i][j],0x4D) ^ gmul(p[i],a[col][j],0x4D);
            b[i][j] = gmul(q,b[i][j],0x4D) ^ gmul(p[i],b[col][j],0x4d);
        }
      }
    }
  }
  
  for(i=0; i < 4;++i)
  {
    if(a[i][i]!=0)
    { 
      for(j=0; j < 4;++j)
        b[i][j] = gmul(b[i][j], ginv(a[i][i],0x4D), 0x4D);
      a[i][i]=1;
    }
    else
      return -1;
  }
  
  for(i=0; i < 4; ++i)
    for(j=0; j < 4; ++j)
      c[i][j] = b[i][j];
      
  return 0;
}

// Matrix multiplication over F_2[x]/14D
void matrix_multiply(u8 c[4][4], u8 a[4][4], u8 b[4][4])
{
  u32 i,j,k;
  u8 t[4][4];
  
  for(i=0; i < 4; ++i)
    for(j=0; j < 4; ++j)
      t[i][j] = 0;
  
  for(i=0; i < 4; ++i)
    for(j=0; j < 4; ++j)
      for(k=0; k < 4; ++k)
        t[i][j] ^= gmul(a[i][k], b[k][j], 0x4D);
        
  for(i=0; i < 4; ++i)
    for(j=0; j < 4; ++j)
      c[i][j] = t[i][j];
}

/* Square root modulo pq; assumes p, q = 3 (mod 4) */
void square_root(mpz_t rop, mpz_t x, mpz_t p, mpz_t q, mpz_t n)
{
  mpz_t ep, eq;
  mpz_t p1, q1;
  mpz_t a, b;
  
  mpz_init(a);
  mpz_init(b);
  
  mpz_init(p1);
  mpz_init(q1);
  
  mpz_init_set(ep, p);
  mpz_init_set(eq, q);
  
  mpz_add_ui(ep, ep, 1);
  mpz_tdiv_q_2exp(ep, ep, 2);
  mpz_add_ui(eq, eq, 1);
  mpz_tdiv_q_2exp(eq, eq, 2);
  
  mpz_powm(a, x, ep, p);
  mpz_powm(b, x, eq, q);
  
  /* CRT */
  mpz_sub_ui(p1, p, 1);
  mpz_sub_ui(q1, q, 1);
  mpz_powm(ep, q, p1, n);
  mpz_powm(eq, p, q1, n);
  mpz_mul(a, a, ep); mpz_mod(a, a, n);
  mpz_mul(b, b, eq); mpz_mod(b, b, n);
  mpz_add(rop, a, b); mpz_mod(rop, rop, n);
  
  mpz_clear(a);
  mpz_clear(b);
  mpz_clear(p1);
  mpz_clear(q1);
  mpz_clear(ep);
  mpz_clear(eq);
}


u32 TinyHash(u8 *buf, u32 len)
{
  u32 i, h=0;
  for(i=0; i < len; ++i)
    h = ( (h>>1) + buf[i] - ((h&1)<<12) ) & 0x1FFF;
  return h^0x1fed;
}

int main(int argc, char **argv)
{
  gmp_randstate_t prng;
  struct NESSIEstruct keyschedule;
  mpz_t x, y, z;
  char str[1024]={0};
  u8 payload[1024] = {0};
  u8 serial[2048] = {0};
  u32 i, j, c, hash;
  mpz_t consts[13];
  mpz_t n, p, q;
  
  static u8 M[4][4] = 
  {
    {0x07, 0x35, 0x09, 0x03}, 
    {0x04, 0x0B, 0x01, 0x39}, 
    {0x0B, 0x2E, 0x24, 0x02}, 
    {0x2A, 0x1B, 0x2D, 0x31}
  };
  
  static u8 iM[4][4] = 
  {
    {0x69, 0xEC, 0x42, 0xD9}, 
    {0xB8, 0xBC, 0xCE, 0x5F}, 
    {0x36, 0x4D, 0xD4, 0xC6}, 
    {0x93, 0xC8, 0x78, 0x9E}
  };
  
  static u8 MM[32];
  static u8 A[4][4] = {{1,0,0,0},{0,1,0,0},{0,0,1,0},{0,0,0,1}};
  static u8 B[4][4] = {{1,0,0,0},{0,1,0,0},{0,0,1,0},{0,0,0,1}};
  static u8 Z[4][4];
  
  if(argc != 2)
  {
    printf("Usage: %s <name>\n", argv[0]);
    return 0;
  }
  
  srand(__rdtsc());
  
  do
  {
	  for(i=0; i < 4; ++i)
	    for(j=0; j < 4; ++j)
	      A[i][j] = rand();
	  
	  c = gaussj(B,A); // B = A^-1
	} while(c);
  matrix_multiply(B, B, M); // B = A^(-1)*M
    
  // Initialize variables
  
  gmp_randinit_default(prng);
  gmp_randseed_ui(prng, __rdtsc());
  
  mpz_init_set_str(n, N, 16);
  mpz_init_set_str(p, P, 10);
  mpz_init_set_str(q, Q, 10);
  mpz_init(x);
  
  for(i=0; i < 13; ++i)
  {
    mpz_init_set_str(consts[i], constants[i], 16);
    mpz_invert(consts[i], consts[i], n); // C_i^-1 mod n  
  }
  
  // Begin key generation  
  
  do
  {
    mpz_t v;
    mpz_urandomm(x, prng, n);
    
    mpz_init(v);
    mpz_import(v, strlen(argv[1]), 1, 1, 0, 0, argv[1]);
    mpz_mul_2exp(v, v, 300);
    mpz_add(v, v, x);
    mpz_export(payload, &c, 1, 1, 0, 0, v);
    mpz_clear(v);
    hash = TinyHash(payload, c);
    for(i=0; i < 13; ++i)
    {
      if( (hash>>i)&1 )
      {
        mpz_mul(x, x, consts[i]);
        mpz_mod(x, x, n);
      }
    }
  } while(mpz_legendre(x,p) != 1 || mpz_legendre(x,q) != 1); // Until quadratic residue mod n
  
  // Obvious
  square_root(x, x, p, q, n);
  
  // Add the rest of serial
  mpz_mul_2exp(x, x, 13);
  mpz_add_ui(x, x, hash);
   
  mpz_init(z);
  memcpy(MM, A, 16);
  memcpy(MM+16, B, 16);  
  mpz_import(z, 32, 1, 1, 0, 0, MM);
  mpz_mul_2exp(z, z, 313);
  mpz_add(x, x, z);
  mpz_clear(z);
  
  NESSIEkeysetup("Andtherewaslight", &keyschedule); 
  
  memset(payload,0,1024);
  memset(serial,0,2048);
  mpz_export(payload, &c, -1, 1, 0, 0, x);
  
  for(i=0; i < (c+7)/8; ++i)
  {
    MDS_multiply(payload + i*8);
    NESSIEdecrypt(&keyschedule, payload + i*8, payload + i*8);
  }
  
  mpz_import(x, 8*((c+7)/8), -1, 1, 0, 0, payload);
  mpz_to_string(str, x);
  printf("Serial: %s\n", str);

  // Cleanup
  
  for(i=0; i < 13; ++i)
    mpz_clear(consts[i]);
  mpz_clear(n);
  mpz_clear(p);
  mpz_clear(q);
  mpz_clear(x);

  return 0;
}

