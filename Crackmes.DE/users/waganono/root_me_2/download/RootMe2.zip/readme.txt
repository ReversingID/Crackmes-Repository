###########################
#  RootMe #2 by waganono  #
###########################

It's another crypto-keygenme a bit more difficult than previous one.
You have to write a keygen, there are many solutions for a given username.

Modular arithmetic must be you friend here too :)

Please root me!

16/03/2011