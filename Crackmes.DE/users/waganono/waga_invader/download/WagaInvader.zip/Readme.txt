##################################
#  WAGA-INVADER CRYPTO KEYGENME  #
#              by                #
#           waganono             #
##################################

Type : Crypto signature scheme
Level : 5
Config : need OpenGL :)



You have to code a keygen to enter secret level area, yes! it's a game.
The verification algorithm is quiet easy (and short) to understand.
No anti-reversing tricks!

Don't patch or you'll burn in hell :)


I hope you'll broke it!


Waganono

wokanono@gmail.com
http://melzas.free.fr
