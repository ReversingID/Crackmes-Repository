###########################
#  RootMe #1 by waganono  #
###########################

It's a standard crypto-keygenme.
You have to write a keygen.

No anti-debug tricks.
Modular arithmetic must be you friend :)

13/02/2011