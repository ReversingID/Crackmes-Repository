import sys,math

def to_base36(x):
	result = []
	while x:
		x, mod = divmod(x, 36)
		result.append("QZM9GYLDR4BKS6PH7FX3TNW1A20J5C8VOEIU"[mod])
	return "".join(reversed(result))


if len(sys.argv) != 2:
    quit()

c = int(sys.argv[1], 10)
print sys.argv[1], '=', to_base36(c)