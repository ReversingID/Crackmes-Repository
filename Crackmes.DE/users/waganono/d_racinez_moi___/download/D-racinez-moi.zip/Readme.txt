///////////////////////////////
// D-Racinez moi... KeyGenMe //
// by Waganono               // 
// French crypto touch!      //
///////////////////////////////

Hello

It's my first keygenme, i hope you will love it!
It has been tested on Win XP and 2000 (basic install).

Level : 3 but all is relative...

Skill : loving bignums :)

TO_DO:
	- Find a serial for name : Waganono
	- Make a keygen
	- Make a tutorial (focalize on the algorithm, don't lose your time)

Advices:
	- Try to understand the strange form of the serial
	- Keygen can be hard to build, it depends on the library you will use.
	- There aren't junk and others obfuscations in serial verification.
	- There is only one trick, be careful!

I hope you will enjoy this one!

contact : wokanono@gmail.com