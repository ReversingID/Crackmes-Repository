﻿Public Class Form1

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        On Error Resume Next
        Dim a, b, btemp As Object
        Dim i, temp, carry As Integer
        Dim tempserial, prueba As String
        '--------------------------------------------------------
        a = 1
        b = 0
        carry = 0
        temp = 0
        'Preparo a y b-------------------------------------------
        If Len(TextBox1.Text) > 1 And Len(TextBox1.Text) < 8 Then
            For i = 1 To Len(TextBox1.Text)
                a = a * Asc(Mid(TextBox1.Text, i, 1))
                b = b + Asc(Mid(TextBox1.Text, i, 1))
            Next
            'preparo btemp---------------------------------------
            'you can use an array too
            btemp = b
            For i = 1 To 21
                btemp = btemp & b
            Next
            'Preparo el serial-----------------------------------
            prueba = a
            For i = 1 To Len(prueba)
                temp = Mid(btemp, i, 1) Xor Mid(a, i, 1)
                temp = temp + carry
                If temp > 9 And i <> Len(prueba) Then
                    temp = Mid(temp, 2, 1)
                    carry = 1
                Else
                    carry = 0
                End If
                tempserial = tempserial & temp
            Next
            If temp > 9 And i > Len(prueba) Then
                tempserial = StrReverse(tempserial)
                tempserial = Mid(tempserial, 3, Len(tempserial))
                tempserial = temp & tempserial
                TextBox2.Text = tempserial
            Else
                tempserial = StrReverse(tempserial)
                TextBox2.Text = tempserial
            End If
        Else
            TextBox2.Text = "Min 2 - Max 7 chars"
        End If
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        System.Diagnostics.Process.Start("http://crackmes.de/users/deurus/")
    End Sub
End Class
