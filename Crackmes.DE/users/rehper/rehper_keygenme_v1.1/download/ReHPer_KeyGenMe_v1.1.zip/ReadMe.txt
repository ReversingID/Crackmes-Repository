ReHPer KeyGenMe v1.1

Date: 10.03.07

Compiler - Delphi 7.1+ ReHPer(r) Edition (c) VCL Library

Packed - NONE :D

Level: 3-4/10

Report.
 Added:
  [!] Added BASE64 Encode function;
  [!] New Style;
  [x] Productivity in function GetComputerName is increased;

Mission:
 Dont not patching!
   1). Search valid serial.
   2). Write working keygen.
   3). Write tutorial.
   4). Send to crackmes.de

Example:
 Name: ReHPer
 Serial: JbGnCZKnDJWrCJSmC30m

Good Luck!

ReHPer. (Saint-Petersburg, Khabarovsk) ;)
