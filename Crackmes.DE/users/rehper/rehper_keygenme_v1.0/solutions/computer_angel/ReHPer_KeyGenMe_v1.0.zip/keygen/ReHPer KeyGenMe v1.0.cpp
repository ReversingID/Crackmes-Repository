// ReHPer KeyGenMe v1.0.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>
#include <stdio.h>
#include <conio.h>



int _tmain(int argc, _TCHAR* argv[])
{
	CHAR buffer[100];
	size_t count;
	int sum=1;
	byte index;

	ZeroMemory(&buffer,100);
	printf("Input username(lowercase please):");
	_cgets_s((PCHAR)buffer,100,&count);

	int length = strlen(buffer)+2;
	buffer[length-1]=0;
	if ( length )
	{
		index = 1;
		do
		{
			sum += buffer[index-1];
			__asm {
				pushad;
				pushfd;
				mov ecx,sum
					ror ecx,6
					add ecx,1
					mov sum,ecx
					popfd;
				popad;
			};
			++index;
			--length;
		}
		while ( length );
	}
	sum = ~sum;

	int size=256;
	char sComputerName[256];
	ZeroMemory(sComputerName,size);
	GetComputerNameA(sComputerName,(LPDWORD)&size);
	printf("Serial number = %08X%s\n",sum,sComputerName);

	getchar();
	return 0;
}

