;););););););););););););););););););););););););););););););););););););););););););););););););

SpiderNet's Second Crackme for the RoyalAccezz Krew (www.royalaccezz.net)

;););););););););););););););););););););););););););););););););););););););););););););););););



There are two goals in this crackme

Goal 1:
###############

Just as normal as every other crackme ;)

The serial is the password for the included file which contains the source code of this crackme ;)

###############



Goal 2:
###############

Only for the REAL crackers

Try to do it with SoftIce!!!!!

###############


Btw, this crackme is made in VB6.0, so you should change the normal
Visual Basic changes in your WinIce.dat
I'm sure you know which I mean.......

Good Luck!