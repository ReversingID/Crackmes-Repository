/*** fusS' Crackme #5 Keygen by Sphinx [04/29/2001] ************************/

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <string.h>

void main()
{
  char Name[27];
  unsigned long int ebx,ecx,tmp;
  int i;
  FILE *regf;
  char *path ="REGEDIT4\n\n"
              "[HKEY_LOCAL_MACHINE\\SOFTWARE\\TrickSoft\\fusS\\Crackme05]\n";

  puts("\nfusS' Crackme #5 Keygen by Sphinx [04/29/2001]\n");

  Name[0] = 26;
  printf("Enter your name: ");
  cgets(Name);
  if (Name[1] < 1)
  {
    printf("\nError: Name should be >= 1 character.\n");
    exit(0);
  }
  ecx = 0;
  for (i = 2; i <= Name[1]+3; i++)
  {
    ebx = Name[i];
    if (ebx == 0) break;
    tmp = Name[i+1] << 8;
    ebx = ebx + tmp;
    ebx = ebx * ebx;
    ecx = ecx + ebx;
  }
  ecx = ecx + 0xBAB1E5L;
  ecx = ecx + 0xC6;
  ecx = ecx * 0xDEADBEEFL;
  ecx = ecx - 0xDEADBEEFL;

  regf = fopen("REGGO.REG", "w+t");
  strcpy(Name, Name+2);
  fprintf(regf,"%s",path);
  fprintf(regf,"%cUserName%c=%c%s%c\n",0x22,0x22,0x22,Name,0x22);
  fprintf(regf,"%cMagicValue%c=%c%ld-[TS]%c\n",0x22,0x22,0x22,ecx,0x22);
  fclose(regf);

  printf("\n\nREGGO.REG generated. Import this to the registry.\n");
}
