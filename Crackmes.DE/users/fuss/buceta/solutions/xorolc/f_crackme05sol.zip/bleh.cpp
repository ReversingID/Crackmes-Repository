#include <windows.h>
#include <stdio.h>
#include <string.h>

int main(){

unsigned char Name[50]={0};
unsigned char Code[25]={0};
long mn=0;
	

printf("Please enter your name: ");
gets(Name);

asm{
	XOR ECX, ECX
	XOR EBX, EBX
	LEA EAX, DWORD PTR [Name]
    J1:
	MOV BL, BYTE PTR [EAX]
	CMP BL, 00
	JE J2
	MOV BH, BYTE PTR [EAX+1]
	IMUL EBX, EBX
	ADD ECX, EBX
	XOR EBX, EBX
	INC EAX
	JMP J1
    J2:
	ADD ECX, 0BAB1E5h
	ADD ECX, 0C6h
	IMUL ECX, 0DEADBEEFh
	SUB ECX, 0DEADBEEFh
	MOV [mn], ECX
    }
sprintf(Code,"%d",mn);
strcat(Code,"-[TS]");
printf("Your Code is: %s",Code);
getchar();

return 0;
}