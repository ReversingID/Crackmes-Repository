#include <iostream.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <fstream.h>

char yesno;
char name[100];
long serial[3];
int zaehler=0, i;


void main () {

	cout<<"------------------------------------\n Keygen for fusS' crackme #05\n by Yoschi (01/05/2001)\n------------------------------------\n\n";
	
	start:
	cout<<"\nName: ";
	ofstream out("regIt.reg");
	zaehler=0;
	serial[0]=0;
	serial[1]=0;
zasdf:
	name[zaehler]=getch();
	switch(name[zaehler])
		{
		case (char)13:
		zaehler--;
		goto write;

		case (char)8:
		if(zaehler>0){
		cout<<(char)8<<(char)32<<(char)8;
		zaehler--;
		serial[0]=name[zaehler-1]+(name[zaehler]*0x100);
		serial[1]-=serial[0]*serial[0];}
		goto zasdf;

		default:
		cout<<name[zaehler];
		if((int)name[zaehler]<0){
			cout<<"\n Bitte keine Sonderzeichen! ("<<(char)name[zaehler]<<")\n";
			goto end;}
		if(zaehler>0){
		serial[0]=name[zaehler-1]+(name[zaehler]*0x100);
		serial[1]+=serial[0]*serial[0];}
		zaehler++;
		goto zasdf;
		}
write:
	serial[1]+=name[zaehler]*name[zaehler];
	if(zaehler<1){
	goto start;}
	if(zaehler>29){
	cout<<"\nMaximal 30 Zeichen!\n";
	goto start;}
	serial[1]+=0x0BAB1E5+0xC6;
	serial[1]*=0x0DEADBEEF;
	serial[1]-=0x0DEADBEEF;

	out<<"REGEDIT4\n\n"<<(char)91<<"HKEY_LOCAL_MACHINE"<<(char)92<<"Software"<<(char)92<<"TrickSoft"<<(char)92<<"fusS"<<(char)92<<"Crackme05"<<(char)93<<"\n";
	out<<(char)34<<"UserName"<<(char)34<<"="<<(char)34;
	i=zaehler;
	zaehler=0;
	while(zaehler<=i){
	out<<(char)name[zaehler];
	zaehler++;}
	out<<(char)34<<"\n"<<(char)34<<"MagicValue"<<(char)34<<"="<<(char)34<<serial[1]<<"-[TS]"<<(char)34<<"\n\n";
	
	cout<<"\n\nDeine Daten sind:\nName : ";
	zaehler=0;
	while(zaehler<=i){
	cout<<(char)name[zaehler];
	zaehler++;}
	cout<<"\nKey  : "<<serial[1]<<"-[TS]\n\nUm die Daten automatisch in die Registry einzutragen, einfach die\nerstellte Datei 'regIt.reg' ausfuehren!";
end:
}