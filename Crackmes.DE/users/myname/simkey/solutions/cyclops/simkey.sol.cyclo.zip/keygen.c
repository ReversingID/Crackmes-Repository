/* 
	KeyGen For [simkey by theone] By Cyclops
	Protection : Simple Math using floating point numbers
*/

#include <stdio.h>
#include <string.h>

main()
{
	char szName[0x20];
	int iLen,Serial;

	printf("Enter ur name :");
	scanf("%s",szName);

	iLen = strlen(szName);
	Serial = iLen;
	Serial ^= 0x138;
	Serial *= iLen;
	Serial += iLen;

	printf("Serial: %d\n",Serial);
	return 0;
}