#include <gmp.h>
#include <time.h>
#include <Windows.h>
#include "../dl_rho/dl_rho.h"

int main(int argc,char **argv)
{
	mpz_t x,g,h,p,pp[8];
	/*
	mpz_init_set_str(pp[0],"2",10);
	mpz_init_set_str(pp[1],"5751247",10);
	mpz_init_set_str(pp[2],"81514567",10);
	mpz_init_set_str(pp[3],"273749507",10);
	mpz_init_set_str(pp[4],"85717369999",10);
	mpz_init_set_str(pp[5],"254289209159",10);
	mpz_init_set_str(pp[6],"254289208463",10);
	mpz_init_set_str(pp[7],"2255442769",10);
	mpz_init_set_ui(x,0);
	mpz_init_set_str(g,"1248310966923498661164204883260437277137373139593887776277032788073",10);
	mpz_init_set_str(h,"11223344556677",10);
	mpz_init_set_str(p,"3208758980294089871636889325639601519765013105042818745876534106523",10);
	*/
	mpz_init_set_str(pp[0],"2",10);
	mpz_init_set_str(pp[1],"7168407357706591259",10);
	mpz_init_set_ui(x,0);
	mpz_init_set_str(g,"7",10);
	mpz_init_set_str(h,"12656518762122073451",10);
	mpz_init_set_str(p,"14336814715413182519",10);
	int aaa=clock();
	solvedlp_rho(x,g,h,p,pp,2);
	aaa=(clock()-aaa);
	char cTime[100]="";
	itoa(aaa,cTime,10);
	MessageBoxA(0,cTime,"It took",0);
	return 0;
}

