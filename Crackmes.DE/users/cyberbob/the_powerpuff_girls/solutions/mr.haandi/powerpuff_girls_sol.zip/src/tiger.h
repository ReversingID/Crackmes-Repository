#ifndef TIGER_H
#define TIGER_H
typedef unsigned long long int word64;
typedef unsigned long word32;
typedef unsigned char byte;
void tiger(word64 *str, word64 length, word64 res[3]);
#endif
