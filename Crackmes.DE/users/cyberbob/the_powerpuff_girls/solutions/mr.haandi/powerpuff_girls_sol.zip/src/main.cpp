//GMP binaries can be found here: http://fp.gladman.plus.com/computing/gmp4win.htm
#include <windows.h>
#include <stdio.h>
#include "resource.h" 
#include "sha1.h"
#include "rc2.h"
#include "tiger.h"
#include "dl_rho.h"
#include "rels.h"
#include <gmp.h>

HINSTANCE	hInst ;
HWND		hWnd;
const unsigned char szPW[19]="Corn flakes & Milk";
char szPW2[9]="";
const char szModulus[30]="2B5CF397E91B4376A51DA3";
const char szConstant[30]="C1CE280BD21C8D573609D";
struct factorbase 
{
	int ne;
	int *data;
	mpz_t P;
};
#define NADDELEMENTS 100
void DLP(mpz_t *lpy,mpz_t *lpx){
	char buf[255];
	mpz_t a,pub;
	
	mpz_init_set_ui(pub,7);


	mpz_init_set(a,*lpy);

	mpz_t p,g, *log, pp, r, t, R,b, addstep[NADDELEMENTS],mulstep[NADDELEMENTS];;
	gmp_randstate_t state;
	factorbase *fbase=new factorbase;
	int *e,i,j,group;
	mpz_init(p); mpz_init(g);
	gmp_sscanf(szRelations[0],"%Zd:%Zd:%d",p,g,&(fbase->ne));
	mpz_init(pp); mpz_sub_ui(pp,p,1);
	fbase->data=new int[fbase->ne];
	e=new int[fbase->ne];
	log=new mpz_t[fbase->ne];
	mpz_init_set_ui(fbase->P,1);
	for (int i=0;i!=fbase->ne;i++)
	{
		mpz_init(log[i]);
		gmp_sscanf(szRelations[i+1],"%d:%Zd",&fbase->data[i],log[i]);
		mpz_mul_ui(fbase->P,fbase->P,fbase->data[i]);
	}
	gmp_randinit_default(state);
	gmp_randseed_ui(state,GetTickCount());
	for (j=0;j!=NADDELEMENTS;j++)
	{
		mpz_init(addstep[j]);
		mpz_urandomm(addstep[j],state,pp);
		mpz_init(mulstep[j]);
		mpz_powm(mulstep[j],g,addstep[j],p);
	}
	mpz_t l1,l2;
	mpz_init(R); mpz_init(r); mpz_init_set_ui(b,0);  mpz_init_set_ui(t,1);
	for (;;)
	{
		group=*(t->_mp_d) % NADDELEMENTS;
		mpz_add(b,b,addstep[group]);
		mpz_mul(t,t,mulstep[group]); mpz_mod(t,t,p);
		mpz_mul(r,t,a); mpz_mod(r,r,p);
		mpz_powm_ui(R,fbase->P,256,r);

		if (mpz_cmp_ui(R,0)==0)
		{
			for (j=0;j!=fbase->ne;j++) e[j]=0;
			for (j=0;j!=fbase->ne;j++) 
			{
				while (mpz_divisible_ui_p(r,fbase->data[j])!=0)
				{e[j]++;mpz_divexact_ui(r,r,fbase->data[j]);}
			}
			mpz_set_ui(r,0);
			for (j=0;j!=fbase->ne;j++)
				mpz_addmul_ui(r,log[j],e[j]);
			mpz_mod(r,r,pp); mpz_mod(b,b,pp);
			mpz_add(r,r,pp); mpz_sub(r,r,b); mpz_mod(r,r,pp);
			mpz_set(*lpx,r);
			break;
		}
	}
}
unsigned int GetChecksum(unsigned char *btBuffer,char *tigerhash){
	unsigned char btChecksumBuffer[0x40]={};
	int iCounter=0;
	for (int i=0x3F;i>0;i--)
	{
		if (btBuffer[i]){
			btChecksumBuffer[iCounter]=btBuffer[i];
			iCounter++;
		}
	}
	unsigned int uiChecksum=0xFFFFFFFF;
	for (int i=0;i!=iCounter;i++)
	{
		uiChecksum^=btChecksumBuffer[i];
		for (int j=0;j!=8;j++)
		{
			if (uiChecksum & 1){
				uiChecksum>>=1;
				uiChecksum^=0xEDB88320;
			}
			else{
				uiChecksum>>=1;
			}

		}
	}
	unsigned char btTiger[24];
	tiger((word64*)btChecksumBuffer,iCounter,(word64 *)btTiger);
	for (int i=0;i!=24;i++)
	{
		sprintf(tigerhash+i*2,"%02X",btTiger[i]);
	}
	return uiChecksum;
}
#define POS(x) ((unsigned char *)memchr(btTransposition,x,0x100)-btTransposition)
void Action()
{
	char szTigerHash[49];
	unsigned char btTransposition[0x100];
	char szName[0x20]="";
	char szCompany[0x20]="";
	
	GetDlgItemTextA(hWnd,IDC_NAME,szName, 19);
	if (!szName[0]){
		SetDlgItemTextA(hWnd,IDC_SIGNATURE,"Invalid data!");
		return;
	}
	GetDlgItemTextA(hWnd,IDC_COMPANY,szCompany, 19);
	if (!szCompany[0]){
		SetDlgItemTextA(hWnd,IDC_SIGNATURE,"Invalid data!");
		return;
	}
	unsigned char btData[0x4E]={};
	unsigned char btNewData[0x4E]={};
	memcpy(btData+0x20,szName,0x20);
	memcpy(btData,szCompany,0x20);
	unsigned int uiChecksum=GetChecksum(btData,szTigerHash);
	for (int i=0;i!=0x100;i++)
		btTransposition[i]=(uiChecksum & 0xFF)+i+1;
	btData[0x48]=0xC7;
	btData[0x49]=0xC4;

	*((unsigned int *)(btData+0x4A))=uiChecksum;

	unsigned short xkey[64];
	rc2_keyschedule(xkey,szPW,18,0);
	for (int i=0;i!=0x20;i+=8)
		rc2_encrypt(xkey,(unsigned char *)btData+i,(unsigned char *)btData+i);
	memcpy(btNewData,btData,0x4E);

	*((unsigned int *)(btNewData+0x44))=1;
	btNewData[0]=POS(btData[0]);
	for (int i=1;i!=0x20;i++)
	{
		POS(btData[i-1])<POS(btData[i])?(*((unsigned int *)(btNewData+0x44))|=(1<<i)):true;
		POS(btData[i-1])>POS(btData[i])?(btNewData[i]=POS(btData[i-1])-POS(btData[i])):(btNewData[i]=POS(btData[i])-POS(btData[i-1]));
	}
	unsigned int uiTemp=(*((unsigned int *)(btNewData+0x44)))>>1;
	sprintf(szPW2,"%02X%02X%02X%02X",(uiTemp & 0xFF),((uiTemp>>8) & 0xFF),((uiTemp>>16) & 0xFF),((uiTemp>>24) & 0xFF));
	rc2_keyschedule(xkey,(unsigned char*)szPW2,8,0);
	for (int i=0x20;i!=0x20+0x20;i+=8)
		rc2_encrypt(xkey,(unsigned char *)btData+i,(unsigned char *)btData+i);
	*((unsigned int *)(btNewData+0x40))=0;
	for (int i=0x20;i!=0x20+0x20;i++)
	{
		POS(btData[i-1])>POS(btData[i])?(*((unsigned int *)(btNewData+0x40))|=(1<<i)):true;
		POS(btData[i-1])>POS(btData[i])?(btNewData[i]=POS(btData[i-1])-POS(btData[i])):(btNewData[i]=POS(btData[i])-POS(btData[i-1]));
	}
	for (int i=0x1E;i>=0;i--)
		btNewData[i]=(btNewData[i]-btNewData[i+1])^btNewData[i+1];
	FILE *f=fopen("GoGirls.dat","wb");
	fwrite(btNewData,1,0x4E,f);
	fclose(f);
	
	//serial processing (first part)
	char szSerial[1024]="";
	char szTemp[256];
	mpz_t mod,x1,tig,x2,x3,x4,s1,s2,s3;
	mpz_init_set_str(mod,"2B5CF397E91B4376A51DA3",16);
	mpz_init_set_str(x1,"3",16);
	mpz_init_set_str(tig,szTigerHash,16);
	mpz_powm(x1,x1,tig,mod);
	
	mpz_init_set_ui(s1,7);
	mpz_init_set_str(x2,"C1CE280BD21C8D573609D",16);
	mpz_powm(x2,x2,s1,mod);
	mpz_invert(x2,x2,mod);
	mpz_mul(x1,x1,x2);
	mpz_mod(x1,x1,mod);
	gmp_sprintf(szTigerHash,"%ZX",x1);
	mpz_init_set_ui(s2,0);
	DLP(&x1,&s2);
	
	
	//serial processing (last part)
	mpz_t hn1,hn2,hc1,hc2;
	SHA1_CTX context; unsigned char digest[20];
	SHA1Init (&context); SHA1Update (&context, (unsigned char*)szName, strlen(szName)); SHA1Final (digest, &context);
	int i=0; for (i=0;i!=20;i++) sprintf(szTemp+i*2,"%02X",digest[i]);
	*(szTemp+i*2)=0;
	mpz_init_set_str(hn1,szTemp,16);
	mpz_init(hn2); mpz_nextprime(hn2,hn1);
	SHA1Init (&context); SHA1Update (&context, (unsigned char*)szCompany, strlen(szCompany)); SHA1Final (digest, &context);
	for (i=0;i!=20;i++) sprintf(szTemp+i*2,"%02X",digest[i]); *(szTemp+i*2)=0;
	mpz_init_set_str(hc1,szTemp,16); 
	mpz_init(hc2); mpz_nextprime(hc2,hc1);
	
	//Chinese remainder theorem evaluation
	mpz_t m; mpz_init(m);
	mpz_init_set_ui(s3,0);

	mpz_invert(m,hc2,hn2); mpz_mul(m,m,hc2); mpz_addmul(s3,m,hn1);
	mpz_invert(m,hn2,hc2); mpz_mul(m,m,hn2); mpz_addmul(s3,m,hc1);
	mpz_mul(m,hc2,hn2); mpz_mod(s3,s3,m);

	gmp_sprintf(szSerial,"%ZX-%ZX-%ZX",s1,s2,s3);
	SetDlgItemTextA(hWnd,IDC_SIGNATURE,szSerial);
}

VOID Initialization()
{
	SetDlgItemTextA(hWnd,IDC_DATA,"MR.HAANDI");
	SetDlgItemTextA(hWnd,IDC_DATA2,"Crypto Corner");
	SetDlgItemTextA(hWnd,IDC_SIGNATURE,"...this can take up to several minutes...");
	return;
}

void ShowInfo(){
	char AboutMsg[400]="cyberbob's The PowerPuff Girls\n\n"
		"Protection: SHA1, RC2, TIGER, DLP, Modular arithmetics\n\n"
		"Made by MR.HAANDI\n"
		"URL: http://mrhaandi.thecoderblogs.com\n"
		"MAIL: mrhaandi@gmail.com";

	MessageBoxA(hWnd,AboutMsg,"Info",MB_OK);
	return;
}

BOOL CALLBACK DlgProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam)
{
	switch(Message)
	{
	case WM_INITDIALOG:
		hWnd=hwnd;
		Initialization();
		break;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
			//case IDC_DATA: if (HIWORD(wParam)==EN_CHANGE) Action(); break;
			case IDC_ACTION: Action(); break;
			case IDC_INFO: ShowInfo(); break;
			case IDC_EXIT: EndDialog(hwnd, 0); break;
		}
		break;
	case WM_CLOSE: EndDialog(hwnd, 0); break;
	default: return FALSE;
	}
	return TRUE;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	hInst=hInstance;
	DialogBox(hInstance, MAKEINTRESOURCE(IDD_DLGMAIN), NULL, DlgProc);
	return 0;
}