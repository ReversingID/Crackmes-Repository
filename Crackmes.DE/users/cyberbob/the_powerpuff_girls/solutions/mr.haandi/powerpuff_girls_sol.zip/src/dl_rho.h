//first version of the x64dlp solver with pollard's rho algo

#ifndef DL_RHO
#define DL_RHO

#include <gmp.h>
#include <Basetsd.h>

#define ADDELCOUNT 20
#define MAXFACTORS 16

void solvedlp_rho(mpz_t x,mpz_t g,mpz_t h,mpz_t prime,mpz_t *pp,int np);

#endif