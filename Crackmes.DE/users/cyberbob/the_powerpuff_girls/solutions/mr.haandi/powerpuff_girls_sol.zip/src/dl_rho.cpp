#include "dl_rho.h"

mpz_t p;
mpz_t tVal; //used everywhere as a template value
mpz_t  re[ADDELCOUNT],rea[ADDELCOUNT],reb[ADDELCOUNT];
gmp_randstate_t state;
__int64 group=0;
mpz_t ax,ay,bx,by,rho_x,rho_y,curr_q,curr_r,subgroup_order;

void init_rho()
{
	mpz_init(ax);
	mpz_init(ay);
	mpz_init(bx);
	mpz_init(by);
	mpz_init(rho_x);
	mpz_init(rho_y);
	mpz_init(curr_q);
	mpz_init(curr_r);
	mpz_init(subgroup_order);
	mpz_init(tVal);
	gmp_randinit_default(state);
	for (int i=0;i!=ADDELCOUNT;i++)
	{
		mpz_init(re[i]);
		mpz_init(rea[i]);
		mpz_init(reb[i]);
	}
}
void finish_rho()
{
	mpz_clear(ax);
	mpz_clear(ay);
	mpz_clear(bx);
	mpz_clear(by);
	mpz_clear(rho_x);
	mpz_clear(rho_y);
	mpz_clear(curr_q);
	mpz_clear(curr_r);
	mpz_clear(subgroup_order);
	mpz_clear(tVal);
	gmp_randclear(state);
	for (int i=0;i!=ADDELCOUNT;i++)
	{
		mpz_clear(re[i]);
		mpz_clear(rea[i]);
		mpz_clear(reb[i]);
	}
}
// find q^m = r^n (mod p) with pollard's rho and improved iteration
void naive_search(mpz_t q,mpz_t r,mpz_t order,mpz_t m,mpz_t n)
{
	mpz_set_ui(m,1); mpz_set_ui(n,1);
	if (mpz_cmp(q,r)==0) return;
	mpz_init_set(tVal,r);
	while (mpz_cmp(q,tVal)!=0)
	{
		mpz_mul(tVal,tVal,r); mpz_mod(tVal,tVal,p);
		mpz_add_ui(n,n,1);
	}
	mpz_mod(n,n,order);
}
void rho(mpz_t q,mpz_t r,mpz_t order,mpz_t m,mpz_t n)
{
	INT64 rr=1,i;
	mpz_set(subgroup_order,order);
	mpz_set(curr_q,q); mpz_set(curr_r,r);
	mpz_set_ui(ax,0); mpz_set_ui(bx,0); mpz_set_ui(ay,0); mpz_set_ui(by,0);
	mpz_set_ui(m,1); mpz_set_ui(n,1); if (mpz_cmp(q,r)==0) return;
	mpz_set_ui(rho_x,1); mpz_set_ui(rho_y,1);
	//random additive walk steps
	for (i=0;i!=ADDELCOUNT;i++)
	{
		mpz_urandomm(rea[i],state,order);
		mpz_powm(re[i],q,rea[i],p);
		mpz_urandomm(reb[i],state,order);
		mpz_powm(tVal,r,reb[i],p);
		mpz_mul(re[i],re[i],tVal);
		mpz_mod(re[i],re[i],p);
	}
	// Brent's cycle finder
	do
	{
		mpz_mod(ay,ay,subgroup_order);
		mpz_mod(by,by,subgroup_order);
		mpz_set(rho_x,rho_y); mpz_set(ax,ay); mpz_set(bx,by);
		rr*=2;
		for (i=1;i<=rr;i++)
		{
			//improved iteration
			group=*(rho_y->_mp_d) % ADDELCOUNT;
			mpz_mul(rho_y,rho_y,re[group]); mpz_mod(rho_y,rho_y,p);
			mpz_add(ay,ay,rea[group]); mpz_add(by,by,reb[group]);
			if (mpz_cmp(rho_x,rho_y)==0) break;
		}
	} while (mpz_cmp(rho_x,rho_y)!=0);
	mpz_sub(m,ax,ay); mpz_mod(m,m,order);
	mpz_sub(n,by,bx); mpz_mod(n,n,order);
}
//g^x = h (mod p)
void solvedlp_rho(mpz_t x,mpz_t g,mpz_t h,mpz_t prime,mpz_t *pp,int np)
{
	int i;
	mpz_t G,H,m,n,order,rem[MAXFACTORS];
	mpz_set(p,prime);
	mpz_init(order);
	mpz_sub_ui(order,p,1);
	mpz_init(G); mpz_init(H);
	mpz_init(m); mpz_init(n);
	init_rho();
	for (i=0;i<np;i++) 
		mpz_init(rem[i]);

	gmp_randseed(state,h);
	for (i=0;i<np;i++)
	{ //pohlig-hellman algorithm
		mpz_divexact(tVal,order,pp[i]);
		mpz_powm(H,h,tVal,p);
		if (mpz_cmp_ui(H,1)==0)
		{
			mpz_set(order,tVal);
			mpz_set_ui(rem[i],0);
			continue;
		}
		mpz_powm(G,g,tVal,p);
		if (mpz_cmp_ui(pp[i],256)<0)
			naive_search(H,G,pp[i],m,n);
		else
			rho(H,G,pp[i],m,n);
		mpz_invert(m,m,pp[i]);
		mpz_mul(m,m,n);
		mpz_mod(rem[i],m,pp[i]);
		gmp_printf ("%Zd\n", rem[i]);
	}
	//eval chinese remainder theorem algorithm
	for (i=0;i!=np;i++)
	{
		mpz_divexact(m,order,pp[i]);
		mpz_invert(n,m,pp[i]);
		mpz_mul(tVal,m,n);
		mpz_addmul(x,tVal,rem[i]);
	}
	mpz_mod(x,x,order);

	gmp_printf ("%Zd\n", x);
	for (i=0;i<np;i++) 
		mpz_clear(rem[i]);
	finish_rho();
}
