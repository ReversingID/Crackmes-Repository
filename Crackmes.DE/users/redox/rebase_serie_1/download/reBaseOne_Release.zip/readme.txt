   ___  ________    _________________
  / _ \|_  / / /___/ / ___/_  <  <  /
 / // //_ <_  _/ _  / /___/_ </ // /
/____/____//_/ \_,_/\___/____/_//_/
==========================d3adc311=

[ reBase Serie ] [ number(ONE) ]
[ r3d0x@mpi.niast.tunis ]

This is the (and my) first crackme of the reBase Serie!
It's not easy neither hard.
Just Keygen it! Don't Patch it!
But if you can't, then patch it!

Features :
	WIN32.ASM
	No exe encryption, nor packing
	Many others, to discover by yourself

TODO :
	Keygen it!
	Patching not allowed, unless you can't keygen it. (But it's too easy then ^_')
	Write a tutorial, to help to new to the scene.

Contact	:
	redox@my-underworld.net, for your comments, suggestions, reviews, even blames ;)