Hello Reversers.

This is my first Crackme in a long time, hope you guys enjoy ^^.

There's basically two conditions to solve this.

1.) Find a correct password to your Username (shouldn't be too difficult)
2.) Make/Figure out the KeyGen algo for this (Hence why i'm placing this as a difficulty level 3).

The three other dll's in the directory are for the program to run, as it relies on the Qt framework. 

Enjoy :D 