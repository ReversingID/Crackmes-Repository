#include <stdio.h>
#include <stdlib.h>

#include <string.h>

int serial_gen (char *username);

int main()
{
    char username[50] = { 0 };

    printf("Username : ");
    scanf("%s", username);
    printf("\nSerial : %u\n", serial_gen(username));

    return 0;
}

int serial_gen (char *username)
{
    unsigned int part1, part2, ch, op;
    size_t i, username_len;

    part2 = 0;
    op = 0;
    username_len = strlen(username);
    for (i = 0; i < username_len; i++)
    {
        ch = username[i];

        for ( ; (op & 0xff) != ch; op++ );

        part1 = op * op;
        part1 += 0x539;
        part2 += part1;
    }

    return part2;
}
