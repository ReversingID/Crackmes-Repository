#include <stdio.h>
#include <string.h>
#include <conio.h>

int main()
{
  char username[255] = {0};
  char input[255] = {0};
  char corptag[255] = {0};
  char result[255] = {0};	
  int i=0;
	
  printf("------------------------------------\n");
  printf("----- KeyGen for Ganoes Paran  -----\n");
  printf("------------ The Key ---------------\n");
  printf("---------- By MCxCodex -------------\n");
  printf("------------------------------------\n");

  printf("\nInsert Username (no spaces): ");
  scanf("%s", username);
  printf("\nInsert Corp Tag (no spaces): ");
  scanf("%s", input);
  printf("\nPassword: ");

  while (strlen(corptag) < strlen(username)) 
  {
    strcat(corptag, input);	             
  }

  for(i=0; i < (strlen(username)); i++)
  {
    result[i] += (username[i] + corptag[i]) - 0x96;		
  }	

  printf("%s", result);
  printf("\n\n\nPress any key to quit...");  
  getch();		    
  return 0;
}
