-- TRVCrackme v1.0

This is a little experiment so something can go wrong. If you find any bug e-mail me :)

You must achieve the following tasks:

1) Understand how the crackme works.
2) Get a valid serial.
3) Create a keygen.
4) Write a tutorial explaining how you solved it.

Solutions must be sent to crackinglandia@gmail.com.
