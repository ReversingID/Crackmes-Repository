#include <windows.h>
#include <stdio.h>
#include <conio.h>

CHAR HD[10];

int main(int argc, char* argv[])
{
	CHAR lpVolumeNameBuffer[MAX_PATH], lpFileSystemNameBuffer[MAX_PATH];
	DWORD lpVolumeSerialNumber, lpMaximumComponentLength, lpFileSystemFlags;

	// Welcome :)
	printf("Keygen for bringola's Bring_Crackme\n Writen by Coderess\n\n");


	// Calculate HD from disc C
	GetVolumeInformation("C:\\", lpVolumeNameBuffer, sizeof(lpVolumeNameBuffer),
						 &lpVolumeSerialNumber, &lpMaximumComponentLength, 
						 &lpFileSystemFlags, lpFileSystemNameBuffer,
						 sizeof(lpFileSystemNameBuffer));

	DWORD sum=0;
	wsprintf(HD, "%X", lpVolumeSerialNumber);
	DWORD sl=strlen(HD);

	// Calculate SUM of HD
	for (DWORD i=0; i<sl; i++) {
		sum+=HD[i];
	}

	// Calculate key
	DWORD x1 = 0x49EB98 - sum;

	// Print key
	printf("HD=%s\n", HD);
	printf("Key1=%C%u\n\n",'A', x1);
	printf("Key2=%C%i\n\n",'S', -(x1));

	getchar();
	
	return 0;
}


