#include <stdio.h>
#include <windows.h>
#include <commctrl.h> 
#include "resource.h"
#include "miracl.h"
#include "global.h"
#include "md5.h"
#include "md5c.c"
#pragma comment(lib, "comctl32.lib")

HINSTANCE	hInst;
long md5hash[3];
long table[8*4];
char name[32];
char serial[129];	
MD5_CTX context;	
big big_table,tmp,ep,eq,pp[2],rem[2];
big_chinese bc;

BOOL CALLBACK DialogProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{	
	int i;
	miracl *mip=mirsys(5000,16);
	mip->IOBASE=16;
	switch (message)
	{    
	case WM_CLOSE:
		EndDialog(hWnd,0);
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{ 
		case IDC_GENERATE:
			if (GetDlgItemTextA(hWnd,IDC_NAME,name,31)<1)
				MessageBoxA(hWnd,"You have a name don't you?","Think again:",MB_ICONWARNING);
			else
			{//hash name
				MD5Init(&context);
				MD5Update(&context,name,strlen(name));
				MD5Final(&md5hash,&context);
				//patch hash
				__asm{
				mov eax,[md5hash]
				mov al,1
				mov [md5hash],eax
				}
				//generate table
				for (i=0;i<8;i++)
				{
					table[4*i]=md5hash[0];
					table[4*i+1]=md5hash[1];
					table[4*i+2]=md5hash[2];
					table[4*i+3]=md5hash[3];
				}
				//do rsa
				mip->IOBASE=256;
				mip->INPLEN=128;
				cinstr(big_table,(char *)table);
				powmod(big_table,ep,pp[0],rem[0]);
				powmod(big_table,eq,pp[1],rem[1]);
				crt_init(&bc,2,pp);
				crt(&bc,rem,tmp);
				crt_end(&bc);
				mip->IOBASE=16;
				cotstr(tmp,serial);
				SetDlgItemTextA(hWnd,IDC_SERIAL,serial);
			}	
			break;
		case IDC_ABOUT:
			MessageBox(hWnd, "Keygenerator for TKM! official trial crackme 2\nProtection: Modular Math & modified md5", "bLaCk-eye PRESENTS:", MB_ICONINFORMATION);
			break;
		}
		break;
		case WM_INITDIALOG:
			ep=mirvar(0);
			eq=mirvar(0);
			cinstr(ep,"9FD6A8F869859893655F930FA3976E79C20295AC83585329C706364F5F3A0D662C2F9561FA2E11AC495FEEBBECAC360988498ACC8F4FDB9CF8EF730A10AD3815");
			cinstr(eq,"26DBADCBB714E0288EACA30D18744AA7DDF44662363C8B3E80558C9A173B0A20924D3CC4E36426A31D2D90F075DB7F4BF1F640BEE7AE84D73DCD0686EEAB8DB9");
			big_table=mirvar(0);
			tmp=mirvar(0);
			for (i=0;i<2;i++)
			{
				pp[i]=mirvar(0);
				rem[i]=mirvar(0);
			}
			cinstr(pp[0],"D7EAE4A5B34196FFF0B433297640FDD7438891BBFB284B1F7434F79CBECC79CD6C100E2652A3A83D934D27F18B242F4D344EA5F049940094DF0DD53BAECEFA5B");
			cinstr(pp[1],"C93FB42656EC633ED4428363F9E3146D6D9A94365113775898884A3886B5A3E9CC54E913E1DE8642FF80D35179AA39918B3902FA209C0FB41724074701ADDCD3");

		break;
	}
     return 0;
}

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{
	hInst=hInstance;
	InitCommonControls();
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_MAIN), NULL, (DLGPROC)DialogProc,0);
	return 0;
}
