#include <iostream>
using namespace std;

void main()
{
	char szName[128];
	char szPassword[128];

	cin.getline(szName, 128);

	unsigned char *s=(unsigned char *) szName;

	while(*s)
	{
		if(*s>=128)
		{
			unsigned char *c=s;
			while(*c)
			{
				*c=*(c+1);
				c++;
			}
			s--;
		}
		s++;
	}

	unsigned int crc=0;

	__asm
	{
		xor eax, eax
		lea esi, szName
	START:
		movzx   ecx, byte ptr [esi]
		test    cl, cl
		jz      EXIT
		ror     eax, 8
		sub     al, cl
		inc     esi
		jmp     START
	EXIT:
		and     eax, 0xF0F0F0F
		mov crc, eax
	}
	char *p=szPassword;
	while(crc!=0)
	{
		unsigned char cur_count=crc&0xff;
		if(cur_count==0)
		{
			__asm
			{
				mov eax, crc
				ror eax, 8
				mov crc, eax
			}
			*p='e';
			p++;
		}
		else
		{
			unsigned char count=cur_count;
			if(cur_count>8)
			{
				count=8;
				cur_count-=8;
			}
			crc-=count;
			count--;			
			unsigned char c=1;
			c=c<<3;
			c= c | count;
			c=c<<2;
			*p=c;
			p++;
			*p='F';
			p++;
			*p='K';
			p++;
		}		
	}
	*p=0;
	cout << szPassword << endl;
	system("pause");
}