#pragma warn -par
#include <windows.h>

void Pexit(int n);

int WINAPI WinMain(
    HINSTANCE hInstance,	// handle to current instance
    HINSTANCE hPrevInstance,	// handle to previous instance
    LPSTR lpCmdLine,	// pointer to command line
    int nCmdShow 	// show state of window
)
{ STARTUPINFO StartupInfo;
  PROCESS_INFORMATION ProcessInformation;
  HANDLE hProcess,hFile,hThread;
  BYTE Buffer[0x1000]; //big enough for data dump
  DWORD NumberOfBytesRead,NumberOfBytesWritten;
  DEBUG_EVENT DebugEvent;
  BOOL done;

  // i'm lazy - let's just default fill this
  GetStartupInfo(&StartupInfo);

  // create the process for the executable file
  // but it will be suspended and we are debugging it
  if(!CreateProcess(
    NULL,	// pointer to name of executable module
    "d:\\zc_11\\cme11.exe",	// pointer to command line string
    NULL,	// pointer to process security attributes
    NULL,	// pointer to thread security attributes
    TRUE,	// handle inheritance flag
    DEBUG_ONLY_THIS_PROCESS,	// creation flags
    NULL,	// pointer to new environment block
    "d:\\zc_11\\",	// pointer to current directory name
    &StartupInfo,	// pointer to STARTUPINFO
    &ProcessInformation 	// pointer to PROCESS_INFORMATION
   )) Pexit(1); // oh no, didnt start

   do
   { done=FALSE;
     // wait for it to hit the breakpoint :)
     if(!WaitForDebugEvent(
      &DebugEvent,	// address of structure for event information
      1000 	// number of milliseconds to wait for event
     )) Pexit(7); // failed ?

     // set up the breakpoint when the process has been created
     if(DebugEvent.dwDebugEventCode==CREATE_PROCESS_DEBUG_EVENT)
     { // now lets set a breakpoint in it
       // get a handle to the process
       hProcess=DebugEvent.u.CreateProcessInfo.hProcess;
       hThread=DebugEvent.u.CreateProcessInfo.hThread;
       if(hProcess==NULL)
         Pexit(2); // oh no, it failed
       if(hThread==NULL)
         Pexit(30);

       // now read the process memory at the point we have in mind
       // and check it is the right string
       if(!ReadProcessMemory(
         hProcess,	// handle of the process whose memory is read
         (LPCVOID)0x406058,	// address to start reading
         &Buffer,	// address of buffer to place read data
         5,	// number of bytes to read
         &NumberOfBytesRead 	// address of number of bytes read
         )) Pexit(3); // failed ?

       // patch it with a breakpoint
       Buffer[0]=0xcc;

       // write patch
       if(!WriteProcessMemory(
         hProcess,	// handle to process whose memory is written to
         (LPCVOID)0x406058,	// address to start writing to
         &Buffer,	// pointer to buffer to write data to
         1,	// number of bytes to write
         &NumberOfBytesWritten 	// actual number of bytes written
         )) Pexit(5); // failed ?

       // now resume it
       if(!ContinueDebugEvent(DebugEvent.dwProcessId,DebugEvent.dwThreadId,DBG_CONTINUE))
         Pexit(15);
     }
     else if (DebugEvent.dwDebugEventCode==LOAD_DLL_DEBUG_EVENT)
     { if(!ContinueDebugEvent(DebugEvent.dwProcessId,DebugEvent.dwThreadId,DBG_CONTINUE))
         Pexit(16);
     }
     else if (DebugEvent.dwDebugEventCode==UNLOAD_DLL_DEBUG_EVENT)
     { if(!ContinueDebugEvent(DebugEvent.dwProcessId,DebugEvent.dwThreadId,DBG_CONTINUE))
         Pexit(17);
     }
     else if(DebugEvent.dwDebugEventCode==EXCEPTION_DEBUG_EVENT)
     { if(DebugEvent.u.Exception.ExceptionRecord.ExceptionCode==EXCEPTION_BREAKPOINT)
       { if(DebugEvent.u.Exception.ExceptionRecord.ExceptionAddress==(LPCVOID)0x406058)
         { // second debug event hit!!!!!!!!! yay!!!!!!!!
           done=TRUE;
         }
         else if(!done)
           if(!ContinueDebugEvent(DebugEvent.dwProcessId,DebugEvent.dwThreadId,DBG_CONTINUE))
             Pexit(18);
       }
       else if(DebugEvent.u.Exception.ExceptionRecord.ExceptionFlags==EXCEPTION_NONCONTINUABLE)
         Pexit(14);
       else if(!ContinueDebugEvent(DebugEvent.dwProcessId,DebugEvent.dwThreadId,DBG_EXCEPTION_NOT_HANDLED))
            Pexit(18);
     }
     else if(DebugEvent.dwDebugEventCode==EXIT_PROCESS_DEBUG_EVENT)
     { Pexit(12);
     }
     else if(DebugEvent.dwDebugEventCode==EXIT_THREAD_DEBUG_EVENT)
     { Pexit(20);
     }
     else if(DebugEvent.dwDebugEventCode==CREATE_THREAD_DEBUG_EVENT)
     { Pexit(21);
     }
     else if(DebugEvent.dwDebugEventCode==RIP_EVENT)
     { Pexit(13);
     }
     else if(!ContinueDebugEvent(DebugEvent.dwProcessId,DebugEvent.dwThreadId,DBG_CONTINUE))
       Pexit(19);

   } while(!done);

   // now open crkme11.exe, a copy of cme11.exe
   hFile=CreateFile(
    "d:\\zc_11\\crkme11.exe",	// pointer to name of the file
    GENERIC_WRITE|GENERIC_READ,	// access (read-write) mode
    0,	// share mode
    NULL,	// pointer to security attributes
    OPEN_EXISTING,	// how to create
    FILE_ATTRIBUTE_NORMAL|FILE_FLAG_RANDOM_ACCESS,	// file attributes
    NULL 	// handle to file with attributes to copy
   );
   if(hFile==NULL)
     Pexit(22);

   // grab the sections we were after
   // section 1: this is the code section
   if(!ReadProcessMemory(
    hProcess,	// handle of the process whose memory is read
    (LPCVOID)0x401000,	// address to start reading
    &Buffer,	// address of buffer to place read data
    0x400,	// number of bytes to read
    &NumberOfBytesRead 	// address of number of bytes read
   )) Pexit(10); // failed ?
   SetFilePointer(
    hFile,	// handle of file
    0x600,	// number of bytes to move file pointer
    NULL,	// address of high-order word of distance to move
    FILE_BEGIN 	// how to move
   );
   if(!WriteFile(
    hFile,	// handle to file to write to
    &Buffer,	// pointer to data to write to file
    0x400,	// number of bytes to write
    &NumberOfBytesWritten,	// pointer to number of bytes written
    NULL 	// pointer to structure needed for overlapped I/O
   )) Pexit(34);

   // section 2: this is the data section
   if(!ReadProcessMemory(
    hProcess,	// handle of the process whose memory is read
    (LPCVOID)0x402000,	// address to start reading
    &Buffer,	// address of buffer to place read data
    0x200,	// number of bytes to read
    &NumberOfBytesRead 	// address of number of bytes read
   )) Pexit(24); // failed ?
   SetFilePointer(
    hFile,	// handle of file
    0xa00,	// number of bytes to move file pointer
    NULL,	// address of high-order word of distance to move
    FILE_BEGIN 	// how to move
   );
   if(!WriteFile(
    hFile,	// handle to file to write to
    &Buffer,	// pointer to data to write to file
    0x200,	// number of bytes to write
    &NumberOfBytesWritten,	// pointer to number of bytes written
    NULL 	// pointer to structure needed for overlapped I/O
   ))Pexit(31);

   CloseHandle(hFile);

   // ok, lets kill off the process
   TerminateProcess(hProcess,0);
   wsprintf((char *)Buffer,"Sections Dumped, last breakpoint:%lx",DebugEvent.u.Exception.ExceptionRecord.ExceptionAddress);
   MessageBox(NULL,"Completed",(char *)Buffer,MB_OK);
   return 0;
}

void Pexit(int n)
{ char i[10];
  char *lpMsgBuf;
  FormatMessage(
    FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
    NULL,
    GetLastError(),
    MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
    (LPTSTR) &lpMsgBuf,
    0,
    NULL
  );
  wsprintf(i,"Error at %d, Last ErrorCode:",n);
  MessageBox(NULL,lpMsgBuf,i,MB_OK);
  exit(n);
}