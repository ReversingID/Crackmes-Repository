#include <string.h>
#include <stdio.h>
#include <fcntl.h>
#include <process.h>
#include <io.h>
#include <sys\stat.h>

unsigned char buffer[1024];
int infile,
    len;
//16 chars  1234567890123456
char pwd[]="Congratulations.";
char dec[16];
char final_pwd[]="Yahoo... Congratulations .. Send me";
char myname[]="Cronos";
char nameenc[16];

void processstring(unsigned char *inoutstring,unsigned int length)
{ unsigned char a,b,c,l,p;
  for(p=0;p<48;p++)
  { a=0;
    for(b=0;b<16;b++)
      dec[(b+p)%16]=pwd[b]^inoutstring[b+p];
    c=0;
    l=length;
    while(l--)
    { printf("%c",inoutstring[c]^dec[a]);
      a++;
      if(a>=16)
      { a=0;
        printf("\n");
      }
      c++;
    }
    printf("\n\n");
  }
}

void main(void)
{ int i;
  unsigned long eebp,eeax,eecx;
  if ((infile=open("blah.txt",O_BINARY))==-1)
  { printf("Can't Open file\n");
    exit(1);
  }
  len=read(infile,buffer,65);
  processstring(buffer,len);
  close(infile);

  printf("addendum....code should be\n");
  for(i=0;i<strlen(final_pwd);i++)
    printf("%c",final_pwd[i]^buffer[i]);
  printf("\n");
  eebp=0x12345678;
  eecx=6;
  for(i=0;i<16;i++)
    nameenc[i]=0;
  for(i=0;i<0x60;i++)
  { eeax=myname[i%strlen(myname)];
    asm{
      push eax
      push edx
      push ecx
      mov eax,eeax
      mov edx,eebp
      mov ecx,eecx
      xor edx,eax
      add eax,ecx
      adc edx,eax
      xor eax,edx
      xchg al,cl
      ror edx,cl
      xchg al,cl
      mov eeax,eax
      mov eecx,ecx
      mov eebp,edx
      pop ecx
      pop edx
      pop eax
    }
    eecx--;
    if(eecx==0) eecx=6;
    nameenc[i%16]+=(eeax&0xff);
    if(i%16==0) printf("\n");
    printf("%2X",eeax&0xff);
  }
  printf("\n\n");
  for(i=0;i<16;i++)
    printf("%02X",(final_pwd[i]^buffer[i]));
  printf("\n");  
  for(i=0;i<16;i++)
    printf("%02X",((final_pwd[i]^buffer[i])-(nameenc[i]&0xff)+256)%256);
}
