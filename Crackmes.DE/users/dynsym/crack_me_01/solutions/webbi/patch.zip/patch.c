/* 
 * Patch done by webbi for crackme_01 from dynsym
 *
 * Compile with gcc -g -Wall -o patch patch.c
 * Exec on the same dir where crackme resides
 *
 */

#include <stdio.h>

#define FIRST_BYTE_POS 0x474
#define FIRST_BYTE_SRC_VALUE 0xF3
#define SECOND_BYTE_SRC_VALUE 0xA6
#define NEW_BYTES_VALUE 0x90

int main(){
	printf("Opening file 'crackme1'... ");
	FILE *fp = fopen("crackme1", "rb+");
	if( fp == NULL ){
		perror("Error, file cant be opened");
		return 1;
	}
	printf("Success\n");

	printf("----- Checking file -----\n");
	fseek(fp, FIRST_BYTE_POS, SEEK_SET);
	int c = fgetc(fp);
	printf("First byte should be 0xF3...\n");
	printf("Byte at 0x8048474: 0x%X... ", c);
	if( c == FIRST_BYTE_SRC_VALUE )
		printf("OK\n");
	else{ 
		printf("ERROR\n");
		return 1;
	}
	c = fgetc(fp);
	printf("Second byte should be 0xA6...\n");
	printf("Byte at 0x8048475: 0x%X... ", c);
	if( c == SECOND_BYTE_SRC_VALUE )
		printf("OK\n");
	else{
		printf("ERROR\n");
		return 1;
	}

	printf("----- Patching file -----\n");

	printf("Now patching file, changing bytes to 0x90 (NOP)...\n");
	fseek(fp, FIRST_BYTE_POS, SEEK_SET);
	putc(NEW_BYTES_VALUE, fp);
	putc(NEW_BYTES_VALUE, fp);
	fflush(fp);
	
	printf("Checking if patch was succesfully... ");
	fseek(fp, FIRST_BYTE_POS, SEEK_SET);
	c = fgetc(fp);
	if( c != NEW_BYTES_VALUE ){
		printf("ERROR\n");
		printf("Patch does not work, something goes wrong...\n");
		return 1;
	}
	c = fgetc(fp);
	if( c != NEW_BYTES_VALUE ){
		printf("ERROR\n");
		printf("Patch does not work, something goes wrong...\n");
		return 1;
	}
	printf("OK!\n");

	fflush(fp);
	fclose(fp);
	return 0;
}

