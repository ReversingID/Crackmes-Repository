/**
 * Allpermutations.java - step2
 * - It's slow.. but it's short !
 * Lucifer48
 */

public class Allpermutations {

    StringBuffer cible = new StringBuffer("0123456789");
    int cible_taille = 10;	// length of cible
    int compteur = 0;		// number of perms generated

    public Allpermutations() {
	gogogo(new StringBuffer(), cible, 0);    
	System.out.println("\n; Total : "+compteur);
    }

    public void gogogo(StringBuffer p1, StringBuffer p2, int level) {
	if (level<cible_taille) {
	  StringBuffer q1, q2;	  
	  for(int i=0; i<p2.length(); i++) {
	    q1 = new StringBuffer(p1.toString() + p2.charAt(i));
	    q2 = new StringBuffer(p2.toString());
	    q2.deleteCharAt(i);
	    gogogo(q1, q2, level+1);	    	  
	  } /* end of for */
	} else {
	  String ligne = new String("db ");
	  for(int j=0; j<cible_taille; j++) ligne = ligne + p1.charAt(j) + ",";
	  System.out.println(ligne+" 6 dup(0)");
	  compteur++;
	}
    }
    
    public static void main(String arvgs[]) {
	new Allpermutations();
    }
} /* end of class */
