/**
 * AllpermutationsBy10.java - step3
 * (will help us to make 10 buffers)
 */

public class AllpermutationsBy10 {

    final String source = "0123456789";
    StringBuffer cible;
    int cible_taille = 9;	// length of cible
    char cible_head;
    int compteur = 0;		// number of perms generated

    public AllpermutationsBy10(final int j) {
        cible = new StringBuffer(source);
	cible_head = source.charAt(j);
	cible.deleteCharAt(j);
	gogogo(new StringBuffer(), cible, 0);
	System.out.println("\n# Total : "+compteur);
    }

    public void gogogo(StringBuffer p1, StringBuffer p2, int level) {
	if (level<cible_taille) {
	  StringBuffer q1, q2;	  
	  for(int i=0; i<p2.length(); i++) {
	    q1 = new StringBuffer(p1.toString() + p2.charAt(i));
	    q2 = new StringBuffer(p2.toString());
	    q2.deleteCharAt(i);
	    gogogo(q1, q2, level+1);	    	  
	  } /* end of for */
	} else {
	  String ligne = new String(".byte "+cible_head+",");
	  for(int j=0; j<cible_taille; j++) ligne = ligne + p1.charAt(j) + ",";
	  System.out.println(ligne+" 0,0,0,0,0,0");
	  compteur++;
	}
    }
    
    public static void main(String args[]) {
        if(args.length == 0) {
	  System.out.println("Usage: java AllpermutationsBy10 [0-9]");
	  System.exit(0);
	}
	
	int i = (new Integer(args[0])).intValue();
	new AllpermutationsBy10(i);
    }
} /* end of class */
