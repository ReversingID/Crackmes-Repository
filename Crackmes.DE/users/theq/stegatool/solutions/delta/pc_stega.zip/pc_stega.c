#include <stdio.h>
static unsigned char* magic="Obscurity is not security!";
static unsigned char wanted[50];
static void encode(unsigned char*data, unsigned char* user) {
   unsigned char buffer[100];
   unsigned int i, j, v1, v2, ecx;
   unsigned char* pos=(unsigned char*)(data+0x0E);
   unsigned int bsize=*((unsigned int*)pos);
   unsigned int comp=*((unsigned int*)(pos+0x10));
   unsigned int clrused=*((unsigned int*)(pos+0x20));
   unsigned char bits=*((unsigned int*)(pos+0x0E));
   unsigned int width=*((unsigned int*)(pos+0x04));
   unsigned int height=*((unsigned int*)(pos+0x08));
   unsigned int edx, edi, k;	
   unsigned char A;
   unsigned char delta, wi;
   unsigned char*w=wanted;
   long total;
   if (comp==0x0) {
	edi=0;
   } else {
	printf("Compressed bitmaps not supported\n");
	exit(-1);
   }
   if (bsize=0x28) {
	if (clrused!=0) edx=clrused<<2;
	else if (bits<=8) edx=(1<<bits)<<2;
	else edx=0;
   } else {
	// OS2 headers
	printf("OS2 bitmaps not supported\n");
	exit(-1);
   }
   delta=(bits>>3);
   memset((void*)buffer, 0, 100);
   v1=0; v2=1; k=0; i=0;
   pos+= edi+edx+bsize;
   pos++;
   printf("\n");
   // init wanted buffer
   strcpy(wanted, user);
   for (j=0; j<strlen(wanted); j++) {	
  	wanted[j+strlen(wanted)+1]=wanted[j]^magic[j];
   }
   total=2+2*strlen(wanted);
   for (j=0; j<height; j++) {
  	if (v2==0) break;
	for (ecx=0; ecx<width*delta; ecx+=delta) {			
		if (v2==0) break;
		A=pos[ecx-1]^pos[ecx]^pos[ecx+1];
		A=(A&1); // get first bit
		k++;
		wi = ((*w)>>(8-k))&1;
		if (wi!=A) pos[ecx+1]=pos[ecx+1]^1; // modify the last bit, to take that into account for upcoming bits changes
		if (k<=8) {	
			v1=(v1+v1)|A;	
		} else {
			buffer[i]=v1;
			v1=A;
			k=1;
			i++;
			w++;
			total--;
			if (total==0) i=100;
		}	
		if (i>=100) v2=0;
	}
	pos+=(2+width*delta);
   }
}

int main(int argc, char **argv) {
	long length;
	unsigned char *data;
	FILE *fp;
	if (argc!=3) {
	   printf("usage: pc_stega <filename> <username>\n");
	   printf("This program will encode <username> into bitmap <filename>\n");
           exit(-1);
	}

	fp=fopen(argv[1], "rb");
	if (fp==NULL) {
		printf("can't open bitmap\n");
		exit(-1);
	}
	fseek(fp, 0, SEEK_END);
	length=ftell(fp);
	rewind(fp);
	data=(unsigned char*)malloc(length);
	fread(data, length, 1, fp);
	fclose(fp);
	//----------------------
	// modify data to store new user/serial
	encode(data, argv[2]);

	//----------------------
	// write new file
	fp=fopen(argv[1], "wb+");
	fwrite(data, length, 1, fp);
	fclose(fp);
	printf("%s has been tagged\n", argv[1]);
	free(data);
}

