#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <fcntl.h>
void Usage(void)
{
	fprintf(stderr,"comm <file>\n");
	exit(1);
}

int main(int argc,char* argv[])
{
	if(argc != 2)
		Usage();

	int fd = open(argv[1],0,O_RDONLY);
	if(fd == -1)
	{
		fprintf(stderr,"Can't open file %s\n",argv[1]);
		exit(1);
	}

	void* p = mmap((void*)0x10000,0x1000,PROT_EXEC | PROT_WRITE | PROT_READ,MAP_PRIVATE | MAP_FIXED,fd,0);

	if(p == MAP_FAILED)
	{
		fprintf(stderr,"MAP_FAILED\n");
		exit(1);
	}
	else
	{
		fprintf(stderr,"POINER: %p\n",p);
	}

	__asm__("mov $0x10020, %eax; jmp *%eax;");

	return 0;
}
