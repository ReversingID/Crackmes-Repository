import binascii

"""
Parse a little endian int of given size from a byte string
"""
def parse_int(data, offset, size):
	accum = ord(data[offset])
	for i in range(1, size):
		accum = accum | (ord(data[offset+i]) << (8*i))

	return accum

"""
render the given int to a little endian byte list
"""
def render_int(num, size):
	frame = [0] * size
	for i in range(0, size):
		frame[i] = ( (0xFF << (8*i)) & num ) >> 8*i
	return frame

"""
sum a contiguous set of bytes
"""
def sum_bytes(data, start, size):
	accum = 0
	for i in range(start,start+size):
		accum += ord(data[i])

	return accum

"""
replace some bytes in dst with the ones from src
"""
def replace_bytes(dst, src, start):
	return dst[0:start] + str(bytearray(src)) + dst[start+len(src):] 

"""
calculate the new checksum and replace the old one
"""
def recheck(filename):
	f = file(filename) 
	contents = f.read()

	current = parse_int(contents, 0x172, 2)

	print "current checksum is " + hex(current)

	"""
	sum all bytes in the file except last two
	"""
	new = sum_bytes(contents, 0, 0x172)


	"""
	store the new checksum in the last two bytes
	"""
	contents = replace_bytes(contents, render_int(new, 2), 0x172)

	current2 = parse_int(contents, 0x172, 2)

	print "new checksum is " + hex(current2)

	f.close()

	"""
	overwrite the input file with new patched contents
	"""
	of = file(filename, 'w')
	of.write(contents)
	of.close()

"""
decrypt the congratulations message, just for fun
"""
def decrypt_win_msg(filename):
	f = file(filename) 
	contents = f.read()

	prev = ord(contents[0x30])
	res = [""] * 8
	for i in range(0,8):
		res[i] = ((ord(contents[0x31+i]) - 0x9) ^ 0xac) ^ prev
		prev = res[i]
		res[i] = chr(res[i])

	return "".join(res)

def patch_elf(filename):

	f = file(filename) 
	contents = f.read()

	"""
	do the patch:

	ELF program headers are overlapped to the ELF header,
	therefore there are the following interesting identities:

	entry point == MemSiz
	version == FileSiz

	by a blind trial and error i found out that MemSiz should
	be equal to FileSiz in order for the loader to correctly run
	the executable.

	This means that in order to change the entry point, it is 
	necessary to change also the version field to the same value.
	"""
	contents = replace_bytes(contents, [0xe4], 0x14) #version == FileSiz
	contents = replace_bytes(contents, [0xe4], 0x18) #entry point == MemSiz


	f.close()

	"""
	overwrite the input file with new patched contents
	"""
	of = file(filename, 'w')
	of.write(contents)
	of.close()

if __name__ ==  "__main__":
	"""
	patch the code
	"""
	patch_elf("crackme.03.32")

	"""
	recalc checksum
	"""
	recheck("crackme.03.32")
	
	print decrypt_win_msg("crackme.03.32")
	