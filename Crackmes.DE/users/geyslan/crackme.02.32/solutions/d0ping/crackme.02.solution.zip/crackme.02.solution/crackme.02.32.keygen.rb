character_array = [	['g', 'w'],
					['h', 'x'],
					['a', 'q'],
					['d', 't'],
					['a', 'q'],
					['h', 'x'],
					['#', '3'],
					['l', '|'],
					['l', '|']
				]
serial = ''

9.times do	|count|
	serial << character_array[count][rand(0..1)]
end
puts "Your key is: #{serial}"
