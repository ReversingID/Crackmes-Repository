Solution to NewHitman's NH Keygenme#7
http://crackmes.de/users/newhitman/nh_keygenme7/

Difficulty: 3 - Getting harder
Platform: Windows
Language: Borland Delphi


1. Introduction
Since this Keygenme is written in Delphi, it is often a good idea to run Delphi
signatures on it (Assuming you are using IDA Pro). You can get signatures for
Delphi 6 and 7 from http://www.woodmann.com/forum/showthread.php?6372.


2. Locating the serial routine
To find the serial routine, you may set a breakpoint on every "SetTimer" call.
If you hit the "GO" Button in the Keygenme, you will break at 00436D13. Step
through the code until you reach 0047F4A5, the entry for the  serial function.
Scrolling down the code, you may notice a lot of conditional jumps to 0047F740,
the bad boy in this keygenme. You should try to get to 0047F6B0, right behind
the last conditional jump to bad boy. Patching would be really easy ;-) 


3. Ways to meet the bad boy
I won't go into detail about each conditional jump, but I am going to explain
the necessary ones to create a keygen. Let's list them up:

0047F4BD	; did you enter a username?
0047F4DB	; did you enter a password?
0047F510	; is your username five characters long?
0047F545	; is your password 20 characters long?
0047F5B4	; are the characters seven to 20 part of 0-9, A-Z ?
0047F5DA	; see above
0047F622	; (see 4.)
0047F64A	; (see 5.)
0047F6AA	; (see 6.)

4. Bruteforcing the first four characters (see .cpp, line 36)
The function 0047EE5C is called in this part to determine if the jump to the
bad boy is taken or not. At 0047EF3F the interesting part of the function 
begins:

0047EF3F mov     eax, 4					; use four chars for calculation
0047EF44 loc_47EF44:							
0047EF44 cmp     eax, 1
0047EF47 jz      short loc_47EF91
0047EF49 mov     edx, [ebp+var_8]
0047EF4C movzx   edx, word ptr [edx+eax*2]
0047EF50 mov     ecx, [ebp+var_8]
0047EF53 movzx   ecx, word ptr [ecx+eax*2-2]
0047EF58 cmp     dx, cx					; compare char n to n-1
0047EF5B jbe     short loc_47EF77
0047EF5D mov     ebx, [ebp+var_8]		; function NextLesser in .cpp
0047EF60 movzx   ebx, word ptr [ebx+eax*2]
0047EF64 movzx   ecx, cx
0047EF67 sub     ebx, ecx
0047EF69 movzx   edx, dx
0047EF6C add     ebx, edx
0047EF6E mov     edx, ebx
0047EF70 add     esi, edx
0047EF72 shl     esi, 28h
0047EF75 jmp     short loc_47EFA7
0047EF77 ; ---------------------------------------------------------------
0047EF77
0047EF77 loc_47EF77:					; function NextGreater in .cpp
0047EF77 mov     ebx, [ebp+var_8]
0047EF7A movzx   ebx, word ptr [ebx+eax*2]
0047EF7E movzx   ecx, cx
0047EF81 add     ebx, ecx
0047EF83 movzx   edx, dx
0047EF86 add     ebx, edx
0047EF88 mov     edx, ebx
0047EF8A add     esi, edx
0047EF8C shl     esi, 48h
0047EF8F jmp     short loc_47EFA7
0047EF91 ; ---------------------------------------------------------------
0047EF91
0047EF91 loc_47EF91:					; line 68 in .cpp
0047EF91 mov     edx, [ebp+var_8]
0047EF94 movzx   edx, word ptr [edx+eax*2]
0047EF98 mov     ecx, edx
0047EF9A mov     ebx, [ebp+var_8]
0047EF9D movzx   ebx, word ptr [ebx+8]
0047EFA1 add     ecx, ebx
0047EFA3 add     ecx, edx
0047EFA5 mov     edx, ecx
0047EFA7
0047EFA7 loc_47EFA7:
0047EFA7 add     esi, edx				; part of NextLesser and Nextgreater
0047EFA9 dec     eax
0047EFAA test    eax, eax
0047EFAC jnz     short loc_47EF44		; loop four times

Basically this code receives the first and the second character of the password,
compares both and modifies esi, depending on which one of both characters is 
greater (function NextLesser -> the first one is greater, function NextGreater 
-> the second one is greater).
In the next loop the second and the third character are compared, followed by 
the comparison of character three and four (see line 53, 58, 63 in .cpp). In
the last step, the code following 0047EF91 is executed (see line 68 in .cpp).
After the return of the function, the calculated value in esi is compared to:

0048A244 dword_48A244 dd 5235471Fh

A bruteforcer is needed to calculate this value, while only changing the values 
of the first four characters.  A successful bruteforce run will find the
characters 'N', 'K', 'M', '7' that have a calculated value of 5235471Fh.


5. Looking for the only valid character (see .cpp, line 83)
This part calls the function 0047EB4C at 0047F643. The function compares the
fifth character of the password to a lot of constant values, especially from 
0047EBBA to 0047EC0E. If one of the values matches the fifth character, the 
conditional jump after the return of the function is taken and we meet the bad
boy. Therefore the aim is to find a character, that does not match any of these
values:

0047EBBA mov     edx, eax
0047EBBC cmp     dx, 21h
0047EBC0 jz      short loc_47EC12		; loc_47EC12 leads to bad boy
0047EBC2 cmp     dx, 22h
0047EBC6 jz      short loc_47EC12
0047EBC8 cmp     dx, 23h
0047EBCC jz      short loc_47EC12
0047EBCE cmp     dx, 24h
0047EBD2 jz      short loc_47EC12
0047EBD4 cmp     dx, 25h
0047EBD8 jz      short loc_47EC12
0047EBDA cmp     dx, 26h
0047EBDE jz      short loc_47EC12
0047EBE0 cmp     dx, 27h
0047EBE4 jz      short loc_47EC12
0047EBE6 cmp     dx, 28h
0047EBEA jz      short loc_47EC12
0047EBEC cmp     dx, 29h
0047EBF0 jz      short loc_47EC12
0047EBF2 cmp     dx, 2Ah
0047EBF6 jz      short loc_47EC12
0047EBF8 cmp     dx, 2Bh
0047EBFC jz      short loc_47EC12
0047EBFE cmp     dx, 2Ch
0047EC02 jz      short loc_47EC12 
0047EC04 cmp     dx, 2Eh				; <- cmp dx, 2Dh is missing!
0047EC08 jz      short loc_47EC12
0047EC0A cmp     dx, 2Fh
0047EC0E jz      short loc_47EC12
0047EC10 mov     cl, 4Eh

Since 2Dh is '-', the valid character is found.


6. Assembling characters six to 13 (see .cpp, line 86)
This last part of the routine calls two important functions: 0047E770 and
004059A4. Since the latter is only needed to verify a value that has been 
generated in the first function, I won't give further information about it.

For the generation of characters six to 13 the local username, that has been 
given in the keygenme and the name of the computer is needed. Both need to be
at least 5 characters long. Given the computername "123456" the username 
"ABCDEF" the function does the following decoding:

Step 1:
ABCDEF -> AFDB (first, last, fourth and second character in this case (6 chars))
123456 -> 1642 (first, last, fourth and second character in this case (6 chars))

Step 2:
AFDB -> BDFA (reversed)
1642 -> 2461 (reversed)

Step 3:
   B   D   F   A   = BDFA
     2   4   6   1 = 2461

-> B 2 D 4 F 6 A 1 = B2D4F6A1

Step4:
This value is then decoded with the help of a lookup table

0048340C dd '4', '9', 'D', 'G', 'K', 'N', '8', '1', 'S', 'W', 'Z', '2', '7', 'B'
0048340C dd 'F', 'J', 'M', '6', '3', 'R', 'V', 'Y', '5', 'T', 'C', 'I', 'L', 'O'
0048340C dd 'P', 'U', 'X', 'Q', 'H', 'E', 'A', '0'

at the following locations:

0047EAAB movzx   edx, word_48334C[edx*4]	; decodes numbers
0047EAE7 movzx   edx, word_483330[edx*4]	; decodes letters

The value B2D4F6A1 will therefore be decoded to 2DBKJ8Z9. (see .cpp, line 99)

These eight characters are compared in the mentioned function 004059A4 to the
characters six to 13 of the given serial. The last seven characters can be any
random characters that are part of 0-9, A-Z. (see .cpp, line 108) 

A valid serial would therefore look like NKM7-2DBKJ8Z9XXXXXXX with X = random.
