void NextLesser(unsigned int *iValue, char i, char j)
{
    *iValue += (i * 2) - j;
    *iValue <<= 0x28;
    *iValue += (i * 2) - j;
}

void NextGreater(unsigned int *iValue, char i, char j)
{
    *iValue += (i * 2) + j;
    *iValue <<= 0x48;
    *iValue += (i * 2) + j;
}

string GenerateSerial(string sComputerName, string sUserName)
{
    string sSerial = "";
    string sValue = "";
    unsigned int iValue = 0;
    unsigned iRandom = 0;;
    char c0, c1, c2, c3;

    srand((unsigned)time(0));

    /* transform the input strings to upper case for simplified logic */
    transform(sUserName.begin(), sUserName.end(), sUserName.begin(), ::toupper);
    transform(sComputerName.begin(), sComputerName.end(), sComputerName.begin(), ::toupper);

    /* constants are taken from the keygenme */
    const unsigned int sCompare = 0x5235471F;
    const char cLookupNumber[] = { '4', '9', 'D', 'G', 'K', 'N', '8', '1', 'S', 'W' };
    const char cLookupString[] = { 'Z', '2', '7', 'B', 'F', 'J', 'M', '6', '3', 'R', 'V', 'Y', '5',
                                  'T', 'C', 'I', 'L', 'O', 'P', 'U', 'X', 'Q', 'H', 'E', 'A', '0'
                                };

    /* bruteforce the first part of the serial by iterating 0-9 and A-Z */
    for (c0 = '0'; c0 <= 'Z'; c0 ++)
    {
        for (c1 = '0'; c1 <= 'Z'; c1 ++)
        {
            for (c2 = '0'; c2 <= 'Z'; c2 ++)
            {
                for (c3 = '0'; c3 <= 'Z'; c3 ++)
                {
                    /* reached > '9', continue with 'A' */
                    if (c0 == ':') c0 = 'A';
                    if (c1 == ':') c1 = 'A';
                    if (c2 == ':') c2 = 'A';
                    if (c3 == ':') c3 = 'A';

                    iValue = 0;

                    if (c0 > c1)
                        NextLesser(&iValue, c0, c1);
                    else
                        NextGreater(&iValue, c0, c1);

                    if (c1 > c2)
                        NextLesser(&iValue, c1, c2);
                    else
                        NextGreater(&iValue, c1, c2);

                    if (c2 > c3)
                        NextLesser(&iValue, c2, c3);
                    else
                        NextGreater(&iValue, c2, c3);

                    iValue += (c3 * 2) + c0;

                    /* bruteforce successful? */
                    if (iValue == sCompare)
                    {
                        sSerial += c0;
                        sSerial += c1;
                        sSerial += c2;
                        sSerial += c3;
                    }
                }
            }
        }
    }

    /* add the char '-' to the serial */
    sSerial += '-';

    /* concatenate the next serial part */
    sValue += sUserName[sUserName.size() / 2 - 2];
    sValue += sComputerName[sComputerName.size() / 2 - 2];

    sValue += sUserName[sUserName.size() / 2];
    sValue += sComputerName[sComputerName.size() / 2];

    sValue += sUserName[sUserName.size() - 1];
    sValue += sComputerName[sComputerName.size() - 1];

    sValue += sUserName[0];
    sValue += sComputerName[0];

    /* encode this part with lookup tables */
    for (iValue = 0; iValue < sValue.size(); iValue++)
    {
        if (sValue[iValue] >= '0' && sValue[iValue] <= '9')
            sSerial += cLookupNumber[sValue[iValue] - '0'];
        else
            sSerial += cLookupString[sValue[iValue] - 'A'];
    }

    /* fill the last part with random numbers */
    for (iValue = 0; iValue < 7; iValue++)
    {
        iRandom = rand() % 36;
        if (iRandom >= 0 && iRandom <= 9)
            sSerial += iRandom + '0';
        else
            sSerial += iRandom + 'A' - 10;
    }

    return sSerial;
}