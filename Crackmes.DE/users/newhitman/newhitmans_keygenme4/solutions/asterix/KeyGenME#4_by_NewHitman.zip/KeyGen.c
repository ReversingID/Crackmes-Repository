#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define  MAX_NAME    255
#define  MIN_NAME    3
#define  MAX_SERIAL  8

void termfunc(void);
void algorithm1(char *, char *);
void algorithm2(char *, char *);
void algorithm3(char *, char *);

int main(void)
{
    char name[MAX_NAME+1], serial[MAX_SERIAL+1];

    atexit(termfunc);

    printf("KeyGen for [NewHitman's KeyGenME #4] by @sterix\n");
    
    printf("\nEnter name: ");
    gets(name);

    if (strlen(name) < MIN_NAME) {
	fprintf(stderr, "\nThe name needs %d or more characters.", MIN_NAME);
        return 1;
    }

    algorithm1(name, serial);
    printf("\nAlgorithm 1 Serial: %s", serial);
 
    algorithm2(name, serial);
    printf("\nAlgorithm 2 Serial: %s", serial);

    algorithm3(name, serial);
    printf("\nAlgorithm 3 Serial: %s", serial);

    return 0;
}

void algorithm1(char *sn, char *ss)
{
    unsigned len;

    len = strlen(sn);

    ss[0] = sn[0];
    ss[1] = sn[len - 1];
    ss[2] = sn[1];
    ss[3] = sn[len - 2];
    ss[4] = sn[2];
    ss[5] = sn[len - 3];

    ss[6] = '\0';
    
}

void algorithm2(char *sn, char *ss)
{        
    unsigned len;

    len = strlen(sn);
    sprintf(ss, "%X%X%X%X", sn[len-2], sn[0], sn[len-3], sn[1]);
}

void algorithm3(char *sn, char *ss)
{
    unsigned val;
 
    val = sn[strlen(sn) - 1];
    val += 0x999;
    
    sprintf(ss, "%u", val * 0x1111);
}

void termfunc(void)
{
    printf("\n\n");
    system("pause");
}