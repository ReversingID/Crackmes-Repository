#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>

#define  MAX_NAME  256
#define  N_SER     14

#define  MY_RAND   5 + rand() % 5

int isright(char *);

int main(void)
{
    char name[MAX_NAME], s[N_SER+1];
    char sym[3];
    unsigned len, i;

    printf("\nKeyGen for [KeyGenME #5 by NewHitman] by -= AsTeRiX =-\n");

    printf("\nEnter name: ");
    gets(name);

    len = strlen(name);

    if (len <= 3 || len >= 24) {
	fprintf(stderr, "\nERROR: The length of name must be between 4 and 23 characters\n");
	return 1;
    }

    s[5] = 3; s[8] = 5;
    s[1] = s[2] = 9;

    srand(time(NULL));
    
    do {   

    	s[3] = 13 - (s[11] = MY_RAND);
    	s[4] = 14 - (s[10] = MY_RAND);

    	s[0] = 20 - (s[3] + s[4]);

    	s[9] = 11 - (s[12] = MY_RAND);
    	s[13] = 12 - s[0];

    	sprintf(sym, "%X", name[0]);
    	strncpy(&s[6], sym, 2);
  
    	s[N_SER] = '\0';

    	for (i = 0; i < N_SER; i++) {
	    if (s[i] >= 0 && s[i] <= 9)
	        s[i] += '0';
        }

    } while (!isright(s));

    printf("\n==========================");
    printf("\nName:   %s", name);
    printf("\nSerial: %s", s);
    printf("\n==========================\n\n");
    system("pause");    

    return 0;
}

int isright(char *s)
{
    register int i;

    for (i = 0; i < N_SER; i++) {
	if (!isdigit(s[i]) && i != 6 && i != 7)
	   return 0;
    }

    return 1;
}