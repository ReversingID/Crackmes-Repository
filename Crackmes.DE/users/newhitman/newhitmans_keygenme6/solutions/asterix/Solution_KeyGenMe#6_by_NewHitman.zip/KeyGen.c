#include <stdio.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>

#define  MAX       256
#define  MIN_NAME  3
#define  N         12

int main(void)
{
    char str[] = "NH KeyGenMe6";

    char name[MAX], temp[MAX], serial[MAX], snum[5];
    unsigned i, j, nname, nserial;
    
    printf("KeyGen for [NewHitman's KeyGenMe6] by -= AsTeRiX =-\n");

    printf("\nEnter name: ");
    gets(name);

    if ((nname = strlen(name)) < MIN_NAME) {
	fprintf(stderr, "\nERROR: The length name needs 3 or more characters.\n\n");
	system("pause");
	return 1;
    }

    strcpy(temp, name);

    for (i = 0; i < nname; i++) {
	if (strlen(name) > N) {
	    for (j = N; name[j] != 0; j++)
	  	name[j] = name[j + 1];
   	} else if (strlen(name) < N) {
	   strcat(name, temp);
 	   strcpy(temp, name);
   	}
    }

    serial[0] = '\0';
    nname = strlen(name);

    for (i = 0; i < nname; i++) {
	sprintf(snum, "%004X", (unsigned char)name[i] + (unsigned char)str[i]);
	strcat(serial, snum);
    }    
    
    
    for ( strcpy(temp, serial) ; (nserial = strlen(serial)) != N ; ) {
	if (nserial > N) {
	    for (j = N; serial[j] != 0; j++)
	  	serial[j] = serial[j + 1];
 	} else if (nserial < N) {
	    strcat(serial, temp);
	    strcpy(temp, serial);
	}
    }

    srand(time(NULL));
    printf("\nSerial: NH6-%u-%s\n\n", rand() % 10, serial);
    system("pause");

    return 0;
}