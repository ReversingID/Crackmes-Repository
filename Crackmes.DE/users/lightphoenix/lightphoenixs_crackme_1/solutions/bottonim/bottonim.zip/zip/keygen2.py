#!/usr/bin/python
'''
Documentation, License etc.

@package keygen
'''	
import sys
import hashlib

keys=[0x4C,0x50,0x4E,0x54,0x43]
  
def printLista():
  numList=list(map(chr, range(0x30, 0x39+1)))
  uppList=list(map(chr, range(0x41, 0x5A+1)))
  lowList=list(map(chr, range(0x61, 0x7A+1)))
  lista=[]
  lista.extend(uppList)
  lista.extend(lowList)
  lista.extend(numList)
  print lista

def mapping_raw(inputAscii,order=0):
  #order==0 takes a letter return position in array
  #order==1 taken position return a letter
  numList=list(map(chr, range(0x30, 0x39+1)))
  uppList=list(map(chr, range(0x41, 0x5A+1)))
  lowList=list(map(chr, range(0x61, 0x7A+1)))
  lista=[]
  lista.extend(uppList)
  lista.extend(lowList)
  lista.extend(numList)
  lista.append('+')
  lista.append('/')
  if order==0:
    return lista.index(inputAscii)
  return lista[inputAscii]

def mapping(inputLista,order=0):
  #order==0 takes a letter return position in array
  #order==1 taken position return a letter
  lista=[]
  for ii in range(0,len(inputLista)):
    lista.append(mapping_raw(inputLista[ii],order))
  return lista

def printHex(elem):
  print "0x%x" % elem,

def printHexList(elem):
  lista=[]
  for ii in range(0,len(elem)):
    lista.append(elem[ii])
  printArrayHex(lista)
  
def printArrayHex(lista):
  map(printHex, lista)
  print ""

def revHashList(inputList):
  temp_list=[]
  for ll in range(0,len(inputList),3):
    if ll+2 < len(inputList):
      temp_addr=(inputList[ll])+(inputList[ll+1]<<0x8)+(inputList[ll+2]<<16)
    elif ll+1 < len(inputList):
      temp_addr=(inputList[ll])+(inputList[ll+1]<<0x8)
    else:
      temp_addr=(inputList[ll])
    temp_list=temp_list + revHash(temp_addr,1)
  return temp_list

def revHash(address,order=0,partial=1):
  #order==1 reversed algo
  #	given a list of numbers find  4 values which takes to it
  if order==1:
    if not isinstance(address, (int, long, float, complex)):
      X=address[0]
      Y=address[1]
      Z=address[2]
    else:
      X=(address & 0x0000FF)
      Y=((address & 0x00FF00) >> 8)
      Z=((address & 0xFF0000) >> 16)
  
    A=(X & 0xFC) >> 2
    B=((X & 0x3) << 4) | ((Y & 0xF0) >> 4) 
    C=((Y & 0xF) << 2) | ((Z & 0xC0) >> 6)
    D=(Z & 0x3F)
    
    temp_result=[]
    temp_result.append(A)
    temp_result.append(B)
    temp_result.append(C)
    temp_result.append(D)
    return temp_result
  elif order==0:
    # normal algo
    #	given 4 values return a list
    tempString2=[]
    tempString=[address[kk] for kk in range(0,len(address))]
    couter=0
    for ii in range(1,len(address),4):
      A=address[ii-1]
      B=address[ii]
      C=0
      D=0
      if ii+1<len(address):
	C=address[ii+1]
      if ii+2<len(address):
	D=address[ii+2]
	
      val1=(A << 2 | B >> 4) & 0xFF
      val2=(B << 4 | C >> 2) & 0xFF
      val3=(C << 6 | D)      & 0xFF
      
      if val1!=0:
	tempString2.append(val1)
      if val2!=0:
	tempString2.append(val2)
      if val3!=0:
	tempString2.append(val3)
      tempString[couter]  = ((A << 2 | B >> 4) & 0xFF)
      tempString[couter+1]= ((B << 4 | C >> 2) & 0xFF)
      tempString[couter+2]= ((C << 6 | D)      & 0xFF)
      couter=couter+3
    if partial==1:
      tempString2=[tempString2[i] for i in range(0x10,len(tempString2))] #cut out the first 0x10
      return  tempString2
    return tempString2
  
def magicXOR(listaIn):
  lista=[listaIn[kk] for kk in range(0,len(listaIn))]
  for ii in range(0,len(lista)):
    lista[ii]=lista[ii] ^ keys[(ii%5)]
  return lista
  
def extractValue(inputNum):  
    retLista=[]
    #print "inputNum:"+str(inputNum)
    retLista.append(inputNum[0] & 0xFFFFFF)
    retLista.append((inputNum[0] & 0xFF000000) >> 24 | (inputNum[1] & 0xFFFF) << 8)
    retLista.append((inputNum[1] & 0xFFFF0000) >> 16 | (inputNum[2] & 0xFF) << 16)
    retLista.append((inputNum[2] & 0xFFFFFF00) >>  8 )
    retLista.append((inputNum[3] & 0xFFFFFF))
    retLista.append((inputNum[3] & 0xFF000000) >> 24 | (inputNum[4] & 0xFFFF) << 8)
    return retLista
  
def returnMagicAddr(lista=0):
  if lista != 0:
    listamd5=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]+lista
    listamd5=[chr(listamd5[kk]) for kk in range(0,len(listamd5))]
    m = hashlib.md5()
    stringaInput="".join(listamd5)
    m.update(stringaInput)
    #print m.hexdigest()
    retString=m.hexdigest()
    
    retLista=[]
    for ll in range(0,len(retString),8):
      retLista.append(int(retString[0+ll:2+ll],16)|int(retString[2+ll:4+ll],16)<<8|int(retString[4+ll:6+ll],16)<<16|int(retString[6+ll:8+ll],16)<<24)
    return retLista
  else:
    LEN=lista
    retList=[]
    if LEN==0:
      retList.append(0xB710E934)
      retList.append(0x56B51728)
      retList.append(0x4CEBE3F8)
      retList.append(0x745CEDDD)
      #retList.append(0x44444444) #padding
    elif (LEN==0x21):
      print "--------------------case 0x21"
      
      retList.append(0xF2185141)
      retList.append(0x96B54578)
      retList.append(0x6484C553)
      retList.append(0xB853531C)
    else:
      retList=[0x34,0xE9,0x10,0xB7,0x28,0x17,0xB5,0x56,0xF8,0xE3,0xEB,0x4C,0xDD,0xED,0x5C,0x74,0x44,0x44,0x44,0x44]
    return retList
  
def splitList(inputList):
  pos=inputList.index(0x9)
  firstList=[inputList[ll] for ll in range(0,pos+1)] # 9 included
  secondList=[inputList[ll] for ll in range(pos+1,len(inputList))] # 9 excluded
  return [firstList,secondList]

def findCorrectPos(inputList):
  pos=len(inputList)-0x8 #remaining len needs to be 8 len
  pos=pos-0x1 # pos start from 0
  print ""
  printHexList(inputList)
  print ""
  print "value to correct: 0x%x" % inputList[pos]
  return pos

def reverseValueInPos(inputList,pos):
  print "pos%5:" + str(pos%5) + " val: 0x%x" % keys[(pos%5)]
  print "inputList[pos]: 0x%x" % inputList[pos]
  correctValue=0x9 ^ keys[(pos%5)]
  return correctValue

def chk1(inputListOriginal):
  loopVal=1
  temp_result=[]
  inputList=[inputListOriginal[ii] for ii in range(0,len(inputListOriginal))]
  inputList.append(0)
  for jj in range(0,len(inputList)-2):
    loopVal=( (   ( (inputList[jj]+2)*inputList[jj] )+0x3 )*loopVal) & 0xFFFFFFFF
  for jj in range(0,8):
    temp_value=( loopVal >> (0x1C-4*jj) ) & 0xF
    if temp_value <= 0x9:
      temp_value=temp_value | 0x30
    else:
      temp_value=temp_value+0x37
    temp_result.append(temp_value)
  return temp_result
  
def computeOriginalLen(inputList):
  userpwdEnc=[inputList[ll] for ll in range(0,len(inputList))]
  lista1=[inputList[ll] for ll in range(0,0x10)]
  completeList=lista1+userpwdEnc
  revList=revHashList(completeList)
  mappedList=mapping(revList,1)
  return (len(mappedList)>>2)*3
  
def solveFirstCheck(LEN,num=0x41414141):
  retList=returnMagicAddr(LEN) #find magic address
  retList.append(num)
  addrList=extractValue(retList) #extract 3 values each times
  hash=revHash(addrList[0],1)+revHash(addrList[1],1)+revHash(addrList[2],1)+revHash(addrList[3],1)+revHash(addrList[4],1)+revHash(addrList[5],1) #find out which value gives the correct solution
  kk=len(hash)-1
  VarCont=True
  while VarCont:
    if hash[kk]==0:
      hash.pop(kk)
    else:
      VarCont=False
    kk=kk-1
  return hash

def findSolution(username):
  #print "BUILDING SOLUTION"
  userEnc=[username[ll] for ll in range(0,len(username))]
  userEnc.append(0x9)
  ret_chk=chk1(userEnc)
  totList=userEnc+ret_chk
  userpwdEnc=magicXOR(totList)
  totList2=magicXOR(userpwdEnc)
  lenOriginal=computeOriginalLen(totList2)
  numer=userpwdEnc[0]|userpwdEnc[1]<<8
  
  retList=returnMagicAddr(userpwdEnc)
  retList.append(numer)
  addrList=extractValue(retList)
  hash=revHash(addrList[0],1)+revHash(addrList[1],1)+revHash(addrList[2],1)+revHash(addrList[3],1)+revHash(addrList[4],1)+revHash(addrList[5],1)
  completeList=userpwdEnc
  revList=revHashList([completeList[ll] for ll in range(2,len(completeList))])
  revList=hash+revList# [revList[ll] for ll in range(3,len(revList))]
  mappedList=mapping(revList,1)
  return mappedList



print "\t\t\t\tSTARTING KEYGEN"
if len(sys.argv) == 2:
    username=sys.argv[1]
elif len(sys.argv) == 1:
    username="bottonim"
else:
    print "USE " + str(sys.argv[0]) + " [username]"
    exit()
lenUser=len(username)
if lenUser<=6:
    print "Error:\t\t\t\tUsername must be greater than 6 character"
    exit()
stringToAdd=""
checkLenUser=(lenUser+1)%3
if checkLenUser==1:
    stringToAdd="=="
elif checkLenUser==2:
    stringToAdd="="
printLista()
print ""

startString="-----BEGIN LIGHTPHOENIX KEY BLOCK-----"
endString="-----END LIGHTPHOENIX KEY BLOCK-----"

#print "REAL SOLUTION"
username=map(ord,list(username) )
mappedList=findSolution(username)
print "complete solution is "+startString+"".join(mappedList)+stringToAdd+endString

print ""
print "checking in the normal way"
#IF NOT ERROR THEN CORRECT SOLUTION
lista=mapping(mappedList,0)
lista=revHash(lista,0,1)
lista=magicXOR(lista)
splitted=splitList(lista)
ret_chk=chk1(splitted[0])
print "DONE :-D"
