/****************************************************************************************************
root@dotwood:~/syscalo# ./bforce
Brute Forcer for crackme 1 's syscalo
Mattwood9 mattwood9@gmail.com

[*]Result : "731940"

root@dotwood:~/syscalo#
****************************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//###################################################################################################

#define NORMAL  "\033[0m"
#define RED     "\033[31m"
#define GREEN   "\033[32m"

//###################################################################################################

unsigned int a, b, c, d, e, strInput;

//###################################################################################################

int encrypt() {
asm("

movl    $0x0, a
movl    $0x0, b
movl    $0x0, c
movl    $0x0, d
movl    $0x0, e

movl    strInput,%eax
andl    $0xff0000,%eax
movl    %eax,a

movl    strInput,%eax
xorl    $0xf0f0f,%eax
movl    %eax,b

movl    strInput,%eax
andl    $0xff00,%eax
movl    %eax,c

movl    strInput,%eax
xorl    $0xf0f0f0,%eax
movl    %eax,d

movzbl  strInput,%eax
movl    %eax,e
movl    e,%eax
addl    %eax,b

addl    $0xff9f0000,a

orb     $0x37,e
andl    $0x45,d
andl    $0x1f00,c
movl    e,%ecx
movl    %ecx,%eax
movl    $0x11,%ebx
cltd
idiv    %ebx
movl    %eax,e

xorl    $0x1e00,c

movl    c,%ebx
xorl    %ebx,b

xorl    $0x150000,a
 
movl    strInput,%ebx
xorl    %ebx,strInput

movl    c,%ebx
addl    %ebx,e

movl    a,%ebx
xorl    e,%ebx
movl    %ebx,strInput

movl    e,%ebx
xorl    %ebx,a

movl    $0x0,b

movl    a,%ebx
orl     %ebx,b
movl    $0x503090,d
andl    $0x111111,d

movl    d,%edx
movl    %edx,%eax
test    %eax,%eax
jge     _Next
addl    $0x7,%eax

_Next:
sar     $0x3,%eax
mov     %eax,d

movl    d,%eax
movl    %eax,%edx
addl    %edx,%edx
addl    %eax,%edx
addl    %edx,%edx
leal    (%eax,%edx,1),%ebx
movl    %ebx,d

movl    d,%eax
movl    %eax,%edx
sar     $0x1f,%edx
movl    %edx,%ecx
shr     $0x1f,%ecx
leal    (%ecx,%eax,1),%edx
movl    %edx,%eax
sar     $0x1,%eax
movl    %eax,d

movl    b,%eax
cmp     %eax,d
je      GoodBoy
xorl    %eax, %eax
leave
ret
GoodBoy:
");
return 1;
}

//###################################################################################################

int main(int argc, char **argv) {
unsigned int i;

printf(GREEN "Brute Forcer for crackme 1 's syscalo\n" NORMAL);
printf(GREEN "Mattwood9 mattwood9@gmail.com\n\n" NORMAL);

for(i=0;i<0xffffffff;i++) {
	strInput = i;
	if(encrypt()) {
		printf(RED "[*]Result : \"%X\"\n\n" NORMAL,i);
		break;
	}
	
}

return 1;
}
