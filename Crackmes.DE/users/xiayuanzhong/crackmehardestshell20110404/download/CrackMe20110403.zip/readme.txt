I use Dev-C++ to creat this CrackMe, but it was seen to be a virus.
So I had to add some special ASM code, and this may add some difficult.

I'm a Chinese , so there must be some mistakes in my word.
I feel sorry for it.

EASY!!!

In fact, this shell is easy to find the OEP, but it's not easy to fix.
So I think this is the most difficult part.
(The shell was thought to be a virus, so I just unpack it, Just practice once)

If you Crack me successfully, you will be able to see my email address and my name.
You should tell me how you fixed it, and how you crack it.
Good Luck!~
\(^o^)/~
