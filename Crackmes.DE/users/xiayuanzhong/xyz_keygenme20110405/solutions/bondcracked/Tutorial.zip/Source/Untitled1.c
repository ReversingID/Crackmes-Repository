void calculation
