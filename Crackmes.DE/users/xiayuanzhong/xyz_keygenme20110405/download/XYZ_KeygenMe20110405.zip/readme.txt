XYZ_KeygenMe 20110405

Difficulty: May be Hard( I can't crack it )

I use Dev-C++ to creat this CrackMe, but it was seen to be a virus.
So I had to add some special ASM code, and this may add some difficult.

I'm a Chinese , so there must be some mistakes in my word.
I feel sorry for it.

The solution can be:
1. Ten Names and Ten correct Passwords & How you crack it;( Basic )
2.Keygen & How crack it;( Good Job )
3.Keygen & code( cannot be .asm, better to be .c/.cpp ) & How you crack it;( Brilliant )

Written by ..., a Chinese; and this is my second time to write KeygenMe
My Email-address is xiayuanzhong@gmail.com
You can ask me for help!~

If you Crack me successfully, you will be able to see my email address and my name.
Thanks for using it , and Good Luck!
\(^o^)/~
