﻿
XYZ_KeygenMe20110505

	Because of my College Entrance Examination, this KeygenMe was delayed.

Introduction:
	1. The interface is similar to my last KeygenMe-KeygenMe20110405, but the code is different.
	2. I spend 0.5 h thinking and 2 h programming.
	3. I'm confident about this KeygenMe. Although it can be harder, I stopped. Step by step~ My next KeygenMe will be harder.
	4. You can ask me for help at any time. And after crack it, send me your tutorial and Keygen. You will receive my annotated code.
	5. I've written a 40 lines Test Keygen. So the Core procedure is short. HaHa~~~
	6. I think you will make a mistake, so be carafully.

Sulution:
	tutorial and Keygen