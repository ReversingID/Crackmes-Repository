	Keygen[meh] v1.0 (C++) 25/4/2004

  This is my first crackme, hope someone can write a nice
  tute for it. The serial algorithm is kinda simple but I
  have done my best to make things at least a little hard.

  If you have any q's or comments just email me.
  Cheers, 
  [meh] (aka gFresh)
  azsxdcfv237@hotmail

  ps, password for the source is the serial for [meh]
  pps, NO PATCHING  -  even I could do it like that ;-)