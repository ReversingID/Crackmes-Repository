#include <iostream.h>
#include <string>

void main() {
string Abex = "4562-ABEX";
string Prefix = "L2C-5781";
string Serial;
string TmpAsc;
string HDD;

system("cls");

cout << "Key generator\n";
cout << "-------------\n";
cout << "Cracker: Cipher (myforwarder@hotmail.com)\n";
cout << "Target : Abex's Crackme #1\n";
cout << "Date   : 14/7/2\n";
cout << "-------------\n";
cout << " ";
cout << "Hard disk volume name (for no name, enter 'none'): ";
cin >> HDD;
if (HDD == "none") { 
	HDD = "";
}
Serial = HDD + Abex;

int DL;
int CharAt;

for (DL=2;DL>0;DL--) {
	for (CharAt=0;CharAt<4;CharAt++) {
		Serial[CharAt] = (char)((int)Serial[CharAt]+1);
	}
}
Serial = Prefix + Serial;
cout << "\nYour key: " + Serial + "\n";
cout << "\n\nExecution terminated successfully.";
}