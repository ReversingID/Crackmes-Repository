/*
 * Qnix <Qnix@bsdmail.org>
 *
 * */

#include <stdio.h>

/* address: 0x80483c4 */

int main(int argc, char* argv[], char** envp) {
    int buffer; 		// m[r28 - 16]

    printf("Type cd-key: ");
    scanf("%d", &buffer);
    if (0x5b1270 != buffer) {
        printf("wrong!\n");
    } else {
        printf("%d\n", 0x11e61);
    }
    return 0;
}

