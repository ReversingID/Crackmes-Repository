import string

def keycheck( passw ):

	bitarray = password_to_bit_array(passw)
	return check(bitarray)


def to_signed(num):
	sign = num >> 0x1f

	if sign != 0:
		return num - 0x100000000

	return num


def is_negative( num ):
	if  num < 0:
		return 1
	else:
		return 0

def char_to_bit_array(char):
	return [ord(char) >> i & 1 for i in range(7,-1,-1)]

def password_to_bit_array(password):

	result = []
	for char in password:
		result += char_to_bit_array(char)

	return result



def reassemble_number(bitarray, start, length):
	result = 0
	for i in range(160-length-start, 159-start+1):
		result = ((result | bitarray[i]) << 1) & 0xffffffff

	return result >> 1

def validation_one(number):
	"""
	+ number is 4 bit length
	+ last two bits must be equal to the first two
	+ last two bits must be '10'
	+ valid number: 10
	"""

	last_two = number & 3
	if last_two != 2:
		return False

	return (number >> 2) == last_two

def validation_one_valid_numbers():
	result = []
	for i in xrange(2**4):
		if validation_one(i):
			result.append(i)
	return result

def count_divisors(number):
	nod = 0
	for d in range(2,number):
		if (number % d) == 0:
			nod += 1
	return nod

def validation_two(number):

	"""
	+ number is long 7 bits
	+ must be prime
	+ must be between 0x65 (excluded) and 0x6a (included)
	+ valid number: 103
	"""

	number = number & 0x7f
	return count_divisors(number) == 0 and  number > 0x65 and number <= 0x6a

def validation_two_valid_numbers():
	result = []
	for i in xrange(0x66, 0x6a+1):
		if validation_two(i):
			result.append(i)

	return result

def validation_three( num ):
	"""
	+ num is 24 bits long
	+ must be a 6-digits (decimal) number
	+ first decimal digit must be equal to the last
	+ must pass 3 math tests
	+ valid number: 805098
	"""
	st_num = str(num)

	if len(st_num) != 6:
		return False

	if st_num[0] != st_num[5]:
		return False

	a = num * to_signed(0xc64b2279)
	a = a & 0xFFFFFFFF00000000
	a = (a >> 32) & 0xFFFFFFFF
	a = (a + num) & 0xffffffff
	a = a / 2**9

	test_num = (a * 0x295) & 0xFFFFFFFF

	if test_num != num:
		return False

	num2 = (((num * 0x6b9ccb75) & 0xFFFFFFFF00000000) >> 32) >> 9

	if count_divisors(num2) != 0:
		return False

	num3 = (((num * 0x30c30c31) & 0xFFFFFFFF00000000) >> 32) >> 3

	num3 *= 0x2a

	if num3 == num:
		return True

	return False

def validation_three_valid_numbers():
	result = []
	for i in xrange(99999,9999999):
		if validation_three(i):
			result.append(i)

	return result

def validation_four(number):

	"""
	+ number is long 63 bits
	+ valid numbers: [13, 3341, 12995853, 1791380749]
	"""
	
	knowledge = [0x4c, 0x73, 0x63, 0x70, 0x69, 0x40, 0x0]
	i = 0

	while number > 0:
		a = (number & 0x3f ) + 0x3f
		k = knowledge[i]
		if a != k:
			return False

		i+=1
		number = number >> 6

	return True

def validation_four_valid_numbers():
	rev = reverse_validation_four()
	return [
	rev & 63,
	rev & 4095,
	rev & 16777215,
	rev
	]

def validation_five(number):
	return number == 9

def validation_five_valid_numbers():
	return [9]

def validation_six(number):
	"""
	+ number must be composed of 10 bits
	+ each chunk of 2 bits must be equal to 0b01
	+ valid numbers: [0,1,5,21,85,341]
	"""
	while number > 0:
		if (number & 3) != 1:
			return False
		number = number >> 2
	return True

def validation_six_valid_numbers():
	result = []
	for i in xrange(2**0xa):
		if validation_six(i):
			result.append(i)
	return result

def generate_constant(long_constant, short_counter):
	saved_short_counter = short_counter
	saved_long_constant = long_constant
	while short_counter != long_constant:
		if long_constant >= short_counter:
			short_counter += saved_short_counter
		else:
			long_constant += saved_long_constant

	return long_constant

def validation_seven(number):
	"""
	+ 15 bits number
	+ valid number: 24903
	"""
	return number == generate_constant(0xacf, 9)

def validation_seven_valid_numbers():
	return [generate_constant(0xacf, 9)]

def validation_eight(number):
	return number == 0x60

def validation_eight_valid_numbers():
	return [0x60]

def validation_nine(number):
	"""
	+ 12 bits
	+ valid number: 3336
	"""
	return number == generate_constant(0x458, 0x342)

def validation_nine_valid_numbers():
	return [generate_constant(0x458, 0x342)]

def validation_ten(number):
	"""
	+ 0x1b bits
	+ valid number: 94148244
	"""
	knowledge = [0x50, 0x61, 0x65, 0x56, 0x52, 0x61, 0x45, 0x6e, 0x58, 0x63, 0x55, 0x52, 0x41, 0x3d]
	i=0
	failures=0
	while number > 0:
		a = (number & 0x3f ) + 0x3c
		k = knowledge[i]

		if a != k:
			print hex(a) + " != " + hex(k)
			failures += 1

		number = number >> 2
		i += 1

	return failures == 0

def validation_ten_valid_numbers():
	return [reverse_validation_ten()]

def validation_eleven(number):
	return number == 0x372

def validation_eleven_valid_numbers():
	return [0x372]

def reverse_validation_ten():

	knowledge = [0x50, 0x61, 0x65, 0x56, 0x52, 0x61, 0x45, 0x6e, 0x58, 0x63, 0x55, 0x52, 0x41, 0x3d]
	number = 0
	i  = 0

	for k in knowledge:
		number = number | ((k - 0x3c) << (i*2))
		i+=1

	return number


def reverse_validation_four():
	knowledge = [0x4c, 0x73, 0x63, 0x70, 0x69, 0x40]
	number = 0
	i = 0
	for k in knowledge:
		number = number | ((k - 0x3f) << (i*6))
		i+=1

	return number 


def check_number(index_p_1, reassembled_number):
	if index_p_1 == 0:
		return True
	elif index_p_1 == 1:
		return validation_one(reassembled_number)
	elif index_p_1 == 2:
		return validation_two(reassembled_number)
	elif index_p_1 == 3:
		return validation_three(reassembled_number)
	elif index_p_1 == 4:
		return validation_four(reassembled_number)
	elif index_p_1 == 5:
		return validation_five(reassembled_number)
	elif index_p_1 == 6:
		return validation_six(reassembled_number)
	elif index_p_1 == 7:
		return validation_seven(reassembled_number)
	elif index_p_1 == 8:
		return validation_eight(reassembled_number)
	elif index_p_1 == 9:
		return validation_nine(reassembled_number)
	elif index_p_1 == 10:
		return validation_ten(reassembled_number)
	elif index_p_1 == 11:
		return validation_eleven(reassembled_number)
	elif index_p_1 == 12:
		return validation_six(reassembled_number)


	return False



def check(bitarray):
	accumulator = 0
	fields = [ 4, 7, 0x18, 0x1f, 4, 0xa, 0xf, 7, 0xc, 0x1b, 0xd, 6 ]
	i = 0
	for fl in fields:
		number = reassemble_number(bitarray, accumulator, fl)

		if not check_number(i+1, number):
			print "failed check " + str(i+1) + " (number = " + str(number) + ")"
			return False
		accumulator += fl
		i+=1

	return True


def keygen():
	print "Bruteforcing single fields..."
	values = [
	validation_one_valid_numbers(), 
	validation_two_valid_numbers(), 
	validation_three_valid_numbers(), 
	validation_four_valid_numbers(), 
	validation_five_valid_numbers(), 
	validation_six_valid_numbers(),  
	validation_seven_valid_numbers(),
	validation_eight_valid_numbers(),
	validation_nine_valid_numbers(),
	validation_ten_valid_numbers(),
	validation_eleven_valid_numbers(),
	validation_six_valid_numbers()[:4]
	]

	indices = [0] * len(values)
	produce_keys(values, indices, 0)

def produce_keys(values, indices, cursor):

	if cursor >= len(values):
		return

	while indices[cursor] < len(values[cursor]):
		
		if cursor == len(values)-1:
			output_key(values, indices)
		else:
			produce_keys(values, indices, cursor+1)

		if cursor < len(values)-1:
			indices[cursor+1:] = [0] * (len(values)-cursor-1)
		
		indices[cursor]+=1

def number_to_bit_array(number, length):
	return [number >> i & 1 for i in range(length-1,-1,-1)]


def reassemble_char(bitarray, start):
	char = 0
	for i in xrange(8):
		char = char | ((bitarray[start +i]) << i)

	return char

def output_key(values, indices):

	fields = [ 4, 7, 0x18, 0x1f, 4, 0xa, 0xf, 7, 0xc, 0x1b, 0xd, 6 ]
	v = [values[i][indices[i]] for i in xrange(len(values)) ]

	bits = []

	i=0
	for value in v:
		bits = number_to_bit_array(value, fields[i]) + bits
		i += 1

	chars = []
	for j in xrange(20):
		chars.append(reassemble_char(bits[::-1], j*8))

	try:
		candidate_key = ''.join([chr(c) for c in chars])[::-1]
		if all(c in string.printable for c in candidate_key):
			print "Valid key: " + candidate_key

	except:
		pass



if __name__ == '__main__':

	keygen()
	
