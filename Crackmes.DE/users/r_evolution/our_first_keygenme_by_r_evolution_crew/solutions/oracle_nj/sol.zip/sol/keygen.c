#include<stdio.h>
#include<string.h>

void main()
{
	unsigned char name[100] ={0}, end=0xd2;

	printf("\nr-Evolution Keygenme Keygen by ORacLE_nJ\n========================================");

	printf("\n\nName :");
	fgets(name, sizeof(name)+1,stdin);

	name[strlen(name) - 1] = 0;

	printf("\n\nSerial : %s%c\n\n", name, end);

	printf("Ctrl + C to exit. . .");		//andrewl.us, please forgive me
	while(1);				//if i am copying this from you!!
}
