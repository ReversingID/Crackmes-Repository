/* Generate valid serial "number" for r-Evolution keygenme#1.   
 *
 * A valid serial number is a string which is an exact copy of the 
 * input username concatenated with the extened ASCII character '0xD2' ('-')   
 * You can type this character on keyboard (in DOS/Windows) by holding down ALT, * pressing 210 on the numeric keypad, then releasing the ALT key
 *
 *  Compiled using MS Visual C++/ MS Visual Studio .net
 * 
 *  %cl keygen.c /MD
 *
 *  -hardbop
 */

#define _CRT_SECURE_NO_DEPRECATE
#include <stdio.h>
#include <string.h>

#define MAXLEN (256)


int main (int argc, char *argv[])
{
char szUsername[MAXLEN];
char szSerialNum[MAXLEN];
unsigned len;

printf("\n***** Keygen for r-Evolution keygenme#1 *****\n");
printf("Enter Username and then press <Enter> to generate a serial number.\n\n");
printf("Username: ");
gets(szUsername);

strcpy(szSerialNum, szUsername);
len = strlen(szSerialNum);
szSerialNum[len] = 0xD2; 
szSerialNum[len+1] = '\0';

printf("Thank You!  Your serial number is: %s\n", szSerialNum);

exit(0);
}
