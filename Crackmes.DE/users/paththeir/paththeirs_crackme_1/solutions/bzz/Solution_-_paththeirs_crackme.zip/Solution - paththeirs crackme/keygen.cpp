#include <Windows.h>
#include <stdio.h>

//This function sorts the char array towards the value
void BubbleSort(char* arr)
{
	int len = strlen(arr);
	for(int i=0;i<len;i++)
	{
		for(int j=0;j<len;j++)
		{
			if(arr[i] < arr[j])
			{
				char t = arr[i];
				arr[i] = arr[j];
				arr[j] = t;
			}
		}
	}
}

//Generate Serial
void GenSerial(char* UserName)
{
	BubbleSort(UserName);
	for(int i=0;i<strlen(UserName);i++)
	{
		UserName[i] ^= 8;
	}
}

int main()
{
	char* sUsername = new char[MAX_PATH];

	SetConsoleTitleA("Paththeirs Crackme #1 - KeyGen");
	printf("Username:");
	gets(sUsername);
	GenSerial(sUsername);
	printf("Serial: %s",sUsername);
	getchar();
	return 0;
}