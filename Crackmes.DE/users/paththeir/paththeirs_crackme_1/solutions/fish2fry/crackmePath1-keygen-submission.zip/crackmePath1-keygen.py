#! /usr/bin/env python
import sys
print "  _      _   _    "
print "_|_o _|_  )_|_._  "
print " | |_>| |/_ | |\/" 
print " ___ ____ ___ _/_ "
print "|___|____|___|___|"
print " "
print "[!] crackmePath1 keygen"
print "[!] Greetz to crackmes.de"
if len(sys.argv) <> 1:
	print "[+] Username: " + sys.argv[1]
	a = sys.argv[1]
	aa = sorted(a)
	L = list(aa)
	b = ""
	for c in L:
		b = b + unichr(ord(c) ^ 8)
	print "[+] Password: "  + b
else:
    print "[!] Usage: " + sys.argv[0] + " " + "username"

