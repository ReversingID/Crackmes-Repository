#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char str [80]; // the login
    char pwd [80]; //the password

    int sorted = 0; // boolean: is the array sorted?
    int char_length = 0;
    int i = 0; // index for for loop
    char xchg = 0;
    int val = 0;

    printf("type login name\n");
    scanf("%s",str);
    char_length = strlen(str);

// sort vector
sorted = 0;
while(!sorted){

    for(i=0;i<char_length-1;i++){
            if(str[i+1]<str[i]){
                xchg = str[i+1];
                str[i+1] = str[i];
                str[i] = xchg;
            }

    }

    sorted = 1;
    for(i=0;i<char_length-1;i++){
            sorted = sorted*(str[i+1]>=str[i]);
    }

}

// Now start create password

 for(i=0;i<char_length;i++){
            val = (int) str[i];
            val = val ^ 8;
            pwd[i] = (char) val;
    }

pwd[char_length] = 0;

printf("password is %s \n",pwd);

system ("PAUSE");

    return 0;

}



