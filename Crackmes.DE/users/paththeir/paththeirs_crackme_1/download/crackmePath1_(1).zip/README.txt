Hello! Welcome to my first keygenme! It's simple enough, just watch the codeflow.
KEYGEN is needed as solution!

Do not use usernames with 'W' char inside them. Can you guess why?

This one uses a procedure from stdlib.h. It can drive you crazy.

Good luck!

#1 KEYGENME by PathTheir