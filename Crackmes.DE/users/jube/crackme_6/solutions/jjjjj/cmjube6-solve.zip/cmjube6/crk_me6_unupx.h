

typedef int BOOL;
typedef char CHAR;
typedef unsigned long DWORD;
typedef void *HANDLE;

struct HICON__ {
	int unused;
};

struct HINSTANCE__ {
	int unused;
};

struct HWND__ {
	int unused;
};
typedef int INT_PTR;
typedef long LONG;
typedef long LONG_PTR;
typedef void *LPVOID;
__stdcall void PostQuitMessage __attribute__((dllimport))(int nExitCode __attribute__((in)));
typedef unsigned int UINT;
typedef unsigned int UINT_PTR;
typedef unsigned long ULONG_PTR;


__stdcall BOOL CloseHandle __attribute__((dllimport))(HANDLE hObject __attribute__((in)));
__noreturn __stdcall void ExitProcess __attribute__((dllimport))(UINT uExitCode __attribute__((in)));
typedef struct HICON__ *HICON;
typedef struct HINSTANCE__ *HINSTANCE;
typedef struct HWND__ *HWND;
typedef LONG_PTR LPARAM;
typedef const CHAR *LPCSTR;
typedef DWORD *LPDWORD;
typedef CHAR *LPSTR;
typedef LONG_PTR LRESULT;
typedef __stdcall DWORD (*PTHREAD_START_ROUTINE)(LPVOID lpThreadParameter);
typedef ULONG_PTR SIZE_T;
typedef UINT_PTR WPARAM;

struct _SECURITY_ATTRIBUTES {
	DWORD nLength;
	LPVOID lpSecurityDescriptor;
	BOOL bInheritHandle;
};

struct tagRECT {
	LONG left;
	LONG top;
	LONG right;
	LONG bottom;
};


typedef __stdcall INT_PTR (*DLGPROC)(HWND, UINT, WPARAM, LPARAM);
__stdcall BOOL EnableWindow __attribute__((dllimport))(HWND hWnd __attribute__((in)), BOOL bEnable __attribute__((in)));
__stdcall LPSTR GetCommandLineA __attribute__((dllimport)) __attribute__((out))(void);
__stdcall HWND GetDesktopWindow __attribute__((dllimport))(void);
__stdcall HWND GetDlgItem __attribute__((dllimport))(HWND hDlg __attribute__((in)), int nIDDlgItem __attribute__((in)));
__stdcall UINT GetDlgItemTextA __attribute__((dllimport))(HWND hDlg __attribute__((in)), int nIDDlgItem __attribute__((in)), LPSTR lpString, int cchMax __attribute__((in)));
typedef HINSTANCE HMODULE;
typedef struct tagRECT *LPRECT;
typedef struct _SECURITY_ATTRIBUTES *LPSECURITY_ATTRIBUTES;
typedef PTHREAD_START_ROUTINE LPTHREAD_START_ROUTINE;
__stdcall HICON LoadIconA __attribute__((dllimport))(HINSTANCE hInstance __attribute__((in)), LPCSTR lpIconName __attribute__((in)));
__stdcall int MessageBoxA __attribute__((dllimport))(HWND hWnd __attribute__((in)), LPCSTR lpText __attribute__((in)), LPCSTR lpCaption __attribute__((in)), UINT uType __attribute__((in)));
__stdcall BOOL MoveWindow __attribute__((dllimport))(HWND hWnd __attribute__((in)), int X __attribute__((in)), int Y __attribute__((in)), int nWidth __attribute__((in)), int nHeight __attribute__((in)), BOOL bRepaint __attribute__((in)));
__stdcall BOOL PostMessageA __attribute__((dllimport))(HWND hWnd __attribute__((in)), UINT Msg __attribute__((in)), WPARAM wParam __attribute__((in)), LPARAM lParam __attribute__((in)));
__stdcall LRESULT SendDlgItemMessageA __attribute__((dllimport))(HWND hDlg __attribute__((in)), int nIDDlgItem __attribute__((in)), UINT Msg __attribute__((in)), WPARAM wParam __attribute__((in)), LPARAM lParam __attribute__((in)));
__stdcall LRESULT SendMessageA __attribute__((dllimport))(HWND hWnd __attribute__((in)), UINT Msg __attribute__((in)), WPARAM wParam __attribute__((in)), LPARAM lParam __attribute__((in)));


__stdcall HANDLE CreateThread __attribute__((dllimport)) __attribute__((out))(LPSECURITY_ATTRIBUTES lpThreadAttributes __attribute__((in)), SIZE_T dwStackSize __attribute__((in)), LPTHREAD_START_ROUTINE lpStartAddress __attribute__((in)), LPVOID lpParameter __attribute__((in)), DWORD dwCreationFlags __attribute__((in)), LPDWORD lpThreadId __attribute__((out)));
__stdcall INT_PTR DialogBoxParamA __attribute__((dllimport))(HINSTANCE hInstance __attribute__((in)), LPCSTR lpTemplateName __attribute__((in)), HWND hWndParent __attribute__((in)), DLGPROC lpDialogFunc __attribute__((in)), LPARAM dwInitParam __attribute__((in)));
__stdcall HMODULE GetModuleHandleA __attribute__((dllimport)) __attribute__((out))(LPCSTR lpModuleName __attribute__((in)));
__stdcall BOOL GetWindowRect __attribute__((dllimport))(HWND hWnd __attribute__((in)), LPRECT lpRect __attribute__((out)));


