self.callback_newaddr = lambda { |addr, ptr| ['fake_ptr', 'good_ptr'] if ptr == [Expression[:eax]] }
