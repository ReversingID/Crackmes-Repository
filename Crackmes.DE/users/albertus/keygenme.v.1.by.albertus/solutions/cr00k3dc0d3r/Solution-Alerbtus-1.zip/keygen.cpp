/*
* Keygen Source Code Sorry if the Code is a Little Messy 
*/


#include<iostream>
#include<string>
#include<ctime>
#include<Windows.h>

using namespace std;

void KeyGen(); //Generate Serial
void UserGen();  //Generate Username

string jagger = "YouHaveGotTheMovesLikeJagger!";

//This keygen generates a random username and serial (AKA doesn't take user input
int main() {
	string username = "";
	for(int x = 0; x < 4; x++) {
		UserGen();
		KeyGen();
		Sleep(1000);
		cout << endl;
	}

	system("PAUSE");
}

void UserGen() {
	string jagger = "YouHaveGotTheMovesLikeJagger!";
	cout << "Your Username Is: ";
	srand (time(NULL));
	for(int x = 0; x < 11; x++) {
		cout << jagger[(rand() % jagger.length())];
	}
	cout << endl;
}

//Always Generate 10 Integer Serial (even though this isn't a requirement
void KeyGen() {
	char Serial[11];
	string digits = "0123456789";
	int y = 0;
	int z = 0;
	int a = 0;
	int b = 0;
	
	srand (time(NULL));

	for(int x = 0; x < 9; x++) {
		y = (rand() % 10);
		Serial[x] = digits[y];
	} 

	for(int x = 0; x < 9; x++) {
		if((x % 2) == 0) {
			z = ((unsigned int)Serial[x]*2)-0x60;
			if(z > 9) {
				b = z/2147483648;
				b = b/2147483648;
				z = (b + z)/2;

			}
		}
		else {
			z = ((unsigned int)Serial[x])-0x30;
		}
		a += z;
	}


	/*
	* Used inline assembly for imul operation then just ripped the rest of the algo using inline assembly..
	*/
	__asm {
		pusha
		mov eax, 0x66666667
		mov ecx, [a]
		imul ecx
		SAR edx, 2
		mov eax, ecx
		SAR EAX, 0x1F
		sub EDX, EAX
		MOV EAX, EDX
		SHL EAX, 2
		ADD EAX, EDX
		ADD EAX, EAX
		SUB ECX, EAX
		MOV [a], ecx
		popa
	}


	cout << "Your Serial Number Is:";
	for(int x = 0; x < 9; x++) {
		cout << Serial[x];
	}
	cout << a;
	cout << endl;
}