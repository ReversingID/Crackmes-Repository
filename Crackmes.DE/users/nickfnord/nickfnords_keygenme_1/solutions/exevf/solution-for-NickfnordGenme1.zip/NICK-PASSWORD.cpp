// NICK-PASSWORD.cpp : Defines the entry point for the console application.
// written by exevf   exevf@yahoo.com

#include "stdafx.h"
#include <stdio.h>
#include <string.h>
char pass_str[255]; 
char user_name[255];
 char nick[10];
char ch1,ch2;



int _tmain(int argc, _TCHAR* argv[])
{
int i,j,len_user,len_nick;
strcpy( nick, "NICKFNORD" );
	printf("\n%s  :   ","Enter UserName");
   gets( user_name );
   len_user = (int)strlen( user_name );

len_nick = (int)strlen( nick );
if(len_user>=8)
{
j=0;
for (i=0;i<	len_user;i++)
{

if (j==9) j=0;
ch1=toupper(user_name[i]);
ch2=nick[j];
_asm

{
pushad
movsx eax,ch1
movsx edx,ch2;
add eax,edx
sub eax,082h
cdq
mov ecx,1ah
idiv ecx
add dl,041h
mov ch2,dl
popad


}



pass_str[i]=ch2;

j++;

}
printf("\rPassword is     :   %s\n",pass_str);
}
else
{
printf("\nLenght of UserName  shall be 8 character At least \n");
}
	return 0;
}

