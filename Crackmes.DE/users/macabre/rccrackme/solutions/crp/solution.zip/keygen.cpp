/* -*- mode: c++ -*-
 * keygen for macabre's rcCrackme
 * http://www.crackmes.de/users/macabre/rccrackme/
 * 
 * crp-
 */
#include <iostream>
#include <fstream>
#include <string>
#include <cstring>

using namespace std;

string generate_key(const char* user) {
	char serial[0x100];
	unsigned char buffer[0x400];
	unsigned int blen, i;

	memset(serial, 0, sizeof(serial));
	memset(buffer, 0, sizeof(buffer));

	strcat((char*)buffer, user);
	/* 08048899-080488D4 expand username*/
	while(strlen((char*)buffer) <= 9) {
		strcat((char*)buffer, user);
	}

	blen = strlen((char*)buffer);

	/* 08048901-08048995 "crypt" buffer */
	for(i = 0; i < (blen/2); i++) {
		buffer[i] ^= buffer[(blen-i)-1];
		buffer[(blen-i)-1] = buffer[i] | buffer[i+1];
		buffer[(blen-i)-1] = ((signed char)buffer[(blen-i)-1]) >> 1;
	}

	/* 0804899E-08048A02 build serial string */
	for(i = 0; i < blen; i++) {
		char tmp[0x10] = "";
		int x = (signed char)buffer[i];
		if(x < 0) {
			x ^= 0xFFFFFFFF;
			x -= 0xFFFFFFFF;
		}
		sprintf(tmp, "%d", x);
		strcat(serial, tmp);
		serial[5] = '-';
		serial[15] = '-';
	}

	return string(serial);
}

bool write_keyfile(const string& user, const string& key) {
	ofstream of(".1x");
	of << "User " << user << "\n"
	   << "Serial " << key << "\n";
	of.close();
	return !of.fail();
}

int main(int argc, char* argv[]) {
	string user;
	string key;

	cout << "--[rcCrackme keygen.crp-]-------------------------------\n";
	cout << "name:   ";
	cin >> user;

	if(user.size() > 250) {
		cout << "name too long...\n";
		return 0;
	}

	key = generate_key(user.c_str());
	cout << "serial: " << key << "\n";
	cout << "-- writing '.1x'\n";

	if(write_keyfile(user.c_str(), key)) {
		cout << "------------------------------------------------[done]--\n";
	} else {
		cerr << "ERROR: writing '.1x'\n";
	}
	return 0;
}
