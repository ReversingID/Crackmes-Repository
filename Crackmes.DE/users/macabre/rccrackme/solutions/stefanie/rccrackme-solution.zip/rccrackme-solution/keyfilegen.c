/*
 * macabre's rc crackme
 * key file generator by niel anthony acuna
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char **argv) 
{
	char buf1[255];
	char username[256], serial[256];
	int unamelen, midval, x;
	FILE *fptr;

	printf("Macabre's rc CrackMe\n");
	printf(" Keyfile generator\n\n");

	if (argc < 2) {
		printf("usage: %s username\n", argv[0]);
		return 0;
	}

	memset(username, 0, 256);
	memset(serial, 0, 256);
	memset(buf1, 0, 256);


	strcat(username, argv[1]);
	while (strlen(username) < 10) {
		strcat(username, argv[1]);
	}

	unamelen = strlen(username);
	midval = unamelen >> 1;

	for (x=0; x<midval; x++) {
		username[x] ^= username[unamelen-x-1];
		username[unamelen-x-1] = username[x] | username[x+1];
		username[unamelen-x-1] >>= 1;
	}

	for (x=0; x<unamelen; x++) {
		sprintf(buf1, "%d", (unsigned char) username[x]);
		strcat(serial, buf1);
		serial[5] =  serial[15] = '-';
	}

	fptr = fopen(".1x", "w");

	if (!fptr) {
		perror("fopen");
		printf("copy the following two lines to file .1x\n");
		printf("User %s\n", argv[1]);
		printf("Serial %s\n", serial);
		return 0;
	}

	sprintf(buf1, "%s %s\n", "User", argv[1]);
	fwrite(buf1, 1, strlen(buf1), fptr);

	sprintf(buf1, "%s %s\n", "Serial", serial);
	fwrite(buf1, 1, strlen(buf1), fptr);

	fclose(fptr);
	printf("Done. Now run the crackme.\n");

	return 0;
}

#if 0
	while (fgets(buf1, 0xff, fptr)) {
		sscanf(buf1, "%s %s", buf2, buf3);
		if (strncmp(buf2, txt1, strlen(txt1)) == 0) {	/* User */
			username = strdup(buf3);
			read_ctr |= 1;
		} else
		if (strncmp(buf2, txt2, 6) == 0) {	/* Serial */
			serial = strdup(buf3);
			read_ctr |= 2;
		}
	}

	if (read_ctr != 3) return 0;

	unamelen = strlen(username);
	sarval = unamelen >> 1;

	__asm__("movl %1, %%eax\n\t"
		"shr $0x1f, %%eax\n\t"	/* is this line still needed?? */
		"addl %1, %%eax\n\t"
		"sar $0x1, %%eax\n\t"	/* unamelen/2 */
		"movl %%eax, %0\n\t"
		: "=r" (sarval) : "r" (unamelen) : "%eax");
#endif 

