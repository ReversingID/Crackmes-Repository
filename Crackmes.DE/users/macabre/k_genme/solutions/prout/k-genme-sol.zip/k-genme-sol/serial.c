/** 
Keygen for K-genme from Macabre 
To compile: gcc serial.c -o serial
*/


#include <stdio.h>
#include <string.h>


int ecx, ebx, edx, var54, esi, eax;

int main(int argc, char **argv)
{
	if(argc == 1){
		return 0;
	}

	char name[1024];
	strcpy(name, argv[1]);

	
	char serial1[100], serial2[100], serial3[100];
	
	esi = strlen(name);
	
	ecx=0;

	edx = *name;
	var54=0;

	for(ebx=1; ; ebx++)
	{

		ecx+=edx;
		edx^=0x45;
		eax=ecx;
		eax*=edx;
		var54+=eax;
		if(ebx==esi){
			break;
		}
		edx = name[ebx];
		if(ecx){
			eax=edx;
			eax>>=1;
			ecx-=eax;
			eax=ecx;
			ecx=edx;
			ecx*=eax;
		}
	}	

	eax = ecx+ecx*4;
	ebx=eax;
	ebx<<=4;
	ebx-=eax;
	eax=0xf0f0f0f1;
	/* Some asm code to get the value of edx register after a mul operation */
	__asm __volatile__("pushl %eax\n\t"
					   "pushl %ecx\n\t"
					   "pushl %edx\n\t"
					   "movl eax, %eax\n\t"
					   "movl ecx, %ecx\n\t"
					   "mul %ecx\n\t"
					   "movl %edx, edx\n\t"
					   "popl %edx\n\t"
					   "popl %ecx\n\t"
					   "popl %eax\n\t");
	
	esi=edx;
	esi>>=6;

	
	sprintf(serial1, "%u", ebx); //QString::setNum in decimal base
	sprintf(serial2, "%u", esi);
	serial2[4]='\0';			//QString::truncate(4)
	sprintf(serial3, "%u", var54);

	serial3[8]='\0';

	printf("1: %s\n", serial1);
	printf("2: %s\n", serial2);
	printf("3: %s\n", serial3);

	return 0;
}
	
	
		

	
