#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MIN	0x2f
#define MAX	0x78

#define CEILING	0x10	/* 16 user key combos maximum */

int get_checksum(char *p)
{
	return (- p[0] - p[1] - p[2] - p[3] - p[4] - p[5]);
}

int main(int argc, char **argv)
{
	int username_sum, checksum, result = 0;
	int a, b, c, d, e, f, x;
	char part2[] = "      ";
	char serial[10];

	if (argc < 2 ) {
		printf("usage: %s <username>\n", argv[0]);
		return 0;
	}

	for (username_sum = x = 0; x<strlen(argv[1]); x++) {
		username_sum +=argv[1][x];
	}
	username_sum *= username_sum;
	username_sum &= 0xff;


	for (a=MIN; a<=MAX; a++) {
		part2[0] = a;
		for (b=MIN; b<=MAX; b++) {
			part2[1] = b;
			for (c=MIN; c<=MAX; c++) {
				part2[2] = c;
				for (d=MIN; d<=MAX; d++) {
					part2[3] = d;
					for (e=MIN; e<=MAX; e++) {
						part2[4] = e;
						for (f=MIN; f<=MAX; f++) {
							part2[5] = f;
							checksum = get_checksum(part2);
							if (((username_sum^ checksum) & 0xff)==0x1C) {
								sprintf(serial, "62-%s", part2);
								printf("found! %s\n", serial);
								result++;
							}
							
							if (result > CEILING) return 0;
						}
					}
				}
			}
		}
	}


	return 0;
}
