/* -*- mode: c++ -*-
 * $Id: $
 */

#include <iostream>
#include <string>
#include <sstream>
#include <numeric>
#include <cctype>

using namespace std;

const string KEY_PREFIX = "62";
const unsigned char JMP_OFFSET = 0x1C;

unsigned char name_chksm(const string& name) {
	unsigned long c = accumulate(name.begin(), name.end(), 0);
	return static_cast<unsigned char>(c*c);
}

unsigned char key_chksm(const string& key) {
	unsigned long c = accumulate(key.begin(), key.end(), 0);
	return static_cast<unsigned char>((-c)&0xFF);
}

char rand_char() {
	char c;
	do {
		c = rand();
	} while( isspace(c) || !isalnum(c) );
	return c;
}

string rand_string(size_t len) {
	string s(len, ' ');
	generate(s.begin(), s.end(), rand_char);
	return s;
}


/* build random string s with key_chksm(s) == chksm */
string find_rand_key(unsigned char chksm) {

	string k = rand_string(4);
	unsigned char current_chksm = 0;

	do {
		unsigned char c = current_chksm - chksm;
		if(isspace(c) || !isalnum(c)) {
			c = rand_char();
		}
		k += c;
		current_chksm = key_chksm(k);
	} while(current_chksm != chksm); 
	
	return k;
}

string generate_key(const string& name) {
	
	unsigned char nchk = name_chksm(name);
	unsigned char kchk = JMP_OFFSET ^ nchk;
	string        key  = find_rand_key(kchk);

	ostringstream os;
	os << KEY_PREFIX << "-" << key;
	return os.str();
}


int main(int argc, char *argv[]) {
	string name;

	srand(time(NULL));

	cout << "--[ macabre's frogger Crackme - keygen.crp- ]-----------\n";
	cout << "name: ";
	getline(cin, name);

	if(name != "") {
		string key = generate_key(name);

		cout << "key:  " << key << "\n";
		cout << "--\n";
		cout << "./frogger \"" << name << "\" \"" << key << "\"\n";
	} else {
		cerr << "empty name...\n";
	}

	return 0;
}




