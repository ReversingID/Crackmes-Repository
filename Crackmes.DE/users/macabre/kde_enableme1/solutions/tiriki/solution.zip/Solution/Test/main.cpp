#include <QtGui/QApplication>
#include "Test.h"


int main(int argc, char** argv)
{
    QApplication app(argc, argv);
    Test foo;
    foo.show();
    return app.exec();
}
