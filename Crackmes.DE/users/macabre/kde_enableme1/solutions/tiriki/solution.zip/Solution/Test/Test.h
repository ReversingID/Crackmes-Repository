#ifndef Test_H
#define Test_H

#include <QtGui/QMainWindow>

class Test : public QMainWindow
{
Q_OBJECT
public:
    Test();
    virtual ~Test();
};

#endif // Test_H
