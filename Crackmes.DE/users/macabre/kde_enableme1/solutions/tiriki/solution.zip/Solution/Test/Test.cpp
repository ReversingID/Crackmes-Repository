#include "Test.h"

#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QAction>

Test::Test()
{
    QPushButton* l = new QPushButton( this );
    l->setText( "enable me!" );
    l->setEnabled(true);
    setCentralWidget( l );
    QAction* a = new QAction(this);
    a->setText( "Quit" );
    connect(a, SIGNAL(triggered()), SLOT(close()) );
    menuBar()->addMenu( "File" )->addAction( a );
}

Test::~Test()
{}

#include "Test.moc"
