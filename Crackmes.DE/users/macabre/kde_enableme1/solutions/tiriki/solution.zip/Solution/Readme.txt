Hello

Now I solved my very first crackme. Here is what I did.

First I created a dummy application with KDevelop which just 
contained a pushbutton. I built it, once with enabled = true and once 
with enabled = false. You may find this in the "Test" directory.

Second I executed that dummy application with the Data Display 
Debugger, so I could step thru and also see the source. By doing so, 
I saw, that there was a subroutine named "_ZN7QWidget10setEnabledEb" 
which was in charge to disable the button.

Third I looked in the enableme, whether the same subroutine exists. 
It does and when I set a breakpoint on it, I can see in the stack 
where from it was called. Disassembling the calling address gives me: 
"call *0x54(%eax)" or in hex: "ff 50 54"

Fourth I opened the enableme in a hex editor and searched for 
"ff 50 54". I found it twice once at 0x4b5b and once at 0x4ddb. After 
I altered the second place to "90 90 90" (hex-code for "nop") the 
button was enabled. (Actually not enabled but just not disabled).

For an absolute beginner like me, this was quite difficult although 
I acknowledge that for a pro, this would be just some time waste. But 
interesting to learn (and that's what it is for).