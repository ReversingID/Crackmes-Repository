Macabre's Infector Crackme does:
================================
 Main goal: create an unpacker.
  - The infector adds his code in 0x0000 - 0x0be60
  - It does an xor with the password host and the binary file.
  - Then adds these xored content sinse 0x0be60
  - He uses 4 bytes at end, but I don't know why.

 Sub goal1: get the password for the host app.
  - The password is xored sinse 0x0be60

 Sub goal2: get the enable password for the infector.
  - The password is imul'ted and compared with 0xA749A990h

my solution is:
===============
 Main goal:
  - I've created the unpacker.

 Sub goal1:
  - The host password is: disease
 
 Sub goal2:
  - The enable password is: _beex

EXAMPLE1: see the host password
===============================

whats@x61s:~/crackme/inf-unpackme/final$ ./unpacker ../unpackme
KeyGenMe1/ascii keygen by whats
===============================
 If the file is an ELF, the password is something like this, but without the
 repeated substring!
  * diseasedis

In this case, the password is disease

EXAMPLE2: unpack a file
=======================

whats@x61s:~/crackme/inf-unpackme/final$ ./unpacker ../unpackme unpacked disease
KeyGenMe1/ascii keygen by whats
===============================
 * Unpacked file: unpacked

NOTE: 
=====
Change de code to try unpack an ELF without promt the password, is very
ease, but not always possible.
