/* 
 * Albert Sellarès <whats[at]wekk.net>
 * http://www.wekk.net
 *
 * Solution for Infector-Unpackme/macabre - http://crackmes.de
 * gcc unpacker.c -o unpacker
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>

char elfheader[21] = "\x7f\x45\x4c\x46\x01\x01\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x03\x00\x01";
char * pass;
int i;
int pass_size;

void xor(char * buff1, char * result){
	int i,j=0;
	for (i=0; i<21; i++) {
		if (elfheader[i] != 0x00){
			result[j] = buff1[i] ^ elfheader[i];
			j++;
		}
	}
	result[10] = '\0';
}

void password(char * pass, int fd){
	char buff[21];
	char result[11];
	if (!pass){
		read(fd, &buff, 21);
		xor(buff, result);
		printf(" If the file is an ELF, the password is something like this, but without the repeated substring!\n * %s\n",result);
	}
}

char transform(char byteread) {
	if ( byteread != pass[i] && byteread != 0x00){
		byteread = byteread ^ pass[i];
		i++;
		if (i==pass_size) i=0;
	}
	return byteread;
}

int main(int argc, char *argv[]) {
	int fdpacked, fdunpacked, bytes=0, filesize;
	unsigned char byte;
	unsigned char byteread;
	
	printf("KeyGenMe1/ascii keygen by whats\n");
	printf("===============================\n");

	if (argc != 2 && argc != 4){
		printf(" * Usage: ./unpacker packed_file [unpacked_file password]\n * With only one param, it tells the password.");
		exit(0);
	}

	fdpacked=open(argv[1],O_RDONLY);
	if (fdpacked<0) {
		perror("open packed file");
		exit(0);
	}

	if (lseek(fdpacked,48736,SEEK_SET) <0){
		perror("lseek");
		exit(0);
	}	
	
	if (argc !=4) {
		password(0, fdpacked);
		exit(0);
	}

	//printf(" * Unpacking file: %s\n",argv[1]);
	pass = argv[3];
	pass_size = strlen(argv[3]);

	fdunpacked=open(argv[2],O_TRUNC|O_CREAT|O_RDWR,S_IRWXU);
	if (fdunpacked<0){
		perror("create unpacked file");
		exit(0);
	}

	if ((filesize = lseek(fdpacked, 0, SEEK_END)-48736-4) < 0){
		perror("lseek");
		exit(0);
	}

	if (lseek(fdpacked,48736,SEEK_SET) <0){
		perror("lseek");
		exit(0);
	}	
	
	i=0;
	while(((bytes+=read(fdpacked,&byteread,sizeof(unsigned char))) || errno == -EINTR) && bytes <= filesize ){
		byte = transform(byteread);
		write(fdunpacked,&byte,sizeof(unsigned char));
	}
	printf(" * Unpacked file: %s\n",argv[2]);

	close(fdunpacked);
	close(fdpacked);

	return 0;
}
