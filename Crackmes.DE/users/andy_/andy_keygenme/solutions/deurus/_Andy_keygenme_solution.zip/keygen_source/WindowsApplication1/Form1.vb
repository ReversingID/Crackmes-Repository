﻿Public Class Form1

    Private Sub tb1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tb1.TextChanged
        Dim letra As Integer
        Dim pass As String
        If Len(tb1.Text) < 4 Then
            tb2.Text = "min 4 chars"
        Else
            For x As Integer = 1 To Len(tb1.Text)
                letra = Asc(Mid(tb1.Text, x, 1))
                letra = letra Xor 32
                pass = Chr(letra) & pass
            Next
            tb2.Text = pass
        End If
    End Sub
End Class
