#include <iostream>
#include <sstream>
#include <string>

using namespace std;

int main(int argc, char *argv[])
{
	string name, key;
	ostringstream oss;

	int i;
 	getline(cin, name);

	oss << name.substr(0, name.length()-4) << "-py";

	for (i = 0; i < name.length(); i += 2)
		oss << name[i];
	oss << ((name.length()+3)/4) << "m-c" << name.substr(3, name.length()-4) << name.length()*2;


	key = oss.str();
	oss << "?A";

	for (i = 0; i < key.length(); i += 2)
		oss << key[i];

	key = "m0-" + oss.str() + "43";

	cout << key << endl;

	return 0;
}
