#! /usr/bin/env python

print "moofy's python crackme #1"
print 'There are two parts to this crackme:'
print 'fish a serial and then you must solve the keygenme'
print 'Good luck!\n'
key = raw_input('Enter a key: ')
yek = 'g0odwerk'
if (key == yek):
	name = raw_input('Enter your name: ')
	sp1 = (((((((name[:-4] + '-') + 'py') + name[None:None:2]) + str(len(name[None:None:-4]))) + 'm-c') + name[3:-1]) + str((len(name) * 2)))
	sp2 = sp1[None:None:2]
	sp3 = (((sp1 + '?A') + sp2) + '43')
	serial = ('m0-' + sp3)
	ukey = raw_input('Enter your serial: ')
	if (ukey == serial):
		print 'Good job! Now make a keygen and submit to crackmes.de!'
	else:
		print 'badboy'
else:
	print 'badboy'