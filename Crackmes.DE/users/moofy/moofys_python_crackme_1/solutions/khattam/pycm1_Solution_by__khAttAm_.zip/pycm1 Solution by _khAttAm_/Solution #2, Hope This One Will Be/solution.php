<?php
echo '

Solution #2 to moofy\'s python crackme #1

';

if ($argc!=2) die("Usage: php solution.php name. 
Usernames with spaces must be enclosed in double quotes");

$name=$argv[1]; //Take the value of name from commandline

//The code is always 'g0odwerk'. Lets print it first.
echo "Code: g0odwerk
Name: $name
";

//The serial takes the first n-4 characters from the name, where n is the length of the name. So we do this in php. It is done in python by name[:-4] as in line 13.
$len=strlen($name);
for($i=0;$i<$len-4;$i++) $sp1part.=$name[$i];

//A dash is then appended.as + '-' in line 13
$sp1part.='-';

//Then 'py' is appended as + 'py' in line 13
$sp1part.='py';

//Now it adds + name[None:None:2])  i.e. it adds alternate characters for any given name i.e. for _khAttAm_, it would take _htA_. That we are going to do in PHP
for($i=0;$i<$len;$i+=2) $alt.=$name[$i];

//Lets append that to sp1
$sp1part.=$alt;

//Now, it takes the length of the name and then by taking the entered name and taking 1st character and then every fourth character from it from the reverse side and takes its length i.e. if I entered a 12 character name, it would take 12th, 4th and 1st characters and form a three charactered string and take its length, so that the resulting length is 3. The code for that is in the 13th line too, str(len(name[None:None:-4]))). There, it converts the thing to string for appending it in the sp1 string. We can do it here, but an easier algo to do the same thing has been inplemented here
$i=$len/4;
$tricky_len=intval($i);
if($tricky_len-$i) $tricky_len++;

//Lets append this too to sp1
$sp1part.=$tricky_len;

//Now again 'm-c' is appended into the file in line 13, so lets do that too
$sp1part.='m-c';

//Now, characters of the name from 3rd to n-1th characters of sting are added into sp1. Lets do that in PHP
for($i=3;$i<$len-1;$i++)
{
$sp1part.=$name[$i];
}

//Now, finally the final part of the sp1 is the length of the string multiplied my 2, and appended to the string. Lets do that to complete the sp1 part
$sp1=$sp1part.$len*2;

//Lets work on sp2 on line 14 of the source. It takes the alternate characters of the sp1 calculated above, so lets do that
for($i=0;$i<strlen($sp1);$i+=2) $sp2.=$sp1[$i];

//As of line number 15, sp3 is calculated by adding '?A' to sp1 and then adding sp2 to the resulting thing and then finally adding '43' to it. So lets do that
$sp3=$sp1.'?A'.$sp2.'43';

//Each serial contains this thing at the beginning. This is in the 16th line of the included source.  serial = ('m0-' + sp3). Lets do that now.
$serial='m0-'.$sp3; 

//OK now final serial for the given name is ready. Lets print it.
echo "Serial: $serial

";
?>