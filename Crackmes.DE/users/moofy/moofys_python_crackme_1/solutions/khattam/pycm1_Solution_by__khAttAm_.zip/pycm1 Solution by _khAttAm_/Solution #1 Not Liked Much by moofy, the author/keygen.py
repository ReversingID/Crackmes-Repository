#! /usr/bin/env python
# emacs-mode: -*- python-*-
# -*- coding: utf-8 -*-

print "_khAttAm_'s keygen to moofy's python crackme #1"
yek = 'g0odwerk'
print 'The key is:\n'
print yek
name = raw_input('Enter your name: ')
print name[None:None:-4]
sp1 = (((((((name[:-4] + '-') + 'py') + name[None:None:2]) + str(len(name[None:None:-4]))) + 'm-c') + name[3:-1]) + str((len(name) * 2)))
sp2 = sp1[None:None:2]
sp3 = (((sp1 + '?A') + sp2) + '43')
serial = ('m0-' + sp3)
print 'The serial is : '
print serial

# local variables:
# tab-width: 4