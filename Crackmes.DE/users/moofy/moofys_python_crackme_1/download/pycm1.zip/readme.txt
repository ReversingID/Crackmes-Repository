moofy's python crackme #1
tools used to create this crackme: brain, nano
diffculty: 1 - although may be difficult to decompile if you dont have the right tools heh heh heh
           if you think its possible, try to solve it without decompiling :)
well, fish a key then solve and make a keygen*
obviously, write a tutorial and submit it to crackmes.de

to run, youll need python installed

*preferably in another language than python - youd be cheating otherwise :)
