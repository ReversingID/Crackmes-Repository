moofy's simple keygenme #1
level: 1/10

Simple algo, shouldnt be too hard :)

When cracked, write a valid keygen and tutorial and submit it to crackmes.de