#include <iostream.h>
#include <windows.h>
void main()
{
	char name[20];
	int i,j;

	cout<<"\n=====Keygen for Moofy's KeygenME#1 by l0calh0st=====";
ReCalc:
	cout<<"\n\n\nEnter your name : ";
	cin>>name;
	i=strlen(name);
	if(i<2)
	{
		cout<<"\nName should have atleast 2 characters.";
		goto ReCalc;
	}
		
    j=name[0]+name[i-1];
	i=j;
	cout.setf(ios::hex);
	_asm
	{
	
		shl j,2
	
		
	}

	j=(j+i)*2+0x2990;
	cout.unsetf( ios::hex );
	cout.setf(ios::dec);
	cout<<"\nYour serial is : "<<j<<endl<<endl<<endl;
	
	system("PAUSE");
}



