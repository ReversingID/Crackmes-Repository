moofy's psp crackme #1
level: 2/10
System: a psp
Coded in c++ on 3/29/07, redone on 3/31/07

This is a crackme for the psp. It should run like a normal homebrew,
so you need to use eLoader if you have a 2.0->2.7 and a HEN (a homebrew
enabler) to run if you have 2.8+. If you have 1.5, put the eboot in
a folder in /psp/game. I will not help if you dont know how to load
it, since its really all over google.

What you need to do is patch it to say cracked rather than uncracked.

Submit a tutorial when your done, or email it to me.

Thanks to bLaCk-eye for some suggestions.
Enjoy.
-moofy