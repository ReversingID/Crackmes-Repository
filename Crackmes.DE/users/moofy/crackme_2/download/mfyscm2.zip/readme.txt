moofy's crackme #2
written in asm on 3/19/07
Level: 1-2/10 depending on what you know

what to do:
find valid serial for your name (hint: it heavily relies on the length)

what NOT to do:
patching
self keygen
etc

submit solution to crackmes.de and/or email it to me at icyflamez@gmail.com