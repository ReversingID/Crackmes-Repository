﻿using System;
using System.Collections.Generic;
using System.Text;

namespace keygen_zyrel_crme2
{
    class serial_number
    {
        public string Generate(string name) {
            char[] aname = name.ToCharArray();
            int a = 0;
            foreach (char s in aname)
            {
                a += (int)s;
            }
            int b = a ^ (name.Length * name.Length * name.Length);
            
            int part2 = (int)(Math.Pow(aname[aname.Length-1] * aname[0], 2)) ^ 0xB221;
            int part1 = part2 / b;
          
            return part1.ToString() + "-" + part2.ToString();
        }
    }
}
