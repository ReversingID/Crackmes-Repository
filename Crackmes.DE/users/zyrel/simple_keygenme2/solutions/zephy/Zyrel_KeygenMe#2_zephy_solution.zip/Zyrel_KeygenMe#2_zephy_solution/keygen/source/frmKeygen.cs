﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace keygen_zyrel_crme2
{
    public partial class frmKeygen : Form
    {
        public frmKeygen()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length <= 4)
            {
                MessageBox.Show("Name lenght must be greatest then 4 chars!","Exclamation",MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            serial_number serial = new serial_number();
            textBox2.Text = serial.Generate(textBox1.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
