A simple keygenme, No patches are allowed!
make a keygen and submit it ;)

--Zyrel.