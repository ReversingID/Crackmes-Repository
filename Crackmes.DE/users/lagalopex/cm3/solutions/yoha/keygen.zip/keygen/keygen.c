// keygen for browselagalopex's cm3
// http://www.crackmes.de/users/lagalopex/cm3/

// Compile with
// gcc -Wall -Wextra -Werror -pedantic -ansi -std=c99 -O3 keygen.c rmd160.C
// the only requisite flag is -std=c99

// The serial is a 160 byte long key to be put in the file ~/.key_NAME
// where NAME is the provided NAME. The serial is actually a list of 20
// pairs of 32 bit integers. Five arithmetics tests are run against each
// pair as well as a check against a RIPEMD-160 hash of a string
// depending of the NAME and the process environment.


#define _XOPEN_SOURCE 500 // requisite for getsid()
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <pwd.h>

unsigned long gcd(unsigned long A, unsigned long B)
{
	if (A < B)
		return gcd(B, A);
	if (B == 0)
		return A;
	return gcd(B, A%B);
}

unsigned char calc(unsigned long A, unsigned long B)
{
	unsigned long long left  = (unsigned long long) 0x6bca1af3*A;
	unsigned long long right = (unsigned long long) 0xae4c415e*B;
	return (left>>35) + (right>>38);
}

unsigned long* primes;
unsigned long nprimes;
unsigned long aprimes;
void getprimes()
{
	primes = malloc(sizeof(unsigned long));
	primes[0] = 2;
	nprimes = 1;
	aprimes = 1;
	for (unsigned long i = 3; i < (1<<16); i += 2)
	{
		char p = 1;
		for (unsigned long j = 0; j < nprimes; j++)
			if (i % primes[j] == 0)
				p = 0;
		if (!p)
			continue;

		if (nprimes == aprimes)
		{
			aprimes *= 2;
			primes = realloc(primes, sizeof(unsigned long) * aprimes);
		}
		primes[nprimes++] = i;
	}
}
unsigned long radix(unsigned long X)
{
	unsigned long ret = 1;
	for (unsigned long i = 0; i < nprimes; i++)
		if (X % primes[i] == 0)
		{
			ret *= primes[i];
			while (X % primes[i] == 0)
				X /= primes[i];
		}
	return ret * X; // at that point, X is 1 or prime
}

void rndchar4(char x[4])
{
	// I avoid non-printable characters for convenience
	x[0] = 32 + (rand() % 96);
	x[1] = 32 + (rand() % 96);
	x[2] = 32 + (rand() % 96);
	x[3] = 32 + (rand() % 32); // must be under 0x40 = '@'
}

unsigned char* RMD(unsigned char*);
int main(int argc, char** argv)
{
	if (argc < 2)
		exit(0);

	srand(42);
	getprimes();

	char buffer[256];
	struct passwd* userinfo = getpwuid(getuid());
	snprintf(buffer, 256, "%s/.key_%s_%i", userinfo->pw_dir, argv[1], getsid(0) - getppid());
	unsigned char* hash = RMD((unsigned char*) buffer); // 20 bytes
	for (int i = 0; i < 20; i++, hash++)
	{
		unsigned long A;
		unsigned long B;
		unsigned long S;
		do
		{
			rndchar4((char*) &A);
			rndchar4((char*) &B);
			S = A + B;
		}
		while (gcd(A, B) != 1    ||
		       gcd(A, S) != 1    ||
		       gcd(B, S) != 1    ||
		       A >= B            ||
		       radix(A*B*S) >= S ||
		       calc(A, B) != *hash);
/*
		printf("gcd(%i, %i) = %i\n", A, B, gcd(A, B));
		printf("gcd(%i, %i+%i) = %i\n", A, A, B, gcd(A, A+B));
		printf("gcd(%i, %i+%i) = %i\n", B, A, B, gcd(B, A+B));
		printf("radix(%i * %i * %i) = %i\n", A, B, A+B, radix(A*B*(A+B)));
		printf("calc(%i, %i) = %i\n", A, B, calc(A, B));
*/
		write(1, &A, 4);
		write(1, &B, 4);
	}
	write(1, "\n", 1);
	return 0;
}

// SOURCE http://homes.esat.kuleuven.be/~bosselae/ripemd160/ps/AB-9601/hashtest.c

/********************************************************************\
 *
 *      FILE:     hashtest.c
 *
 *      AUTHOR:   Antoon Bosselaers, ESAT-COSIC
 *      DATE:     18 April 1996
 *      VERSION:  1.1
 *      HISTORY:  bug in RMDonemillion() corrected
 *
 *      Copyright (c) Katholieke Universiteit Leuven
 *      1996, All Rights Reserved
 *
\********************************************************************/
#ifndef RMDsize
#define RMDsize 160
#endif

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#if RMDsize == 128
#include "rmd128.h"
#elif RMDsize == 160
#include "rmd160.h"
#endif

#define TEST_BLOCK_SIZE 8000
#define TEST_BLOCKS 1250
#define TEST_BYTES ((long)TEST_BLOCK_SIZE * (long)TEST_BLOCKS)

/********************************************************************/

byte *RMD(byte *message)
/*
 * returns RMD(message)
 * message should be a string terminated by '\0'
 */
{
   dword         MDbuf[RMDsize/32];   /* contains (A, B, C, D(, E))   */
   static byte   hashcode[RMDsize/8]; /* for final hash-value         */
   dword         X[16];               /* current 16-word chunk        */
   unsigned int  i;                   /* counter                      */
   dword         length;              /* length in bytes of message   */
   dword         nbytes;              /* # of bytes not yet processed */

   /* initialize */
   MDinit(MDbuf);
   length = (dword)strlen((char *)message);

   /* process message in 16-word chunks */
   for (nbytes=length; nbytes > 63; nbytes-=64) {
      for (i=0; i<16; i++) {
         X[i] = BYTES_TO_DWORD(message);
         message += 4;
      }
      compress(MDbuf, X);
   }                                    /* length mod 64 bytes left */

   /* finish: */
   MDfinish(MDbuf, message, length, 0);

   for (i=0; i<RMDsize/8; i+=4) {
      hashcode[i]   =  MDbuf[i>>2];         /* implicit cast to byte  */
      hashcode[i+1] = (MDbuf[i>>2] >>  8);  /*  extracts the 8 least  */
      hashcode[i+2] = (MDbuf[i>>2] >> 16);  /*  significant bits.     */
      hashcode[i+3] = (MDbuf[i>>2] >> 24);
   }

   return (byte *)hashcode;
}

/********************************************************************/
