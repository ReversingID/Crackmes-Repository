PATH_TO_MIRACL=/home/dani/miracl
gcc -c rad.c -I $PATH_TO_MIRACL
gcc -o keygen keygen.c  exteuc.c hash.c rmd160.c rad.o miracl.a
