#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "rmd160.h"

#include <sys/types.h>
#include <pwd.h>
#include <string.h>

extern void extended_euclid(long a, long b, long *x, long *y, long *d);
extern int calc(int *v);
extern int rad(int a);
extern byte *RMD(byte *message);
extern int rad_(int a);
extern int init_miracl();
extern int end_miracl();

int solve_calc(int x, int k)
{
	// x/19 + y/94 = k

	int d = k - (int)(x/19);

	return  d*94;	// valid solutions are from the returned value to retvalue+94 and for each one:   + n*94*256  para todo n entero

	
}


int main(int argc, char **argv)
{
	unsigned int x, sum, i,j,k=1;
	int y, v[4];
	int a,b,gcd;
	byte *hashcode;
	int index=0;
	int found=0;
	int calcret;
	unsigned int calcrad;
	unsigned int x_s[20], y_s[20];
	struct passwd *pwbuf;
	char hashstr[128], username[16];
	FILE *p;
	
	printf("Username: "); fflush(stdout);
	fgets(username,16,stdin);
	username[strlen(username)-1]='\0';
	pwbuf=getpwuid(getuid());
	sprintf(hashstr,"%s/.key_%s_0",pwbuf->pw_dir,username);

	hashcode = RMD(hashstr);

	printf("Sieve of Eratosthenes Prime Generation..."); fflush(stdout);
	init_miracl();
	printf("OK\n");

	printf("%%%d completed\r",index*5);

	while(index < 20)
	{
		if( found == 1 )
			found=0;

		for(x=0;x<0x7fffffff;x+=19)
		{
			if(found==1)
				break;


			calcret=solve_calc(x, hashcode[index]);
			if( calcret > 0 && calcret > x)
			{

				for(i=x;i<(x+18);i++)
				{
					if( found == 1 )
						break;
					if( i == 0 )
						i++;
					for(k=1;k<0x7FFFFF;k+=256)
					{
						if(found==1)
							break;

						for(j=k*calcret;j<(k*calcret+94);j++)
						{
							if( !(i&1) && !(j&1) )
								continue;
							sum=i+j;

							calcrad=rad((i*j*sum));
							if(calcrad >= sum ) 
								continue;


							extended_euclid(i,j,(long*)&a,(long*)&b,(long*)&gcd);
							if( gcd != 1 )
								continue;
						
							extended_euclid(i,sum,(long*)&a,(long*)&b,(long*)&gcd);
							if( gcd != 1 )
								continue;

							extended_euclid(j,sum,(long*)&a,(long*)&b,(long*)&gcd);
							if( gcd != 1 )
								continue;
							
							v[0]=i; v[1]=j; v[2]=sum;
							printf("%d%% completed\r",(index+1)*5); fflush(stdout);
							x_s[index]=i;
							y_s[index]=j;
							found=1;
							index++;
							break;
						}
					}
				}
			}
		}
	}
	printf("\n");

	sprintf(hashstr,"%s/.key_%s",pwbuf->pw_dir,username);
	printf("Writing license info into %s\n",hashstr);
	p=fopen(hashstr,"wb");
	if(!p)
	{
		printf("Error opening the file\n");
		end_miracl();
		exit(1);
	}
	
	for(i=0;i<20;i++)
	{
		fwrite(x_s+i,1,4,p);
		fwrite(y_s+i,1,4,p);
	}
	fclose(p);
	end_miracl();
	exit(1);
}
