/*
 *   Program to factor Integers
 *
 *   Current parameters assume a large 32-bit address space is available.
 *
 *   This program is cobbled together from the implementations of various
 *   factoring algorithms better described in:-
 *
 *   brute.c/cpp     - brute force division by small primes
 *   brent.c/cpp     - Pollard Rho method as improved by Brent
 *   pollard.c/cpp   - Pollard (p-1) method
 *   williams.c/cpp  - Williams (p+1) method
 *   lenstra.c/cpp   - Lenstra's Elliptic Curve method
 *   qsieve.c/cpp    - The Multiple polynomial quadratic sieve
 *
 *   Note that the .cpp C++ implementations are easier to follow
 *
 *   NOTE: The quadratic sieve program requires a lot of memory for 
 *   bigger numbers. It may fail if you system cannot provide the memory
 *   requested.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "miracl.h"



#define LIMIT 0x7fffff
#define BTRIES 1000
#define MULT 2310      /* 2*3*5*7*11    */
#define NEXT 13        /* .. next prime */
#define mr_min(a,b) ((a) < (b)? (a) : (b))

static big *fu;
static BOOL *cp,*plus,*minus;
big n;
FILE *output;
static int PADDING;
static miracl *mip;
char cad[64];

 int rad_ret;
int init_miracl()
{
	int b,d=250;
	b=(d*45)/100;
	#ifndef MR_NOFULLWIDTH
	mip=mirsys(-b,0);
	#else
	mip=mirsys(-b,MAXBASE);
	#endif
	mip->NTRY=100;
	gprime(LIMIT);
}

int end_miracl()
{
	gprime(0);
	mr_free(n);
	mirexit();
}


int brute(void)
{ /* find factors by brute force division */
    big x,y;
    int m,p;
	unsigned  int rad=1, last_p=0;

   
    x=mirvar(0);
    y=mirvar(0);
    m=0;
    p=mip->PRIMES[0];

    forever
    { /* try division by each prime in turn */
        if (subdiv(n,p,y)==0)
        { /* factor found */
            copy(y,n);
	if( last_p != p )
	{
		last_p=p;
		rad*=p;
	}
	if(size(n) == 1){ mr_free(x);    mr_free(y);  return rad;}
       	continue;

        }
        if (size(y)<=p) 
        { /* must be prime */
		p=0;
		cotstr(n,cad);
		p=atoi(cad);
		if(last_p!=p)
		{
			rad*=p;
		}
		mr_free(x);
		mr_free(y);
		return rad;
        }
        p=mip->PRIMES[++m];
        if (p==0) break;
    }
    if (isprime(n)) 
    {

		cotstr(n,cad);
		p=atoi(cad);
		if(last_p!=p)
		{
			rad*=p;
		}
    }
    mr_free(x);
    mr_free(y);
    return rad;
}



int rad(int a)
{


	if( a < 0 )
		return 1;


	n=mirvar(0);
	sprintf(cad,"%d",a);
	cinstr(n,cad);
	  

	if (size(n)==0) 
		return 0;
	 
	if (size(n)<0)
		return 0;
	 
	if (isprime(n))
		return a;

	rad_ret= brute();
		return rad_ret;
}

