#!/usr/bin/env ruby

require "digest/rmd160"
require 'dl'

def bswap(n)
	((n >> 24) & 0xff) | ((n >> 8) & 0xff00) | ((n << 8) & 0xff0000) | ((n << 24) & 0xff000000) 
end

sid = syscall 147, 0
ppid = Process.ppid

dl = DL::dlopen('./cm3_keygen.so')
calc = dl['calc','III']
rad = dl['rad','II']

print "Your name: "
name = gets.chomp!

if name.length < 3 then puts 'At least 3 chars!'; exit end

T = Array.new
H = Array.new
hash = Digest::RMD160.hexdigest("#{ENV["HOME"]}/.key_#{name}_#{ppid-sid}")

20.times { |i|
	H << hash[i*2, 2].to_i(base=16)
	
	found = false
	(0x1..0x7ffffffe).each do |a|
		(a+1..0x7fffffff).each do |b|
			
			c = a + b
			
			if a != 1 && (a.gcd(b) != 1 || a.gcd(c) != 1 || b.gcd(c) != 1) then next end
			
			if rad.call(a*b*c)[0] >= c then next end
			
			if calc.call(a,b)[0] == H[i] then
				T << bswap(a) << bswap(b)
				found = true
				print '.'
				STDOUT.flush
				break
			end
		end
		if found then break end
	end
}

filename = "#{ENV["HOME"]}/.key_#{name}"

File.open(filename, 'w')  { |fd|
	fd.write T.pack('N*')
}

puts
puts "Key saved to #{filename}"
