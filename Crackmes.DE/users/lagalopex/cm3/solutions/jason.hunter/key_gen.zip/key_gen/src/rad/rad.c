#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "integer.h"


// #define compile_rad_directly

extern int miller_rabin(integer n);

int isprime(unsigned long inp)
{
	unsigned long i;
	for (i=2; i*i <= inp; i++)
	{
		if (inp % i == 0)
			return 0;
	}

	return 1;
}

int isprime_miller_rabin(unsigned long inp)
{
	if (inp < 0)
		return 0;

	if (inp < 4)
		return 1;

	integer n = create_integer(1);
	n.c[0] = inp;
	return (miller_rabin(n));
}

int rad_(unsigned long n)
{
	unsigned long result = 1;
	unsigned long newnum = n;
	unsigned long checker = 2;
	unsigned long last_checker = 0;

	while (checker*checker <= newnum)
	{
		if (newnum % checker == 0)
		{
			if (last_checker != checker)
			{
#ifdef compile_rad_directly
				printf("%d ", checker);
#endif
				result *= checker;
				last_checker = checker;
			}
			newnum = newnum/checker;
		}
		else
		{
			checker++;
		}
	}

	if (newnum != 1 && last_checker != newnum)
	{
#ifdef compile_rad_directly
		printf("%d ", newnum);
#endif
		result *= newnum;
	}

	return result;
}



unsigned long rad_slow(unsigned long inp)
{
	unsigned long i, rad;
	rad = 1;

	for (i=2; i<inp; i++)
	{
		if (inp % i != 0)
			continue;

		if (!isprime_miller_rabin(i))
			continue;
#ifdef compile_rad_directly
		printf("%d ", i);
#endif
		rad *= i;
	}

#ifdef compile_rad_directly
	printf("\n");
#endif

	return rad;
}

#ifdef compile_rad_directly

int main(int argc, char **argv)
{
	unsigned long check;

	if (argc != 2)
	{
		fprintf(stderr, "Usage: %s <number>\n", argv[0]);
		exit(1);
	}

	srand(time(NULL));
	unsigned long n = strtoul(argv[1], NULL, 10);
	if (isprime_miller_rabin(n))
		printf("prime!\n");
	else
		printf("not prime.\n");
	printf("rad(%u) = %u\n", n, rad_(n));

	return 0;
}

#endif
