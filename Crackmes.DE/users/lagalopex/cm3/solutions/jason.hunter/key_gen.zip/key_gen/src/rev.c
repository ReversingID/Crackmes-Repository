#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define RMDsize 160


#include "rmd160.h"

byte *RMD(byte *hashcode, byte *message)
{
	dword         MDbuf[RMDsize/32];   /* contains (A, B, C, D(, E))   */
	dword         X[16];               /* current 16-word chunk        */
	word          i;                   /* counter                      */
	dword         length;              /* length in bytes of message   */
	dword         nbytes;              /* # of bytes not yet processed */

	/* initialize */
	MDinit(MDbuf);
	length = (dword)strlen((char *)message);

	/* process message in 16-word chunks */
	for (nbytes=length; nbytes > 63; nbytes-=64) {
		for (i=0; i<16; i++) {
			X[i] = BYTES_TO_DWORD(message);
			message += 4;
		}
		compress(MDbuf, X);
	}                                    /* length mod 64 bytes left */

	/* finish: */
	MDfinish(MDbuf, message, length, 0);

	for (i=0; i<RMDsize/8; i+=4) {
		hashcode[i]   =  MDbuf[i>>2];         /* implicit cast to byte  */
		hashcode[i+1] = (MDbuf[i>>2] >>  8);  /*  extracts the 8 least  */
		hashcode[i+2] = (MDbuf[i>>2] >> 16);  /*  significant bits.     */
		hashcode[i+3] = (MDbuf[i>>2] >> 24);
	}

	return (byte *)hashcode;
}

#define calc_gcd gcd_fast
// #define calc_gcd gcd_


unsigned long gcd_fast(unsigned int a, unsigned int b)
{
      int gcd;
      if(b > a)
      {
          return gcd_fast(b,a);
      }

      if(b == 0)
      {
            return a;
      }

      gcd = gcd_fast(b, a%b);

      return gcd;
}

unsigned long gcd1(unsigned long *inp)
{
	if (calc_gcd(inp[0], inp[1]) == 1)
		return 1;

	return 0;
}

unsigned long gcd2(unsigned long *inp)
{
	if (calc_gcd(inp[0], inp[2]) == 1)
		return 1;

	return 0;
}

unsigned long gcd3(unsigned long *inp)
{
	if (calc_gcd(inp[1], inp[2]) == 1)
		return 1;

	return 0;
}

unsigned long gs(unsigned long *inp)
{
	return (inp[0] < inp[1]);
}

unsigned long rad(unsigned long *inp)
{
	unsigned long i8, r;

	r = inp[0];
	r *= inp[1];
	i8 = inp[2];
	r *= i8;

	r = rad_(r);
	if (i8 >= r)
		return 1;

	return 0;
}

int check_token(unsigned long *token, char name_hash)
{
	char cret;
	unsigned long ret;
	unsigned long test_hash[4];

	test_hash[0] = token[0];
	test_hash[1] = token[1];
	test_hash[2] = test_hash[0] + test_hash[1];
	test_hash[3] = 0;

	ret = gs(&test_hash[0]);
	if (ret != 1)
	{
		// printf("gs failed (%08x)\n", ret);
		return 5;
	}

	// do the fast calculation first...
	cret = calc(&test_hash[0]);
	if (cret != name_hash)
	{
		// printf("  check is %02x but should be %02x\n", ret, name_hash);
		return 1;
	}

	ret = gcd1(&test_hash[0]);
	if (ret != 1)
	{
		// printf("gcd1 failed\n");
		return 2;
	}

	ret = gcd2(&test_hash[0]);
	if (ret != 1)
	{
		// printf("gcd2 failed\n");
		return 3;
	}

	ret = gcd3(&test_hash[0]);
	if (ret != 1)
	{
		// printf("gcd3 failed\n");
		return 4;
	}

	ret = rad(&test_hash[0]);
	if (ret != 1)
	{
		// printf("rad failed (%08x)\n", ret);
		return 6;
	}

	return 0;
}

int main(int argc, char **argv)
{
	unsigned char *name;
	byte   name_hash[RMDsize/8];
	unsigned long test_hash[2];
	int i, ii, j1, j2;
	unsigned long ret, check;

	if (argc != 2)
	{
		fprintf(stderr, "Usage: %s <string>\n", argv[0]);
		fprintf(stderr, "  string is typically '/home/<userid>/.key_<name>_0'\n");
		fprintf(stderr, "  if you are not using gdb or any other tool...\n");
		fprintf(stderr, "\n");
		fprintf(stderr, "  Hint: This program outputs information on stdout\n");
		fprintf(stderr, "  and writes the key to stderr\n");
		fprintf(stderr, "\n");
		fprintf(stderr, "  Invoking it with\n");
		fprintf(stderr, "  %s 2>/home/<userid>/.key_<name>\n", argv[0]);
		fprintf(stderr, "  thus makes sense ;-)\n");
		exit(1);
	}

	name = argv[1];
	if (strlen(name) < 3)
	{
		fprintf(stderr, "Error: string must be at least 3 characters!\n");
		fprintf(stderr, "sorry ;-)\n");
		exit(1);
	}

	printf("generating checks for\n");
	printf("  name = '%s'\n", name);

	RMD(name_hash, (byte *)name);
	printf("  name hashed = '");
	for (i=0; i<20; i++)
	{
		printf("%02x", name_hash[i]);
	}
	printf("'\n");

	char *t = (char*)test_hash;
	for (ii=0; ii<20; ii++)
	{
		printf("generating serial character #%i\n", ii);
		for (j1=0x1; j1<0x7ffffffe; j1++)
		{
			test_hash[0] = j1;

			for (j2=j1; j2<0x7ffffffe; j2++)
			{
				test_hash[1] = j2;

				check = check_token(test_hash, name_hash[ii]);
				if (!check)
				{
					printf("  ");
					for (i=0; i<4; i++)
					  printf("%02x", (unsigned int)((unsigned char)(t[i])));

					printf(" ");
					for (i=4; i<8; i++)
					  printf("%02x", (unsigned int)((unsigned char)(t[i])));

					printf(" = '");
					for (i=0; i<4; i++)
					  printf("%c", t[i]);

					printf(" ");
					for (i=4; i<8; i++)
					  printf("%c", t[i]);

					printf("'\n");

					// print to stderr so it can
					// be redirected to a file
					for (i=0; i<8; i++)
					  fprintf(stderr, "%c", t[i]);

					j1 = 0x7ffffffe;
					break;
				}
			}
		}
	}

	return 0;
}
