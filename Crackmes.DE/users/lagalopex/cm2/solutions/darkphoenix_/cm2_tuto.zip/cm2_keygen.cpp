#include <iostream>
#include <string>
#include <cstdlib>

using namespace std;

int main(void)
{
	string username;
	do
	{
		cout << "Username (at least 4 chars): ";
		cin >> username;
	} while ( username.length() < 4 );

	int edi = 1;
	short a = 0;
	int b;
	for ( int esi = 0 ; esi < 1024 ; ++esi )
	{
		int i = username[esi % username.length()] + edi;
		
		edi = i % 0xFB;
		b = edi;
		a = (a + edi) % 0xFB;
	}

	int s1, s2, s3, s4;
	srand(time(0));
	s1 = rand() % 256;
	s3 = s1 ^ a;
	s2 = s3 ^ 0x8A;
	s4 = s2 ^ b;

	unsigned serial = ~((s1 << 24) | (s2 << 16) | (s3 << 8) | s4);
	
	cout << "Serial: " << serial << endl;
	
	return EXIT_SUCCESS;
}

