// Keygen for lagalopex's cm2
// http://www.crackmes.de/users/lagalopex/cm2/

// Compile with
// $ gcc -Wall -Wextra -Werror -pedantic -ansi -std=c99 -O3 keygen.c
// The only requisite flag is -std=c99

// The executable takes three arguments: name, key and serial.
// The name is a string ; the key and the serial 32 bit integers.
// The key is needed to decode the check function. It had to be found
// manually. The serial depends on two fingerprints of the name, x3c and
// x2e which are basically sums of the characters of the name (1024
// iterations, see below for details). The check binds each byte of the
// serial with each others. Therefore, one is taken randomly and the
// other infered.

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

#define KEY (0xA0662CF3)

int main(int argc, char** argv)
{
	if (argc < 2)
	{
		printf("Usage: %s name\n", argv[0]);
		exit(0);
	}

	srand(time(NULL));

	char* name = argv[1];
	int len = strlen(name);
	int x3c = 1;
	int x2e = 0;
	for (int i = 0; i < 1024; i++)
	{
		x3c = (x3c + name[i%len]) % 251;
		x2e = (x2e +         x3c) % 251;
	}


	long serial;
	char* bytes = (char*) &serial;
	bytes[0] = rand();
	bytes[2] = bytes[0] ^ x3c;
	bytes[1] = bytes[2] ^ 0x8a;
	bytes[3] = bytes[1] ^ x2e;

	printf("./cm2 %s %u %lu\n", name, KEY, serial);
	return 0;
}
