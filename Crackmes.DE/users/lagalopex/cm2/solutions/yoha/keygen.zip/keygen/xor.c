#include <stdlib.h>
#include <stdio.h>
#define BUFSIZE 1024
typedef unsigned long word;
int main(int argc, char** argv)
{
	if (argc < 6)
	{
		printf("Usage: %s src dst offset length mask\n", argv[0]);
		exit(0);
	}

	FILE* src = fopen(argv[1], "r");
	FILE* dst = fopen(argv[2], "w");

	if (!src)
	{
		fprintf(stderr, "Could not open '%s'\n", argv[1]);
		exit(1);
	}
	if (!dst)
	{
		fprintf(stderr, "Could not open '%s'\n", argv[2]);
		exit(1);
	}

	int offset = atoi(argv[3]);
	int end = offset + atoi(argv[4]);
	word mask = (unsigned long) atoll(argv[5]);

	word buffer[BUFSIZE];
	int r;
	int c = 0;
	do
	{
		r = fread(buffer, 1, BUFSIZE*sizeof(word), src);
		for (int i = 0; i < BUFSIZE; i+=1, c+=sizeof(word))
			if (offset <= c && c < end)
				buffer[i] ^= mask;
		fwrite(buffer, 1, r, dst);
	} while (r == BUFSIZE*sizeof(word));
	fclose(src);
	fclose(dst);

	return 0;
}
