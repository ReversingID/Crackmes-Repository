/**
* Keygen for hackereha's Crackme by hackereh@!
* Author: mjones
* August 25, 2009
*
* Keygen creates a serial for the app,
* then outputs the serial to STDOUT
*/

#include <iostream>

using namespace std;

int main() {
    char serial[7] = {0};

    serial[0] = (char)~0xAD;
    serial[1] = (char)~0x9A;
    serial[2] = (char)~0x97;
    serial[3] = (char)~0xBF;
    serial[4] = (char)~0xC5;
    serial[5] = (char)~0xD6;

    std::cout << "Serial is " << serial << endl;

    std::cin.get();
    std::cin.get();
    return 0;
}