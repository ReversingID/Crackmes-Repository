#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
	unsigned int i,len,temp1,temp2;
	char name[199];
	printf("*************************************************\n");
	printf("*** Keygen for Hackereha's KeygenMe by br0ken ***\n");
   	printf("*************************************************\n");
	printf("\n\nEnter your name (1 <= name length <= 24) = ");
	scanf("%s",name);
    	len=strlen(name);
	temp2=0xDEADC0DE;
	for(i=0;i<len;i++)
	{
      	temp1 = temp2 + name[i];
	   temp1 = temp1 * 0x666;
	   temp2 = temp1 + temp2;
	   temp1 = temp1 - 0x777;
	}
   	printf("\nSerial = %u\n",temp1);
   	getch();
}
	   


