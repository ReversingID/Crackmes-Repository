#include <iostream>
#include <string>

int main(int argc, char *argv[])
{
    std::string username;
    int serial = 0, value = 0xDEADC0DE;
    
    do{
        std::cout << "Username: ";
        std::getline( std::cin, username );
    }while(!(username.length() && username.length() <= 24));
    
    for(unsigned int i = 0; i < username.length(); i++){
        serial = ((int)username[i] + value) * 0x666;
        value += serial;
        serial -= 0x777;
    }
    
    std::cout << "Serial:   " << (unsigned int)serial << "\n";    
    system("pause");
    return EXIT_SUCCESS;
}

