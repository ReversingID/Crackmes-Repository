/* 
   -------------------------------------------------------------------------
   - Filename  : main.c
   - Purpose   : KeyGen for hackerehas Very easy keygenme
   - Created   : 12.08.08
   - Protection: Serial number
   - Difficulty: Author says level 1.....I agree
   -------------------------------------------------------------------------
   - Copyright (C) 2008  [Xorolc]
   -
   - This program is free software: you can redistribute it and/or modify
   - it under the terms of the GNU General Public License as published by
   - the Free Software Foundation, either version 3 of the License, or
   - (at your option) any later version.
   -
   - This program is distributed in the hope that it will be useful,
   - but WITHOUT ANY WARRANTY; without even the implied warranty of
   - MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   - GNU General Public License for more details.
   - 
   - You should have received a copy of the GNU General Public License
   - along with this program.  If not, see http://www.gnu.org/licenses/
   -------------------------------------------------------------------------   
*/
#define WIN32_LEAN_AND_MEAN

/* Includes */
#include <windows.h>
#include "resource.h"

/* save a few bytes */
#pragma comment(linker,"/FILEALIGN:0x200 /MERGE:.data=.text /MERGE:.rdata=.text /SECTION:.text,EWR /IGNORE:4078")

/* Defines */
#define CTRLMSG HIWORD(wParam)
#define CTRLID  LOWORD(wParam)

/* Globals */
HMENU hmenu;
HWND hDlg, hwndName, hwndSerial, hwndCompany;
char AppTitle[]		="hackerehas Very easy keygenme KeyGen";
char szSerial[50]	= {0};
char szName[25]		= {0};

/* Our Function Prototypes */
void InitApp( HWND );
void CalculateSerial();
void CenterDialog( HWND );
BOOL CALLBACK DialogProcedure( HWND, UINT, WPARAM, LPARAM );
int WINAPI WinMain( HINSTANCE, HINSTANCE, LPSTR, int );

BOOL CALLBACK DialogProcedure( HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam ){
	switch( uMsg ){

	case WM_INITDIALOG:
		InitApp( hDlg );
		SetWindowText(hDlg, AppTitle );
		hmenu = GetMenu( hDlg );
		CenterDialog( hDlg );
		break;

	case WM_CLOSE:
		EndDialog( hDlg, TRUE );
		break;

	case WM_LBUTTONDOWN: // Drag dialog with mouse trick
		ReleaseCapture();
		SendMessage( hDlg, WM_NCLBUTTONDOWN, HTCAPTION, 0 );
		break;

	case WM_COMMAND:
		switch( CTRLID ){

		case IDC_NAME:
			if( CTRLMSG == EN_UPDATE ){
				CalculateSerial();
			}
			SetWindowText( hwndSerial, szSerial );
			break;

		case IDC_EXIT:
			EndDialog( hDlg, TRUE );
		}

		break;

		default:
			return FALSE;
	}
	return TRUE;
}


int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow ){
	DialogBox( hInstance,MAKEINTRESOURCE(IDD_DIALOG),NULL,( DLGPROC )DialogProcedure );
	return FALSE;
}


/* Custom Functions */

void CalculateSerial(){

	int i = 0, len = 0;
	unsigned int Magic	= 0xDEADC0DE;
	unsigned int serial	= 0;

	ZeroMemory( szName, sizeof(szName) );
	ZeroMemory( szSerial, sizeof(szSerial) );

	GetWindowText( hwndName, szName, sizeof(szName) );

	len = lstrlen( szName );

	for( i=0; i<len; i++ ){
		serial = ( ( szName[i] + Magic ) * 0x666 );
		Magic += serial;
		serial -= 0x777;
	}

	wsprintf( szSerial, "%u", serial );


	return;
}

void InitApp( HWND hDlg ){

	hwndName	= GetDlgItem( hDlg, IDC_NAME );
	hwndSerial	= GetDlgItem( hDlg, IDC_SERIAL );

	SendMessage( hwndName, EM_LIMITTEXT, 24, 0 );
	SetWindowText( hwndName, "Good Luck!" );
}

void CenterDialog(HWND hwndDlg){

	RECT Dlg, Desktop;
	DWORD Height, Width, DeskX, DeskY;

	GetWindowRect(hwndDlg, &Dlg);
	GetWindowRect(GetDesktopWindow(), &Desktop);

	Width = Dlg.right - Dlg.left;
	Height = Dlg.bottom - Dlg.top;
	DeskX = (Desktop.right - Width) >> 1;
	DeskY = (Desktop.bottom - Height) >> 1;	

	MoveWindow(hwndDlg, DeskX, DeskY, Width, Height, FALSE);

	return;
}
