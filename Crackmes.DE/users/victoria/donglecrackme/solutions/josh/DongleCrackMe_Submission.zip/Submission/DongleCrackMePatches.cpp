// asmTests.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h> //this has been included to identify windows constants

//DongleCrackMe
int _tmain(int argc, _TCHAR* argv[])
{
	__asm
	{
			; #0x01b
			;orig adr 00404f59 vor 0f0b 1b00
		lea eax, [ebp - 0x11d]
		lea ebx, [ebp - 0x11d]		;8D 9D E3 FE FF FF
		add ebx, eax				;03 D8

			;---> 0f2 <----orig adr 00424deb vor 0f0b f200
			;E8 FC C3 FD FF                          call    RaiseException
			sub esp, 8				;83 ec 08
			mov edx, esp			;8b d4
			mov ebx, eax			;8b d8
			mov edi, ecx			;8b f9
			stc						;f9

			;---> 103 <----   orig adr 00428c23 vor 0f0b 0301
			;E8 c4 85 FD FF                          call    RaiseException
			sub esp, 0x10			;83 ec 10
			mov edi, eax			;8b f8

			;---> 15d <----   orig adr 004437a0 vor 0f0b 5d01
			mov edx, esp			;8b d4			;this statement is placed before the function, because there is a non-necessary statement
			;E8 c4 85 FD FF                          call    RaiseException
			sub esp, 0x20			;83 ec 20
			sub edx, 0x28			;83 ea 28		;calculate the correct stack pointer
			mov ebp, esi			;8b ee
			mov esi, eax			;8b f0			
			mov edi, ebx			;8b fb

			;---> 15e <----   orig adr 004437a3 before 0f0b 5e01
			mov eax, edi			;8b C7
			mov ecx, esp			;8b cc
			mov edx, esp			;8b d4
			add edx, 0x18			;c2 18

			;---> 0f1 <----   orig adr 004424dbf before 0f0b f100
			push edx				;52
			push ecx				;51
			mov edx, esp			;8b d4
			mov edi, ecx			;8b d9

			;---> 0ea <----   orig adr 00423cac before 0f0b ea00
			push edx				;52
			push ecx				;51
			xor esi, esi			;33 f6
			mov edi, eax			;8b f8

			;---> 102 <----   orig adr 00428b63 before 0f0b 0201
			mov eax, ebx			;8b c3
			xor ecx, ecx			;33 c9
			mov edx, 0xb00a			;BA 0a b0 00 00

			;---> e1 <----   orig adr 004226a3 before 0f0b 0e100
			xor edx, edx			;33 d2
			xor esi, esi			;33 f6
			mov edi, esp			;8b fc
			add edi, 0x28			;83 c7 28

			;---> 4e <----   orig adr 0040983c before 0f0b 04e00
			push edx			;52
			push ecx			;51
			mov esi, ebp		;8b f5

			;---> 21 <----   orig adr 00405dda before 0f0b 02100
			mov eax, 0x46704c	;b8 4c 70 46 00
			mov edx, 0x405e30	;ba 30 5e 40 00

			;---> 22 <----   orig adr 00405de9 before 0f0b 02200
			mov eax, 0x467218	;b8 18 72 46 00
			mov edx, 0x405e30	;ba 30 5e 40 00

			;---> 0 <----   orig adr 0040153f before 0f0b 00000
			mov ebx, edx		;8b da
			;jg 401552 replaced by NOPs, as esi is initialized always with 0x100000

			;---> 1 <----   orig adr 00401552 before 0f0b 00000
			;because of #0 patch never accessed
			;JPEGConv.006.exe

			;---> 262 <----   
			mov ebp, esp		;8b ec
			sub esp, 0x0c		;83 ec 0c
			mov eax, 0x464370	;b8 70 43 46 00

			;---> 047 <----   
			mov edi, eax		;8b f8
			add eax, 4			;83 c0 04
			mov edx, ecx		;8b d1
			mov esi, ecx		;8b f1

			;---> 04f <----   
			sub esp, 0x18		;83 ec 18
			sub ebp, 0x78		;83 ed 78
			mov esi, 0x4675b0	;be b0 75 46 00
			mov edi, 0x4650d8	;bf d8 50 46 00

			;---> 03b <----   
			mov esi, 0x467518	;be 18 75 46 00
			mov edi, 0x467548	;bf 48 75 46 00
			mov bl, 1			;b3 01

			;---> 03c <----   
			mov esi, edi		;8b f7
			mov edi, 0x467594	;bf 94 75 46 00
			xor ebx, ebx		;33 db
			inc ebx				;43

			;---> 050 <----   
			mov eax, ebx		;8b c3
			xor ecx, ecx		;33 c9
			mov edx, 0x14		;BA 14 00 00 00

			;---> 051 <----   
			mov eax, ebx		;8b c3
			xor edx, edx		;33 d2
			add dl, 0x1b		;80 c2 1b
			mov ecx, 0x409cd8	;B9 d8 9c 40 00

			;---> 052 <----   
			mov eax, ebx		;8b c3
			xor edx, edx		;33 d2
			add dl, 0x1c		;80 c2 1c
			mov ecx, 0x409cd8	;B9 d8 9c 40 00

			;---> 053 <----   
			mov eax, ebx		;8b c3
			add dl, 0x0f		;80 c2 0f
			sub ecx, 0x68		;83 e9 68 

			;---> 054 <----   
			mov eax, ebx		;8b c3
			add cl, 0x22		;80 c1 22
			xor edx, edx		;33 d2
			mov dl, 0x0e		;b2 0e

			;---> 055 <----   
			mov eax, ebx		;8b c3
			mov ecx, 0x409cd8	;B9 d8 9c 40 00
			xor edx, edx		;33 d2
			mov dl, 0x19		;b2 19

			;---> 056 <----   
			mov eax, ebx		;8b c3
			add dl, 0x1d		;80 c2 0f
			sub ecx, 0x75		;83 e9 68 

			;---> 057 <----   
			mov eax, ebx		;8b c3
			mov ecx, 0x409ce4	;B9 e4 9c 40 00
			xor edx, edx		;33 d2
			add dl, 0x1f		;80 c2 1f

			;---> 058 <----   
			mov eax, ebx		;8b c3
			mov ecx, 0x409cf4	;B9 f4 9c 40 00
			xor edx, edx		;33 d2
			mov dl, 0x20		;b2 20

			;---> 059 <----   
			mov eax, ebx		;8b c3
			;xor ecx, ecx		;
			mov cl, 0x3a		;b1 3a
;			xor edx, edx		;33 d2
			mov dl, 0x1e		;b2 1e

			;---> 05a <----   
			mov eax, ebx		;8b c3
			mov ecx, 0x409d0c	;B9 0c 9d 40 00
			mov dl, 0x28		;b2 28

			;---> 05b <----   
			mov eax, ebx		;8b c3
			mov ecx, 0x409d18	;B9 18 9d 40 00
			mov dl, 0x29		;b2 29

			;---> 05c <----   
			mov eax, ebx		;8b c3
			mov ecx, 0x409cd8	;B9 d8 9c 40 00
			mov dl, 0x25		;b2 25

			;---> 05d <----   
			mov eax, ebx		;8b c3
			mov ecx, 0x409cd8	;B9 d8 9c 40 00
			mov dl, 0x23		;b2 23

			;---> 05f <----   
			mov eax, 0x467510	;b8 10 75 46 00
			mov dl, 0x04		;b2 04

			;---> 060 <----   
			mov eax, 0x467514	;b8 14 75 46 00

			;---> 061 <----   
			mov eax, ebx		;8b c3
			mov cl, 0x2c		;b1 2c
			mov dl, 0x0c		;b2 0c

			;---> 040 <----   
			mov ecx, 0x408b78	;b9 78 8b 40 00
			mov dx, 0x1009		;66 ba 09 10

			;---> 04c <----   
			mov eax, 0x4650d4	;b8 d4 50 46 00
			mov cx, 0x80		;66 b9 80 00
			lea edx, [esp+0x14] ;8d 54 24 14

			;---> 0ab <----   
			mov ecx, 0x40		;B9 40 00 00 00
			lea edx, [esp+0x08] ;8d 54 24 08

			;---> 07b <----							.010
			xor ecx, ecx		;33 c9
			lea eax, [esp+0x128] ;8d 84 24 28 01 00 00

			;---> 037 <----						!!!!!!!!!!!	ERROR CODE:004084F5
			mov eax, ebx		;8b c3
			mov ecx, esi		;8b ce
			mov edx, 0x7fffffff ;ba ff ff ff 7f

			;---> 035 <----                    !!!!! check out !!! CODE:004081D3
			mov eax, 8		;B8 08 00 00 00
			mov ebx, eax		;8b d8

			;---> 036 <----							.011
			mov cl, al			;8a c8
			and cl, 0x5f		;80 E1 5F
			xor eax, eax		;33 c0
			mov al,  1			;b0 01
			;mov ecx, 0x42fa58	;b9 58 fa 42 00

			;---> 153 <---- 
			mov ebx, 0xffffffea		;bb ea ff ff ff
			mov esi, 0x00465904		;be 04 59 46 00

			;---> 9e <----   
			sub esp, 0x2c		;83 ec 2c
			mov ebx, eax		;8b d8
			mov eax, edx		;8b c2
			mov esi, edx		;8b f2
			mov edx, esp		;8b d4

			
			;---> 9b <----   
			mov ecx, 0x0b		;b9 0b 00 00 00
			mov esi, 0x46531c	;be 1c 53 46 00
			mov edi, ebx		;8b fb

			;---> 9c <----   
			mov ecx, 0x20		;b9 20 00 00 00
			lea eax, [esp + 0x3c];8d 44 24 3c
			lea edx, [esp + 0x1c];8d 54 24 1c

			;---> 9d <----   
			mov ecx, 0x1f		;b9 1f 00 00 00
			lea eax, [esp + 0x7b];8d 44 24 7b

			;---> 0d <----
			inc al				;fe c0			
			mov cl, al			;8a c8
			and cl, 0xfc
			shr cl, 2			;c0 e9 02
			sub al, 4			;2c 04

			;---> 31 <----
			mov al, 0					;b0 00		
			xor ecx, ecx				;33 c9
			dec ecx						;49
			mov edi, eax				;8b f8

			;---> 157 <----
			mov edx, eax			;8b d0		
			inc edx					;42
			;lea eax, [ebp + pSrc]  	;8d 85 ff fe ff ff

			;---> 2d <----
			mov esi, eax			;8b f0
			mov al, 0					;b0 00		
			xor ecx, ecx				;33 c9
			dec ecx						;49
			mov edi, edx				;8b fa

			;---> 2e <----
			mov eax, esi		;8b c6
			mov edi, esi		;8b fe
			not ecx				;f7 d1
			mov esi, edx		;8b f2
			mov edx, ecx		;8b d1
			shr ecx, 2			;c1 e9 02

			;---> 158 <----
			dec eax				;48
			mov edx, eax		;8b d0
			lea eax, [ebx+0x7c]	;8d 43 7c
			mov ecx, 0x100		;b9 00 01 00 00

			;---> 14a <----								.014
			mov eax, 0x465868	;B8 68 58 46 00
			mov ecx, 2			;B9 02 00 00 00
			lea edx, [esi+0x04]	;8D 56 04

			;---> 15b <----
			sub esp, 0x100		;81 EC 00 01 00 00
			mov esi, edx		;8B F2
			mov ebx, eax		;8b d8				

			;---> 14c <----
			xchg edx, ebx		;87 d3
			mov edi, eax		;8B F8

			;---> 14d <----
			mov ax, 8			;66 B8 08 00
			mov ecx, 0x0a		;B9 0A 00 00 00

			;---> 7c <----
			mov eax, esi		;8b c6
			lea edx, [esp+0x14]	;8D 54 24 14

			;---> 7d <----
			lea eax, [esp+0x114]	;8D 84 24 14 01 00 00

			;---> 85 <----
			mov ebx, edx		;8b da
			xor edx, edx		;33 d2
			mov esi, ecx		;8b f1
			mov edi, eax		;8b f8

			;---> 9f <----
			mov ebx, eax		;8b d8
			mov esi, ecx		;8b f1
			sub esp, 0x2c		;83 ec 2c
			mov edx, esp		;8b d4

			;---> 83 <----
			mov ebx, eax		;8b d8
			xor edx, edx		;33 d2
			mov cx, 1			;66 B9 01 00

			;---> 84 <----							.015
			mov eax, ebx		;8b c3
			xor esi, esi		;33 f6
			mov cx, 2			;66 B9 02 00

			;---> 0a <----
			lea eax, [esi+4]	;8D 46 04
			lea ecx, [esp]		;8d 0c 24
			lea edx, [edi-4]	;8D 57 FC

			;---> 6 <----  
			add esi, eax	;03 f0
			and esi, 0xffffc000	; 81 E6 00 C0 ff ff
			cmp ebx, esi	;3B de

			;---> 7 <----    
			mov eax, 0x467464	;B8 64 74 46 00
			sub edx, 8			;83 ea 08

			;---> 9 <----      
			sub ecx, 4			;83 e9 04
			mov edx, 4			;ba 04 00 00 00

			;---> 16b <----							.017
			mov ebx, edx		;8b da
			xor edx, edx		;33 d2
			mov esi, ecx		;8b f1
			mov edi, eax		;8b f8

			;---> b1 <----
			mov ebx, eax		;8b d8
			cmp ebx, 8			;83 fb 08

			;---> a6 <----							.018
			mov ecx, eax		;8b c8
			mov eax, 0x10		;b8 10 00 00 00

			;---> ae <----							.019
			lea eax, [ebx + 0x64];8D 43 64
			mov edx, 0x40		;BA 40 00 00 00

			;---> 76 <----							.019
			add eax, 0x58			;83 C0 58
			and edi, 0x00ffffff		;81 E7 FF FF FF 00

			;---> 98 <----							.019
			;It is not possible to set edx, eax and ZF-dependent cl in 9 Bytes (available)
			;cl is apparantly not used
			mov edx, 0x412018	;BA 18 20 41 00
			mov eax, esi		;8B C6
			mov cl, 0			;b1 00
			;cmovz cl, al		;0F 44 C8

			;---> 99 <----							.019
			mov edx, 0x412028	;BA 28 20 41 00
			mov eax, esi		;8B C6
			xor ecx, ecx		;33 c9

			;---> 7e <----		unclear if sufficient
			mov ecx, eax		;8b c8
			mov eax, edx		;8B C2
			mov edx, 0x34		;ba 34 00 00 00			

			;---> ef <----		
			push edx		;52
			push ecx		;51
			mov ebx, eax		;8b d8
			mov esi, edx		;8b f2

			;---> f0 <----	                       .020	
			push edx		;52
			push ecx		;51
			mov ebx, eax		;8b d8
			mov esi, edx		;8b f2

			;---> 14f <----	                       	
			xor ecx, ecx;	;33 c9
			xor edx, edx	;33 d2
			inc ecx			;41
			inc edx			;42

			;---> 150 <----						.021                                	
			xor ecx, ecx;	;33 c9
			xor edx, edx	;33 d2
			inc ecx			;41
			inc edx			;42

			;---> 151 <----              	
			mov eax, edi;	;8b c7
			xor ecx, ecx	;33 c9
			mov edx, 0xb007	;BA 07 B0 00 00

			;---> 152 <----						.022
												;accessed with almost all functions            	
			mov eax, ebx;	;8b c3
			xor ecx, ecx	;33 c9
			mov edx, 0xb029	;BA 29 b9 00 00

			;---> 107 <----              	
			sub esp, 0x20;	;83 ec 20
			xor ebx, ebx	;33 db
			mov ebp, edx	;8b ea
			mov esi, eax	;8b f0

			;---> a2 <----              	
			sub esp, 0x10;	;83 ec 10
			mov ebx, eax	;8b d8
			mov esi, edx	;8b f2
			cmp dl, cl		;3a d1

			;---> a0 <----              	
			sub esp, 0x10;	;83 ec 10
			mov ebx, eax	;8b d9
			mov esi, edx	;8b f2
			mov edx, esp	;8b d4

			;---> 168 <----              	
			mov eax, esi		;8b c6
			xor ecx, ecx		;33 c9
			inc ecx				;41
			inc ecx				;41
			lea edx, [esp+0x20]	;8D 54 24 20

			;---> 169 <----						.023        	
			mov eax, esi		;8b c6
			xor ecx, ecx		;33 c9
			inc ecx				;41
			inc ecx				;41
			lea edx, [esp+0x20]	;8D 54 24 20

			;---> db <----						        	
			mov eax, 8		; B8 08 00 00 00
			xor ecx, ecx		;33 c9
			xor edx, edx		;33 d2

			;---> de <----						        	
			mov ebx, eax		;8b d8
			mov eax, 0x420		;B8 20 04 00 00

			;---> 10e <----						        	
			and eax, 0xfff0		;25 F0 FF 00 00
			cmp eax, 0xf100		;3D 00 F1 00 00		SC_KEYMENU only here was ZF==1

			;---> 110 <----					identisch 10e	        	
			and eax, 0xfff0		;25 F0 FF 00 00
			cmp eax, 0xf100		;3D 00 F1 00 00		SC_KEYMENU only here was ZF==1

			;---> 10f <----							aktivate 2nd window: show w.channel
			mov eax, ebx		;8b c3
			xor ecx, ecx		;33 c9
			mov edx, 0xb017		;BA 17 B0 00 00

			;---> 11 <----			.024				closing			      	
			mov ebx, 0x4674a0		;BB A0 74 46 00
			mov esi, 0x467034		;BE 34 70 46 00
			mov edi, 0x467038		;BF 38 70 46 00

			;---> 174 <----			closing				      	
			mov eax, 0x465a0c		;B8 0C 5A 46 00
			mov ecx, 0x0b			;B9 0B 00 00 00

			;---> 123 <----			closing				      	
			mov eax, 0x465624		;B8 24 56 46 00
			mov ecx, 0x16			;B9 16 00 00 00

			;---> 149 <----			beim Schliessen				      	
			mov eax, 0x465774		;B8 74 57 46 00
			mov ecx, 0x12			;B9 12 00 00 00

			;---> d3 <----			closing				      	
			mov eax, 0x46549c		;B8 9C 54 46 00
			mov ecx, 0x12			;B9 12 00 00 00

			;---> d4 <----			closing			      	
			mov eax, 0x46534c		;B8 4C 53 46 00
			mov ecx, 0x2a			;B9 2a 00 00 00

			;---> 7a <----			closing				      	
			mov eax, 0x4652b0		;B8 B0 52 46 00
			mov ecx, 0x2			;B9 02 00 00 00

			;---> 6d <----			closing			      	
			mov eax, 0x4651fc		;B8 FC 51 46 00
			mov ecx, 0x16			;B9 16 00 00 00

			;---> 6e <----			closing		      	
			mov eax, 0x4651c4		;B8 C4 51 46 00
			mov ecx, 0x7			;B9 07 00 00 00

			;---> 6f <----			closing	      	
			mov eax, 0x4675bc		;B8 BC 75 46 00
			mov ecx, 0x7			;B9 07 00 00 00

			;---> 70 <----			closing	      	
			mov eax, 0x467594		;B8 94 75 46 00
			mov ecx, 0x7			;B9 07 00 00 00

			;---> 71 <----			closing		      	
			mov eax, 0x467578		;B8 78 75 46 00
			mov ecx, 0x7			;B9 07 00 00 00

			;---> 72 <----			closing		      	
			mov eax, 0x467548		;B8 48 75 46 00
			mov ecx, 0x0c			;B9 0c 00 00 00

			;---> 73 <----			.026     closing			      	
			mov eax, 0x467518		;B8 18 75 46 00
			mov ecx, 0x0c			;B9 0c 00 00 00

;---------------------------------------------------------------------------------
; file breakIndexes_all.load.txt
			;---> 19e <----			load myJPG				      	
			lea eax, [ebp-0x9f8]	;8D 85 08 F6 FF FF
			xor ecx, ecx			;33 C9
			mov edx, 0x180			;BA 80 01 00 00

			;---> 16e <----			load myJPG				      	
			lea eax, [esp+0x14]		;8D 44 24 14
			mov edx, 0x4c			;BA 4C 00 00 00

			;---> 16d <----			load myJPG				      	
			mov ecx, 0x447210		;B9 10 72 44 00
			mov edx, esi			;8B D6

			;---> 16c <----			load myJPG				      	
			mov edi, 0x100			;B9 00 01 00 00		--> unclear, seems to determine the y-pos of the file dialog
			xor ecx, ecx			;33 c9
			mov cl, 3				;b1 03
			xor edx, edx			;33 d2
			mov dl, 2				;B2 02

			;---> 2c <----			load 	
			xor al, al				;32 c0
			mov edx, edi			;8B D7
			mov edi, esi			;8b fe
			xor ecx, ecx			;33 c9
			dec ecx					;49

			;---> 170 <----			load 	
			mov ebx, eax			;8B D8
			sub esp, 0x108			;81 EC 08 01 00 00
			mov esi, edx			;8b f2

			;---> 2a <----			load 	
			mov esi, eax			;8B f0
			mov edi, edx			;8b fa
			mov edx, eax			;8b d0
			mov eax, 0x407d98		;B8 98 7D 40 00

			;---> 2b <----			load 	
			mov eax, esi			;8B c6
			mov ecx, 0x7fffffff		;B9 FF FF FF 7F

			;---> 27 <----			.027            load 	
			mov eax, ebx			;8B c3
			shr eax, 4				;c1 e8 04
			and eax, 0x07			;83 e0 07

			;---> 17e <----			load 	myJPG
			mov esi, eax			;8B f0
			mov ecx, 4				;B9 04 00 00 00
			lea edi, [edx + 0x26]	;8D 7A 26

			;---> 17f <----			load 	myJPG
			xor ecx, ecx			;33 c9
			inc ecx					;41
			lea edx, [edx+3]		;8d 52 03

			;---> 180 <----			load 	myJPG
			mov ecx, 0x40			;B9 40 00 00 00
			lea edx, [edx+eax+0x4]	;8d 54 02 04

			;---> 181 <----			.028              load 	myJPG
			mov ecx, 0x42			;B9 42 00 00 00
			lea edi, [edx + 0x3c]	;8D 7A 3c
			mov esi, eax			;8b f0

			;---> 17a <----			load 	myJPG
			mov ecx, 1				;B9 01 00 00 00
			lea edx, [edx+eax+0x9]	;8d 54 02 09

			;---> 17b <----			load 	myJPG
			mov ecx, 1				;B9 01 00 00 00
			lea edx, [edx+eax+0xa]	;8d 54 02 0a

			;---> 17c <----			load 	myJPG
			mov ecx, 1				;B9 01 00 00 00
			lea edx, [edx+eax+0xa]	;8d 54 02 0b

			;---> 17d <----			.029              load 	myJPG
			mov ecx, 8				;B9 08 00 00 00
			mov esi, eax			;8b f0
			lea edi, [edx+0x4]		;8d 7a 04

			;---> 182 <----			load 	myJPG
			mov ecx, 1				;B9 01 00 00 00
			lea edx, [edx+0x4+2*eax];8D 54 42 04

			;---> 183 <----			load 	myJPG
			mov ecx, 0x10				;B9 01 00 00 00
			lea edx, [edx+0x5+2*eax];8D 54 42 04

			;---> 184 <----			.030              load 	myJPG
			mov ecx, 0x153			;B9 53 01 00 00
			mov esi, eax			;8b f0
			lea edi, [edx+0x144]	;8d BA 44 01 00 00

			;---> 186 <----			load 	myJPG
			mov ecx, 1			;B9 01 00 00 00
			lea edx, [edx+0x3+2*eax];8D 54 42 03

			;---> 187 <----			load 	myJPG
			mov ecx, 1			;B9 01 00 00 00
			lea edx, [edx+0x4+2*eax];8D 54 42 04

			;---> 188 <----			load 	myJPG
			mov ecx, 5			;B9 05 00 00 00
			mov esi, eax		;8b f0
			lea edi, [byte ptr edx+ 0x10690]		;8D BA 90 06 01 00

			;---> 19d <----			.031            load 	myJPG
			xor ecx, ecx		;33 c9
			mov edx, 6			;BA 06 00 00 00
			lea eax, [ebp-0x2c]	;8D 45 D4

			;---> cf <----			            load 	myJPG
			xor ecx, ecx		;33 c9
			mov edx, 0x54		;BA 54 00 00 00
			lea eax, [ebp-0x5d]	;8D 45 a3

			;---> d0 <----			            load 	myJPG
			mov ecx, 6		;B9 06 00 00 00
			lea esi, [eax+0x18]	;8D 70 18
			lea edi, [ebp-0x5d]	;8D 7d a3

			;---> c5 <----			            load 	myJPG
			xor ebx, ebx		;33 db
			sub esp, 0x408		;81 EC 08 04 00 00

			;---> c9 <----			            load 	myJPG
			mov ecx, 0x15		;B9 15 00 00 00
			mov esi, eax		;8b f0
			lea edi, [edx + 0x18]; 8D 7A 18

			;---> c4 <----			            load 	myJPG
			mov ecx, 0x0a		;B9 15 00 00 00
			mov edi, edx		;8b fa
			lea esi, [ebp + 0x40]; 8D 75 40

			;---> 19b <----			       .032     load 	myJPG
			;not sure
			add eax, 0x80		;05 80 00 00 00
			cmp eax, 0x80000000	;3D 00 00 00 80

			;---> 178 <----			     .033         load 	myJPG
			;comparison not sure
			;mov eax, 0x100
			;mov edx, 8
			mov ecx, edx		;8b ca
			xor edx, edx		;33 d2
			div ecx				;f7 f1
			cmp eax, 0x80000000 ;3D 00 00 00 80

			;---> 179 <----			       load 	myJPG
			;comparison not sure
			mov ecx, edx		;8b ca
			xor edx, edx		;33 d2
			div ecx				;f7 f1
			cmp eax, 0x80000000 ;3D 00 00 00 80

			;---> 261 <----			       load 	myJPG
			mov cx, 2		;66 B9 02 00
			mov edx, -4		;BA FC FF FF FF

			;---> c7 <----			       load 	myJPG
			mov eax, 0x01000000		;B8 00 00 00 01
			mov ecx, eax		;8b c8
			xor edx, edx		;33 d2

			;---> ac <----			       load 	myJPG
			mov edi, eax		;8b f8
			xor esi, esi		;33 f6
			sub esp, 0x404		;81 EC 04 04 00 00

			;---> c2 <----		.034	       load 	myJPG
			mov ebx, edx		;8b da
			xor edx, edx		;33 d2
			mov esi, ecx		;8b f1
			mov edi, eax		;8b f8
;---------------------------------------------------------------------------------
; e n d   file breakIndexes_all.load.txt


;---------------------------------------------------------------------------------
;   file breakIndexes_all.store1.txt

			;---> 197 <----		
			mov ecx, 4				;B9 04 00 00 00
			mov esi, eax			;8b f0
			lea edi, [edx + 0x26]	;8D 7A 26 

			;---> 196 <----		
			mov ecx, 8				;B9 08 00 00 00
			mov esi, eax			;8b f0
			lea edi, [edx + 0x4]	;8D 7A 04 

			;---> 198 <----		
			mov ecx, 0x42			;B9 42 00 00 00
			mov esi, eax			;8b f0
			lea edi, [edx + 0x3c]	;8D 7A 3c 

			;---> 199 <----		
			mov ecx, 0x153			;B9 53 01 00 00
			mov esi, eax			;8b f0
			lea edi, [edx + 0x144]	;8D BA 44 01 00 00 

			;---> 19a <----		
			mov ecx, 0x5			;B9 05 00 00 00
			mov esi, eax			;8b f0
			lea edi, [edx + 0x10690];8D BA 90 06 01 00 

			;---> 177 <----			.035     
			and eax, 0xff			;25 FF 00 00 00
			cmp eax, eax			;3b c0

			;---> 18c <----		
			mov ecx, 0x1			;B9 01 00 00 00
			lea edx, [edx + eax +0x3f];8D 54 02 3F

			;---> 18d <----		
			mov ecx, 0x40			;B9 40 00 00 00
			lea edx, [edx + eax +0x40];8D 54 02 40

			;---> 189 <----		
			mov ecx, 0x1			;B9 01 00 00 00
			lea edx, [edx + eax +0x0d];8D 54 02 0d

			;---> 18a <----		
			mov ecx, 0x01			;B9 01 00 00 00
			lea edx, [edx + eax +0x0e];8D 54 02 0e

			;---> 18b <----								.036
			mov ecx, 0x01			;B9 01 00 00 00
			lea edx, [edx + eax +0x0f];8D 54 02 0f

			;---> 18e <----								
			mov ecx, 0x01			;B9 01 00 00 00
			lea edx, [edx + eax*2 +0x148];8D 94 42 48 01 00 00

			;---> 18f <----								
			mov ecx, 0x10			;B9 10 00 00 00
			lea edx, [edx + eax*2 +0x149];8D 94 42 49 01 00 00

			;---> 190 <----								
			mov ecx, 0x1			;B9 01 00 00 00
			lea edx, [eax + 0x10692];8D 90 92 06 01 00

			;---> 191 <----								
			mov ecx, 0x1			;B9 01 00 00 00
			lea edx, [edx+ 2*eax + 0x10693];8D 94 42 93 06 01 00

			;---> 192 <----								
			mov ecx, 0x1			;B9 01 00 00 00
			lea edx, [edx+2*eax + 0x10694];8D 94 42 94 06 01 00 lea

			;---> 193 <----								
			mov ecx, 0x3			;B9 03 00 00 00
			lea edx, [eax + 0x10694];8D 90 94 06 01 00

			;---> 194 <----								
			mov ecx, 0x4			;B9 04 00 00 00
			lea edx, [eax + 0x106a8];8D 90 A8 06 01 00

			;---> 195 <----								
			mov ecx, 0x1			;B9 01 00 00 00
			lea edx, [eax + 0x106ac];8D 90 AC 06 01 00

			;---> 19c <----								
			xor ecx, ecx			;33 c9
			mov edx, 0x6			;BA 06 00 00 00
			lea eax, [ebp - 0x26]	;8D 45 da
;---------------------------------------------------------------------------------
; e n d   file breakIndexes_all.store1.txt
; JPEGConv.038.exe
; 161 indexes converted

			;---> 15c <----								
			lea eax, [esp +0x18]	;8D 44 24 18
			mov edx, 0x4431a8		;BA A8 31 44 00

			;---> 159 <----								
			and eax, 0x100	;25 00 01 00 00

			;---> 38 <----								
			mov ecx, 0xc02	;B9 02 0C 00 00
			mov dx, 0x400	;66 BA 00 04

			;---> 39 <----								
			mov edx, 0x1001		;BA 01 10 00 00
			lea eax, [esp+0x16]	;8D 44 24 16

			;---> 3a <----								
			mov ecx, eax	;8b c8
			mov eax, esi	;8b c6
			lea edx, [esp+0x0a]	;8D 54 24 0a

			;---> 175 <----								
			mov ecx, 5	;B9 05 00 00 00
			lea edi, [ebp-0x18]	;8D 7d e8
			mov esi, edx	;8b f2

;---------------------------------------------------------------------------------
;   file breakIndexes_all.some_remaining2.txt
			;---> 173 <----								
			mov edi, eax		;8b f8
			mov edx, 0x447ffc	;BA FC 7F 44 00

			;---> 171 <----
			sub esp, 0x34		;83 ec 34
			mov esi, eax		;8b f0
			mov ebx, edx		;8b da
			mov edx, esp		;8b d4
			xor eax, eax		;33 c0

			;---> bd <----
			xor ecx, ecx		;33 c9
			xor edx, edx		;33 d2
			inc ecx				;41
			inc edx				;42

			;---> 14 <----
			and ecx, 0x00ff0000		;81 E1 00 00 F0 FF
			and ebx, 0x00ff0000		;81 E3 00 00 F0 FF
			cmp ecx, ebx			;3b cb

			;---> 48 <----			stream read error
			mov ebx, edx			;8b da
			lea edx, [eax + 4]		;8d 50 04
			mov edi, eax			;8b f8
			mov eax, ecx			;8b c1
;---------------------------------------------------------------------------------
;   file JPEGConv.allPatch.exe
	}
	return 0;
}

