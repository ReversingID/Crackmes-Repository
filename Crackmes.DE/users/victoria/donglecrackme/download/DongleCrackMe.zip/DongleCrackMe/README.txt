Dongle CrackMe 1
================

The aim of this crackme is an analysis of the works of some hardware key. 
The key is simulated through a process named DongleBlackBox, which is run
along the protected program. The program (JPEGConv) will have been cracked 
when it's fully operational and you don't need the key process to make it 
work. Physically it's equivalent to elimination of the need for the dongle.

As it's only a software simulation of the dongle, there's only one rule:
YOU MAY NOT IN ANY WAY ANALYSE THE WORKS OF THE DONGLEBLACKBOX PROCESS.
You musn't disassemble, debug or patch it, nor even look into the file, 
in which it's code is located (DongleBlackBox file).
Let's assume that the hardware key is a black box which you can't peek into.

Aside from that rule, anything goes :) You may use debuggers, disassemblers,
hook the DLL, modify and patch the code (it's a real crackme), simulate 
the key on your own, communicate with the key through pipes, as it's done 
in the DLL, etc.

As it's pretty easy to give a full solution by simply breaking the rules 
and just looking into the DongleBlackBox file, a much more interesting thing 
would be the description of the way itself to deal with the problem. 
Write how (if ever) you'd crack this protection, how long would it take, 
and how strong you think it is.

Please send any suggestions and solutions to crackme@poczta.fm

ML