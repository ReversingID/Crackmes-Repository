small.LiB v1.0

small.LiB is a bignum library :]
I think there's no need for writing a manual.. 
just look into slib.inc. lib is quite fast, it's
not miracl, but f.e. powmod is about 20ms faster than
roy's lib (from which, I've stolen lib.mod.asm :x).
small.LiB is an open project, I'm too lazy to add new
functions, so everything is in your able hands :-).
the most needed is support of negative numbers,
if any1 feel up to code it... small.LiB can be
changed, rewritten, optimised etc.
if any1 added something interesting to the lib, pls
send it to bff7286d@o2.pl - if it's good enough, I'll
put it on the page :]

excuse my poor english :x

ged_//tkm!
bff7286d@o2.pl
http://www.tkm-squad.prv.pl