small.LiB v1.0

small.LiB to mala biblioteka do obslugi duzych liczb ;p
rozpiski funkcji chyba nie ma po co pisac.. wystarczy
looknac do slib.inc. smiga calkiem szybko, nie jest
to miracl, ale np. powmod jest o 20ms szybszy niz
libek roya (z ktorego btw pochodzi lib.mod.asm lekko
przerobiony :x).
small.LiB to open project, nie chce mi sie juz bawic
w dodawanie nowych funkcji, so wszystko w waszych zdolnych
rekach :-). najbardziej potrzebna jest obsluga liczb ujemnych,
jesli ktos czuje sie na silach to zapraszam. libka mozna
zmieniac, przerabiac, dodawac nowe funkcje, optymizowac itd.
tylko 1 prosba, przerobiona wersje pls podsylac na 
bff7286d@o2.pl - kiedy uzbiera sie kilka ciekawych rzeczy to
wrzuce na stronke :)

ged_//tkm!
bff7286d@o2.pl
http://www.tkm-squad.prv.pl