/*
	Insipid Crackme v.2 by Veneta
	Protection: SHA256, E2, CRT-256
	Difficulty: 2/10
	Date: 29 september 2004

    CRT:
    P1 = A0F79281A9EF48CDDE52D8E4AC862EC8B984CD11A3AA0582E108B3F58A0202AF
    P2 = D3734933AD4E43D986390D1E841C2430AB14C154B22EE0360C846E9F38875E5F
*/
#define WIN32_MEAN_AND_LEAN
#include <stdio.h>
#include <windows.h>
#include <COMMCTRL.H> 
#include <miracl.h>
#include "resource.h"
#pragma comment(lib, "comctl32.lib")
#include "e2.c"

HINSTANCE	hInst;
miracl *mip;
LOGFONT font = {0};
HANDLE hfont;
char szname[32];
char szserial[512];
char sha_hash[32];
char e2_sha[32];
char szkey[]={0x2E,0x3A,0x65,0x78,0x69,0x6C,0x65,0x3A,0x2E,0x00,0x41,0x30,0x46,0x37,0x39,0x32};
char szprime1[]="A0F79281A9EF48CDDE52D8E4AC862EC8B984CD11A3AA0582E108B3F58A0202AF";
char szprime2[]="D3734933AD4E43D986390D1E841C2430AB14C154B22EE0360C846E9F38875E5F";
int ComputeCRT()
{
	big pp[2], rem[2], n;
	big_chinese bc;
	int flag;

	//init crt constants
	pp[0] = mirvar(0);
	pp[1] = mirvar(0);
	rem[0] = mirvar(0);
	rem[1] = mirvar(0);
	n = mirvar(0);

	cinstr(pp[0], (char*) szprime1);
	cinstr(pp[1], (char*) szprime2);

	// get remainders
	bytes_to_big(32, (char*) &sha_hash, rem[0]);
	bytes_to_big(32, (char*) &e2_sha, rem[1]);
	// if one of the remainder is greater then the divisor
	// we don't have a valid solution so there's no valid serial
	// available
	if ( compare(rem[0], pp[0]) < 1 && compare(rem[1], pp[1]) < 1 )
	{
		// do actual CRT 
		crt_init(&bc,2,pp);
		crt(&bc,rem,n);
		crt_end(&bc);
		// output as bytes
		cotstr(n, (char*) szserial);
		flag = 1;
	}
	else
    {
        flag = 0;
    }
	//destroy bignums
	mirkill(pp[0]);
	mirkill(pp[1]);
	mirkill(rem[0]);
	mirkill(rem[1]);
	mirkill(n);
	return flag;
}
BOOL CALLBACK DlgProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{	
	int len;
	unsigned int i;
	sha256 psh;
    
	switch (message)
	{    
	case WM_CLOSE:
		EndDialog(hWnd,0);
		break;
	case WM_COMMAND:
		{
			int event = HIWORD(wParam),
				id = LOWORD(wParam);
			switch(id)
			{
			case IDC_OK:
				len = GetDlgItemText(hWnd, IDC_NAME, (char*) szname,32);
				if ( len>0 && len < 32)
				{
                    //hash it with sha256
                    shs256_init(&psh);
                    for (i=0; i<strlen(szname); i++)
                    {
                        shs256_process(&psh, (char) szname[i]);
                    }
                    shs256_hash(&psh, (char*) sha_hash);

                    //encrypt the hash with E2
                    set_key((const unsigned long *) szkey,16);
                    encrypt((const unsigned long *) sha_hash,(char*) e2_sha);
                    encrypt((const unsigned long *) &sha_hash[16],(char*) &e2_sha[16]);
                    if (ComputeCRT())
					    SetDlgItemText(hWnd,IDC_SERIAL, (char*) szserial);
                    else
                        MessageBox(hWnd,"No serial for this name","Bad Luck:", MB_ICONERROR);
				}
				
				else
					MessageBox(hWnd, "Name is too short..", "Watch it:", MB_ICONWARNING);
				break;
			case IDC_ABOUT:
				MessageBox(hWnd, "Target: 	Insipid Crackme v.2 by Veneta\nProtection: SHA256, E2, CRT-256\nDifficulty: 2/10\nDate:" __DATE__  " \n\nDone by bLaCk-eye","About:",MB_ICONINFORMATION);
				break;
			}
			break;
		}
	case WM_LBUTTONDOWN: // moving dialog trick with mouse
		{
			ReleaseCapture(); // see above :-)
			SendMessage(hWnd,WM_NCLBUTTONDOWN,HTCAPTION,0); // see above
		}
		break;

	case WM_INITDIALOG:
		font.lfHeight = -12; 
		font.lfWeight = FW_BOLD; 
		strcpy(font.lfFaceName,"Arial");
		hfont=CreateFontIndirect(&font); 
		SendMessage(GetDlgItem(hWnd, IDC_NAME), WM_SETFONT, (WPARAM) hfont, (LPARAM)NULL);
		SendMessage(GetDlgItem(hWnd, IDC_SERIAL), WM_SETFONT, (WPARAM) hfont, (LPARAM)NULL); 
		SendMessage(hWnd,WM_SETICON, ICON_SMALL,(long) LoadIcon(hInst, MAKEINTRESOURCE(IDI_ICON1)));
		SendMessage(hWnd,WM_SETICON, ICON_BIG,(long) LoadIcon(hInst, MAKEINTRESOURCE(IDI_ICON1)));
		mip = mirsys(1024,0);
		mip -> IOBASE = 16;
		break;
	}
     return 0;
}
int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{
	hInst=hInstance;
	InitCommonControls();
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, (DLGPROC)DlgProc,0);
	return 0;
}