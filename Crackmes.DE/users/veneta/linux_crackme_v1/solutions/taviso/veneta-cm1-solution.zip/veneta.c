#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* password cracker for veneta//MBE's Linux Crackme v1
 * by Tavis Ormandy, <taviso@sdf.lonestar.org>
 * Date: 03/01/2006
 */

#define SALTLEN 20

/* salt extracted from cm1, at 0x80482FE */
unsigned char salt[] = "veneta//mbe12345678.";

/* key extracted from cm1, at 0x08048312 */
unsigned char key[]  = "\x76\x88\x79\x78\x74\x22\x4a\xa8"
                       "\xe4\xc0\x7c\x00\xe3\x5b\xb1\x4a";

/* union to make translating register code easier */
typedef union {
    unsigned char byte[4];
    signed short word[2];
    signed int dword;
} registers_t;

void cm1_crypt(unsigned char *salt, 
               unsigned char *password, 
               unsigned char *buf);
int memmatch(unsigned char *s1, unsigned char *s2, int n);

int main(int argc, char **argv)
{
    unsigned char password[19], best[4], *buf;
    int i, n, m, p, max, c;

    memset(password, 0x00, sizeof(password));
    memset(best, 0x00, sizeof(best));

    /* allocate scratch space for storing auth attempt */
    if ((buf = malloc(SALTLEN)) == NULL) {
        fprintf(stderr, "[!] Error: allocation failed, sorry.\n");
        return 1;
    }

    /* print out key */
    fprintf(stderr, "[*] Key: :");
    for (i = 0; i < 16; i++)
        fprintf(stderr, "%02x:", (unsigned) key[i]);
    fprintf(stderr, "\n");

    /* for each chunk of 4 */
    for (max = -1, c = n = 0; n < 16; n += 4) {
        /* if we've already cracked this chunk, restore it */
        if (max > 0) memcpy(password + n - 4, best, 4);

        /* for every character between 'A' and 'z' */
    incpos: for (i = '!'; i <= '~'; i++) {
            /* current character we're testing */
            password[n] = i;

            /* encrypt this password, see if it matches the key */
            c++, cm1_crypt(salt, password, buf);

            /* check how many characters matched */
            if (memmatch(buf, key, 16) > max) {
                /* most seen so far, record this */
                max = memmatch(buf, key, 16);
                memcpy(best, password + n, 4);
    
                if (max >= 16) goto match;

                /* print status */
                fprintf(stderr, "[*] New Record: %u/16, Password: %s\n", 
                        max, password);
            }
        }
        /* increment next character */
        for (p = 0; p < 4; p++) {
            if (password[n + p] < '~') {
                /* check if this character has been used before */
                if (password[n + p] == '\0')
                    password[n + p] = '!';
                else password[n + p]++;
                goto incpos;
            } else {
                password[n + p] = '!';
            }
       }
    }

match:

    /* check if we won */
    if (memcmp(key, buf, 16) == 0) {
        fprintf(stderr, "[*] Match found!, Password: %s\n", password);
    } else {
        fprintf(stderr, "[!] Sorry, No Match found.\n");
    }
    
    /* print out our match */
    fprintf(stderr, "[*] Hash: :");
    for (i = 0; i < 16; i++)
        fprintf(stderr, "%02x:", (unsigned) buf[i]);
    fprintf(stderr, "\n");
    
    /* print out stats */
    fprintf(stderr, "[*] Total Attempts: %u\n", c);

    free(buf);

    return 0;
}


/* this is an approximation of the code from cm1, at 0x08048242 */
void cm1_crypt(unsigned char *salt, 
               unsigned char *password, 
               unsigned char *buf)
{
    registers_t eax, ebx, ecx, edx, esi;

    /* copy the salt into supplied buffer */
    memcpy(buf, salt, SALTLEN);

    /* initialise registers to zero */
    eax.dword = ebx.dword = ecx.dword = 0x00;
    edx.dword = esi.dword = 0x00;

    /* copy bytes 0, 1, 4 and 5 from password into eax */
    eax.byte[0] = password[5]; /* XXX: 0x804824C */
    eax.byte[1] = password[1];
    eax.byte[2] = password[4];
    eax.byte[3] = password[0];
    
    eax.dword = (eax.dword ^ 0x0A589CA11) << 5; /* XXX: 0x08048257 */
    
    buf[0] ^= eax.byte[0]; /* XXX: 0x08048264 */
    buf[1] ^= eax.byte[1];
    buf[2] ^= eax.byte[2];
    buf[3] ^= eax.byte[3];

    ebx.byte[0] = password[4];
    ebx.byte[1] = password[5];
    ebx.byte[2] = password[6];
    ebx.byte[3] = password[7];
    
    asm("rcr $0x13, %0" : "+r"(ebx.dword)); /* XXX: 0x0804826C */

    edx.dword = (ebx.dword &= 0x211333) ^ 0x87654321; /* XXX: 0x87654321 */

    buf[4] ^= edx.byte[0];
    buf[5] ^= edx.byte[1];
    buf[6] ^= edx.byte[2];
    buf[7] ^= edx.byte[3];
     /* XXX: 0x08048287 */
    esi.dword = ebx.dword = (ebx.dword & 0x2F13AF92) + 0x12623345;
    
    asm("ror $0x39, %0" : "+r"(esi.dword)); /* XXX: 0x08048291 */

    buf[8] ^= esi.byte[0]; /* XXX: 0x0804829A */
    buf[9] ^= esi.byte[1];
    buf[10] ^= esi.byte[2];
    buf[11] ^= esi.byte[3];
    /* XXX: 0x0804829C */
    esi.dword ^= ebx.dword = (ebx.dword & 0x2113FF98) + 0x5623A5FF; 

    ecx.byte[0] = password[0];
    ecx.byte[1] = password[1];
    ecx.byte[2] = password[2];
    ecx.byte[3] = password[3];

    /* XXX: 0x080482AA */
    asm("ror $0x39, %0" : "+r"(esi.dword));
    asm("rol $0x56, %0" : "+r"(ecx.dword));
    asm("ror $0x07, %0" : "+r"(ebx.dword));

    ecx.dword ^= ebx.dword;

    /* XXX: 0x080482B5, I dont know how safe this is to use in inline asm */
    asm("rcl $0x32, %0" : "+r"(ecx.dword));

    buf[12] = ecx.byte[0];
    buf[13] = ecx.byte[1];
    buf[14] = ecx.byte[2];
    buf[15] = ecx.byte[3];

    edx.dword = 0x00;

    edx.byte[0] = eax.byte[0];
    edx.byte[1] = eax.byte[1];

    /* XXX: 0x080482CA */
    esi.dword = edx.dword = (-edx.dword << 8) & 0xDEADC8B3;

    /* XXX: 0x080482D2 */
    /* perhaps this imul could be written in c, I'm not sure */
    asm("imul %%esi\n"  : "=a"(eax.dword), "=d"(edx.dword)
                        : "S"(esi.dword), "a"(eax.dword));
    asm("rcr $0x15, %0" : "+r"(esi.dword));

    ecx.dword ^= esi.dword;
    ecx.dword ^= eax.dword;
    eax.dword ^= esi.dword;
    edx.dword ^= ebx.dword;
    edx.dword ^= 0x12345678; /* XXX: 0x080482DF */

    asm("rol $0x19, %0" : "+r"(edx.dword)); /* XXX: 0x080482E5 */

    edx.dword += eax.dword; /* XXX: 0x080482E8 */
    edx.dword += esi.dword;

    buf[16] = edx.byte[0] ^ eax.byte[0]; /* XXX: 0x080482F2 */
    buf[17] = edx.byte[1] ^ eax.byte[1];
    buf[18] = edx.byte[2] ^ eax.byte[2];
    buf[19] = edx.byte[3] ^ eax.byte[3];

    return;
}

int memmatch(unsigned char *s1, unsigned char *s2, int n) {
    int count;

    for (count = 0; n >= 0; n--) {
        if (s1[n] == s2[n])
            count++;
    }

    return count;
}
