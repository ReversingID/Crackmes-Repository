from sys import argv

### Helpers functions: bitwise operations on 32-bit registers ###

def not32(x):
	'''
	Negate bits but prevent Python treat the outcome as a negative value.
	Assuming a 32-bit register.

	@param	x	Value to negate

	@return	Bits of x inverted
	'''

	return ~x & ((1 << 32) - 1)

def ror32(x, n):
	'''
	Rotate bits right, assuming a 32-bit register.

	@param	x	Value to rotate
	@param	n	Positions to rotate x by

	@return	Value of x rotated to the right by n places
	'''

	mask_bits = x & ((1 << n) - 1)

	return (x >> n) | (mask_bits << (32 - n))

def rol32(x, n):
	'''
	Rotate bits left, assuming a 32-bit register.

	@param	x	Value to rotate
	@param	n	Positions to rotate x by

	@return	Value of x rotated to the left by n places
	'''

	return ror32(x, 32 - n)

### Key generator starts here ###

def genkey(username):
	'''
	Generate a key for yo-mismo's CrackMe V1 (http://www.crackmes.de/users/yo_mismo/crackme_v1)
	Written by elicn

	@param	username	Username to generate a key for. note: 4 <= len(username) <= 6

	@return	Legitimate key for specified username
	'''

	# address 0x401300 to 0x40131a: xor first four bytes of username with first four bytes of string 'Yo-Mismo'
	xorstring = [ord(a) ^ ord(b) for a, b in zip(username, 'Yo-Mismo'[:4])]
	xorstring.append(0x00)

	# address 0x40132a to 0x401338: sum result xor-string as little-endian words
	magic = sum(hi << 8 | lo for lo, hi in zip(xorstring, xorstring[1:]))

	# address 0x40133a to 0x40134e: apply non-sense calculations
	magic = magic * 0x666
	magic = magic >> 2
	magic = rol32(magic, 0xe)
	magic = ror32(magic, 0x14)
	magic = magic * 2
	magic = not32(magic)
	magic = magic + 0x999

	# address 0x401353 to 0x401377 concatenate username and magic number
	return username + str(magic)

if __name__ == '__main__':
	if len(argv) < 2:
		print 'usage: %s username' % argv[0]
	else:
		username = argv[1]

		if len(username) < 4 or len(username) > 6:
			print 'username length should be at least four but not more than six'
		else:
			print 'key: %s' % genkey(username)
#end