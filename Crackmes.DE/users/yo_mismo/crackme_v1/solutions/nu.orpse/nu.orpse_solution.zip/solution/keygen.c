#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv)
{
	int i = 0;
	char text[6];
	unsigned long hash;
	char *modif = "Yo-Mismo";
	
	__asm {
		pushad
		mov al, 0
		mov ecx, 6
		lea edi, text
		rep stosb
		popad
	};
	
	if(argc != 2) {
		printf("Only specify a name as argument.\n");
		exit(-1);
	} else {
		if(strlen(argv[1]) > 5 || strlen(argv[1]) < 4) {
			printf("Name must be no more than 5 characters and no less than 4 characters in length.\n");
			exit(-1);
		} else {
			strcpy(text, argv[1]);
			for(i = 0; i < 4; i++) {
				text[i] ^= modif[i];
			}
			
			__asm {
				pushad
				mov al, 0
				mov ecx, 2
				lea edi, text + 4
				rep stosb
				mov eax, 0
				lea esi, text
				mov ecx, 4
			L1: add ax, word ptr [esi]
				inc esi
				loopd L1
				imul eax, eax, 0666h
				shr eax, 2
				rol eax, 0Eh
				ror eax, 14h
				imul eax, eax, 2
				not eax
				add eax, 999h
				lea esi, hash
				mov dword ptr [esi], eax
				popad
			};
			
			printf("%s%u\n", argv[1], hash);
		}
	}
	return(0);
}