#include <iostream>

int main()
{
	char userid[256];
	const char* pi="3.1415926535897932384626433832795";
	int len=0,sum_of_symbols=0;
	char passid[10];

	memset(passid,0,10);

	std::cout<<"~~~~~~~~~~~~~~~~~~~~~~~{j2crackme01 keygen by indivisible_int}~~~~~~~~~~~~~~~~~~~~~~"<<std::endl<<std::endl;
	std::cout<<"Enter userid: ";
	std::cin>>userid;
	std::cout<<std::endl;
	if((len=strlen(userid))<=5 || len>9) std::cout<<"The passid is: invalid input\nBe careful: there is only one space symbol in this passid"<<std::endl;
	else 
	{
		for(int i=0;i<len;i++)
			sum_of_symbols+=userid[i];
		passid[0]=(userid[0]*pi[0]+sum_of_symbols)%10+'0';
		for(int i=1;i<len;i++)
			passid[i]=(passid[i-1]+userid[i]*pi[i]+sum_of_symbols)%10+'0';
		std::cout<<"Your passid is: "<<passid<<std::endl;
	}



}