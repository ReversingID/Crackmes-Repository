/* http://www.crackmes.de/users/qnix/qcrk5/ */

#include <stdio.h>
#define WANTED 0x4b7f3da0

int main()
{

	int eax, edx, num;

	printf ("Qnix's qcrk5 key generator by pof\n");

	num = 0;
	do 
	{
		eax = num + 0x60 + 0x5;
		edx = eax;
		eax <<= 0x8;
		eax = eax - edx;
		eax = eax * 0x909090;
		if ( eax == WANTED ) printf ("key: %d\n", num);
		num ++;
	} while ( num < 0xffffffff);

	printf ("Done!\n");
	return 0;
}
