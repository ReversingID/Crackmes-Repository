/* Qnix's qcrk5
 * key generator by niel
 *
 */

#include <stdio.h>

#define CMPVALUE	0x4b7f3da0
#define MULTIPLIER	0x00909090

int main(t, c)
{
	int eax = 1;
	
	while (eax < 0xffffffff) {
		{
			int teax;
			int tedx;

			teax = eax + 5;
			teax += 96;
			tedx = teax;
			teax <<= 8;
			teax -= tedx;
			teax*=MULTIPLIER;
			if (teax == CMPVALUE) {
				printf("%d\n", eax);
				break;
			}
		}
		eax++;
	}

	return 0;
}

