#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

unsigned int
key (unsigned int i)
{
  register unsigned int e, d;

  e = d = (i + 101);
  e <<= 8;
  e -= d;
  e *= 0x909090;

  return e;
}

int
main (void)
{
  register unsigned int i = 1, j = 0;

  while (i < 0xffffffff)
    {
      if (key (i) == 0x4b7f3da0)
	{
	  j++;
	  printf ("%-4u: %15u\n", j, i);
	}

      i++;
    }

  printf ("-- found %u valid keys\n", j);

  return EXIT_SUCCESS;
}
