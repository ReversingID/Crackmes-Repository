#include <stdio.h>
#include <stdlib.h>

#define buffer1_len 1023	// argv[1] Buffer	
#define buffer2_len 3071	// argv[2] Buffer
#define NOP     0x90
#define FILE "qcrk2"


int main() {

	char buffer1[buffer1_len];
	char buffer2[buffer2_len];
	int i=0;
	char *run[3];

	printf("Loader for QCRK2 Crackme\n");
	printf("  Done by cyrex\n");
	printf("- Preparing Buffer...\n");

	for(i=0;i<1023;i++) {
	 buffer1[i]=NOP;
	}

	buffer1[buffer1_len]='\0';

	printf("- Buffer1 done. (size: %u)\n",sizeof(buffer1));

	for(i=0;i<3067;i+=4) *(long *)&buffer2[i] = 0x0804868F;

	buffer2[buffer2_len]='\0';

        printf("- Buffer2 done. (size: %u)\n",sizeof(buffer2));	

	printf("- Starting crackme..\n");

	run[0]=FILE;
	run[1]=buffer1;
	run[2]=buffer2;
	run[3]=0;
	execve(run[0],run,NULL);

}

