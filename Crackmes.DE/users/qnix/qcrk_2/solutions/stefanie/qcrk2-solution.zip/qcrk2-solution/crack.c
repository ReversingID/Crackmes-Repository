#include <signal.h>
#include <stdlib.h>

#define CRAP_FUNC_ADDR	0x8048686

/* call crap() on SIGSEGV */
void handler(int sig)
{
	int (*fp)();
	fp = (long *) CRAP_FUNC_ADDR;
	fp();
	exit(0);
}

/* setup a signal handler for the SIGSEGV signal */
void __attribute__ ((constructor)) qcrk_constructorr()
{
	signal(SIGSEGV, handler);
}

/* we don't even need this anymore */
int ptrace(int a, int b, int c, int d)
{
	return 0;	// always return succeesfully!
}

