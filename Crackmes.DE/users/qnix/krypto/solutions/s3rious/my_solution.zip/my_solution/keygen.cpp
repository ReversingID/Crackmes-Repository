// ------------------------------------------------------------------------------------------------ //
/*                                      
**	Qnix's krypto (level 4)
**	keygen by __s3R10u5__
**
**	WARNING: please compile it in x86 architecture mode: g++ keygen.cpp -m32 -o keygen
*/
//-------------------------------------------------------------------------------------------------
#include <stdio.h>
#include <math.h>
#include <time.h>	
#include <sys/types.h>
#include <unistd.h>
#include <sys/ptrace.h>
#include <pwd.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>


//#define DEBUG				// uncomment this line for debugging information
//#define VERBOSE_DEBUG		// uncomment this line for extra debugging information



#ifdef VERBOSE_DEBUG
	#ifndef DEBUG
		#define DEBUG
	#endif
#endif

typedef unsigned int 			UINT;
typedef unsigned short int 		USHORT;
typedef unsigned long long int 	ULLONG;
typedef unsigned char           UCHAR;
typedef unsigned char* 			PCHAR;


UCHAR a_804a540[] = {
	0xa3,0xd7,0x09,0x83,0xf8,0x48,0xf6,0xf4,0xb3,0x21,0x15,0x78,0x99,0xb1,0xaf,0xf9,
	0xe7,0x2d,0x4d,0x8a,0xce,0x4c,0xca,0x2e,0x52,0x95,0xd9,0x1e,0x4e,0x38,0x44,0x28,
	0x0a,0xdf,0x02,0xa0,0x17,0xf1,0x60,0x68,0x12,0xb7,0x7a,0xc3,0xe9,0xfa,0x3d,0x53,
	0x96,0x84,0x6b,0xba,0xf2,0x63,0x9a,0x19,0x7c,0xae,0xe5,0xf5,0xf7,0x16,0x6a,0xa2,
	0x39,0xb6,0x7b,0x0f,0xc1,0x93,0x81,0x1b,0xee,0xb4,0x1a,0xea,0xd0,0x91,0x2f,0xb8,
	0x55,0xb9,0xda,0x85,0x3f,0x41,0xbf,0xe0,0x5a,0x58,0x80,0x5f,0x66,0x0b,0xd8,0x90,
	0x35,0xd5,0xc0,0xa7,0x33,0x06,0x65,0x69,0x45,0x00,0x94,0x56,0x6d,0x98,0x9b,0x76,
	0x97,0xfc,0xb2,0xc2,0xb0,0xfe,0xdb,0x20,0xe1,0xeb,0xd6,0xe4,0xdd,0x47,0x4a,0x1d,
	0x42,0xed,0x9e,0x6e,0x49,0x3c,0xcd,0x43,0x27,0xd2,0x07,0xd4,0xde,0xc7,0x67,0x18,
	0x89,0xcb,0x30,0x1f,0x8d,0xc6,0x8f,0xaa,0xc8,0x74,0xdc,0xc9,0x5d,0x5c,0x31,0xa4,
	0x70,0x88,0x61,0x2c,0x9f,0x0d,0x2b,0x87,0x50,0x82,0x54,0x64,0x26,0x7d,0x03,0x40,
	0x34,0x4b,0x1c,0x73,0xd1,0xc4,0xfd,0x3b,0xcc,0xfb,0x7f,0xab,0xe6,0x3e,0x5b,0xa5,
	0xad,0x04,0x23,0x9c,0x14,0x51,0x22,0xf0,0x29,0x79,0x71,0x7e,0xff,0x8c,0x0e,0xe2,
	0x0c,0xef,0xbc,0x72,0x75,0x6f,0x37,0xa1,0xec,0xd3,0x8e,0x62,0x8b,0x86,0x10,0xe8,
	0x08,0x77,0x11,0xbe,0x92,0x4f,0x24,0xc5,0x32,0x36,0x9d,0xcf,0xf3,0xa6,0xbb,0xac,
	0x5e,0x6c,0xa9,0x13,0x57,0x25,0xb5,0xe3,0xbd,0xa8,0x3a,0x01,0x05,0x59,0x2a,0x46
};

UCHAR v_38[] = { 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0xe7, 0xc7, 0x4e, 0x3a, 0x6d, 0x2f, 0xe4, 0xa3,
	0x58, 0x51, 0x38, 0x55, 0xd3, 0x4d, 0xc0, 0xd3,
	0xb3, 0x3f, 0xb3, 0x3f, 0x13, 0x37
};
//-------------------------------------------------------------------------------------------------
int func_2( PCHAR arg1, UINT arg2, USHORT arg3 )
{
	register UINT 	ebx, ecx, esi, edi;
	UINT 			v_19, v_1a, v_1b, v_1c;
	UINT 			A, C, D;
	UCHAR 			*v_10, v_18[2];

	v_10 = arg1;
	v_18[0] = arg3 & 0xff;
	v_18[1] = (arg3 & 0xff00) >> 8;
	//-------------------------------------------------------------------
	D    = ((ULLONG)0x66666667*arg2*4) >> 32;
	C    = arg2*4 - (((signed)D >> 2) + (D >> 31)) * 10;
	A    = arg1[C] ^ v_18[0];
	v_19 = (v_18[1] ^ a_804a540[A]) & 0xff;
	//-------------------------------------------------------------------
	esi = (((arg2 & 1) << 2) | 1) + ((arg2 >> 1) & 1) * 8;
    edi = 0;
	
	for( int L=4; L<31; L++ )
	{
		esi = ((((edi ^ 1) & ((arg2 >> (L - 2)) & 1)) | (~(arg2 >> (L - 2)) & edi) ) << L) + esi;
		edi = ((arg2 >> (L - 2)) & 1) & edi;
	}

	ecx = (((arg2 >> 29) ^ edi) << 31) + esi;
	//-------------------------------------------------------------------
	D    = ((ULLONG)0x66666667*ecx) >> 32;
	C    = ecx - (((signed)D >> 2) + (D >> 31)) * 10;
	A    = arg1[C] ^ v_19;	
	v_1a = (v_18[0] ^ a_804a540[A]) & 0xff;
	//-------------------------------------------------------------------
	edi = (arg2 >> 1) & 1 & arg2 & (arg2*2);
	esi = (((((arg2 & 1 & (arg2*2)) ^ 1) & (arg2 >> 1) & 1) |
		   (~(arg2 >> 1) & arg2 & 1 & (arg2*2))) << 3) | 
		    (2 | (arg2 * 4) & 1 | ((arg2 & 1) << 2));
	
	for( int L=4; L<31; L++ )
	{
		esi = ((((edi ^ 1) & ((arg2 >> (L - 2)) & 1)) | (~(arg2 >> (L - 2)) & edi) ) << L) + esi;
		edi = ((arg2 >> (L - 2)) & 1) & edi;
	}
	
	ecx = edi;
	ecx = ((ecx ^ (arg2 >> 29)) << 31) + esi;
	//-------------------------------------------------------------------
	D    = ((ULLONG)0x66666667*ecx) >> 32;
	C    = ecx - (((signed)D >> 2) + (D >> 31)) * 10;
	A    = v_1a ^ v_10[C];
	v_1b = (a_804a540[A] ^ v_19) & 0xff;	

	D    = ((ULLONG)0x66666667*(arg2*4 + 3)) >> 32;
	C    = -((((signed)D >> 2) + (0 >> 31)) * 10) + arg2*4 + 3;
	A    = v_10[C] ^ v_1b;
	v_1c = (v_1a ^ a_804a540[A]) & 0xff;
	//-------------------------------------------------------------------
	
#ifdef VERBOSE_DEBUG
	printf( "-------------------- func_2() stats --------------------\n" );
	printf( "v_19 = 0x%x\nv_1a = 0x%x\nv_1b = 0x%x\nv_1c = 0x%x\n", v_19, v_1a, v_1b, v_1c );
	printf( "func_2(arg1, 0x%x, 0x%x) returns: 0x%x\n", arg2, arg3, (v_1b << 8) | v_1c );
	printf( "--------------------------------------------------------\n\n" );
#endif

	return (v_1b << 8) | v_1c;
}
//-------------------------------------------------------------------------------------------------
void func_1( PCHAR arg1, PCHAR arg2 )
{
	register UINT 	eax, ebx, ecx, edx, esi, edi;
	UINT 			v_10, v_18, v_1c, v_20, v_24, v_2c, v_30, v_34;	
	USHORT 			v_26, v_28;	
	UINT			RET1, RET2,
		 			A[ 125 ] = { 0 },
					B[ 29  ] = { 0 },
					C[ 27  ] = { 0 };

	v_10 = (UINT) arg1;
   	v_18 = (UINT) arg2;
   	v_1c = 0;
    v_20 = 0;
   	v_24 = 1;
	v_26 = arg2[1] + (arg2[0] << 8);
	v_28 = (arg2[2] << 8) | arg2[3];
	//-------------------------------------------------------------------
#ifdef DEBUG
	printf( 
		"v_10 = 0x%x\nv_18 = 0x%x\nv_1c = 0x%x\nv_20 = 0x%x\nv_24 = 0x%x\nv_26 = 0x%x\nv_28 = 0x%x\n",
		v_10,v_18,v_1c,v_20,v_24,v_26,v_28 
	);
#endif
	

	for( v_20=0; v_20<=11; v_20++ )
	{
#ifdef DEBUG
		printf( "============================: Iteration %d :============================\n", v_20 );
#endif

		RET1 = func_2( (PCHAR) v_10, v_1c, v_26 );
		v_28 = ( (v_1c ^ RET1) ^ (v_28 & 0xffff) ) & 0xffff;

		v_1c += v_24;

		RET2 = func_2( (PCHAR) v_10, v_1c, v_28 );
		v_26 = ( (v_1c ^ RET2) ^ (v_26 & 0xffff) ) & 0xffff;
		//-------------------------------------------------------------------
		v_2c = v_1c;
		v_34 = v_24;
		v_30 = v_2c & v_24;

#ifdef DEBUG
		printf( "func_2( arg1, 0x%x, 0x%x )\t", v_1c, v_26 ); 
		printf( "RET1 = 0x%x\tv_28 = 0x%x\n", 	RET1, v_28, v_1c );	
		printf( "func_2( arg1, 0x%x, 0x%x )\t", v_1c-v_24, v_26 ); 
		printf( "RET2 = 0x%x\tv_26 = 0x%x\n", 	RET2, v_26 );
		printf( "v_2c = 0x%x\nv_30 = 0x%x\nv_34 = 0x%x\n", v_2c, v_30, v_34 );
#endif	

		B[28] = v_30 & 1;

		A[124] = B[28] ^ 1;
		A[123] = (v_30 >> 1) & 1;
		A[122] = (v_24 >> 1) ^ 1;
		A[120] = ((v_2c >> 1) & 1) ^ 1;
		A[121] = ((v_24 >> 1) & A[120]) | ((v_2c >> 1) & 1 & A[122]);
		B[27]  = (A[121] & B[28]) | (A[123] & v_30 | A[123] & A[124]);

		A[119] = B[27] ^ 1;
		A[118] =  (v_30 >> 2) & 1;     
		A[117] = ((v_24 >> 2) & 1) ^ 1;
		A[115] = ((v_2c >> 2) & 1) ^ 1;
		A[116] = ((v_24 >> 2) & 1 & A[115]) | ((v_2c >> 2) & 1 & A[117]);
		B[26]  = (A[116] & B[27]) | (A[119] & A[118] | A[119] & B[27]);

		A[114] = B[26] ^ 1;
		A[113] =  (v_30 >> 3) & 1;     
		A[112] = ((v_24 >> 3) & 1) ^ 1;
		A[110] = ((v_2c >> 3) & 1) ^ 1;
		A[111] = ((v_24 >> 3) & 1 & A[110]) | ((v_2c >> 3) & 1 & A[112]);
		B[25]  = (A[111] & B[26]) | (A[114] & A[113] | A[114] & B[26]);

		for( int i=4; i<=28; i++ )
		{
			int o_a = 109 - 4*(i-4);		// set offset of array A
			int o_b = 28  - i;				// set offset of array B
			int o_c = 26  - (i - 4);		// set offset of array C

			if( i == 22 ) o_c = 7;
			if( i == 23 ) o_c = 3;
			if( i == 24 ) o_c = 0;
			if( i == 25 ) o_c = 1;
			if( i == 26 ) o_c = 2;
			if( i == 27 ) o_c = 4;
			if( i == 28 ) o_c = 5;

			A[o_a - 0] = B[o_b + 1] ^ 1;
			A[o_a - 1] = (v_30 >> i) & 1;     
			A[o_a - 2] = ((v_24 >> i) & 1) ^ 1;
			A[o_a - 3] = ((v_2c >> i) & 1) ^ 1;

			C[o_c] = ((v_24 >> i) & 1 & A[o_a - 3]) | 
					 ((v_2c >> i) & 1 & A[o_a - 2]);

			B[o_b]  = (C[o_c] & B[o_b + 1]) | (A[o_a - 0] & A[o_a - 1]  | 
					   						   A[o_a - 0] & B[o_b + 1]);
		}


		A[9] = B[0] ^ 1;
		A[8] = (v_30 >> 29) & 1;     
		A[7] = ((v_24 >> 29) & 1) ^ 1;
		A[6] = ((v_2c >> 29) & 1) ^ 1;
		C[6] = ((v_24 >> 29) & 1 & A[6]) | ((v_2c >> 29) & 1 & A[7]);
		A[2] = (C[5] & B[0]) | (A[9] & A[8] | A[9] & B[0]);

		A[5] = A[2] ^ 1;
		A[4] = (v_30 >> 30) & 1;
		A[3] = ((v_34 >> 30) & 1) ^ 1;
		C[8] = (v_34 >> 30) & 1 & (((v_2c >> 30) & 1) ^ 1) | (v_2c >> 30) & 1 & A[3];
	   	A[1] = v_34 >> 31;


		A[0] = A[1] ^ 1;

		edi  = C[8] & A[2] | A[4] & A[5] | A[4] & A[2]; 
		v_30 = ((A[1] | A[0]) & edi | ((v_30 >> 31) | ((v_2c >> 31) ^ 1) & (A[1] ^ 1) & edi)) << 31;
		//-------------------------------------------------------------------

#ifdef VERBOSE_DEBUG
		printf( "\n\n------------- B ----------------\n");
		for( int i=0; i<29; i++ ) printf( "offset = 0x%x, i = %d, value = 0x%x\n", 0x114 - 4*i, i, B[i] );

		printf( "\n\n------------- C ----------------\n");
		for( int i=0; i<27; i++ ) printf( "offset = 0x%x, i = %d, value = 0x%x\n", 0xa0 - 4*i, i, C[i] );

		printf( "\n\n------------- A ----------------\n");
		for( int i=0; i<125; i++ ) printf( "offset = 0x%x, i = %d, value = 0x%x\n", 0x308 - 4*i, i, A[i] );

		printf( "v_30 = 0x%x\n", v_30 );
#endif

		//-------------------------------------------------------------------
		int off[] = { 8, 6, 5, 4, 2, 1, 0, 3, 7, 9, 10, 11, 12, 13, 14, 15, 16,
					  17, 18, 19, 20, 21, 22, 23, 24, 25, 26 };

		eax = ((v_2c >> 30) & 1 & A[3] | A[4]) & A[2];

		for( int i=30; i>=4; i-- )
		{
			int o_a = 5 + 4*(30 - i);
			int o_b = 30 - i;

			C[ off[30-i] ] = (C[ off[30-i] ] & A[o_a + 0] | eax) << i;

			eax = (A[o_a + 1] & A[o_a + 2] | A[o_a + 3]) & B[o_b];

#ifdef VERBOSE_DEBUG
			printf( "i = %d\t off = 0x%x\t C[ %d ] = 0x%x\t eax = 0x%x\n", 
					i, 0xa0-4*off[30-i], off[30-i], C[off[30-i]], eax );
#endif
		}
	

		eax = ( ((v_34 & 1) ^ 1) & v_2c | 
				(~v_2c & v_34 & 1) 		| 
				(A[121] & A[124] | (A[120] & A[122] | A[123]) & B[28]) * 2) + 
			  4 * (A[116] & A[119] | (A[115] & A[117] | A[118]) & B[27]) + 
			  8 * (A[111] & A[114] | (A[110] & A[112] | A[113]) & B[26]);


		v_1c = eax + v_30;
		for( int i=0; i<27; i++ ) v_1c += C[i];

#ifdef DEBUG			
		printf( "v_1c = 0x%x\tv_30 = 0x%x\teax = 0x%x\n", v_1c, v_30, eax );
#endif

	}
	
    arg2[0] = (v_28 & 0xff00) >> 8;
    arg2[1] = v_28 & 0x00ff;


    arg2[2] = (v_26 & 0xff00) >> 8;
    arg2[3] = v_26 & 0x00ff;

#ifdef DEBUG
	printf( "arg2: 0x%x, 0x%x, 0x%x, 0x%x\n", arg2[0],arg2[1],arg2[2],arg2[3] );
#endif
}
//-------------------------------------------------------------------------------------------------
/*
**	quartet_search(): This function makes a brute force attack on a quartet of password characters.
**
**	Return Value: If a quartet found, function returns true. Otherwise returns false.
*/
bool quartet_search
( 
	UCHAR 		c_st,		// character to start from 
	UCHAR 		c_end, 		// character to stop
	UINT 		off1, 		// offset of password in v_38 array
	UINT 		off2 		// offset of krypto   in v_38 array
)
{
	long int cc = 0;		// counter
	bool found 	= false;	// flag for determining if quartet is found
	
	for( UCHAR a=c_st; !found && a<=c_end; a++ )
	for( UCHAR b=c_st; !found && b<=c_end; b++ )
	for( UCHAR c=c_st; !found && c<=c_end; c++ )
	for( UCHAR d=c_st; !found && d<=c_end; d++ )
	{
		v_38[off1 + 0] = a;							// set characters in v_38
		v_38[off1 + 1] = b;
		v_38[off1 + 2] = c;
		v_38[off1 + 3] = d;
				
		func_1( &v_38[28], &v_38[off1] ); 			// modify them

		if( v_38[off1 + 0] == v_38[off2 + 0] &&		// correct quartet? 
			v_38[off1 + 1] == v_38[off2 + 1] &&
			v_38[off1 + 2] == v_38[off2 + 2] && 
			v_38[off1 + 3] == v_38[off2 + 3]  )
		{
			printf( "\tQuater found! : %c %c %c %c\n", a, b, c, d );
			found = 1;								// enable found & exit
		}

		if( ++cc % 100000 == 0 )	
			printf( "\t%ld iterations. Trying... %c %c %c %c\n" , cc, a, b, c, d);
	}

	return found;
}
//-------------------------------------------------------------------------------------------------
int main( int argc, char *argv[] )
{
	printf( "+--------------------------------------------------+\n" );
	printf( "+              Qnix's krypto (level 4)             +\n" );
	printf( "+               keygen by __s3R10u5__              +\n" );
	printf( "+--------------------------------------------------+\n" );


	const int C_START = 'a',						// set character to start from
			  C_END   = 'z';						// set character to end with


	printf( "Searching for 1st quartet...\n" );		// find first 4 character of password
	quartet_search( C_START, C_END, 12, 24 );

	printf( "Searching for 2nd quartet...\n" );		// find next  4 character of password
	quartet_search( C_START, C_END, 8, 20 );

	printf( "Searching for 3rd quartet...\n" );		// find last  4 character of password
	quartet_search( C_START, C_END, 0, 16 );

	return 0;
}
//-------------------------------------------------------------------------------------------------

