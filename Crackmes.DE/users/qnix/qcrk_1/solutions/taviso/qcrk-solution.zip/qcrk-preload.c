#define _GNU_SOURCE
#include <dlfcn.h>

#define KEY "110100010010100011110101010010100100101010100101010100101010"

static int (* strcmpptr)(const char *s1, const char *s2);

void __attribute__((constructor)) init (void)
{
    strcmpptr = dlsym(RTLD_NEXT, "strcmp");
}

int strcmp(const char *s1, const char *s2)
{
    if (strcmpptr(s1, KEY) == 0)
        return strncmp(s1, s2, 9);

    return strcmpptr(s1, s2);
}
