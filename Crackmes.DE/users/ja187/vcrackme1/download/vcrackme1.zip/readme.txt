Name: VCrackme1

Author: losgrandes

Language: Assembler

Platform: Windows

Description:	
- DYNAMIC SMC
- SIMPLY DATA CRYPTO
- SIMPLY SERIAL CHECKING
- ANTI-DEBUGGING TRICK
- LITTLE CODE OBFUSCATION

This is my first crackme so don't blame me for mistakes or poor standard.

