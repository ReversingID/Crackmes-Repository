
# Quick 'n dirty solution

## Recon

The binary is huge due to static compilation and symbols have been stripped out.
A little googling of error strings allow us to know its a CHICKEN compiled binary.
 
Little optionnal tips:

* In order to have more insight about what part of the code was interesting throught the 1.4Mb, I compiled an helloword scheme file `[1]` and manually match common code section propagating symbol informations by the way.
* I read a great post about CHICKEN internal representation `[2]` to better understand how things was organised in memory. Crazy stuff...

## Down the rabbit hole

I decide to start by tracking usage of "good boy" and "bad boy" strings in the binary.

<pre>

	0x0810c30f  636d 00fe 4200 0037 506c 6561 7365 2072  cm..B..7Please r
	0x0810c31f  756e 2061 7320 2e2f 6265 726b 7574 2061  un as ./berkut a
	0x0810c32f  6e5f 6172 6775 6d65 6e74 2028 652e 672e  n_argument (e.g.
	0x0810c33f  202e 2f62 6572 6b75 7420 6162 6329 0a00   ./berkut abc)..
	0x0810c34f  fe42 0000 0a47 6f6f 6420 626f 7921 0a00  .B...Good boy!..
	0x0810c35f  fe42 0000 0942 6164 2062 6f79 210a 006c  .B...Bad boy!..l
	0x0810c36f  6962 7261 7279 5f74 6f70 6c65 7665 6c00  ibrary_toplevel.

</pre>

Grepping for references lead us to `0x804991e`:

<pre>

			...
            0x08049a23      ba4fc31008     mov edx, 0x810c34f			; good_boy
            0x08049a28      a36c311a08     mov dword [0x81a316c], eax
            0x08049a2d      b8146d1a08     mov eax, 0x81a6d14
            0x08049a32      e805250c00     call 0x810bf3c
            0x08049a37      ba5fc31008     mov edx, 0x810c35f			; bad_boy
            0x08049a3c      a370311a08     mov dword [0x81a3170], eax	; good_boy_wrapped
            0x08049a41      b8146d1a08     mov eax, 0x81a6d14
            0x08049a46      e8f1240c00     call 0x810bf3c
            0x08049a4b      b9c6c11008     mov ecx, 0x810c1c6
            0x08049a50      a374311a08     mov dword [0x81a3174], eax  ; bad_boy_wrapped
			...

</pre>

After a quick look a the function `0x810bf3c` we realize it use register based calling convention.
We then assume that the function consume a string and produce some derived datas.
These datas are then stored at `0x81A3174` (bad) and `0x81A3170` (good) offsets.

Tracking these globals references lead to a function at `0x80495bb`:

<pre>

            0x080495bb      83ec1c         sub esp, 0x1c
            0x080495be      8b442424       mov eax, dword [esp + 0x24] ; arg
            0x080495c2      8d542404       lea edx, dword [esp + 4]
            0x080495c6      8b08           mov ecx, dword [eax]
            0x080495c8      83780406       cmp dword [eax + 4], 6	   ; *(arg + 4) == 6 ?
            0x080495cc      a168311a08     mov eax, dword [0x81a3168]
            0x080495d1      8b4004         mov eax, dword [eax + 4]
            0x080495d4      89442404       mov dword [esp + 4], eax
            0x080495d8      8b4908         mov ecx, dword [ecx + 8]
            0x080495db      894c2408       mov dword [esp + 8], ecx
            0x080495df      8b0d70311a08   mov ecx, dword [0x81a3170]  ; good_boy_wrapped
        ,=< 0x080495e5      7506           jne 0x80495ed
        |   0x080495e7      8b0d74311a08   mov ecx, dword [0x81a3174]  ; bad_boy_wrapped
        `-> 0x080495ed      894c240c       mov dword [esp + 0xc], ecx  ; ecx is either good or bad based on arg value
            0x080495f1      51             push ecx 
            0x080495f2      51             push ecx
            0x080495f3      52             push edx
            0x080495f4      6a03           push 3
            0x080495f6      ff5004         call dword [eax + 4]

</pre>

We clearly see that the function choose either the good or bad value based on the its parameters.

We then look at the xref function, `0x8049715`:

<pre>
			...
            0x0804974a      c7442414bb95.  mov dword [esp + 0x14], 0x80495bb  ; our bad / good switch function
            0x08049752      8d7c241c       lea edi, dword [esp + 0x1c]
            0x08049756      8b4308         mov eax, dword [ebx + 8]
            0x08049759      893c24         mov dword [esp], edi
            0x0804975c      89442418       mov dword [esp + 0x18], eax
            0x08049760      50             push eax
            0x08049761      50             push eax
            0x08049762      55             push ebp
            0x08049763      680a630000     push 0x630a			   ; 0x63 = 'c'
            0x08049768      e88cfeffff     call 0x80495f9          ; check_fct(0x630a, ebp)
            0x0804976d      83c410         add esp, 0x10
            0x08049770      83f806         cmp eax, 6
            0x08049773      8d4c2404       lea ecx, dword [esp + 4]
        ,=< 0x08049777      0f8485000000   je 0x8049802
        |   0x0804977d      8b6d08         mov ebp, dword [ebp + 8]
        |   0x08049780      50             push eax
        |   0x08049781      50             push eax
        |   0x08049782      55             push ebp
        |   0x08049783      680a780000     push 0x780a			   ; 0x78 = 'x'
        |   0x08049788      e86cfeffff     call 0x80495f9          ; check_fct(0x780a, ebp)
        |   0x0804978d      83c410         add esp, 0x10
        |   0x08049790      83f806         cmp eax, 6
       ,==< 0x08049793      746d           je 0x8049802
       ||   0x08049795      8b6d08         mov ebp, dword [ebp + 8]
       ||   0x08049798      50             push eax
       ||   0x08049799      50             push eax
       ||   0x0804979a      55             push ebp
       ||   0x0804979b      680a650000     push 0x650a				; 0x65 = 'e'
       ||   0x080497a0      e854feffff     call 0x80495f9  			; check_fct(0x650a, ebp)
       ||   0x080497a5      83c410         add esp, 0x10
       ||   0x080497a8      83f806         cmp eax, 6
      ,===< 0x080497ab      7455           je 0x8049802
      |||   0x080497ad      8b6d08         mov ebp, dword [ebp + 8]
      |||   0x080497b0      50             push eax
      |||   0x080497b1      50             push eax
      |||   0x080497b2      55             push ebp
      |||   0x080497b3      680a6d0000     push 0x6d0a				; 0x6d = 'm'
      |||   0x080497b8      e83cfeffff     call 0x80495f9  			; check_fct(0x6d0a, ebp)
      |||   0x080497bd      83c410         add esp, 0x10
      |||   0x080497c0      83f806         cmp eax, 6
     ,====< 0x080497c3      743d           je 0x8049802
     ||||   0x080497c5      8b5508         mov edx, dword [ebp + 8]
     ||||   0x080497c8      8d442424       lea eax, dword [esp + 0x24]
     ||||   0x080497cc      c744241c0100.  mov dword [esp + 0x1c], 1
     ||||   0x080497d4      c74424240200.  mov dword [esp + 0x24], 0x24000002
     ||||   0x080497dc      c74424282798.  mov dword [esp + 0x28], 0x8049827
     ||||   0x080497e4      897c242c       mov dword [esp + 0x2c], edi
     ||||   0x080497e8      89442420       mov dword [esp + 0x20], eax
     ||||   0x080497ec      89442404       mov dword [esp + 4], eax
     ||||   0x080497f0      89742408       mov dword [esp + 8], esi
     ||||   0x080497f4      8954240c       mov dword [esp + 0xc], edx
     ||||   0x080497f8      53             push ebx
     ||||   0x080497f9      53             push ebx
     ||||   0x080497fa      51             push ecx
     ||||   0x080497fb      6a03           push 3
   ,=||||=< 0x080497fd      e825000000     call 0x8049827
   | |||| 
   | |||| 
   | ````-> 0x08049802      a168311a08     mov eax, dword [0x81a3168] ; if we jump here we likely failed ...
   |        0x08049807      8b4004         mov eax, dword [eax + 4]
   |        0x0804980a      89442404       mov dword [esp + 4], eax
   |        0x0804980e      8b5308         mov edx, dword [ebx + 8]
   |        0x08049811      89542408       mov dword [esp + 8], edx
   |        0x08049815      8b1574311a08   mov edx, dword [0x81a3174] ; bad_boy_wrapper
   |        0x0804981b      8954240c       mov dword [esp + 0xc], edx
   |        0x0804981f      52             push edx
   |        0x08049820      52             push edx
   |        0x08049821      51             push ecx
   |        0x08049822      6a03           push 3
   |        0x08049824      ff5004         call dword [eax + 4]
   |
   |        ....
   |
   `------> 0x08049827      56             push esi
            0x08049828      53             push ebx
            0x08049829      83ec14         sub esp, 0x14
            0x0804982c      3925bc6d1a08   cmp dword [0x81a6dbc], esp 
            0x08049832      8b4c2424       mov ecx, dword [esp + 0x24] 
        ,=< 0x08049836      760e           jbe 0x8049846
        |   0x08049838      53             push ebx
        |   0x08049839      51             push ecx
        |   0x0804983a      6a03           push 3                      
        |   0x0804983c      6827980408     push 0x8049827
        |   0x08049841      e8e0ca0b00     call 0x8106326
        `-> 0x08049846      8b7108         mov esi, dword [ecx + 8]    
            0x08049849      8b4104         mov eax, dword [ecx + 4]    
            0x0804984c      8d5c2404       lea ebx, dword [esp + 4]    
            0x08049850      83fe0e         cmp esi, 0xe
        ,=< 0x08049853      750e           jne 0x8049863
        |   0x08049855      89442404       mov dword [esp + 4], eax
        |   0x08049859      c74424080600.  mov dword [esp + 8], 6		; 0x6 = false
       ,==< 0x08049861      eb1d           jmp 0x8049880
       |`-> 0x08049863      8b5604         mov edx, dword [esi + 4]
       |    0x08049866      c1fa08         sar edx, 8					; shift and mask ... just like in 80495f9 fn
       |    0x08049869      81e2ffff1f00   and edx, 0x1fffff
       |    0x0804986f      83fa61         cmp edx, 0x61                ; 0x61 = 'a'
       |,=< 0x08049872      7514           jne 0x8049888
       ||   0x08049874      89442404       mov dword [esp + 4], eax
       ||   0x08049878      c74424081600.  mov dword [esp + 8], 0x16    ; 0x16 = true
       `--> 0x08049880      52             push edx
        |   0x08049881      52             push edx
        |   0x08049882      53             push ebx
        |   0x08049883      6a02           push 2                      
        |   0x08049885      ff5004         call dword [eax + 4]
        |
        `-> 0x08049888      8b11           mov edx, dword [ecx]			; if we jump here we likely failed ...
            0x0804988a      8b7608         mov esi, dword [esi + 8]    
            0x0804988d      8b5208         mov edx, dword [edx + 8]    
            0x08049890      8b5204         mov edx, dword [edx + 4]    
            0x08049893      89442408       mov dword [esp + 8], eax
            0x08049897      8974240c       mov dword [esp + 0xc], esi
            0x0804989b      89542404       mov dword [esp + 4], edx
            0x0804989f      50             push eax
            0x080498a0      50             push eax
            0x080498a1      53             push ebx
            0x080498a2      6a03           push 3
            0x080498a4      ff5204         call dword [edx + 4]
</pre>

Here we see an interesting pattern of imbricated conditions based on operation involving constants. We also notice that the function end by a branching wich may lead to the use of (bad) `0x81a3174`.

The conditions are based on the `0x80495f9` function result:

<pre>

     0x080495f9      8b542408       mov edx, dword [esp + 8]  ; arg2
     0x080495fd      b806000000     mov eax, 6
     0x08049602      83fa0e         cmp edx, 0xe
 ,=< 0x08049605      741a           je 0x8049621
 |   0x08049607      8b442404       mov eax, dword [esp + 4]  ; arg1
 |   0x0804960b      334204         xor eax, dword [edx + 4]
 |   0x0804960e      c1f808         sar eax, 8
 |   0x08049611      25ffff1f00     and eax, 0x1fffff
 |   0x08049616      83f801         cmp eax, 1
 |   0x08049619      19c0           sbb eax, eax
 |   0x0804961b      83e010         and eax, 0x10
 |   0x0804961e      83c006         add eax, 6
 `-> 0x08049621      c3             ret

</pre>

The function strangely check its two parameters equality (minus the dword low byte, this is tied to CHICKEN internals see `[2]` for further explanations) and return 0x16 (true) or 0x6 (false).

By following the control flow we land in the `0x08049827` function and find a similar check and again the same 0x16 and 0x6 constants.

At this point we can pretty safely assume that we are facing some checks against (derived) input values.

Lets fire up the debugger... and confirm our assumptions :)

<pre>

$ ./berkut cxema
Good boy!

</pre>

Notice that only the first 5 characters are checked.

## The end

Quite interresting, I had hard time figuring out how CHICKEN control flow goes, but has exposed above, it wasn't mandatory to solve the challenge.

Imo stripping the binary wasn't needed as symbol semantics are somewhat limited but overall easily retrievable.

If the scheme sources where a little more developed, the static analysis may have been far more painful, especially if we try to get a generic CHIKEN decompiler...

~sdf

	[1] : echo "(print "Hello, world!")" >> helloworld.scm && csc helloworld.scm -static
	[2] : http://www.more-magic.net/posts/internals-data-representation.html 

