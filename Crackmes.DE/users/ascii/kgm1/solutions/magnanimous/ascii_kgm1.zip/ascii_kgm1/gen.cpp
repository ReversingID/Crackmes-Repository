/*
 * For "KeyGenMe1" by ascii.
 *
 * Hopefully not too heavily commented ;D
 *
 * __magnanimous__
 *
 */

#include <iostream>
#include <stdlib.h>	//For srand()
#include <time.h>	//For time()
using namespace std;

main()
{
	int key[9];		//Our inputted key
	int cmp[8] = {0x45, 0x36, 0xAB, 0xC8, 0xCC, 0x11, 0xE3, 0x7A}; //Values compared
	int final_key[9];	//Tmp
	int i;			//Counter
	int sigma = 0;		//Summation


	srand( time( NULL ) );

	while( 1 ) {

		/* Generate random key */

		cout << hex;

		for( i = 0; i <= 8; ++ i ) {

			key[i] = (rand() % 95 + 32);	//Between 32d and 127d
			cout << key[i] << " ";
		}

		cout << endl;

		for( i = 0; i <= 9; ++i )
			final_key[i] = key[i];		//Copy to temp var

		/* Calc key */

		for( i = 0; i <= 7; ++i) {

			key[i] ^= cmp[i];		//New key == (old key) xor (stored values)
			sigma += key[i];		//Summation of the new key
		}

		sigma &= 0xFF;				//Clear high bits of ECX (ECX -> CL)


		cout << sigma << "\t";
		cout << final_key[8] << endl << endl;


		if( sigma == final_key[8] && final_key[8] < 0x80 && final_key[8] > 0x61 ) {

			cout << "\nFOUND KEY: \n\n";
			
			for( i = 0; i <= 8; ++ i )
                        	cout << final_key[i] << " ";

			cout << endl;

			break;				//Let's get the hell out of this loop.
		}

		/*Clear vars*/

		sigma = 0;

	}
}
