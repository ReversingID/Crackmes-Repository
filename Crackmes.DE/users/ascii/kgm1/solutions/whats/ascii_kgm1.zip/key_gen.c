/* 
 * Albert Sellarès <whats[at]wekk.net>
 * http://www.wekk.net
 *
 * Solution for KeyGenMe1/ascii - http://crackmes.de
 *
 * gcc key_gen.c -o key_gen $(pkg-config --libs openssl)
 */

#include <stdio.h>
#include <openssl/rand.h>

#define KEYLENGHT 9
unsigned char hardcoded[KEYLENGHT-1] = "\x45\x36\xab\xc8\xcc\x11\xe3\x7a";

int suma(char * vector, int n){
	unsigned int result=0,i=0;
	for (i=0; i<n; i++){
		result+=vector[i];
	}
	return result;
}

void xor(char * dst, char * src,  int n){
	int i;
	for (i=0; i<n; i++){
		dst[i]=src[i]^hardcoded[i];
	}
}

void randomstring(char * buff, int n){
	int i;
	for (i=0; i<n; i++){
		do {
			RAND_bytes(&buff[i], 1);
		} while (buff[i] < 0x21 || buff[i] > 0x7e);
	}
}

int main(int argc, char *argv[]) {
	
	unsigned char key[KEYLENGHT];
	unsigned char rand[KEYLENGHT];
	int num;

	printf("KeyGenMe1/ascii keygen by whats\n");
	printf("===============================\n");

	do {
		randomstring(key, KEYLENGHT-1);
		xor(rand, key, KEYLENGHT-1);
		num=suma(rand, KEYLENGHT-1);
	} while (num < 0x61 || num > 0x7a);

	key[KEYLENGHT-1]=(char)num;
	key[KEYLENGHT]='\0';
	printf(" * KEY => %s\n",key);
	
	return 0;
}
