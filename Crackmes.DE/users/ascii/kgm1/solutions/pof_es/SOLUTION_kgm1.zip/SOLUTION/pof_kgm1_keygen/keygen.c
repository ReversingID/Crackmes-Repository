#include <sys/times.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

/* returns random number seed, run like this: srandom(RandomSeed()); */
int RandomSeed()
{
	struct tms timeinfo;
	return times(&timeinfo);
}

/* returns random number between min and max */
int RandomNumber(int min,int max)
{
	int j;
	do j = 1 + (int) ((double)(max)*(rand() / (RAND_MAX + 1.0)));
	while (( j < min ) || (j > max));
	return j;
}

int main()
{

	unsigned int i;
	unsigned char val[9];
	unsigned char pos[9];
	unsigned char res[9];
	unsigned int total=0;
	
	pos[0]=0x45;
	pos[1]=0x36;
	pos[2]=0xab;
	pos[3]=0xc8;
	pos[4]=0xcc;
	pos[5]=0x11;
	pos[6]=0xe3;
	pos[7]=0x7a;

	printf ("KeyGenMe1 / ascii key generator by pof\n");
	srandom(RandomSeed());
	
	do
	{
		total = 0;
		for (i=0;i<8;i++)
		{
			val[i]=RandomNumber(0x21,0x7a); // get a valid printable char
			res[i]=(val[i])^pos[i]; // XOR
			total = total + res[i];
		}
	}
	while (((total & 0xFF) < 0x61) || ((total & 0xFF) > 0x7a));

	val[8]=total & 0xFF;

	printf ("Key: ");
	for (i=0;i<9;i++)
	{
		printf("%c",val[i]);
	}
	printf ("\n");

	return 0;
}
