This is my first key generator for crackmes.de :)

I wrote the keygen using radare disassembler and debugger.
	http://radare.nopcode.org/

Steps to write it:

- debug it using radare -c dbg://./kgm1
at 0x0804846E it does 'cmp eax, 0xa' so we know the lengh should be 9
- invalid key is at 0x80484CF , so we want always to avoid jumping here
at 0x0804847C it loads [edx+0x8049707] into eax, this is the pos[]; array used in my keygen
- for each char we entered as key, it does XOR with the value in pos[].
- the value of the last char should match the SUM(all xor result values)^FF
- and it should be a character between a-z (0x61 to 0x7a)
if we match these conditions we never jump to 0x80484CF  (invalid key)
- so just write a c program to brute force a string matching the conditions

I hope you enjoy it as much as I did :)


						-pof
					http://pof.eslack.org/
