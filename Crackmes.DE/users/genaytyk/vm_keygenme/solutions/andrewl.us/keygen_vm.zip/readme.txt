disasm.cpp           disassembler source file
disasm.exe           disassembler executable
disasm.txt           disassembler output
disasm_commented.txt disassembler output with comments
keygen.cpp           keygen source
keygen.exe           keygen executable
readme.txt           this file
solution.txt         tutorial/explanation


