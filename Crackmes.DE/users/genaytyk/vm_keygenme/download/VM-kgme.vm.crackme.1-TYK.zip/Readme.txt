VM Kgme by Genaytyk (VM crackme 1)
----------------------------------

Ce crackme utilise un interpr�teur de p-code maison pour v�rifier les serials.

R�gles/Remarques :
----------------
- Ce n'est pas un d�fi pour les d�butants
- Le patching est interdit, seuls les keygens sont accept�s
- Le crackme peut mettre du temps pour v�rifier un serial, c'est du � la machine virtuelle et au cryptage �lev�, il n'y a pas
  de "Sleep" ^^.
- Bonne chance, envoyez vos keygens/tuts � genaytyk@hotmail.com

---------------------

Rules/Comments :
--------------
- This is not a challenge for beginners
- Patching is forbidden, only keygens will be approved
- The crackme can check the serial during many seconds, it comes from the virtual machine and the high cipher, there is no
  "Sleep" ^^
- Good luck, sends keygens/tuts to genaytyk@hotmail.com



Thanks to : nGen team, FRET members and idlers on forum and chan, #uct chan (extr�mistes!), fff, every crazy people from anywhere 
---------   and all I know... That's all ^^


And special thanks to all who will try to crack this shit





Genaytyk
