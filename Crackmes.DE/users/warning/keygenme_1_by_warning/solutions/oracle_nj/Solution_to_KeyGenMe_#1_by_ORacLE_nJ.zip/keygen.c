/*

Keygen for KeyGenMe #1 By Warning by ORacLE_nJ
Written in pure C with Visual C++ 6.0

*/


#include<stdio.h>
#include<string.h>
#include<conio.h>
#include<math.h>

void main()
{
unsigned int i0, i1, i2, i3, i4, i5, i6, i7, i8, i9;
int i, l, fin, temp1;
char ser[12] = {"0"};
double str1, str2, str3, str4, str5, str6, str7, str8, str9, temp2;

double u1 = 443333.43550, u2 = 444314213.435500032;

// Saving the Values of 1/20 and 1/12
// Shortens Code Length + Faster

double inv20[] = {0, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45};
double inv12[] = {0, 0.083334, 0.166667, 0.25, 0.33334, 0.416667, 0.5, 0.58334, 0.66667, 0.75};


char ch1[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
unsigned int sz = strlen(ch1);

printf("\n\nStarting bruteforce......\n\nKeys :\n");

for (i0 = 0; i0<sz;i0++){
for (i1 = 0; i1<sz;i1++){
for (i2 = 0; i2<sz;i2++){
for (i3 = 0; i3<sz;i3++){
for (i4 = 0; i4<sz;i4++){
for (i5 = 0; i5<sz;i5++){
for (i6 = 0; i6<sz;i6++){
for (i7 = 0; i7<sz;i7++){
for (i8 = 0; i8<sz;i8++){
for (i9 = 0; i9<sz;i9++){

l = sprintf(ser, "%c%c%c%c%c%c%c%c%c%c",ch1[i0], ch1[i1], ch1[i2], ch1[i3], ch1[i4],
										ch1[i5], ch1[i6], ch1[i7], ch1[i8], ch1[i9]);


str1=0; str2=0; str3=0; str4=0; str5=0;
str6=0; str7=0; str8=0; str9=0; fin=1;

for(i=0; i<l; i++)
{
	str1 = ser[l-i-1];

	str2 = inv20[i];
	str3 = pow(u2, str2);
	str4 = str1 / str3;

	str6 = inv12[i];
	str7 = pow(u1, str6);
	str8 = str4 * str7;
	str9 = str8 + fin;

	// Equivalent to Fix function in vb

	temp1 = str9;			// getting decimal part
	temp2 = temp1 + 0.5;
	if(str9 == temp2)
	{
		continue;
	}

	if(str9 > temp2)
	{	fin = str9 + 1;	}
	else 
	{	fin = str9; }
}

// printf("%s\t%X\n", ser, fin);

if(fin == 0x46E)
{
	printf("\n\n%s\n\n", ser);
	system("pause");
}

}}}}}}}}}}

getch();
}