
#ifndef DREGZ_DECODER_523445235_H
#define DREGZ_DECODER_523445235_H

#ifdef __cplusplus
extern "C" {
#endif

int decode_license(const char *license, int *lic_id);

#ifdef __cplusplus
}
#endif

#endif

