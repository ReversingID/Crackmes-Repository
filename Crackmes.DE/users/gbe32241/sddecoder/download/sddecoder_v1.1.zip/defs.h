
#ifndef DEFDREGZ_5234363454324_H
#define DEFDREGZ_5234363454324_H

typedef char ELEMENT;
typedef unsigned char   WORD_8;
typedef unsigned short  WORD16;
typedef unsigned int    WORD32;

#endif
