
#ifndef LICENSE_CODE_9EE0340673494794_H
#define LICENSE_CODE_9EE0340673494794_H

#ifdef __cplusplus
extern "C" {
#endif

#define KEYIDSIZE        36
#define G_KEYSIZE        128
#define G_RESULTSIZE     120
#define POTSIZE          4
#define POLYSIZE         3

#define LICENSE_VECTOR   33028

extern const unsigned int lsvec[LICENSE_VECTOR];
extern const int ipol[POLYSIZE];

#ifdef __cplusplus
}
#endif

#endif    /* LICENSE_CODE_9EE0340673494794_H */

