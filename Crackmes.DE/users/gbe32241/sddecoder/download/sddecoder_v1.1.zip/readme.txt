
SDDecoder V1.1
==============

=================================================================

This is an updated version of my original SDDecoder challenge 
which will hopefully clarify some misunderstandings.

Nothing has changed from the previous challenge under a mathematical
point of view.

I just added a few tasks for you and a couple of functions to the 
code in order to perform some extra checks.

=================================================================

Very simple to understand, but hopefully very hard to carry out !
Here's a decoder to check for valid codes related to product 
activation.

Task #1: Describe the math behind functions f_evaluate and
verify_parity and what is the lsvec used for.

Task #2: find a valid serial other than these I provide (added 4 new) 

ID   License string
-------------------------------------
 0:  J2PCD-7N9CY-UT3KY-6YCYO-YDN93
 1:  74G7C-TIKSB-UO3L9-HUOFB-R44X7
 2:  Q3HU7-HBJTG-2QCXZ-JYRNM-RDNMG
 3:  MRNUF-933SM-VMNWD-JM7SA-B2UDJ
 4:  Q6EVW-K3GV7-IZZC3-G4974-DKB2B
 5:  RISUU-S6EY7-TPVTE-GXGOI-6YH7Q
 6:  R4VUK-LOAQB-RE93N-VTCVL-XGW6P
 7:  SPYZA-VIPVX-3T3GF-F32TM-IQJY7
 8:  SEJUK-Z7SBS-GBDUS-MHEZS-Y7DLC
 9:  NVLS2-AU6A6-ZDGP6-FEBBO-J2CNQ


Task #3: Create a keygen.

Task #4: Describe the core problem you have faced in solving
this challenge (or you are facing and prevents you from solving).

A tutorial on how you did is well appreciated.

========================================

Notes: 

I've added a blacklist to prevent people from solving this challenge by
using codes trivially derived from the ones I supplied.
In a real world scenario a black-list would also exist to revoke stolen 
codes of course.

Once validated, a code has an embedded signature which bears an ID - 
a number in the range [0..2^31) - which may be shared among other valid 
codes but that's for a given code is always the same.

For example codes: "J2PCD-7N9CY-UT3KY-6YCYO-YDN93" and 
"UWZ73-7JPR3-AKQHT-DNR9Z-WPXS6" (oops! I leaked another license, shame 
on me! :-) both share the same ID which will always be equal to 0. 

Once a code is revoked, it's black-listed by ID not by string, therefore 
it is useless to trivially derive codes by using combinations of letters
in the license string which are mapped to the same symbols (for example
digits '1058' are replaced with letters 'IOSB' and letters are always
uppercased).

A keygenerator is expected to produce codes with random or sequential IDs, 
covering a large portion of the 2^31 key space. In other words, if we were 
in a real world scenario, it should be impossible for me to black-list codes
of your keygen without invalidating also codes of legitimate users.

In the same spirit new license codes are expected to have different IDs from 
those belonging to the ones I supplied (which anyway are detected as 
blacklisted).

A legitimate key generator is able to create codes with a 
specific license ID, therefore no pair of codes emitted to users would share 
the same ID (unless I'll do it on purpose as in the example above).


Finally some suggestions / comments:

1) I would not recommend you to use brute-force to solve this one, the
complexity is expected to be 2^84 in the key space, just to find a single 
valid license.

2) I may have underrated this challenge.

3) I'm not using HFE (Hidden Field Equations).

4) I've added only a few comments in the source code. 
   Too many hints would spoil the game.

5) I'm providing full C source code of this decoder because the difficulty 
   does not rely on any code obfuscation tecnique but is entirely 
   mathematical.

========================================

Hope you enjoy the challenge.

Thank you.
gbe32241@libero.it













