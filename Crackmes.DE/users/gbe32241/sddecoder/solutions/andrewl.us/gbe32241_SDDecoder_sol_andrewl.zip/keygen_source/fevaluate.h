int f_evaluate(char *x, int xsize, char *r, int rsize);
Vect f_evaluatev(Vect x);

