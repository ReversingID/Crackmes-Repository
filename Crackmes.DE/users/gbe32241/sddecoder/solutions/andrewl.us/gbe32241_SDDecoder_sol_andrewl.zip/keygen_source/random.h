

BOOL InitRandom();


BOOL GetRandom(UINT64 *val);


BOOL ReleaseRandom();

