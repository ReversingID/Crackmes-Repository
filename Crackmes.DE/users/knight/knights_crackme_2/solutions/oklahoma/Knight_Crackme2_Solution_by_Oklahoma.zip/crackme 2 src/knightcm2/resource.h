//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by knightcm2.rc
//
#define IDD_DIALOG                      101
#define IDC_EDIT_NAME                   1001
#define IDC_EDIT_CODE                   1002
#define IDC_BUTTON1                     1003
#define IDC_CHECK                       1003
#define IDC_BUTTON2                     1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
