#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <commctrl.h>
#include <stdlib.h>
#include <stdio.h>
#include "resource.h"

char	name[32];
char	code[30];

unsigned long key[5];

signed	long	hash1,hash2,hash3;

bool	checkPads(void) // kinda checking dashes "-", but can be "<" or something else.
{
	return (!(BYTE)(~(code[11]|(code[5]<<4)^(code[5]>>4)))
		&&!(BYTE)(((code[23]<<4)^(code[17])|(code[23]>>4))+1));
}

bool	deHex(void) // Yeak!
{
	for(int a=0,k=0;a<30;a+=6,k++)
	{
		key[k]=0;
		for(int b=0;b<5;b++)
			if(code[a+b]>='0'&&code[a+b]<='9')
			{
				key[k]<<=4;
				key[k]|=code[a+b]-48;
			}
			else
				if(code[a+b]>='A'&&code[a+b]<='F')
				{
					key[k]<<=4;
					key[k]|=code[a+b]-55;
				}
				else
					return false;
	}
	return true;
}

void	hashName(int len) // just name hashing, (boring).
{
	long	temp=0;
	if((len&1)!=0) // length/2 even or odd
		hash3=hash2=name[len/2]&0xfffffffe;
	else
		hash3=hash2=(name[len/2-1]+name[len/2])/2&0xfffffffe;
	for(int i=len/2+1;i<len;i++)
		temp+=name[i];
	temp=(/* kinda short rotr */(temp<<12|temp>>4)&0xffff);
	hash2+=temp;
	hash3*=temp;
	len=(len/2)-((~(len&1))&1);
	temp=0;
	for(int i=0;i<len;i++)
		temp+=name[i]^32;
	temp=(((temp<<12|temp>>4)&0xffff)*hash2)^hash2; // last xor is a trash
	
	// ... and tashy code, yup I'm lazy to make a candy...
	hash1=hash3^temp^(hash2^temp)^(hash2^temp^(hash3^temp^(hash2^temp)));
	hash2=hash2^temp^(hash3^temp^(hash2^temp))^(temp^(hash2^temp^(hash3^temp^(hash2^temp))))^hash3^temp^(hash2^temp)^(hash2^temp^(hash3^temp^(hash2^temp)));
	hash3=temp^(hash2^temp^(hash3^temp^(hash2^temp)));
	/*
	i.e
	hash1=temp^hash2;
	hash2=hash2;
	hash3=hash3;
	*/
}

bool	checkIt(void) // Zzzzzz.....
{
	if(strlen(name)>=5
		&&/*strlen(code)==29*/!(BYTE)(~(((strlen(code)*8)+7)|16))
		&&checkPads()&&deHex())
	{
		hashName((int)strlen(name)); // hash it!
		key[4]^=(key[2]<<20);
		key[0]=-(key[0]^(key[1]<<20));			
		key[1]>>=12; // 0xfffff>>12 = 0xff
		key[2]>>=12; // the same
		if(hash3==key[3]*key[2])
		{
			if((key[1]-hash2)*key[1]==-hash3)
				if((key[0]+key[4])*hash2/2==hash1)
					if(key[3]+key[2]==hash2)
						if((hash2-1)*key[1]+key[0]==key[4])
							return true;
		}
	}
	return false;
}

void	generate(void) // voila
// Sorry for stupidity, could be prettyer
{
	int	len=(int)strlen(name);
	long	temp=0;
	if((len&1)!=0) // lenght/2 even or odd
		hash3=hash2=name[len/2]&0xfffffffe;
	else
		hash3=hash2=(name[len/2-1]+name[len/2])/2&0xfffffffe;
	for(int i=len/2+1;i<len;i++)
		temp+=name[i];
	temp=(/* kinda short rotr */(temp<<12|temp>>4)&0xffff);
	hash2+=temp;

	// these are simple
	key[3]=temp;
	key[1]=key[2]=hash3<<12;
	//

	hash3*=temp;
	len=(len/2)-((~(len&1))&1);
	temp=0;
	for(int i=0;i<len;i++)
		temp+=name[i]^32;

	temp=(((temp<<12|temp>>4)&0xffff)*hash2);

	long	t4,t0;

	t0=(((temp)/(hash2))*2)+((hash2-1)*(key[1]>>12)/2)-((temp)/(hash2)*3);
	t4=(((temp)/(hash2))*2)+((hash2-1)*(key[1]>>12)/2)-((temp)/(hash2));

	// making it fit into key
	key[0]=(t0&0xfffff);
	key[1]|=(t0&0xfff00000)>>20;
	key[2]|=(t4&0xfff00000)>>20;
	key[4]=(t4&0xfffff);

	sprintf(code,"%05X-%05X-%05X-%05X-%05X",key[0],key[1],key[2],key[3],key[4]);
	if(!checkIt()) // check it for validity. :(
		strcpy(code,"Invalid name");
}

INT_PTR	CALLBACK proc(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	switch(uMsg)
	{
	case WM_INITDIALOG:
		return 1;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDOK:
		case IDCANCEL:
			EndDialog(hWnd,LOWORD(wParam));
			return 1;
		case IDC_GENERATE:
			GetDlgItemTextA(hWnd,IDC_EDIT_NAME,name,32);
			if(strlen(name)<5)
				strcpy(code,"Lenght is too small");
			else
				generate();
			SetDlgItemTextA(hWnd,IDC_EDIT_NAME,name);
			SetDlgItemTextA(hWnd,IDC_EDIT_CODE,code);
			break;
		}
	}
	return 0;
}

int	WINAPI WinMain(HINSTANCE hInstance,HINSTANCE,LPSTR,int)
{
	InitCommonControls();
	DialogBoxParam(hInstance,MAKEINTRESOURCE(IDD_DIALOG),0,proc,0);
	return 0;
}
