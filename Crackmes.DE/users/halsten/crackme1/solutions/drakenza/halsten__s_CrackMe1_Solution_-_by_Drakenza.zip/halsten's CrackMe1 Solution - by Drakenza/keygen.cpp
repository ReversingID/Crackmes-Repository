#include <iostream>
#include <stdlib.h>

using namespace std;

int main(void) {
    char un[20];
    cout << "Welcome to Drakenza's Keygen for halsten's Crackme 1" << endl;
    cout << "Please enter username (<= 20 chars):";
    cin >> un;
    for(int i = 0; i < strlen(un); i++) {
            un[i]++;
    }
    cout << "Your serial is " << un << endl << endl;
    cout << "Thanks for using my keygen!";
    system("pause");
}
