#include <windows.h>
#include "resource.h"

#include <string>
#include <sstream>
using namespace std;

__declspec(naked) DWORD GetMagicNameHash(const char*const pcName)
{
	__asm
	{
		push    ebp
		mov     ebp, esp
		sub     esp, 4

		mov     eax, [ebp+8]
		lea     ecx, [eax+4]
		xor     edx, edx

loc_4051AF:
		add     dl, [ecx]
		inc     ecx
		cmp     byte ptr [ecx], 0
		jnz     loc_4051AF
		xor     ecx, ecx
		mov     cl, dl
		mov     ch, dl
		bswap   ecx
		mov     cl, dl
		mov     ch, dl
		mov     eax, [eax]
		xor     ecx, eax
		bswap   ecx
		add     ecx, 0x3022006
		bswap   ecx
		sub     ecx, 0x0DEADC0DE
		bswap   ecx
		inc     cl
		inc     ch
		bswap   ecx
		dec     cl
		dec     ch
		bswap   ecx

		xor     ecx, 0x0EDB88320
		bswap   ecx
		add     ecx, 0x0D76AA478
		bswap   ecx
		sub     ecx, 0x0B00BFACE
		bswap   ecx
		add     ecx, 0x0BADBEEF
		bswap   ecx
		inc     ecx
		bswap   ecx
		dec     ecx
		bswap   ecx
		add     ecx, eax
		bswap   ecx
		inc     cx
		bswap   ecx
		inc     cx
		bswap   ecx
		bswap   ecx
		mov     [ebp-4], ecx
		xor     edx, edx
		mov     ecx, [ebp-4]
		sub     cl, 0x0EF
		xor     cl, 0x0CD
		and     ecx, 0x0FF
		mov     edx, ecx
		shl     edx, 8
		mov     ecx, [ebp-4]
		shr     ecx, 8
		sub     cl, 0x0AB
		xor     cl, 0x90
		and     ecx, 0x0FF
		add     edx, ecx
		shl     edx, 8
		mov     ecx, [ebp-4]
		shr     ecx, 8
		shr     ecx, 8
		sub     cl, 0x78
		xor     cl, 0x56
		and     ecx, 0x0FF
		add     edx, ecx
		shl     edx, 8
		mov     ecx, [ebp-4]
		shr     ecx, 8
		shr     ecx, 8
		shr     ecx, 8
		sub     cl, 0x34
		xor     cl, 0x12
		and     ecx, 0x0FF
		add     edx, ecx
		bswap   edx
	}

	__asm
	{
		mov eax, edx

		add esp, 4
		pop ebp
		retn
	}
}

string GetKey(const string& sName)
{
	if(sName.length()<=5)
	{
		return "";
	}
	else
	{
		stringstream ssKey;
		ssKey << "STH-" << hex << uppercase << GetMagicNameHash(sName.c_str());
		return ssKey.str();
	}
}

BOOL CALLBACK EnumChildrenProc(HWND Child,pair<DWORD,HWND>*const pdwUserData)
{
	if(reinterpret_cast<DWORD>(GetMenu(Child))==pdwUserData->first)
	{
		pdwUserData->second=Child;
		return FALSE;
	}
	else
	{
		return TRUE;
	}
}

HWND FindChildWindow(const HWND& Parent,const DWORD& dwChildWindowID)
{
	pair<DWORD,HWND> dwUserData(dwChildWindowID,NULL);
	EnumChildWindows(Parent,
		reinterpret_cast<WNDENUMPROC>(EnumChildrenProc),
		reinterpret_cast<LPARAM>(&dwUserData));
	return dwUserData.second;
}

BOOL CALLBACK DlgProc(HWND Window,UINT Message,WPARAM WParam,LPARAM LParam)
{
	switch(Message)
	{
	case WM_INITDIALOG:
		SendDlgItemMessage(Window,IDC_NAME,EM_SETLIMITTEXT,32,0);
		SetDlgItemText(Window,IDC_NAME,"Trundle");
		break;

	case WM_COMMAND:
		switch(LOWORD(WParam))
		{
		case IDC_ABOUT:
			MessageBox(Window,
				"Solution to halsten's SomethingToHide by "
					"Christopher 'Trundle' Schmidt\n\n"
					"http://trundle.gamedev.de/",
				"Solution to halsten's SomethingToHide by Trundle",
				MB_OK);
			break;

		case IDC_EXIT:
			EndDialog(Window,0);
			break;

		case IDC_NAME:
			if(HIWORD(WParam)==EN_UPDATE)
			{
				char acName[32];
				GetDlgItemText(Window,IDC_NAME,acName,sizeof(acName));
				if(!GetKey(acName).length())
				{
					SetDlgItemText(Window,IDC_KEY,"[ERROR: Invalid name]");
					break;
				}
				
				SetDlgItemText(Window,IDC_KEY,GetKey(acName).c_str());
				if(FindWindow(NULL,"SomethingToHide"))
				{
					SendMessage(FindChildWindow(
							FindWindow(NULL,"SomethingToHide"),0x3E9),
						WM_SETTEXT,
						0,
						reinterpret_cast<LPARAM>(acName));
					SendMessage(FindChildWindow(
							FindWindow(NULL,"SomethingToHide"),0x3EA),
						WM_SETTEXT,
						0,
						reinterpret_cast<LPARAM>(GetKey(acName).c_str()));
				}
			}
			break;
		}
		break;

	case WM_CLOSE:
		EndDialog(Window,0);
		break;

	default:
		return FALSE;
	}

	return TRUE;
}

int WINAPI WinMain(HINSTANCE Instance,HINSTANCE,LPSTR,int iCmdShow)
{
	return DialogBox(Instance,MAKEINTRESOURCE(IDD_MAINDLG),NULL,DlgProc);
}