#include <windows.h>
#include <stdio.h>

#include "Blowfish.h"

const unsigned char szPW1[8]="spm**@-";
const unsigned char szPW2[12]="!_LIO)[]nn|";
const unsigned char bRipeMD[20]={0x5A,0xB3,0xAF,0x61,0x3B,0xFA,0x5A,0x14,0xA6,0x25,0x02,0xE1,0x7D,0x10,0xF4,0x59,0x62,0x73,0x9B,0x69};
const unsigned char bXorKey[4][5]={{0x69,0x6A,0x67,0x66,0x0F},{0x6B,0x73,0x0C,0x0D,0x10},{0x62,0x59,0x2F,0x24,0x19},{0x01,0x36,0x17,0x22,0x0E}};

void main(int argc,char**argv)
{
	printf("halsten's CryptoME1 solution\n");
	printf("by MR.HAANDI\n\n");
	
	FILE *f=fopen("halsten.sp","wb");

	srand(GetTickCount());
	unsigned char bData[0x80A]={};
	for (int i=1+5;i!=0x7FF+5;i++) bData[i]=rand() % 0x100;
	memcpy(bData+5+0x1BF,bRipeMD,20);

	BlowFish((unsigned char *)szPW2,11).Encrypt(bData+5,0x800);

	memcpy(bData,bXorKey[3],5);
	for (int i=0x7FF+5;i>=0+5;i--) bData[i]^=bData[i-5];

	memcpy(bData+0x800+5,bXorKey[2],5);
	for (int i=0+5;i!=0x800+5;i++) bData[i]^=bData[i+5];

	memcpy(bData,bXorKey[1],5);
	for (int i=0x7FF+5;i>=0+5;i--) bData[i]^=bData[i-5];

	memcpy(bData+0x800+5,bXorKey[0],5);
	for (int i=0+5;i!=0x800+5;i++) bData[i]^=bData[i+5];

	BlowFish((unsigned char *)szPW1,7).Encrypt(bData+5,0x800);

	fwrite(bData+5,1,0x800,f); fclose(f);
	
	printf("halsten.sp generated\n\n");
	system("PAUSE");
}