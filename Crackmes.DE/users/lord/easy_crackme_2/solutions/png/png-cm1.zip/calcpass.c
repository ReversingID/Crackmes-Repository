#include <stdio.h>
#include <stdlib.h>

int
main (int argc, char **argv)
{
  char foo[8] = "QTBXCTU";
  char bar[8] = "";
  int i;

  for (i = 0; i < 8; i++)
    bar[i] = (foo[i] ^ 0x21);

  bar[7] = '\0';

  printf ("encrypted: %s\ndecrypted: %s\n", foo, bar);

  return EXIT_SUCCESS;
}
