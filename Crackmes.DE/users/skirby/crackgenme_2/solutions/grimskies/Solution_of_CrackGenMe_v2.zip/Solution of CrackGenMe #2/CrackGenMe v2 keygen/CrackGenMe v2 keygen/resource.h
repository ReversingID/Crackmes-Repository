//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CrackGenMeV2keygen.rc
//
#define IDD_MAIN_DIALOG                 129
#define IDI_KIRBY_0                     134
#define IDI_KIRBY_1                     135
#define IDI_KIRBY_2                     136
#define IDI_KIRBY_3                     137
#define IDI_KIRBY_4                     138
#define IDI_KIRBY_5                     139
#define IDI_KIRBY_6                     140
#define IDI_KIRBY_7                     141
#define IDI_KIRBY_8                     142
#define IDI_KIRBY_9                     143
#define IDI_KIRBY_10                    144
#define IDI_KIRBY_11                    145
#define IDI_KIRBY_12                    146
#define IDI_KIRBY_13                    147
#define IDI_KIRBY_14                    148
#define IDI_KIRBY_15                    149
#define IDI_KIRBY_ICON                  150
#define IDC_USERNAME                    1001
#define IDC_SERIAL                      1002
#define IDC_KIRBYCODE_0                 1004
#define IDC_KIRBYCODE_1                 1005
#define IDC_KIRBYCODE_2                 1006
#define IDC_KIRBYCODE_3                 1007
#define IDC_KIRBYCODE_4                 1008
#define IDC_KIRBYCODE_5                 1009
#define IDC_KIRBYCODE_6                 1010
#define IDC_KIRBYCODE_7                 1011
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        151
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
