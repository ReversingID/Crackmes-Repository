#include "CrackGenMeV2keygen.h"

// Global Variables:
HINSTANCE hInst;								// current instance
HBRUSH bkBrush;									// background brush

extern "C" void wWinMainCRTStartup()
{
	hInst = GetModuleHandle(NULL);
	bkBrush = CreateSolidBrush(RGB(0, 0, 0));

	HWND hDialog = CreateDialog(hInst, 
								MAKEINTRESOURCE(IDD_MAIN_DIALOG), 
								0, 
								DialogProc);
	if(!hDialog) {
		return;
	}

	MSG msg;

	// Main message loop:
	while(GetMessage(&msg, NULL, 0, 0)) {
		if(!IsDialogMessage (hDialog, &msg)) {
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	DeleteObject(bkBrush);

	return ;
}

INT_PTR CALLBACK DialogProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	HDC hdc;
	HICON hIcon;

	switch(message) {
		case WM_INITDIALOG:
			hIcon = LoadIcon(hInst, MAKEINTRESOURCE(IDI_KIRBY_ICON));
			SendMessage(hDlg, WM_SETICON, WPARAM(ICON_SMALL), LPARAM(hIcon));
			SendMessage(hDlg, WM_SETICON, WPARAM(ICON_BIG), LPARAM(hIcon));

			SendMessage(GetDlgItem(hDlg, IDC_USERNAME), EM_SETLIMITTEXT, WPARAM(50), LPARAM(0));
			SendMessage(GetDlgItem(hDlg, IDC_SERIAL), EM_SETLIMITTEXT, WPARAM(50), LPARAM(0));
			SendMessage(GetDlgItem(hDlg, IDC_SERIAL), EM_SETREADONLY, WPARAM(TRUE), LPARAM(0));
			return (INT_PTR)TRUE;

		case WM_CTLCOLOREDIT:
		case WM_CTLCOLORMSGBOX:
		case WM_CTLCOLORBTN:
		case WM_CTLCOLORSTATIC:
			hdc = (HDC)wParam;
			SetTextColor(hdc, RGB(255, 255, 255));
			SetBkMode(hdc, TRANSPARENT);
			return (INT_PTR)bkBrush;

		case WM_CTLCOLORDLG:
			return (INT_PTR)bkBrush;

		case WM_COMMAND:
			if(LOWORD(wParam) == IDC_USERNAME && HIWORD(wParam) == EN_CHANGE) {
				onUsernameTextChanged(hDlg);
				return (INT_PTR)TRUE;
			}
			break;

		case WM_DESTROY:
			PostQuitMessage(0);
			return (INT_PTR)TRUE;

		case WM_CLOSE:
			DestroyWindow(hDlg);
			return (INT_PTR)TRUE;
	}
	return (INT_PTR)FALSE;
}

void onUsernameTextChanged(HWND hDlg)
{
	const int size = 50;
	char buffer[size];
	char username[size];
	char serial[size] = "KIRBY-";
	char alphabet[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	const int alphabetLength = 62;


	GetDlgItemText(hDlg, IDC_USERNAME, username, size);
	int length = strlen(username);

	if(length > 5) {
		unsigned int usernameValue = 0;

		for(int i = 1; i <= 0x32; ++i) {
			usernameValue = usernameValue * (i + length) + username[(i - 1) % length] * i;
		}

		bool serialFound = false;
		unsigned int counter;
		unsigned int currValue;

		for(int m = 2; !serialFound && m <= 30; m += 2) {
			buffer[m] = '\0';

			counter = m / 2 - 1;
			currValue = usernameValue;

			for(int i = m - 2; i >= 0; i -= 2) {
				int offset = 0;

				if(counter % 2 == 0) {
					offset = 0x11;
				} else {
					if(counter % 3 == 0) {
						offset = 0x31;
					}
				}

				for(int j = 0; j < alphabetLength; ++j) {
					for(int k = j; k < alphabetLength; ++k) {
						if((currValue - ((alphabet[j] + offset) ^ alphabet[k])) == 0) {
							serialFound = true;
							buffer[i] = alphabet[j];
							buffer[i + 1] = alphabet[k];
						}
					}
				}

				if(!serialFound) {
					unsigned int min = currValue;
					buffer[i] = '0';
					buffer[i + 1] = '0';

					for(int j = 0; j < alphabetLength; ++j) {
						for(int k = j; k < alphabetLength; ++k) {
							unsigned int possibleMin = currValue - ((alphabet[j] + offset) ^ alphabet[k]);

							if(possibleMin % 10 == 0) {
								possibleMin /= 10;

								if((possibleMin < min) && (possibleMin >= 0)) {
									buffer[i] = alphabet[j];
									buffer[i + 1] = alphabet[k];
									min = possibleMin;
								}
							}
						}
					}
				}

				currValue -= (buffer[i] + offset) ^ buffer[i + 1];
				currValue /= 10;

				--counter;
			}
		}

		if(!serialFound) {
			buffer[0] = '\0';
		} else {

			double doubleValue = 0.0;
			counter = 0;
			currValue = 0;

			for(int i = 0; i < strlen(buffer); i += 2) {
				doubleValue = (doubleValue + buffer[i + 1]) * buffer[i + 1] * counter;

				if(doubleValue > 1048575.0) {
					doubleValue /= 65535.0;
				}

				++counter;
			}

			sprintf_s(serial + 6, size - 6, "%s-%.0f", buffer, doubleValue * 10.0);
		}

		char firstControlString[] = "aLF3t5lfLdsYEzT34Fdsf63BqO10lM";
		char secondControlString[] = "1dh6NE7jrv4dJ2fAw95liO7bs2wbY58j4hYkL94dtNkIL2s5h7K9g1AXr4j0";
		
		int firstLength = strlen(firstControlString);
		int secondLength = strlen(secondControlString);

		int firstCounter = 0;
		int secondCounter = 0;

		unsigned int kirbyValue = 1;
		int loopLength = (length % 2 == 0) ? (length + 0xB) : (length + 0xA);

		for(int i = 0; i < loopLength; ++i) {
			if(firstCounter >= firstLength) {
				firstCounter %= 2;
			}

			if(secondCounter >= secondLength) {
				secondCounter %= 3;
			}
			
			unsigned int tmp = username[i % length] ^ firstControlString[firstCounter] ^ secondControlString[secondCounter];
			
			if(tmp == 0) {
				tmp = username[i % length];
			}

			kirbyValue += ~(tmp * kirbyValue * length);

			firstCounter += (i + 2);
			secondCounter += (firstCounter + 1);
		}

		for(int i = 0; i < 8; ++i) {
			unsigned int kirby = (kirbyValue >> (4 * (7 -i))) & 0xF;

			HICON hIcon = LoadIcon(hInst, MAKEINTRESOURCE(IDI_KIRBY_0 + kirby));
			SendMessage(GetDlgItem(hDlg, IDC_KIRBYCODE_0 + i), STM_SETIMAGE, WPARAM(IMAGE_ICON), LPARAM(hIcon));
		}

		SetDlgItemText(hDlg, IDC_SERIAL, serial);
	} else {
		SetDlgItemText(hDlg, IDC_SERIAL, "");
		for(int i = 0; i < 8; ++i) {
			SendMessage(GetDlgItem(hDlg, IDC_KIRBYCODE_0 + i), STM_SETIMAGE, WPARAM(IMAGE_ICON), LPARAM(NULL));
		}
	}
}

