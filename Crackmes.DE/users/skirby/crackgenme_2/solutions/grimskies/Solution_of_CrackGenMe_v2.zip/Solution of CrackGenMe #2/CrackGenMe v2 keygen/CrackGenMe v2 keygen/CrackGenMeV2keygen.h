#pragma once

#include "targetver.h"
#include "resource.h"

#define WIN32_EXTRA_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers

#include <windows.h>
#include <stdio.h>

INT_PTR CALLBACK DialogProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
void onUsernameTextChanged(HWND hDlg);
