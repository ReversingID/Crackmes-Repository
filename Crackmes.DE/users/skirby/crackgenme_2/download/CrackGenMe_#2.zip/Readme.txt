Hi everybody,

Here is my second challenge. The CrackGenme #2.
It was made for beginners but also for advanced crakers.

It is a little bit more difficule than previous one.

Goals:
- For warriors: make a keygen
- For good boys: find the activation code and the Kirby code for your name
- For slacker: display the success message

Peculiarities: No rule, you can do everything you want!!!

So, be without pity with my challenge.
I hope you will write a tuto if you find the solution.

Do not hesitate to ask me if you need more informations.


Skirby
