/*****************************************
Keygen for Bitpatcher's MY1ST crackme.

(Some parts of this code undoubtedly suck.)
******************************************/


#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include "Resource.h"

#define ID_EDIT    1
#define ID_EDIT_N  2
#define ID_EDIT_S1 3
#define ID_EDIT_S2 4
#define ID_EDIT_S3 5
#define ID_GENERATE  6
#define ID_TEXT1 7
#define ID_TEXT2 8


LRESULT CALLBACK WndProc (HWND, UINT, WPARAM, LPARAM) ;

    HWND hwndEditName;
    HWND hwndEditSerial1;
    HWND hwndEditSerial2;
    HWND hwndEditSerial3;
    HWND hwndButton;
    
    TCHAR text[30];
	HINSTANCE hInst;
	HDC hDC, MemDCBurst;



int GenerateKey(HWND hwnd) {
	
    #define RANGE1 10
	#define RANGE2 7
	#define RANGE3 1000
    
    char Name[80]="";
	char SerialPart1[16]="";
	char SerialPart2[8]="";
	char SerialPart3[4]="";
	char Cap[] = "Oops!";
	char err1[] = "Name must be at least 5 characters long.";
	
	int  part4, part1, part2, part3, part5;
	unsigned long int color;
	int X, Y;
	int i=0;
	int num=0x22;
	unsigned int digit;


	GetDlgItemText(hwnd,ID_EDIT_N,Name,80);
	if (strlen(Name) < 5) {
		MessageBox(NULL,err1,Cap,NULL);
		return 0;		
	}


	//Generating the first part of the serial

	while (RANGE3 <= (part4 = rand() / (RAND_MAX/RANGE3)));
	while (RANGE3 <= (part1 = rand() / (RAND_MAX/RANGE3)));

	X=part4;
	Y=part1;
	if (part4>300)
		X=part4-300*(part4/300);
	if (part1>65)
		Y=part1-65*(part1/65);

	 /** I have not put much thought into this part.
	     This crappy code is capable of making only
	     one set of triads for one RGB value, but there
	     could be much more. 
	 **/
	color=GetPixel(MemDCBurst, X, Y);
	part2=color/0x10000;
	part3=color-(color/0x100)*0x100;
	part5=(color/0x100)-((color/0x100)/0x100)*0x100;


	sprintf(SerialPart1, "%03d%03d%03d%03d%03d", part1, part2, part3, part4, part5);
	SetWindowText(hwndEditSerial1, SerialPart1);


	//Generating the second part of the serial
	while (RANGE1 <= (digit = rand() / (RAND_MAX/RANGE1)));


	while (i<7) {
		while (RANGE1 <= (digit = rand() / (RAND_MAX/RANGE1)));
		num-=digit;
		SerialPart2[i]=digit+0x30;
		i++;
	}
	
	while (num>0) {
		while (RANGE2 <= (i = rand() / (RAND_MAX/RANGE2)));
		if (SerialPart2[i]<0x39) { 
			SerialPart2[i]++;
			num--;
		}
	}
	while (num<0) {
		while (RANGE2 <= (i = rand() / (RAND_MAX/RANGE2)));
		if (SerialPart2[i]>0x30) { 
			SerialPart2[i]--;
			num++;
		}
	}

	SetWindowText(hwndEditSerial2, SerialPart2);
	

	//Generating the third part of the serial
	sprintf(SerialPart3, "%d", Name[2]-2);
	SetWindowText(hwndEditSerial3, SerialPart3);

	return 0;
}


int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    PSTR lpCmdLine, int iCmdShow)
{
     static TCHAR szAppName[] = TEXT ("KeyGen") ;
     HWND         hwnd ;
     MSG          msg ;
     WNDCLASS     wndclass ;
	 hInst       = hInstance;

     wndclass.style         = CS_HREDRAW | CS_VREDRAW ;
     wndclass.lpfnWndProc   = WndProc ;
     wndclass.cbClsExtra    = 0 ;
     wndclass.cbWndExtra    = 0 ;
     wndclass.hInstance     = hInstance ;
     wndclass.hIcon         = LoadIcon (NULL, IDI_APPLICATION) ;
     wndclass.hCursor       = LoadCursor (NULL, IDC_ARROW) ;
     wndclass.hbrBackground = (HBRUSH) GetStockObject (LTGRAY_BRUSH) ;
     wndclass.lpszMenuName  = NULL ;
     wndclass.lpszClassName = szAppName ;

     RegisterClass (&wndclass);


     hwnd = CreateWindow (szAppName,                  
                          TEXT ("KGen for Bitpatcher's MY1ST crackme"),
                          WS_CAPTION | WS_POPUPWINDOW | WS_MINIMIZEBOX, 
                          220,              
                          220,              
                          300,             
                          220,              
                          NULL,             
                          NULL,                     
                          hInstance,                 
                          NULL) ;                     
     
     ShowWindow (hwnd, iCmdShow) ;
     UpdateWindow (hwnd) ;
     
     while (GetMessage (&msg, NULL, 0, 0))
     {
          TranslateMessage (&msg) ;
          DispatchMessage (&msg) ;
     }
     return msg.wParam ;
}

LRESULT CALLBACK WndProc (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
     
    
    
    PAINTSTRUCT Ps;
    HBITMAP bmpBurst;


     switch (message)
     {
		case WM_CREATE:
		CreateWindow(TEXT("Static"), TEXT("Name"), WS_VISIBLE | WS_CHILD,
			    10, 70, 275, 17, hwnd, (HMENU) ID_TEXT1, NULL, NULL);
		hwndEditName = CreateWindow(TEXT("Edit"), NULL, WS_CHILD | WS_VISIBLE | WS_BORDER,
				10, 90, 150, 20, hwnd, (HMENU) ID_EDIT_N, NULL, NULL);
		CreateWindow(TEXT("Static"), TEXT("Serial"), WS_VISIBLE | WS_CHILD,
			    10, 115, 275, 17, hwnd, (HMENU) ID_TEXT2, NULL, NULL);
		hwndEditSerial1 = CreateWindow(TEXT("Edit"), NULL, WS_CHILD | WS_VISIBLE | WS_BORDER,
				10, 135, 133, 20, hwnd, (HMENU) ID_EDIT_S1, NULL, NULL);
		hwndEditSerial2 = CreateWindow(TEXT("Edit"), NULL, WS_CHILD | WS_VISIBLE | WS_BORDER,
				145, 135, 78, 20, hwnd, (HMENU) ID_EDIT_S2, NULL, NULL);
		hwndEditSerial3 = CreateWindow(TEXT("Edit"), NULL, WS_CHILD | WS_VISIBLE | WS_BORDER,
				225, 135, 60, 20, hwnd, (HMENU) ID_EDIT_S3, NULL, NULL);
		hwndButton = CreateWindow(TEXT("Button"), TEXT("Generate"), WS_VISIBLE | WS_CHILD,
				20, 165, 70, 22, hwnd, (HMENU) ID_GENERATE, NULL, NULL);
		CreateWindow(TEXT("Static"), TEXT("made by grooshenka"), WS_VISIBLE | WS_CHILD | WS_DISABLED,
			    157, 176, 200, 17, hwnd, NULL, NULL, NULL);
		break;



		case WM_PAINT:
	    hDC = BeginPaint(hwnd, &Ps);
	    
	    bmpBurst = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BURST));	    
	    MemDCBurst = CreateCompatibleDC(hDC);
        SelectObject(MemDCBurst, bmpBurst);	    
	    BitBlt(hDC, 0, 0, 300, 65, MemDCBurst, 0, 0, SRCCOPY);

	    EndPaint(hwnd, &Ps);

	    break;


    	case WM_COMMAND:	
		   switch(LOWORD(wParam))
			case ID_GENERATE:
				GenerateKey(hwnd);   
		break;
          
		case WM_DESTROY:
          PostQuitMessage (0) ;
          return 0 ;
     }
     return DefWindowProc (hwnd, message, wParam, lParam) ;
}
