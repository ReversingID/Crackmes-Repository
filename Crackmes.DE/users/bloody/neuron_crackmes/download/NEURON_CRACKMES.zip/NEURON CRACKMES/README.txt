				BLOODY PROUDLY PRESENTS NEW GENERATION OF CRACKMES :-)
				------------------------------------------------------

This crackmes uses artifical neuron network. That's all what can I say :-)
Okay, I'm joking now. Your task is to draw a sign and after that press 'r' (small r - without CAPSLOCK - pay attention on that). When sign is correct, congratulation will be shown, otherwise - message with bad sign.

To the file is connected file "weights.dat". YOU CAN NOT change him. Changing is equal to the patch and that is NOT ALLOWED !! (this file can be also into the file, but for more comfortable work for me, it is separately).

RULES:
------

NO PATCHING (changing files: "weights.dat" and "NEURON_CRACKMES.exe")
NO BRUTE FORCE

ONLY FAIR CRACKING.

Crackmes is considered cracked when short tutorial and correct sign (which will be tested by me) will be sent to me on e-mail address: RealNightWolf@wp.pl

And one thing is worth to say - there is no only one sign correct. The degree of recognizing is strongly dependent on learning process which I did. I tried to learn it in that way it recognize only one sign, but artifical neuron network are hard to predict.

ps.: I hope that there is one cracker who cracks it though...

And last words to newbie - do not try it... I think it is job for proffessional crackers... but maybe I am wrong :-))


GOOD LUCK GUYS !!



GREETINGS:
----------

To my love - EVA :-)
To VENETA
and all men trying this :-)



--------------
BLOODY. 

