# -*- coding: utf-8 -*-
import sys

class Cript():
	_buff = bytearray('\0'*64)
	
	MAGI = [0x10D88067, 0xBC16D3D5, 0xE7039A64, 0x39EC8A6D, 
			0xFF09B4BF, 0xF828DB76, 0x8BE40C8E, 0xF7AA583E, 
			0x60858E23, 0xE487F5A3, 0x39A57B89, 0xB006573E, 
			0x79609807, 0x620AD108, 0x5CD86398, 0x6CA94B51]
	
	def dump(self):
		prev = 0
		s = ''
				
		for i in range(16):
			b = self._buff[i*4:i*4+4]
	
			chunk = (b[0]+(b[1]<<8)+(b[2]<<16)+(b[3]<<24)) ^ self.MAGI[i] ^ prev
			prev = chunk
			
			s += '{0:08X}'.format(chunk)
		return s

	def _set_int(self, n, i):
		try:
			x = eval('0x'+n) & 0xFFFFFFFF
		except:
			x = 0x00
			
		i *= 4
		self._buff[i+0] = x>>(0*8) & 0xFF
		self._buff[i+1] = x>>(1*8) & 0xFF
		self._buff[i+2] = x>>(2*8) & 0xFF
		self._buff[i+3] = x>>(3*8) & 0xFF
		
	def set_name(self, name):
		name = name[:32]
		self._buff = name.ljust(32,'\0')+self._buff[32:]

	def set_sn(self, sn):
		self._set_int(sn, 8)		
		
	def set_featureset(self, fs):
		self._set_int(fs, 9)
	
	def set_expiration(self, ex):
		self._set_int(ex, 10)
		
	def calc_chksum(self):
		cs = 0
		for j in range(0x3c):
			cs = cs ^ self._buff[j] ^ 0xFFFFFFFF
			for i in range(1, 0x8+1):
				cs = (cs >> 1) ^ ((0x00 - (cs & 0x01)) & 0xEDB88320)
			cs = cs ^ 0xFFFFFFFF
			
		self._buff = self._buff[0:0x3c]
		self._buff.extend([(cs>>(j*8))&0xFF for j in range(4)])
		return cs	


if __name__=='__main__':
	print ":---------------------------------------------------------:"
	print ": It's keygen for Yonkie's keygenme#4 <dennis@conus.info> :"
	print ": ⓒ kercra 05/2016                                        :"
	print ":---------------------------------------------------------:"
	
	try:
		c = Cript()
		c.set_name(sys.argv[1])
		c.set_sn(sys.argv[2])
		c.set_featureset(sys.argv[3])
		c.set_expiration(sys.argv[4])
		c.calc_chksum()
		print 'key:', c.dump()
	except:
		print '  Usage: {0} [name] [sn] [featureset] [expiration]'.format(sys.argv[0])
		print 'Example: {0} "New name" 111 0eaf 01012017'.format(sys.argv[0])

