# -*- coding: utf-8 -*-

import subprocess
import os
import time


WORKDIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(WORKDIR)

KEYGENME = 'keygenme4.exe'
ARGKG = ['3EAFF710E1D856A675BEA1A94C374FEAB33EFB554B162023C0F22CAD3758749345E9ACC8A16EA66499CAFDFF29CCAAC150AC32C632A6E3CE6E7E8056F2C78CA3',
         '7BB6EF3EC7A0598220A3C3E6194F498BE646FD341E6E2642958A2ACC622072F202A5FCD0E622F68CDE86AD206E80FA1E17E0621975EAB3112932D089A0EEBA29',
         '63BDF520DFAB268138A8BCE501443688FE4D8237066559418D8155CF7A2B0DF11AAE83D0FE297671C68D2DEA768B7AD40FEBE2D36DE133DB3139504307C86027',
         '74B7EF20A3C249B944C1D3DD7D2D59B08224ED0F7A0C3679F1E83AF7064262C966C7EDEA82401746BAE64CDB0AE01BE5738083E2118A52EA4D523172338CA012']

TIMEOUT  = 1.0

SECSIZE  = 0x1a200
OFFSET   = 0x200
IMGBASE  = 0x400000
VA       = 0x1000

runFn    = os.path.join(WORKDIR, 'tmp.exe')
okFn     = os.path.join(WORKDIR, 'tmp-ok.exe')
buff     = bytearray(open(os.path.join(WORKDIR, KEYGENME),'rb').read())
txt      = open(os.path.join(WORKDIR, 'allincode.lst'), 'r')

cntT = 0
cnti = 0
cntF = 0
cnt  = 0
cnti = 0

TRYSIZE = 64

#----------------------------------------------------------------------------
class opcode():
    segm = ''
    addr = None
    code = []
    mnemonic = ''
    comment = ''
    __lenco = 3*8

    def __init__(self, s):
        s = s.partition(':')
        self.segm = s[0]
        s = s[2].partition(' ')
        self.addr = eval('0x'+s[0])
        self.code = s[2][:self.__lenco].strip().split(' ')
        self.code = [] if self.code[0]=='' else self.code
        s = s[2][self.__lenco:].strip().partition(';')
        self.mnemonic = s[0]
        self.comment = s[2]

    def __str__(self):
        s = '{0}:{1:08X} {2:{4}.{4}} {3}'.format(self.segm, self.addr, ' '.join(self.code), self.mnemonic, self.__lenco)
        if self.comment:
            s += self.comment
        return s+'\n'

#----------------------------------------------------------------------------
def chk_exe(ar):
    t1 = time.time()
    p = subprocess.Popen([runFn, ar],shell=False,stdout=subprocess.PIPE)
    r = p.poll()
    while r is None:
        if (time.time()-t1)>TIMEOUT:
            while (p.poll() is None):
                p.kill()
                time.sleep(0.8)
            r = None
            break
        time.sleep(0.1)
        r = p.poll()
    return p, r

#----------------------------------------------------------------------------
def rm_tmp(p):
    while os.path.isfile(runFn):
        try:
            os.remove(runFn)
        except Exception as err:
            p.kill()

#----------------------------------------------------------------------------
def print_rez(char):
    global beg, codes, cnt
    print char,
    cnt += 1
    if cnt%40==0:
            print (beg)*100/len(codes),'%'

#----------------------------------------------------------------------------
codes = []
for s in txt:
    if s.startswith('.text'):
        codes.append(s)
txt.close()

beg = 0
lenca = len(codes)
siz = TRYSIZE
t2 = time.time()

#----------------------------------------------------------------------------
run = open(runFn, 'wb')
run.write(buff)
run.close()

#----------------------------------------------------------------------------
ANSW = []
for a in ARGKG:
    p,r = chk_exe(a)
    ANSW.append(p.stdout.read())
rm_tmp(p)

#----------------------------------------------------------------------------
while beg<=lenca:
    while True:
        if siz == 0:
            siz = 1
        end = beg+siz
        if end>lenca:
            end = lenca

        rngco = codes[beg:end]
        oox = {}

        for s in rngco:
            o = opcode(s)
            if o.addr > 0x41B0D8:
                break
            if o.mnemonic == '':
                continue
            if len(o.code) == 0:
                continue
            if o.mnemonic.startswith('align'):
                continue
            if o.mnemonic[:3] in ['db ', 'dw ', 'dd ', 'dq ']:
                continue
            if o.code[0] in ['', '??', '90', 'C9']:		# ??, nop, leave
                continue
            i = o.addr -IMGBASE -VA +OFFSET
            t = []
            oox[i] = t
            for c in o.code:
                t.append(buff[i])
                buff[i] = 0x90
                i += 1

        if len(oox) == 0:
            beg += siz
            print_rez('-')
            break

        run = open(runFn, 'wb')
        run.write(buff)
#~        os.fsync(run)
        run.close()

        rezult = True
        for i,a in enumerate(ARGKG):
            p,r = chk_exe(a)
            if (r is None) or (r<>20) or p.stdout.read()<>ANSW[i]:	#len(p.stdout.readlines())<>5:
                rezult = False
                break
        rm_tmp(p)

        if rezult:
            print_rez('+')
            for s in rngco:
                o = opcode(s)
                if oox.has_key(o.addr -IMGBASE -VA +OFFSET):
                    o.code = ['90' for c in o.code]
                    o.mnemonic = ''
                    codes[beg] = str(o)
                beg += 1
                cntT += 1   #len(o.code)

            okf = open(okFn, 'wb')
            okf.write(buff)
            okf.close()
            siz = siz * 2
            if siz >TRYSIZE:
                siz = TRYSIZE
            break
        else:
            for i in oox:
                t = oox[i]
                for c in t:
                    buff[i] = c
                    i += 1
            if siz>1:
                print_rez('*')
                siz = siz / 2
                continue
            else:
                print_rez('.')
                cntF += 1   #len(o.code)
                beg += 1
                break

#----------------------------------------------------------------------------
print ''
print cntT, cntF
print '{0:3.0f}% {1:3.0f}%'.format(cntT*100.0/len(codes), cntF*100.0/len(codes))

#----------------------------------------------------------------------------
cle = open(os.path.join(WORKDIR, 'purecode.lst'), 'w')
for s in codes:
    o = opcode(s)
    cle.write(str(o))
cle.close()
print 'time:', time.time()-t2, 's'

#30260 1640
# 94%   5%
#time: 4197.42199993 s
