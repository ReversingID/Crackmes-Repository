#include <stdio.h>
#include <stdint.h>
#include <ctype.h>
#include <string.h>

#include "aes.h"
#include "rdtsc.h"

#define BLOCK_LEN   16

#define OK           0
#define READ_ERROR  -7
#define WRITE_ERROR -8

extern int sub_401000( int namelen,char *name);

void KeyGen (unsigned char *ubName, 
             signed char sbNameLen,
	     signed long slSerialNumber,
	     signed long slFeatures)
{
    aes_encrypt_ctx ctx;
    int key_len,i;
    signed long slEncoded , slCrc , slSalto , slMagic , slTemp ;
    signed char found ;
    unsigned char ubPtext[32] , ubEtext[32] , ubKey[32];
    char key[32]={0xE9,0x3F,0x0D,0xA1,0x96,0x95,0x31,0x04,
                  0x49,0x2D,0x9E,0x61,0x83,0xCF,0x09,0x6F};

    key_len = 128; 
    aes_encrypt_key((unsigned char*)key, key_len, &ctx);

    memset(ubPtext,0x0,(sizeof(unsigned char)*32));

    slEncoded = sub_401000((long)sbNameLen,ubName);
    memcpy(ubPtext, &slEncoded, (sizeof(signed long)*1));

    /* Assign features */
    ubPtext[5] =(slFeatures>>8)&0xff;
    ubPtext[4] =(slFeatures)&0xff;

    /*Magic number. hardwired in the code*/
    ubPtext[6] =0x79;
    ubPtext[7] =0x19;

    /* update serial number*/
    memcpy(ubPtext+8, &slSerialNumber, sizeof(slSerialNumber));
    
    slSalto = 0;
    found = 0;
    while (found == 0) {
      memcpy(ubPtext+12, &slSalto, sizeof(slSalto));
      memset(ubEtext,0x0,(sizeof(unsigned char)*32));
      aes_encrypt(ubPtext, ubEtext, &ctx);
      slCrc = (ubEtext[14]<<8) + (ubEtext[15]); 
      slTemp =0;
      for (i=0;i<12;i++)
        slTemp = slTemp + ubEtext[i];
      
      if (slTemp == slCrc) {
        found = 1;	
      } else {
       slSalto = slSalto + 1; 
      }    
    }

    memset(ubKey,0,(sizeof(unsigned char)*32));
    for (i=0;i<16;i++) 
      sprintf(ubKey,"%s%02X", ubKey,ubEtext[i]);

    /*display result*/
    printf("# License file for Yonkie's CrackMe#2\n");
    printf("# Licensed name %s\n", ubName);
    printf("# feature flags %08X\n",slFeatures);
    printf("# serial number %X\n",slSerialNumber);
    printf("\n");    
    printf("N=%s K=%s\n",ubName,ubKey);
}



int main(void)
{
    KeyGen("Alejandra",9,0x12345678,0xabcd);   
    return 0;
}
