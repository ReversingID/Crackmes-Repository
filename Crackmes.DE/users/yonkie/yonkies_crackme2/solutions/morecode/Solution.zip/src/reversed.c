#include <stdio.h>
#include <stdint.h>
#include <ctype.h>
#include <string.h>

#include "aes.h"
#include "rdtsc.h"

#define BLOCK_LEN   16

#define OK           0
#define READ_ERROR  -7
#define WRITE_ERROR -8

extern int sub_401000( int namelen,char *name);

void Reversing (unsigned char *Key,
                unsigned char *ubName, 
                signed char sbNameLen)
{
    aes_decrypt_ctx dtx;
    int key_len,i,jj;
    signed long slEncoded , slFeatures;
    signed long slSerialNumber , slCrc;
    unsigned char ubPtext[32];
    unsigned char ubEtext[32];
    char PseudoRand[32]={0xE9,0x3F,0x0D,0xA1,0x96,0x95,0x31,0x04,
                         0x49,0x2D,0x9E,0x61,0x83,0xCF,0x09,0x6F};

    for (i=0;i<16; i=i+1)     /*hex string to byte array (List.1)*/
      sscanf(&(Key[2*i]),"%2hhx",&(ubEtext[i]));

    slCrc = 0;
    for (i=0;i<12;i++)       /*12  bytes crc calculation (List.2)*/
      slCrc=slCrc+ ubEtext[i];
    
    if (slCrc ==  (ubEtext[14]<<8)+(ubEtext[15])) 
    {  
      key_len = 128; /*AES key expansion and decrypt.(List.4 & 5)*/
      aes_decrypt_key((unsigned char*)PseudoRand, key_len, &dtx);
      aes_decrypt(ubEtext, ubPtext, &dtx);

      slEncoded = (ubPtext[3]<<24) |
                  (ubPtext[2]<<16) |
                  (ubPtext[1]<<8)  | 
                  (ubPtext[0]<<0);

      if (sub_401000(sbNameLen,ubName) == slEncoded)
      { /*Name's transformation and verification (List.6)*/
        if ((ubPtext[6]==0x79) && (ubPtext[7]==0x19))
        { /*Magic number verification (List.7)*/
           slFeatures = (ubPtext[5]<<8) | (ubPtext[4]);
           slSerialNumber = (ubPtext[11]<<24) |
                            (ubPtext[10]<<16) |
                            (ubPtext[9]<<8)  | 
                            (ubPtext[8]<<0);

           /*display result*/
           printf("Transformed name %X\n", slEncoded);
           printf("Serial number %X\n",slSerialNumber);
           printf("Feature flags %08X\n",slFeatures);
           for (i=0;i<16;i++) {
             if ((slFeatures&0x1) == 1) {
                printf("Feature [%d] is ON \n",i);
             } else {
                printf("Feature [%d] is OFF\n",i);      
             }
             slFeatures = (slFeatures>>1)&0xffff;
           }
        }
      }    
   }
}


int main(void)
{
    Reversing("6715076D988BB82C55AF259C580204BC", "Alejandra",9);
    return 0;
}

