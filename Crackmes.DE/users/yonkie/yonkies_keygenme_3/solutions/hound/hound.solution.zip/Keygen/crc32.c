#include "crc32.h"

uint32 g_crcTable[256];

uint32 crc32 (unsigned char *block, unsigned int length)
{
	register unsigned long crc;
	unsigned long i;

	crc = 0xFFFFFFFF;
	
	for (i = 0; i < length; i++)
	{
		crc = ((crc >> 8) & 0x00FFFFFF) ^ g_crcTable[(crc ^ *block++) & 0xFF];
	}
	
	return (crc ^ 0xFFFFFFFF);
}

void crc32_init()
{
	unsigned long crc, poly;
	int i, j;

	poly = 0xEDB88320L;

	for (i = 0; i < 256; i++)
	{
		crc = i;
		for (j = 8; j > 0; j--)
		{
			if (crc & 1)
			{
			crc = (crc >> 1) ^ poly;
			}
			else
			{
			crc >>= 1;
			}
		}
		g_crcTable[i] = crc;
	}
}