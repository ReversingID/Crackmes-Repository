#include <stdio.h>
#include <windows.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "crc32.h"

HANDLE g_mtxGlobalVariables;
HANDLE g_eventAllWorkersFinished;
BOOL g_fValidKeyFound, g_fExit;
DWORD g_dwActiveThreadCount;
DWORD g_aKey[4];

typedef struct _CTX
{
	DWORD aKey[4];
	DWORD aInput[2];
	DWORD dwThreadNumber;
} CTX;

__forceinline DWORD EncryptXTEA(DWORD aKey[4], DWORD aIn[2], DWORD aOut[2])
{
	DWORD dwSum = 0, dwValue0 = aIn[0], dwValue1 = aIn[1];
	unsigned int i = 0;
	
	do
	{
		dwValue0 += (((dwValue1 << 4) ^ (dwValue1 >> 5)) + dwValue1) ^ (aKey[dwSum & 0x3] + dwSum);
		dwSum += 0xBADF00D;
		dwValue1 += (((dwValue0 << 4) ^ (dwValue0 >> 5)) + dwValue0) ^ (aKey[(dwSum >> 0xB) & 0x3] + dwSum);
		
		i++;
	} while (i < 0x45);
	
	aOut[0] = dwValue0;
	aOut[1] = dwValue1;
	
	return dwValue0;
}

__forceinline DWORD GenerateRand()
{
	return ((DWORD)rand() << 18) ^ ((DWORD)rand() << 9) ^ ((DWORD)rand());
}

DWORD WINAPI SolverThread(LPVOID lpParameter)
{
	DWORD aKey[4], aInput[2], aOutput[2], dwTarget;
	DWORD j,jPrev;
	DWORD dwActiveThreadCount;
	
	/* Setup aKey and aInput */
	CTX * pCtx = (CTX *)lpParameter;
	DWORD dwThreadNumber = pCtx->dwThreadNumber;
	memcpy(aKey,pCtx->aKey,sizeof(aKey));
	memcpy(aInput,pCtx->aInput,sizeof(aInput));
	
	/* Free the context memory */
	free(pCtx);
	
	/* Set thread priority */
	SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_HIGHEST);
	
	/* Start brute force */
	for (;;)
	{
		aKey[0] = GenerateRand();
		dwTarget = aKey[0];
		j = 0;
		
		do
		{
			/* Set aKey[2] */
			aKey[2] = j;
			
			/* Do XTEA */
			if (dwTarget == EncryptXTEA(aKey,aInput,aOutput))
			{
				WaitForSingleObject(g_mtxGlobalVariables, INFINITE);
				
				/* Load key into global variable */
				memcpy(g_aKey,aKey,sizeof(aKey));
				
				/* Signal other worker threads to exit */
				g_fValidKeyFound = TRUE;
				g_fExit = TRUE;
				dwActiveThreadCount = --g_dwActiveThreadCount;
				
				ReleaseMutex(g_mtxGlobalVariables);
				
				if (!dwActiveThreadCount)
					SetEvent(g_eventAllWorkersFinished);
				
				return TRUE;
			}
			
			/* Every so often, check whether the thread should exit */
			if ((j % 0xFFFFF) == 0)
			{
				if (g_fExit)
				{
					WaitForSingleObject(g_mtxGlobalVariables, INFINITE);
					dwActiveThreadCount = --g_dwActiveThreadCount;
					ReleaseMutex(g_mtxGlobalVariables);
					
					if (!dwActiveThreadCount)
						SetEvent(g_eventAllWorkersFinished);
					
					return FALSE;
				}
			}	
			
			jPrev = j;
			j++;
			
		} while (j > jPrev);
	} 
	
	/* Report failure */
	/* NOTE: Should never reach here */
	WaitForSingleObject(g_mtxGlobalVariables, INFINITE);
	printf("[X] Key not found\n");
	dwActiveThreadCount = --g_dwActiveThreadCount;
	ReleaseMutex(g_mtxGlobalVariables);
	
	if (!dwActiveThreadCount)
		SetEvent(g_eventAllWorkersFinished);
						
	return FALSE;
}
	
DWORD GetNumberOfProcessors()
{
	SYSTEM_INFO si;	
	GetSystemInfo(&si);
	return si.dwNumberOfProcessors;
}
	
void FindXTEAKey(DWORD dwSerialNumber, DWORD aKey[4])
{
	DWORD dwNumberOfProcessors, i;
	CTX ctx;
	SYSTEMTIME st;
	
	/* Seed random number generator */
	srand(GetTickCount());
	RAND_MAX;
	
	/* Initialise global variable(s) */
	g_fValidKeyFound = FALSE;
	g_dwActiveThreadCount = 0;
	g_mtxGlobalVariables = CreateMutex(NULL,FALSE,NULL);
	g_eventAllWorkersFinished = CreateEvent(NULL,TRUE, FALSE, NULL);
	
	/* Get the number of processors */
	dwNumberOfProcessors = GetNumberOfProcessors();
	
	/* Setup the ctx */
	memset(&ctx,0,sizeof(ctx));
	
	ctx.aKey[1] = GenerateRand();
	ctx.aKey[3] = GenerateRand();
	
	ctx.aInput[0] = 0x7369676E; /* Magic number */
	ctx.aInput[1] = dwSerialNumber; /* Desired serial number */
	
	/* Start when ready */
	printf("> Press <Enter> to start search for XTEA key (this may take a while) ... ");
	getchar();
	
	/* Output the start time */
	GetLocalTime(&st);
	printf("Starting search at %02d:%02d:%02d.%03d\n",
		st.wHour, st.wMinute, st.wSecond, st.wMilliseconds);
		
	/* Raise process priority */
	// SetPriorityClass(GetCurrentProcess(), HIGH_PRIORITY_CLASS);
	
	/* Start each solver thread */
	g_dwActiveThreadCount = dwNumberOfProcessors;
	
	for (i=0; i<dwNumberOfProcessors; i++)
	{
		CTX * pCtx = malloc(sizeof(CTX));
		ctx.dwThreadNumber = i;
		memcpy(pCtx,&ctx,sizeof(CTX));
		
		CreateThread(NULL,0,SolverThread,pCtx,0,NULL);
	}
	
	/* Wait for the threads to start */
	Sleep(1000);
	
	/* Wait until the solver threads finish */
	printf("Waiting for solver threads to finish ...\n");
	WaitForSingleObject(g_eventAllWorkersFinished,INFINITE);
	
	/* Output the end time */
	GetLocalTime(&st);
	printf("Search finished at %02d:%02d:%02d.%03d\n",
		st.wHour, st.wMinute, st.wSecond, st.wMilliseconds);
		
	/* Cleanup */
	CloseHandle(g_eventAllWorkersFinished);
	CloseHandle(g_mtxGlobalVariables);
	
	/* Store return key */
	memcpy(aKey,g_aKey,sizeof(g_aKey));
	
	return;
}

int main()
{
	DWORD aKey[4]; // = {0x23456789, 0, 0xABCDEF01, (DWORD)(-1820123470)};
	
	DWORD dwSerialNumber = 0;
	DWORD dwFeatureSet = 0xFFFFFFFF;
	CHAR szNamePtr[128];
	CHAR szName [17];
	
	DWORD dwSerialEncryption[2];
	DWORD dwFeatureSetEncryption[2];
	DWORD dwNameEncrypted[4];
	DWORD dwCRCChecksum;
	DWORD aOutputKeys[4];
	
	HANDLE hFile;
	DWORD dwBytesWritten;
	
	/* Get desired serial, featureset, and name */
	printf("%% Keyfile generator by hound for Yonki's Keygenme 3\n");
	printf("%% Compiled %s\n",__TIMESTAMP__);
		
	printf("> Enter desired serial number (decimal): ");
	scanf("%d",&dwSerialNumber); getchar();
	printf("> Enter desired feature set number (hex): ");
	scanf("%x",&dwFeatureSet); getchar();
	printf("> Enter name (max 16 characters): ");
	scanf("%s",szNamePtr); getchar();
	
	/* Find keys for encryption */
	printf("Searching for XTEA keys ...\n");

	FindXTEAKey(dwSerialNumber,aKey);
	
	printf("Key: %08X %08X %08X %08X\n", aKey[0], aKey[1], aKey[2], aKey[3]);
	
	/* Setup name */
	memset(szName,' ',sizeof(szName));
	szName[16] = 0;
	memcpy(szName,szNamePtr,strlen(szNamePtr) < 16 ? strlen(szNamePtr) : 16);
	
	/* Encrypt serial */
	dwSerialEncryption[0] = 0x7369676E; /* Fixed constant */
	dwSerialEncryption[1] = dwSerialNumber;
	
	EncryptXTEA(aKey,dwSerialEncryption,dwSerialEncryption);
	printf("Serial Encrypted: %08X %08X\n", dwSerialEncryption[0],
		dwSerialEncryption[1]);
		
	/* Calculate the CRC32 checksum on the name */
	crc32_init();
	dwCRCChecksum = crc32(szName,16);
	printf("Checksum of padded name: %08X\n", dwCRCChecksum);
	
	/* Encrypt the featureset with the checksum */
	dwFeatureSetEncryption[0] = dwFeatureSet;
	dwFeatureSetEncryption[1] = dwCRCChecksum;
	
	EncryptXTEA(aKey,dwFeatureSetEncryption,dwFeatureSetEncryption);
	printf("Feature set and checksum encrypted: %08X %08X\n", dwFeatureSetEncryption[0],
		dwFeatureSetEncryption[1]);
		
	/* Encrypt the name */
	dwNameEncrypted[0] = *(DWORD *)&szName[0];
	dwNameEncrypted[1] = *(DWORD *)&szName[4];
	dwNameEncrypted[2] = *(DWORD *)&szName[8];
	dwNameEncrypted[3] = *(DWORD *)&szName[12];
	
	EncryptXTEA(aKey,&dwNameEncrypted[0], &dwNameEncrypted[0]);
	EncryptXTEA(aKey,&dwNameEncrypted[2], &dwNameEncrypted[2]);
	
	printf("Encrypted name: %08X %08X %08X %08X\n",
		dwNameEncrypted[0],
		dwNameEncrypted[1],
		dwNameEncrypted[2],
		dwNameEncrypted[3]);
		
	/* Setup output keys */
	aOutputKeys[0] = aKey[1];
	aOutputKeys[1] = aKey[2];
	aOutputKeys[2] = aKey[3];
	aOutputKeys[3] = aKey[0];
	
	/* Write the keyfile */
	printf("Saving keyfile.dat ... ");
	
	hFile = CreateFile("keyfile.dat",
		GENERIC_WRITE,
		0,
		NULL,
		CREATE_ALWAYS,
		FILE_ATTRIBUTE_NORMAL,
		NULL);
		
	WriteFile(hFile,
		aOutputKeys,
		sizeof(aOutputKeys),
		&dwBytesWritten,
		NULL);
		
	WriteFile(hFile,
		&dwSerialEncryption[1],
		sizeof(DWORD),
		&dwBytesWritten,
		NULL);

	WriteFile(hFile,
		dwFeatureSetEncryption,
		sizeof(dwFeatureSetEncryption),
		&dwBytesWritten,
		NULL);
		
	WriteFile(hFile,
		dwNameEncrypted,
		sizeof(dwNameEncrypted),
		&dwBytesWritten,
		NULL);
		
	CloseHandle(hFile);
	
	printf("DONE\n");
	printf("> Press <Enter> to exit ");
	getchar();
	
	return 0;
}
	
	
	
	