#ifndef CRC32_H
#define CRC32_H

typedef unsigned long uint32;

uint32 crc32(unsigned char * block, unsigned int length);
void crc32_init();

#endif