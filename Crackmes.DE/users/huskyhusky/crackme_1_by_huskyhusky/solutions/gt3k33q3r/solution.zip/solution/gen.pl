#!/usr/bin/perl
#
# 2016, saucec0de
#
use warnings;
use strict;

my $minCH = 'e';
my $maxCH = 'l';

################################################################################

# func_2
sub genPattern {
    my $r9 = $_[0];
    my $r10 = int( $r9 / 2 );
    my $r12;
    
    for my $i (0..19) {
        $r12 = int( $r9 / $r10 );
        $r10 = int( ($r10 + $r12) / 2 );
    }
    $r10;
}

# func_1
sub nextCoeff {
    my $r9  = $_[0];
    my $r12;
    my $r11;
    
  loop1:
    $r9++;
    $r11 = 2;
    $r12 = genPattern ($r9);
  loop2:
    if ( 0 == ($r9 % $r11) ) { goto loop1; };
    $r11++;
    if ( $r12 > $r11 ) { goto loop2 };
    $r9;
}

sub testPassword {
    my $passwd   = $_[0];
    my $r9       = 1;
    my $checksum = 0;

    foreach my $c (split //,$passwd) {
        $r9 = nextCoeff($r9);

        $checksum += $r9*ord($c);
    }
    #$checksum == 0x125e6;
    $checksum;
}

sub minTest {
    my $test = 0;
    my $pw   = "";
    my $ch   = $_[0];

    while ($test==0) {
        $pw .= $ch;
        if ( testPassword($pw) > 0x125e6 ){
            return length($pw);
            $test = 1;
        }
    }
}

sub fisher_yates_shuffle {
    my $array = shift;
    my $i;
    for ($i = @$array; --$i; ) {
        my $j = int rand ($i+1);
        next if $i == $j;
        @$array[$i,$j] = @$array[$j,$i];
    }
}

my $L1 = minTest ($minCH);
my $L2 = minTest ($maxCH);
my $LEN;

for my $i ($L2 .. $L1) {
    my $tryStr;
    
    $tryStr = $minCH x $i;
    if ( testPassword($tryStr) > 0x125e6 ) {
        print "ERROR: ranges too short\n";
        exit;
    }
    $tryStr = $maxCH x $i;
    if ( testPassword($tryStr) < 0x125e6 ) {
        print "ERROR: ranges too short\n";
        exit;
    }
    $LEN = $i;
    last;
}

print "Generating Coefficients: ...\n";

my @coeff;
my $r9 = 1;
for my $i (0..$LEN) {
    $r9        = nextCoeff ($r9);
    $coeff[$i] = $r9;
}

# define a random starting point
my $PASS = "";
my $w = ord($maxCH) - ord($minCH) + 1;
for my $i (0..$LEN-1) {
    $PASS .= chr( ord($minCH) + rand($w) );
}
my $CHK  = testPassword($PASS);
print "Initial guess: $PASS, CHK=$CHK\n";
if ($CHK==0x125e6) {
    printf "Lucky guess!\n";
    print "WINNER: $PASS :: ", testPassword($PASS) . "\n\n";
    exit;
}

print "Lets go...\n";

my @IDX = 0..length($PASS)-1;
fisher_yates_shuffle (\@IDX);

for my $loocnt (0..5) {
    #for_loop: for my $i (0..length($PASS)-1) {
  for_loop: for my $i (@IDX) {
    repeat:
      my $idx    = length($PASS) - $i - 1;
      my @tmpStr = split //, $PASS;
      my $tmpChr = $tmpStr[$idx];
      my $hi     = $maxCH;
      my $lo     = $minCH;
      my $nx;
      my $ck;
      my $tmpPass;

      if (ord($tmpChr)==ord($minCH)) {
          next for_loop;
      }
    next_char:
      $nx           = chr( (ord($hi) + ord($lo)) / 2 );
      $tmpStr[$idx] = $nx;
      $tmpPass      = join "", @tmpStr;
      $ck           = testPassword($tmpPass);

      for my $n (0..length($PASS)-1) {
          # test to see if I can adjust the string to match in a single stoke
          # this should be a very fast test...
          my $distance = abs(0x125e6 - $ck);
          if ( ($distance % $coeff[$n]) == 0 ) {
              # maybe it is possible to adjust... lets try it...
              my @A = split //, $tmpPass;
              my $v = $A[$n];
              if ($ck > 0x125e6) {
                  # i have to lower the value...
                  # how much can I lower?
                  my $howMuch = (ord($v) - ord($minCH))*$coeff[$n];
                  if ( $howMuch > $distance ) {
                      # Winner winner... chicken dinner!
                      # Perform Adjustment... :-)
                      my $adj = $distance / $coeff[$n];
                      $A[$n] = chr( ord($v) - $adj );
                      $PASS = join "", @A;
                      print "WINNER: $PASS :: ", testPassword($PASS) . "\n\n";
                      exit;
                  }
              } else {
                  my $howMuch = (ord($maxCH) - ord($v))*$coeff[$n];
                  if ( $howMuch > $distance ) {
                      # Winner winner... chicken dinner!
                      # Perform Adjustment... :-)
                      my $adj = $distance / $coeff[$n];
                      $A[$n] = chr( ord($v) + $adj );
                      $PASS = join "", @A;
                      print "WINNER: $PASS :: ", testPassword($PASS) . "\n\n";
                      exit;
                  }
              }
          }
      }

      my $d = 0x125e6 - $ck;
      if (ord($nx)==ord($lo)) {
          $PASS = $tmpPass;
          next for_loop;
      }
      if ($ck == 0x125e6) {
	  print "WINNER: $PASS :: ", testPassword($PASS) . "\n\n";
          exit;
      }
      if ($ck < 0x125e6) {
          $lo = $nx;
      } else {
          $hi = $nx;
      }
      goto next_char;
  }
}
print "Bummer!... could not find a password :-(\n";
