#!/usr/bin/python

import struct

code = '\x00\x00\x00\x00\x22\x00\x20\x02\x0A\x00\xC0\x31\x11\x00\xC0\x31\x07\x00\x20\x25\x44\x00\x20\x02\x08\x00\x00\x20\x3C\x00\x20\x02\x0A\x00\xC0\x31\x0B\x00\xC0\x70\x00\x00\xC2\x33\x00\x00\x49\x02\x07\x00\x40\x04\x01\x00\x20\x11\x0B\x00\x40\x25\x00\x00\xC2\x34\x00\x00\xC0\x32\x00\x00\xC2\x33\x00\x00\xC3\x33\x00\x00\x60\x02\x98\x3A\x60\x12\x01\x00\x20\x02\x06\x00\x40\x03\x0A\x00\x40\x1F\x1D\x00\x00\x28\x64\x00\xC0\x31\x00\x00\x41\x13\x00\x00\x62\x11\x16\x00\x00\x20\x00\x00\x23\x02\x4E\xEB\x20\x12\x00\x00\xC3\x34\x00\x00\xC2\x34\x00\x00\xC0\x32\x50\x00\x00\x00\x6C\x00\x00\x00\x65\x00\x00\x00\x61\x00\x00\x00\x73\x00\x00\x00\x65\x00\x00\x00\x20\x00\x00\x00\x65\x00\x00\x00\x6E\x00\x00\x00\x74\x00\x00\x00\x65\x00\x00\x00\x72\x00\x00\x00\x20\x00\x00\x00\x61\x00\x00\x00\x20\x00\x00\x00\x70\x00\x00\x00\x61\x00\x00\x00\x73\x00\x00\x00\x73\x00\x00\x00\x77\x00\x00\x00\x6F\x00\x00\x00\x72\x00\x00\x00\x64\x00\x00\x00\x3A\x00\x00\x00\x20\x00\x00\x00\x00\x00\x00\x00\x57\x00\x00\x00\x72\x00\x00\x00\x6F\x00\x00\x00\x6E\x00\x00\x00\x67\x00\x00\x00\x21\x00\x00\x00\x0A\x00\x00\x00\x00\x00\x00\x00\x43\x00\x00\x00\x6F\x00\x00\x00\x72\x00\x00\x00\x72\x00\x00\x00\x65\x00\x00\x00\x63\x00\x00\x00\x74\x00\x00\x00\x21\x00\x00\x00\x20\x00\x00\x00\x3D\x00\x00\x00\x29\x00\x00\x00\x0A\x00\x00\x00\x00\x00\x00\x00\x00\x00\xC4\x33\x00\x00\xC3\x33\x00\x00\xC2\x33\x00\x00\x41\x02\x01\x00\x40\x1A\x00\x00\x00\x02\x01\x00\x00\x11\x00\x00\x62\x02\x00\x00\x81\x02\x00\x00\x82\x14\x00\x00\x44\x11\x01\x00\x40\x1A\x14\x00\x00\x1F\x57\x00\x00\x27\x00\x00\x22\x02\x00\x00\xC2\x34\x00\x00\xC3\x34\x00\x00\xC4\x34\x00\x00\xC0\x32\x00\x00\xC5\x33\x00\x00\xC4\x33\x00\x00\xC3\x33\x00\x00\xC2\x33\x01\x00\x20\x11\x00\x00\x41\x02\x51\x00\xC0\x31\x00\x00\x81\x02\x00\x00\x22\x02\x02\x00\x60\x02\x01\x00\x40\x02\x00\x00\xA1\x02\x00\x00\xA3\x15\x00\x00\x45\x13\x00\x00\x40\x1F\x68\x00\x00\x28\x01\x00\x60\x11\x00\x00\x83\x1F\x6F\x00\x00\x29\x00\x00\xC2\x34\x00\x00\xC3\x34\x00\x00\xC4\x34\x00\x00\xC5\x34\x00\x00\xC0\x32'

def disasm(token):
    d = token & 0xFFFF
    a = token >> 0x10
    b = a >> 8
    i1 = (a >> 5) & 7
    i2 = a & 7
    f1 = a & 0x10
    f2 = a & 8
    
    if i2 == 0:
        op2 = '0x%X' % d
    elif d == 0:
        op2 = 'r%dd' % (i2 + 8)
    else:
        op2 = 'r%dd + 0x%X' % (i2 + 8, d)
    
    if f1 != 0:
        op2 = '[[' + op2 + ']]'
    elif f2 != 0:
        op2 = '[' + op2 + ']'
    
    op1 = 'r%dd' % (i1 + 8)
    
    inst = get_inst(b, op1, op2)
    if '%d' in inst:
        inst = inst % (i2 + 8)
    
    return inst

def get_inst(b, op1, op2):
    tmp = 'esi'
    
    if b == 2:
        inst = 'mov %s, %s' % (op1, op2)
    elif b == 3:
        inst = 'gchr %s' % op1
    elif b == 4:
        inst = 'pchr %s' % op1
    elif b == 17:
        inst = 'add %s, %s' % (op1, op2)
    elif b == 18:
        inst = 'sub %s, %s' % (op1, op2)
    elif b == 19:
        inst = 'mul %s, %s' % (op1, op2)
    elif b == 20:
        inst = 'quo %s, %s' % (op1, op2)
    elif b == 21:
        inst = 'rem %s, %s' % (op1, op2)
    elif b == 22:
        inst = 'and %s, %s' % (op1, op2)
    elif b == 23:
        inst = 'or %s, %s' % (op1, op2)
    elif b == 24:
        inst = 'xor %s, %s' % (op1, op2)
    elif b == 25:
        inst = 'shl %s, %s' % (op1, op2)
    elif b == 26:
        inst = 'sar %s, %s' % (op1, op2)
    elif b == 27:
        inst = 'xor %s, 0xFFFFFFFF' % op1
    elif b == 31:
        inst = 'sub %s, %s, %s' % (tmp, op1, op2)
    elif b == 32:
        inst = 'jmp %s' % op2
    elif b == 33:
        inst = 'cmp %s, 0; jlt %s' % (op1, op2)
    elif b == 34:
        inst = 'cmp %s, 0; jeq %s' % (op1, op2)
    elif b == 35:
        inst = 'cmp %s, 0; jgt %s' % (op1, op2)
    elif b == 36:
        inst = 'cmp %s, 0; jge %s' % (op1, op2)
    elif b == 37:
        inst = 'cmp %s, 0; jne %s' % (op1, op2)
    elif b == 38:
        inst = 'cmp %s, 0; jle %s' % (op1, op2)
    elif b == 39:
        inst = 'cmp %s, 0; jlt %s' % (tmp, op2)
    elif b == 40:
        inst = 'cmp %s, 0; jeq %s' % (tmp, op2)
    elif b == 41:
        inst = 'cmp %s, 0; jgt %s' % (tmp, op2)
    elif b == 42:
        inst = 'cmp %s, 0; jge %s' % (tmp, op2)
    elif b == 43:
        inst = 'cmp %s, 0; jne %s' % (tmp, op2)
    elif b == 44:
        inst = 'cmp %s, 0; jle %s' % (tmp, op2)
    elif b == 49:
        inst = 'call %s' % op2
    elif b == 50:
        inst = 'retn'
    elif b == 51:
        inst = 'push %s' % op2
    elif b == 52:
        inst = 'pop r%dd'
    elif b == 53:
        inst = 'pusha rXd'
    elif b == 54:
        inst = 'popa rXd'
    elif b == 112:
        inst = 'exit'
    else:
        inst = 'nop'
    
    return inst

for i in range(0, 34):
    print '%2X: %s' % (i, disasm(struct.unpack('<L', code[4*i:4*(i+1)])[0]))

for i in range(34, 81):
    c = code[4*i:4*i+1]
    if 0x20 <= ord(c) and ord(c) < 0x7F:
        print '%2X: dd \'%s\'' % (i, c)
    else:
        print '%2X: dd %02Xh' % (i, ord(c))

for i in range(81, 124):
    print '%2X: %s' % (i, disasm(struct.unpack('<L', code[4*i:4*(i+1)])[0]))
