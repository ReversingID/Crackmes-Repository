//Coded on January 3rd, 2008 by TCM
//Beer: Chimay, Grand Reserve (9%)
//Music: Okkervil River (Black Sheep Boy)
//Disassembler/Debugger: IDA Pro 5.0
//Compiler: Dev-C++ 4.99


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>


void printSerialBin(BYTE * serialBin);
void readSnowBin(BYTE * snowBin);
void writeSerialBin(BYTE * serialBin);
long getFileSize (FILE * file);

int size = 0x200;
int iterations = 0x80;

int main(void)
{
    BYTE serialBin[0x80];
    BYTE snowBin[0x200];
	int i;
	int k;
	int attempt = 0;
	
	//Populate serial.bin with fake data
	for(i = 0; i < 0x80; i++)
	      serialBin[i] = i & 0xFF;
 
    //Read snow.bin
    readSnowBin(snowBin);
 
    printf("+ Beginning Computations...\n");
    for(k = 0; k < 0xFF; k++)
    {   
     
        for(i = 0; i < 0xFF; i++)
        {
              BYTE initial_1 = 's';
	          BYTE initial_2 = 'n';
	          int count = 0;
	          int remainder;
	          int savedOffset;
	          
              serialBin[0x7E] = k;  //Varied Key 1
              serialBin[0x7F] = i;  //Varied Key 2
	      
	
              for(; count < 0x80; count+=0x4)
              {
		            //Transform 1
		            savedOffset = initial_1 & 0x8000007F;
		            remainder = (BYTE)(serialBin[savedOffset] % size);
		            savedOffset = initial_2 & 0x8000007F;
		            initial_1 ^= snowBin[remainder] ^ serialBin[count] ^ initial_2;

		            //Transform 2
		            remainder = (BYTE)(serialBin[savedOffset] % size);
		            savedOffset = initial_1 & 0x8000007F;
		            initial_2  ^= snowBin[remainder] ^ serialBin[count];
		
		            //Transform 3
		            remainder = (BYTE)(serialBin[savedOffset] % size);
		            savedOffset = initial_2 & 0x8000007F;
		            initial_1 ^= snowBin[remainder] ^ serialBin[count+1] ^ initial_2;
		
		            //Transform 4
		            remainder = (BYTE)(serialBin[savedOffset] % size);
		            savedOffset = initial_1 & 0x8000007F;
		            initial_2 ^= snowBin[remainder] ^ serialBin[count+1];
		
		            //Transform 5
		            remainder = (BYTE)(serialBin[savedOffset] % size);
		            savedOffset = initial_2 & 0x8000007F;
		            initial_1 ^= snowBin[remainder] ^ serialBin[count+2] ^ initial_2;
		
		            //Transform 6
		            remainder = (BYTE)(serialBin[savedOffset] % size);
		            initial_2 ^= snowBin[remainder] ^ serialBin[count+2];
		            savedOffset = initial_1 & 0x8000007F;
		
		            //Transform 7
		            remainder = (BYTE)(serialBin[savedOffset] % size);
		            initial_1 ^= snowBin[remainder] ^ serialBin[count+3] ^ initial_2;
		            savedOffset = initial_2 & 0x8000007F;
		
		            //Transform 8
		            remainder = (BYTE)(serialBin[savedOffset] % size);
		            initial_2 ^= snowBin[remainder] ^ serialBin[count+3];
              }

	          if(initial_1 == initial_2)
              	  {
                    	  printf("+ Valid Serial found on Attempt %d\n", attempt+1);
		          writeSerialBin(serialBin);
		          system("pause");
		          return 0;
                  }
	          else
		          attempt++;
        }
   }
   printf("- Colossial Fail! Not found in %d attempts\n", attempt);
   return -1;
}

void writeSerialBin(BYTE * serialBin)
{
     int i;
     int ret;
     FILE * file = fopen("serial.bin", "wb");
     if(file == NULL)
     {
             printf("- Cannot write file\n");
             return;
     }
     fwrite("snow", 4, 1, file);
     for(i = 0; i < 0x80; i++)
           fwrite(&serialBin[i], 1, 1, file);
           
     printf("+ serial.bin written to the current directory\n");
     fclose(file);    
}

void readSnowBin(BYTE * snowBin)
{
     FILE * file = fopen("snow.bin", "rb");
     int size = 0;
     if(file == NULL)
     {
             printf("- Cannot read \"snow.bin\" in the current directory\n");
             return;
     }
     size = getFileSize(file);
     if(size != 0x200 + 0x10) //Key Size + Header Size
     {
             printf("- Invalid Sized File\n");
             return;
     }
     printf("+ Read in snow.bin\n");
     fseek(file, 0x10, SEEK_CUR);
     fread(snowBin, 0x200, 1, file);
}

long getFileSize (FILE * file)
{
     long lCurPos, lEndPos;
     if (file == NULL)
        return -1;
     lCurPos = ftell(file);
     fseek (file, 0, SEEK_END);
     lEndPos = ftell(file);
     fseek (file, lCurPos, 0);
     return lEndPos;
}
