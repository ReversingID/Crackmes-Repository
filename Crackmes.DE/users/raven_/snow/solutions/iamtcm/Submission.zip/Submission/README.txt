Snow Keygen
By: TCM

Instructions:

1. Copy keygen.exe into the snow directory.
2. Double click keygen.exe 
	- serial.bin will be computed and written to the directory.

3. Double click snow.exe (Success!)