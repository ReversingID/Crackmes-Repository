Justfun by _raven
_______________________________________________
Rules:
       - No patching
Solution is a tutorial and a working keygen!
_______________________________________________