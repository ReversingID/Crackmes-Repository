#include <stdio.h>

char serial[16] = "KK"; /* length 2 is important */

/* declare the table twice to account for negative remainders */
char table[32] = {
	0x55, 0x36, 0x87, 0xA5,
	0x5D, 0x01, 0x0F, 0xFD,
	0xE4, 0xD5, 0x66, 0x3D,
	0xBA, 0xCC, 0x21, 0x5D,
	0x55, 0x36, 0x87, 0xA5,
	0x5D, 0x01, 0x0F, 0xFD,
	0xE4, 0xD5, 0x66, 0x3D,
	0xBA, 0xCC, 0x21, 0x5D
};

#define f(x) table[((x) % 15) + 0x10]
#define g(i) f(serial[i])

int check()
{
	char a, b;
	int i;

	/* init */
	a = f(serial[0]);
	b = f(serial[1]);

	/* calculations 1 and 2 */
	for (i = 0; i < 16; i++)
		a ^= f(i * b);
	for (i = 0; i < 16; i++)
		b ^= f(i * a);

	/* calculation 3 - this is effectively a nop */
	for (i = 0; i < 4; i++) {
		a ^= g(4*i)      ^ g(4*i + 1)  ^ g(4*i + 2)  ^ g(4*i + 3);
		b ^= g(12 - 4*i) ^ g(13 - 4*i) ^ g(14 - 4*i) ^ g(15 - 4*i);
	}

	/* the check */
	return (a == b);
}

void main(int argc, char *argv[])
{
	char i, j;

	printf("Use any string for the serial as long as it starts\n"
		"with one of the following sequences:\n");

	for (i = 'K'; i <= 'Y'; i++) {
		serial[0] = i;
		for (j = 'K'; j <= 'Y'; j++) {
			serial[1] = j;
			if (check())
				printf("%s\n", serial);
		}
	}

	getchar();
}
