#include <iostream>
#include <vector>
#include <string>

using namespace std;

const unsigned char data[41] = "\x0d\x2f\xe9\x86\x10\x29\xf8\x86\x1d\x34\xbd\x86\x1a\x2f\xeb\x86\x13\x2f\xbc\xc7\x1a\x24\xbc\xd1\x06\x29\xe8\xc3\x54\x21\xbc\xd2\x01\x34\xf3\xd4\x1d\x21\xf0\x88";
const unsigned char set[37] = "0123456789abcdefghijklmnopqrstuvwxyz";

void decryptall(const vector<vector<unsigned char> > &presol, int len, int idx = 0, string sol = "")
{
	if (sol.length() != 40)
		sol.resize(40, ' ');
	if (presol.size() == idx) {
		cout << sol << endl;
		return;
	}

	for (int i = 0; i < presol[idx].size(); ++i) {
		for (int pos = idx; pos < 40; pos += len)
			sol[pos] = (char)(data[pos] ^ presol[idx][i]);
		decryptall(presol, len, idx + 1, sol);
	}
}

int main()
{
	for (int len = 1; len <= 5; ++len) {
		bool full_solution = true;
		vector<vector<unsigned char> > presol(len, vector<unsigned char>());
		
		for (int start = 0; start < len; start++) {
			bool one_byte_solution = false;
			for (unsigned char s = 0; ; s++) {
				bool this_byte_solution = true;
				for (int pos = start; pos < 40; pos += len) {
					unsigned char d = data[pos] ^ s;
					if ((d < 'a' || d > 'z') && (d < 'A' || d > 'Z') && d != '.' && d != ';' && d != ',' && d != ' ' && d != ':' && d != '?' && d != '!') {
						this_byte_solution = false;
						break;
					}
				}
				if (this_byte_solution) {
					unsigned char a, b;
					for (int k = 0; k < 36; k++) {
						a = set[k];
						for (int pos = start; pos < 40; pos += len) {
							b = (a + (data[pos] ^ s)) % 0xff;
							a = (a >> 1) ^ b;
						}
						if (a == s) {
							one_byte_solution = true;
							presol[start].push_back(s);
							break;
						}
					}
				}
				if (s == 255)
					break;
			}
			if (!one_byte_solution) {
				full_solution = false;
				break;
			}
		}
		if (full_solution)
			decryptall(presol, len);
	}
}
