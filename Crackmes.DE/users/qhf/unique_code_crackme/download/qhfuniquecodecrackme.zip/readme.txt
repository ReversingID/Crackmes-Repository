Name: 		qHF's Unique Code CrackMe
Difficulty:	1 Easy, for Newbies
Language:	C++
Author:		qHF

Rules:
Make a keygen for this unique crackme.
You are allowed to display the "key" as
a string of 1's and 0's (1 = checked,
0 = unchecked).

Example (working key):
qHF;
0011110001

No Patching.
Write a solution or a tutorial if you like
it a lot and have some spare time on your
hands.

by qHF