/* 
   -------------------------------------------------------------------------
   - Filename  : main.c
   - Purpose   : KeyGen for qHF's Unique Code CrackMe
   - Created   : 01.06.10
   - Protection: Check boxes
   - Difficulty: Author says level 1...but noobs will find it harder
   -------------------------------------------------------------------------
   - Copyright (C) 2010  [Xorolc]
   -
   - This program is free software: you can redistribute it and/or modify
   - it under the terms of the GNU General Public License as published by
   - the Free Software Foundation, either version 3 of the License, or
   - (at your option) any later version.
   -
   - This program is distributed in the hope that it will be useful,
   - but WITHOUT ANY WARRANTY; without even the implied warranty of
   - MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   - GNU General Public License for more details.
   - 
   - You should have received a copy of the GNU General Public License
   - along with this program.  If not, see http://www.gnu.org/licenses/
   -------------------------------------------------------------------------   
*/
#define WIN32_LEAN_AND_MEAN // Doesn't really do much anymore, but still looks cool

/* Includes */
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include "resource.h"

/* save a few bytes. 10,240 on my rig*/
#pragma comment(linker,"/FILEALIGN:0x200 /MERGE:.data=.text /MERGE:.rdata=.text /SECTION:.text,EWR /IGNORE:4078")

/* Defines */
#define CTRLMSG HIWORD(wParam)
#define CTRLID  LOWORD(wParam)


/* Globals */
HMENU hmenu;
HANDLE phandle;
HINSTANCE g_inst;
HWND gHwnd = NULL;
HWND hDlg, hwndName, hwndSerial, hwndID;
HWND hwndb1, hwndb2, hwndb3, hwndb4, hwndb5, hwndb6, hwndb7, hwndb8, hwndb9, hwndb10, hwndcmName, hwndcmOK;

char AppTitle[]		="qHF's Unique Code CrackMe KeyGen";
char szSerial[11]	= {0};
char szName[50]		= {0};
char WindowClass[]	= "";
char WindowTitle[]	= "qHF's Unique Code CrackMe";


/* Our Function Prototypes */
void InitApp( HWND );
void CalculateSerial();
void CenterDialog( HWND );

BOOL CALLBACK DialogProcedure( HWND, UINT, WPARAM, LPARAM );
int WINAPI WinMain( HINSTANCE, HINSTANCE, LPSTR, int );

BOOL CALLBACK DialogProcedure( HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam ){

	switch( uMsg ){

	case WM_INITDIALOG:
		InitApp( hDlg );
		SetWindowText(hDlg, AppTitle );
		CenterDialog( hDlg );
		break;

	case WM_CLOSE:
		EndDialog( hDlg, TRUE );
		break;

	case WM_LBUTTONDOWN: // Drag dialog with mouse trick
		ReleaseCapture();
		SendMessage( hDlg, WM_NCLBUTTONDOWN, HTCAPTION, 0 );
		break;

	case WM_COMMAND:
		switch( CTRLID ){

		case IDC_OK:
			ZeroMemory( szName, sizeof( szName ) );
			ZeroMemory( szSerial, sizeof( szSerial ) );
			
			
			GetWindowText( hwndName, szName, sizeof( szName ) );
			CalculateSerial();
			SetWindowText( hwndSerial, szSerial );
			break;

		case IDC_LAZY:
			gHwnd = FindWindow(0, WindowTitle);	// Find Window By Title
		    //gHwnd = FindWindow(WindowClass, 0 );// Find Window By Class
			if( gHwnd == NULL){
				MessageBox( hDlg, "Can't Find The Crackme", "Error", MB_OK);
				break;
			}
			if( GetWindowTextLength( hwndSerial ) < 10 ){
				MessageBox( hDlg, "Press 'OK' to get a valid serial first", "Error", MB_OK );
				break;
			}
			
			hwndb1		= GetDlgItem( gHwnd, 1004 );
			hwndb2		= GetDlgItem( gHwnd, 1005 );
			hwndb3		= GetDlgItem( gHwnd, 1006 );
			hwndb4		= GetDlgItem( gHwnd, 1007 );
			hwndb5		= GetDlgItem( gHwnd, 1008 );
			hwndb6		= GetDlgItem( gHwnd, 1009 );
			hwndb7		= GetDlgItem( gHwnd, 1010 );
			hwndb8		= GetDlgItem( gHwnd, 1011 );
			hwndb9		= GetDlgItem( gHwnd, 1012 );
			hwndb10		= GetDlgItem( gHwnd, 1013 );
			hwndcmOK	= GetDlgItem( gHwnd, 1000 );
			hwndcmName	= GetDlgItem( gHwnd, 1003 );

			SendMessage( hwndcmName, WM_SETTEXT, 0, szName );
			
			if( szSerial[0] == 0x31){
				SendMessage( hwndb1, BM_SETCHECK, BST_CHECKED, 0 );
			}
			else{
				SendMessage( hwndb1, BM_SETCHECK, BST_UNCHECKED, 0 );
			}

			if( szSerial[1] == 0x31){
				SendMessage( hwndb2, BM_SETCHECK, BST_CHECKED, 0 );
			}
			else{
				SendMessage( hwndb2, BM_SETCHECK, BST_UNCHECKED, 0 );
			}

			if( szSerial[2] == 0x31){
				SendMessage( hwndb3, BM_SETCHECK, BST_CHECKED, 0 );
			}
			else{
				SendMessage( hwndb3, BM_SETCHECK, BST_UNCHECKED, 0 );
			}

			if( szSerial[3] == 0x31){
				SendMessage( hwndb4, BM_SETCHECK, BST_CHECKED, 0 );
			}
			else{
				SendMessage( hwndb4, BM_SETCHECK, BST_UNCHECKED, 0 );
			}

			if( szSerial[4] == 0x31){
				SendMessage( hwndb5, BM_SETCHECK, BST_CHECKED, 0 );
			}
			else{
				SendMessage( hwndb5, BM_SETCHECK, BST_UNCHECKED, 0 );
			}

			if( szSerial[5] == 0x31){
				SendMessage( hwndb6, BM_SETCHECK, BST_CHECKED, 0 );
			}
			else{
				SendMessage( hwndb6, BM_SETCHECK, BST_UNCHECKED, 0 );
			}

			if( szSerial[6] == 0x31){
				SendMessage( hwndb7, BM_SETCHECK, BST_CHECKED, 0 );
			}
			else{
				SendMessage( hwndb7, BM_SETCHECK, BST_UNCHECKED, 0 );
			}

			if( szSerial[7] == 0x31){
				SendMessage( hwndb8, BM_SETCHECK, BST_CHECKED, 0 );
			}
			else{
				SendMessage( hwndb8, BM_SETCHECK, BST_UNCHECKED, 0 );
			}

			if( szSerial[8] == 0x31){
				SendMessage( hwndb9, BM_SETCHECK, BST_CHECKED, 0 );
			}
			else{
				SendMessage( hwndb9, BM_SETCHECK, BST_UNCHECKED, 0 );
			}

			if( szSerial[9] == 0x31){
				SendMessage( hwndb10, BM_SETCHECK, BST_CHECKED, 0 );
			}
			else{
				SendMessage( hwndb10, BM_SETCHECK, BST_UNCHECKED, 0 );
			}

			SendMessage( hwndcmOK, BM_CLICK, 0, 0 );
			SendMessage( hwndcmOK, BM_CLICK, 0, 0 ); // I don't know why it doesn't work with just one?

			break;

		case IDC_EXIT:
			EndDialog( hDlg, TRUE );
			break;

		}

		break;

		default:
			return FALSE;
	}
	return TRUE;
}


int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow ){
	g_inst = hInstance;
	DialogBox( hInstance,MAKEINTRESOURCE(IDD_DIALOG),NULL,( DLGPROC )DialogProcedure );
	return FALSE;
}


/* Custom Functions */

void CalculateSerial(){

	int len, i, j, k, l;

	i = 0x30;
	j = 0;
	len = lstrlen( szName );

	if( len < 4 ) {
		lstrcat( szSerial, "Name must be 4 or more characters" );
		return;
	}

	if( ( len & 1) == 1 ) i = 0x31;
	szSerial[j] = i;
	j++;

	for( k=0 ; k<3; k++ ){
		i = 0x30;
		if( szName[k] < 0x5F) i=0x31;
		szSerial[j] = i;
		j++;
	}

	for( k=len-3; k<len; k++ ){
		i = 0x30;
		if( ( szName[k] & 1 ) == 0 ) i = 0x31;
		szSerial[j] = i;
		j++;
	}
	k = (len / 2) - 1;
	l = k + 3;

	for( ; k<l; k++ ){
		i = 0x30;
		if( ( szName[k] & 1) == 1 ) i = 0x31;
		szSerial[j] = i;
		j++;
	}

	return;
}

void InitApp( HWND hDlg ){

	hwndName	= GetDlgItem( hDlg, IDC_NAME );
	hwndSerial	= GetDlgItem( hDlg, IDC_SERIAL );

	return;
}

void CenterDialog(HWND hwndDlg){

	RECT Dlg, Desktop;
	DWORD Height, Width, DeskX, DeskY;

	GetWindowRect(hwndDlg, &Dlg);
	GetWindowRect(GetDesktopWindow(), &Desktop);

	Width = Dlg.right - Dlg.left;
	Height = Dlg.bottom - Dlg.top;
	DeskX = (Desktop.right - Width) >> 1;
	DeskY = (Desktop.bottom - Height) >> 1;	

	MoveWindow(hwndDlg, DeskX, DeskY, Width, Height, FALSE);

	return;
}
