#define WIN32_LEAN_AND_MEAN

#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include "resource.h"
#include "ufmod.h"

class Keygen {
	public:
		static void GenerateKey(char *user, char *key)
		{
			int a;
			strcpy(key, "");
			for(int i=0; i<strlen(user); i++)
			{
				a = user[i];
				if(a&1)
				{
					a -= 0x0F;
					a ^= 2;
				}
				else
				{
					a += 2;
					a ^= 0x0F;
				}
				sprintf(key, "%s%x", key, a);
			}
			strcat(key, "d");
		    
			for(int i=0; i<strlen(key);i++)
			{
				switch(key[i])
				{
					case 0x66:
						key[i] = 0x71;
						break;
		            
					case 0x31:
						key[i] = 0x48;
						break;
		                
					case 0x35:
						key[i] = 0x7A;
						break;
				}
			}
			return;
		}

		static BOOL CALLBACK DialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
		{
			switch(uMsg)
			{
				case WM_INITDIALOG:
					SetDlgItemText(hwndDlg, IDC_EDIT_NAME,   "DjH2oo7");
					SetDlgItemText(hwndDlg, IDC_EDIT_SERIAL, "Click it!");
					uFMOD_PlaySong((char*)IDR_RCDATA1, 0, XM_RESOURCE);
					return TRUE;

				case WM_CLOSE:
					EndDialog(hwndDlg, 0);
					return TRUE;

				case WM_COMMAND:
					switch(LOWORD(wParam))
					{
						case ID_GENERATE:
							char *name = new char[255];
							char *key  = new char[16];

							GetDlgItemText(hwndDlg, IDC_EDIT_NAME, name, 255);
							GenerateKey(name, key);
							SetDlgItemText(hwndDlg, IDC_EDIT_SERIAL, key);
							return TRUE;
					}
			}

			return FALSE;
		}
};


int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
	return DialogBox(hInstance, MAKEINTRESOURCE(ID_DIALOG), NULL, Keygen::DialogProc);
}
