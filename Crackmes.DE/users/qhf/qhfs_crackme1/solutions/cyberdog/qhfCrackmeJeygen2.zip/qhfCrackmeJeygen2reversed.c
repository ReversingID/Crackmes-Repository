// qhfCrackmeJeygen2.c : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "stdio.h"
#include "string.h"
#include "windows.h"

#define DEBUG 1

int main ()
{
	char name[]= "ANNABELLE" ;
	char serial[] = "LCENLCDP1CED";
	char encodage[] = "AJXGRFV6BKOW3Y9TM4S2ZU I70H5Q81PDECLNAJXGRFV6BKOW3Y9TM4S2ZU I70H5Q81PDECLNAJXGRFV6BKOW3Y9TM4S2ZU I70H5Q81PDECLN" ;
	int result= 0;

	int ii=0 ;
	
	while (ii<=3) {
		float  z = strlen(name) /4 ;
		float t1 = z*ii+z ;
		float t2 =(int)t1 -1 ;
		int w = (int) t2 ;
		int var74 = 0 ;
		char c0 = name[w];

		printf("loop 1 -- ii = %d / w (position) = %d / %c is our character \n",ii,w,c0);

		var74=2*ii+ii ;
		if (DEBUG) printf("loop 1 -- var 74 = %d \n",var74);

		while ( (2*ii+ii+3)>var74) {
			char *var78 ; 
			char *var7c ;
			int distance;
			char c1 ;

			c1 = serial[var74] ;
			//c1 is the caracter located at var74 in SERIAL entered
			if (DEBUG) printf("== loop 2 -- c1 = %c \n",c1);
			// Parse encoding string with char at position var74 from SERIAL entered
			var78 = strchr(encodage, c1) ;
			 if (DEBUG) printf("== loop 2 -- 1st occurence of c1= found at %p \n",var78);		
			var78 = strchr(var78+1, c1) ;
			if (DEBUG)printf("== loop 2 -- 2nd occurence found at %p \n",var78);

			
			// c0 is the character located at name[w]
			if (DEBUG) printf("== loop 2 -- c0 = %c \n",c0);
			// Parse encoding string to find 2nd occurence of var38 from name entered
			var7c = strchr(encodage, c0) ;
			if (DEBUG) printf("== loop 2 -- 1st occurence found at %p \n",var7c);
			
			var7c = strchr(var7c+1, c0) ;
			if (DEBUG) printf("== loop 2 -- 2nd occurence found at %p \n",var7c);

			distance = abs((int)var78-(int)var7c);
			printf("== loop 2 -- distance %d \n",distance);

			if (distance>5) {
			// FAILED
			result=1; 
			printf("== loop 2 -- result to 1 \n");
			}
			var74 +=1 ;
		}
		ii++;
	}
	Sleep(200000);
	return 0;
}
	
	

