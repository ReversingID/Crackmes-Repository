===========================================================

The .exe is the KEYGEN

Tuto.odt and .doc are tutorial in Open office / Word format

The qhfCrackmeKeygen2reverse.c is the fully reversed code in C of the original crackme main loop enabling to udnerstand what the program actually does...and the math behind.

The qhfCrackmeKeygen2.c is the keygen I wrote written in C 


HAPPY READING =============================================
Cyberdog