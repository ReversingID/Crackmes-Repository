// qhfCrackmeJeygen2.c : Defines the entry point for the console application.
//
#include "stdio.h"
#include "string.h"
#include "windows.h"

#define DEBUG 0

int main ()
{
	char name[255]= "" ;
	char serial[12] = "";
	char encodage[] = "AJXGRFV6BKOW3Y9TM4S2ZU I70H5Q81PDECLNAJXGRFV6BKOW3Y9TM4S2ZU I70H5Q81PDECLNAJXGRFV6BKOW3Y9TM4S2ZU I70H5Q81PDECLN" ;
	int ii=0 ;
	char c;
	
	do {
	printf("Please enter your name (minimum 4 chars pls) : ") ;
	scanf("%s",name) ;
	strupr(name);
	} while (strlen(name)<=3);
		

	while (ii<=3) {
		int z = strlen(name) / 4;
		int t1 = z*ii+z ;
		int t2 = t1 - 1 ;
		int w =  t2;
		int var74 = 0 ;
		char c0 = name[w];
		char c1;
		char *var78;
		char *temp;

		if (DEBUG) printf(" z= %d / t1= %d / t2 = %d ; w= %d ",z,t1,t2,w);

		if (DEBUG) printf("ii = %d / w (position) = %d / %c is our character \n",ii,w,c0);

		var74=2*ii+ii ;
		var78 = strchr(encodage, c0) ;
		var78 = strchr(var78+1, c0) ;

		if (DEBUG)printf("var74 = %d, \n",var74);

		// Based on var78 we have to check whether to take the caracters after of before var78... as string repeat.	
		// try taking caracter after
		c1 = var78[1] ;

		// Check if c1 is actually its second occurence in string or not. of more will be too distant from c0
		temp = strchr(encodage, c1) ;
		temp = strchr(temp+1, c1) ;
		if (temp==var78+1)
		{
			serial[var74]=var78[1] ;
			serial[var74+1]=var78[1];
			serial[var74+2]=var78[1] ;
		}
		else
		{
			serial[var74]=var78[-1] ;
			serial[var74+1]=var78[-1];
			serial[var74+2]=var78[-1] ;
		}
		var74+=3;
		ii++;
	}
	serial[12]='\0';
	printf("SERIAL =  %s \n",serial);

	printf("Press any key to exit...") ;
	getch();
	return 0;
}
