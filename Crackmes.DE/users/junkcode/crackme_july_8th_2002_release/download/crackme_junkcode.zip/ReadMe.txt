CrackMe July 8th, 2002 Release
Coded by JunkCode

its a rather simple crackme, meant for beginners. i haven't put any
kind of anti-* stuff in it.. so a disassembly in W32Dasm will do.

Objective of CrackMe...
Get the combination, name and key right :-)

Author : JunkCode
E-Mail : junkcode@phreaker.net

