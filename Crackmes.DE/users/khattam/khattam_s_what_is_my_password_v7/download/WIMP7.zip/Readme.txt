_khAttAm_'s What Is My Password v7
----------------------------------
This is a very difficult dos crackme by me. It is the sixth one that has been approved in crackmes.de (WIMP3 being rejected). I would rate it 7-9 out of 10. The crackers can rate it better (I'm poor at rating, :D hehe). 

Target
------
1. Find a valid password for WIMP7.exe (Very Difficult)
2. Use the password found to Unzip "_khAttAm_'s WIMP v7.ZIP" and read the Congratz.txt inside the zip file for further info.

Greetz
------
>ZeroCoder (who has cracked some difficult versions of _khAttAm_'s WIMP)
>_mAkA_
>Crackmes.de team