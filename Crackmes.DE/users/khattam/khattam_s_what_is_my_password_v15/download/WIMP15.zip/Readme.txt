_khAttAm_'s What Is My Password v15
-----------------------------------

It is very easy with only a little bit of trick...... Just look for it....

All you need to do is find a valid password that will make the box show the text as shown in "WIMP15 Result.JPG", included.

Multiple passwords are valid....


Q. Why is WIMP15 easy to solve??
Ans: Coz 1. The serial is just 3 charactered.
         2. The check is lame.
         3. No brute forcing has to be applied, At least, I hope so....

Q. Why is WIMP15 difficult to solve??
Ans: Coz there are many lamers in the business... :D

Rules:
1. No patching.. Well, if you find where to patch and how to patch, you will also find the Serial. So, not a great deal.......