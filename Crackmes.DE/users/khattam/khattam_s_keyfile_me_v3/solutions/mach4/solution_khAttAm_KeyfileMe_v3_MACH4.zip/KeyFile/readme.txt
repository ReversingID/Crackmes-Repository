To register the program:

Method 1: Place kfmv3.key file in C:\windows directory.

Method 2: Open program, click register, then browse for file, point to regCode.wmp

Don't forget, will not run on W7, runs fine on XP..............

MACH4.