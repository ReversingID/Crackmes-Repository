Hi ppl,
This is _khAttAm_ here...... I have come up with yet another crackme..... It is called unNag me v2. You need to remove the nag that comes up with the program loading. It is very easy, but not as easy as you might have thought. It will be a good exercise for a newbie....

Best of luck