_khAttAm_'s patch-me v2
-----------------------

Target Description
------------------
Compiled By - AutoIt
Packed - UPX
Protection - NAG, Serial
Level - 3

To Be Done
----------
1. Patch to remove the start-up nag
2. Patch to accept any serial or Find the valid serial
3. Patch to remove the "Bye Loser" nag that comes up when you click "Calcel"