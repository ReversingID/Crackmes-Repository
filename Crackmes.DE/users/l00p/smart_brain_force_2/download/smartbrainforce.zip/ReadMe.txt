
===================================
= Target:  SmartBrainForce.exe    =
= Coder:   ^L00P                  =
= Cracker: MabeYou :)             =
= Date:    13.09.2002             =
===================================


Intro.

 KeyFile crackme...
 It REALY could drive you insane...
 :)


Level.

 4 (1-10). 


You Need To:

 Make A KeyFile.


Allowed:

 All.
 Patching is NOT all0wed.



Protection.

 Key checking routine is SO easy,
 that it REALY will make You screeeeeem
 

Hint.

 Trie to solve it Smart...
    


Outro.

 If You are Succesfuly maked a keyfile, and Writted a Short Tutorial, 
 then send all this to: rel00p@yahoo.com and offcourse to www.crackmes.de 




			...: EndOfReadMe      :...
			...: rel00p@yahoo.com :...
 			...: ^L00P .:. 2002   :...