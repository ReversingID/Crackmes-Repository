#! /usr/bin/expect --

 for {set i 1} {$i<256} {incr i} {
 spawn ./crack
   expect  "User ID: " 
   send "$i\n"
   interact
 }
