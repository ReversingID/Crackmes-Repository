#include <windows.h>
#include <stdio.h>
#include "miracl.h"
#include "key2_tbl.h"
/*--------------------------------------------------------------------------*/
void miracl_init (char * mod, char * pub_exp, char * prv_exp);
void make_name_hash (char * name, big * mr_name, big * mr_prime_name);
void make_plain_key3 (big mr_name_hash, big mr_nx_prime, big * plain3);
void encrypt_key3 (big key3, big mod, big prv_exp, big *);
void make_key3 (char * name, char * pub_mod, char * pub_exp, char * prv_exp);
/*--------------------------------------------------------------------------*/

typedef struct _key2_ctx {
    unsigned long seed;
    unsigned long r0;
    unsigned long r1;
    unsigned long r2;
    unsigned long r3;
    unsigned long k0;
    unsigned long k1;
    unsigned long k2;
    unsigned long k3;
    unsigned long magic;
} key2_ctx;

void key2_srand (char * name, key2_ctx * ctx);
void key2_unmap (unsigned char * in, unsigned char * out, int inlen);
char find_char (unsigned char ch);
void make_key2 (char * name, key2_ctx * ctx);
