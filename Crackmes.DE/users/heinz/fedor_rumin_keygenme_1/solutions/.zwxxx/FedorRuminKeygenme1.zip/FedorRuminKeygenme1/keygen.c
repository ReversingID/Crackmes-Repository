


#include "keygen.h"

/*----------------------------------------------------*/
miracl * mip;
char pub_mod[] = "E6B4F5A5C6BE26DFB96694BDE6BD31FA0CB3F87D2B477AA77B74A5B9541CE299";
char pub_exp[] = "10001";
char prv_exp[] = "2938E04394B55940D461CDE5F89A89992B4C7BE8529430114A3BC6895C59C8B9";
char prv_p[] = "E9526DEFF53B54FDC5EEDB5A68F00CBB";
char prv_q[] = "FD2175CF229F863725BCB0AE2B6C62BB";

big mr_pub_exp, mr_pub_mod, mr_prv_exp, mr_prv_p, mr_prv_q;
big mr_lucas_mod;

unsigned char bigcool[] = "bigcoolrobotyeaah";
unsigned char frighten[] = "frighteningoptic";
unsigned char shake[] = "shakezmonctrfdvyx";
unsigned char ironcock[] = "ironcock";
/*----------------------------------------------------*/

/*-------------------KEY 3----------------------------*/
void miracl_init (char * mod, char * pub_exp, char * prv_exp)
{
    mip = mirsys (500, 10);
    mr_pub_exp = mirvar (0);
    mr_pub_mod = mirvar (0);
    mr_prv_exp = mirvar (0);
    mr_prv_p = mirvar (0);
    mr_prv_q = mirvar (0);
    mr_lucas_mod = mirvar (0);
    mip->IOBASE = 16;
    cinstr (mr_pub_exp, pub_exp);
    cinstr (mr_pub_mod, mod);
    cinstr (mr_prv_exp, prv_exp);
    cinstr (mr_prv_p, prv_p);
    cinstr (mr_prv_q, prv_q);
}

void make_name_hash (char * name, big * mr_name, big * mr_prime_name)
{
    int len0 = strlen (bigcool);
    int len1 = strlen (frighten);
    int namelen = strlen (name);
    int ix, t0, offset, reminder;
    unsigned char hash[32], hash1[256];
    big mr_hash, mr_nx_prime, mr_temp;
    sha256 sh;
    
    shs256_init (&sh);
    
    for (ix = 0; ix < namelen; ix ++) {
        t0 = name[ix] ^ bigcool[ix % len0];
        shs256_process (&sh, t0);
    }
    
    shs256_hash (&sh, hash);
    
    for (ix = 0, offset = 0; ix < 32; ix ++) {
        t0 = frighten [ix % len1] ^ hash[ix];
        offset += sprintf (hash1 + offset, "%02X", t0);
    }
    
    mr_hash = mirvar (0);
    hash1[63] = 0;
    cinstr (mr_hash, (char *)hash1);
    mr_nx_prime = mirvar (0);
    copy (mr_hash, mr_nx_prime);
    mr_temp = mirvar (0);
    reminder = subdiv (mr_hash, 31, mr_temp);
    
    while (reminder -- > -1) {
        nxprime (mr_nx_prime, mr_temp);
        copy (mr_temp, mr_nx_prime);
    }
    
    mr_free (mr_temp);
    * mr_name = mr_hash;
    * mr_prime_name = mr_nx_prime;
}

void make_plain_key3 (big mr_name_hash, big mr_nx_prime, big * plain3)
{
    big out = mirvar (0);
    xgcd (mr_name_hash, mr_nx_prime, out, out, out);
    * plain3 = out;
}

void encrypt_key3 (big key3, big lmod, big lprv_exp, big * keyout)
{
    big v = mirvar (0);
    big w = mirvar (0);
    big p_sq = mirvar (0), q_sq = mirvar (0);
    big t0 = mirvar (0), t1 = mirvar (0), t2 = mirvar (0), t3 = mirvar (0);
    
    multiply (mr_prv_p, mr_prv_p, p_sq);
    decr (p_sq, 1, t0);
    multiply (mr_prv_q, mr_prv_q, q_sq);
    decr (q_sq, 1, t1);
    multiply (t0, t1, t2);
    copy (mr_pub_exp, t3);
    xgcd (t3, t2, t3, t3, t3);
    
    lucas (key3, t3, lmod, v, v);
    powmod (v, lprv_exp, lmod, w);
    * keyout = w;
    mirkill (v);
}

void make_key3 (char * name, char * pub_mod, char * pub_exp, char * prv_exp)
{
    big mr_name, mr_prime, plain_key, fkey;
    miracl_init (pub_mod, pub_exp, prv_exp);
    make_name_hash (name, &mr_name, &mr_prime);
    make_plain_key3 (mr_name, mr_prime, &plain_key);
    encrypt_key3 (plain_key, mr_pub_mod, mr_prv_exp, &fkey);
    printf ("key3 : ");
    mip->IOBASE = 64;
    cotnum (fkey, stdout);
}

/*-------------------KEY 2----------------------------*/

void key2_srand (char * name, key2_ctx * ctx)
{
    int len = strlen (name);
    int x = 1, y = 0, ix, key2seed;
    
    for (ix = 0; ix < len; ix ++) {
        x = (name[ix] + x) % 0xfff1;
        y = (x + y) % 0xfff1;
    }
    
    ctx->seed = key2seed = ((y << 16) + x) ^ 0x31373313;
    srand (key2seed);
    ctx->r0 = rand () ^ 0x67452301;
    ctx->r1 = rand () ^ 0xefcdab89;
    ctx->r2 = rand () ^ 0x98badcfe;
    ctx->r3 = rand () ^ 0x10325476;
    ctx->k0 = 'nori';
    ctx->k1 = 'kcoc';
    ctx->k3 = 0xaf040888;
    ctx->k2 = 0xaa66d2b0;
    
    for (ix = 0; ix < 0x30; ix ++) {
        ctx->k2 -= ctx->k3 ^ 0x31337131;
    }
    
    ctx->magic = 0x31337131;
}

/* x, y -> i, i + 1     : (x << 2) | ((y >> 4) & 3)
 * x, y -> i + 2, i + 1 : ((y << 4) & 0xf0) | ((x >> 2) & 0x0f)
 * x, y -> i + 2, i + 3 : ((x << 6) & 0xc0) | y
 */

void key2_unmap (unsigned char * in, unsigned char * out, int inlen)
{
    
    unsigned char t0, x, y ;
    int ix;
    /* -1, 0, 1, 2, ..., 3f */
    
    for (ix = 0; ; ix ++) {
        t0 = in[3 * ix];
        x = t0 >> 2;
        x = find_char (x); /* s[i] */
        out[4 * ix] = x;
        
        if (3 * ix + 1 >= inlen) break;
        
        y = (t0 & 3) << 4;
        t0 = in[3 * ix + 1];
        y |= t0 >> 4;
        y = find_char (y); /* s[i+1] */
        out[4 * ix + 1] = y;
        
        if (3 * ix + 2 >= inlen) break;
        
        x = (t0 & 0xf) << 2; 
        t0 = in[3 * ix + 2];
        x |= t0 >> 6; 
        x = find_char (x); /* s[i+2] */
        out[4 * ix + 2] = x;
        
        if (3 * ix + 3 >= inlen) break;
        
        y = t0 & 0x3f;
        y = find_char (y); /* s[i+3] */
        out[4 * ix + 3] = y;
    }
}

char find_char (unsigned char ch)
{
    int ix;
    for (ix = 0; ix < 256; ix ++) {
        if ((key2_tbl[ix] & 0xff) == ch) {
            return ix;
        }
    }
    return ix ++;
}

void make_key2 (char * name, key2_ctx * ctx)
{
    unsigned long k0, k1, k2, k3;
    unsigned long r0, r1, r2, r3;
    unsigned long buffer[5];
    unsigned char out[64];
    int ix;
    
    key2_srand (name, ctx);
    
    k0 = ctx->k0; k1 = ctx->k1; k2 = ctx->k2; k3 = ctx->k3;
    r0 = ctx->r0; r1 = ctx->r1; r2 = ctx->r2; r3 = ctx->r3;
    
    for (ix = 0x30; ix > 0; ix --) {
        k2 += k3 ^ ctx->magic;
        k0 += ((k1 << 4) + r1) ^ (k1 + k2) ^ ((k1 >> 5) + r0);
        k1 += ((k0 << 4) + r3) ^ (k0 + k2) ^ ((k0 >> 5) + r2);
    }
    memset (buffer, 0, sizeof (buffer));
    buffer[0] = k0; buffer[1] = k1; buffer[2] = k2; buffer[3] = k3;
    key2_unmap ((unsigned char *)buffer, out, 16);
    out[12] = 0;
    printf ("key2 : %s\n", out);
    return ;
}

/*-------------------KEY 1----------------------------*/

void make_key1 (char * name)
{
    unsigned long bitfield = 0, seed;
    int x = 0, y = 1, ix;
    char ch1, ch2, perm0[16], key1[32];
    
    for (ix = 0; ix < (int)strlen (name); ix ++) {
        y = (name[ix] + y) % 0xfff1;
        x = (x + y) % 0xfff1;
    }
    
    seed = ((x << 16) | y) ^ 0x31337313;
    srand (seed);
    
    for (ix = 0; ix < 16; ix ++) {
        while (1) {
            x = rand () & 0xf;
            if (! (bitfield & (1 << x)))
                break;
        }
        bitfield |= 1 << x;
        perm0[ix] = x;
    }
    
    
    for (ix = 0; ix < 300; ix ++) {
        x = rand () & 0xf;
        y = rand () & 0xf;
        ch1 = shake[x]; ch2 = shake[y];
        shake[y] = ch1; shake[x] = ch2;
    }
    
    for (ix = 0, x = rand () & 0xffff; ix < 16; ix ++, x >>= 1) {
        if (x & 1)
            continue;
        shake[ix] = (char) toupper (shake[ix]);
    }
    
    
    memset (key1, 0, sizeof (key1));
    
    for (ix = 0; ix < 16; ix ++) {
        key1[perm0[ix]] = shake[ix];
    }
    printf ("key1 : %s\n", key1);
    return;
}

int main ()
{
    char name [64];
    key2_ctx ctx;
    printf ("your name : ");
    scanf ("%16s", name);
    make_key1 (name);
    make_key2 (name, & ctx);
    make_key3 (name, pub_mod, pub_exp, prv_exp);
    printf ("dont input last 2 characters of key3!!!\n");
    return 0;
}


