#include <stdio.h>
#include <string.h>

int main()
{
	char str[] = "myne{xtvfw~";
	int strl = strlen(str);
	int i, j = strl;

	for(i=0; i<strl; i++, j++) {
		str[i] ^= j;
	}

	printf("password is : %s\n", str);

	return 0;
}
