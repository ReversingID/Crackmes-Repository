#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>

#define VSTART	(0x08048000)
#define VOFFSET	(0x08048196)
#define POFFSET (VOFFSET - VSTART)
#define ECX	(0xa80)
#define XORVAL	(0x58)

const char crackme[] = "oxfoo1m3";
const char crackme_copy[] = "oxfoo1m3.decrypt";

static void create_copy(int fd, int fd2, int count)
{
	char *m;
	
	if ((m = mmap(0, count, \
			PROT_READ | PROT_WRITE, MAP_SHARED, \
			fd, 0)) == MAP_FAILED) {
		perror("mmap()1");
		exit(-3);
	}

	write(fd2, m, count);

	munmap(m, count);
}

static void do_xor(int fd, int count)
{
	int i, j;
	char *m, *tmp;

	if ((tmp = m = mmap(0, count, \
			PROT_READ | PROT_WRITE, MAP_SHARED, \
			fd, 0)) == MAP_FAILED) {
		perror("mmap()1");
		exit(-3);
	}

	tmp += POFFSET;

	for (i = ECX; i > 0; i--, tmp++) {
		j = *tmp;
		j ^= XORVAL;
		*tmp = j;
	}

	munmap(m, count);

}


int main(int argc, char **argv)
{
	int fd, fd2;
	struct stat st;

	if ((fd = open(crackme, O_RDWR)) == -1) {
		perror("open(crackme, O_RDWR)");
		exit(-1);
	}

	if (stat(crackme, &st) == -1) {
		perror("stat(crackme, &st)");
		exit(-2);
	}

	if ((fd2 = open(crackme_copy, O_RDWR | O_CREAT | O_TRUNC, \
			S_IRWXU)) == -1) {
		perror("open(crackme_copy, O_RDWR | O_CREAT)");
		exit(-3);
	}

	create_copy(fd, fd2, st.st_size);
	close(fd);

	/*
	if (stat(crackme_copy, &st) == -1) {
		perror("stat(crackme, &st)");
		exit(-2);
	}
	*/

	do_xor(fd2, st.st_size);
	close(fd2);

	return 0;
}
