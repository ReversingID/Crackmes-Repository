// Smart4KeyGen.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "stdio.h"
#include "conio.h"


void main()
{
	printf("������������ Ajax Crackme 4 KeyGen By CuTedEvil ������������\n\n");

	printf("Preparing....\n");

	int		A,B,C,D,E;
	int		ValidEntry;

	for (A = 0x20; A < 0x7F; A ++)
	{
		for (B = 0x20; B < 0x7F; B ++)
		{
			for (C = 0x20; C < 0x7F; C ++)
			{
				for (D = 0x20; D < 0x7F; D ++)
				{	
					for (E = 0x20; E < 0x7F; E ++)
					{
						__asm
						{
							xor eax, eax
							mov al, byte ptr [A]
							mov ah, byte ptr [B]
							xor ebx, ebx
							mov bl, byte ptr [B]
							mov bh, byte ptr [C]
							add eax, ebx
							mov bl, byte ptr [C]
							mov bh, byte ptr [D]
							sub eax, ebx	
							cmp ax, 0x6860
							jz Valid
							mov ValidEntry, 0
							jmp LoopAgain
Valid:
							mov ValidEntry, 1			
LoopAgain:

						}

						if (ValidEntry == 1)
						{

							printf("\n\nThis is a valid serial: �%c%c%c%c%c�\n",A,B,C,D,E);
							printf("\tGenertate another?\t(Y-N)");
							int Another = getch();
							if (Another == 0x6E) // 0x79 == Y  0x6E == N 
							{
								printf("\n\nPress Ctrl+C To Close");												
								do {
									
								} while(true);
							}
					
							
						}
					}
				}
			}
		}
	}

}
