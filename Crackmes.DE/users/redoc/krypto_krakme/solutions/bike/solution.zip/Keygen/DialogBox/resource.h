#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDD_DIALOG1                             100
#define IDC_GENERATE                            1002
#define IDC_SERIAL                              1004
#define IDC_NAME                                1005
#define IDC_CLOSE                               1006
