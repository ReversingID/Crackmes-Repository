#include <windows.h>
#include "resource.h"
#include "wincrypt.h"
#pragma comment(lib, "crypt32.lib")

char name[31];
char serial[100];
HWND hWnd;

//---------------------------------------------------------------------------
void Keygen(HWND hWnd)
{
    HWND        hName;
    RECT        rect;
    HDC         dcSrc, dcDest;
    HBITMAP     hBitmap;
    HGDIOBJ     hObj;
    DWORD       size, len=16;
    DWORD       *table;
    DWORD       x,y;
    DWORD       color;
    HCRYPTPROV  hProv;
    HCRYPTHASH  hHash;
    HCRYPTKEY   hKey;
    BYTE        md5[16];

    hName = GetDlgItem(hWnd, IDC_NAME);
    GetClientRect(hName, &rect);
    dcSrc = GetDC(hName);
    dcDest = CreateCompatibleDC(dcSrc);
    hBitmap = CreateCompatibleBitmap(dcSrc, rect.right, rect.bottom);
    hObj = SelectObject(dcDest, hBitmap);
    BitBlt(dcDest, 0, 0, rect.right, rect.bottom, dcSrc, 0, 0, SRCCOPY);
    
    size = rect.right * rect.bottom * 4;
    table = (DWORD*)malloc(size);
    if (!table) return;
    memset(table, 0, size);
    for (y=0; y<rect.bottom; y++)
    {
        for (x=0; x<rect.right; x++)
        {
            color = GetPixel(dcDest, x, y);
            if (color != CLR_INVALID) table[y * rect.right + x] = color;
        }
    }
    SelectObject(dcDest, hObj);
    DeleteObject(hBitmap);
    DeleteDC(dcDest);
    // calc MD5 on table
    CryptAcquireContextA(&hProv, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT);
    CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHash);
    CryptHashData(hHash, (BYTE*)table, size, 0);
    CryptGetHashParam(hHash, HP_HASHVAL, md5, &len, 0);
    CryptDestroyHash(hHash);
    CryptReleaseContext(hProv,0);
    free(table);
    len = 100;
    // convert to base64
    CryptBinaryToStringA(md5, 16, CRYPT_STRING_BASE64 , serial, &len);
    // don't mind 0x0d 0x0a
    serial[strlen(serial)-2] = 0;
    SetDlgItemTextA(hWnd, IDC_SERIAL, serial);
}
//---------------------------------------------------------------------------
LRESULT CALLBACK DlgProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
    INT         result = 0;
	switch(Msg)
	{
    case WM_INITDIALOG:
        SetFocus(GetDlgItem(hWnd, IDC_NAME));
        SendDlgItemMessageA(hWnd, IDC_NAME, EM_LIMITTEXT, 30, 0);
        SendDlgItemMessageA(hWnd, IDC_SERIAL, EM_SETREADONLY, TRUE, 0);
        break;
	case WM_CLOSE:
		DestroyWindow(hWnd);
		break;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
        case IDC_GENERATE:
            Keygen(hWnd);
            break;
        case IDC_CLOSE:
    		EndDialog(hWnd, result);
            break;
		}
		break;
	}
	return FALSE;
}

INT WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
				   LPSTR lpCmdLine, int nCmdShow)
{
	DialogBox(hInstance, MAKEINTRESOURCE(IDD_DIALOG1),
			  hWnd, reinterpret_cast<DLGPROC>(DlgProc));

	return FALSE;
}
