
#ifndef __REPO_SOCKS_H__
#define __REPO_SOCKS_H__

#define WSAAPI FAR PASCAL
#include "windows.h"

extern "C"
{
	 __declspec(dllexport)  void __stdcall FindUnlockCode(HWND h);
}

#endif