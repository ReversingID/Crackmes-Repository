#define DLL_EXPORT

#include "unlock.h"
#include "windows.h"
#include "stdio.h"

typedef void (*HASH_FUNC)(BYTE *, int, BYTE *);
typedef void (*INIT_FUNC)(BYTE *, int, BYTE *, BYTE *);
typedef void (*DECRYPT_FUNC)(BYTE *, BYTE *, int);

HWND        hDlg;
HANDLE      hThread;
BYTE        ctx[1000];        
char        unlockCode[10]="********";
char        codes[100];
BYTE        hash[32];
BYTE        key[16];
BYTE        iv[16];
BYTE        *encrypted; 

DWORD WINAPI ThreadProc(void *lParam)
{
    DWORD           dImageBase;
    HASH_FUNC       Hash;
    INIT_FUNC       Init;
    DECRYPT_FUNC    Decrypt;
    BYTE            buffer[16];
    DWORD           n,i,j;
    DWORD           temp,N;
    DWORD           total, index, step;
    char            text[100];

    SetWindowTextA(hDlg, "Finding unlock codes... 0%");
    EnableWindow(GetDlgItem(hDlg, 1005), FALSE);

    // find functions in crackme
    dImageBase = (DWORD)GetModuleHandle(NULL);
    Hash = (HASH_FUNC)(dImageBase + 0x7FA0);
    Init = (INIT_FUNC)(dImageBase + 0x6310);
    Decrypt = (DECRYPT_FUNC)(dImageBase + 0x6400);
    // start of the .core section
    // guessed that section starts with a function header to check on
    encrypted = (BYTE*)(dImageBase + 0x9000);

    // total iterations for bruteforce
    total = 62 + 62*62 + 62*62*26 + 62*62*62*62;
    step = total / 20;
    SetWindowTextA(hDlg, "Finding unlock codes... 0%");
    index = 0;
    for (n=1; n<5; n++)
    {
        unlockCode[0] = '0';
        N = 1;
        for (i=0; i<n; i++, N*=62) unlockCode[i]= '0';
        j = 0;
        while(j < N)
        {
            index++;
            if (index % step == 0)
            {
                sprintf(text,"Finding unlock codes... %d%%", index/step*5);
                SetWindowTextA(hDlg, text);
            }
            // unlock code chars: 'a'-'z' 'A'-'Z' '0'-'9'
            unlockCode[0]++;
            if (unlockCode[0] == 0x3A) unlockCode[0] = 'A';
            if (unlockCode[0] == 0x5B) unlockCode[0] = 'a';
            if (unlockCode[0] == 0x7B) 
            {
                    unlockCode[0] = '0';
                    for (i=1; i<n; i++)
                    {
                        unlockCode[i]++;
                        if (unlockCode[i] == 0x3A) unlockCode[i] = 'A';
                        if (unlockCode[i] == 0x5B) unlockCode[i] = 'a';
                        if (unlockCode[i] == 0x7B) 
                        {
                            unlockCode[i] = '0';
                        }
                        else break;
                    }
            }
            j++;
            memcpy(buffer, encrypted, 16);
            Hash((BYTE*)unlockCode, n, hash);
            Init(ctx, 2, hash, hash + 16);
            // decrypt only the first 16 bytes of the section is enough
            Decrypt(ctx, buffer, 16);
            temp = *(DWORD*)buffer;
            temp = temp & 0xFFFFFF;
            if (temp == 0xEC8B55)
            {
                unlockCode[n] = 0;
                if (codes[0] != 0) strcat(codes, " , ");
                strcat(codes, unlockCode);
                SetDlgItemTextA(hDlg, 1004, (char*)codes);
            }
        }
    }
    EnableWindow(GetDlgItem(hDlg, 1005), TRUE);
    EnableWindow(GetDlgItem(hDlg, 1004), TRUE);
    return 1;
}

extern "C"
{

     __declspec(dllexport)  void __stdcall FindUnlockCode(HWND h)
    {
        hDlg = h;
        hThread = CreateThread(NULL, 0, ThreadProc, NULL, 0, NULL); 
    }


    BOOL WINAPI DllMain(
        HINSTANCE hinstDLL,  // handle to DLL module
        DWORD fdwReason,     // reason for calling function
        LPVOID lpReserved )  // reserved
    {
        // Perform actions based on the reason for calling.
        switch( fdwReason ) 
        { 
        case DLL_PROCESS_ATTACH:
            // Initialize once for each new process.
            // Return FALSE to fail DLL load.
            break;
        case DLL_THREAD_ATTACH:
            // Do thread-specific initialization.
            break;
        case DLL_THREAD_DETACH:
            // Do thread-specific cleanup.
            break;
        case DLL_PROCESS_DETACH:
            // Perform any necessary cleanup.
            break;
        }
        return TRUE;  // Successful DLL_PROCESS_ATTACH.
    }

}

