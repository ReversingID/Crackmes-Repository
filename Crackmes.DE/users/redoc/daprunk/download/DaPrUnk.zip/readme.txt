Level 2-3. Some code should be reversed. It's little different, anyway it's really easy. I hope you enjoy it.

Good boy message is MsgBox ("Successfully registered") ... or if you want you can experiment some more. Your task is to write registrar program and solution.