
Level 3-4. It is based on code from DaPrUnk #1 but is little more complicated. No anti-debug. Crackme contains windows crypto API. You need to construct bruteforcer as a part of solution. It has only one regular password. Don't post it to discussion. Password consist of no more than 8 characters from a-z,A-Z,0-9.

Write keygen and post solution.
