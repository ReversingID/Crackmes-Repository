#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winsock2.h>
#include <stdio.h>
#include "resource.h"
#include "wincrypt.h"

HINSTANCE       hInst; 
UINT            newMsg;
HWND            daprunkWnd,hwnd;
HANDLE          hMap;
HCRYPTPROV      hProv;
HCRYPTKEY       hImportedKey;
DWORD           dwSeed, threadid;
BYTE            randomVector[256];
BYTE            *mapView;
char            buffer[200];
char            password[]="x4iQD";
BYTE            GetPassword[29]={0xE8,0x05,0x00,0x00,0x00,0x90,0x90,0x90,0x90,0x90,0x5E,0x8B,0x7C,0x24,0x04,0x8B,0x5C,0x24,0x08,0xB9,0x05,0x00,0x00,0x00,0x89,0x0B,0xF3,0xA4,0xC3};
WSADATA         data;
SOCKET          s;
DWORD           addr;
WORD            port;
sockaddr_in     name;


BYTE ror( BYTE c, BYTE n)
{
    n = n % 8;
    return (c >> n) | (c << (8-n));
}
//
// The algorithm from crackme to initialize RandomVector
//
void InitVector(DWORD dwSeed)
{
    BYTE b0,b1,b2,b3;
    DWORD i;
    
    b0 = (BYTE)dwSeed;
    b1 = (BYTE)(dwSeed>>8);
    b2 = (BYTE)(dwSeed>>16);
    b3 = (BYTE)(dwSeed>>24);
    for(i=0; i<=0xff; i++)
    {
        randomVector[ ror(b2^(BYTE)i, b3) ] = ror(b0^(BYTE)i,b1);
    }
    return;
}
//
// Receive from server
//
DWORD ReceiveBuffer(char *buffer) 
{
    fd_set set;
    int i=0,received=1, sel;
    timeval t;

    set.fd_count = 1;
    set.fd_array[0] = s;
    t.tv_sec = 0;
    t.tv_usec = 800000;
    while(received)
    {
        sel = select( 0, &set,0,0, &t);
        if (sel != 1 && i == 0) return FALSE;
        if (sel != 1 && i>0) break;
        received = recv(s, buffer++,1,0);
        if (received == SOCKET_ERROR)
        {
            return 0;
        }
        i++;
    }
    *buffer = 0;
    return i;
}
//
// Send to server
//
BOOL SendBuffer(char *buffer,int len)
{
    if (send(s, buffer, len, 0) == SOCKET_ERROR) return FALSE;
    return TRUE;
}

//
// See BYTE GetPassword[]={...}, it is the hex encoding of this function.
// Something goes wrong if compile for debug, the function gets messed
// so i copy it directly from the array. This is copied in shared memory.
//
__declspec(naked) void GeneratePassword()
{
    _asm
    {
        call $+10
        nop                     
        nop
        nop                         ; save 5 bytes for the the indices 
        nop                         ; of the letters of the password
        nop
        pop     esi                 ; call destination
        mov     edi, [esp+4]        ; password
        mov     ebx, [esp+8]        ; length
        mov     ecx, 5
        mov     [ebx], ecx
        rep     movsb
        retn                        ; stack is cleared outside
    }
}

BOOL ConnectToServer()
{
    WSAStartup(0x202, &data);
    s = socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
    name.sin_family = AF_INET;
    name.sin_port = htons(port);
    name.sin_addr.S_un.S_addr = inet_addr("127.0.0.1");
    if (connect(s, (sockaddr*)&name, sizeof(name))) return FALSE;
    return TRUE;
}
DWORD thread(void)
{
    int index,i,j;
    DWORD dwLen, dwKeyLen,dwErr;
    char dummy[100];
    char val[20];
    char vectorIndex[8];

    SendMessageA( GetDlgItem(hwnd,IDC_LIST1), LB_INSERTSTRING, -1, (LPARAM)"OK: Received seed and port, generating vector...");
    // initialize vector
    InitVector(dwSeed);
    // find the indices of password letters in generated vector
    for (i=0; i<5; i++)
        for (j=0; j<256; j++)
            if (randomVector[j] == password[i]) vectorIndex[i] = j;
   
    if ( !ConnectToServer() )
    {
        SendMessageA( GetDlgItem(hwnd,IDC_LIST1), LB_INSERTSTRING, -1, (LPARAM)"Error: Cannot connect to server.");
        return FALSE;
    }
    SendMessageA( GetDlgItem(hwnd,IDC_LIST1), LB_INSERTSTRING, -1, (LPARAM)"OK: Connected to socket server.");
    // receive Authenticate at %u
    if ( !ReceiveBuffer(buffer) )
    {
        SendMessageA( GetDlgItem(hwnd,IDC_LIST1), LB_INSERTSTRING, -1, (LPARAM)"Error: Auth index receive error.");
        return FALSE;
    }
    SendMessageA( GetDlgItem(hwnd,IDC_LIST1), LB_INSERTSTRING, -1, (LPARAM)buffer);
    sscanf(buffer,"%s%s%d",dummy,dummy,&index);
    sprintf(val+1,"%X",*(DWORD*)(randomVector + index));
    val[0] = strlen(val+1);
    // send authentication dword at position index, first byte is length
    if ( !SendBuffer(val,strlen(val+1)+1) )
    {
        SendMessageA( GetDlgItem(hwnd,IDC_LIST1), LB_INSERTSTRING, -1, (LPARAM)"Error: Auth send error.");
        return FALSE;
    }
    SendMessageA( GetDlgItem(hwnd,IDC_LIST1), LB_INSERTSTRING, -1, (LPARAM)"OK: Sent authentication dword.");
    // receive RSA public key blob
    if ( !ReceiveBuffer(buffer) )
    {
        SendMessageA( GetDlgItem(hwnd,IDC_LIST1), LB_INSERTSTRING, -1, (LPARAM)"Error: Public key receive error.");
        return FALSE;
    }
    // get the key from the blob
    if ( !CryptImportKey(hProv, (BYTE*)buffer, 0x100, 0, 0, &hImportedKey) )
    {
        dwErr = GetLastError();
        SendMessageA( GetDlgItem(hwnd,IDC_LIST1), LB_INSERTSTRING, -1, (LPARAM)"Error: Importing public key error.");
        return FALSE;
    }
    if ( !CryptGetKeyParam(hImportedKey, KP_BLOCKLEN, (BYTE*)&dwKeyLen, &dwLen, 0) )
    {
        return FALSE;
    }
    SendMessageA( GetDlgItem(hwnd,IDC_LIST1), LB_INSERTSTRING, -1, (LPARAM)"OK: Received RSA public key.");

    hMap = CreateFileMappingA((HANDLE)-1, 0, PAGE_EXECUTE_READWRITE, 0, 5120, "DaPrUnkFlock");
    mapView = (BYTE*)MapViewOfFile(hMap, FILE_MAP_ALL_ACCESS, 0, 0, 5120);
    SendMessageA( GetDlgItem(hwnd,IDC_LIST1), LB_INSERTSTRING, -1, (LPARAM)"OK: Created shared memory zone.");

    // copy function in SharedBuffer+4
    memcpy(mapView + 4, GetPassword, 29);
    // copy the indices to GetPassword function, replacing the nops
    memcpy(mapView + 9, vectorIndex, 5);
    dwLen = 100;
    if ( !CryptEncrypt(hImportedKey, 0, TRUE, 0, mapView + 4, &dwLen, 512) )
    {
        return FALSE;
    }
    *(DWORD*)mapView = dwLen;
    SendMessageA( GetDlgItem(hwnd,IDC_LIST1), LB_INSERTSTRING, -1, (LPARAM)"OK: Function encrypted.");
    SendMessageA( GetDlgItem(hwnd,IDC_LIST1), LB_INSERTSTRING, -1, (LPARAM)"OK: Done.");

    closesocket(s);
    WSACleanup();
    return TRUE;
}

BOOL CALLBACK DialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
   
    if (uMsg == newMsg)
    {
        // we received message from crackme with seed and port
        dwSeed = lParam;
        port = wParam;
        CreateThread(0, 0, (LPTHREAD_START_ROUTINE)thread,0,0, &threadid);
	    return TRUE; 
    }
    switch(uMsg)
    {
        case WM_INITDIALOG:
            hwnd = hwndDlg;
            break;
        case WM_CLOSE:
            UnmapViewOfFile(mapView);
            CloseHandle(hMap);
            CryptReleaseContext(hProv, 0);
            EndDialog(hwndDlg, 0);
            break;
        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case IDC_SEND:
                    daprunkWnd = FindWindowA(NULL, "DaPrUnk #2");
                    if ( !daprunkWnd )
                    {
                        SendMessageA( GetDlgItem(hwndDlg,IDC_LIST1), LB_INSERTSTRING, -1, (LPARAM)"Error: DaPrUnk #2 window not found.");
                        return FALSE;
                    }
                    // send our hwndDlg to crackme
                    SendMessageA( daprunkWnd, newMsg, (WPARAM)hwndDlg, 0);
                    SendMessageA( GetDlgItem(hwndDlg,IDC_LIST1), LB_INSERTSTRING, -1, (LPARAM)"OK: Message sent. Press \"Register\" on crackme window.");
                    break;
            }
    }
    return FALSE;
}


int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
    hInst = hInstance;
    if ( !CryptAcquireContextA(&hProv, "DaPrUnk2_Sol", "Microsoft Base Cryptographic Provider v1.0", PROV_RSA_FULL, 0))
    {
        if ( !CryptAcquireContextA(&hProv, "DaPrUnk2_Sol", "Microsoft Base Cryptographic Provider v1.0", PROV_RSA_FULL, CRYPT_NEWKEYSET) )
        {
            return 0;
        }
    }
    newMsg = RegisterWindowMessageA( "DaPrUnkMsg" );
    return DialogBox(hInstance, MAKEINTRESOURCE(DLG_MAIN), NULL, (DLGPROC)DialogProc);
}
