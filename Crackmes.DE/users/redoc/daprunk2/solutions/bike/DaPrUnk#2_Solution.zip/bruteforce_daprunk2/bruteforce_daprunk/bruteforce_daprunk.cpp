// bruteforce_daprunk.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "stdafx.h"
#include "windows.h"
#include "wincrypt.h"
#define NUMCHARS 62
#define MAXLEN  8

HCRYPTPROV hProv;
HCRYPTKEY hKey;
HCRYPTHASH hHash;
DWORD dwDataLen;
BYTE keyData[512];
BYTE randomVector[256];
char chars[]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
BYTE passindex[9]={0,0,0,0,0,0,0,0,0};
char pass[800];
DWORD dwPassLen=1;
BYTE hash_pass[] = {0xA3,0xAD,0xC7,0xB1,0x06,0x2C,0x8C,0x34,0x6D,0x02,0x1A,0x3C,0x26,0x05,0xBC,0xA4,0x07,0xF6,0x11,0x89};
BYTE hash[20];
BOOL finished;

BYTE ror(BYTE c, BYTE n)
{
    n = n % 8;
    return (c >> n) | (c << (8-n));
}
void InitVector(DWORD dwSeed)
{
    BYTE b0,b1,b2,b3;
    DWORD i;
    
    b0 = (BYTE)dwSeed;
    b1 = (BYTE)(dwSeed>>8);
    b2 = (BYTE)(dwSeed>>16);
    b3 = (BYTE)(dwSeed>>24);
    for(i=0; i<=0xff; i++)
    {
        randomVector[ ror(b2^(BYTE)i, b3) ] = ror(b0^(BYTE)i,b1);
    }
    return;
}

void GetPassword(char *password, DWORD *len)
{
    DWORD i;

    if (passindex[dwPassLen] != 0)
    {
        if (dwPassLen == MAXLEN) 
        {
            finished = TRUE;
            return;
        }
        dwPassLen++;
        printf("\nGenerating with length: %d",dwPassLen);
        for (i=0; i<dwPassLen; i++) passindex[i]=0;
    }
    else
    {
        passindex[0]++;
        for (i=0; i<dwPassLen; i++)
        {
            if(passindex[i]==62)
            {
                passindex[i] = 0;
                passindex[i + 1]++;
            }
        }
    }
    for(i=0; i<dwPassLen; i++) password[i] = chars[passindex[i]];
}

int main(int argc, char* argv[])
{
    DWORD   dwErr,dwLen;
    
    finished = FALSE;
    InitVector(0x69976C03);
    if ( !CryptAcquireContextA(&hProv, "DaPrUnk2_brute", "Microsoft Base Cryptographic Provider v1.0", PROV_RSA_FULL, 0))
    {
        if ( !CryptAcquireContextA(&hProv, "DaPrUnk2_brute", "Microsoft Base Cryptographic Provider v1.0", PROV_RSA_FULL, CRYPT_NEWKEYSET) )
        {
            dwErr = GetLastError();
            printf("\nCryptAcquireContextA error: %x.\n",dwErr);
            return 0;
        }
    }
    while ( !finished )
    {
        GetPassword(pass, &dwLen);
        if ( !CryptCreateHash(hProv, CALG_SHA1, 0, 0, &hHash) )
        {
            dwErr = GetLastError();
            printf("\nCryptCreateHash error: %x.\n",dwErr);
            return 0;
        }
        if ( !CryptHashData(hHash, (BYTE*)pass, dwPassLen, 0) )
        {
            dwErr = GetLastError();
            printf("\nCryptHashData error: %x.\n",dwErr);
            return 0;
        }
        dwLen = 20;
        if ( !CryptGetHashParam(hHash, HP_HASHVAL, hash, &dwLen, 0) )
        {
            dwErr = GetLastError();
            printf("\nCryptGetHashParam error: %x.\n",dwErr);
            return 0;
        }
        CryptDestroyHash(hHash);
        if ( !memcmp(hash, hash_pass, 20) )
        {
            printf("\nFound password: %s",pass);
            finished = TRUE;
        }
    }
	return 0;
}

