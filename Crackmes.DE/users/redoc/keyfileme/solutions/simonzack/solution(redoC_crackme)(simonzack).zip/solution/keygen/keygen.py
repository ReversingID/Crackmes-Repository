
import os

def genKey():
	compName=os.getenv('COMPUTERNAME').encode()
	compName=compName[:8].ljust(8,b'@')
	checksum_40221C=0x59EC10A7
	checksumStr=bytearray([checksum_40221C&0xFF,(checksum_40221C>>8)&0xFF,(checksum_40221C>>16)&0xFF,checksum_40221C>>24])*2
	res=bytearray(compName)
	for i in range(len(res)):
		res[i]^=checksumStr[i]
	ret=''
	for c in res:
		ret+='{:02X}'.format(c)
	return ret

	
def main():
	if os.access('CrackmE.key',os.F_OK):
		print('Error: CrackmE.key already exists')
		return
	open('CrackmE.key','w').write(genKey())

if __name__=='__main__':
	main()
