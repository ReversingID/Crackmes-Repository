// SPOK3FF Keygen2.cpp : Defines the entry point for the console application.
//

#include <iostream>
#include <cstring>
#include <cmath>
#include <cstdio>

using namespace std;

void calculate(char *, char *);

int main(int argc, char* argv[])
{
	try
	{
		char *name = new char[65535];
		char *serial = new char[65535];
		unsigned long bugfix=0;
		cout<<" ---------------------------------------------------- \n"
			  "|                                                    |\n"
			  "|               SPOK3FF Crackme#2                    |\n"
			  "|                  Keygenerator                      |\n"
			  "|                                                    |\n"
			  "|                    by Whivel                       |\n"
			  "|                                                    |\n"
			  " ---------------------------------------------------- \n\n";
		cout<<"Insert your [nick]name: ";
		cin>>name;
		calculate(name,serial);
		cout<<"Serial: "<<serial<<endl<<endl;
	}catch(char *ex)
	{
		cout<<"ERROR: "<<ex<<endl<<endl;;
	}
	system("pause");
	return 0;
}

void calculate (char *name, char *serial)
{

	unsigned int len=0;
	unsigned long character = 0;
	unsigned long first = 0;
	unsigned long second = 0;
	unsigned long third = 0;
	unsigned long tmp = 0;

	char tmp2[20]={0};

	len=(unsigned int)strlen(name);
	if(len<1) throw "Insert a [nick]name";// with 5 characters minimum";
	if(len<5)
		for (unsigned int i=len;i<6;i++)
			name[i]=0x0;
	character = name[0] + (name[1]<<8) + (name[2]<<16) + (name[3]<<24);
	character = character ^ 0x77777;


	for(unsigned int i=0;i<len;i++)
	{
		first+=name[i];
	}

	sprintf_s(tmp2,"%d",first);

	for(unsigned int i=0;i<(strlen(tmp2)+2);i++)
	{
		if(name[i]!=0x25)
		{
			second+=name[i]*0x3FFF-1;
		}
	}

	sprintf_s(tmp2,"%x",second);

	third = second;
	tmp=len;
	for(unsigned int i=0;i<(strlen(tmp2)+1-3);i++)
	{
		tmp = (((tmp + character) >> 7) + 1) ^ 0xBAFE;
		third+=tmp;
	}

	try
	{
		
		sprintf_s(serial,65535,"%d-%X%X",first, second, third);
	}catch(char *ex)
	{
		throw ex;
	}

}

