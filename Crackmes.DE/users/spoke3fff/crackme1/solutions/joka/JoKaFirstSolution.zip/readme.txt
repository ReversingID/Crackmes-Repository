This solution uses only OllyDbg.

1. Load crackme into OllyDbg. Run and get error message "Olly".
   First anti-debug check is using TEB

004012A1   . 64:FF35 1E0000>PUSH DWORD PTR FS:[1E]
004012A8   . 64:8925 000000>MOV DWORD PTR FS:[0],ESP
004012AF   . 9C             PUSHFD
004012B0   . 813424 5401000>XOR DWORD PTR SS:[ESP],154
004012B7   . 9D             POPFD

   To avoid it assemble
   jmp 4012dd
   at start of program (address 401281) then copy to executable and save file (I save as cr2.exe).

2. Re-run in Olly. Press Check. Process terminated.
   Re-run without Olly. Press Check. Error message "Enter name".
   Re-run when Olly started, debugging some other file. Press Check. Process terminated.
   This check is searching for OllyDbg window.
   Re-Open in Olly. Context menu - Search for - All intemodular calls - FindWindowA
   
00401702     6A 00          PUSH 0
00401704   . 68 08604000    PUSH cr2.00406008                        ; |Class = "OWL_Window"
00401709   . E8 76060000    CALL <JMP.&user32.FindWindowA>           ; \FindWindowA
0040170E   . 83F8 00        CMP EAX,0
00401711   . 75 34          JNZ SHORT cr2.00401747
00401713   . 6A 00          PUSH 0                                   ; /Title = NULL
00401715   . 68 00604000    PUSH cr2.00406000                        ; |Class = "OllyDbg"
0040171A   . E8 65060000    CALL <JMP.&user32.FindWindowA>           ; \FindWindowA
0040171F   . 83F8 00        CMP EAX,0
00401722   . 75 23          JNZ SHORT cr2.00401747
00401724   . 6A 00          PUSH 0                                   ; /Title = NULL
00401726   . 68 13604000    PUSH cr2.00406013                        ; |Class = "TSymbolTableDlg"
0040172B   . E8 54060000    CALL <JMP.&user32.FindWindowA>           ; \FindWindowA
00401730   . 0BC0           OR EAX,EAX
00401732   . 74 11          JE SHORT cr2.00401745
00401734   . 6A 00          PUSH 0                                   ; /Title = NULL
00401736   . 68 23604000    PUSH cr2.00406023                        ; |Class = "TsplashDlg"
0040173B   . E8 44060000    CALL <JMP.&user32.FindWindowA>           ; \FindWindowA
00401740   . 83F8 00        CMP EAX,0
00401743   . 75 02          JNZ SHORT cr2.00401747
00401745   > EB 07          JMP SHORT cr2.0040174E

   To avoid this check assemble
   jmp 40174e
   at address 401702

0040174F   . 6A 2D          PUSH 2D                                  ; /Count = 2D (45.)
00401751   . 68 94A84700    PUSH cr2.0047A894                        ; |Buffer = cr2.0047A894
00401756   . 68 D0070000    PUSH 7D0                                 ; |ControlID = 7D0 (2000.)
0040175B   . FF75 08        PUSH DWORD PTR SS:[EBP+8]                ; |hWnd
0040175E   . E8 2D060000    CALL <JMP.&user32.GetDlgItemTextA>       ; \GetDlgItemTextA
00401763   . 83F8 00        CMP EAX,0
00401766   . 0F84 BA050000  JE cr2.00401D26
0040176C   . E9 A2010000    JMP cr2.00401913

This reads entered Name if not empty go further to 401913
Setting breakpoint on 401913, then run, enter some name, press Check.
Breakpoint plays.
Let's trace with F7 (there are calls without returns so, tracing with F8 is not an option)

3. At addresses 401923,401789,40179b,401991,40187d program is self-looping after time measure checks. To avoid this Fill with NOP these addresses when looping.
At address 4017F3 program goes wrong address after time measure check
To avoid this Fill 4017F3 with NOPs or Change jump at 4017F1 to unconditional (jmp 4017f8)
Again Copy to executable (all modification) and save file

4. Tracing further

004019D3   ? 6A 00          PUSH 0
004019D5   ? 68 1DA84700    PUSH cr2.0047A81D
004019DA   ? 68 D1070000    PUSH 7D1
004019DF   . FF75 08        PUSH DWORD PTR SS:[EBP+8]                ; |hWnd
004019E2   . E8 A3030000    CALL <JMP.&user32.GetDlgItemInt>         ; \GetDlgItemInt
004019E7   . 803D 1DA84700 >CMP BYTE PTR DS:[47A81D],0
004019EE   . 0F84 1D030000  JE cr2.00401D11

This reads entered numerical Code, if "not OK" goes to 401D11

004019F4   . 50             PUSH EAX ; entered code -> to stack
004019F5   . 33F6           XOR ESI,ESI
004019F7   . 33C0           XOR EAX,EAX
004019F9   . 33D2           XOR EDX,EDX
004019FB   . 33DB           XOR EBX,EBX
004019FD   . 33C9           XOR ECX,ECX
004019FF   > 8D35 94A84700  LEA ESI,DWORD PTR DS:[47A894] ; Entered name
00401A05   > 0FBE06         MOVSX EAX,BYTE PTR DS:[ESI]
00401A08   . 8BD8           MOV EBX,EAX
00401A0A   . 2BF2           SUB ESI,EDX
00401A0C   . C1E0 0E        SHL EAX,0E
00401A0F   . C1EB 0D        SHR EBX,0D
00401A12   . 33C3           XOR EAX,EBX
00401A14   . 05 62226254    ADD EAX,54622262
00401A19   . 33C1           XOR EAX,ECX
00401A1B   . 03C8           ADD ECX,EAX
00401A1D   . 46             INC ESI
00401A1E   . 803E 00        CMP BYTE PTR DS:[ESI],0
00401A21   .^75 E2          JNZ SHORT cr2.00401A05
00401A23   . B8 36927A08    MOV EAX,87A9236
00401A28   . 2BC1           SUB EAX,ECX
00401A2A   . 0FAFC0         IMUL EAX,EAX
00401A2D   . 5B             POP EBX ; entered code <- from stack
00401A2E   . 33C0           XOR EAX,EAX
00401A30   . 03C8           ADD ECX,EAX
00401A32   . 3BCB           CMP ECX,EBX ; comparing entered (ebx) and computed (ecx) code
00401A34   . 0F84 B6020000  JE cr2.00401CF0
00401A3A   . E9 B2010000    JMP cr2.00401BF1

So to know code for your entered name, just breakpoint at address 401a32, after breakpoint plays,
double-click ECX in Registers frame of CPU window, Select Unsigned number and copy it to clipboard.
It is your personal code.

5. Keygenning. I write keygen with FASM.

Part of keygen sourcecode (WM_COMMAND Message from BUTTON Generate handler)
        invoke  GetDlgItemText,[hwnddlg],ID_NAME,name,20
        mov esi,name
        xor edx,edx
        xor eax,eax
        xor ecx,ecx
   .loop1:
        movsx eax, byte [esi]
        mov ebx, eax
        sub esi, edx
        shl eax,0eh
        shr ebx,0dh
        xor eax,ebx
        add eax,54622262h
        xor eax,ecx
        add ecx,eax
        inc esi
        cmp byte [esi],0
        jnz .loop1
        invoke  SetDlgItemInt,[hwnddlg],ID_CODE,ecx,0
