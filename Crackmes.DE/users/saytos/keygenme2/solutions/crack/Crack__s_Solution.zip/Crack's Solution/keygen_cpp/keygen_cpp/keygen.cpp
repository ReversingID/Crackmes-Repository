// program is linked with cryptlib v5.4
// icon is extracted from keygenme with reshack

#include <windows.h>

#include <cryptopp\md5.h>
#include <cryptopp\tea.h>

#include "resource.h"

INT_PTR CALLBACK DlgFunc(HWND, UINT,WPARAM, LPARAM);

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstace, PSTR szCmdLIne, int iCmdShow)
{
	DialogBoxParam( hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, &DlgFunc, NULL);
	ExitProcess(0);
}

INT_PTR CALLBACK DlgFunc(HWND hWin, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	const char	szFormat[] = "%.2x%.2x%.2x%.2x";
	const byte	tea_key[] = {'c','r','a','c','k','m','e','s','\0','H','m','m',',','b','u','t'};

	CryptoPP::MD5*	md5;
	CryptoPP::TEAEncryption*	tea;
	char	lpszName[21];
	UINT	uiLenName;
	byte	byTemp[50];
	char	szTemp[9];
	char	szSerial[50];
	int		x;

	switch(uMsg){
		case WM_INITDIALOG :
			SetDlgItemTextA(hWin, IDC_EDT_NAME, "crack");
			SendMessage(hWin, WM_COMMAND, IDC_BTN_GENERATE, 0);
			break;
		case WM_COMMAND :
			switch(LOWORD(wParam)){
				case IDC_BTN_GENERATE:
					uiLenName = GetDlgItemTextA(hWin, IDC_EDT_NAME, lpszName, 0x14);
					switch(uiLenName){
						case 0:
							SetDlgItemTextA(hWin, IDC_EDT_NAME2, "Enter your name please");
							break;
						case 1:
						case 2:
						case 3:
							SetDlgItemTextA(hWin, IDC_EDT_NAME2, "name is to short");
							break;
						default:
							md5 = new CryptoPP::MD5;
							tea = new CryptoPP::TEAEncryption;

							// 1. part of serial: md5(NAME)
							md5->CalculateDigest(byTemp, (const byte*)lpszName, (size_t)uiLenName);
							szSerial[0]='\0';
							for(x=0;x<16;x+=4){
								wsprintfA(szTemp, szFormat, byTemp[x], byTemp[x+1], byTemp[x+2], byTemp[x+3]);
								lstrcatA(szSerial, szTemp);
							}

							lstrcatA(szSerial, "-");

							// 2.part of serial: tea(NAME, KEY)
							tea->SetKey(tea_key, 16);
							tea->ProcessBlock((const byte*)lpszName, (byte*)byTemp);
							for(x=4;x>=0;x-=4){
								wsprintfA(szTemp, szFormat, byTemp[x+3], byTemp[x+2], byTemp[x+1], byTemp[x]);
								lstrcatA(szSerial, szTemp);
							}

							//3.part of serial: change some bytes
							szSerial[6] = 'C';
							szSerial[20] = 'X';
							szSerial[31] = '$';

							SetDlgItemTextA(hWin, IDC_EDT_NAME2, szSerial);

							delete md5;
							delete tea;
							break;
					}
					break;
			}
			break;
		case WM_CLOSE :
			EndDialog(hWin, 0);
			break;
		default :
			return(false);
			break;
	}

	return(true);
}