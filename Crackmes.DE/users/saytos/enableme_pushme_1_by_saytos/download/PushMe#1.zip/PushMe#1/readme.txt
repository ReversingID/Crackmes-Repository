.:.:. EnableMe & PushMe #1 .:.:.
---------------------------------
Author      : saytos
Compiled in : asm
Problem     : Patch this crackme,enable button "Push me".If press on button,
              you must see good_boy message.Plz write a solution and send
              to crackmes.de!!! :)
Test        : WinXp SP2
Greets goes to all people on crackmes.de and YOU!

saytos
      2006

