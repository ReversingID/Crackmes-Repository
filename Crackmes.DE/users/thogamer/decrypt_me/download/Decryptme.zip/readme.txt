*********Thogamer's first decrypt me*********

1) The Challenge: You must find the key to decrypt the message.
2) Some info about the decrypt me: The decrypt me uses a Polyalphabetic cipher to encrypt/decrypt the message.
3) Hint: 306
4) Restrictions: NONE! but I need a key that works with the original version.
5) Difficulty: 5 BUT if you don't know anything about Polyalphabetic cipher 7.