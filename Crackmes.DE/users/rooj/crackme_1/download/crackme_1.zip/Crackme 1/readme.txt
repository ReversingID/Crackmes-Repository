 
        |insert 1337 ascii image here :P|

RooJ Crackme 1

Your Goal:

Simply find the correct serial. Optionally and preferably you can also write a tutorial on how you did it and send to me: quibus_umbra@hotmail.com

Happy Cracking :D

RooJ.

========
for every coder, theres an equal and opposite decoder.