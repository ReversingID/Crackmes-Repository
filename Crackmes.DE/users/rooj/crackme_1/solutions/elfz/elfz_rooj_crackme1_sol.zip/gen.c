// elfz, 2004
#include <conio.h>
#include <stdio.h>

int main() {

  unsigned char* secret = "phlftp|\x80\x88xtxv";
  unsigned i = 1;

  printf("\npass decoder for RooJ Crackme 1\n");
  
  do {
    unsigned t = secret[i - 1];
    unsigned q = t % 10;
    switch(q) {
      case 1: // MS CPP doesn't like case 1,3,5,7,9 by default
      case 3: // but I like if I can compile it by cl gen.c
      case 5: // without specifying any flags
      case 7: 
      case 9: {
        printf("IMPOSSIBLE!");
        break;
      }
      case 2: {
        // 1+1, 6+6
        printf("[%c%c]", t - 1 - i, t - 6 - i);
        break;
      }
      case 4: {
        // 2+2, 7+7
        printf("[%c%c]", t - 2 - i, t - 7 - i);
        break;
      }
      case 6: {
        // 3+3, 8+8
        printf("[%c%c]", t - 3 - i, t - 8 - i);
        break;
      }
      case 8: {
        // 4+4, 9+9
        printf("[%c%c]", t - 4 - i, t - 9 - i);
        break;
      }
      case 0: {
        // 0+0, 5+5
        printf("[%c%c]", t - 0 - i, t - 5 - i);
        break;
      }
    }
  } while(secret[i++]);
  
  printf("\nany key to quit");
  getch();
  
  return 0;
}