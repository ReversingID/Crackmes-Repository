Name: Button Race
Author: RooJ
Level: 1
Language: VB6

Aim:
Create a keygen so that anyone can register the game with any password. Also make a tutorial of how you did it and send to me: quibus_umbra@homail.com :).

Comments:
Ok.. i got bored and decided to turn an old game i made years ago into a simple crackme. The game itself is quite badly coded so try to ignore it and concentrate on cracking :P.  I warn you that i did rush this one out as a bit of fun so dont be too dissapointed with it.

*Note for the game, if you win a race your bet is doubled and sent back to you. If you lose you just lose your bet.

Happy cracking.

RooJ

==================
For every coder theres an equal and opposite decoder.