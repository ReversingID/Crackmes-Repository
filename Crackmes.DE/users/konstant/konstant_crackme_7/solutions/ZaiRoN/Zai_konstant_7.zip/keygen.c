#include <stdio.h>

void main(void)
{
	char hKey[36] = "";
	char ser[29] = "8310111410597108105122101114";
	int i;

	printf("Insert your hardware key: ");
	scanf("%s",&hKey);

	printf("\nYour serial is: ");
	for(i=0;i<strlen(hKey);i++)
	{
		printf("%02X", hKey[i]^ser[i]);
	}
	getch();
}

