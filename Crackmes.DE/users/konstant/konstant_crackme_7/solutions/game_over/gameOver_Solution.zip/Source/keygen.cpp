#include <windows.h>
#include <stdio.h>
#include "keygen.h"
#include "resource.h"


HINSTANCE hInst;

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{  
	hInst = hInstance;
	DialogBox(hInst, MAKEINTRESOURCE( IDD_DIALOG ), 0, (DLGPROC) DialogProc);
	return(0);
 }


LRESULT CALLBACK DialogProc( HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	int length,i; 
	char Serializer[] = "831011141059710810512210111483", Serial[31] = "", Key[61] = "", Calculated[3] = "";

	switch (uMsg)
	{
		case WM_INITDIALOG :
			SetWindowText(hDlg,"Game-Over");
			break;	
		case WM_LBUTTONDOWN :
			SendMessage(hDlg,WM_NCLBUTTONDOWN,HTCAPTION,0);
			break;	
		case WM_COMMAND :
			switch (LOWORD (wParam))
			{
				case IDC_SERIAL:
					GetDlgItemText(hDlg,IDC_SERIAL,Serial,31);
					length = strlen(Serial);
					for(i=0;i<length;i++)
					{
						sprintf(Calculated,"%02X",Serial[i]^Serializer[i]);
						strcat(Key,Calculated);
					}
					SetDlgItemText(hDlg,IDC_KEY,Key);
					break;
				case IDEXIT :
					EndDialog( hDlg, IDEXIT);
					break;
			}
		default : return(0);
	}
	
	return(1);
}
