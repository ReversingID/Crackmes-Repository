konstAnt Crackme 7
=-=0-=-=-=-=-=-=-=
Yet another crackme by konstAnt.. And this time is a keygen me...:P

Not a system utility this time... A crackme after a long time....:lol
All u have to do is find a serial for the hardware code.. and make a keygenerator....

Think it would be easy and u'll have fun keygening nothing good trick...
But some confusing one and I'll like to rate it 8/10

And won't be angry only if one of he solver suggests to lower the level of the crackme...

:P

[Hintz]
Every thing including the serial checking goes in the serial.dll:P If u can find it

Greetz:
Oorjahalt{Perhaps the spelling is worng, I missed him a lot and welcome back again}
_khAttAm_
[A]bu
TDCNL
Rem Members 
and all crackmes.de members