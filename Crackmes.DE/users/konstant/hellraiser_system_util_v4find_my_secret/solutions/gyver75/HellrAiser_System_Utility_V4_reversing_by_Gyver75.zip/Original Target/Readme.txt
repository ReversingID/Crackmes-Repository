Yet another system utility. This one is Find my Secret.

Well the rulz are simple. Unpack it. Find a valid secret(pAssword) to
move the buffer slider. No patching allowed.

Have fun.

Thanks to _khAttAm_ for inviting me in his group and 
crackmes.de for choosing me as top coder in such a 
small interval.