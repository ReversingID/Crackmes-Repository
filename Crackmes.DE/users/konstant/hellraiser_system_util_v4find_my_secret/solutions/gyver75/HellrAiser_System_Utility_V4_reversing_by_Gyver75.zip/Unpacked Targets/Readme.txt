These files are unpacked:

1 - fastcopy Fixed.exe             .... Main target;
2 - hellrAiser.fms first layer.exe .... Internal Loader; 

I put also "fastcopy.tmp" ( original packed version of "fastcopy Fixed.exe" )
inside this folder because, without of this, the loader doesn't work!