Hey,

Crackers wanna some patching. Try this.
Ok no rules, Only patch the exe and 
unnag it. so that nothing bothers you.

Well, This one has no higher rating.

Only 5/10....

Ok no extra protection used.
