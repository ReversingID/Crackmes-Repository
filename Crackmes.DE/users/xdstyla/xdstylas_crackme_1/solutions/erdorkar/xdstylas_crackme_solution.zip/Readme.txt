CrackMe #1 by xdstyla

Hint: There's ony one right Serial.

written in C++

Goal:
Find the right serial.