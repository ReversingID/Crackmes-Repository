Let this small app work fine(!) with Ollydbg. Do not change any jumpcommands, patch the code as less as you can to lead it to the good message. 

There are 4 antidebug/-olly "methods". (Some are easy, some are hard)

Please explain the methods in your solution.