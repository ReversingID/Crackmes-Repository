You can patch it you can keygen it. But if you really want to solve it then keygen it.

I thinks its pretty easy for newbies.