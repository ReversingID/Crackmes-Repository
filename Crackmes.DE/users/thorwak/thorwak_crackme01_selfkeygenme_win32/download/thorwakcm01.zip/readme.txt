2008-06-03

Thorwak Crackme 01

This is my first crackme. In fact, it's
my first Windows program. Ever. I started
learning yesterday so please don't expect
too much =)

I want a keygen for this crackme. Since it's
my first one, self-keygen is enough. Also,
this is to enable more ppl to post a solution.
Obviously, complete reversal and writing
a standalone keygen gives extra creds though! :)

Please do comment, good or bad!

Written in native Win32 using VC++ Express.