Good evening,

That was I big challenge. Maybe I missed something during analysis,
or maybe I have some mistakes in the solution. If there's anything 
that you think that I have to rewrite/review it, feel free to tell
me and correct it asap.

Best Regards,
-Ispo