import binascii

"""
converts a string to a list of numbers
"""
def s2b( string ):
	return [ord(c) for c in string]

"""
represents a single byte to bruteforce, it is a pair
of clear text and cypher text, and an offset into the
cleartext file
"""
class Pin:
	def __init__(self, cyphertext, clear_byte, offset):
		self.clear_byte = clear_byte

		self.block_idx = offset / 16
		self.block_offset = offset % 16

		# get the cypher byte from cypher file
		cyphertext.get_cypher_pin(self)

"""
represents the cyphertext file, organized in 16-bytes blocks
"""
class CypherText:
	def __init__(self, fileName):
		f = file(fileName)
		self.contents = f.read()[4:]

	def get_cypher_block(self, block_idx):
		end = (block_idx+1)*16
		if end > len(self.contents):
			end = len(self.contents)
			
		return s2b(self.contents[block_idx*16:end])

	def get_cypher_pin(self, pin):
		block = self.get_cypher_block(pin.block_idx)
		pin.cypher_byte = block[pin.block_offset]

	def get_num_blocks(self):
		nblocks = len(self.contents) / 16
		if len(self.contents) % 16 > 0:
			nblocks += 1

		return nblocks


"""
tools related to the Crypter algorithm
"""
class Crypter:
	shuffle = [ 0x8, 0xA, 0x0, 0x1, 0x9, 0xC, 0xF, 0x3, 0x6, 0x2, 0xD, 0xE, 0x4, 0x2, 0x5, 0x7 ]

	"""
	derive a key from master key and previous key (only one byte)
	"""
	def generate_key_byte(self, mk_byte, gk_byte):
		gk = gk_byte
		for i in range(5):
			gk = (self.shuffle[(gk / 16)] * 0x10) + self.shuffle[(gk % 16)]
			gk = (gk + mk_byte) & 0xFF
		return gk

	"""
	derive a key from master key and previous key (16-bytes block)
	"""
	def generate_key(self, master_key, generate_key):
		for i in range(5):
			for j in range(16):
				nr = generate_key[j]
				generate_key[j] = (self.shuffle[(nr / 16)] * 0x10) + self.shuffle[(nr % 16)]

			for j in range(16):
				generate_key[j] = (generate_key[j] + master_key[j]) & 0xFF

		return generate_key

	"""
	get the first key of the possible keys, given a cypher block
	and its cleartext equivalent
	"""
	def brute_v2(self, cypher, clear, passes):
		missing = set(range(len(cypher)))
		key = [0] * len(cypher)
		for c in range(0,256):
			gk = 0
			for j in range(passes):
				gk = self.generate_key_byte(c, gk)
			
			for i in range(len(cypher)):
				if i not in missing:
					continue

				decr = cypher[i] ^ gk
				if decr == clear[i]:
					key[i] = c
					missing.remove(i)
					if len(missing) == 0:
						return key

		return key


	"""
	decrypt a cypher block using the given master key,
	and the given passes for key derivation
	"""
	def decrypt(self, cypher, master_key, passes):
		clear = [0] * len(cypher)	
		
		for i in range(len(cypher)):
			gk = 0
			for j in range(passes):
				gk = generate_key_byte(master_key[i], gk)
			clear[i] = cypher[i] ^ gk

		return clear

	"""
	decrypt the whole cyphertext file into the given outputFileName,
	given the master key
	"""
	def decrypt_to_file(self, cypher, master_key, outputFileName):
		
		of = file(outputFileName , 'w')
		g_key = [0] * 16

		self.generate_key(master_key, g_key)

		for block_idx in range(cypher.get_num_blocks()):
			self.generate_key(master_key, g_key)
			block = cypher.get_cypher_block(block_idx)

			clear = [0] * len(block)

			for i in range(len(block)):
				clear[i] = block[i] ^ g_key[i]
			
			of.write(bytearray(clear))


		of.close()

	"""
	decrypt a single block of cypher file
	"""
	def decrypt_file_block(self, cypher, master_key, block_index):
		block = cypher.get_cypher_block(block_index)
		return self.decrypt(block, master_key, block_index+2)

	"""
	display a block of bytes in hex values (friendly to hex editors)
	"""
	def draw_key(self, list):
		print " ".join(["{:02X}".format(c) for c in list])


	"""
	find all possible keys for a cypher/clear pair of bytes
	"""
	def brute_v3_byte(self, cypher, clear, passes):
		candidates = set()
		for c in range(0,256):
			gk = 0
			for j in range(passes):
				gk = self.generate_key_byte(c, gk)
			
			decr = cypher ^ gk
			if decr == clear:
				candidates.add(c)

		return candidates

	"""
	try to find a key that simultaneosly satisfy a list of
	pins (clear/cypher byte pairs)
	"""
	def satisfy_pins(self, pins, master_key):
		by_block_offset = {}

		for pin in pins:
			if pin.block_offset not in by_block_offset:
				by_block_offset[pin.block_offset] = [ pin ]
			else:
				by_block_offset[pin.block_offset] += [ pin ]

		allok = True

		for it in by_block_offset.items():
			bo = it[0]
			pins = it[1]
			candidates = None
			for pin in pins:
				cand = self.brute_v3_byte(pin.cypher_byte, pin.clear_byte, pin.block_idx+2)

				if candidates == None:
					candidates = cand
				else:
					candidates = candidates.intersection(cand)
			if len(candidates) == 1:
				master_key[bo] = list(candidates)[0]
				print "setting byte " + str(bo) + " to value " + hex(master_key[bo])
			else:
				allok = False


"""
calculate 16-bit MSDOS timestamp
"""
def msdos_time(hours, minutes, seconds, day, month, year):
	s = (seconds >> 1) & 31
	m = minutes & 63
	h = hours & 31

	time = s | (m << 5) | (h << 11)

	d = day & 31
	mo = month & 15
	y = (year - 1980) & 127

	date = d | (mo << 5) | ( y << 9) 


	return binascii.hexlify(bytearray([time & 0xFF, (time & 0xFF00) >> 8, date & 0xFF, (date & 0xFF00) >> 8]))



if __name__ == "__main__":

	cypher = CypherText("crackme/crackme.zip.enc")
	cr = Crypter()

	# first guess of first 16 bytes ZIP header
	clear_header = s2b( binascii.unhexlify("504B0304140001000100" + msdos_time(6, 40, 58, 16, 9, 2014) + "0000"))
	#clear_header = s2b( binascii.unhexlify("504B0304140001000100" + msdos_time(7, 02, 00, 16, 9, 2014)+ "0000"))
	cypher_header = cypher.get_cypher_block(0)


	master_key = cr.brute_v2(cypher_header, clear_header, 2)


	# re-calculate single key bytes, setting clear text "pins"
	# this can take some time (about 1 minute on macbook i7)
	cr.satisfy_pins([
		Pin( cypher, ord('x'), 38 ), 
		Pin( cypher, ord('M'), 360582 ), 

		Pin( cypher, ord('A'), 32 ), 
		Pin( cypher, ord('P'), 0 ), 

		Pin( cypher, ord('R'), 30 ), 
		Pin( cypher, ord('H'), 360670 ), 

		Pin( cypher, ord('E'), 31 ), 
		Pin( cypher, ord('a'), 360671 ), 

		Pin( cypher, ord('p'), 360680 ), 
		Pin( cypher, ord('.'), 360584 ), 

		Pin( cypher, ord('H'), 245 ), 
		Pin( cypher, ord('t'), 37 ), 

		Pin( cypher, ord('0'), 12 ), 
		Pin( cypher, ord('n'), 252 ), 


		], master_key)

	# here is the final master_key
	cr.draw_key(master_key)

	# write cleartext output file file
	cr.decrypt_to_file(cypher, master_key, "myOutput.zip")
