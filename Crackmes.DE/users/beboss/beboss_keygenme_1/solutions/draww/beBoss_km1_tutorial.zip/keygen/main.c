#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <time.h>

int main(int argc, char *argv[])
{
    char n[11]="0123456789";
	char serial[50];
    srand((unsigned) time (NULL));
	system("TITLE beBoss KeyGenMe #1 Keygen");
    system("COLOR 0D");
	printf("\n beBoss KeyGenMe #1 Solution\n");
	printf(" draww @ crackmes.de // 15.01.2011\n\n");
	printf(" Press ESC to exit.. Any other key will continue!\n\n");

	keygen:
	sprintf(serial, "%c44%c%c%c%c%c%c%c66%c%c7%c%c%c%c%c5507%c%c%c%c%c",	n[rand()%10],n[rand()%10],n[rand()%10],n[rand()%10],
    					n[rand()%10],n[rand()%10],n[rand()%10],n[rand()%10],n[rand()%10],n[rand()%10],n[rand()%10],n[rand()%10],
						n[rand()%10],n[rand()%10],n[rand()%10],n[rand()%10],n[rand()%10],n[rand()%10],n[rand()%10],n[rand()%10],
						n[rand()%10],n[rand()%10],n[rand()%10],n[rand()%10]);
	printf(" %s2%s\n",serial,serial);

	while (_getch() != 27)
	{
    goto keygen;
	}
	return 0;
}
