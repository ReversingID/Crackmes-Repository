//bf.c

#include <windows.h>
#include <stdio.h>

#pragma comment(linker,"/MERGE:.rdata=.text")
#pragma comment(linker,"/FILEALIGN:512 /SECTION:.text,EWRX /IGNORE:4078")

int main(int argc, char* argv[])
{
	int len=0;
	int var=0;

	__asm {

brut:
        mov ecx, 0DEADC0DEh                  ; Ecx=DEADCODE
        mov eax, dword ptr ss:[len]          ; Eax = len(Key)
        mov bl, 1
        bswap eax
        rol eax, 6
        xor eax, ecx
        mov bl, al
        xor bl, cl
        mov al, bl
        mov dword ptr ss:[var], eax
   
        xor dword ptr ss:[var], 0B00h
        cmp dword ptr ss:[var], 0B000C0DEh
	jz _END
_Inc:
	inc len
	jmp brut

_END:
	}

	// Print needed length 
	printf("Length %X, %u", len, len);
	
	// press char
	getchar();


	return 0;
}
