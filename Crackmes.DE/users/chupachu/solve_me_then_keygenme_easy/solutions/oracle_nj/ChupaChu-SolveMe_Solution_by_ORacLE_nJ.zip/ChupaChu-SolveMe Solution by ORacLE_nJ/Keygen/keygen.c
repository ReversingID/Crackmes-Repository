
#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <time.h>
#include <windows.h>
#include "resource.h"


void partA(char *ret)
{
	char n[]="CHUPACHU",r[9]={0},buff[5]={0};
	unsigned long int i=0;
	int u[] =
	{
		0x00, 0x07, 0x0D, 0x14, 0x14, 0x02, 0x0C, 0x0C, 0x10,
		0x00, 0x17, 0x03, 0x02, 0x67, 0x64, 0x06, 0x0A, 0x64,
	};

	for(i=1;i<=strlen(n);i++)
		r[i-1] =n[i-1] ^ u[i];

	strcat(ret,r);
	return;
}


void partB(char *ret)
{
	char tmp[5]={0};
	int t,a,b,c,d;
	SYSTEMTIME st;

	// Random Number Generation
	// I'm experimenting a lot there days!!
	GetSystemTime(&st);
	t=st.wMilliseconds;

	a=t%10;	t/=10;
	b=t%10;	t/=10;
	c=t%10;	t/=10;
	d=(c+1)%10;

    sprintf(tmp,"%d%d%d%d",a,b,c,d);

	for(;;)
		for(;;tmp[3]++)
			if(tmp[0]+tmp[3] == 0x66)
			{
				if(isprint(tmp[3]))
				{
					strcat(ret,tmp);
					return;
				}
				else
				{
					tmp[3]='0';
					continue;
				}
			}
}

void SerialGenerate(char *ret)
{
	char static buffA[10],buffB[5],join,serial[25]={0};

	strncpy(buffA,"",sizeof(buffA));
	strncpy(buffB,"",sizeof(buffB));

	partA(&buffA[0]);
	partB(&buffB[0]);
	
	join = ((0x0F0FF - 0x0F0F0) & 0x0FF) ^ 0x22;

	sprintf(serial,"%s%c%s",buffA,join,buffB);

	strcat(ret, serial);
}





HINSTANCE	hInst;

BOOL CALLBACK DialogProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	char serial[25]={0};


	switch (message)
	{    
	case WM_CLOSE:
		EndDialog(hWnd,0);
		break;

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{ 
		case IDC_GENERATE:

			SerialGenerate(&serial[0]);

			SetDlgItemText(hWnd,IDC_1,&serial[0]);
			
			break;

		case IDC_ABOUT:
			MessageBox(hWnd, "ChupaChu-solve_me KeyGenerator By ORacLE_nJ", "About", MB_OK);
			break;
		}
		break;

	case WM_INITDIALOG:
		SendMessageA(hWnd,WM_SETICON,(WPARAM) 1,(LPARAM) LoadIconA(hInst,MAKEINTRESOURCE(IDI_ICON)));
		break;
	}
     return 0;
}



int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{
	hInst=hInstance;
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, (DLGPROC)DialogProc,0);
	return 0;
}