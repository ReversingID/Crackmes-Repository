
 -=[ Bumpy Flea CrackMe #1 Solutions ]=-

 infos: VB6-coded and compiled to P-Code :)
 tools: SoftICE and ExDec (and fc :)
 
 Yap, it's me again. Anyway, let's go on. Btw, this is NOT a cracking
 walkthrough, so no dasms here. This was intended to be just a solution
 really, so just mail for any questions or anything else :)

 1. Remove Me (nag)
 ---
 Anyway, since it's P-Coded, this is kinda tricky to patch coz we'll
 be using ExDec and our own intuition only, no debugger. In P-Code,
 inverting jumps could be also simple like a "jz" to "jnz" type :) But
 in this case, we're NOT inverting any jumps coz there's NO jump to
 invert in the first place. So we have to make one :) And here it is:
 ...
 Comparing files CRACKME1.BAK and CRACKME1.EXE
 00004C87: 4E 1E
 00004C88: 5C 26
 00004C89: FF 00
 ...
 The difference you'll see when you decompile both files. Btw, this
 patch simply bypasses the call to rtcMsgBox and the parameters are
 still pushed. So there are other (and better) ways to patch it.

 Level 1 Menu:

 2. Password
 ---
 Yah, it's: bUmPy FlEa 1799. Hard-coded. ExDec makes this very easy :)
 Btw, there's a fake code and even a length check too!

 3. Enable Me
 ---
 This is just a simple flag switch located after the name of the menu.
 Now here it is:
 ...
 Comparing files CRACKME1.bak and CRACKME1.EXE
 00001BC3: 05 06	     ; (note: 05=disabled; 06=enabled)
 ...

 Level 2 Menu:

 4. Serial Code
 ---
 Ok, like in w32dasm, search for String Refs in my.txt (from ExDec)
 related to this. Afterwards, page up, you'll see the length check of > 6.
 Page down and you'll see:
 ...
 4052F6: f3 LitI2:           0x4352   17234   (.C) ; note the middle # :)
 4052F9: Lead0/fc CStrI2     ; tracing in SI, you'll see it's converting
                             ; from hex to decimal to string which is
                             ; to be used as a prefix :)
 4052FB: 23 FStStrNoPop      local_0110
 4052FE: 08 FLdPr            local_param_0008
 405301: 89 MemLdI2          local_param_0034
 405304: Lead0/fc CStrI2     ; And again? But what to convert? Yep, the
                             ; value loaded in memory (see prior code).
                             ; So search my.txt for "local_param_0034".
                             ; After, you'll know it's the keygen routine!
 405306: 23 FStStrNoPop      local_0114
 405309: 2a ConcatStr        ; concatenate strings (ie. "17234"+SERIAL)
 40530A: 23 FStStrNoPop      local_0118
 40530D: Lead0/3d NeStr            
 40530F: 32 FFreeStr
 40531A: 1a FFree1Ad         local_0088
 40531D: 1c BranchF:         40536D  ; jump if not equal
 ...
 So to sniff the serial, in SoftICE (using Symbol Loader), bpm 405309.
 Trace with F8/F10. I preferred F8 coz I wanted to enter the ConcatStr call
 coz of the parameters :) Anyway, here's just the main part:
 ...
 for (ctr=0; ctr<strlen(name); ctr++) {
      tmp=(name[ctr]*ctr);
      ser+=tmp;
 }
 printf("\nSerial: 17234%lu", ser);
 ...
 So there, it shouldn't do any problems. Though sometimes, serials become
 incorrect coz of a buffer problem. In that case, register anew (probably
 under a new name ;) Yes, small C code compared with P-Code :)

 Sample Reggo: (coz too lazy to code :)
 name: Sphinxter
 code: 172343990

 Level 3 Menu:

 5. Solve The Patterns
 ...
 Ok, this is kinda easy as well coz the author didn't use any sort
 of calcus whatsoever, it just compares it 1x1 :) And also the correct
 values for the slidebars can be seen right before your eyes in my.txt :)
 Ok, here's the common pattern:
 ...
 40543C: 04 FLdRfVar         local_008A
 40543F: 21 FLdPrThis              
 405440: 0f VCallAd          check
 405443: 19 FStAdFunc        local_0088
 405446: 08 FLdPr            local_0088
 405449: 0d VCallHresult     _CCHECK_vtbl::get__ipropVALUECHECK
 40544E: 6b FLdI2            ocal_008A
 405451: f4 LitI2_Byte:      0x1  1  (.)     ; 1 = should-be-checked flag
 405453: c6 EqI2             ; check equality; bpm in SoftICE to check
 ...
 And there are 8 hits of this with 0x1's in them. So this means that
 there should be 8 checks :) And from the 9th onwards, it compares it
 with 0, meaning those ones shouldn't be checked :) A snapshot is saved
 to Patterns.jpg. Btw, is this kind of protection seen in REAL apps?

 Well, that's it. No ASM code coz P-Code (and I haven't tried out the
 VB debugger yet :) Yep, P-Code programs could easily (most of the time)
 be cracked using ExDec ONLY, coz sometimes (if not always) SoftICE
 alone will give garbage (makes your head ache tracing :)

 Greets to: josephCo, The+Q, BlackB, McCodEMaN, tnHuAn, TRES2000 and, of
 course, Bumpy Flea for the CrackMe :)

 Later, Sphinx [sphinxter@edsamail.com.ph]			[12/30/01]
