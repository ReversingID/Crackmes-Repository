Video Solution to costy's anti reflector CrackMe
Solved by MACH4

Tools:
reflector
Visual studio
IlDasm

If you have problems with the flash video screen size, Google for "SWF Opener" by UnH Solutions, I wouldn't be without it!

Greetz to costy, Crackmes.de and all members!

MACH4.