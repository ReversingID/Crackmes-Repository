/*
Bispoo Trainer 1.0 (c) 2008
Version Info:
1.0  Tidied up some code, increased overall performance , Added an icon :P
0.5  Added Set Debug Privilege Function to attach to all processes
0.1  initial version, cant attach to some processes because permition, 
	 Used GetProcessList( ) function coded by  " muhko "
*/
#include <windows.h>
#include <tlhelp32.h>
#include "resource.h"

#pragma comment(linker,"/MERGE:.rdata=.text /MERGE:.data=.text /SECTION:.text,EWR")

BOOL GameRunning;
BOOL GetProcessList( );

char *about   =								//The button about will display this text
"Bispoo Trainer V1.00\n"
" \n"
"Greets go out to:\n"
"Costy, All Crackme.de Members\n"
" \n"
"Copyright Bispoo (c) 2008";
/////////////////////////////////////////////////////////////////////
char *gameWindow = "Videogame Setup.exe"; //  HERE WE ASSIGN THE GAME EXE WE ARE GONNA ASSASINATE :P

DWORD pid; HWND hwndWindow; DWORD bytes; HANDLE hand = NULL; // The Variables to maintain the target exe
HANDLE pFile;

BOOL IsHack1On, IsHack2On, FirstTimeRunning; // The Booleans for toggling function

////Global Variables

	BYTE curscore[3] = {0};								//The Score Hacker  !!
	BYTE NOP[2] = {0x90, 0x90};							// this is a 2 Byte NOP

	BYTE original_code1[2] = {0}; // The variables to store the unchanged code before changing it
    //BYTE original_code2[3] = {0}; // so when we disable the hack it restores the patched code
	

///////////////////////////////////////////////////////

BOOL SetDebugPrivilege()   // SET DEBUG PRIVILEGE ON THE GAME PROCESS WE ARE ATTACHING OTHERWISE SOME GAMES
{						   // WILL NOT LET YOU ATTACH :P
HANDLE hToken;
BOOL bOK = FALSE;

if (OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken))
{
if (!SetPrivilege(hToken, SE_DEBUG_NAME, TRUE))
{
 bOK = FALSE;
}
else
bOK = TRUE;
CloseHandle(hToken);
}
else
 bOK = FALSE;
return bOK;
}

BOOL SetPrivilege( HANDLE hToken, LPCTSTR lpszPrivilege, BOOL bEnablePrivilege )
{
TOKEN_PRIVILEGES tp;
LUID luid;
TOKEN_PRIVILEGES tpPrevious;
DWORD cbPrevious = sizeof(TOKEN_PRIVILEGES);

if(!LookupPrivilegeValue( NULL, lpszPrivilege, &luid ))
return FALSE;

// 1) Get current privilege setting
tp.PrivilegeCount = 1;
tp.Privileges[0].Luid = luid;
tp.Privileges[0].Attributes = 0;

AdjustTokenPrivileges(hToken, FALSE, &tp, sizeof(TOKEN_PRIVILEGES), &tpPrevious, &cbPrevious);
if (GetLastError() != ERROR_SUCCESS)
return FALSE;

// 2) Set privilege based on previous setting
tpPrevious.PrivilegeCount = 1;
tpPrevious.Privileges[0].Luid = luid;
if (bEnablePrivilege)
tpPrevious.Privileges[0].Attributes |= (SE_PRIVILEGE_ENABLED);
else
tpPrevious.Privileges[0].Attributes ^= (SE_PRIVILEGE_ENABLED & tpPrevious.Privileges[0].Attributes);

AdjustTokenPrivileges( hToken, FALSE, &tpPrevious, cbPrevious, NULL, NULL );
if (GetLastError() != ERROR_SUCCESS)
return FALSE;

return TRUE;
}


void aboutButton(HWND hwnd)
{
	MessageBox(hwnd,about,"About",MB_ICONINFORMATION);
}


void Initialize(HWND hwnd,WPARAM wParam, LPARAM lParam) {
	GetProcessList();	// look up for our process in process list
	SetDebugPrivilege();	// set up the debug privilege so we can attach

	FirstTimeRunning=TRUE; // Set the FirstTime Flag to true so the trainer stores the Original Values / Code
					// in the variables original_codeX that i defined up above when it starts
	IsHack1On=FALSE; 
	IsHack2On=FALSE; 

	if(GameRunning==TRUE)
	{		 
         GetWindowThreadProcessId(hwndWindow, &pid);
		 hand = OpenProcess(PROCESS_ALL_ACCESS,0,pid);
		 SetTimer(hwnd, 1, 500, NULL);	// Set up a timer with 500ms , so we check for keypress
										// and enable disable hack's etc...
	} 
	else 
	{ //Error message when target exe is not found in process's
		MessageBox(NULL, "Run the game (Videogame Setup.exe) Before the Trainer!!!", "Game not running...", MB_OK + MB_ICONWARNING);
		EndDialog (hwnd, 0);
	}

}

void HookExe() //This function Hook's to the target exe
{
	CloseHandle(hand);
	GetProcessList( );
	GetWindowThreadProcessId(hwndWindow, &pid);
	hand = OpenProcess(PROCESS_ALL_ACCESS,0,pid);
}


void timerCall() // Out Timer ,  The Functions here are called at the rate defined Above (500 ms)
{
		HookExe(); 
	
	if(FirstTimeRunning==TRUE) //checks to see if this is the first time its run, if it is continue
	{
		// reads the bytes at address Defined (0x4283BE) and stores them in our variables
		// so we can restore it when we disable the hack
		//              handle,  Address to Read,store in:,   n�of Bytes, number of bytes written
		ReadProcessMemory(hand, (void*)0x4283BE , &original_code1, 2, &bytes);
		
		//no need to backup this one since we are altering memory values, not code
		//ReadProcessMemory(hand, (void*)0x0041d292 , &original_code2, 3, &bytes);

		FirstTimeRunning=FALSE;  // Set Variable to false because the original values are already backed up
	}
	
	// Here we check for Keypresses and do the according changes

    if(GetAsyncKeyState(VK_NUMPAD1))
	{			
		   
		if(IsHack1On==FALSE) // if the hack is OFF and we are turning it ON:
			{  
				// Write the modified code into memory. The NOP we defined above as a 2 byte nop
				WriteProcessMemory(hand, (void*)0x4283BE, &NOP, 2, &bytes);
 				IsHack1On=TRUE; // Change the variable so we know the Hack1 is Turned on
			}
			else // if the hack is on and we are turning it OFF
			{
				// Restore back the original code / Memory value
				WriteProcessMemory(hand, (void*)0x4283BE, &original_code1,2, &bytes); 
				IsHack1On=FALSE; //Change the variable so we know the Hack1 is Turned OFF
			}
	}

	if(GetAsyncKeyState(VK_NUMPAD2)) 
	{			
			
		ReadProcessMemory(hand, (void*)0x0041d292 , &curscore, 3, &bytes); // Retrieve the Current Score to Variable curscore
		curscore[0]+= 0x40;	curscore[1]+= 0x42;	curscore[2]+= 0x0F; // Here we add 1,000,000 to current score [0x0F4240 Reversed]
 		WriteProcessMemory(hand, (void*)0x0041d292, &curscore, 3, &bytes);// Write the modified score into memory.
			
	}
}


BOOL GetProcessList( )
{
  HANDLE hProcessSnap;
  HANDLE hProcess;
  PROCESSENTRY32 pe32;
  DWORD dwPriorityClass;
  int PidTest;
  GameRunning=FALSE;
 
  
 
  hProcessSnap = CreateToolhelp32Snapshot( TH32CS_SNAPPROCESS, 0 );  // Take a snapshot of all processes running in the system.
  if( hProcessSnap == INVALID_HANDLE_VALUE ) return( FALSE );
  
  pe32.dwSize = sizeof( PROCESSENTRY32 ); // Set the size of the structure before using it.

  // Retrieve information about the first process and quit if unsucessfull 
  if( !Process32First( hProcessSnap, &pe32 ) )
  {
    CloseHandle( hProcessSnap );     // Clean up the snapshot object before quitting!
    return( FALSE );
  }

  
  // Loop trough all processes, and retrieve info
    do
  {
    // Retrieve the priority class.
    dwPriorityClass = 0;
    hProcess = OpenProcess( PROCESS_ALL_ACCESS, FALSE, pe32.th32ProcessID );
    if( hProcess != NULL )
    {
      dwPriorityClass = GetPriorityClass( hProcess );
      if( !dwPriorityClass )
        
      CloseHandle( hProcess );
    }

    PidTest=strcmp(gameWindow, pe32.szExeFile); // compare each process name with our target exe name
	if(PidTest==0){ pid=pe32.th32ProcessID; GameRunning=TRUE;}

  } while( Process32Next( hProcessSnap, &pe32 ) );

  CloseHandle( hProcessSnap ); // Clean up the snapshot object before exiting function!
  return( TRUE );
}

BOOL CALLBACK DialogProc (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
	{
		case WM_INITDIALOG:
			Initialize(hwnd,wParam,lParam);
			return TRUE;

		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
				case IDC_ABOUT:
					aboutButton(hwnd);
					return TRUE;

				case IDC_EXIT:
					EndDialog (hwnd, 0);
					return TRUE;
			}
		return TRUE;

		case WM_DESTROY:
			CloseHandle(pFile);
			PostQuitMessage(0);
			return TRUE;

		case WM_CLOSE:
			PostQuitMessage(0);
			return TRUE;
		case WM_TIMER:
			timerCall();
			return TRUE;
    }
    return FALSE;
}


int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow )
{
	DialogBox(hInstance,MAKEINTRESOURCE(IDD_MAINDLG), NULL,DialogProc);
	return 0;
}


// And Thats it :) Hope u can understand the code,

// Bispoo (c) 2008