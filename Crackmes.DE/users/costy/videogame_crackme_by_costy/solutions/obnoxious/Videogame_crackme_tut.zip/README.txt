put the loader in the same directory as the target.
i have included the source of the loader incluing the loader maker
the source opens with the loader creator. Alternately you can study the source opening it with note pad.
the loader is named videogame_setup.exe
thanks to the author of the loader maker!!!!!!!
