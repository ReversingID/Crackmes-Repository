KeyGen Me - Image and Serial

by COSTY

The user must load an image.
The serial is generated from the image content.

The purpose is to create a keygen.