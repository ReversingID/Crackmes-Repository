#include<stdio.h>
#include<conio.h>
int main()
{
long int limit,i,num=10000000;
printf("*********************************************\n");
printf("  BruteForcer for Costy's crackme by br0ken\n");
printf("*********************************************\n");
printf("\n\nHow many serial(s) do you want? : ");
scanf("%ld",&limit);
while(num<=99999999)
{
    i=2;
       while(i<=num)
          {
            if(num%i==0)
            break;
            i++;
          }
       if(i==num)
if(limit!=0)
 {
printf("\n  Serial = %ld\n",num);
limit--;
}
num++;
if(limit==0)
{
goto end;
}
}
end: getch();
}
