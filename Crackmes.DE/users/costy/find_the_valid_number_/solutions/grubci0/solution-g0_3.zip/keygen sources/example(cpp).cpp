#include <iostream>

int main()
{
   unsigned int a,b,c,d=0;
	std::cout << "Looking for 'good' numbers...\n";
   for(a = 10000001;a<99999999;a++)
   {
	   for(b = 2;b<=(a/2);b=b+2)
	   {

		    if (!(a % b)) //modulo dividing
			{
			c = 1; //if zero - set 'c' to 1
			break; //and end this number - its wrong
			}
			if (b==2) b++;
	   }
	   if (!c) //if 'c' wasn't set to 1 and it's still zero
	   {
		   d++;
		   std::cout << d << ":\t\t" << a << "\n"; //write this number
	   }
	   if (d==200)
	   {
		   std::cout << "Want more numbers? Choose 1.";
	       std::cin >> d; if (d == 1) d=0; else return 0;
	   }
	   c = 0; //reset our 'flag' ;)
   }
   return 0;
}