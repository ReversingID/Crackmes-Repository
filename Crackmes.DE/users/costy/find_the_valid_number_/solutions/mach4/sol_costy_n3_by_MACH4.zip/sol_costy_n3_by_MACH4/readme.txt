Video Solution to costy's n3 CrackMe
Solved by MACH4

Tools:
PEID
OLLYDBg
MASM32

If you have problems with the flash video screen size, Google for "SWF Opener" by UnH Solutions, I wouldn't be without it!

Greetz to costy, Crackmes.de and all members!

MACH4.