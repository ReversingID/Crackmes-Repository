This keygen was quickly wrote so I have not added editBox filtering!
Please enter int only
The upper range sets the upper range to check (Obvious)
The difference between the upper an lower range (ie the amount of possibilities to check) will have a huge impact on the processing time, with increasing range...

Greetz,

MACH4.