Crack Thee By D-Jester

This is my first actual crackme. I threw in a few tricks.
If you can't get the file to run, its probably found something wrong with itself or its environment.

Visual Basic Compiled to Native: No Optimization
Keygen not required, but thats what I want if you have the brain.

Report any errors to me so I can prevent them from happening in the next version. 

d-jester(AT)execs(DOT)com any emails to me must have "PER:CT1 INBOX" in the subject line.

If you crack it you may have a copy of the source code, upon request only.

News:

1.02.0009
Fixed a bug in the register routine thnx to Kao

1.02.0008
Original Release 