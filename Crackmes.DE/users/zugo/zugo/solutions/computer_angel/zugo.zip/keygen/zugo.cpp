// zugo.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>




int _tmain(int argc, _TCHAR* argv[])
{
	char szName[100];
	int length=0;
	unsigned int calc_value=0x1908;

	printf("Input username:");
	gets_s(szName,99);

	length=strlen(szName);
	if (length<=4){
		printf("Username must be >=5 characters!!\n");
		return 0;
	}

	for (int i = 0; i < length; i++){
            unsigned int tmp = (length + calc_value) * (szName[i]);
			calc_value = tmp ;
	}
	calc_value^= 0xA9F9FA;

	printf("Serial = %i\n",calc_value);

	getchar();


	return 0;
}

