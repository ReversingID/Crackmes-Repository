////////////////////////////////////////////////////////////////////////////
// Keygen for  zugo (keygenme)
//
// Published: 20. Jan, 2008
// URL: http://crackmes.de/users/zugo/zugo/
// Keygen was written by mik26vn/tastatur -20.Jan.2008
//
// Recommended & thanks to: crackmes.de, reaonline.net, SeeknDestroy...
////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <string>

using namespace std;

int main()
{
	const int MaxLength=64;
	char szName[MaxLength]; // input Name
	int  szlng=0;	 		// Length of input Name
	unsigned long s0=0x1908, j;  // SS:[EBP+C]
	
	int i=0;
	do
  	{
		cout << "Name: ";
		cin >> szName;
	}
	while (strlen(szName)<5);

	szlng=strlen(szName); // EBX

	do
	{	
		j = s0; //MOV EDX,DWORD PTR SS:[EBP+C]
		s0 = long(szName[i]) * (j+szlng);	// ECX

		i++;	
	}
	while (i < szlng);
	s0 = s0 ^ 0x0A9F9FA;
	
	cout << "Valid Serial  : " << s0 << endl;

  
	return 0;
}
