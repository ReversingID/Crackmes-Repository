Prof. DrAcULA's Keygenme #1 Readme
----------------------------------
> How to work with this keygenme?
        1. Enter name
        2. Enter a trial-code
        3. Hit 'Unlock'-button
        4. If trial-code is valid, 'Serial'-textbox & 'Register'-button become enabled.
        5. Enter serial
        6. Hit 'Register'-button
        7. If serial is valid you win :)
        
> Your objective?
        1. Write a tutorial
        2. Code a keygen
        3. Enjoy :)