Prof. DrAcULA presents, Cryptok KeygenMe {2}
===========================================

It is the 2nd KeygenMe in the Cryptok-series.
Hope you enjoy this!

You have to:
1. Code a keygen-loader(single executable that'll run my DLL).
2. On entering a valid-serial, Cryptok {2} displays a Googboy-dialogbox.
Your keygen-loader must be able to display given image(youdidit.bmp) in this dialog-box(without changing
code/resource of the DLL, of course. You have to code this feature in your leygen-loader).

Solution for this KeygenMe means;
1. Tutorial explaining how it works.
2. No patching, no self-keygenning.
3. A working keygen-loader with source.

Protection Level : For you to rate it

Hints: You have to be a Dan Brown fan?

See u with next Cryptok Relaese.