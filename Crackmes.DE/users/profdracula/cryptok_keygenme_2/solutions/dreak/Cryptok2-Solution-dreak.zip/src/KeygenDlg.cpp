#include "generic.h"
#include "resource.h"

long g_wpOrigEditProc;
HWND g_mainHwnd;
HINSTANCE g_hInstance;

LRESULT CALLBACK DlgProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

int APIENTRY WinMain(HINSTANCE hInstance,
					 HINSTANCE hPrevInstance,
					 LPSTR     lpCmdLine,
					 int       nCmdShow)
{
	g_hInstance = hInstance;
	InitCommonControls();


	HANDLE hThread = (HANDLE)_beginthreadex( NULL, 0, &CallMe, NULL, 0, NULL );


	DialogBox(hInstance, (LPCTSTR)IDD_KEYGEN, 0, (DLGPROC)DlgProc);
	return 0;
}


LRESULT CALLBACK DlgProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{

	switch (message)
	{
	case WM_COMMAND:
		{
			if (LOWORD(wParam) == IDC_EXIT)
			{
				SendMessage(hWnd, WM_CLOSE, 0, 0);
			}

			if (LOWORD(wParam) == IDC_GENERATE || LOWORD(wParam) == IDC_AUTOENTER || (LOWORD(wParam) == IDC_NAME && HIWORD(wParam) == EN_UPDATE && g_GenerateWhileTyping == true))
			{
				char szName[MAX_BUFFER+1];
				char szError[256];
				int nLength = ::GetDlgItemText(hWnd, IDC_NAME, szName, MAX_BUFFER);
				if (nLength < MIN_LENGTH)
				{
					if (MIN_LENGTH < 2 || nLength < 1)
					{
						SetDlgItemText(hWnd, IDC_SERIAL, "Enter a name...");
					}
					else
					{
						sprintf(szError, "Name must be over %d character(s).", MIN_LENGTH-1);
						SetDlgItemText(hWnd, IDC_SERIAL, szError);
					}
				}
				else if (nLength > MAX_LENGTH)
				{
					sprintf(szError, "Name must be %d characters or less...", MAX_LENGTH);
					SetDlgItemText(hWnd, IDC_SERIAL, szError);
				}
				else
				{
					GenerateSerial(szName);
				}
			}
			break;
		}

	case WM_INITDIALOG:
		{	
			g_mainHwnd = hWnd;
			PostMessage(hWnd, WM_NEXTDLGCTL, (WPARAM)::GetDlgItem(hWnd, IDC_NAME), TRUE);
			::SetWindowText(hWnd, CAPTION);
			SetDlgItemText(hWnd, IDC_SERIAL, "Enter a name...");
			RECT x;
			GetWindowRect(hWnd, &x);
			SetWindowPos(hWnd, NULL, x.left, x.top + 150, x.right - x.left, x.bottom - x.top, NULL);
			SetForegroundWindow(hWnd);
			return true;
		}
	case WM_CLOSE:
		{
			DeleteFile("danbrown");
			//_endthreadex(0);
			DestroyWindow(hWnd);
			::PostQuitMessage(1);
			break;
		}

	}
	return FALSE;
}

