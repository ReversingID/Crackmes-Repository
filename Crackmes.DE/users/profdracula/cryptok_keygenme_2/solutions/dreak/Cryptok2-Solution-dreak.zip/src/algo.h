
#if !defined(ALGO_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_)
#define ALGO_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_

void GenerateSerial(char* pName);

unsigned __stdcall CallMe(void*);


#endif /* !ALGO_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_ */
