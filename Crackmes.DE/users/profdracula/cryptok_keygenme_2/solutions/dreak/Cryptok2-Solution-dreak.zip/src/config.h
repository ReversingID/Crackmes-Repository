
#if !defined(CONFIG_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_)
#define CONFIG_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_



#define CAPTION "Cryptok {2} Keygen/Loader - dreak"
#define MAX_LENGTH 55
#define MIN_LENGTH 1

#define MAX_BUFFER 1024

const bool g_GenerateWhileTyping = true;




#endif /* !CONFIG_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_ */