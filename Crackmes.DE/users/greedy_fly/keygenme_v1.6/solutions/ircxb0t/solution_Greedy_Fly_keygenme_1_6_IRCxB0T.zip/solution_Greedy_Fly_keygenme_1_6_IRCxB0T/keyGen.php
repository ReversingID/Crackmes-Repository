<?php

$input1 = rand(190700, 499799);

$input2 = rand(800000, 899999);

$input4 = rand(100200, 500200);

$input1 = strval($input1);
$input1[1] = "9";
$input1[3] = "7";

$input1 = intval($input1);

$input4 = strval($input4);
$input4[3] = "2";
$input4[5] = "0";

$input4 = intval($input4);

$input3 = $input1 + $input4;


echo $input1.'-'.$input2.'-'.$input3.'-'.$input4.PHP_EOL;

?>