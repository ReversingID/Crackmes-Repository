#include <math.h>
#include <stdio.h>

int main() {

    unsigned int MM0, MM1, MM2, i;

    char nfo[] = "===============================================================================\n"\
                 "= CrackMe v1.1, by Greedy_Fly @ crackmes.de                     [09. Oct, 2013]\n"\
                 "= Solution by XpoZed @ nullsecurity.org                         [16. Oct, 2013]\n"\
                 "===============================================================================\n\n";
    printf(nfo);

    printf("Calculating, please wait...\n\n");

    for (MM0 = 0; MM0 < 0xFFFFFFFF; MM0++) {
        MM2 = MM0*2;
        if ((MM0*2) == MM2) {
            MM1 = 0x8166F372-(MM0+MM2);
            if (((MM0+(MM1*4))-(MM2<<1)) == 0x16F0599C) {

                for(i = 24; i > 0; i--) {
                    MM0 ^= 0xE1785A22;
                    MM0 += MM1;
                    MM1--;
                    MM2 ^= MM0;
                }

                __asm__("bswap %0" : "+r" (MM0));
                __asm__("bswap %0" : "+r" (MM1));
                __asm__("bswap %0" : "+r" (MM2));

                printf("VALID SERIAL: %08X%08X%08X\n", MM2, MM1, MM0);
				break;
            }
        }
    }

    return 0;
}
