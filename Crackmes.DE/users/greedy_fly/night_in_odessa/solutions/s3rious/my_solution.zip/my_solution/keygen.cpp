// ------------------------------------------------------------------------------------------------
/*
**  Night In Odessa - KM v2.0 by Greedy Fly (level 4)
**  Keygen by s3r1ous
**  21/09/2013
*/
// ------------------------------------------------------------------------------------------------
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>


#define ROL(n, p) ( ((n) << p) | ((n) >> (16-p)) )  // MACRO for left  circular rotation
#define ROR(n, p) ( ((n) >> p) | ((n) << (16-p)) )  // MACRO for right circular rotation

// MACRO for converting a number from little-endian to big-endian
#define BIG_ENDIAN(n) (             \
        ((n & 0x000000ff) << 24) |  \
        ((n & 0x0000ff00) << 8)  |  \
        ((n & 0x00ff0000) >> 8)  |  \
        ((n & 0xff000000) >> 24)    \
    )

typedef unsigned int UINT;
// ------------------------------------------------------------------------------------------------
/*
**  hash_name(): This function performs a simple hash on name
**
**  Return Value: Hash value of name.
*/
// ------------------------------------------------------------------------------------------------
UINT hash_name( char *name, UINT n_len )  // name and name length as arguments
{
	UINT sum = 1,                        // summary of characters
         cum = 0;                        // cummulative summary of characters

	for( UINT i=0; i<n_len; i++ )
	{
        name[i] = (name[i]^'l') >> 1;   // XOR and shift by 1 each character

		sum += name[i];                 // add value to sum
		cum += sum;                     // add sum to cumulative sum
	}

	return (sum % 0xfff1) | ((cum << 16) ^ 0x1c2a);
}
// ------------------------------------------------------------------------------------------------
/*
**  hash_serial(): This function performs a more complex hash on serial
**
**  Return Value: Hash value of serial.
*/
// ------------------------------------------------------------------------------------------------
UINT hash_serial( UINT E )
{
    return
        ( (((BIG_ENDIAN(E) & 0xffff) >> 1) ^ 0x4de2) << 16 ) |
        ((ROL((BIG_ENDIAN(E) >> 16) ^ 0x2ec9, 2) - 0x7e) & 0xffff);
}
// ------------------------------------------------------------------------------------------------
/*
**  inv_hash_serial(): This function performs the inverse operations from hash_serial(). Thus we
**      can get serial from hash.
**
**  Return Value: serial
*/
// ------------------------------------------------------------------------------------------------
UINT inv_hash_serial( UINT name_hash )
{
    return
        BIG_ENDIAN(
            ((BIG_ENDIAN((((name_hash >> 16) ^ 0x4de2) << 1) & 0xffff)) |
             (BIG_ENDIAN((ROR((name_hash & 0xffff) + 0x7e, 2) ^ 0x2ec9) << 16)))
        );
}
// ------------------------------------------------------------------------------------------------

int main()
{
    char name[32] = {'\0'}; // name
    UINT n_len,             // password length
         n_h,               // name hash value
         sv;                // serial value
    char cont='\0';         // continue flag


    printf( "+--------------------------------------------------+\n");
    printf( "|      Night In Odessa - KM v2.0 by Greedy Fly     |\n");
    printf( "|                Keygen by s3r1ous                 |\n");
    printf( "+--------------------------------------------------+\n\n");

    printf( "Enter your name (6-10 characters): " );
    scanf ( "%s", name );
    n_len = strlen( name );

    if( n_len < 6 || n_len > 10 )
    {
        printf( "Name must be from 6 to 10 characters long. Exiting.\n");
        exit( EXIT_FAILURE );
    }

    n_h = hash_name( name, n_len ); // calculate name hash
    inv_hash_serial( n_h );         // inverse name hash

    printf( "Name   hash is 0x%x\n", n_h );
    printf( "Serial hash is %4XE%4X\n\n", inv_hash_serial(n_h) >> 16,
                                          inv_hash_serial(n_h) & 0xffff );

    /*
    ** brute forcing all hashes
    */
    printf( "Brute-Forcing in order to find all valid serials [y/n]? " );
    scanf( "\n%c", &cont );

    if( cont == 'y' )
    {
        for( sv=0x0; sv<0xffffffff; sv++)     // for each possible serial
        {
            if( hash_serial(sv) == n_h )
            {
                printf( "Serial found: %XE%X\n", BIG_ENDIAN(sv) >> 16,
                                                 BIG_ENDIAN(sv) & 0xffff );

                //break;      // comment this if you want to find all hashes
            }

            if( sv % 100000000 == 0 && sv>0 )
                printf( "%u iterations... Trying 0x%x\n", sv, sv);
        }
    }

/*
    // The code below used to find valid serial length (which is 9)

    int v_404120, v_404000 = 2;
    for( int v_4040bc=0; v_4040bc<=21; v_4040bc++ )
    {
        double d1=v_404000, d2=v_4040bc;

        v_404120 = round( pow(2,(d1*log2(d2) - round(d1*log2(d2)))) * pow(2, round(d1*log2(d2))) );

        printf( "v_4040bc = %f\tv_404120 = %d\n", d2, v_404120 );
    }
*/

    return 0;
}
// ------------------------------------------------------------------------------------------------
