// Solution to Greedy_Fly's "Night In Odessa"
// (c) Demoth. 2013

#include <stdio.h>
#include <string.h>

unsigned short ror2(unsigned short val)
{
    val = (val >> 2) | (val << 14);
    return val;
}

unsigned long stringHash(char *str)
{
    unsigned char *data;
    unsigned char size = 0;
    unsigned int part1;
    unsigned int part2;
    signed int block_size;

    data = (unsigned char *)str;
    while (data[size] != 0)
        ++size;
    
    part1 = 1;
    part2 = 0;
    while (size != 0)
    {
        if ( size > 5552 )
            block_size = 5552;
        else
            block_size = size;
        size -= block_size;
        while (block_size != 0)
        {
            --block_size;
            part1 += (*data ^ 0x6C) >> 1;
            part2 += part1;
            ++data;
        }
        part2 %= 0xFFF1u;
        part1 %= 0xFFF1u;
    }

    return (part2 << 16) ^ 0x1C2A | part1;
}

unsigned long getSerialByHash(unsigned long hash)
{
    unsigned short key1, key2;

    key1 = (unsigned short)hash;
    key1 = ror2(key1 + 0x7E) ^ 0x2EC9;

    key2 = hash >> 0x10;
    key2 = (key2 ^ 0x4DE2) << 1;
    
    return (key1 << 0x10) | key2;
}

int main(int argc, char *argv[])
{
    char name[11];
    unsigned long key;

    printf("Enter name (length 6..10 chars): ");
    scanf("%10s", name);

    if (strlen(name) < 6)
    {
        printf("Name is too short\n");
        return 0;
    }

    printf("  Name: %s\n", name);
    key = getSerialByHash(stringHash(name));
    printf("Serial: %04XE%04X\n", key >> 0x10, key & 0xFFFF);

    return 0;
}