/*
greedkeygen.c
Greedy_Fly CrackMe v1.3 Keygen

Solution by dandries, crackmes.de
*/

#include <stdio.h>

int main(void) {
	int i, j;
	for (i = 0; i <= 255; i++) {
	   for (j = 0; j <= 255; j++) {
		   if (((234 ^ i ^ j) == 223) && ((38 ^ i ^ j) == 19) && ((10 ^ i ^ j) == 63) && ((5 ^ i ^ j) == 48)) {
			   printf("07D0-05EA-0A26-%02X%02X\n", i, j);
			   
		   }
		   
	   }
        
    }
	scanf("\n");
	return 0;
}