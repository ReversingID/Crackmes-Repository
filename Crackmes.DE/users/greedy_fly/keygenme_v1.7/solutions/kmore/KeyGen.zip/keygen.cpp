#include<iostream>
#include<cstring>
#include<vector>

using namespace std;

unsigned long lrotl(int value,unsigned char rotation)
{
return (value<<rotation) | (value>>(sizeof(value)*8 - 
rotation));
}

unsigned int _rotl32( unsigned int value, int shift )
{
	unsigned int retval = 0;
	retval = ( value << (shift & 0x1f) ) | ( value >> ( sizeof( int ) * 32 - (shift & 0x1f) ));
	return retval;	
}

char payload[] = { 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x3E, 0xFF, 0xFF, 0xFF, 0x3F,
  0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 0xFF, 0xFF, 0xFF, 0x00, 0xFF, 0xFF,
  0xFF, 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E,
  0x0F, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
  0xFF, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28,
  0x29, 0x2A, 0x2B, 0x2C, 0x2D, 0x2E, 0x2F, 0x30, 0x31, 0x32, 0x33, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF } ;



string partOne(int a, int b, int c, int d)
{

	//char string[] = "0000000000000000000000";
	////cout<<string<<endl;
	////cout<<"START"<<endl;
	int eax = 0;
	int ebx = 0;
	int edx = 0;
	int j=0;
	int *tab = new int[12];	
	bool f = false;
	int hash_old[] = { 0x77, 0x63, 0x73, 0x6b, 0x57, 0x49, 0x5a, 0x34, 0x75, 0x55, 0x37, 0xD3 };
	int hash[] = {a, b, c, d};
	//b = __builtin_bswap32(b);
	////cout<<endl<<(hex)<<a<<endl;
	////cout<<"old:"<<(hex)<<hash_old[0]<<endl;
	string test="";
	for(int i=0;i<4;i++)
	{
		f = false;
		for(int j=0;j<127;j++){
		 if(f){
		    break;
		 }
		f=false;
		 for(int k=0;k<127;k++){
			char A = j ;
			char B = k ;
			int r = 16 * (A-55 + (A<0x40 ? 7 : 0));
			////cout<<(hex)<<r<<endl;
			r += 0xF & (B-55 + (B < 0x40 ? 7 : 0));
			
			////cout<<r<<endl;
			
			if(r==hash[i]){
				if((A>='a' && A<='z') || (A>='0' && A<='9')){
//				//cout<<i<<":A"<<A<<endl;;
//				//cout<<i<<":B"<<B<<endl;
				if((B>='a' && B<='z') || (B>='0' && B<='9')){
				////cout<<"asd"<<endl;
				//string test;
				test +=A;
				test +=B;
				//return test;
				////cout<<i<<": "<<test<<endl;
				f = true;
				break;
				}
				}
				
			}
		}
		}

		
	}
//	tab[11] = 0x00;

	return test;
}

int getHash(char* hash_new)
{
	int hash[] = { 0xC1, 0xCB, 0x24, 0x58, 0x86, 0x78, 0xB9, 0x4E, 0xC0 };
    ////cout<<(hex)<<(int)hash[0];
	for(int i=0;i<8;i++)
	{
		hash[i] = ((int)hash_new[i] & 0xFF);
		////cout<<(hex)<<(int)hash[i]<<endl;;
	}
	////cout<<endl;
	//vector<string> key;
	vector<string> key_1;
	vector<string> key_2;
	vector<string> key_3;	

	for(int natka = 0; natka<9;natka+=3)
	for(int i=0;i<255;i++){
		for(int j=0;j<255;j++){
			unsigned char al = payload[i];
			unsigned char ah = payload[j];
			al = (al << 2);
			ah = (ah >> 4);
			al = al | ah;
		    ////cout<<"Testing: "<<hash[natka]<<" with "<<(al-0xffffff00)<<endl;;

			if(hash[natka]==(al)){
				////cout<<natka<<endl;
				for(int m=0;m<255;m++){
					unsigned char bl = payload[m];
					unsigned char ah = payload[j];
					bl = (unsigned char)(bl >> 2);
					ah = (unsigned char)(ah << 4);
					ah = ah | bl;
					if(hash[natka+1]==(ah)){
						////cout<<"2"<<natka<<endl;
						for(int q=0;q<255;q++){
						unsigned char bh = payload[q];
						unsigned char c = payload[m];
						unsigned char dh = (unsigned char)(c << 6);
						bh = bh | dh;
						if(hash[natka+2]==(bh) || hash[natka+2]==0xC0){
						////cout<<(dec)<<i<<endl;
						switch(natka)
						{
							case 0:
								key_1.push_back(partOne(i,j,m,q));
								break;
							case 3:
								key_2.push_back(partOne(i,j,m,q));
								break;
							case 6:
								key_3.push_back(partOne(i,j,m,q));
								m=255;
								j=255;
								q=255;
								i=255;
								break;
						}	
						}		
						}
				}

//			//cout<<(hex)<<(al-0xffffff00)<<endl;;
			}	
			}

//			//cout<<(hex)<<(al-0xffffff00)<<endl;;
		}
	}
   ////cout<<endl<<"HELLO"<<endl;
	////cout<<(dec)<<key_2.size()<<endl;
	////cout<<(dec)<<key_3.size()<<endl;
	//for(int i=0;i<key_1.size();i++)
	 //// for(int j=0;j<key_2.size();j++)
	  //{
	  //string ans = 
		////cout<<key_1[0];
		////cout<<key_2[0];
		
		string ans = key_1[0]  + key_2[0] + key_3[0];
		ans[22] = '3';
		ans[23] = 'D';
		cout<<ans<<endl;
	 // }

	return 0;
}

char memory[140*16];
char login[] = { 
0xA9, 0x85, 0xC1, 0xAD, 
0x75, 0x85, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x38 };
unsigned char con[] = { 0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF, 0xFE, 0xDC, 0xBA, 0x98, 0x76, 0x54, 0x32, 0x10, 0xF0, 0xE1, 0xD2, 0xC3 };
unsigned char val_con[] = { 0x3D, 0xC3, 0x09, 0xE4, 0xAA, 0x89, 0x07, 0xE4, 0x20, 0xEF, 0xDE, 0x03, 0xB4, 0xC3, 0x06, 0xE8 };

 
unsigned int eax;
unsigned int ebx;
unsigned int ecx;
unsigned int edx;
unsigned int esi;
unsigned int edi;
unsigned int ebp;

int dec(int q)
{
	return q/4;
}

int hackfunk(char *p)
{
	if(p==0)
		return 0;
	int *login_int = 0;
	int *memory_int = 0;
	login_int  = (int*)p;
	memory_int = (int*)memory;
	int ebx;
	
	//for(int i=0;i<16;i++)
	//	//cout<<login_int[i]<<endl;
	////cout<<"end"<<endl;
	
	for(ebx=0;ebx<8;ebx+=2)
	{
		eax = login_int[ebx];
		ecx = login_int[ebx+1];
		edx = login_int[ebx+8];
		esi = login_int[ebx+9];		

		
		
		eax = __builtin_bswap32(eax);
		ecx = __builtin_bswap32(ecx);
		edx = __builtin_bswap32(edx);
		esi = __builtin_bswap32(esi);

		
		memory_int[ebx] = eax;
		memory_int[ebx+1] = ecx;
		memory_int[ebx+8] = edx;
		memory_int[ebx+9] = esi;
	}
	ebx = ebx << 1;
	
	for(;ebx<80;ebx+=2)
	{
		eax = memory_int[ebx-dec(0xC)];
		edx = memory_int[ebx-dec(0x8)];
		////cout<<(hex)<<eax<<endl;
		////cout<<edx<<endl<<endl;;	
		eax = eax ^ memory_int[ebx-dec(0x20)];
		edx = edx ^ memory_int[ebx-dec(0x1C)];
		////cout<<(hex)<<eax<<endl;
		////cout<<edx<<endl<<endl;;
		eax = eax ^ memory_int[ebx-dec(0x38)];
		edx = edx ^ memory_int[ebx-dec(0x34)];
		////cout<<(hex)<<eax<<endl;
		////cout<<edx<<endl<<endl;;
		eax = eax ^ memory_int[ebx-dec(0x40)];
		edx = edx ^ memory_int[ebx-dec(0x3C)];
		////cout<<(hex)<<eax<<endl;
		////cout<<edx<<endl<<endl;;
		eax = _rotl32(eax, 1);
		memory_int[ebx] = eax;
		edx = _rotl32(edx, 1);
		memory_int[ebx+1] = edx;
		////cout<<(hex)<<eax<<endl;
		////cout<<edx<<endl<<endl;;		
	}

	int *cont_val = (int*)con;
	eax = cont_val[0];
	ebx = cont_val[1];
	ecx = cont_val[2];
	edx = cont_val[3];
	esi = cont_val[4];

	edi = ecx;
	edi = edi ^ edx;
	edi = edi & ebx;
	edi = edi ^ edx;

	esi = edi + esi + 0x5A827999;
	ebx = _rotl32(ebx, 0x1E);
	//cout<<ebx<<endl;
	edi = eax;
	edi = _rotl32(edi, 5);
	esi+=memory_int[0];
	esi += edi;
	edi = ebx;
	edi ^= ecx;
	edi &= eax;
	edi ^= ecx;
	edx = edi + edx + 0x5A827999;
	eax = _rotl32(eax, 0x1E);
	edi = esi;
	edi = _rotl32(edi, 5);
	edx+=memory_int[1];
	edx += edi;
	edi = eax;
	edi ^=ebx;
	edi &= esi;
	edi ^=ebx;
	ecx = edi + ecx + 0x5A827999;
	esi = _rotl32(esi, 0x1E);
	edi = edx;
	edi = _rotl32(edi, 5);
	ecx+=memory_int[2];
	ecx += edi;
	edi = esi;
	edi ^= eax;
	edi &= edx;
	edi ^= eax;
	ebx = edi + ebx + 0x5A827999;
	edx = _rotl32(edx, 0x1E);
	edi = ecx;
	edi = _rotl32(edi, 5);
	ebx+=memory_int[3];
	ebx += edi;
	edi = edx;
	edi ^= esi;
	edi &= ecx;
	edi ^= esi;
	eax = edi + eax + 0x5A827999;
	ecx = _rotl32(ecx, 0x1E);
	//cout<<ecx<<endl;
	edi = ebx;
	edi = _rotl32(edi, 5);
	//cout<<"EAX "<<eax<<endl;
	eax+=memory_int[4];
	//cout<<"MEM "<<memory_int[4]<<endl;
	eax += edi;
	//cout<<"EAX "<<eax<<endl;
	edi = ecx;
	edi ^= edx;
	edi &=ebx;
	edi ^= edx;
	esi = edi + esi + 0x5A827999;
	ebx = _rotl32(ebx, 0x1E);
	//cout<<ebx<<endl;
	edi = eax;
	edi = _rotl32(edi, 5);
	esi+=memory_int[5];
	esi += edi;
	edi = ebx;
	edi ^= ecx;
	edi &= eax;
	edi ^= ecx;
	edx = edi + edx + 0x5A827999;
	//cout<<"OLD "<<eax<<endl;
	eax = _rotl32(eax, 0x1E);
	//cout<<"A"<<eax<<endl;
	edi = esi;
	edi = _rotl32(edi, 5);
	edx+=memory_int[6];
	edx += edi;
	edi = eax;
	edi ^=ebx;
	edi &= esi;
	edi ^=ebx;
	ecx = edi + ecx + 0x5A827999;
	esi = _rotl32(esi, 0x1E);
	//cout<<esi<<endl;
	edi = edx;
	edi = _rotl32(edi, 5);
	ecx+=memory_int[7];
	ecx += edi;
	edi = esi;
	edi ^= eax;
	edi &= edx;
	edi ^= eax;
	ebx = edi + ebx + 0x5A827999;
	edx = _rotl32(edx, 0x1E);
	edi = ecx;
	edi = _rotl32(edi, 5);
	ebx+=memory_int[8];
	ebx += edi;
	edi = edx;
	edi ^= esi;
	edi &= ecx;
	edi ^= esi;
	eax = edi + eax + 0x5A827999;
	ecx = _rotl32(ecx, 0x1E);
	edi = ebx;
	edi = _rotl32(edi, 5);
	eax+=memory_int[9];
	eax += edi;
	edi = ecx;
	edi ^= edx;
	edi &=ebx;
	edi ^= edx;
	esi = edi + esi + 0x5A827999;
	ebx = _rotl32(ebx, 0x1E);
	edi = eax;
	edi = _rotl32(edi, 5);
	esi+=memory_int[10];
	esi += edi;
	edi = ebx;
	edi ^= ecx;
	edi &= eax;
	edi ^= ecx;
	edx = edi + edx + 0x5A827999;
	eax = _rotl32(eax, 0x1E);
	//cout<<eax<<endl;
	edi = esi;
	edi = _rotl32(edi, 5);
	edx+=memory_int[11];
	edx += edi;
	edi = eax;
	edi ^=ebx;
	edi &= esi;
	edi ^=ebx;
	ecx = edi + ecx + 0x5A827999;
	esi = _rotl32(esi, 0x1E);
	edi = edx;
	edi = _rotl32(edi, 5);
	ecx+=memory_int[12];
	ecx += edi;
	edi = esi;
	edi ^= eax;
	edi &= edx;
	edi ^= eax;
	ebx = edi + ebx + 0x5A827999;
	edx = _rotl32(edx, 0x1E);
	edi = ecx;
	edi = _rotl32(edi, 5);
	ebx+=memory_int[13];
	ebx += edi;
	edi = edx;
	edi ^= esi;
	edi &= ecx;
	edi ^= esi;
	eax = edi + eax + 0x5A827999;
	ecx = _rotl32(ecx, 0x1E);
	edi = ebx;
	edi = _rotl32(edi, 5);
	eax+=memory_int[14];
	eax += edi;
	edi = ecx;
	edi ^= edx;
	edi &=ebx;
	edi ^= edx;
	esi = edi + esi + 0x5A827999;
	ebx = _rotl32(ebx, 0x1E);
	edi = eax;
	edi = _rotl32(edi, 5);
	esi+=memory_int[15];
	esi += edi;
	edi = ebx;
	edi ^= ecx;
	edi &= eax;
	edi ^= ecx;
	edx = edi + edx + 0x5A827999;
	eax = _rotl32(eax, 0x1E);
	//cout<<eax<<endl;
	edi = esi;
	edi = _rotl32(edi, 5);
	edx+=memory_int[16];
	edx += edi;
	edi = eax;
	edi ^=ebx;
	edi &= esi;
	edi ^=ebx;
	ecx = edi + ecx + 0x5A827999;
	esi = _rotl32(esi, 0x1E);
	edi = edx;
	edi = _rotl32(edi, 5);
	ecx+=memory_int[17];
	ecx += edi;
	edi = esi;
	edi ^= eax;
	edi &= edx;
	edi ^= eax;
	ebx = edi + ebx + 0x5A827999;
	edx = _rotl32(edx, 0x1E);
	edi = ecx;
	edi = _rotl32(edi, 5);
	ebx+=memory_int[18];
	ebx += edi;
	edi = edx;
	edi ^= esi;
	edi &= ecx;
	edi ^= esi;
	eax = edi + eax + 0x5A827999;
	ecx = _rotl32(ecx, 0x1E);
	edi = ebx;
	edi = _rotl32(edi, 5);
	eax+=memory_int[19];
	eax += edi;
	edi = ecx;
	edi ^= edx;
	edi ^=ebx;
	esi = edi + esi + 0x6ED9EBA1;
	ebx = _rotl32(ebx, 0x1E);
	edi = eax;
	edi = _rotl32(edi, 5);
	esi+=memory_int[20];
	esi += edi;
	edi = ebx;
	edi ^= ecx;
	edi ^= eax;
	edx = edi + edx + 0x6ED9EBA1;
	eax = _rotl32(eax, 0x1E);
	edi = esi;
	edi = _rotl32(edi, 5);
	edx+=memory_int[21];
	edx += edi;
	edi = eax;
	edi ^=ebx;
	edi ^= esi;
	ecx = edi + ecx + 0x6ED9EBA1;
	esi = _rotl32(esi, 0x1E);
	edi = edx;
	edi = _rotl32(edi, 5);
	ecx+=memory_int[22];
	ecx += edi;
	edi = esi;
	edi ^= eax;
	edi ^= edx;
	ebx = edi + ebx + 0x6ED9EBA1;
	edx = _rotl32(edx, 0x1E);
	edi = ecx;
	edi = _rotl32(edi, 5);
	ebx+=memory_int[23];
	ebx += edi;
	edi = edx;
	edi ^= esi;
	edi ^= ecx;
	eax = edi + eax + 0x6ED9EBA1;
	ecx = _rotl32(ecx, 0x1E);
	edi = ebx;
	edi = _rotl32(edi, 5);
	eax+=memory_int[24];
	eax += edi;
	edi = ecx;
	edi ^= edx;
	edi ^=ebx;
	esi = edi + esi + 0x6ED9EBA1;
	ebx = _rotl32(ebx, 0x1E);
	edi = eax;
	edi = _rotl32(edi, 5);
	esi+=memory_int[25];
	esi += edi;
	edi = ebx;
	edi ^= ecx;
	edi ^= eax;
	edx = edi + edx + 0x6ED9EBA1;
	eax = _rotl32(eax, 0x1E);
	edi = esi;
	edi = _rotl32(edi, 5);
	edx+=memory_int[26];
	edx += edi;
	edi = eax;
	edi ^=ebx;
	edi ^= esi;
	ecx = edi + ecx + 0x6ED9EBA1;
	esi = _rotl32(esi, 0x1E);
	edi = edx;
	edi = _rotl32(edi, 5);
	ecx+=memory_int[27];
	ecx += edi;
	edi = esi;
	edi ^= eax;
	edi ^= edx;
	ebx = edi + ebx + 0x6ED9EBA1;
	edx = _rotl32(edx, 0x1E);
	edi = ecx;
	edi = _rotl32(edi, 5);
	ebx+=memory_int[28];
	ebx += edi;
	edi = edx;
	edi ^= esi;
	edi ^= ecx;
	eax = edi + eax + 0x6ED9EBA1;
	ecx = _rotl32(ecx, 0x1E);
	edi = ebx;
	edi = _rotl32(edi, 5);
	eax+=memory_int[29];
	eax += edi;
	edi = ecx;
	edi ^= edx;
	edi ^=ebx;
	esi = edi + esi + 0x6ED9EBA1;
	ebx = _rotl32(ebx, 0x1E);
	edi = eax;
	edi = _rotl32(edi, 5);
	esi+=memory_int[30];
	esi += edi;
	edi = ebx;
	edi ^= ecx;
	edi ^= eax;
	edx = edi + edx + 0x6ED9EBA1;
	eax = _rotl32(eax, 0x1E);
	edi = esi;
	edi = _rotl32(edi, 5);
	edx+=memory_int[31];
	edx += edi;
	edi = eax;
	edi ^=ebx;
	edi ^= esi;
	ecx = edi + ecx + 0x6ED9EBA1;
	esi = _rotl32(esi, 0x1E);
	edi = edx;
	edi = _rotl32(edi, 5);
	ecx+=memory_int[32];
	ecx += edi;
	edi = esi;
	edi ^= eax;
	edi ^= edx;
	ebx = edi + ebx + 0x6ED9EBA1;
	edx = _rotl32(edx, 0x1E);
	edi = ecx;
	edi = _rotl32(edi, 5);
	ebx+=memory_int[33];
	ebx += edi;
	edi = edx;
	edi ^= esi;
	edi ^= ecx;
	eax = edi + eax + 0x6ED9EBA1;
	ecx = _rotl32(ecx, 0x1E);
	edi = ebx;
	edi = _rotl32(edi, 5);
	eax+=memory_int[34];
	eax += edi;
	edi = ecx;
	edi ^= edx;
	edi ^=ebx;
	esi = edi + esi + 0x6ED9EBA1;
	ebx = _rotl32(ebx, 0x1E);
	edi = eax;
	edi = _rotl32(edi, 5);
	esi+=memory_int[35];
	esi += edi;
	edi = ebx;
	edi ^= ecx;
	edi ^= eax;
	edx = edi + edx + 0x6ED9EBA1;
	eax = _rotl32(eax, 0x1E);
	edi = esi;
	edi = _rotl32(edi, 5);
	edx+=memory_int[36];
	edx += edi;
	edi = eax;
	edi ^=ebx;
	edi ^= esi;
	ecx = edi + ecx + 0x6ED9EBA1;
	esi = _rotl32(esi, 0x1E);
	edi = edx;
	edi = _rotl32(edi, 5);
	ecx+=memory_int[37];
	ecx += edi;
	edi = esi;
	edi ^= eax;
	edi ^= edx;
	ebx = edi + ebx + 0x6ED9EBA1;
	edx = _rotl32(edx, 0x1E);
	edi = ecx;
	edi = _rotl32(edi, 5);
	ebx+=memory_int[38];
	ebx += edi;
	edi = edx;
	edi ^= esi;
	edi ^= ecx;
	eax = edi + eax + 0x6ED9EBA1;
	ecx = _rotl32(ecx, 0x1E);
	edi = ebx;
	edi = _rotl32(edi, 5);
	eax+=memory_int[39];
	eax += edi;
	edi = ebx;
	edi |= ecx;
	edi &= edx;
	ebp = edi;
	edi = ebx;
	edi &= ecx;
	edi |= ebp;
	esi = edi + esi + 0x8F1BBCDC;
	ebx = _rotl32(ebx, 0x1E);
	edi = eax;
	edi = _rotl32(edi, 5);
	esi+=memory_int[40];
	esi += edi;
	edi = eax;
	edi |= ebx;
	edi &= ecx;
	ebp = edi;
	edi = eax;
	edi &=ebx;
	edi |= ebp;
	edx = edi + edx + 0x8F1BBCDC;
	eax = _rotl32(eax, 0x1E);
	edi = esi;
	edi = _rotl32(edi, 5);
	edx+=memory_int[41];
	edx += edi;
	edi = esi;
	edi |= eax;
	edi &=ebx;
	ebp = edi;
	edi = esi;
	edi &= eax;
	edi |= ebp;
	ecx = edi + ecx + 0x8F1BBCDC;
	esi = _rotl32(esi, 0x1E);
	edi = edx;
	edi = _rotl32(edi, 5);
	ecx+=memory_int[42];
	ecx += edi;
	edi = edx;
	edi |= esi;
	edi &= eax;
	ebp = edi;
	edi = edx;
	edi &= esi;
	edi |= ebp;
	ebx = edi + ebx + 0x8F1BBCDC;
	edx = _rotl32(edx, 0x1E);
	edi = ecx;
	edi = _rotl32(edi, 5);
	ebx+=memory_int[43];
	ebx += edi;
	edi = ecx;
	edi |= edx;
	edi &= esi;
	ebp = edi;
	edi = ecx;
	edi &= edx;
	edi |= ebp;
	eax = edi + eax + 0x8F1BBCDC;
	ecx = _rotl32(ecx, 0x1E);
	edi = ebx;
	edi = _rotl32(edi, 5);
	eax+=memory_int[44];
	eax += edi;
	edi = ebx;
	edi |= ecx;
	edi &= edx;
	ebp = edi;
	edi = ebx;
	edi &= ecx;
	edi |= ebp;
	esi = edi + esi + 0x8F1BBCDC;
	ebx = _rotl32(ebx, 0x1E);
	edi = eax;
	edi = _rotl32(edi, 5);
	esi+=memory_int[45];
	esi += edi;
	edi = eax;
	edi |= ebx;
	edi &= ecx;
	ebp = edi;
	edi = eax;
	edi &=ebx;
	edi |= ebp;
	edx = edi + edx + 0x8F1BBCDC;
	eax = _rotl32(eax, 0x1E);
	edi = esi;
	edi = _rotl32(edi, 5);
	edx+=memory_int[46];
	edx += edi;
	edi = esi;
	edi |= eax;
	edi &=ebx;
	ebp = edi;
	edi = esi;
	edi &= eax;
	edi |= ebp;
	ecx = edi + ecx + 0x8F1BBCDC;
	esi = _rotl32(esi, 0x1E);
	edi = edx;
	edi = _rotl32(edi, 5);
	ecx+=memory_int[47];
	ecx += edi;
	edi = edx;
        edi |= esi;
	edi &= eax;
	ebp = edi;
	edi = edx;
	edi &= esi;
	edi |= ebp;
	ebx = edi + ebx + 0x8F1BBCDC;
	edx = _rotl32(edx, 0x1E);
	edi = ecx;
	edi = _rotl32(edi, 5);
	ebx+=memory_int[48];
	ebx += edi;
	edi = ecx;
	edi |= edx;
	edi &= esi;
	ebp = edi;
	edi = ecx;
	edi &= edx;
	edi |= ebp;
	eax = edi + eax + 0x8F1BBCDC;
	ecx = _rotl32(ecx, 0x1E);
	edi = ebx;
	edi = _rotl32(edi, 5);
	eax+=memory_int[49];
	eax += edi;
	edi = ebx;
	edi |= ecx;
	edi &= edx;
	ebp = edi;
	edi = ebx;
	edi &= ecx;
	edi |= ebp;
	esi = edi + esi + 0x8F1BBCDC;
	ebx = _rotl32(ebx, 0x1E);
	edi = eax;
	edi = _rotl32(edi, 5);
	esi+=memory_int[50];
	esi += edi;
	edi = eax;
	edi |= ebx;
	edi &= ecx;
	ebp = edi;
	edi = eax;
	edi &=ebx;
	edi |= ebp;
	edx = edi + edx + 0x8F1BBCDC;
	eax = _rotl32(eax, 0x1E);
	edi = esi;
	edi = _rotl32(edi, 5);
	edx+=memory_int[51];
	edx += edi;
	edi = esi;
	edi |= eax;
	edi &=ebx;
	ebp = edi;
	edi = esi;
	edi &= eax;
	edi |= ebp;
	ecx = edi + ecx + 0x8F1BBCDC;
	esi = _rotl32(esi, 0x1E);
	edi = edx;
	edi = _rotl32(edi, 5);
	ecx+=memory_int[52];
	ecx += edi;
	edi = edx;
        edi |= esi;
	edi &= eax;
	ebp = edi;
	edi = edx;
	edi &= esi;
	edi |= ebp;
	ebx = edi + ebx + 0x8F1BBCDC;
	edx = _rotl32(edx, 0x1E);
	edi = ecx;
	edi = _rotl32(edi, 5);
	ebx+=memory_int[53];
	ebx += edi;
	edi = ecx;
	edi |= edx;
	edi &= esi;
	ebp = edi;
	edi = ecx;
	edi &= edx;
	edi |= ebp;
	eax = edi + eax + 0x8F1BBCDC;
	ecx = _rotl32(ecx, 0x1E);
	edi = ebx;
	edi = _rotl32(edi, 5);
	eax+=memory_int[54];
	eax += edi;
	edi = ebx;
	edi |= ecx;
	edi &= edx;
	ebp = edi;
	edi = ebx;
	edi &= ecx;
	edi |= ebp;
	esi = edi + esi + 0x8F1BBCDC;
	ebx = _rotl32(ebx, 0x1E);
	edi = eax;
	edi = _rotl32(edi, 5);
	esi+=memory_int[55];
	esi += edi;
	edi = eax;
	edi |= ebx;
	edi &= ecx;
	ebp = edi;
	edi = eax;
	edi &=ebx;
	edi |= ebp;
	edx = edi + edx + 0x8F1BBCDC;
	eax = _rotl32(eax, 0x1E);
	edi = esi;
	edi = _rotl32(edi, 5);
	edx+=memory_int[56];
	edx += edi;
	edi = esi;
	edi |= eax;
	edi &=ebx;
	ebp = edi;
	edi = esi;
	edi &= eax;
	edi |= ebp;
	ecx = edi + ecx + 0x8F1BBCDC;
	esi = _rotl32(esi, 0x1E);
	edi = edx;
	edi = _rotl32(edi, 5);
	ecx+=memory_int[57];
	ecx += edi;
	edi = edx;
        edi |= esi;
	edi &= eax;
	ebp = edi;
	edi = edx;
	edi &= esi;
	edi |= ebp;
	ebx = edi + ebx + 0x8F1BBCDC;
	edx = _rotl32(edx, 0x1E);
	edi = ecx;
	edi = _rotl32(edi, 5);
	ebx+=memory_int[58];
	ebx += edi;
	edi = ecx;
	edi |= edx;
	edi &= esi;
	ebp = edi;
	edi = ecx;
	edi &= edx;
	edi |= ebp;
	eax = edi + eax + 0x8F1BBCDC;
	ecx = _rotl32(ecx, 0x1E);
	edi = ebx;
	edi = _rotl32(edi, 5);
	eax+=memory_int[59];
	eax += edi;
	edi = ecx;
	edi ^= edx;
	edi ^=ebx;
	esi = edi + esi + 0xCA62C1D6;
	ebx = _rotl32(ebx, 0x1E);
	edi = eax;
	edi = _rotl32(edi, 5);
	esi+=memory_int[60];
	esi += edi;
	edi = ebx;
	edi ^= ecx;
	edi ^= eax;
	edx = edi + edx + 0xCA62C1D6;
	eax = _rotl32(eax, 0x1E);
	edi = esi;
	edi = _rotl32(edi, 5);
	edx+=memory_int[61];
	edx += edi;
	edi = eax;
	edi ^=ebx;
	edi ^= esi;
	ecx = edi + ecx + 0xCA62C1D6;
	esi = _rotl32(esi, 0x1E);
	edi = edx;
	edi = _rotl32(edi, 5);
	ecx+=memory_int[62];
	ecx += edi;
	edi = esi;
	edi ^= eax;
	edi ^= edx;
	ebx = edi + ebx + 0xCA62C1D6;
	edx = _rotl32(edx, 0x1E);
	edi = ecx;
	edi = _rotl32(edi, 5);
	ebx+=memory_int[63];
	ebx += edi;
	edi = edx;
	edi ^= esi;
	edi ^= ecx;
	eax = edi + eax + 0xCA62C1D6;
	ecx = _rotl32(ecx, 0x1E);
	edi = ebx;
	edi = _rotl32(edi, 5);
	eax+=memory_int[64];
	eax += edi;
	edi = ecx;
	edi ^= edx;
	edi ^=ebx;
	esi = edi + esi + 0xCA62C1D6;
	ebx = _rotl32(ebx, 0x1E);
	edi = eax;
	edi = _rotl32(edi, 5);
	esi+=memory_int[65];
	esi += edi;
	edi = ebx;
	edi ^= ecx;
	edi ^= eax;
	edx = edi + edx + 0xCA62C1D6;
	eax = _rotl32(eax, 0x1E);
	edi = esi;
	edi = _rotl32(edi, 5);
	edx+=memory_int[66];
	edx += edi;
	edi = eax;
	edi ^=ebx;
	edi ^= esi;
	ecx = edi + ecx + 0xCA62C1D6;
	esi = _rotl32(esi, 0x1E);
	edi = edx;
	edi = _rotl32(edi, 5);
	ecx+=memory_int[67];
	ecx += edi;
	edi = esi;
	edi ^= eax;
	edi ^= edx;
	ebx = edi + ebx + 0xCA62C1D6;
	edx = _rotl32(edx, 0x1E);
	edi = ecx;
	edi = _rotl32(edi, 5);
	ebx+=memory_int[68];
	ebx += edi;
	edi = edx;
	edi ^= esi;
	edi ^= ecx;
	eax = edi + eax + 0xCA62C1D6;
	ecx = _rotl32(ecx, 0x1E);
	edi = ebx;
	edi = _rotl32(edi, 5);
	eax+=memory_int[69];
	eax += edi;
	edi = ecx;
	edi ^= edx;
	edi ^=ebx;
	esi = edi + esi + 0xCA62C1D6;
	ebx = _rotl32(ebx, 0x1E);
	edi = eax;
	edi = _rotl32(edi, 5);
	esi+=memory_int[70];
	esi += edi;
	edi = ebx;
	edi ^= ecx;
	edi ^= eax;
	edx = edi + edx + 0xCA62C1D6;
	eax = _rotl32(eax, 0x1E);
	edi = esi;
	edi = _rotl32(edi, 5);
	edx+=memory_int[71];
	edx += edi;
	edi = eax;
	edi ^=ebx;
	edi ^= esi;
	ecx = edi + ecx + 0xCA62C1D6;
	esi = _rotl32(esi, 0x1E);
	edi = edx;
	edi = _rotl32(edi, 5);
	ecx+=memory_int[72];
	ecx += edi;
	edi = esi;
	edi ^= eax;
	edi ^= edx;
	ebx = edi + ebx + 0xCA62C1D6;
	edx = _rotl32(edx, 0x1E);
	edi = ecx;
	edi = _rotl32(edi, 5);
	ebx+=memory_int[73];
	ebx += edi;
	edi = edx;
	edi ^= esi;
	edi ^= ecx;
	eax = edi + eax + 0xCA62C1D6;
	ecx = _rotl32(ecx, 0x1E);
	edi = ebx;
	edi = _rotl32(edi, 5);
	eax+=memory_int[74];
	eax += edi;
	edi = ecx;
	edi ^= edx;
	edi ^=ebx;
	esi = edi + esi + 0xCA62C1D6;
	ebx = _rotl32(ebx, 0x1E);
	edi = eax;
	edi = _rotl32(edi, 5);
	esi+=memory_int[75];
	esi += edi;
	edi = ebx;
	edi ^= ecx;
	edi ^= eax;
	edx = edi + edx + 0xCA62C1D6;
	eax = _rotl32(eax, 0x1E);
	edi = esi;
	edi = _rotl32(edi, 5);
	edx+=memory_int[76];
	edx += edi;
	edi = eax;
	edi ^=ebx;
	edi ^= esi;
	ecx = edi + ecx + 0xCA62C1D6;
	esi = _rotl32(esi, 0x1E);
	edi = edx;
	edi = _rotl32(edi, 5);
	ecx+=memory_int[77];
	ecx += edi;
	edi = esi;
	edi ^= eax;
	edi ^= edx;
	ebx = edi + ebx + 0xCA62C1D6;
	edx = _rotl32(edx, 0x1E);
	edi = ecx;
	edi = _rotl32(edi, 5);
	ebx+=memory_int[78];

	ebx += edi;
	edi = edx;
	edi ^=esi;
	edi ^=ecx;
	eax = edi + eax + 0xCA62C1D6;
	ecx = _rotl32(ecx, 0x1E);
	edi = ebx;
	edi = _rotl32(edi, 0x5);
	eax +=memory_int[79];
	eax +=edi;
	
	////cout<<(hex)<<ecx<<endl;
	////cout<<(hex)<<cont_val[2]<<endl;
	cont_val[0]+=eax;
	cont_val[1]+=ebx;
	cont_val[2]+=ecx;
	cont_val[3]+=edx;
	cont_val[4]+=esi;
	////cout<<(hex)<<cont_val[0]<<endl;
	////cout<<(hex)<<cont_val[1]<<endl;
	////cout<<(hex)<<cont_val[2]<<endl;
	////cout<<(hex)<<cont_val[3]<<endl;
	////cout<<(hex)<<cont_val[4]<<endl;

	edx = 0;
	esi = __builtin_bswap32(cont_val[3]);
	edi = __builtin_bswap32(cont_val[4]);
	////cout<<(hex)<<esi<<endl;
	////cout<<(hex)<<edi<<endl;
	ebp = 32;
for(;ebp>0;ebp--){
	edx += 0x9E3779B9;
	eax = edi;
	ecx = eax;
	ebx = edi;
	eax = (eax << 4);
	////cout<<(hex)<<ebx<<endl;	
	ebx = (ebx >> 5);
	ebx &= 0x7FFFFFF;

	////cout<<(hex)<<(unsigned int)ebx<<endl;
	int *po = (int*)val_con;

	eax += po[0];
	////cout<<(hex)<<ebx<<endl;
	ebx += po[1];
	////cout<<(hex)<<po[1]<<endl;
	////cout<<(hex)<<ebx<<endl;
	//break;
	ecx+=edx;
	ecx^=eax;
	ecx ^= ebx;
	esi+=ecx;
	eax = esi;
	ebx = esi;
	ecx = esi;
	eax = eax << 4;
	ebx = ebx >> 5;
	ebx &= 0x7FFFFFF;
	eax += po[2];
	ebx += po[3];

	ecx += edx;
	ecx ^= eax;
	ecx ^= ebx;
	edi += ecx;
}
	////cout<<"Part 1"<<endl;
	////cout<<(hex)<<esi<<endl;
	////cout<<(hex)<<edi<<endl;
	int* hash = new int[2];
	hash[0] = esi;
	hash[1] = edi;
	getHash((char*)hash);
	

}

unsigned char lrotl(char value,unsigned char rotation)
{
return (value<<rotation) | (value>>(sizeof(value)*8 - 
rotation));
}

char* getLogin()
{
	char* name = new char[16*4];
	cin>>name;
	char* login = new char[16*4];
	for(int i=0;i<16*4;i++)
		login[i] = 0;
	if(strlen(name)<=5){
		//cout<<"login is too small (6+)"<<endl;
		return 0;
	}
	if(strlen(name)>10){
		//cout<<"login is too big (10-)"<<endl;
		return 0;
	}
	for(int i=0;i<strlen(name);i+=2)
        {
		////cout<<(hex)<<(int)name[i]<<" ";
		name[i]-=4;
	}
	
	for(int i=0;i<strlen(name);i++)
	{
		////cout<<(hex)<<(int)name[i]<<" ";
		name[i] = lrotl(name[i], 2);
		login[i] = name[i];
		
	}
	////cout<<endl;
	for(int i=0;i<16*4;i++)
	{
		//cout<<(hex)<<(int)name[i]<<" ";
	}
	login[strlen(name)] = 0x80;
	login[16*4-1] = strlen(name)*8;
	////cout<<endl;
	return login;
}
int main()
{
	////cout<<(hex)<<_rotl32(0xeb0aeb0a, 1);
	hackfunk(getLogin());
	return 0;
}






