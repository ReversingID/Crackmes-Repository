import hashlib
import struct
import tea
import binascii
# Calculamos la longitud que debe tener nuestro nombre como mínimo
longmin=(0x10960/0x182-0x40)/16-1
print("Longitud minima:",longmin)
nombre = "sisco_0"
nombre = input("Nombre (min len is 6, max is 10): ")
assert(len(nombre)>=6)
print("Nombre:",nombre)
nombre = list(nombre)
for c in range(len(nombre)):
	nombre[c] = ord(nombre[c])
# Va modificando nuestro nombre, en las posiciones 0,2,4... Va restando 0x4
contador = 0
while contador < len(nombre):
	nombre[contador] = nombre[contador]-0x04
	contador = contador+2
# Debug
for c in range(len(nombre)):
	nombre[c] = chr(nombre[c])
print("Modificados pares:","".join(nombre))
for c in range(len(nombre)):
	nombre[c] = ord(nombre[c])
# /Debug
# Ahora va modificando haciendo rotacion a la izquierda
for c in range(len(nombre)):
	temp = nombre[c]>>6
	nombre[c] = ((nombre[c]<<0x2)&0xFF)+temp
# Debug
print("Rotado:",nombre)
# /Debug
# SHA1
sha1 = hashlib.sha1(struct.pack(len(nombre)*'B',*nombre)).hexdigest()
print("SHA1:",sha1)
# TEA
teaval=[struct.unpack("<I",binascii.unhexlify(sha1[-16:-8]))[0],
	struct.unpack("<I",binascii.unhexlify(sha1[-8:]))[0]]
teakey=[0xe409c33d,0xe40789aa,0x03deef20,0xe806c3b4]
teares=tea.encipher(teaval,teakey)
# MD4
md4val=struct.pack("<I",teares[0])+struct.pack("<I",teares[1])
print("TEA:",md4val)
md4res=hashlib.new('md4',md4val).hexdigest().upper()
print("MD4:",md4res)
# No es necesaria la parte MD4, nos quedamos con lo de TEA
# Debemos buscar en una tabla.
md4val+=bytes("\x00\x00\x00\x00",'utf-8')
s=[]
for k in range(3):
	s.append((md4val[3*k+0]>>2))
	s.append(((((md4val[3*k+0] & 0x03)<<4))|((md4val[3*k+1] & 0xf0)>>4)))
	s.append(((((md4val[3*k+1] & 0x0f)<<2))|((md4val[3*k+2] & 0xc0)>>6)))
	s.append((md4val[3*k+2] & 0x3f))
# Ahora debemos ir buscando en la tabla
tabla=list("\x00\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\x3E\xFF\xFF\xFF\x3F\x34\x35\x36\x37\x38\x39\x3A\x3B\x3C\x3D\xFF\xFF\xFF\x00\xFF\xFF\xFF\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0A\x0B\x0C\x0D\x0E\x0F\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\xFF\xFF\xFF\xFF\xFF\xFF\x1A\x1B\x1C\x1D\x1E\x1F\x20\x21\x22\x23\x24\x25\x26\x27\x28\x29\x2A\x2B\x2C\x2D\x2E\x2F\x30\x31\x32\x33\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF")
for c in range(len(tabla)):
	tabla[c] = ord(tabla[c])
c = 0
for x in s:
	s[c]=tabla.index(x)
	c=c+1
s[c-1]=0x3d
# Serial válido
print("Serial:",''.join('%02X'%b for b in s))