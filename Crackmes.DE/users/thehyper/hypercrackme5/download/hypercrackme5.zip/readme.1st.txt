=================
++HyperCrackMe5++
=================

level=0+
Compiler=Visual Basic 6.0
Packer=NA
Encryption/decryption=NA

About this crackme
++++++++++++++++++

This is my first miniprogram and crackme coded in visual basic. 

Rules
+++++

-1. Find the unlock code and enable the crackme.
 0. Also find the serial for your name and register the crackme.
 1. as always, no patching
 2. don't give up
 3. you can write a keygen.
 4. use any tool
 5. enjoy it
 6. and remember pls, no patching!!!!
 7. don't forget to send your solution to crackmes.de	

Greetings to everyone who thinks visual basic rocks/sucks!!!


============
++TheHyper++
============