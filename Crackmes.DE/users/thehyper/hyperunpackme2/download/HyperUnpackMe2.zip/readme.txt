HyperUnpackMe2
++++++++++++++++

Difficulty Level: 5

You must unpack a protected notepad executable

I  have added some cool anti-debugging tricks :D
Let's me see how you will bypass them 

Will work only on Windows XP. May work in Windows 2000 and 2003.

P.S 

I have tried my best to make this unpackme to work in XP. If it crashes on your system, then i am very sorry

This is a revised and improved version. I hope it will work on all versions of XP. I have also removed the bsod. 