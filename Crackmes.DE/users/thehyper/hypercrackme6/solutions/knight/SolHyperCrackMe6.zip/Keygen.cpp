#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <stdlib.h>
#include <time.h>
#include "resource.h"

//for easier byte - dword manipulation
union DWTB{
	DWORD dw;
	byte bt[4];
};

void Generate(HWND hWnd)
{
	DWTB ser_p[5], msg[2];
	int seed;
	char serial[25];
	srand(time(NULL));

	//randomly generates first 3 parts
	for(int i = 0; i < 3; i++)
		for(int j = 0; j < 4; j++)
			ser_p[i].bt[j] = rand() % 0x4A + 0x30;

	//calculate seed
	seed = (ser_p[0].dw % 0xFFFF + ser_p[1].dw % 0xFFFF + ser_p[2].dw % 0xFFFF) % 0xFFFF / 0xFF;
	srand(seed);

	//we need only first 8 bytes of msg
	for(int i = 0; i < 8; i++)
		msg[i / 4].bt[i % 4] = rand() % 26 + 32;

	//calculate two last serial parts
	ser_p[3].dw = msg[0].dw ^ 0x646F6F47;	//dooG - little endian
	ser_p[4].dw = msg[1].dw ^ 0x63617243;	//carC

	//format serial
	serial[4] = serial[9] = serial[14] = serial[19] = '-';
	serial[24] = 0;
	for(int i = 0; i < 5; i++)
		for(int j = 0; j < 4; j++)
			serial[i * 5 + j] = ser_p[i].bt[j];
	SetDlgItemText(hWnd, IDC_SERIAL, serial);
}

static BOOL CALLBACK DlgAbout(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
	case WM_INITDIALOG:
		SetDlgItemText(hwnd, IDC_EDIT1, "2005 06 02");
		SetDlgItemText(hwnd, IDC_EDIT2, "Knight");
		SetDlgItemText(hwnd, IDC_EDIT3, "HyperCrackMe6 (HyperCrackMe6.exe)");
		break;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDOK:
			EndDialog(hwnd, 0);
			break;
		}
		break;
	default:
		return FALSE;
	}
	return true;
}

static BOOL CALLBACK DlgFunc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
		case WM_INITDIALOG:
			SendMessage(hwnd, WM_SETICON, ICON_SMALL, (LPARAM)LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1)));
			SendMessage(hwnd, WM_SETICON, ICON_BIG, (LPARAM)LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1)));
			break;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case IDC_BEXIT:
					EndDialog(hwnd, 0);
					break;
				case IDC_BABOUT:
					DialogBox(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_ABOUT), hwnd, DlgAbout);
					break;
				case IDC_BGEN:
					Generate(hwnd);
					break;
			}
			break;
		case WM_CLOSE:
			EndDialog(hwnd, 0);
		default:
			return FALSE;
	}
	return TRUE;
}

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	return DialogBox(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, DlgFunc);
}
