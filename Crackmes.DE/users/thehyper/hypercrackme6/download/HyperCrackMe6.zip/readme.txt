Name: HyperCrackMe6
Coder: TheHyper
Difficulty Level: 2
Compiler: VC++ 6.0

Rulez
+++++

1. No patching
2. Find a serial and if you are bored, try writing a keygen  (very easy)

Remarks
+++++++

1. The crackme will notify you if you have 'supplied' the correct serial
2. A bit of basic encryption
3. No packing

Please give your opinion for this crackme in the solution! I need your suggestions

Happy cracking!



I know that my previous vb crackme sucks!! 

clue: there is a hidden button which is used for registration