Special christmas crackme... very easy...
Try to make a keygen for this one and...
don't patch !!!!!!

NOTE: is this another crypto crackme?
      yeah :P


Greets to:
Ox87k, l0calh0st, Ank83, cyclops, lord_phoenix, x15or, BugHunter,
and all people from crackmes.de, ARTEAM and iNFLUENCE forum...