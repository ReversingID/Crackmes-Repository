=====================
HMX0101's Keygenme #3
=====================

This is my new crackme with easy antidebugging
tricks and medium hashing routine specially
for intermediate crackers with a lame serial
checking.

To beat this crackme, you need:
	
	- Analyze the algo
	- Make a keygen
	- Write a tutorial

Rules:

	- Patching is not allowed.

==========
Greets to:
==========

TWiST, dila, moofy, ScR1pT_, Ank83, KLiZMA, Kerberos, 
R.E.M, CracksLatinos, and all members in crackmes.de

===============
Regards,
HMX0101 / R.E.M
===============