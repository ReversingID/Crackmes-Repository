﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-

from fractions import Fraction,gcd
from zlib import crc32
import copy

def gausselim(A, B, ztol = 1.0e-8):

    size = len(A)
    X    = [0.0] * size
    R    = range(size)
    C    = range(size)
    code = 0

    # Triangularization.
    for pivot in range(size - 1):
        absm    = abs(A[pivot][pivot])
        exchrow = pivot
        exchcol = pivot

        for row in range(pivot + 1, size):
            atestm  = abs(A[row][pivot])
            if atestm > absm:
                absm    = atestm
                exchrow = row

        # Exchange columns ? 
        if pivot != exchcol:
            for row in range(pivot, size):
                A[row][pivot], A[row][exchcol] = A[row][exchcol], A[row][pivot]
            C[pivot] = exchcol

        # Exchange rows?
        if pivot != exchrow:
            A[exchrow],A[pivot] = A[pivot], A[exchrow]
            B[exchrow],B[pivot] = B[pivot], B[exchrow]
            R[pivot] = exchrow

        if absm > ztol:
            m = float(A[pivot][pivot])
            for row in range(pivot +1, size): 
                kmul = float(A[row][pivot])/m 
                # Apply rectangular rule.(Reduction)
                for col  in range(size - 1, pivot, -1):
                    A[row][col] = float(A[row][col]) - kmul * A[pivot][col]
                B[row] = float(B[row]) - kmul * B[pivot]
                A[row][pivot] = 0.0
        else:
            code = 1

    # Perform Back substitution.
    if code == 0:
        for row in range(size-1, -1, -1):
            sum = B[row]
            for k in range(row+1, size):
                sum -= (X[k] * A[row][k])
            X[row] = sum/A[row][row]
        reorder(X, C)
    return (code,R,C, A,X,B)

def reorder(X, C):
    for i, c in enumerate(C):
        if i != c:
            # exchange elements at positions i and c.
            X[i], X[c] =  X[c], X[i]
    return X

def solve(A, b):
    (code, R,C, A, X, B) = gausselim(A, b)
    if code == 0:
        return X
    else:
        return None

# returns the least common multiple
lcm = lambda ns: reduce(lambda x,y:x*y/gcd(x,y),ns)

if __name__ == "__main__":

    serial   = ''
    bin      = ''
    divisor  = 0
    divs     = []
    tooShort = 0
    
    name = raw_input("your name: ")
    crcval = str(abs(crc32(name) + 0x13333337))
    crcval = crcval[::-1]
    # check if length of crc32 value is too short. if true, add an element
    if len(crcval) < 9:
        crcval += '0'
        tooShort = 1
    crcval = crcval[:9]

    A = []
    A.append(list(crcval[::3]))
    A.append(list(crcval[1::3]))
    A.append(list(crcval[2::3]))
    
    # if crc32 value was too short, make the last element in the matrix == -3
    if tooShort:
        A[2][2] = '-3'

    for item in A:
        for i in xrange(len(item)):
            item[i] = int(item[i])

    B = [[1, 0, 0],[0, 1, 0],[0, 0, 1]]
    B1 = copy.deepcopy(B)

    # search the divisor - it's needed because sometimes a value is odd and can't be reduced more but others aren't
    # ex.: 41/135 and 5/27 <- we need to make it all like x/135.
    A1 = copy.deepcopy(A)
    for i in xrange(3):
        A1 = copy.deepcopy(A)
        X = solve(A1,B1[i])
        for num in X:
            if num != 0.0:
                fracs = str(Fraction.from_float(num).limit_denominator()).split('/')
                if len(fracs) > 1:
                    div = int(fracs[1])
                    divs.append(div)
    divisor = lcm(divs)

    B[0][0] = divisor
    B[1][1] = divisor
    B[2][2] = divisor

    B1 = copy.deepcopy(B)
    for i in xrange(3):
        A1 = copy.deepcopy(A)
        X = solve(A1,B1[i])
        for num in X:
            value = '%X' % abs(int(str(Fraction.from_float(num).limit_denominator()).split('/')[0]))
            if num < 0:
                bin += '1'
            else:
                bin += '0'
            serial += value + '.'
    serial += '%X' % divisor + '.'
    
    bin = bin[::-1]
    lastnum = 0
    for i in xrange(len(bin)):
        if bin[i] == '1':
            lastnum <<= 1
            lastnum += 1
        else:
            lastnum <<= 1

    serial += '%X' % lastnum
    print 'your serial:', serial
