// user2k(at)user2k.wz.cz 
// use in peace...

#include <stdio.h>

typedef unsigned long dd;
typedef long sd;

unsigned long curvalue;
unsigned long cureax;

int main(void)
{

    dd buf_455be0[8];
    dd buf_455c00[8];
    dd buf_455bd8[2];
    int i,j;
    
    srand(time(NULL));
    curvalue = rand()*13^rand();
    unsigned long startval = curvalue;
    
    cureax = 0x0ffffffff;		 				//1.1
    curvalue = ((curvalue*0x8088405)+1);
    __asm__ ("movl cureax, %eax;" "movl curvalue, %edx;"
             "mul %edx;" "movl %eax, cureax;" "movl %edx, curvalue;");
    buf_455bd8[0] = curvalue;
    
    for (i=0;i<8;i++) {							//1.2
        cureax = 0x0ffffffff;
	curvalue = ((curvalue*0x8088405)+1);
	__asm__ ("movl cureax, %eax;" "movl curvalue, %edx;"
             "mul %edx;" "movl %edx, cureax;");
	buf_455be0[i] = cureax ^ 0x67452301;
    }

    cureax = 0x0ffffffff;						//1.3    
    curvalue = ((curvalue*0x8088405)+1);
    __asm__ ("movl cureax, %eax;" "movl curvalue, %edx;"
             "mul %edx;" "movl %eax, cureax;" "movl %edx, curvalue;");
    buf_455bd8[1] = curvalue;
    
    for (i=0;i<8;i++) {							// 1.4
        cureax = 0x0ffffffff;
	curvalue = ((curvalue*0x8088405)+1);
	__asm__ ("movl cureax, %eax;" "movl curvalue, %edx;"
             "mul %edx;" "movl %edx, cureax;");
	buf_455c00[i] = cureax ^ 0xEFCDAB89;
    }
    for (i=0;i<20;i++) {						// 1.5.1
	for (j=0;j<8;j++) {
	    if (i&1) buf_455be0[j] = ~buf_455be0[j];
	    else buf_455be0[j] = buf_455be0[j] ^ buf_455c00[j];
	}
	for (j=0;j<8;j++) {
	    if (i&1) buf_455c00[j] = ~buf_455c00[j];
	    else buf_455c00[j] = buf_455c00[j] ^ buf_455be0[j];
	}
    }
    for	(i=0;i<8;i++) {							// 1.5.2
	buf_455be0[0] = (buf_455be0[i]+buf_455be0[i]) ^ 0x4142;
	buf_455c00[1] = (buf_455c00[i]<<2) ^ 0x4344;
    }
							      // rest not needed
    printf("RANDOM VALID KEY %08X-%04X-%04X \r\n",startval,(0x0ffff & buf_455be0[0]),(0x0ffff & buf_455c00[0]));
    
    return 0;
}
