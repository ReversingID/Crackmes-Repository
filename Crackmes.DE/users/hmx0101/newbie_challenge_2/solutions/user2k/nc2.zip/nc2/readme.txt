solution for NC2 by user2k(at)user2k.wz.cz

Keygen written in gcc [linux binary and source code included]
using only stdio, so u can "probably" compile it on windows.

keygen generating random keys [1 a time]

First the key
0-7 - 0x0452951 -> first part of the key is getted
8 - empty -> not used
9-11 (second part of key search GetText)
12 - empty -> not used
13-16 (third part of key like in second part)

1' 0-7 (first part of the key compute)
(from 1.1 to 1.4 some asm in keygen code was used (eax:edx from mul needed)

1.1  -> 0x045261b [look at code]
    curvalue = 0-7 [first 8 bytes of key in HEX]
    eax = 0xffffffff
    imul edx,value,0x8088405
    inc edx
    mul eax,edx
    mov eax,edx
    eax stored in 0x455bd8 and curvalue

1.2 -> 0x0452632 
    esi = 0x455ce0
    8 repeats [dwords]
    {
	eax = 0xffffffff
	imul edx,curvalue,0x8088405
	inc edx
	curvalue = edx
	mul eax,edx
	mov edx,eax
	xor eax,0x67452301
	mov [esi], eax
	add esi,4
    }
    
1.3 -> same as 1.1 -> 0x452651
    eax = 0xffffffff
    imul edx,curvalue,0x8088405
    inc edx
    mul eax,edx
    eax stored in 0x455bdc and curvalue

1.4 -> 0x452672
almost same like 1.2, ony buffer[esi] and xor[efcdab89] diff

    esi = 0x455c00
    8 repeats [dwords]
    {
	eax = 0xffffffff
	imul edx,curvalue,0x8088405
	inc edx
	curvalue = edx
	mul eax,edx
	mov eax,edx
	xor eax,0xEFCDAB89
	mov [esi],eax
	add esi,4
    }
    
1.5.1  0x45268c
    20h repeats = ecx (nothing to say, just some xoring/not-ing :)
       {
		5 repeats = esi
		{
		    esi == 1 -> edi = 455c00 / edx = 455be0
			cl = np -> just not edx
			cl = p  -> xor [edx],[edi] 8 times edx+=4 edi+=4 
		    esi == 2 -> edi = 455be0 / edx = 455c00
			same
		    esi > 2 -> do nothing [3x do nothing, waste of time :P
		}
	}
	
1.5.2	this code just after 1.5.1
	5 repeats = esi
	{
		esi == 1 -> edx = 455be0
			[455be0] = ([edx]+[edx]) ^ 4142h; edx+=4
		esi == 2 -> edx = 455c00
			[455c04] = (edx<<2)^4344h; edx+=4 
			
			[here is (i think) mistake of author, should be 00!]
			[455c00 not modified so why to compute if only this
			[part is used later
		esi > 2 -> do nothing [another 3x do nothing
	}
1.5.3   making binary from first word in the first buffer
	[455be0] & FFFF
	eax = 1; ecx = 1
	until [455be0] != 0
	{
	    dl = p (pair)
		(([455c1c+ecx*4] | 1) << 4)
	    dl = np (not pair)
		<< 4
	    [455be0] >> 1
	    after 8 bits [eax counting] increase ecx, eax = 1
	} should generate sth like 10111001 . 10100101 . 00001111
	
1.5.4  making binary from first word of the second buffer
	[455c00] & FFFF
	eax = 1; ecx = 1
	until [455c00] != 0
	    same code [recorded in [455c24+ecx*4]

keyparts 9-11 and 13-16 have got same calculation like in 1.5.3 and 1.5.4
so we dont need >=1.5.3 , just get rest of key after 1.5.2 ends.

so long.


