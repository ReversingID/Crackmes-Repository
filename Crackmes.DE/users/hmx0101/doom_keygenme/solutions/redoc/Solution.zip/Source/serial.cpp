#undef UNICODE
#undef _UNICODE
#include <windows.h>
#include "main.h"

#define	MAX_VALUE	36

struct BRIDGE {
	char from;
	char to;
	POINT ptFrom;
	POINT ptTo;
	int length;
};
struct BRUTE_NODE {
	POINT	point;
	int intBruteValues[16];
	int intBruteMax;	// number of values in intBruteValues[]
};


// proto
extern "C" int base32_decode (unsigned char *encoded, unsigned char *result, int bufSize);
extern "C" int base32_encode (unsigned char *data, int length, unsigned char *result, int bufSize);
// vars
extern "C" HWND g_hKeygenSerial;
extern "C" char g_szSerialDecoded[256];

//----------------------------------------
__inline int GetDistance (POINT A, POINT B)
{
	return (abs(A.x - B.x) + abs(A.y - B.y));
}
//----------------------------------------
POINT ShiftPoint (const int table[6][6], POINT X, bool &bAmbiguous)
{
	POINT pRet = {0};
	bool bAssigned = false;
	bAmbiguous = false;

	// up
	if (X.x > 0)
		if (table[X.x-1][X.y] == 0)
			{pRet.x = X.x-1; pRet.y = X.y; bAssigned = true;}
	// right
	if (X.y < 5)
		if (table[X.x][X.y+1] == 0)
			if (bAssigned)
				{bAmbiguous = true; return pRet;}
			else
				{pRet.x = X.x; pRet.y = X.y+1; bAssigned = true;}
	// down
	if (X.x < 5)
		if (table[X.x+1][X.y] == 0)
			if (bAssigned)
				{bAmbiguous = true; return pRet;}
			else
				{pRet.x = X.x+1; pRet.y = X.y; bAssigned = true;}
	// left
	if (X.y > 0)
		if (table[X.x][X.y-1] == 0)
			if (bAssigned)
				{bAmbiguous = true; return pRet;}
			else
				{pRet.x = X.x; pRet.y = X.y-1; bAssigned = true;}

	if (!bAssigned) bAmbiguous = true;
	return pRet;
}
//----------------------------------------
POINT FindCoords (const int table[6][6], char c)
{
	POINT ret = {0};
	for (DWORD i=0; i<6; i++)
		for (DWORD j=0; j<6; j++)
			if (table[i][j] == (int)c)
				{ret.x = i; ret.y = j; break;}
	return ret;
}
// return > 0 if some advance was reached
//----------------------------------------
unsigned int AdvanceGraph (int table[6][6])
{
	POINT pStart, pEnd;
	int i, j;
	bool numbers[37]={0};
	BRIDGE Bridges[18] = {0};
	bool bInBridge = false;
	int intBridgeCount = 0;
	unsigned int dwRet = 0;

	for (i=0; i<6; i++)
		for (j=0; j<6; j++)
			if (table[i][j] > 0 && table[i][j] <= 36)
				numbers[table[i][j]] = true;

	/////////////////////////////////////////////////
	// determine 'jumps' - bridges
	if (!numbers[1])
		{Bridges[intBridgeCount].from = -1; bInBridge = true;}		// point 1 is not known till now

	for (i=1; i<36; i++)
		if (numbers[i] && bInBridge) {
			Bridges[intBridgeCount].to = (char)i;
			Bridges[intBridgeCount].ptTo = FindCoords (table, Bridges[intBridgeCount].to);
			intBridgeCount++;
			bInBridge = false;
		}
		else if (!numbers[i] && !bInBridge) {
			Bridges[intBridgeCount].from = (char)(i-1);
			Bridges[intBridgeCount].ptFrom = FindCoords (table, Bridges[intBridgeCount].from);
			bInBridge = true;
		}

	if (bInBridge)
		{Bridges[intBridgeCount].to = -1; intBridgeCount++;}			// point 36 is not known till now

	// set distance of jumps
	for (i=0; i<intBridgeCount; i++) {
		if (Bridges[i].from == -1)
			Bridges[i].length = Bridges[i].to - 1;
		else if (Bridges[i].to == -1)
			Bridges[i].length = MAX_VALUE - Bridges[i].from;
		else
			Bridges[i].length = Bridges[i].to - Bridges[i].from - 1;
	}

	// we can try to resolve starts and ends of jumps
	/////////////////////////////////////////////////
	for (i=0; i<intBridgeCount; i++)
	{
		bool bAmbiguous, bHaveStart=false, bHaveEnd=false;

		if (Bridges[i].from != -1) {
			pStart = ShiftPoint (table, Bridges[i].ptFrom, bAmbiguous);
			if (!bAmbiguous) {
				bHaveStart = true; table[pStart.x][pStart.y] = Bridges[i].from + 1; dwRet++;
				if (Bridges[i].length == 1) continue;
			}
		}
		if (Bridges[i].to != -1) {
			pEnd = ShiftPoint (table, Bridges[i].ptTo, bAmbiguous);
			if (!bAmbiguous) {
				bHaveEnd = true; table[pEnd.x][pEnd.y] = Bridges[i].to - 1; dwRet++;
				if ((Bridges[i].length == 1) || (Bridges[i].length == 2 && bHaveStart))
					continue;
			}
		}

		// we can safely finalize path if the rest of path is 1 point long and is in same line or column
		if (Bridges[i].length == 3 && bHaveStart && bHaveEnd)
			if (pStart.x == pEnd.x) {
				table [pStart.x] [min(pStart.y,pEnd.y) + 1] = Bridges[i].from + 2;
				dwRet++;
			}
			else if (pStart.y == pEnd.y) {
				table [min(pStart.x,pEnd.x) + 1] [pStart.y] = Bridges[i].from + 2;
				dwRet++;
			}
	}
	return dwRet;
}

//############################################################
int g_brute_table[6][6];
BRUTE_NODE	g_brute_points[16];
int g_intBrutePointsMax;
BRIDGE g_brute_bridges[18] = {0};
int g_intBridgeCount = 0;
char g_intCurrentValues[16];
bool g_bBruteSuccess;

//----------------------------------------
bool TestSnake (BRIDGE bridge)
{
	int len = 0;
	bool bAscending;

	if (bridge.from == bridge.to) return false;

	if (bridge.from == -1)
		bAscending = false;
	else if (bridge.to == -1)
		bAscending = true;
	else
		bAscending = (bridge.from <= bridge.to);

	POINT pt = bAscending ? bridge.ptFrom : bridge.ptTo;
	int intValToFind = bAscending ? bridge.from + 1 : bridge.to - 1;

	if (bridge.from == -1 || bridge.to == -1)
		len = 1;

	for ( ; len <= bridge.length; len++)
	{
		if ((pt.x > 0) && (g_brute_table[pt.x-1][pt.y] == intValToFind))
			pt.x--;	// up
		else if ((pt.y < 5) && (g_brute_table[pt.x][pt.y+1] == intValToFind))
			pt.y++;	// right
		else if ((pt.x < 5) && (g_brute_table[pt.x+1][pt.y] == intValToFind))
			pt.x++;	// down
		else if ((pt.y > 0) && (g_brute_table[pt.x][pt.y-1] == intValToFind))
			pt.y--;	// left
		else
			return false;	// snake error

		if (bAscending) {
			if (bridge.to == -1)
				{if (len == bridge.length) return true;}
			else if ((intValToFind==bridge.to) && pt.x==bridge.ptTo.x && pt.y==bridge.ptTo.y)
				return true;
		}
		else {
			if (bridge.from == -1)
				{if (len == bridge.length) return true;}
			else if ((intValToFind==bridge.from) && pt.x==bridge.ptFrom.x && pt.y==bridge.ptFrom.y)
				return true;
		}

		intValToFind += bAscending ? 1 : -1;
	}
	return false;
}
//----------------------------------------
bool BruteRecursive (int intNextBrutePoint)
{
	int i, j, intMax, intVal;
	bool bAdd;

 	intMax = g_brute_points[intNextBrutePoint].intBruteMax;
 	for (i=0; i<intMax; i++)
	{
		intVal = g_brute_points[intNextBrutePoint].intBruteValues[i];

		for (bAdd=true, j=0; j < intNextBrutePoint; j++)
			if (intVal == g_intCurrentValues[j])
				{bAdd = false; break;}
		if (!bAdd) continue;

		g_intCurrentValues[intNextBrutePoint] = intVal;
		g_brute_table[g_brute_points[intNextBrutePoint].point.x][g_brute_points[intNextBrutePoint].point.y] = intVal;

		if (intNextBrutePoint < g_intBrutePointsMax - 1)
			BruteRecursive (intNextBrutePoint + 1);
		else if (intNextBrutePoint == g_intBrutePointsMax - 1)		// highest level - test permutation
		{
			for (g_bBruteSuccess=true, j=0; j<g_intBridgeCount; j++)
				if (!TestSnake (g_brute_bridges[j]))
					{g_bBruteSuccess = false; break;}
		}

		if (g_bBruteSuccess)
			return true;
	}
	return false;
}
//----------------------------------------
bool BruteforceGraph (int table[6][6])
{
	int i, j, k;
	bool numbers[37]={0};
	bool bInBridge = false;
	unsigned int dwRet = 0;

	g_intBrutePointsMax = 0; g_intBridgeCount = 0;
	memset (g_brute_points, 0, sizeof(BRUTE_NODE)*16);
	memset (g_brute_bridges, 0, sizeof(BRIDGE)*18);

	for (i=0; i<6; i++)
		for (j=0; j<6; j++)
			if (table[i][j] > 0 && table[i][j] <= 36)
				numbers[table[i][j]] = true;

	// determine 'jumps' - g_brute_bridges
	/////////////////////////////////////////////////
	if (!numbers[1])
		{g_brute_bridges[g_intBridgeCount].from = -1; bInBridge = true;}		// point 1 is not known till now

	for (i=1; i<36; i++)
		if (numbers[i] && bInBridge) {
			g_brute_bridges[g_intBridgeCount].to = (char)i;
			g_brute_bridges[g_intBridgeCount].ptTo = FindCoords (table, g_brute_bridges[g_intBridgeCount].to);
			g_intBridgeCount++;
			bInBridge = false;
		}
		else if (!numbers[i] && !bInBridge) {
			g_brute_bridges[g_intBridgeCount].from = (char)(i-1);
			g_brute_bridges[g_intBridgeCount].ptFrom = FindCoords (table, g_brute_bridges[g_intBridgeCount].from);
			bInBridge = true;
		}

	if (bInBridge)
		{g_brute_bridges[g_intBridgeCount].to = -1; g_intBridgeCount++;}			// point 36 is not known till now

	if (g_intBridgeCount == 0) 
		return true;	// nothing to bruteforce

	// set distance of jumps
	for (i=0; i<g_intBridgeCount; i++) {
		if (g_brute_bridges[i].from == -1)
			g_brute_bridges[i].length = g_brute_bridges[i].to - 1;
		else if (g_brute_bridges[i].to == -1)
			g_brute_bridges[i].length = MAX_VALUE - g_brute_bridges[i].from;
		else
			g_brute_bridges[i].length = g_brute_bridges[i].to - g_brute_bridges[i].from - 1;
	}

	// determine points to bruteforce
	/////////////////////////////////////////////////
	for (i=1; i<5; i++)
		for (j=1; j<5; j++)
			if (table[i][j] == 0) {
				g_brute_points[g_intBrutePointsMax].point.x = i;
				g_brute_points[g_intBrutePointsMax].point.y = j;
				g_intBrutePointsMax++;
			}

	// set their possible values
	for (i=0; i<g_intBrutePointsMax; i++)
		for (j=0; j<g_intBridgeCount; j++)
		{
			int intMin = 1, intMax = 36;

			if (g_brute_bridges[j].from != -1)
				intMin = g_brute_bridges[j].from + GetDistance (g_brute_bridges[j].ptFrom, g_brute_points[i].point);
			if (g_brute_bridges[j].to != -1)
				intMax = g_brute_bridges[j].to - GetDistance (g_brute_bridges[j].ptTo, g_brute_points[i].point);

			if (g_brute_bridges[j].from == -1)
				for (k=intMax; k>=intMin; k-=2) {
					g_brute_points[i].intBruteValues[g_brute_points[i].intBruteMax] = k;	// possible values to bruteforce for one point
					g_brute_points[i].intBruteMax++;
				}
			else
				for (k=intMin; k<=intMax; k+=2) {
					g_brute_points[i].intBruteValues[g_brute_points[i].intBruteMax] = k;	// possible values to bruteforce for one point
					g_brute_points[i].intBruteMax++;
				}

			if (g_brute_bridges[j].to == -1) {
				g_brute_points[i].intBruteValues[g_brute_points[i].intBruteMax] = 0xDCFFFFFF;
				g_brute_points[i].intBruteMax++;
			}
		}

	// start bruteforce
	/////////////////////////////////////////////////
	memcpy (g_brute_table, table, sizeof(int)*6*6);
	g_bBruteSuccess = false;

	if (BruteRecursive (0)) {
		memcpy (table, g_brute_table, sizeof(int)*6*6);
		return true;
	}
	return false;
}
//----------------------------------------
bool ComputeSerial (HWND hDlg)
{
	char szNum[8]={0}, szOut[256]={0};
	unsigned char cVal;
	int i, j, intRet, *pInt;
	int table[6][6];

	// get snake table from process memory
	__asm {
		mov eax, 0x473734
		mov eax, dword ptr[eax]
		mov eax, dword ptr[eax]
		mov eax, dword ptr[eax+4]
		add eax, 4
		mov dword ptr[pInt], eax
	}
	for (i=0; i<6; i++) {
		for (j=0; j<6; j++)
			{table[i][j] = *pInt; pInt++;}
		pInt += 5;
	}

	// convert -36 to 36 ...later we'll convert it back
	for (i=0; i<6; i++)
		for (j=0; j<6; j++)
			if (table[i][j] == -36)
				table[i][j] = 36;

	//***************************
	// optimize
	while (AdvanceGraph(table)) ;
	// rest we can bruteforce
	if (!BruteforceGraph (table))
		{MessageBox (hDlg, "Can't compute serial.", APP_NAME, 0); return false;}
	//***************************

	// convert back 36 to -36
	for (i=0; i<6; i++)
		for (j=0; j<6; j++)
			if (table[i][j] == 36)
				table[i][j] = -36;

	// modify to proper output form...

	memset (g_szSerialDecoded, 0, sizeof(g_szSerialDecoded));
	for (i=1; i<5; i++)
		for (j=1; j<5; j++)
			if (table[i][j] != -36) {
				cVal = (unsigned char) table[i][j];
				wsprintf (szNum, "%u#", cVal);
				lstrcat (g_szSerialDecoded, szNum);
			}
	// align to 59
	for (i=0; i<59; i++)
		if (g_szSerialDecoded[i] == 0)
			g_szSerialDecoded[i] = '-';

	// base32 encode
	intRet = base32_encode ((unsigned char*)g_szSerialDecoded, lstrlen(g_szSerialDecoded), (unsigned char*)szOut, sizeof(szOut));
	if (intRet <= 0)
		{MessageBox (hDlg, "base32_encode() error", APP_NAME, 0); return false;}

	SendMessage (g_hKeygenSerial, WM_SETTEXT, 0, (LPARAM)szOut);

	return true;
}
