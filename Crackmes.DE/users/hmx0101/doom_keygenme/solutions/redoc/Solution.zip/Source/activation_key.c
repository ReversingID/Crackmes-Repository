#undef UNICODE
#undef _UNICODE
#include <windows.h>
#include "main.h"
#include "./MIRACL/miracl.h"
#include "./MD5/md5.h"

HWND g_hWndKeygen, g_hKeygenName, g_hKeygenSerial, g_hKeygenActKey;
char g_szSerialDecoded[256];

//----------------------------------------
BOOL ComputeActKey (HWND hDlg, OUT char ActNum1Bin[128], OUT DWORD *ActNum1Len, \
										OUT char ActNum2Bin[128], OUT DWORD *ActNum2Len)
{
	char szBuf[256] = {0};
	int intLen;
	miracl *mip;
	big actnum1, actnum2, X, C, md5, buf_big;
	MD5_CTX md5_ctx;
	unsigned char md5_hash[16] = {0};

	intLen = SendMessage (g_hKeygenName, WM_GETTEXT, sizeof(szBuf), (LPARAM)szBuf);
	if (intLen < 6) return FALSE;
	strcat_s (&szBuf[intLen], sizeof(szBuf)-intLen, g_szSerialDecoded);
	MD5Init (&md5_ctx);
	MD5Update (&md5_ctx, (unsigned char*)szBuf, lstrlen(szBuf));
	MD5Final (md5_hash, &md5_ctx);

	// Initialize MIRACL library
	mip = mirsys (0x100, 0x10);
	if (mip == 0) return FALSE;
	actnum1 = mirvar(0); actnum2 = mirvar(0); buf_big = mirvar(1);
	X = mirvar(0); C = mirvar(0); md5 = mirvar(0);
	mip->IOBASE = 16;

	// Compute Activation Key
	cinstr (X, "33008243F89B52F94BD1FBE5C18062CF71BCD6AB");
	cinstr (C, "C593BED83AEFB703F775EC8798FF398CF31FEDFF");
	bytes_to_big (16, (char*)md5_hash, md5);
	add (buf_big, md5, actnum1);	// actnum1 = md5_hash + 1
	//ActNum2 = C - (ActNum1*X mod C)
	multiply (actnum1, X, actnum2);	// actnum2 = actnum1 * X
	divide (actnum2, C, C);				// actnum2 = actnum2 mod C
	subtract (C, actnum2, actnum2);	// actnum2 = C - actnum2

	*ActNum1Len = big_to_bytes (128, actnum1, ActNum1Bin, FALSE);
	*ActNum2Len = big_to_bytes (128, actnum2, ActNum2Bin, FALSE);

	mirkill(actnum1); mirkill(actnum2);
	mirkill(X); mirkill(C); mirkill(md5); mirkill(buf_big);
	mirexit ();

	return TRUE;
}