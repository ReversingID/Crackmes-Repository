#undef UNICODE
#undef _UNICODE
#include <windows.h>
#include <CommCtrl.h>
#include "main.h"

#define	NAME_MAX		60

// proto
extern "C" int base32_decode (unsigned char *encoded, unsigned char *result, int bufSize);
extern "C" int base32_encode (unsigned char *data, int length, unsigned char *result, int bufSize);
extern "C" BOOL ComputeActKey (HWND hDlg, OUT char ActNum1Bin[128], OUT DWORD *ActNum1Len, \
										OUT char ActNum2Bin[128], OUT DWORD *ActNum2Len);
bool base64_encode (unsigned char *source, unsigned int sourcelen, char *target, unsigned int targetlen);
bool ComputeSerial (HWND hDlg);

extern "C" HWND g_hWndKeygen, g_hKeygenName, g_hKeygenSerial, g_hKeygenActKey;
HWND g_hCrackmeName, g_hCrackmeSerial, g_hCrackmeActKey, g_hCrackmeButton;

//----------------------------------------
BOOL CALLBACK EnumChildProcCrackme (HWND hwnd, LPARAM lParam)
{
	char szBuf[64];
	RECT rect;

	GetClassName (hwnd, szBuf, sizeof(szBuf));

	if (!lstrcmp (szBuf, "TButton")) {
		GetWindowText (hwnd, szBuf, sizeof(szBuf));
		if (!lstrcmp (szBuf, "Validate"))
			g_hCrackmeButton = hwnd;
	}
	else if (!lstrcmp (szBuf, "TLabeledEdit"))
		g_hCrackmeName = hwnd;
	else if (!lstrcmp (szBuf, "TMemo")) {
		GetWindowRect (hwnd, &rect);
		if (rect.bottom - rect.top == 49)
			g_hCrackmeSerial = hwnd;
		else if (rect.bottom - rect.top == 57)
			g_hCrackmeActKey = hwnd;
	}
	return TRUE;
}
//----------------------------------------
void Test (HWND hDlg)
{
	HWND hWnd;
	char szBuf[256]={0};

	hWnd = FindWindow (NULL, "DOOM Keygenme - coded by HMX0101");
	if (hWnd == NULL)
	{
		ShellExecute (NULL, NULL, "doom-keygenme.exe", NULL, NULL, SW_SHOW);
		Sleep (250);
		hWnd = FindWindow (NULL, "DOOM Keygenme - coded by HMX0101");
	}
	if (hWnd == NULL)
		{MessageBox (hDlg, "Please start doom-keygenme.exe first", APP_NAME, 0); return;}

	g_hCrackmeName=0; g_hCrackmeSerial=0; g_hCrackmeActKey=0; g_hCrackmeButton=0;

	EnumChildWindows (hWnd, EnumChildProcCrackme, 0);

	if (g_hCrackmeName==0 || g_hCrackmeSerial==0 || g_hCrackmeActKey==0 || g_hCrackmeButton==0)
		return;

	SendMessage (g_hKeygenName, WM_GETTEXT, sizeof(szBuf), (LPARAM)szBuf);
	SendMessage (g_hCrackmeName, WM_SETTEXT, 0, (LPARAM)szBuf);
	SendMessage (g_hKeygenSerial, WM_GETTEXT, sizeof(szBuf), (LPARAM)szBuf);
	SendMessage (g_hCrackmeSerial, WM_SETTEXT, 0, (LPARAM)szBuf);
	SendMessage (g_hKeygenActKey, WM_GETTEXT, sizeof(szBuf), (LPARAM)szBuf);
	SendMessage (g_hCrackmeActKey, WM_SETTEXT, 0, (LPARAM)szBuf);

	PostMessage (hWnd, WM_COMMAND, 0, (LPARAM)g_hCrackmeButton);
}
//----------------------------------------
bool Generate (HWND hDlg)
{
	char szBuf[256] = {0};
	char ActNum1Bin[128], ActNum2Bin[128];
	DWORD ActNum1Len, ActNum2Len;
	int intLen;

	if (!ComputeSerial (hDlg))
		return false;

	if (!ComputeActKey (hDlg, ActNum1Bin, &ActNum1Len, ActNum2Bin, &ActNum2Len))
		return false;

	base64_encode ((unsigned char*)ActNum1Bin, ActNum1Len, szBuf, sizeof(szBuf)-1);
	intLen = lstrlen (szBuf);
	szBuf[intLen] = '*';
	base64_encode ((unsigned char*)ActNum2Bin, ActNum2Len, &szBuf[intLen+1], sizeof(szBuf)-intLen-2);

	SendMessage (g_hKeygenActKey, WM_SETTEXT, 0, (LPARAM)szBuf);

	if (IDYES == MessageBox (hDlg, "Done. Want to test the serial?", APP_NAME, MB_YESNO))
		Test (hDlg);

	return true;
}
//----------------------------------------
BOOL CALLBACK EnumChildProcKeygen (HWND hwnd, LPARAM lParam)
{
	char szBuf[64];
	RECT rect;

	GetClassName (hwnd, szBuf, sizeof(szBuf));

	if (!lstrcmp (szBuf, "TLabeledEdit"))
		g_hKeygenName = hwnd;
	else if (!lstrcmp (szBuf, "TMemo")) {
		GetWindowRect (hwnd, &rect);
		if (rect.bottom - rect.top == 49)
			g_hKeygenSerial = hwnd;
		else if (rect.bottom - rect.top == 57)
			g_hKeygenActKey  = hwnd;
	}
	return TRUE;
}
//----------------------------------------
bool ResolveKeygenWndHandles()
{
	g_hWndKeygen = FindWindow (NULL, APP_NAME);
	if (g_hWndKeygen == 0) return false;

	g_hKeygenName=0; g_hKeygenSerial=0; g_hKeygenActKey=0;
	EnumChildWindows (g_hWndKeygen, EnumChildProcKeygen, 0);
	if (g_hKeygenName==0 || g_hKeygenSerial==0 || g_hKeygenActKey==0)
		return false;

	return true;
}
//----------------------------------------
BOOL APIENTRY DllMain (HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
	return TRUE;
}
//----------------------------------------
extern "C"__declspec(dllexport) bool ComputeSerial ()
{
	if (!ResolveKeygenWndHandles())
		{MessageBox (0, "Can't find keygen handles", APP_NAME" (Debug)", 0); return 0;}

	return Generate(g_hWndKeygen);
}
