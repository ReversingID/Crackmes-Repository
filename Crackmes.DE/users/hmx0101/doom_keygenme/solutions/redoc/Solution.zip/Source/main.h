
#include "resource.h"

#define	OUT
#define	APP_NAME		"HMX0101's DOOM - Keygen"
