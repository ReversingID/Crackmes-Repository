Rules are simple, make a keygen for this wicked keygenme :)
No patch, after you analyse it.. you may probably ask, if you miss something or I am crazy?.
I'm not crazy, you missed something, yea! :)

Greets fly out to: Numernia, Encrypto, Cyclops, pusher, everlast, Till.ch and all my other friends I forgot ;P 