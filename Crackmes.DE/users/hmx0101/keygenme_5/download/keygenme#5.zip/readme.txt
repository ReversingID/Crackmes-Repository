=====================
HMX0101's Keygenme #5
=====================

This is my new crackme, with a couples
of antidebugging tricks and crypto-modified
plus a special trick.

To beat this crackme, you need:
	
	- Analyze the algo
	- Remove the timer
	- Make a keygen
	- Write a tutorial

Rules:

	- Patching the goodboy jump not allowed.

==========
Greets to:
==========

Shub-Nigurrath, Taliesin, monkey, TDC, Linden,
_khAttAm_, l0calh0st, Ox87k, Ank83, TWiST, dila,
moofy, ScR1pT_, KLiZMA, Kerberos, R.E.M, 
CracksLatinos, and all members in crackmes.de