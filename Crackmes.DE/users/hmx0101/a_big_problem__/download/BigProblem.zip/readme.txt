A big problem... by HMX0101

An user of a program bought a registration key for it,
for as many known, remove trial limitations.. and one of his
friends (a cracker) found his registration key and leaked it
to the public... but this cracker its stupid (or just a lamer),
how it will leak a key which just works in the machine of
the user who bought the app? well.. an 0wn3d for it, will be good ;)

Now, you as the real cracker might want to keygen this bitch :)
Maybe you can use the leaked key to understand it better the algo
and deal with the mysteries which are covered by this app :D

Tasks:
	- Make a keygen.. it should be easy, with the leaked key
	- Write a tut!

Don't do:
	- Patching!
	- Bruteforcing!

Enjoy it!
Greetz to everyone who knows me, and want to ;)

01/08/2008