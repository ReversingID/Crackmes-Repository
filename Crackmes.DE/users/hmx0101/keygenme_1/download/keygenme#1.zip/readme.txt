=====================
HMX0101's Keygenme #1
=====================

This is my new crackme, with an "easy"
serial calculation using my algorithm 
"XConst" (this algo make up to 0x42FE chars),
with some junk code and packed with
UPX and scrambled with UPolyX v0.5

To beat this crackme, you need:
	
	- Unpack it!
	- Find the way to enable the "Check" button
	- Find the way to enable the 2nd textbox
	- Analyze the algorithm
	- Make a keygen
	- Write a tutorial

Rules:

	- Patching is not allowed!

==========
Greets to:
==========

Ank83, KLiZMA, Kerberos, R.E.M, CracksLatinos,
and all members in crackmes.de

===============
Regards,
HMX0101 / R.E.M
===============