Beam by HMX0101

Just get a valid key pair, for your hardware id...
and make a nice keygen and tutorial...

The rules as always:

 - Don't patch
 - Make a keygen (!)
 - Write a tut

Greetz: lord_phoenix, Ox87k, Ank83, l0calh0st, n00b, cyclops, starzboy, 
crosys, Guetta, anorganix and crackmes.de, ARTeam, CracksLatinos members