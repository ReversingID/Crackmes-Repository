Crappy Fun - by HMX0101

The name says it all :)... just a piece of crap to entertain you!
this crackme isn't intended for totally newbies, you must have
at least some knowledge ;)

There exists two tasks to do:

	- Make a valid unpacked (it will not run until you find
	  why it don't! :))
	- Find the correct serial (easy, huh?)

The rules as always:

 - Don't patch
 - Write a tut

Greetz: lord_phoenix, Ox87k, Ank83, l0calh0st, n00b, cyclops, starzboy, 
crosys, Guetta, anorganix and crackmes.de, ARTeam, CracksLatinos members