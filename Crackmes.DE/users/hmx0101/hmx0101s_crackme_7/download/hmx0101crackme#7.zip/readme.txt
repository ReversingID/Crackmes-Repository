Unpack this manually, 
and make a keygen.

Regards,
HMX0101