=====================
HMX0101's Keygenme #2
=====================

This is my new crackme, it is packed
with FSG 2.0, this time two serials
to be fished for each name.

To beat this crackme, you need:
	
	- Unpack it!
	- Analyze the algorithm
	- Find the 2 codes for each name
	- Make a keygen
	- Write a tutorial

Rules:

	- Patching is not allowed!

==========
Greets to:
==========

Ank83, KLiZMA, Kerberos, R.E.M, CracksLatinos,
and all members in crackmes.de

===============
Regards,
HMX0101 / R.E.M
===============