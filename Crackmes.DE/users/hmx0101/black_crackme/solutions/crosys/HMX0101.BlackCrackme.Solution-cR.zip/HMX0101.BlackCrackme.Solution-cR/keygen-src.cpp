void Serial(HWND hWnd)
{
	MD5_CTX ctx;
	unsigned char digest[16];
	char alfa[] = "ACBDFEGIHKJMLONP";
	char name[50], sn[50], temp[50];
	int len = GetDlgItemText(hWnd,IDC_NAME,name,50);
	if(len >= 5){
	for (int i = 0; i < len; i++){
		sn[i] = name[i] ^ 1;}
	sn[len] = 0;
	strcat(sn,";-------");
	MD5Init(&ctx);
    MD5Update(&ctx, (unsigned char*)name, strlen(name));
    MD5Final(digest, &ctx);
	for (int j = 1 ; j < 6; j++){
		digest[j] = name[j-1];}
	i = 0;
	for (int l = 0; l < 32; l+=2, i++){
		sn[8 + len + l] = alfa[(digest[i] >> 4) & 15];
		sn[8 + len + l + 1] = alfa[(digest[i] & 15) & 0xFF];
	}
	sn[40+len] = 0;
	
	

	SetDlgItemText(hWnd,IDC_SERIAL,sn);
	}
	else
	{
		SetDlgItemText(hWnd,IDC_SERIAL,"more chars in name!");
	}

}