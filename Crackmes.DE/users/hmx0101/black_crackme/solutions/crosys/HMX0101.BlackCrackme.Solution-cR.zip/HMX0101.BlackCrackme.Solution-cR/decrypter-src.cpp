#include <iostream.h>
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
char target[] = "crypted.exe";
int main()
{
	int lSize = 0, start_p = 0x400;
	size_t result;
	char *rBuffer, *qBuffer;
	FILE * pFile;
	pFile = fopen(target , "rb");
    fseek(pFile , 0 , SEEK_END);
    lSize = ftell(pFile);
	rewind (pFile);
	rBuffer = (char*) malloc (sizeof(char)*lSize);
    result = fread(rBuffer,1,lSize,pFile);
	for (int i = start_p, j = 0; i < 0x4CD9; i++, j++)
	{
		rBuffer[i] = (rBuffer[i] ^ 0x5D); // 0x30 ^ 0x31 ^ 0x30 ^ 0x31 ^ 0x4D ^ 0x58 = 0x5D
	}
	fclose(pFile);
	DeleteFile(target);
    pFile = fopen ( target , "wb" );
    fwrite (rBuffer , lSize , 1 , pFile );
	fclose ( pFile );

return 0;
}
