Alive

Just another crypto keygenme and delphi shit.
Only valid solution is a keygen.

Luck,
HMX0101 // 10-04-2011