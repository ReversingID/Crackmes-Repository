Unpack and make a keygen,
if you can!

Regards,
HMX0101 / R.E.M