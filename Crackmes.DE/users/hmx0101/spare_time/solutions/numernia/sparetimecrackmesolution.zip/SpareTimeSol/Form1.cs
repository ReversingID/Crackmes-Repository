﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            this.constb = new uint[6];
            this.inblock = new uint[4];

            this.constb[0] = 0x408112f1;
            this.constb[1] = 0x1a3b0b51;
            this.constb[2] = 0x2957c9fd;
            this.constb[3] = 0x1b327d1d;
            this.constb[4] = 0xa38d0af1;
            this.constb[5] = 0x2ad5e941;
           
            InitializeComponent();
        }
        public class ytrewq
        {
            private uint[] tqepq;
            public ytrewq()
            {
                uint num = 0xbaadf00d;
                this.tqepq = new uint[0x100];
                uint num2 = 0;
                for (uint i = 0; i < this.tqepq.Length; i++)
                {
                    num2 = i;
                    for (int j = 8; j > 0; j--)
                    {
                        if ((num2 & 1) == 1)
                        {
                            num2 = (num2 >> 1) ^ num;
                        }
                        else
                        {
                            num2 = num2 >> ((byte)(num / num));
                        }
                    }
                    this.tqepq[i] = num2;
                }
            }

            public uint nhash(byte[] bytes)
            {
                uint num = 0;
                num = ~num;
                for (int i = 0; i < bytes.Length; i++)
                {
                    byte index = (byte)((num & 0xff) ^ bytes[i]);
                    num = (num >> 8) ^ this.tqepq[index];
                }
                return ~num;
            }
        }
        private uint[] inblock;
        private uint[] constb;
 
        public static byte[] hash1(string str)
        {
            ASCIIEncoding encoding = new ASCIIEncoding();
            return encoding.GetBytes(str);
        }
        /*
        private void Decrypt(uint[] blocks, uint[] sbox, uint key)
        {
            uint rounds = 32;
            uint b1 = blocks[0];
            uint b2 = blocks[1];
            uint KeyShift = key << 5;
            while (rounds-- > 0)
            {
                b2 -= (((b1 << 4 ^ b1 >> 5) + b1) ^ (KeyShift + sbox[(KeyShift >> 11) % 4])) - rounds;
                KeyShift -= key;
                b2 -= rounds;
                b1 -= ((b2 << 4 ^ b2 >> 5) + b2) ^ (KeyShift + sbox[(KeyShift & 3)]);
            }
            blocks[0] = b2;
            blocks[1] = b1;
        }
         * */
        private void Encrypt(uint[] blocks, uint[] sbox, uint key)
        {
            uint rounds = 0;

            uint b2 = blocks[0];
            uint b1 = blocks[1];
            uint KeyShift = 0;
            
            while (rounds++ < 32)
            {
                b1 += ((b2 << 4 ^ b2 >> 5) + b2) ^ (KeyShift + sbox[(KeyShift & 3)]);
                b2 += rounds;
                KeyShift += key;
                b2 += (((b1 << 4 ^ b1 >> 5) + b1) ^ (KeyShift + sbox[(KeyShift >> 11) % 4])) - rounds;
            }
            blocks[0] = b1;
            blocks[1] = b2;
        }
        private int RandomNumber(int min, int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }

        private void button1_click(object sender, EventArgs e)
        {
            string serial;
            ytrewq ytrewq = new ytrewq();
            if (this.textBox1.Text.Length >= 5)
            {

                uint tmp = ytrewq.nhash(hash1(this.textBox1.Text));
                uint hashCode = (uint)this.textBox1.Text.GetHashCode();
                uint k = (uint)RandomNumber(1, 0x47DC0FE); // 2^32-1 / 0x39 - 0x21
                uint key = (k * 0x39) + 0x21;
                uint p3 = hashCode ^ 0x8ffe2225 ^ key;

                this.inblock[0] = hashCode;
                this.inblock[1] = tmp;

                this.Encrypt(this.inblock, this.constb, key);
               

                serial = this.inblock[0].ToString("X8");
                serial += "-";
                serial += this.inblock[1].ToString("X8");
                serial += "-";
                serial += p3.ToString("X8");
                textBox2.Text = serial;

            }
            else
            {
                textBox2.Text = "strlen(name) >= 5";
            }

        }



       
       

    }
}
