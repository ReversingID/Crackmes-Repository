=====================
HMX0101's Secretme #1
=====================

This is my new crackme with a
short algorithm and many tricks
to make your life burning in hell :D

To beat this crackme, you need:
	
	- Unpack it!
	- Find the tricks
	- Make a keygen
	- Write a tutorial

Rules:

	- Patching is not allowed!

==========
Greets to:
==========

moofy, ScR1pT_, Ank83, KLiZMA, Kerberos, R.E.M, 
CracksLatinos, and all members in crackmes.de

===============
Regards,
HMX0101 / R.E.M
===============