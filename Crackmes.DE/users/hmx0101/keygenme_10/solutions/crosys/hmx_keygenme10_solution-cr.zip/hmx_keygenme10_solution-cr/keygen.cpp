const char Base64Table[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
void Base64Encode(char *szBuffer, int nLen, char *szResult)
{
	int n;
	n = nLen / 3;
	if(nLen % 3 != 0)
		n++;
	if(n == 0)
		return;

	BYTE v1, v2, v3, v4;
	DWORD tmp, reslen = 0;
	for(int i = 0; n != 0; n--, i++)
	{
		tmp = i * 3;
		if(tmp + 3 <= nLen)
		{
			v1 = Base64Table[szBuffer[tmp] >> 2];
			v2 = Base64Table[((szBuffer[tmp] << 4 & 0x30) 
				| (szBuffer[tmp + 1] >> 4)) & 0xFF];
			v3 = Base64Table[((szBuffer[tmp + 1] << 2 & 0x3C) 
				| (szBuffer[tmp + 2] >> 6)) & 0xFF];
			v4 = Base64Table[szBuffer[tmp + 2] & 0x3F];
			
		}
		else if(tmp + 2 <= nLen)
		{
			v1 = Base64Table[szBuffer[tmp] >> 2];
			v2 = Base64Table[((szBuffer[tmp] << 4 & 0x30) 
				| (szBuffer[tmp + 1] >> 4)) & 0xFF];
			v3 = Base64Table[((szBuffer[tmp + 1] << 2 & 0x3C) 
				| (szBuffer[tmp + 2] >> 6)) & 0xFF];
			v4 = '=';
		}
		else
		{
			v1 = Base64Table[szBuffer[tmp] >> 2];
			v2 = Base64Table[((szBuffer[tmp] << 4 & 0x30) 
				| (szBuffer[tmp + 1] >> 4)) & 0xFF];
			v3 = '=';
			v4 = '=';
		}
		szResult[reslen] = v1;
		szResult[reslen+1] = v2;
		szResult[reslen+2] = v3;
		szResult[reslen+3] = v4;
		reslen += 4;
	};
	szResult[reslen] = 0;
}

void XTEA_Encrypt(unsigned int num_rounds, unsigned long* v, unsigned long* k) {
    unsigned long v0=v[0], v1=v[1], i;
    unsigned long sum=0, delta=0x9E3779B9;
    for(i=0; i<num_rounds; i++) {
        v0 += ((v1 << 4 ^ v1 >> 5) + v1) ^ (sum + k[sum & 3]);
        sum += delta;
        v1 += ((v0 << 4 ^ v0 >> 5) + v0) ^ (sum + k[sum>>11 & 3]);
    }
    v[0]=v0; v[1]=v1;
}
DWORD crc32(char *buff, int len)
{
	DWORD crc = 0xFFFFFFFF;
	DWORD tmp;
	for(int i = 0; i < len; i++)
	{
		tmp = buff[i];
		tmp ^= (crc & 0xFF);
		for(int j = 0; j < 8; j++)
		{
			if(tmp & 1)
			{
				tmp >>= 1;
				tmp ^= 0xEDB88320;
			}
			else
				tmp >>= 1;
		}
		crc >>= 8;
		crc ^= tmp;
	}
	return ~crc;
}

void MakePermutation(unsigned char temp[20], int x, int ValueSub)
{
	do{
		int ValToAdd=0;
	for (int i=0;i<x;i++){
		temp[i] = rand() % 10;}
	i=0;

	for (i=0;i<x-1;i++){
		ValToAdd+=temp[i];}
	temp[x-1]=ValueSub-ValToAdd;
	}
	while(! (temp[x-1] >= 0 && temp[x-1] <= 9));
	for(int z=0;z<x;z++)
	{
			temp[z]+='0';
	}
	temp[x]='\0';
	

}
unsigned long bswap(unsigned long in)
{
	return (((in & 0x000000FF) << 24)
	+ ((in & 0x0000FF00) << 8)
	+ ((in & 0x00FF0000) >> 8)
	+ ((in & 0xFF000000) >> 24));
}


void Generate(HWND hWnd)
{
	char name[50], serial[1000], sn[500], q[60], p[5][10], serialm[50], temp[4][100];
	unsigned long w[5] = {0};
	//DES Vars
	unsigned char keyb[300], data[300], re[300];
    unsigned long DES_Key[4] = {0x58AA7831, 0x4E474B5B, 0x00000000, 0x00000000};
	ZeroMemory(serial,1000);
	ZeroMemory(re,300);
	ZeroMemory(keyb,300);
	ZeroMemory(data,300);
	
	//TEA Vars
	long TEA_Key[] = {0x19912006,0x20061991, 0, 0x29A};
	long TEA_Data[] = {0x00000000, 0x00000000, 0x00000000, 0x00000000};


	for (int kk = 0; kk < 56; kk++)
	{
		q[kk] = rand() % 10 + '0';
	}
	q[56] = 0;

	//Permutation variables
	int a[3], b[8], e, f;
	
	//find: 2 == a[0] mod a[1]
	do{
	a[0] = rand() % 33 + 3; // 3 - never divide by zero = crash
	a[1] = a[0] - 2;
	}
	while(a[0] % a[1] != 2); // Should not be needed, but always good to be sure
	
	//Create permutations out of a[0] & a[1]
	MakePermutation((unsigned char*)p[0],4,a[0]);
	MakePermutation((unsigned char*)p[1],4,a[1]);
	
	//Shuffle correct orders
	q[0] = p[0][0]; q[2] = p[0][1];
	q[4] = p[0][2]; q[6] = p[0][3];

	q[8] = p[1][0]; q[10] = p[1][1];
	q[12] = p[1][2]; q[14]  = p[1][3];

	//find: 7 == a[0] ^ a[1]
	do{
	a[0] = rand() % 35;
	a[1] = a[0] ^ 7;
	}while(a[1] > 35);
	
	//Again permutations
	MakePermutation((unsigned char*)p[0],4,a[0]);
	MakePermutation((unsigned char*)p[1],4,a[1]);

	q[1] = p[0][0]; q[3] = p[0][1];
	q[5] = p[0][2]; q[7] = p[0][3];

	q[9] = p[1][0]; q[11] = p[1][1];
	q[13] = p[1][2]; q[15]  = p[1][3];


    /*find (a * b + c * d) / (g * h + i * j) == 3
	Using quite lame technique, example r data
	1 2 3 4

    1*2 + 3*4 = 14*3/2 = 21
	factor 21 gets 3 and 7
	(1*2 + 3*4) * 3 == (3*7 + 7*3)
	*/
	novalidstart:
	for (int im = 0; im < 4; im++){ //fill random data first
		b[im] = rand() % 10;}
	e = ((b[0] * b[1]) + (b[2] * b[3])) * 3;
	f = e / 2;
	if((e % 2) != 0){goto novalidstart;}

	//Quick factor
	int px = 2;
	do{
		e = f % ++px;
		if(px > 9){
			goto novalidstart;}
	}while(e != 0);
	if((f / px) > 9){goto novalidstart;}
	

	//Shuffle in correct orders
	b[6] = b[4] = px;
	b[7] = b[5] = f / px;
	if(((b[0] * b[1]) + (b[2] * b[3])) * 3 != ((b[4] * b[5]) + (b[6] * b[7]))){
		goto novalidstart;}

	q[16] = b[4] + 0x30; q[18] = b[5] + 0x30;
	q[20] = b[6] + 0x30; q[22] = b[7] + 0x30;

	q[24] = b[0] + 0x30; q[26] = b[1] + 0x30;
	q[28] = b[2] + 0x30; q[30] = b[3] + 0x30;

	novalidstart_:
	/*find: (a + b ^ c + d) * (g + h ^ i + j) == 6
	Example a,b{1,2} and g,h{3,4}
	(1 + 2) ^ 2 = 1
	permutation(2) = 1 + 0 
	(3 + 4) ^ 3 = 4
	permutation(4) = 2 + 2, 3 + 1, 4 + 0, etc etc

    ((1 + 2) ^ (1 + 0)) * ((3 + 4) + (3 + 1)) == 6
	*/
	
	for (int imn = 0; imn < 4; imn++){ //fill random data first
		b[imn] = rand() % 10;}

	e = (b[0] + b[1]) ^ 2;
	f = (b[2] + b[3]) ^ 3;
	if(e > 18 || f > 18){
		goto novalidstart_;}
	MakePermutation((unsigned char*)p[0],2,e);
	MakePermutation((unsigned char*)p[1],2,f);




	q[17] = b[2] + 0x30; q[19] = b[3] + 0x30;
	q[21] = p[1][0]; q[23] = p[1][1];

	q[25] = b[0] + 0x30; q[27] = b[1] + 0x30;
	q[29] = p[0][0]; q[31] = p[0][1];

    //Permutations done
	int len = GetDlgItemText(hWnd,IDC_NAME,name,50);
	if(len != 0){
	for (int o = 0; o < len; o++){
		w[0] += name[o];}
	w[0] = bswap((w[0] << 8) | (w[0] * 0x186A0));
	w[1] = crc32(name,len);
	w[0] ^= w[1];
	
	for (int j1 = 0, l = 0; j1 < 16; j1+=8, l++){
		strcpy(temp[l], q + j1);
		temp[l][8] = 0;
		sscanf(temp[l], "%X", &w[l+2]);
	}
	w[4] = w[0];
	w[0] = (w[2] + w[3]) ^ w[0];
	wsprintf(temp[0],"%08X",w[0]);
	for (int jj = 0; jj < 8; jj++)
	{
		q[jj+0x20] = temp[0][jj];
	}
	for (int j2 = 0, l2 = 0; j2 < 16; j2+=8, l2++)
	{
		strcpy(temp[l2], q + j2 + 16);
		temp[l2][8] = 0;
		sscanf(temp[l2], "%X", &w[l2+1]);
	}
	w[1] *= w[2];
	w[0] = w[4];
	w[0] *= 0x3E8;
	w[1] += w[0];
	wsprintf(temp[0],"%08X",w[1]);

	for (int jjj = 0; jjj < 8; jjj++)
	{
		q[jjj+0x28] = temp[0][jjj];
	}

	w[0] = crc32(name,len);
	wsprintf(temp[0],"%08X",w[0]);
	*(DWORD*)TEA_Data = *(DWORD*)temp[0];
	*(DWORD*)(TEA_Data + 1) = *(DWORD*)(temp[0] + 4);

	
	XTEA_Encrypt(32, (unsigned long*)TEA_Data, (unsigned long*)TEA_Key);
	wsprintf(serialm,"%08X%08X",TEA_Data[0],TEA_Data[1]);


	des_ky(DES_Key,keyb);
	memcpy(data,q,56);
	ZeroMemory(re,200);
	for (int j = 0; j < 56; j+=8)
	{
	des_ec(data + j,re + j,keyb);
	}

	for (int i = 0; i < 56; i++)
	{
		wsprintf(sn +i*2,"%02X",re[i]);
	}
	sn[i*2] = '\0';

	Base64Encode((char*)sn,strlen(sn),serial);
	strcat(serial,serialm);

	SetDlgItemText(hWnd,IDC_SERIAL,serial);
	}
	else
	{
		SetDlgItemText(hWnd,IDC_SERIAL,"A Name Please!");
	}
}
