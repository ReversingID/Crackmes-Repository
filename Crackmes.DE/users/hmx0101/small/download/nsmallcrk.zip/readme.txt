Small crackme by HMX0101

Find the correct password in order to
decrypt good boy message... don't patch it, its easy ;)

Greetz: lord_phoenix, Ox87k, Ank83, l0calh0st, n00b, cyclops, starzboy, 
crosys, Guetta, anorganix and crackmes.de, ARTeam, CracksLatinos members