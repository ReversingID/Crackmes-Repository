HMX0101's Keyfileme #1
======================

This is my first keyfileme, 
its so easy to reverse the serial
calculation in the keyfile.

The goals:
----------

* Make a keyfilemaker
* Write a tutorial

The rules:
----------

* Patching is not allowed !!!

=============
HMX0101/R.E.M