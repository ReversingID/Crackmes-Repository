#include <windows.h>
#include <winnt.h>

//DECLARES
HWND txtname;
HWND txtserial;

void keygen_start();
void keygen();
void keygen_end();
void syserror(char*);

//keygen info

char* szAboutText="HMX0101 #4 - Keygen by Ultrasound\n\nGreetz to NoRG, D4ph1, Zero, Kreatief, Merker and all crackmes.de!";
char* szAppTitle="Keygen by Ultrasound";

//end info

//oraculum info
char* exefile="keygenme#4.exe";
char* cmClassName="CRACKME";
char* cmAppTitle="HMX0101's Keygenme #4";
char* fakeSerial="555555555555";

long addr_to_patch=0x0015630;

int minName=5;
int maxName=30;

	//new process info
	PROCESS_INFORMATION pi={0};
	HANDLE hTarget;

	//debugger info
	HANDLE hdbgThread;
	DWORD WINAPI dbgThread(LPVOID);

BYTE oldByte, newByte=0xCC;

//end info

void keygen(){
	char username[30]={0};

	if(GetWindowText(txtname, username, maxName)<minName){
		MessageBox(NULL, "Username has too few characters", "Error.", MB_ICONERROR | MB_OK);
		return;
	}

	SetWindowText(txtname, username);
	
	STARTUPINFO sp={0};
	sp.cb=sizeof(STARTUPINFO);

	//create suspended process
	if(!CreateProcess(exefile, NULL, NULL, NULL, FALSE, 0, NULL, NULL, &sp, &pi)){
		//handle error
		char message[255]={0};
		strcpy(message, "Could not find ");
		strcat(message, exefile);
		syserror(message);
		return;
	}

	//wait until target is loaded
	WaitForInputIdle(pi.hProcess, (unsigned long)-1);
	SuspendThread(pi.hThread);

	//open for read/write
	HANDLE hProc=OpenProcess(PROCESS_ALL_ACCESS, FALSE, pi.dwProcessId);
	
	DWORD written;

	//read the old byte
	if(!ReadProcessMemory(hProc, (void*)addr_to_patch, &oldByte, 1, &written)){
		syserror("");
		return;
	}

	//write the new byte
	if(!WriteProcessMemory(hProc, (void*)addr_to_patch, &newByte, 1, &written)){
		syserror("");
		return;
	}

	//start the debugger thread
	DWORD threadId;
	hdbgThread=CreateThread(NULL, 0, &dbgThread, 0,0, &threadId);


	//do the SendKeys stuff
	HWND crkWindow;

	crkWindow=FindWindowEx(NULL, NULL, cmClassName, cmAppTitle);

	HWND editbox;

	//PROCESS TEXT BOXES AND BUTTON PRESSES
	editbox=FindWindowEx(crkWindow, NULL, "Edit", NULL);
	SendMessage(editbox, WM_SETTEXT, 0, (LPARAM)username);

	editbox=FindWindowEx(crkWindow, editbox, "Edit", NULL);
	SendMessage(editbox, WM_SETTEXT, 0, (LPARAM)fakeSerial);

	editbox=FindWindowEx(crkWindow, NULL, "Button", "Check");
	SendMessage(editbox, BM_CLICK, 0, 0);

	return;
}

DWORD WINAPI dbgThread(LPVOID){
	DEBUG_EVENT dbgr;

	hTarget=OpenProcess(PROCESS_ALL_ACCESS, FALSE, pi.dwProcessId);

	if(!DebugActiveProcess(pi.dwProcessId)){
		ExitProcess(0);
	}

	ResumeThread(pi.hThread);

	while(WaitForDebugEvent(&dbgr, INFINITE)){
		if(dbgr.dwDebugEventCode==EXIT_PROCESS_DEBUG_EVENT){
			ExitThread(0);
		}
		else if(dbgr.dwDebugEventCode==EXCEPTION_DEBUG_EVENT && dbgr.u.Exception.ExceptionRecord.ExceptionCode==EXCEPTION_BREAKPOINT && dbgr.u.Exception.ExceptionRecord.ExceptionAddress==(void*)addr_to_patch){
				SuspendThread(pi.hThread);

				DWORD written;
				WriteProcessMemory(hTarget, (void*)addr_to_patch, &oldByte, 1, &written);

				CONTEXT far_cont={0};
				
				far_cont.ContextFlags=CONTEXT_FULL;

				
				GetThreadContext(pi.hThread, &far_cont);

				DWORD myReg;

				//WHAT TO READ
				myReg=far_cont.Eax;


				//read serial from memory
				char serial[255]={0};
				ReadProcessMemory(hTarget, (void*)myReg, serial, 255, &written);
				
				//set app serial
				SetWindowText(txtserial, serial);

				ResumeThread(pi.hThread);
				ContinueDebugEvent(dbgr.dwProcessId,dbgr.dwThreadId,DBG_CONTINUE);

				TerminateProcess(hTarget, 0);
		}
		else{
			ContinueDebugEvent(dbgr.dwProcessId,dbgr.dwThreadId,DBG_CONTINUE);
		}
	}
	

	return 0;
}

void keygen_start(){

	return;
}

void keygen_end(){
	ResumeThread(pi.hThread);
	TerminateProcess(pi.hProcess, 0);
	TerminateThread(hdbgThread, 0);
	return;
}

void syserror(char* additional_info){
	//handle errors
	char err_desc[306]={0};
	DWORD err_code=GetLastError();

	FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, err_code, 0, err_desc, 255, NULL);

	if(lstrlen(additional_info)>0){
		strcat(err_desc, "\n");
		strncat(err_desc, additional_info, 50);
	}

	MessageBox(NULL, err_desc, "Error", MB_ICONERROR | MB_OK);

	return;
}
