HMX0101's Crackme #6
====================

This is my new challenge,
get the correct colors and
have the goodboy message.


Goals:
------
 * Get the correct colors
 * Write a tutorial


Rules:
------
 * Patching is not allowed!

=============
HMX0101/R.E.M