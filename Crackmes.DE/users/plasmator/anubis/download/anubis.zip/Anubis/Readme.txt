
***************************************************


CrackMe		:	Anubis by d@b 2004

Date		:	12-Jul-2004

Type		:	KeyGenMe
	
Level		:	4/10

Language	:	Assembly

Compiler	:	MAsm32

Encryption	:	MayBe

Packing		:	MayBe

Anti-Debugger	:	MayBe

Platform	:	Windows XP , 2000 , NT 4.0


***************************************************


Introduction
============


	.... book of the dead .... beware ....



The Challenge
=============


Find a Valid Serial and create a Key Generator.. ;)

The protection scheme will be defeated, once you are 
presented with the correct congratulations message box.


Rules
=====


0. NO Patching Allowed.

1. Find a Valid Serial.

2. Create a Key Generator.

3. You CANNOT use the MessageBox function to display the serial.

4. Ensure your Key Generator works for ALL situations before submitting your solution.

5. Write a Tutorial.



Good Luck! 


.... Free Your Mind ....


Regards,

d@b

E-Mail : dab@rogers.com