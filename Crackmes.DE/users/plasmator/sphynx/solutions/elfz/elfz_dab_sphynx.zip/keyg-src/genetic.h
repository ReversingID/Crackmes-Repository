// (c) 2004, elfz, elfz@laacz.lv
// generic simple genetic solver 
// based on the Merkuur's source of solution for Crueheads CrueMe crackme


#pragma once

#include <iostream>
using std::cout;
using std::endl;

class Alphabet;

template <class T, int POOL_SIZE = 20, int SURVIVORS = 5, int MUTATORS = 10>
class GenePool {
public:
   
   void solve() {
      do {
        qsort(pool, POOL_SIZE, sizeof(T), comparator); 

        unsigned safe_count, i;

        // wholly mutate some genomes with other genomes
        for(i=SURVIVORS; i < POOL_SIZE - MUTATORS; i++) {
          safe_count=0;
          do {
            for( unsigned j=0; j < pool[i].length; j++)
              pool[i].copyMutation(pool[rand()%SURVIVORS], j);

              
            if (5 == ++safe_count) {
              pool[i] = T();
              break;
            };

          } while (duplicate(i));
        }

        // last MUTATORS ones are mutations of the best ones - a single byte is randomly changed 
        for( i = POOL_SIZE - MUTATORS; i<POOL_SIZE; i++) {
          safe_count=0;
          
          pool[i] = pool[POOL_SIZE - i - 1];

          do {
            pool[i].randomMutation();
            if (5 == ++safe_count) {
              pool[i] = T();
              break;
            }
          } while (duplicate(i));

        }


      } while (pool[0].score);
      
      pool[0].dump();

   }


   bool duplicate(unsigned idx) {
     for (int i=0; i<POOL_SIZE; i++) {
       if (i != idx && pool[i] == pool[idx]) {
         return true;
       }
     }
     return false;
   }


protected:
   
   static int __cdecl comparator(const void* g1, const void* g2) {
     return((*(T*)g1).score - (*(T*)g2).score);
   }

   T pool[POOL_SIZE];

};









// singleton alphabet class
static Alphabet* alpha = 0;
class Alphabet {
public:
  Alphabet(char* alphabet_ = "ABCDEFGHIJKLMNOPQRSTUVWXYZ") : alphabet(alphabet_) {
    len = 0; while (alphabet[++len]);
  };

  static void set(char* newAlpha) {
    if (0 != alpha)
      delete alpha;
    alpha = new Alphabet(newAlpha);
  }

  char get() {
    return alphabet[rand() % len];
  }

  static Alphabet* getInstance() {
    if (0 == alpha) 
      alpha = new Alphabet();

    return alpha;
  }

private:
  char* alphabet;
  unsigned len;
};





class Genome {
public:
  Genome(unsigned length_ = 16) : length(length_) {
    for (unsigned i = 0 ; i < length; i++) {
      data[i] = Alphabet::getInstance()->get();
    }
    data[length] = 0;
//    calcScore();
  }

  const char * const getData() {
    return (const char* const)data;
  }
  
  void copyMutation(const Genome& other, int pos = -1) {
    unsigned mutation = (pos == -1 ? rand() % length : pos);
    data[mutation] = other.data[mutation];
    calcScore();
  }
  
  void randomMutation() {
    data[rand() % length] = Alphabet::getInstance()->get();
    calcScore();
  }

  bool operator== (const Genome& other) {
    if (other.length != length) return false;
    for (unsigned i = 0 ; i < other.length; i++) {
      if (data[i] != other.data[i]) return false;
    }
    return true;
  }

  void dump() {
    cout << data << endl;
  }

  virtual unsigned getMatch() = 0;
  unsigned score;
  unsigned length;
  
protected:
  
  unsigned char data[256];
  
  unsigned calcScore() {
    unsigned hash = getMatch();
    score = 0;
    while (hash) {
      score += (hash & 1);
      hash >>= 1;
    }
    return score;
  }

};

