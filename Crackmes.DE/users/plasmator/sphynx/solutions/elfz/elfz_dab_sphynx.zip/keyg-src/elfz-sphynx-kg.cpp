#include "genetic.h"

#include <time.h>
#include <stdlib.h>
#include <iostream>
#include <conio.h>
using std::cout;
using std::endl;



class SphynxGenome: public Genome {
public:
  
  // tell that we're using 11 chars long password
  // you can make the passwords with len >= 24 as well
  SphynxGenome() : Genome(11) {
    
    calcScore(); // hack: Genome constructor doesn't know about our function, but calcScore MUST be called in constructor
  }


  // calculate the hash and get its difference from required one 
  // should be 0 if this is THE match
  unsigned getMatch() {
    unsigned dataptr = (unsigned)data;
    unsigned csum;
    __asm {
      xor     eax, eax
      xor     edx, edx
      mov     esi, dataptr
  lp:
      lodsb
      or      al, al
      je      term
      add     edx, 12345678h
      rcl     edx, 1
      adc     edx, eax
      add     edx, 87654321h
      jmp lp
  term:
      xor     edx, 0xC3B42A38
      mov     csum, edx
    }
    return csum;
  }

};

void main() {

  srand(time(0));

  cout << "Genetic solver for d@b's sphynx, (c) 2004, elfz" << endl <<
  "press any key to start spitting out the valid serials, Ctrl+C to break" << endl;
  getch();
  
  Alphabet::set(" !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
  
  do {
    for (unsigned i = 0 ; i < 24; i++) {
      GenePool<SphynxGenome,9,3,5> pool;  // genome_class, pool_size, survivors, mutators
      pool.solve();
    }
    cout << "more?\r";
  } while (getch() != 3);
}

