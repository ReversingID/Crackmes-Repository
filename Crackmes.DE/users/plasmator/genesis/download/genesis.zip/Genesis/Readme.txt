
***************************************************


CrackMe		:	Genesis by d@b 2004

Date		:	02-Jun-2004

Type		:	Password Key / KeyGenMe
	
Level		:	1/10

Language	:	Assembly

Compiler	:	MAsm32

Encryption	:	Some

Packing		:	None

Anti-Debugger	:	None

Platform	:	Windows XP , 2000 , NT 4.0


***************************************************


Introduction
============


	.... in the beginning god created man .... god told man to be fruitful and multiply ....



The Challenge
=============


Find the Password Key and create a Password Generator.. ;)

The protection scheme will be defeated, once you are presented with the correct congratulations message box.


Rules
=====


0. NO Patching Allowed.

1. A True Cracker will find the Password Key using the information I've provided here without writing one line of code.

2. Newbies will probably use a brute force approach.

3. Once the Password Key is found you must write a Password Generator and Tutorial.

4. There is one Password Key but many other Passwords that will work.


Good Luck! 


.... Free Your Mind ....


Regards,

d@b

E-Mail : dab@rogers.com