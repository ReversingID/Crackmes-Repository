#include <iostream.h>
#include <fstream.h>
#include <stdlib.h>
#include <stdio.h>
#include <io.h>
#include <string.h>

//It's late, but I THINK I am loading WAY too many libraries here.


//What is the file called?
const char * filename = "AC_ExDec_03_B.exe";
//Who wrote the program?
const char * fileauthor = "Acid Cool 178";
//Short note about the program. Could be anything.
const char * filedescription = "Enables the button.";
//The EXACT size of the file. (MUST match).
int filesize = 16384;


//Okay, so is this handy? I don't know, maybe. I'll just test this for now.
//Offset of byte to change.
long offsetbytes[] = {0x1FE1};
//What WAS the byte?
int originalbytes[] = {0x00};
//What is the NEW byte?
int bytestochange[] = {0x01};


//Count all the elements of offsetbytes and you can fill in this number.
int numchanges = 1;

void main() {

system("cls");

cout << "��������������ͻ\n";
cout << "� File patcher �\n";
cout << "��������������ͼ\n";
cout << "\nWritten by Cipher (myforwarder@hotmail.com)\n\n";
cout << "Target     : " << filename << "\n";
cout << "Size       : " << filesize << "\n";
cout << "Author     : " << fileauthor << "\n";
cout << "Description: " << filedescription << "\n";
cout << "\n";
cout << "Checking file size.... ";


long l,m;
ifstream file (filename, ios::out|ios::in|ios::binary|ios::nocreate);
l = file.tellg();
file.seekg (0, ios::end);
m = file.tellg();
file.close();

if ((m-l) == filesize) {
	cout << "OK!\n";
} else {
	cout << "ERROR: Bad file size (" << (m-l) << ")\n";
	exit(1);
}

//cout << hex;

fstream Fpatch (filename, ios::out | ios::in | ios::binary);

bool AllTheSame;
int mw;
char HexByte;
AllTheSame=true;
for (mw=0;mw<numchanges;mw++) {
	Fpatch.seekg(offsetbytes[mw],ios::beg);
	Fpatch.get(HexByte);
	
	cout << HexByte << " | " << originalbytes[mw] << " | ";
	if (HexByte == originalbytes[mw]) {
		cout << " seems to be the same byte!\n";
	} else {
		cout << " does not seem to be the same byte!\n";
		AllTheSame=false;
	}
}

//Are all the bytes the same?

if (AllTheSame==true) {
	for (mw=0;mw<numchanges;mw++) {
		Fpatch.seekg(offsetbytes[mw],ios::beg);
		Fpatch.put(bytestochange[mw]);
	}
} else {
	cout << "\nERROR: Not all the bytes matched. No patch applied.\n";
	exit(1);
}

// Here, the patch has just been applied successfully.
Fpatch.close();
cout << "File was patched successfully!\n";


}