#include <stdio.h>
#include <iostream.h>
#include <windows.h>
#include <winuser.h>

// Yes, source was taken from BB.. Thanks a lot for your essay! It rules!
// Slightly modified to fit C++. (Sloppy code now, uses both C and C++ syntax)

char * proggie="AC_Crackme_01_A.exe";
HWND mewhwnd,clickithwnd;

BOOL CALLBACK enumMain(HWND myhwnd, LPARAM lparam)
{
cout << "MAIN HWND: " << myhwnd << "\n";
mewhwnd=myhwnd;
return(FALSE);
}

BOOL CALLBACK enumChild(HWND myhwnd, LPARAM lparam)
{
char myclass[200];
char mytext[200];

GetClassName(myhwnd,myclass,sizeof(myclass));
GetWindowText(myhwnd,mytext,sizeof(mytext));
if (!strcmp(myclass,"ThunderRT6CommandButton") && !strcmp(mytext,"Command1")) {
  printf("Found the button..\n");
  clickithwnd=myhwnd;
  return(FALSE);
  }
return(TRUE);

}


main()
{
STARTUPINFO startinfo;
PROCESS_INFORMATION procinfo;

GetStartupInfo(&startinfo);
int Result = CreateProcess(NULL,proggie,NULL,NULL,FALSE,NORMAL_PRIORITY_CLASS,NULL,NULL,&startinfo,&procinfo);
if (Result == 0) {
  cout << "Could not create process!\n";
  exit(-1);
  } else {
  cout << "Successfully created process.\n";
}

WaitForInputIdle(procinfo.hProcess,4000);
EnumThreadWindows(procinfo.dwThreadId,&enumMain,0);
WaitForInputIdle(procinfo.hProcess,1000);
EnumChildWindows(mewhwnd,&enumChild,0);
//Sleep(1000);
cout << "Clicking the button..\n";
PostMessage(clickithwnd,BM_CLICK,0,0);


}
