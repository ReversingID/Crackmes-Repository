/*****************************************************************/
/* This is my second Crackme                                     */
/* I am the real Acid_Cool_178, a proud member of hellforge      */
/* When you have cracked this my second crackme please write     */
/* an totorial and send it to acid_cool_178@hotmail.com          */
/* This crackme is coded by:                                     */
/*           	    Acid_Cool_178  [AC_178]                      */
/*							AND									 */
/*                  [The Bug Tracker] [TBT]                      */
/*****************************************************************/
/*                 Greets goes to                                */
/*  LaZaRuS, Shadow_, [ManKind],                                 */
/*****************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <dos.h>
#include <conio.h>

void main()

{
	char code[8];
	printf("This cracme is coded by Acid_Cool_178 and The Bug Tracker\n");
	printf("Please write the code:");
	scanf("%8s",code);
	if(!strcmp(code,"aCiDrOcK")) {
	printf("\tYoU dId It\n");
	}
	else{
		printf("\tYoU fAiLeD\n");
	}

	
}

/*****************************************************************/
/*The End of my crackme                                          */
/*****************************************************************/
