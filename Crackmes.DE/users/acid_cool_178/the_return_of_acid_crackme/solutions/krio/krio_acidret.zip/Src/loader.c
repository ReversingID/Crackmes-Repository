//
// loader for the return of Acid Cool crackme :)
//

#include <windows.h>

void WinMainCRTStartup()
{
	HANDLE hWin;
	int i;

	MessageBox(0,"Note: this will remove only the first NAG, the second must be removed by patching the program code...","NOTE!",MB_OK+MB_ICONINFORMATION);

	if ((ShellExecute(0,"open","cracked.exe",0,".",SW_SHOWDEFAULT)) < 32)
	{
		MessageBox(0,"ERROR: cannot find crackme executable...","ops!",MB_OK+MB_ICONERROR);
		ExitProcess(0);
	}

	i=0;

	do
	{
		hWin=FindWindow(0,"The Return of Acid_Cool_178");

		i++;
		if (i > 0xFFFFFF)
		{
			MessageBox(0,"ERROR: loader timeout...","ops!",MB_OK+MB_ICONERROR);
			ExitProcess(0);
		}

	} while (hWin == 0);

	SendMessage(hWin,WM_CLOSE,0,0);
	ExitProcess(0);
}