Good evening dear cracker/reverser

I have been ideling in the cracking sence and Hellfroge is dead (I think), so now I want to get back in the sence again... But I'm a better cracker now, I have learnd andI have time again, (almost time) 

Protection:

Name, Group, Contry, Calculation and NOT PACKED

Taks:
KEYGENNING with one solution and source....
Patching and serial sniffing is now allowed... Sorry.... 

Mail me at my good old mail

acid_cool_178@hotmail.com


Regards and kissed to the girls :D

Acid_Cool_178 [Hellforge member]

AcidCool.cjb.net
hellforge.org
