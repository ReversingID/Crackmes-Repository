===================================================
Program name: acid cool 178 Crackme3.exe
Cracker     : DaKneeMan
Crack date  : 7 October 2003
Type        : Tutorial and patching (2 steps)
URL         : http://www.crackmes.de
Notes       : Nag killing; Name and Serial fishing
Tools       : ExDec - OllyDbg - UltraEdit
Version     : 1.00
===================================================


In his tut (you must read it first and then my ExDec.txt) Cipher wrote that to kill the nag you must change as follow:

Offset		Original Bytes		New Bytes
00402810	27			1E
00402811	FC			26
00402812	FE			00

but I think it's better to change

00402826     3A6CFF 0B      CMP CH,BYTE PTR DS:[EDI+EDI*8+B]

with

00402826     1E             PUSH DS
00402827     26:000B        ADD BYTE PTR ES:[EBX],CL

(may be now his patcher can crack it: I don't know: I didn't try). 


Step 1: read:      1-NoNag.txt
        execute:   1-NoNag.exe
        you have:  Crackme3.exe with no nag


In ExDec or in OllyDbg you can see the two strings "AcidHell" and "5843" that are the name and the serial required. You can change with them the others two strings "Enter the name here" and "Enter the code here" (I used UltraEdit).


Step 2: read:      2-NameSerial.txt
        execute:   2-NameSerial.exe
        you have:  Crackme3.exe with name and serial




Greets,
DaKneeMan


P.S. - I'm a newbie and this is my first tut, so excuse my style and also my english.