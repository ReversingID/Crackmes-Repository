	

This package includes:

KwazyWeb.bit--->My keyfile to register PacMe
Source.pas  --->My pascal source file
Tutorial.txt--->My tutorial on PacMe
KeyGenerator--->My coded KeyGenerator
PacMe.exe   --->Kwazy Webbits crackme
Readme.txt  --->This file!

Try the crackme, read my tutorial, register with my keyfile,
study my source, make your own keyfile or do whatever you want.
YeZz...