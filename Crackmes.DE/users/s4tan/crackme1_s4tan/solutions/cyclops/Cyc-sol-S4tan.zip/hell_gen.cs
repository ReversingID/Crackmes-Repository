		private void button1_Click(object sender, EventArgs e)
        {
            string text = "Cyclops";
            string str2 = "serial";
            AssemblyName name = new AssemblyName("CrackMe1Assembly");
            AssemblyBuilder builder = AppDomain.CurrentDomain.DefineDynamicAssembly(
             name, AssemblyBuilderAccess.RunAndSave);

            TypeBuilder builder3 = builder.DefineDynamicModule(name.Name, name.Name + ".dll").DefineType("MyDynamicType", TypeAttributes.Public);
            ILGenerator iLGenerator = builder3.DefineConstructor(MethodAttributes.Public, CallingConventions.Standard, Type.EmptyTypes).GetILGenerator();
            iLGenerator.Emit(OpCodes.Ldarg_0);
            iLGenerator.Emit(OpCodes.Call, typeof(object).GetConstructor(Type.EmptyTypes));
            iLGenerator.Emit(OpCodes.Ret);
            this.GenerateOpcode(builder3.DefineMethod("ActivateProduct", MethodAttributes.Public, typeof(bool), new Type[] { typeof(string), typeof(string) }).GetILGenerator());
            Type type = builder3.CreateType();
            MethodInfo method = type.GetMethod("ActivateProduct");

            builder.Save("hell.dll");		//Saves the DLL

            object obj2 = Activator.CreateInstance(type);
            if ((bool)method.Invoke(obj2, new object[] { text, str2 }))
            {
                MessageBox.Show("Product is now registered!! : )");
            }
            else
            {
                MessageBox.Show("Incorrect Key");
            }

        }
        private void GenerateOpcode(ILGenerator ilGen)
        {
            System.Reflection.Emit.Label label = ilGen.DefineLabel();
            System.Reflection.Emit.Label label2 = ilGen.DefineLabel();
            System.Reflection.Emit.Label label3 = ilGen.DefineLabel();
            System.Reflection.Emit.Label loc = ilGen.DefineLabel();
            ilGen.DeclareLocal(typeof(char[]));
            ilGen.DeclareLocal(typeof(char[]));
            ilGen.DeclareLocal(typeof(int));
            ilGen.DeclareLocal(typeof(int));
            ilGen.Emit(OpCodes.Ldarg_1);
            ilGen.EmitCall(OpCodes.Callvirt, typeof(string).GetMethod("ToCharArray", Type.EmptyTypes), Type.EmptyTypes);
            ilGen.Emit(OpCodes.Stloc_0);
            ilGen.Emit(OpCodes.Ldarg_2);
            ilGen.EmitCall(OpCodes.Callvirt, typeof(string).GetMethod("ToCharArray", Type.EmptyTypes), Type.EmptyTypes);
            ilGen.Emit(OpCodes.Stloc_1);
            ilGen.Emit(OpCodes.Ldloc_1);
            ilGen.Emit(OpCodes.Ldlen);
            ilGen.Emit(OpCodes.Conv_I4);
            ilGen.Emit(OpCodes.Ldloc_0);
            ilGen.Emit(OpCodes.Ldlen);
            ilGen.Emit(OpCodes.Conv_I4);
            ilGen.Emit(OpCodes.Ldc_I4_2);
            ilGen.Emit(OpCodes.Mul);
            ilGen.Emit(OpCodes.Beq_S, label);
            ilGen.Emit(OpCodes.Ldc_I4_0);
            ilGen.Emit(OpCodes.Ret);
            ilGen.MarkLabel(label);
            ilGen.Emit(OpCodes.Ldc_I4_0);
            ilGen.Emit(OpCodes.Stloc_2);
            ilGen.Emit(OpCodes.Ldc_I4_0);
            ilGen.Emit(OpCodes.Stloc_3);
            ilGen.Emit(OpCodes.Br_S, label2);
            ilGen.MarkLabel(loc);
            ilGen.Emit(OpCodes.Ldloc_1);
            ilGen.Emit(OpCodes.Ldloc_3);
            ilGen.Emit(OpCodes.Ldelem_U2);
            ilGen.Emit(OpCodes.Ldloc_0);
            ilGen.Emit(OpCodes.Ldloc_2);
            ilGen.Emit(OpCodes.Ldelem_U2);
            ilGen.Emit(OpCodes.Ldloc_3);
            ilGen.Emit(OpCodes.Add);
            ilGen.Emit(OpCodes.Beq_S, label3);
            ilGen.Emit(OpCodes.Ldc_I4_0);
            ilGen.Emit(OpCodes.Ret);
            ilGen.MarkLabel(label3);
            ilGen.Emit(OpCodes.Ldloc_2);
            ilGen.Emit(OpCodes.Ldc_I4_1);
            ilGen.Emit(OpCodes.Add);
            ilGen.Emit(OpCodes.Ldloc_0);
            ilGen.Emit(OpCodes.Ldlen);
            ilGen.Emit(OpCodes.Conv_I4);
            ilGen.Emit(OpCodes.Rem);
            ilGen.Emit(OpCodes.Stloc_2);
            ilGen.Emit(OpCodes.Ldloc_3);
            ilGen.Emit(OpCodes.Ldc_I4_1);
            ilGen.Emit(OpCodes.Add);
            ilGen.Emit(OpCodes.Stloc_3);
            ilGen.MarkLabel(label2);
            ilGen.Emit(OpCodes.Ldloc_3);
            ilGen.Emit(OpCodes.Ldloc_1);
            ilGen.Emit(OpCodes.Ldlen);
            ilGen.Emit(OpCodes.Conv_I4);
            ilGen.Emit(OpCodes.Blt_S, loc);
            ilGen.Emit(OpCodes.Ldc_I4_1);
            ilGen.Emit(OpCodes.Ret);
        }