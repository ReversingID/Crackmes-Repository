## CrackME #1 by s4tan ##

this .NET crackme implements a simple key generator. The tricky part is to understand the msil code (reflector will not be much usefull) : )

rules:
no patching
no bruteforcing
write a key generator
