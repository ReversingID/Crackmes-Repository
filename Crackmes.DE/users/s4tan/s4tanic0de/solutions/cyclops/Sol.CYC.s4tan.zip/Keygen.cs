﻿//
//	Keygen by Cyclops
//	http://cyclops.ueuo.com
//	http://crackmes.de
//
//	Protection: Custom
//
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Keygen
{
    public partial class Keygen : Form
    {
        public Keygen()
        {
            InitializeComponent();
        }

        private void btnMake_Click(object sender, EventArgs e)
        {
            string username = txtName.Text;
            string serial = string.Empty;

            if (username.Length !=0 && username.Length % 4 == 0)
            {
                //Fixed secret buffer
                byte[] secretBuffer = { 0xde, 0xc0, 0xad, 0xba, 0xde, 0xc0, 0xad, 0xba };
                char[] chArray = new char[8];

                for (int i = 0; i < username.Length; i++)
                {
                    chArray[i % 4] = (char)(username.ToCharArray()[i] + chArray[i % 4]);
                }
                //Inverting and appending
                chArray[4] = chArray[3];
                chArray[5] = chArray[2];
                chArray[6] = chArray[1];
                chArray[7] = chArray[0];

                //XORing 
                for (int i = 0; i < 8; i++)
                {
                    serial += string.Format("{0:X2}", (byte)(secretBuffer[i] ^ chArray[i]));
                }
            }
            else
            {
                MessageBox.Show("Pleas input a name with length as multiple of 4!!!", "Error");
            }
            txtSerial.Text = serial;
        }
    }
}
