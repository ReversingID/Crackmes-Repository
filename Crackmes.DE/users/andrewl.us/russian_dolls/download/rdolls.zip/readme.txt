"Russian Dolls" CrackME

You will quickly find good boy and bad boy message.

The decision is based on one call. No tricks.

The call is to the "Russian Dolls" verification function.
(Russian dolls are those dolls where there's like one inside
another, and one inside that, and so on...)

You'll quickly see the similarity of how this verification
function executes and the dolls that the crackme name refers
to.

Write a keygen and a tutorial!

-Andrew