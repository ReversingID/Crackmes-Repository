#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    char code_string[]="sana.masolb.nyo.etosarap|kumantotok.to.itry.niyong.lahat.ha";
    int code=0x3745B2FA;   //Startcode
    FILE *file_handle; 
        
    //Generate File
    // Filename in Crackme: "WalangHiyangCrackme.by.m0d",
    // but old TP only knows 8 characters + first Extension ;-)
    file_handle=fopen("Walanghi.by","w"); // zero size lone 
    fclose(file_handle);
    
    //Generate Code
    for(int i=0;i<strlen(code_string);i++) code+=toupper(code_string[i])+0x45543;        
    code+=strlen(code_string);
    printf("Code : %i\n",code);
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
