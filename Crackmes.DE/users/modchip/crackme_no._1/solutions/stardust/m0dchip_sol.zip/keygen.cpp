#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    char file_code[]="M0DCH!P-K4NTUT!N-M0-N4M4N-4K0-)AAW\x14"; 
    //Seperate here, becuase elsewise my Compiler reads code \x148
    char file_code2[]="8WA-MXA-\x1CNbJabNDONV:-DCW#M0DCH!P-K4NTUT!N-M0-N4M4N-4K0-";
    char code_string[]="putangina-anguwapo-ni-m0dchipsarap|kumantotanu.ba.tong.ginagawa.ko";
    int code=0x08C6FC01;   //Startcode
    FILE *file_handle; 
        
    //Generate File
    file_handle=fopen("text.dat","w");
    fwrite(file_code,strlen(file_code),1,file_handle);
    fwrite(file_code2,strlen(file_code2),1,file_handle);
    fclose(file_handle);
    
    //Generate Code
    for(int i=0;i<strlen(code_string);i++) code+=toupper(code_string[i])+0xd03e3;        
    code+=strlen(code_string);
    printf("Code : %i\n",code);
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
