Here's a simple keygenme that will test your patience.

Protection: MD5

Rules:
1) Keygen + Tutorial is the ultimate goal
2) Self-Keygenning and Phishing are more than welcome -- a posted serial will be difficult to test, as you may soon find out ;)
3) Do NOT patch

Please report any bugs...

Good luck,
OJ