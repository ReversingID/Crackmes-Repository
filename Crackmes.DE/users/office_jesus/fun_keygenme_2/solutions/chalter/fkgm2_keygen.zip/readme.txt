This is the keygen.

Short overview of how it generates the keys:

It takes the first input, checks that its length is not below 5 and digests it 
with the regular SHA-1 hash algorithm.

Then it takes the first 13 bytes of the digest and raises it (interpreting the first 13 bytes as a big-endian hex int) to the power of e=65537 modulo n=90768149341054638040755238998295662661, 
which is the product of primes p=263 and q=345126043121880753006673912541048147. n=p*q

Then it checks that the first 5 chars of the second input are "OJ15-" and what follows after
that is equal to the answer it got from the previous modular exponentiation.

So to generate the decryption key, we find e^(-1) mod (p-1)*(q-1), which is 
d=43326117728942192110561674181345902265.

Then we run the SHA-1 algorithm on the first input, take the first 13 bytes of it, raise 
them (as a big-endian hex) to the power of the decryption key d modulo n and output it 
as "OJ15-" + the hex big-endian representation of the answer we got from the last exponentiation.

The program uses a BigInt implementation. It has algorithms for SHA-1, division, modular 
exponentiation and for finding the modular inverse. I used the functions already in 
the program by patching it a little to generate keys.

It also checks if a debugger is present by calling IsDebuggerPresent and if it is, it 
changes the decryption key plus a lot of other stuff I'm not sure that got used. But it 
definitely changes the decryption key. So this has to be patched to work on it with a 
debugger.