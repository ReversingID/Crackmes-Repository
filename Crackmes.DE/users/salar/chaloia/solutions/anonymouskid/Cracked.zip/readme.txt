SolutionBy[AnonymousKid]
Open Chaloia in ollydbg.
Search Reference Text and go to the line "Right pas......"
below that there's a mov and below JMP section. 
on the JMP part right click and EDIT > FILL WITH NOPS
Then EDIT > COPY All modifi........