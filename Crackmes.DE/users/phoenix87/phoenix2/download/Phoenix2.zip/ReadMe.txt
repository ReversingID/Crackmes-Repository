  ***   Phoenix2   ***
  ***      by      ***
  ***   Phoenix87  ***

Like the first one, find
a valid serial for your
name, but with a different
algorithm.
Write a working keygen and
a tutorial and send 'em to
 phoenix_xx87@hotmail.com

Good Luck, REVERSER!

Special Thanks:
- Quequero (4 publishing)
- Spider (as always!)
- The one who will solve
  correctly this crackme
  for first!

http://bluphoenix.cjb.net
http://quequero.cjb.net
http://bigspider.cjb.net