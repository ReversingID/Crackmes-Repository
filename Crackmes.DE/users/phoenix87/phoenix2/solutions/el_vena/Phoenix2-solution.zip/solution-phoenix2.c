/* coded by elvena at gmail dot com
 *
 * cc -lm -o solution-phoenix2 solution-phoenix2.c
 *
 * 06/nov/04
 */

#include <stdio.h>
#include <math.h>

#include "CrackMePhoenix2.h"

#define GetIndex() \
    __asm__ __volatile__ (  \
    "aam $0x10\t\n" \
    "addb %%ah, %%al\t\n" \
    "xorb %%ah, %%ah\t\n" \
    "shr $0x1, %%eax\t\n" \
    "xorl %%eax, %0\t\n" \
    : "=b" (rv) \
    : "a" (byte), "b" (rv) \
    : "memory"  \
    );

#define LastMagic() \
    __asm__ __volatile__ ( \
    "aam $0x10\t\n" \
    "addb %%ah, %%al\t\n" \
    "xorb %%ah, %%ah\t\n" \
    "shr $1, %%eax" \
    : "=a" (serialbyte) \
    : "a" (serialbyte) \
    : "memory"  \
    );

int GetFunctID(char *name)
{
    int nlen = strlen(name);
    int x;
    int byte = 0;
    int rv = 0;

    for(x=0 ; x < nlen ; x++)
    {
	byte = name[x];

        GetIndex();
    }

    /* Really, its rv plus the first number of the serial, we hardcode it to
     * 1 - useless to randomly generate, but you will need to remove it if
     * you want to code something to see all the possibles keys (not so much
     * for each name, besides that they repeat between different names)
     */
    return ((++rv) / 2);
}

void GetSerial(char *name)
{
    int fid;
    int guide = 0;
    int offset = 0;
    int serialbyte;
    int magic;
    int aux;

    fid = GetFunctID(name);

    printf("FunctionID: %d\n", fid);
    printf("Serial Number for %s is: 1", name);

    for(guide = 0 ; guide < 15 ; guide++)
    {
	switch(fid)
	{
	case 0:
            offset = pow(guide, 2) * 2 + 0xd;
	    break;

	case 1:
	case 2:
            offset = pow(guide, 2) + guide;
            break;

	case 3:
	    offset = pow((guide+1), 2) * guide;
	    break;

	case 4:
	    offset = pow((guide-3), 3) * 3 + pow((guide-2), 2) * 2 + guide + 0x49;
       	    break;

	case 5:
            offset = (pow(guide, 2) + guide) / 2;

	case 6:
            offset = pow(guide, 3);
	    break;

	case 7:
            offset = pow(guide,2) + ( (pow(guide, 2) * 2 + 0xd) *5);
	    break;

	default:
	    printf("Sorry, this FunctionID havent been reverse engineered!\n");
            exit(0);
	}

	serialbyte = CrackMeHeader[offset];

	LastMagic();

	printf("%x", (serialbyte & 0x000000ff));
    }
}

int main(int argc, char *argv[])
{
    printf("solution for phoenix2 crackme - by elvena at gmail dot com\n\n");

    printf("Calculating serial....\n\n");

    GetSerial(argv[1]);

    printf("\n\n");

    exit(1);
}
