#include<iostream>
#include<stdlib.h>
#include<string.h>
using namespace std;
int main()
{
cout<<" -------------------------------------\n";
cout<<"     Phoenix3 - keygen by haggar\n";
cout<<" -------------------------------------\n\n\n\n";





unsigned int x,y,z,i,j,l,NameValue,d1,d2,d3,d4,d5,s1,s2,s3,s4,s5;
char         Name[200];



//-------------- TAKING USER NAME AND CALCULATING NAME_VALUE -------------------
cout<<" User name:         ";cin.get(Name,200);
l=strlen(Name);

y=0;
z=0;
x=3735929054;
for(i=0;i<l;i++)
{
    y=(int)Name[i];
    y=y*16777216+y*65536+y*256+y;
    x=x^y;
    x=x&4278112464;
    x=x|88483;
    z=x/65536;z=z*65536;z=x-z;
    x=x/65536;
    x=x^z;
}
x=x&65535;
NameValue=x;





//-------------------------- SERIAL NUMBER -------------------------------------
cout<<"\n Serial no:         ";

s1=(10946^NameValue)&65535;
s2=(17711^NameValue)&65535;
s3=(28657^NameValue)&65535;
s4=(46368^NameValue)&65535;
s5=(75025^NameValue)&65535;

d1=s1/10000;
d2=s1/1000-d1*10;
d3=s1/100-d1*100-d2*10;
d4=s1/10-d1*1000-d2*100-d3*10;
d5=s1-d1*10000-d2*1000-d3*100-d4*10;
cout<<d1<<d2<<d3<<d4<<d5<<"-";

d1=s2/10000;
d2=s2/1000-d1*10;
d3=s2/100-d1*100-d2*10;
d4=s2/10-d1*1000-d2*100-d3*10;
d5=s2-d1*10000-d2*1000-d3*100-d4*10;
cout<<d1<<d2<<d3<<d4<<d5<<"-";

d1=s3/10000;
d2=s3/1000-d1*10;
d3=s3/100-d1*100-d2*10;
d4=s3/10-d1*1000-d2*100-d3*10;
d5=s3-d1*10000-d2*1000-d3*100-d4*10;
cout<<d1<<d2<<d3<<d4<<d5<<"-";

d1=s4/10000;
d2=s4/1000-d1*10;
d3=s4/100-d1*100-d2*10;
d4=s4/10-d1*1000-d2*100-d3*10;
d5=s4-d1*10000-d2*1000-d3*100-d4*10;
cout<<d1<<d2<<d3<<d4<<d5<<"-";

d1=s5/10000;
d2=s5/1000-d1*10;
d3=s5/100-d1*100-d2*10;
d4=s5/10-d1*1000-d2*100-d3*10;
d5=s5-d1*10000-d2*1000-d3*100-d4*10;
cout<<d1<<d2<<d3<<d4<<d5;



//----------------- ACTIVATION CODE --------------------------------------------

cout<<"\n\n Activation code:   FCFDFEFCFBFBFBF8F0F1F2F0FFFFFFFCECEDEEECFBFBFBF8";




cout<<"\n\n\n\n\n\n ";
system("pause");
return 0;
}