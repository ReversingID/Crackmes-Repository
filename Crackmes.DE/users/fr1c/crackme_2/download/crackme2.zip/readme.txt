	Welcome to my second crackme!
	Made by Fr1c!
I made it in vb5!
It's very easy to crack it!
If you crack it , please send me a tut on how you did it!
Well,go crack it!

E-mail: franjos@usa.net
ICQ UIN:14419920