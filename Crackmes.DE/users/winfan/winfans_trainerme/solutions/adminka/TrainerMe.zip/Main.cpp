/*	
	Solution to TrainerMe.exe from crackmes.de.

	Typing values > 0 sets the value in the program and continues ticking.
	Typing 0 exits trainer.
	Typing values < 0 freezes tick count.

	If no program in the folder or launched program was closed - report error and quit.
	
	By Adminka
*/

#include <iostream>
#include <string.h>
#include <windows.h>

using namespace std;

// <== strings ==>

LPCWSTR program		= TEXT("TrainerMe.exe");
LPCWSTR errorTitle	= TEXT("Error");
LPCWSTR errorMsg	= TEXT("No program found");

// <== offsets & bytes ==>

// change call from program to fake
DWORD addrCallWithFake			= 0x44E493;
int numBytesCallWithFake		= 4;
BYTE patchBytesCallWithFake[]	= {0x09, 0x03, 0x00, 0x00};
/*  call 44E7A0		*/

// set value & continue execution
DWORD addrFakeCode				= 0x44E7A0;
int numBytesFakeCode			= 11;
BYTE patchBytesFakeCode[]		= {0xBA, 0x00, 0x10, 0x00, 0x00, 0xE8, 0x96, 0xFC, 0xFF, 0xFF, 0xC3}; 
/*	mov edx, 1000
	call 44e440
	retn			*/

// change call back from fake to normal
DWORD addrUnfakeCall			= addrCallWithFake;
int numBytesUnfakeCall			= numBytesCallWithFake;
BYTE patchBytesUnfakeCall[]		= {0xA9, 0xFF, 0xFF, 0xFF};
/*  call 44E440		*/

// freeze  count
DWORD addrFreezeCount			= 0x44E48F;
int numBytesFreezeCount			= 1;
BYTE patchBytesFreezeCount[]	= {0x90};
/*  nop				*/

// launch  count
DWORD addrLaunchCount			= addrFreezeCount;
int numBytesLaunchCount			= numBytesFreezeCount;
BYTE patchBytesLaunchCount[]	= {0x4A};
/*  dec edx			*/


int checkInputReturnValue()
{
	int value;
	char buf[2];

	while (true) {
		system("cls");
		cout << "Set time left before quiting:\n";
		cin >> value;
		if (cin.fail()) {
			cin.clear();
			cin.getline(buf, 2);
			continue;
		}
		break;
	}

	return value;
}

int readValueSetBytes()
{
	int value;
	char* buffer = _strdup("00000000");
	string strValue;
	string bytes[4];

	value = checkInputReturnValue();
// want to exit trainer?
	if (value == 0)
		return -1;
	if (value < 0)
		return 1;
// making DWORD from value
	_itoa_s(value, buffer, 8, 16);
	for (unsigned int i = 0; i < (8 - strlen(buffer)); i++)
		strValue += "0";
	strValue += buffer;
	delete buffer;
	buffer = _strdup(strValue.c_str());
// converting DWORD to little endian format
	for (int i = 0; i < 4; i++) {
		bytes[i] += buffer[(i << 1)];
		bytes[i] += buffer[(i << 1) + 1];
		patchBytesFakeCode[4 - i] = strtol(bytes[i].c_str(), NULL, 16);
	}

	return 0;
}

int patchPlace(HANDLE hThread, HANDLE hProcess, LPVOID lpBaseAddress, LPCVOID lpBuffer, SIZE_T nSize)
{
	SuspendThread(hThread);
	WriteProcessMemory(hProcess, lpBaseAddress, lpBuffer, nSize, NULL);
	ResumeThread(hThread);
	return 0;
}

int main()
{
	PROCESS_INFORMATION pi;
	STARTUPINFO si;
	ZeroMemory(&si, sizeof(si));
	ZeroMemory(&pi, sizeof(pi));

	int result;

// launch the program to patch
	result = CreateProcess(program, NULL, NULL, NULL, FALSE, 
		CREATE_NEW_CONSOLE | NORMAL_PRIORITY_CLASS, NULL, NULL, &si, &pi);
	if (result == 0) {
		MessageBox(NULL, errorTitle, errorMsg, MB_OK);
		return -1;
	}
	Sleep(100);

// patch the program where necessary
	DWORD buffer;

	while (TRUE) {
		result = ReadProcessMemory(pi.hProcess, LPCVOID(addrCallWithFake), &buffer, 4, NULL);
		if (result != 0) {
			// setting bytes according to value
			result = readValueSetBytes();
			// exit?
			if (result < 0) {
				CloseHandle(pi.hThread);
				return 0;
			}
			// freeze count?
			if (result > 0) {
				patchPlace(pi.hThread, pi.hProcess, LPVOID(addrFreezeCount), 
					&patchBytesFreezeCount, numBytesFreezeCount);
				continue;
			}
			// apply changes and return to normal execution
			Sleep(400);
			patchPlace(pi.hThread, pi.hProcess, LPVOID(addrCallWithFake), 
				&patchBytesCallWithFake, numBytesCallWithFake);
			patchPlace(pi.hThread, pi.hProcess, LPVOID(addrFakeCode), 
				&patchBytesFakeCode, numBytesFakeCode);
			Sleep(1000);
			patchPlace(pi.hThread, pi.hProcess, LPVOID(addrUnfakeCall), 
				&patchBytesUnfakeCall, numBytesUnfakeCall);
			patchPlace(pi.hThread, pi.hProcess, LPVOID(addrLaunchCount), 
				&patchBytesLaunchCount, numBytesLaunchCount);
		}
		else {
			MessageBox(NULL, errorTitle, errorMsg, MB_OK);
			return -1;
		}
	}

	return 0;
}