Solution to WinFan's TrainerMe


**-Finding the references-**
By loading the application into DE Decompiler we can locate the timer's function; located at 0044E470.
0044E470  /.  55            PUSH EBP
0044E471  |.  8BEC          MOV EBP,ESP
0044E473  |.  6A 00         PUSH 0
0044E475  |.  53            PUSH EBX
0044E476  |.  8BD8          MOV EBX,EAX
0044E478  |.  33C0          XOR EAX,EAX
0044E47A  |.  55            PUSH EBP
0044E47B  |.  68 D1E44400   PUSH 0044E4D1
0044E480  |.  64:FF30       PUSH DWORD PTR FS:[EAX]
0044E483  |.  64:8920       MOV DWORD PTR FS:[EAX],ESP               ;  SEH Setup
0044E486  |.  8BC3          MOV EAX,EBX
0044E488  |.  E8 BFFFFFFF   CALL 0044E44C                            ;  >>>

Following the call to 0044E44C, we can find a first reference to the remaining time:
0044E44C  /$  8B80 F8020000 MOV EAX,DWORD PTR [EAX+2F8]
0044E452  |.  E8 71FDFFFF   CALL 0044E1C8                            ;  >>>
0044E457  \.  C3            RETN

0044E1C8  /$  53            PUSH EBX
0044E1C9  |.  56            PUSH ESI
0044E1CA  |.  57            PUSH EDI
0044E1CB  |.  8BD8          MOV EBX,EAX
0044E1CD  |.  8B43 08       MOV EAX,DWORD PTR [EBX+8]                ;  EAX <- Base
0044E1D0  |.  8B53 0C       MOV EDX,DWORD PTR [EBX+C]                ;  EDX <- Offset
0044E1D3  |.  8B3490        MOV ESI,DWORD PTR [EAX+EDX*4]            ;  ESI <- Seconds left | [Base + Offset * 4]
0044E1D6  |.  8BC3          MOV EAX,EBX
0044E1D8  |.  E8 87FFFFFF   CALL 0044E164
0044E1DD  |.  8B43 08       MOV EAX,DWORD PTR [EBX+8]
0044E1E0  |.  E8 AF73FBFF   CALL 00405594
0044E1E5  |.  E8 324CFBFF   CALL 00402E1C
0044E1EA  |.  8BF8          MOV EDI,EAX
0044E1EC  |.  897B 0C       MOV DWORD PTR [EBX+C],EDI
0044E1EF  |.  8B43 08       MOV EAX,DWORD PTR [EBX+8]
0044E1F2  |.  8934B8        MOV DWORD PTR [EAX+EDI*4],ESI
0044E1F5  |.  8BC6          MOV EAX,ESI
0044E1F7  |.  5F            POP EDI
0044E1F8  |.  5E            POP ESI
0044E1F9  |.  5B            POP EBX
0044E1FA  \.  C3            RETN

Once we know where the data is stored, we can modify it. In order to so, we'll need to find the source of EAX at 0044E1CB; tracing back we can tell the pointer is encoded in the following way:
[[ST+02F8]+08] + [[ST+02F8]+0C] * 4
Where ST would be EBX given at 0044E486.
At that point we could simply search for that value; doing so would lead us to a static pointer, located at 00450C20.

**-Creating a trainer-**
In this case I used a program called Cheat Engine (see attached CT file) to generate the trainer, and used it's Auto Assembler feature.
Here is the script:
=======================================
[Enable]                               //Each script has both an 'Enable' section and a 'Disable' section, each is being executed as the entry is toggled

alloc(code,1024)                       //This will allocate 1024 bytes of memory (page) on the target process
label(num)                             //This is a declaration of a label, that will be used later

registersymbol(num)                    //This will register the symbol 'num' for future use, that way we could use the symbol (num) outside of the scripting interface.

code:                                  //Implementation of the 'code' labeled allocated memory
  cmp [num],0                          //This will ensure that the user would be able to set a value, as the appliance is immidiate
 jz code
 mov eax,[TrainerMe.exe+50C20]         //This would be the base pointer (00450C20)
 mov eax,[eax+02F8]                    //As encoded: EAX <- [ST+02F8]
 mov edx,[eax+08]                      //            EDX <- base
 mov eax,[eax+0C]                      //            EAX <- offset
 push [num]                            //The selected time
 pop  [edx+eax*4]
xor eax,eax
ret

num:                                   //implementation of the lable 'num'
 dd 0                                  //stands fo Define DWORD

CreateThread(code)                     //Will create a new thread where the label 'code' is implemented as soon as the cheat is being enabled

[Disable]

unregistersymbol(num)                  //Once disabled, the symbol is no longer needed

dealloc(code,1024)                     //...and so is the memory

=======================================
