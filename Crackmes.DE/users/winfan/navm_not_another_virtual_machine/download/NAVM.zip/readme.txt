Platform: Microsoft Windows (tested on Windows 7 - 32 bit)
Language: CodeGear Delphi 2009
Difficulty: 3 (I think so ...)

A simple VM is used to verify serials. The algorithm is extra easy, as this CrackMe focuses on analyzing the VM-Code.

Goals: 
    - Explain whats going on in the VM-Code
    - Write a KeyGen which generates random serials
    - Patch the .navm file to make every serial valid (NO EXE-PATCHING)

Have fun :)