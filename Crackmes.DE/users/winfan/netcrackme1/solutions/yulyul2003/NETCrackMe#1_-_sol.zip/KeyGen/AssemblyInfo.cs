// Assembly NETCrackMe1L, Version 1.0.3501.26649

[assembly: System.Reflection.AssemblyVersion("1.0.3501.26649")]
[assembly: System.Reflection.AssemblyTitle("NETCrackMe1L")]
[assembly: System.Reflection.AssemblyDescription("")]
[assembly: System.Reflection.AssemblyConfiguration("")]
[assembly: System.Reflection.AssemblyCompany("")]
[assembly: System.Reflection.AssemblyProduct("NETCrackMe1L")]
[assembly: System.Reflection.AssemblyCopyright("Copyright 2009")]
[assembly: System.Reflection.AssemblyTrademark("")]
[assembly: System.Runtime.InteropServices.ComVisible(false)]
[assembly: System.Runtime.CompilerServices.CompilationRelaxations(8)]
[assembly: System.Runtime.CompilerServices.RuntimeCompatibility(WrapNonExceptionThrows=true)]

