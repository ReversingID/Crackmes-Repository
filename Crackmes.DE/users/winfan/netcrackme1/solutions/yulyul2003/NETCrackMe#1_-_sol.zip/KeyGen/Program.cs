using System;
using System.IO;
using System.Reflection;
using System.Resources;
using System.Windows.Forms;

namespace NETCrackMe1L
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            
            ConsoleKeyInfo c = new ConsoleKeyInfo();
            while (c.KeyChar.ToString().ToUpper() != "0")
            {
                PrintHelp();
                c = Console.ReadKey();
                switch (c.KeyChar)
                {
                    case '1':
                        RunKeyGen();
                        break;
                    case '2':
                        RunCrackme();
                        break;
                    case '3':
                        ExtractCrackme();
                        break;
                    case '0':
                    default:
                        break;
                }
            }
        }

        private static void PrintHelp()
        {
            Console.Clear();
            Console.WriteLine("Available options:");
            Console.WriteLine("0. To quit.");
            Console.WriteLine("1. To run the keygen.");
            Console.WriteLine("2. To run the crackme.");
            Console.WriteLine("3. To extract the actual crackme to output.exe.");
            Console.WriteLine("Choose your option: ");
        }

        private static void  RunKeyGen()
        {
            Application.Run(new Generator());
        }

        private static void RunCrackme()
        {
            ExtractCrackme();
            Assembly assembly = Assembly.Load(DecryptAssembly());
            MethodInfo entryPoint = assembly.EntryPoint;
            if (entryPoint != null)
            {
                object obj2 = assembly.CreateInstance(entryPoint.Name);
                entryPoint.Invoke(obj2, null);
            }
        }

        private static void ExtractCrackme()
        {
            byte[] rawAssembly = DecryptAssembly();
            string fileName = "output.exe";
            if (File.Exists(fileName))
                File.Delete(fileName);
            using (FileStream stream = new FileStream(fileName, FileMode.CreateNew))
            {
                stream.Write(rawAssembly, 0, rawAssembly.Length);
            }
        }

        private static byte[] DecryptAssembly()
        {
            ResourceManager manager = new ResourceManager("NETCrackMe1L.NETCrackMe1L.Resource1", Assembly.GetExecutingAssembly());
            byte[] rawAssembly = (byte[]) manager.GetObject("asm");
            for (int i = 0; i < rawAssembly.Length; i++)
            {
                rawAssembly[i] = (byte) (rawAssembly[i] ^ 0x25);
            }
            return rawAssembly;
        }


    }
}