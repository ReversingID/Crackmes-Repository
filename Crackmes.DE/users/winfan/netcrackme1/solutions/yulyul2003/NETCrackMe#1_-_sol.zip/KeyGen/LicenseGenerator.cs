using System;

namespace NETCrackMe1L
{
    static class LicenseGenerator
    {
        static Random random = new Random((int)DateTime.Now.Ticks);

        public static TLicense GetLicenseFromA(string keyA)
        {
            if (keyA.Trim().Length != 39)
                throw new Exception("Invalid key A.");

            TLicense license = new TLicense();
            string[] keysA = keyA.Split('-');
            license.A.A = Convert.ToInt32(keysA[1]);
            license.A.B = Convert.ToInt32(keysA[2]);
            license.A.C = Convert.ToInt32(keysA[3].Substring(0, 8));
            license.A.D = Convert.ToInt32(keysA[4]);

            license.B.A = Convert.ToInt32(license.A.A ^ license.A.B);
            license.B.B = Convert.ToInt32(license.A.C ^ license.A.D);

            return license;
        }

        public static TLicense GetLicenseFromB(string keyB)
        {
            if (keyB.Trim().Length != 21)
                throw new Exception("Invalid key B.");

            TLicense license = new TLicense();
            string[] keysA = keyB.Split('-');

            license.B.A = Convert.ToInt32(keysA[1]);
            license.B.B = Convert.ToInt32(keysA[2]);

            license.A.A = GenerateRandom(8);
            license.A.B = license.B.A ^ license.A.A;

            license.A.C = GenerateRandom(9);
            license.A.D = license.B.B ^ (license.A.C / 10);

            return license;
        }

        private static int GenerateRandom(int p)
        {
            string result = string.Empty;
            for (int i = 0; i < p; i++)
            {
                result += random.Next(0, 9);
            }

            return Convert.ToInt32(result);
        }

        public class TKeyA
        {
            int a;
            int b;
            int c;
            int d;

            public int A
            {
                get { return a; }
                set { a = value; }
            }

            public int B
            {
                get { return b; }
                set { b = value; }
            }

            public int C
            {
                get { return c; }
                set { c = value; }
            }

            public int D
            {
                get { return d; }
                set { d = value; }
            }
        }

        public class TKeyB
        {
            int a;
            int b;

            public int A
            {
                get { return a; }
                set { a = value; }
            }

            public int B
            {
                get { return b; }
                set { b = value; }
            }
        }

        public class TLicense
        {
            TKeyA a;
            TKeyB b;

            public TLicense()
            {
                a = new TKeyA();
                b = new TKeyB();
            }

            public TKeyB B
            {
                get { return b; }
                set { b = value; }
            }

            public TKeyA A
            {
                get { return a; }
                set { a = value; }
            }
        }
    }
}
