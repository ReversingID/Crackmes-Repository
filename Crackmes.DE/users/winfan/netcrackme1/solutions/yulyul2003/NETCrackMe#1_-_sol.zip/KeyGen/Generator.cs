using System;
using System.Windows.Forms;

namespace NETCrackMe1L
{
    public partial class Generator : Form
    {
        public Generator()
        {
            InitializeComponent();
        }

        private void GenerateAFromB(object sender, EventArgs e)
        {
            try
            {
                LicenseGenerator.TLicense license = LicenseGenerator.GetLicenseFromB(txtKeyB.Text);
                txtKeyA.Text = license.A.A.ToString().PadLeft(8, '0') + license.A.B.ToString().PadLeft(8, '0') +
                    license.A.C.ToString().PadLeft(9, '0') + license.A.D.ToString().PadLeft(9, '0');                
            }
            catch (Exception ex)
            {
                MessageBox.Show("KeyB is not valid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } 
            
        }

        private void GenerateBFromA(object sender, EventArgs e)
        {
            try
            {
                LicenseGenerator.TLicense license = LicenseGenerator.GetLicenseFromA(txtKeyA.Text);
                txtKeyB.Text = license.B.A.ToString().PadLeft(9, '0') + license.B.B.ToString().PadLeft(9, '0');
            }
            catch (Exception ex)
            {
                MessageBox.Show("KeyA is not valid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } 
        }
    }
}