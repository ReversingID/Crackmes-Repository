namespace NETCrackMe1L
{
    partial class Generator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtKeyA = new System.Windows.Forms.MaskedTextBox();
            this.txtKeyB = new System.Windows.Forms.MaskedTextBox();
            this.btnGenerateA = new System.Windows.Forms.Button();
            this.btnGenerateB = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtKeyA
            // 
            this.txtKeyA.AccessibleDescription = "";
            this.txtKeyA.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtKeyA.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtKeyA.Location = new System.Drawing.Point(41, 12);
            this.txtKeyA.Mask = "\\A-00000000-00000000-000000000-000000000";
            this.txtKeyA.Name = "txtKeyA";
            this.txtKeyA.Size = new System.Drawing.Size(233, 20);
            this.txtKeyA.TabIndex = 0;
            // 
            // txtKeyB
            // 
            this.txtKeyB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtKeyB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtKeyB.Location = new System.Drawing.Point(88, 38);
            this.txtKeyB.Mask = "\\B-000000000-000000000";
            this.txtKeyB.Name = "txtKeyB";
            this.txtKeyB.Size = new System.Drawing.Size(132, 20);
            this.txtKeyB.TabIndex = 1;
            // 
            // btnGenerateA
            // 
            this.btnGenerateA.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnGenerateA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGenerateA.Location = new System.Drawing.Point(171, 73);
            this.btnGenerateA.Name = "btnGenerateA";
            this.btnGenerateA.Size = new System.Drawing.Size(136, 23);
            this.btnGenerateA.TabIndex = 2;
            this.btnGenerateA.Text = "Generate A from B";
            this.btnGenerateA.UseVisualStyleBackColor = true;
            this.btnGenerateA.Click += new System.EventHandler(this.GenerateAFromB);
            // 
            // btnGenerateB
            // 
            this.btnGenerateB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnGenerateB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGenerateB.Location = new System.Drawing.Point(12, 73);
            this.btnGenerateB.Name = "btnGenerateB";
            this.btnGenerateB.Size = new System.Drawing.Size(136, 23);
            this.btnGenerateB.TabIndex = 3;
            this.btnGenerateB.Text = "Generate B from A";
            this.btnGenerateB.UseVisualStyleBackColor = true;
            this.btnGenerateB.Click += new System.EventHandler(this.GenerateBFromA);
            // 
            // Generator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(319, 99);
            this.Controls.Add(this.btnGenerateB);
            this.Controls.Add(this.btnGenerateA);
            this.Controls.Add(this.txtKeyB);
            this.Controls.Add(this.txtKeyA);
            this.Name = "Generator";
            this.Text = "WinFan\'s NETCrackMe#1 Key Generator";
            this.TopMost = true;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MaskedTextBox txtKeyA;
        private System.Windows.Forms.MaskedTextBox txtKeyB;
        private System.Windows.Forms.Button btnGenerateA;
        private System.Windows.Forms.Button btnGenerateB;
    }
}