/* 
   -------------------------------------------------------------------------
   - Filename  : main.c
   - Purpose   : trainer for Winfans 3rd Crackme
   - Created   : 08.11.08
   - Protection: "Serial"
   - Difficulty: Author says level 3.... I think more like level 2 but that
   -             is all subjective. I have written loads of game trainers so
   -             this excersise isn't to tough.
   -------------------------------------------------------------------------
   - Copyright (C) 2008	Xorolc
   -
   - This program is free software; you can redistribute it and/or modify it
   - under the terms of the GNU General Public License as published by the
   - Free Software Foundation.
   -
   - This program is distributed in the hope that it will be useful, but
   - WITHOUT ANY WARRANTY; without even the implied warranty of
   - MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
   - See the GNU General Public License for more details.
   -------------------------------------------------------------------------   
*/


/* Includes */
#include <windows.h>
#include "resource.h"

/* save a few bytes */
#pragma comment(linker,"/FILEALIGN:0x200 /MERGE:.data=.text /MERGE:.rdata=.text /SECTION:.text,EWR /IGNORE:4078")

/* Defines */
#define CTRLMSG HIWORD(wParam)
#define CTRLID  LOWORD(wParam)

/* Globals */
char dwBuff[1]      = {0};
char szSerial[17]	= {0};
char WindowClass[]	= "";
char WindowTitle[]	= "WinFan's CrackMe #3";
char TrainerTitle[]	= "Trainer for WinFan's CrackMe #3";

HANDLE hFile		= NULL;
HWND hDlg			= NULL;
HWND gHwnd			= NULL;
HWND hwndSerial;
HANDLE phandle;
HINSTANCE g_inst;

DWORD pid;
DWORD dwAddr		= 0x0045C9A4;


/* Prototypes */
void CenterDialog(HWND);
int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int);
BOOL CALLBACK GameTrainerProc(HWND, UINT, WPARAM, LPARAM);


/* --------------------------- Callback Procedure ---------------------------*/

BOOL CALLBACK GameTrainerProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam){

	int i;

	switch(uMsg){

	case WM_INITDIALOG:
		hwndSerial = GetDlgItem( hDlg, IDC_SERIAL );
		SetWindowText(hDlg, TrainerTitle);
		CenterDialog(hDlg);
		break;

	case WM_CLOSE:
		CloseHandle( phandle );
		EndDialog(hDlg, TRUE);
		break;

	case WM_COMMAND:
		switch(CTRLID){
			
		case IDC_EXIT:
			CloseHandle( phandle );
			EndDialog(hDlg, TRUE);
			break;

		case IDC_OK:
			ZeroMemory( szSerial, sizeof(szSerial) );
			gHwnd = FindWindow(0, WindowTitle);	// Find Window By Title
		    //gHwnd = FindWindow(WindowClass, 0 );// Find Window By Class

			if( gHwnd == NULL ){
				MessageBox( hDlg, "I can't find the Crackme, is it open?", "Err!!!", MB_OK );
				break;
			}

			GetWindowThreadProcessId(gHwnd, (unsigned long *)&pid);
			phandle = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);

			for( i=0; i<16; i++ ){    
				ReadProcessMemory( phandle, (void *)dwAddr, &dwBuff, 1, NULL );
				dwAddr += 4;
				if( dwBuff[0] == 0x01 )
					lstrcat( szSerial, "X" );
				if( dwBuff[0] == 0x00 )
					lstrcat( szSerial, "O" );
			}
			SetWindowText( hwndSerial, szSerial );

			break;
		}
		break;

		default:
			return FALSE;
	}
	return TRUE;
}
/* ------------------------- End Callback Procedure -------------------------*/



/* Entry Point For The Trainer */

int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nCmdShow){
	g_inst = hInstance;
	DialogBox(hInstance,MAKEINTRESOURCE(IDD_DIALOG),NULL,(DLGPROC)GameTrainerProc);
	return FALSE;
}


/* Custom Functions Go Here */

void CenterDialog(HWND hwndDlg){

	RECT Dlg, Desktop;
	DWORD Height, Width, DeskX, DeskY;

	GetWindowRect(hwndDlg, &Dlg);
	GetWindowRect(GetDesktopWindow(), &Desktop);

	Width = Dlg.right - Dlg.left;
	Height = Dlg.bottom - Dlg.top;
	DeskX = (Desktop.right - Width) >> 1;
	DeskY = (Desktop.bottom - Height) >> 1;	

	MoveWindow(hwndDlg, DeskX, DeskY, Width, Height, FALSE);

	return;
}
