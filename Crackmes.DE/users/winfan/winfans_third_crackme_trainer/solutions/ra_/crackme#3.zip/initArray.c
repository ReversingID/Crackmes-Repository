#include <windows.h>
#include <stdio.h>
char str[16]="XXXXOOOOXXXXOOOO";
DWORD dw_457008;
DWORD dw_45c9a4[16]={0};
DWORD unk_45c5a4[16][16];

//00402FB8
DWORD getRandom(DWORD limit)
{
	DWORD v_edx = (DWORD64)dw_457008*0x8088405;
	DWORD64 temp;
	v_edx++;
	dw_457008 = v_edx;
	temp = (DWORD64)limit* (DWORD64)v_edx;
	v_edx = (temp >> 32) & (0x00000000ffffffff);
	return v_edx;
}

//45549C 
int arrInit()
{
	DWORD var_8=0;
	DWORD var_c=0;
	DWORD d1,d2,i;
	DWORD* p1;
	LARGE_INTEGER li;
	
	QueryPerformanceCounter(&li);
	dw_457008 = li.LowPart;

	//first we init the double dim array.
	for(var_8=0;var_8<16;var_8++)
	{
		for(var_c=0;var_c<16;var_c++)
			unk_45c5a4[var_8][var_c] = getRandom(2);
			//get a random integer less than 2
	}

	//then randomly selecting 16  [i][j] pairs, store them into dw_45c9a4
	for(var_8=0;var_8<16;var_8++)
	{
		d1 = getRandom(0x10);//get a random integer less than 16
		d2 = getRandom(0x10);
		printf("d2 %x, d1 %x\n",d2,d1);
		dw_45c9a4[var_8] = unk_45c5a4[d2][d1];
	}

	for(i=0;i<16;++i)printf("%x\n",dw_45c9a4[i]);

}

int main()
{
	DWORD var_8,d1,d2,d3;
	BOOL isCorrect = TRUE;
	arrInit();

	var_8 = 0;
	for(var_8=0; var_8<16 && isCorrect;var_8++)
	{
		d1 = dw_45c9a4[var_8];
		if(d1 == 0)
			if(str[var_8] != 'O')
				isCorrect = FALSE;
		else if(d1 == 1)
			if(str[var_8] != 'X')
				isCorrect = FALSE;
	}
	if(isCorrect)
		printf("Correct Code! %s\n",str);
}
