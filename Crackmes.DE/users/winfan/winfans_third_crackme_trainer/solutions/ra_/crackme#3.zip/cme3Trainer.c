#include <windows.h>
#include <stdio.h>
#include <psapi.h>

#define gle (GetLastError())
#define MAX_PROCESSES_RUNNING 2048

//returns a handle to the process of CrackMe3.exe. the caller should close the handle
VOID getCme3Handle(HANDLE* hCme3)
{
	BOOL found = FALSE;
	DWORD numPids = MAX_PROCESSES_RUNNING;
	DWORD bytesRet,i;
	DWORD* pids = (DWORD*)VirtualAlloc(NULL,MAX_PROCESSES_RUNNING*sizeof(DWORD),MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE);
	*hCme3 = NULL;
	if(pids)
	{
		EnumProcesses((DWORD*)pids, numPids*sizeof(DWORD),(DWORD*)&bytesRet);
		for(i=0;i<bytesRet/sizeof(DWORD);++i)
		{
			HANDLE hProc = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ,	FALSE,pids[i]);
			UCHAR nameBuff[256] = {0};
			if(hProc)
			{
				HMODULE hMod;
				DWORD cbNeeded;
				if ( EnumProcessModules( hProc, &hMod, sizeof(hMod), (LPDWORD)&cbNeeded) )
					GetModuleBaseName( hProc, hMod, nameBuff, 255 );
				if(strcmpi(nameBuff,"CrackMe3.exe") == 0)
				{
					*hCme3 = hProc;
					break;
				}
				CloseHandle(hProc);
			}
		}
		VirtualFree(pids,0,MEM_RELEASE);
	}
	else
		printf("Could not allocate memory for PIDs. GLE 0x%x\n",gle);
}
int main(int argc, char** argv)
{
	HANDLE hProc=NULL;
	BOOL bret;
	DWORD bytesRead,i;
	DWORD dw_45c9a4[16] = {0};
	getCme3Handle(&hProc);
	if(hProc == NULL)
	{
		printf("Could not find CrackMe3.exe running in the system.\n");
		printf("Steps to follow:\n");
		printf("1. Run CrackMe3.exe. You should see a small window with a text box\n");
		printf("2. From cmd prompt, run cme3Trainer.exe\n");
		printf("3. If no error occured, it should print out 16-char code\n");
		printf("4. Paste that code into CrackMe3.exe text box\n");	
		return -1;
	}
	bret = ReadProcessMemory(hProc, (LPCVOID)(0x45c9a4),dw_45c9a4,16*sizeof(DWORD),&bytesRead);
	if(bret == FALSE)
	{
		printf("ReadProcessMemory failed. GLE 0x%x\n",gle);
		return -2;
	}
	printf("The code is: ");
	for(i=0;i<16;++i)
	{
		if(dw_45c9a4[i] == 1)printf("X");
		else if(dw_45c9a4[i] == 0)printf("O");
		else printf("<should not reach here>\n");
	}

	CloseHandle(hProc);
	return 0;
}
