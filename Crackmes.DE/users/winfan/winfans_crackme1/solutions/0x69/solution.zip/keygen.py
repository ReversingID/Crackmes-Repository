def ser(s,i,a):
  rez = a*i
  if i < len(s):
    # Serial is accumulated as multiplying
    # old value by character index and
    # adding character ASCII code
    return ser(s,i+1,rez+ord(s[i]))
  else:
    # We need to convert number to
    # signed int32, because Python
    # integer goes well beyond 32 bits.
    rez = (rez + 2**31) % 2**32 - 2**31
    return rez

while 1:
  usr = raw_input('Enter username: ')
  print 'Generated serial:',ser(usr,1,0)
  print '-----------------------------'
