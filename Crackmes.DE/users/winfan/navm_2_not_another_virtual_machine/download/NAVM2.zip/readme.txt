Platform: Microsoft Windows (tested on Windows 7 - 32 bit)
Language: CodeGear Delphi 2009
Difficulty: 4

This crackme is running entirely from the included VM. To start the crackme,
enter "program.navm" when asked for a file name.

Goals:
- Describe what exactly the VM is doing
- Patch the included program.navm (it must accept any serial)
- KeyGen (MUST BE A .NAVM FILE)

Rules:
- No EXE-Patching

Note: The keygen for the solution must run inside the NAVMCrackme2 Interpreter. You have to
create a new .navm file and enter its name on startup.


Have fun :)