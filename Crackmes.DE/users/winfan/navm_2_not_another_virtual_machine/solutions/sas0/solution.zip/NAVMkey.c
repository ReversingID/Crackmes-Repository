#include <stdio.h>
#include <stdlib.h>

typedef unsigned char byte;
typedef unsigned int dword;

#define WELCOME_MSG_OFFSET 0x00000100
#define USERNAME_LENGTH 0x00000000
#define USERNAME_REQ_LENGTH 0x00000001
#define USERNAME_HASH 0x00000002
#define USERNAME_CHAR 0x00000003
#define USERNAME_TEMP_HASH 0x00000004
#define PASSWORD_OFFSET 0x00000005
#define USERNAME_TEMP_HASH2 0x00000006
#define USERNAME_TEMP_HASH3 0x00000007
#define HEX_DECODE_VAL 0x00000008
#define TEMP_HEX_VALUE 0x00000009
#define HEX_CONV_MAGIC 0x0000000A
#define USERNAME_POINTER 0x000000FF

#pragma pack(1)
typedef struct {
	byte opcode;
	byte postFix;
	dword param1;
	dword param2;
} VM_COMMAND;

int main(int argc, char* argv[]){

	char* welcomeMsg = "NAVM 2 Keygen by |sas0|\n\nEnter username: \0";
	char* tooShortUsername = "Username must have 10 chars\0";
	char* passwordMsg = "Password: $";
	int i = 0;
	int shorUsernameOffset;
	int passOffset;
	int passwordStart;
	VM_COMMAND *vmCommand;
	
	if(0 == (vmCommand = (VM_COMMAND*)malloc(sizeof(VM_COMMAND)))){
		printf("Can not allocate memory\n");
		return 1;
	}
	
	FILE* fdout = fopen("keygen.navm","wb");
	
	if(fdout == 0){
		printf("Can not open output file\n");
		return 1;
	}
	
	/* MOV [param2], param1 */
	vmCommand->opcode = 0xE4;
	vmCommand->postFix = 0xD1;
	/* write welcome msg until null byte */
	while(*((char*)(welcomeMsg + i)) != '\0'){
		vmCommand->param1 = (int)*((char*)(welcomeMsg + i));
		vmCommand->param2 = (WELCOME_MSG_OFFSET + i);
		fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
		i++;
	}
	/* write null byte at the end */
	vmCommand->param1 = (int)*((char*)(welcomeMsg + i));
	vmCommand->param2 = (WELCOME_MSG_OFFSET + i);
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	i++;
	
	/* write message if username is too short */
	shorUsernameOffset = WELCOME_MSG_OFFSET + i;
	i = 0;
	while(*((char*)(tooShortUsername + i)) != '\0'){
		vmCommand->param1 = (int)*((char*)(tooShortUsername + i));
		vmCommand->param2 = (shorUsernameOffset + i);
		fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
		i++;
	}
	/* write null byte at the end */
	vmCommand->param1 = (int)*((char*)(tooShortUsername + i));
	vmCommand->param2 = (shorUsernameOffset + i);
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	i++;
	
	/* write password msg */
	passOffset = shorUsernameOffset + i;
	i = 0;
	while(*((char*)(passwordMsg + i)) != '$'){
		vmCommand->param1 = (int)*((char*)(passwordMsg + i));
		vmCommand->param2 = (passOffset + i);
		fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
		i++;
	}
	vmCommand->param1 = (int)*((char*)(passwordMsg + i));
	vmCommand->param2 = (passOffset + i);
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	i++;
	
	passwordStart = passOffset + i;
	
	/* fill 8 chars with "0", this is the max number of chars that password can have */
	for(i = 0; i < 8; i++){
		vmCommand->param1 = 0x00000030; //"0"
		vmCommand->param2 = (passwordStart + i);
		fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	}
	vmCommand->param1 = 0x00000000; //null
	vmCommand->param2 = (passwordStart + i);
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	passwordStart += 7;
	
	/* VM_PRINT(WELCOME_MSG) */
	vmCommand->opcode = 0xA0;
	vmCommand->postFix = 0xD1;
	vmCommand->param1 = WELCOME_MSG_OFFSET;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* VMIN_USERNAME */
	vmCommand->opcode = 0xA2;
	vmCommand->postFix = 0xD1;
	vmCommand->param1 = USERNAME_LENGTH;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* MOV [USERNAME_REQ_LENGTH], 10 */
	vmCommand->opcode = 0xE4;
	vmCommand->postFix = 0xD1;
	vmCommand->param2 = USERNAME_REQ_LENGTH;
	vmCommand->param1 = 10;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* CMP [USERNAME_LENGTH], [USERNAME_REQ_LENGTH]*/
	vmCommand->opcode = 0x02;
	vmCommand->postFix = 0xD0;
	vmCommand->param1 = USERNAME_LENGTH;
	vmCommand->param2 = USERNAME_REQ_LENGTH;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* JZ skip next 2 instruction */
	vmCommand->opcode = 0x03;
	vmCommand->postFix = 0xD1;
	vmCommand->param1 = 2;
	vmCommand->param2 = 1;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* print msg too short or too long usernames */
	vmCommand->opcode = 0xA0;
	vmCommand->postFix = 0xD1;
	vmCommand->param1 = shorUsernameOffset;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* EXIT_VM(param1) */
	vmCommand->opcode = 0x00;
	vmCommand->postFix = 0xD1;
	vmCommand->param1 = 0;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* MOV [USERNAME_REQ_LENGTH], 0 */
	vmCommand->opcode = 0xE4;
	vmCommand->postFix = 0xD1;
	vmCommand->param2 = USERNAME_REQ_LENGTH;
	vmCommand->param1 = 0;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* MOV [USERNAME_HASH], 1 */
	vmCommand->opcode = 0xE4;
	vmCommand->postFix = 0xD1;
	vmCommand->param2 = USERNAME_HASH;
	vmCommand->param1 = 1;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* CMP [USERNAME_REQ_LENGTH], [USERNAME_POINTER]*/
	vmCommand->opcode = 0x02;
	vmCommand->postFix = 0xD0;
	vmCommand->param1 = USERNAME_REQ_LENGTH;
	vmCommand->param2 = USERNAME_POINTER;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* JZ skip next 3 instruction */
	vmCommand->opcode = 0x03;
	vmCommand->postFix = 0xD1;
	vmCommand->param1 = 3;
	vmCommand->param2 = 1;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* MOV [USERNAME_CHAR], USERNAME.CHAR */
	vmCommand->opcode = 0xE1;
	vmCommand->postFix = 0xD0;
	vmCommand->param1 = USERNAME_CHAR;
	vmCommand->param2 = 0;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* IMUL [USERNAME_HASH], [USERNAME_CHAR] */
	vmCommand->opcode = 0xF2;
	vmCommand->postFix = 0xD0;
	vmCommand->param1 = USERNAME_HASH;
	vmCommand->param2 = USERNAME_CHAR;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* JMP 4 instructions back */
	vmCommand->opcode = 0x01;
	vmCommand->postFix = 0xD1;
	vmCommand->param1 = 5;
	vmCommand->param2 = 2 ;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* MOV [USERNAME_TEMP_HASH], [USERNAME_HASH] */
	vmCommand->opcode = 0xE4;
	vmCommand->postFix = 0xD0;
	vmCommand->param2 = USERNAME_TEMP_HASH;
	vmCommand->param1 = USERNAME_HASH;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* DIV [USERNAME_TEMP_HASH], 2 */
	vmCommand->opcode = 0xF3;
	vmCommand->postFix = 0xD1;
	vmCommand->param1 = USERNAME_TEMP_HASH;
	vmCommand->param2 = 2;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* XOR [USERNAME_HASH], [USERNAME_TEMP_HASH] */
	vmCommand->opcode = 0xF4;
	vmCommand->postFix = 0xD0;
	vmCommand->param1 = USERNAME_HASH;
	vmCommand->param2 = USERNAME_TEMP_HASH;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* MOV [HEX_CONV_MAGIC], 9 */
	vmCommand->opcode = 0xE4;
	vmCommand->postFix = 0xD1;
	vmCommand->param2 = HEX_CONV_MAGIC;
	vmCommand->param1 = 9;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* LOOP + DEKODIRANJE */
	i = 0;
	for(i = 0; i < 8; i++){
	
	/* MOV [USERNAME_TEMP_HASH3], [USERNAME_HASH] */
	vmCommand->opcode = 0xE4;
	vmCommand->postFix = 0xD0;
	vmCommand->param2 = USERNAME_TEMP_HASH3;
	vmCommand->param1 = USERNAME_HASH;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* DIV [USERNAME_HASH], 16 */
	vmCommand->opcode = 0xF3;
	vmCommand->postFix = 0xD1;
	vmCommand->param1 = USERNAME_HASH;
	vmCommand->param2 = 16;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* MOV [USERNAME_TEMP_HASH2], [USERNAME_HASH] */
	vmCommand->opcode = 0xE4;
	vmCommand->postFix = 0xD0;
	vmCommand->param2 = USERNAME_TEMP_HASH2;
	vmCommand->param1 = USERNAME_HASH;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* IMUL [USERNAME_TEMP_HASH2], 16 */
	vmCommand->opcode = 0xF2;
	vmCommand->postFix = 0xD1;
	vmCommand->param1 = USERNAME_TEMP_HASH2;
	vmCommand->param2 = 16;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* SUB [USERNAME_TEMP_HASH3], [USERNAME_TEMP_HASH2]*/
	vmCommand->opcode = 0xF1;
	vmCommand->postFix = 0xD0;
	vmCommand->param1 = USERNAME_TEMP_HASH3;
	vmCommand->param2 = USERNAME_TEMP_HASH2;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* MOV [HEX_DECODE_VAL], 6 */
	vmCommand->opcode = 0xE4;
	vmCommand->postFix = 0xD1;
	vmCommand->param2 = HEX_DECODE_VAL;
	vmCommand->param1 = 6;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* MOV [TEMP_HEX_VALUE], [USERNAME_TEMP_HASH3] */
	vmCommand->opcode = 0xE4;
	vmCommand->postFix = 0xD0;
	vmCommand->param2 = TEMP_HEX_VALUE;
	vmCommand->param1 = USERNAME_TEMP_HASH3;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* CMP [USERNAME_REQ_LENGTH], [HEX_DECODE_VAL]*/
	vmCommand->opcode = 0x02;
	vmCommand->postFix = 0xD0;
	vmCommand->param1 = USERNAME_REQ_LENGTH;
	vmCommand->param2 = HEX_DECODE_VAL;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* JZ char_0_9 */
	vmCommand->opcode = 0x03;
	vmCommand->postFix = 0xD1;
	vmCommand->param1 = 5;
	vmCommand->param2 = 1;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* SUB [HEX_DECODE_VAL], 1 */
	vmCommand->opcode = 0xF1;
	vmCommand->postFix = 0xD1;
	vmCommand->param1 = HEX_DECODE_VAL;
	vmCommand->param2 = 1;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* SUB [TEMP_HEX_VALUE], 1 */
	vmCommand->opcode = 0xF1;
	vmCommand->postFix = 0xD1;
	vmCommand->param1 = TEMP_HEX_VALUE;
	vmCommand->param2 = 1;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* CMP [TEMP_HEX_VALUE], [HEX_CONV_MAGIC] */
	vmCommand->opcode = 0x02;
	vmCommand->postFix = 0xD0;
	vmCommand->param1 = TEMP_HEX_VALUE;
	vmCommand->param2 = HEX_CONV_MAGIC;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* JZ char_A_F */
	vmCommand->opcode = 0x03;
	vmCommand->postFix = 0xD1;
	vmCommand->param1 = 3;
	vmCommand->param2 = 1;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* JMP 7 instructions back */
	vmCommand->opcode = 0x01;
	vmCommand->postFix = 0xD1;
	vmCommand->param1 = 7;
	vmCommand->param2 = 2 ;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* 0 - 9 */
	/* ADD [USERNAME_TEMP_HASH3], 0x30 (convert mod to chars from 0 to 9) */
	vmCommand->opcode = 0xF0;
	vmCommand->postFix = 0xD1;
	vmCommand->param1 = USERNAME_TEMP_HASH3;
	vmCommand->param2 = 0x00000030;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* JMP 2 instructions forward */
	vmCommand->opcode = 0x01;
	vmCommand->postFix = 0xD1;
	vmCommand->param1 = 1;
	vmCommand->param2 = 1 ;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* A - F */
	/* ADD [USERNAME_TEMP_HASH3], 0x37 (convert mod to chars from A to F) */
	vmCommand->opcode = 0xF0;
	vmCommand->postFix = 0xD1;
	vmCommand->param1 = USERNAME_TEMP_HASH3;
	vmCommand->param2 = 0x00000037;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* MOV [passwordStart - i], [USERNAME_TEMP_HASH3] */
	vmCommand->opcode = 0xE4;
	vmCommand->postFix = 0xD0;
	vmCommand->param2 = (passwordStart - i);
	vmCommand->param1 = USERNAME_TEMP_HASH3;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	}
	
	/* VM_PRINT serial passOffset */
	vmCommand->opcode = 0xA0;
	vmCommand->postFix = 0xD1;
	vmCommand->param1 = passOffset;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	/* EXIT_VM(param1) */
	vmCommand->opcode = 0x00;
	vmCommand->postFix = 0xD1;
	vmCommand->param1 = 0;
	fwrite(vmCommand,1,sizeof(VM_COMMAND),fdout);
	
	free(vmCommand);
	free(fdout);
}
