#include <stdio.h>
#include <stdlib.h>

typedef unsigned char byte;
typedef unsigned int dword;

#pragma pack(1)
typedef struct {
	byte opcode;
	byte postFix;
	dword param1;
	dword param2;
} VM_COMMAND;

void AnalizeJmpCommand(FILE *fdout, VM_COMMAND *vmCommand, int vmOffset, char* jmpType, int eip, int programLength);

int main(int argc, char* argv[]){

	long inputLength;
	int numOfVMCommands;
	int fileAlignment;
	int vmOffset = 0;
	int i;
	byte isInString = 0;
	byte *buffer = 0;
	VM_COMMAND *vmCommand;
	
	if(argc != 3){
		printf("Usage: diss input_file output_file\n");
		return 1;
	}
	
	FILE* fdin = fopen(argv[1],"rb");
	FILE* fdout = fopen(argv[2],"w");
	
	if(fdin == 0){
		printf("Can not open input file %s\n",argv[1]);
		return 1;
	}
	
	if(fdout == 0){
		free(fdin);
		printf("Can not open input file %s\n",argv[2]);
		return 1;
	}
	
	if(0 != fseek(fdin,0,SEEK_END)){
		free(fdin);
		free(fdout);
		printf("Can not retrieve input file length\n");
		return 1;
	}
	
	printf("Input file length: %d\n",(inputLength = ftell(fdin)));
	
	rewind(fdin);
	
	if(inputLength <= 0){
		free(fdin);
		free(fdout);
		printf("Invalid file length %d\n",inputLength);
		return 1;
	}
	else if ((fileAlignment = inputLength % 10) != 0){
		printf("Invalid file alignment %d\n",fileAlignment);
	}
	else{
		printf("File alignment: %d\n",fileAlignment);
	}
	
	printf("Number of VM commands: %d\n",(numOfVMCommands = inputLength / 10));
	if(numOfVMCommands <= 0){
		free(fdin);
		free(fdout);
		return 1;
	}
	
	if(0 == (buffer = (byte*)malloc(sizeof(byte)*inputLength))){
		free(fdin);
		free(fdout);
		printf("Can not allocate memory (%d bytes)\n",inputLength);
		return 1;
	}
	
	if(inputLength != fread(buffer,sizeof(byte),inputLength,fdin)){
		if(feof(fdin)){
			printf("EOF accured!\n");
		}
		else{
			printf("Error accured (error number: %d)\n",ferror(fdin));
		}
		free(buffer);
		fclose(fdin);
		fclose(fdout);
		return 1;
	}
	
	int vm_offset = 0;
	
	/* analyze all vm commands */
	for(i = 0; i < numOfVMCommands; i++){
		vmOffset = (int)(i * sizeof(VM_COMMAND));
		vmCommand = (VM_COMMAND*)(buffer + vmOffset);
		
		/* EXIT_VM */
		if(vmCommand->opcode == 0x00){
			if(vmCommand->postFix == 0xD0){
				fprintf(fdout,"CODE:%08X\t/* %s%08X%s */\n", vmOffset,"EXIT_VM([",vmCommand->param1,"])");
			}
			else{
				fprintf(fdout,"CODE:%08X\t/* %s%08X%s */\n", vmOffset,"EXIT_VM(",vmCommand->param1,")");
			}
		}
		/* JMP */
		else if (vmCommand->opcode == 0x01){
			AnalizeJmpCommand(fdout,vmCommand,vmOffset,"JMP",i+1,numOfVMCommands);
		}
		/* CMP */
		else if (vmCommand->opcode == 0x02){
			if(vmCommand->postFix == 0xD0){
				fprintf(fdout,"CODE:%08X\t/* CMP [%08X], [%08X] */\n", vmOffset,vmCommand->param1,vmCommand->param2);
			}
			else{
				fprintf(fdout,"CODE:%08X\t/* CMP %08X, %08X */\n", vmOffset,vmCommand->param1,vmCommand->param2);
			}
		}
		/* JZ */
		else if (vmCommand->opcode == 0x03){
			AnalizeJmpCommand(fdout,vmCommand,vmOffset,"JZ",i+1,numOfVMCommands);
		}
		/* JNZ */
		else if (vmCommand->opcode == 0x04){
			AnalizeJmpCommand(fdout,vmCommand,vmOffset,"JNZ",i+1,numOfVMCommands);
		}
		/* VM_PRINT */
		else if (vmCommand->opcode == 0xA0){
			fprintf(fdout,"CODE:%08X\t/* VM_PRINT([%08X]) */\n", vmOffset,vmCommand->param1);
		}
		/* VM_PRINTLN */
		else if (vmCommand->opcode == 0xA1){
			fprintf(fdout,"CODE:%08X\t/* VM_PRINTLN([%08X]) */\n", vmOffset,vmCommand->param1);
		}
		/* VM_INPUT */
		else if (vmCommand->opcode == 0xA2){
			fprintf(fdout,"CODE:%08X\t/* VMIN_USERNAME([%08X]) */\n", vmOffset,vmCommand->param1);
		}
		/* VM_INPUT(StrToInt -> [param1]) */
		else if (vmCommand->opcode == 0xA3){
			if(vmCommand->postFix == 0xD0){
				fprintf(fdout,"CODE:%08X\t/* VMIN_PASSWORD([%08X]) */\n", vmOffset,vmCommand->param1);
			}
			else{
				fprintf(fdout,"CODE:%08X\t/* VMIN_PASSWORD([[%08X]]) */\n", vmOffset,vmCommand->param1);
			}
		}
		/* another pair of function which look useless, the last "byte" of string is set to param1 or VM_STACK[param1] */
		else if (vmCommand->opcode == 0xE0){
			if(vmCommand->postFix == 0xD0){
				fprintf(fdout,"CODE:%08X\t/* USERNAME.CONCAT(%08X) */\n", vmOffset,vmCommand->param1);
			}
			else{
				fprintf(fdout,"CODE:%08X\t/* USERNAME.CONCAT([%08X]) */\n", vmOffset,vmCommand->param1);
			}
		}
		/* pair of the same type of functions, first one move fist string byte to VM_STACK[param1], second one look like internal TSNAVMSTACK function */
		else if (vmCommand->opcode == 0xE1){
			if(vmCommand->postFix == 0xD0){
				fprintf(fdout,"CODE:%08X\t/* MOV [%08X], USERNAME.CHAR */\n", vmOffset,vmCommand->param1);
			}
			else{
				fprintf(fdout,"CODE:%08X\t/* USERNAME.MOVENEXT */\n", vmOffset);
			}
		}
		/* MOV or NOP */
		else if (vmCommand->opcode >= 0xE2 && vmCommand->opcode <= 0xEF){
			/* MOV */
			if(vmCommand->opcode == 0xE4){
				if(vmCommand->postFix == 0xD0){
					fprintf(fdout,"CODE:%08X\t/* MOV [%08X], [%08X] */\n", vmOffset, vmCommand->param2, vmCommand->param1);
				}
				else{
					fprintf(fdout,"CODE:%08X\t/* MOV [%08X], %08X */\n", vmOffset, vmCommand->param2, vmCommand->param1);
				}
			}
			/* NOP */
			else{
				fprintf(fdout,"CODE:%08X\t/* NOP */\n", vmOffset);
			}
		}
		/* ADD */
		else if (vmCommand->opcode == 0xF0) {
			if(vmCommand->postFix == 0xD0){
				fprintf(fdout,"CODE:%08X\t/* ADD [%08X], [%08X] */\n", vmOffset, vmCommand->param1, vmCommand->param2);
			}
			else{
				fprintf(fdout,"CODE:%08X\t/* ADD [%08X], %08X */\n", vmOffset, vmCommand->param1, vmCommand->param2);
			}
		}
		/* SUB */
		else if (vmCommand->opcode == 0xF1) {
			if(vmCommand->postFix == 0xD0){
				fprintf(fdout,"CODE:%08X\t/* SUB [%08X], [%08X] */\n", vmOffset, vmCommand->param1, vmCommand->param2);
			}
			else{
				fprintf(fdout,"CODE:%08X\t/* SUB [%08X], %08X */\n", vmOffset, vmCommand->param1, vmCommand->param2);
			}
		}
		/* IMUL */
		else if (vmCommand->opcode == 0xF2) {
			if(vmCommand->postFix == 0xD0){
				fprintf(fdout,"CODE:%08X\t/* IMUL [%08X], [%08X] */\n", vmOffset, vmCommand->param1, vmCommand->param2);
			}
			else{
				fprintf(fdout,"CODE:%08X\t/* IMUL [%08X], %08X */\n", vmOffset, vmCommand->param1, vmCommand->param2);
			}
		}
		/* DIV */
		else if (vmCommand->opcode == 0xF3) {
			if(vmCommand->postFix == 0xD0){
				fprintf(fdout,"CODE:%08X\t/* DIV [%08X], [%08X] */\n", vmOffset, vmCommand->param1, vmCommand->param2);
			}
			else{
				fprintf(fdout,"CODE:%08X\t/* DIV [%08X], %08X */\n", vmOffset, vmCommand->param1, vmCommand->param2);
			}
		}
		/* XOR */
		else if (vmCommand->opcode == 0xF4) {
			if(vmCommand->postFix == 0xD0){
				fprintf(fdout,"CODE:%08X\t/* XOR [%08X], [%08X] */\n", vmOffset, vmCommand->param1, vmCommand->param2);
			}
			else{
				fprintf(fdout,"CODE:%08X\t/* XOR [%08X], %08X */\n", vmOffset, vmCommand->param1, vmCommand->param2);
			}
		}
		
		
		/* VM command */
		if(vmCommand->opcode == 0xE4 && vmCommand->postFix == 0xD1){
			fprintf(fdout,"CODE:%08X\t %02X %02X %08X %08X '%c'\n\n",
					vmOffset,
					vmCommand->opcode,
					vmCommand->postFix,
					vmCommand->param1,
					vmCommand->param2,
					(char)(vmCommand->param1 & 0x000000FF)
					);
		}
		else{
			fprintf(fdout,"CODE:%08X\t %02X %02X %08X %08X\n\n",
					vmOffset,
					vmCommand->opcode,
					vmCommand->postFix,
					vmCommand->param1,
					vmCommand->param2
					);
		}
	}
	
	free(buffer);
	fclose(fdin);
	fclose(fdout);
	
	return 0;
}

void AnalizeJmpCommand(FILE *fdout, VM_COMMAND *vmCommand, int vmOffset, char* jmpType, int eip, int programLength){
	/* vm_stack based type of command */
	if(vmCommand->postFix == 0xD0){
		/* 0 + VM_STACK{param1} */
		if(vmCommand->param2 == 0x00000000){
			fprintf(fdout,"CODE:%08X\t/* %s VM_STACK[%08X] */\n", vmOffset, jmpType, vmCommand->param1);
		}
		/* EIP + VM_STACK{param1} */
		else if (vmCommand->param2 == 0x00000001){
			fprintf(fdout,"CODE:%08X\t/* %s %08X + VM_STACK[%08X] */\n", vmOffset, jmpType, eip, vmCommand->param1);
		}
		/* EIP - VM_STACK{param1} */
		else if (vmCommand->param2 == 0x00000002){
			fprintf(fdout,"CODE:%08X\t/* %s %08X - VM_STACK[%08X] */\n", vmOffset, jmpType, eip, vmCommand->param1);
		}
		/* PROGRAM_LENGTH - VM_STACK{param1} */
		else if (vmCommand->param2 == 0x00000003){
			fprintf(fdout,"CODE:%08X\t/* %s %08X - VM_STACK[%08X] */\n", vmOffset, jmpType, programLength, vmCommand->param1);
		}
	}
	/* parameterized type of command */
	else{
		if(vmCommand->param2 == 0x00000000){
			fprintf(fdout,"CODE:%08X\t/* %s %08X */\n", vmOffset, jmpType, vmCommand->param1*sizeof(VM_COMMAND));
		}
		else if (vmCommand->param2 == 0x00000001){
			fprintf(fdout,"CODE:%08X\t/* %s %08X */\n", vmOffset, jmpType, (eip + vmCommand->param1)*sizeof(VM_COMMAND));
		}
		else if (vmCommand->param2 == 0x00000002){
			fprintf(fdout,"CODE:%08X\t/* %s %08X */\n", vmOffset, jmpType, (eip - vmCommand->param1)*sizeof(VM_COMMAND));
		}
		else if (vmCommand->param2 == 0x00000003){
			fprintf(fdout,"CODE:%08X\t/* %s %08X */\n", vmOffset, jmpType, (programLength - vmCommand->param1)*sizeof(VM_COMMAND));
		}
	}
}
