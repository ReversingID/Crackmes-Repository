Difficulty: 3 - Getting harder
Language: Borland Delphi
Platform: MS Windows

In this KeyFileMe, your task is to write a generator for the licensefile. I have already included one valid 
license.dat for the name "WinFan". 

There is a little AntiDebug trick, which can be avoided without patching, but if you want to, patching is allowed.


Rules: 
	-No Bruteforcing ^^
	-Write a KeyFile Generator
	-Explain what you've done 

Of course, the source of the Generator must be included in the solution (I don't care what language you use)

Good luck!

note: Some AV's detect a virus / malware in this file. This can be ignored, theres no virus inside ;)