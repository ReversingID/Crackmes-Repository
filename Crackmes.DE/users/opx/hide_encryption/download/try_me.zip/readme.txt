Crackme ver 4.00

Rulez : 1. Get valid password  
        2. Patch allowed
        3. Anything way you want to do ?

recommended : advanced or higher

I think this very very difficult for beginner,
so don't try if u are beginner.

see u in next crackme.

Opx 8-)
