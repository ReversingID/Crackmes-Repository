Target : make password generator

Opx
