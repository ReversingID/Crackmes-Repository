Rulez:
1. Patch till successful.
2. You must make patch file.

Opx :) enjoy it!