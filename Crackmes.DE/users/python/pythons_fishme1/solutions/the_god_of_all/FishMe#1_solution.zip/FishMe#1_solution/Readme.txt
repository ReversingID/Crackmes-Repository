Keygen for Python's FishMe#1 (http://www.crackmes.de/users/python/pythons_fishme1/)

The Keygen is copyright by The-God-of-all.

Sorry for my bad englisch, I hope you can understand everything.

Files:
FishMe#1: The original FishMe#1 from Python
KeygenFishMe#1: My Keygen (.exe) and the source (source.vb) and a little explanation.