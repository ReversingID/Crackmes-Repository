The Fishme is written in .Net. Luckily it is possible to decompile .Net Programs and get the source Code.

After decompiling the Fischme I had the source Code. There were many trash code like many sensless vars.
After deleting all Trash functions only parts of the functions Button1_Click, keykey and versteck left.
But even in this functions there is a lot of trash code. After further studies of the code I found out
that the Fishme create of every Character of the name the Sha1 Hash, converts it into a hex String at
takes the first Caracter as part of the Key (same position in the Key as the character in the name).

The Key can have max the size of the name but it can be shorter because only the typed characters are compared,
not the length of the password. The first Character of the key is enough. For example if the name starts with 'H'
a simple '7' will work as key.