	Private Sub btnGenerate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGenerate.Click
        Dim name As String
        Dim pw As String = ""
        name = txtName.Text
        If name.Length < 5 Then
            MsgBox("The name must be longer than 4 Characters!", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Error")
        ElseIf name.Length > 9 Then
            MsgBox("The name must be shorter than 10 Characters!", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Error")
        Else
            Dim provider As New SHA1CryptoServiceProvider
            Dim temp As String
            Dim buffer() As Byte
            Dim nc() As Byte
            Dim i As Integer

            For i = 0 To (name.Length - 1)
                nc = Encoding.ASCII.GetBytes(name.Substring(i, 1))
                buffer = provider.ComputeHash(nc)
                temp = Conversion.Hex(buffer(0))
                If temp.Length < 2 Then
                    temp = 0 & temp
                End If
                pw = pw & temp.Substring(0, 1)
            Next
        End If
        txtPw.Text = pw
    End Sub