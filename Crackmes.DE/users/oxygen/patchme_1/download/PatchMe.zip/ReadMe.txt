This is a PatchMe in full ASM (My first)

You need to add a Nag Screen and write your name in the Main Window (After your nag screen)
You can use what you want, you can do what you want. You just need to do these 2 things

Have Fun Reversing ! ;D
oXY <3