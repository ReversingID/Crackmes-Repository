import binascii

"""
little endian bytes to integer number
"""
def render_int16(bytes):
	return bytes[0] + (bytes[1] << 8)

"""
integer number to little endian bytes
"""
def unrender_int16(int16):
	return [ int16 & 0xff, (int16 & 0xff00) >> 8 ]

"""
decrypt the bytecode in place
"""
def unpack(bytes):
	
	"""
	encrypted bytecode starts at offset 64
	"""
	cursor = 64


	while cursor < len(bytes):
		"""
		scan bytecode in 16 bits blocks and xor with constant 22102 in place
		"""
		bytes[cursor:cursor+2] = unrender_int16(render_int16(bytes[cursor:cursor+2]) ^ 22102)

		"""
		advance to next word
		"""
		cursor += 2


	return bytes


if __name__ == "__main__":
	packed = bytearray(binascii.unhexlify("010040000101DA00810002018900020081000302890001030D1B00820004010604565683000401080102000A0202000E40000A0201000E4000090202000D1B00545656465C564F56598F56545606515A565E5653525256545754465F576656DC565752598F56545600515A565C5652525356545746465F576656DC565752598F5654574E465C576756598F565457724654547046D75652575F575456DC565754598F5654557C465C556E56598F56545578465E525756DC565552598F5654560E515A565C5652525556545766465F576656DC565752598F56A8A9"))

	unpacked = unpack(packed)

	print binascii.hexlify(str(unpacked))