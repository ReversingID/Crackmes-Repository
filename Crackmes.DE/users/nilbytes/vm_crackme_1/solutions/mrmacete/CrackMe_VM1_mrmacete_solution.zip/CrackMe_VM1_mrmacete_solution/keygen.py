import random

def itoa(num):
	return num + 48

def keygen(username):

	if len(username) < 4:
		return "INVALID USERNAME"

	"""
	Build a char table to store possible chars for the password.
	I choose to use only ascii digits because some of the constraints assume it, 
	but in fact any printable 8-bit value it's ok for all unconstrained positions.
	"""
	numchars = range(48,58)


	"""
	Constraint 1:
	password must be composed by exacly 25 chars.
	let's initialize it at random.
	"""
	pw = [ random.choice(numchars) for i in range(25) ]


	"""
	Constraint 2:
	pw[0] depends on username length
	"""
	pw[0] = itoa((len(username) % 8) | 4)

	
	"""
	Constraint 3:
	pw[7] depends on username[2]
	"""
	pw[7] = itoa((ord(username[2]) % 10) & 5)


	"""
	Constraint 4:
	pw[11] must be equal to ascii digit '1'
	"""
	pw[11] = itoa(1)


	"""
	Constraint 5:
	pw[18] depends on pw[17]
	"""
	pw[18] = pw[17] - 2


	"""
	Constraint 6:
	pw[20] must be equal to ascii digit '8'
	"""
	pw[20] = itoa(8)


	"""
	Constraint 7:
	pw[22] depends on pw[17]
	"""
	pw[22] = pw[17] + 1

	
	"""
	Constraint 8:
	pw[7] depends on username[3]
	"""
	pw[23] = itoa((ord(username[3]) % 10) & 3)


	"""
	back to printable string
	"""
	return "".join([chr(x) for x in pw])

if __name__ == "__main__":
	
	"""
	replace "porcodio" with your preferred username
	"""
	print keygen("porcodio")
	