import binascii

"""
attempt to parse an instruction at given start address
from the bytes array (which contains bytecode)
"""
def parse_bytes(bytes, start):
	opcode = bytes[start]
	
	addr = start
	start += 1
	instr = "INVALID"
	error = False

	if opcode == 0xfe:
		instr = "WIN"
	elif opcode == 0xff:
		instr = "LOOSE"
	else:
		fcode = opcode & 0x7f

		if fcode <= 0x7d:

			mode = (fcode + 0x82) & 0xff
			if mode >= 2:
				mode = opcode >> 7

			instrcode = fcode - 1

			if instrcode > 0xe:
				# not in the range, skip as data
				instr = "db {0}".format(opcode)
			else:

				# figure out the instruction length
				ilen = 3
				if instrcode >= 12:
					ilen = 2

				# pass through the "big switch" decoder
				instr = decode_instruction(instrcode, opcode, mode, bytes[start:start+ilen])

				# advance to next instruction
				start += ilen

				if instr == "INVALID":
					# decoder failed
					print "unknown instr code {0}".format(instrcode)
					error = True

	if instr == "INVALID":
		# invalid opcode, no way to interpret this
		print "unknown opcode {0}".format(opcode)
		error = True

	return (start, "{2}    \t{0} \t{1}".format(hex(opcode), instr, addr), error)


def decode_instruction(instrcode, opcode, mode, bytes):
	
	if instrcode == 0:
		return decode_4bytes("mov", mode, bytes)
	elif instrcode == 1:
		return decode_4bytes_rptr("mov", mode, bytes)
	elif instrcode == 2:
		return decode_4bytes_lptr("mov", mode, bytes)
	elif instrcode == 3:
		return decode_4bytes("and", mode, bytes)
	elif instrcode == 4:
		return decode_4bytes("or", mode, bytes)
	elif instrcode == 5:
		return decode_4bytes("xor", mode, bytes)
	elif instrcode == 6:
		return decode_4bytes("not", mode, bytes)
	elif instrcode == 7:
		return decode_4bytes("add", mode, bytes)
	elif instrcode == 8:
		return decode_4bytes("sub", mode, bytes)
	elif instrcode == 9:
		return decode_4bytes("cmp", mode, bytes)
	elif instrcode == 10:
		return decode_4bytes("mul", mode, bytes)
	elif instrcode == 11:
		return decode_4bytes("div", mode, bytes)
	elif instrcode == 12:
		return decode_3bytes("jmp", mode, bytes)
	elif instrcode == 13:
		return decode_3bytes("jz", mode, bytes)
	elif instrcode == 14:
		return decode_3bytes("jnz", mode, bytes)


	return "INVALID"

def decode_4bytes(mnemonic, mode, bytes):
	if mode == 0:
		r = bytes[0]
		const = render_int16(bytes[1:3])
		return "{0} r{1}, {2}".format(mnemonic, r, const)
	elif mode == 1:
		r = bytes[1]
		r2 = bytes[2]
		return "{0} r{1}, r{2}".format(mnemonic, r, r2)

def decode_4bytes_lptr(mnemonic, mode, bytes):
	if mode == 0:
		r = bytes[0]
		const = render_int16(bytes[1:3])
		return "{0} word[r{1}], {2}".format(mnemonic, r, const)
	elif mode == 1:
		r = bytes[1]
		r2 = bytes[2]
		return "{0} word[r{1}], r{2}".format(mnemonic, r, r2)

def decode_4bytes_rptr(mnemonic, mode, bytes):
	if mode == 0:
		r = bytes[0]
		const = render_int16(bytes[1:3])
		return "{0} r{1}, word[{2}]".format(mnemonic, r, const)
	elif mode == 1:
		r = bytes[1]
		r2 = bytes[2]
		return "{0} r{1}, word[r{2}]".format(mnemonic, r, r2)

def decode_3bytes(mnemonic, mode, bytes):
	if mode == 0:
		addr = render_int16(bytes)
		return "{0} {1}".format(mnemonic, addr)
	elif mode == 1:
		return "{0} r{1}".format(mnemonic, bytes[1])
	

def render_int16(bytes):
	return bytes[0] + (bytes[1] << 8)

if __name__ == "__main__":
	
	#original
	#exe = bytearray(binascii.unhexlify("010040000101DA00810002018900020081000302890001030D1B00820004010604565683000401080102000A0202000E40000A0201000E4000090202000D1B00545656465C564F56598F56545606515A565E5653525256545754465F576656DC565752598F56545600515A565C5652525356545746465F576656DC565752598F5654574E465C576756598F565457724654547046D75652575F575456DC565754598F5654557C465C556E56598F56545578465E525756DC565552598F5654560E515A565C5652525556545766465F576656DC565752598F56A8A9"))
	
	#unpacked
	exe = bytearray(binascii.unhexlify("010040000101da00810002018900020081000302890001030d1b00820004010604565683000401080102000a0202000e40000a0201000e4000090202000d1b00020000100a0019000fd900020050070c0008000504040002010210090130008a0001040fd900020056070c000a000404050002011010090130008a0001040fd900020118100a0131000fd900020124100202261081000401090102008a0001020fd90002032a100a0338000fd90002032e10080401008a0003040fd900020058070c000a000404030002013010090130008a0001040fd900feff"))
	cursor = 0
	error = False

	while cursor < len(exe) and not error:

		cursor, instr, error = parse_bytes(exe, cursor)
		print "\t" + instr