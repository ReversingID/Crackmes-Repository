// KeygenDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Keygen.h"
#include "KeygenDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CKeygenDlg dialog

CKeygenDlg::CKeygenDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CKeygenDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CKeygenDlg)
	m_sName = _T("");
	m_sSerial = _T("");
	m_sNumber = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CKeygenDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CKeygenDlg)
	DDX_Control(pDX, IDC_BGENERATE, m_ctlGenerate);
	DDX_Control(pDX, IDC_ENAME, m_ctlName);
	DDX_Text(pDX, IDC_ENAME, m_sName);
	DDV_MaxChars(pDX, m_sName, 33);
	DDX_Text(pDX, IDC_ESERIAL, m_sSerial);
	DDV_MaxChars(pDX, m_sSerial, 16);
	DDX_Text(pDX, IDC_ENUMBER, m_sNumber);
	DDV_MaxChars(pDX, m_sNumber, 14);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CKeygenDlg, CDialog)
	//{{AFX_MSG_MAP(CKeygenDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BEXIT, OnBexit)
	ON_EN_CHANGE(IDC_ENAME, OnChangeEname)
	ON_BN_CLICKED(IDC_BGENERATE, OnBgenerate)
	ON_EN_CHANGE(IDC_ESERIAL, OnChangeEserial)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CKeygenDlg message handlers

BOOL CKeygenDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	UpdateData(true);
	m_sNumber = "KKVJ-EDQI-3CVU";

	CRegKey hRegKey;
	DWORD dwKey = 0, dwSiteID = 536873901;
	TCHAR szBuff[16] = {0};
	DWORD dwSize = sizeof(szBuff)/sizeof(szBuff[0]);
	TCHAR szPath1[] = _T("Software\\Keygeme078\\");
	TCHAR szPath2[] = _T("Software\\Keygeme078\\Key\\");
	CString sIDKEY = "", sNewIDKey ="12345-7890ABCD";
	unsigned char cTemp = 0;

	//Create or open
	if (hRegKey.Create(HKEY_CURRENT_USER, szPath1) != ERROR_SUCCESS)
	{
		AfxMessageBox("Registry Error!",0,0);
	}
	
	//Create or open
	if (hRegKey.Create(HKEY_CURRENT_USER, szPath2) != ERROR_SUCCESS)
	{
		AfxMessageBox("Registry Error!",0,0);
	}
	
	//Read SiteID
	if (hRegKey.QueryValue(dwKey, TEXT("Key")) == ERROR_SUCCESS)
	{
		if (dwKey == dwSiteID)
		{
			//SiteID ok
			//Read Key
			if (hRegKey.QueryValue(szBuff, TEXT("IDKEY"), &dwSize) == ERROR_SUCCESS)
			{
				sIDKEY = szBuff;
				//Treat Key
				for (int i = 0; i < 14; i++)
				{
					cTemp = sIDKEY.GetAt(i);
					cTemp = cTemp ^ 21554;
					cTemp += 2;
					cTemp = cTemp ^ 30;
					sIDKEY.SetAt(i, cTemp);
				}
			}
			else
			{
				AfxMessageBox("No IDKEY Value to Read",0,0);
			}
		}
		else
		{
			//Different SiteID
			//Write SiteId to Register
			if(hRegKey.SetValue(dwSiteID, "Key") != ERROR_SUCCESS)
			{
				AfxMessageBox("Registry Error!",0,0);
			}
		}
		//
	}
	else
	{
		//No SiteID
		AfxMessageBox("First Time\nGenerating Personal IDKEY",0,0);
		//Write SiteId to Register
		if(hRegKey.SetValue(dwSiteID, "Key") != ERROR_SUCCESS)
		{
			AfxMessageBox("Registry Error!",0,0);
		}
	}

	m_sNumber = sIDKEY;
	RegCloseKey(hRegKey);
	UpdateData(false);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CKeygenDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CKeygenDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CKeygenDlg::OnBexit() 
{
	OnOK();	
}

void CKeygenDlg::OnChangeEname() 
{
}

void CKeygenDlg::OnChangeEserial() 
{
	int iLength = 0;

	UpdateData(true);
	iLength = m_sSerial.GetLength();

	if	(iLength == 16)
	{
		m_ctlGenerate.EnableWindow(true);
	}
	else
	{
		m_ctlGenerate.EnableWindow(false);
	}

	UpdateData(false);
}

void CKeygenDlg::OnBgenerate() 
{
	//This is a real working keygenme source
	UpdateData(true);

	bool bValid = true;
	CString sSerial = m_sSerial, sSerialP1 = "12345678", sSerialP2 = "90ABCDEF", sName ="TiGa";
	unsigned char cSerialP1[8] = {0}, cSerialP2[8] = {0}, cIdNumber[8] = {0},
		cTemp[4] = {0}, cTemp1[4] = {0}, cTemp2[4] = {0}, cBackup = 0;
	unsigned int iPart1 = 0, iPart2 = 0, iPart3 = 0, iPart4 = 0, iPart5 = 0, iPart6 = 0,
		iPart7 = 0, iPart8 = 0, iPart9 = 0, iTemp1 = 0, iTemp2 = 0, iTempx = 0;

	if (m_sName.GetLength() >= 4)
		sName = m_sName;
	
	for (int i = 0; i < 16; i++)
		if (!(((sSerial.GetAt(i) >= '0') && (sSerial.GetAt(i) <= '9')) || ((sSerial.GetAt(i) >= 'A') && (sSerial.GetAt(i) <= 'Z')) || ((sSerial.GetAt(i) >= 'a') && (sSerial.GetAt(i) <= 'z'))))
			bValid = false;

	if (!bValid)//not really true but true after all anyway IYKWIM
		AfxMessageBox("Only alphanumeric range characters allowed (0-9 to A-z)\nCase sensitive too!",0,0);
	else
	{
//Prepare
		for (i = 0; i < 8; i++)
		{
			//Getting base value
			cSerialP1[i] = (sSerial.GetAt(i) - 48);
			cSerialP2[i] = (sSerial.GetAt(i+8) - 48);
			
			//Adjusting Alpha value
			if (cSerialP1[i] > 9)
				cSerialP1[i] -= 7;
			if (cSerialP2[i] > 9)
				cSerialP2[i] -= 7;

			//Adjusting for some chars
			if (i % 2)
			{
				cSerialP1[i-1] = cSerialP1[i-1] << 4;
				cSerialP1[i-1] = cSerialP1[i-1] | cSerialP1[i];
				cSerialP1[i] = cSerialP1[i-1] % 16;
				cSerialP1[i-1] /= 16;
				cSerialP2[i-1] = cSerialP2[i-1] << 4;
				cSerialP2[i-1] = cSerialP2[i-1] | cSerialP2[i];
				cSerialP2[i] = cSerialP2[i-1] % 16;
				cSerialP2[i-1] /= 16;
			}
		}

		for (i = 3; i >= 0; i--)
		{
			//Translating and bswapping
			iPart1 *= 16;
			iPart1 += cSerialP1[i*2];
			iPart1 *= 16;
			iPart1 += cSerialP1[(i*2)+1];
			iPart2 *= 16;
			iPart2 += cSerialP2[i*2];
			iPart2 *= 16;
			iPart2 += cSerialP2[(i*2)+1];
		}

//LoopSerial1
		for (i = 0; i != 2003; i++)
		{
			iPart1 = iPart1 ^ 2003;
			//iTemp1 = iTemp1 ^ 2003;
			
			//eax <-> ebx
			iTempx = iPart2;
			iPart2 = iPart1;
			iPart1 = iTempx;

			//iTemp2--;

			//ecx <-> edx
			//iTempx = iTemp1;
			//iTemp1 = iTemp2;
			//iTemp2 = iTempx;

			iPart2++;

			//lazy bswap eax ;p
			__asm
			{
				mov eax,iPart1
				bswap eax
				mov iPart1,eax
			}
		}

//LoopID
		for (i = 0; i < 8; i++)
			cIdNumber[i] = m_sNumber.GetAt(i);
		
		iTemp2 = 0;

		for (i = 0; i < 8; i++)
		{
			if (i < 4)
			{
				iTemp1 = cIdNumber[i] + i;
				iTemp2 += iTemp1 ;
				iTemp2 += cIdNumber[i];
				cTemp[i] = iTemp2;
				iPart3 *= 16;
				iPart3 *= 16;
				iPart3 += cTemp[i];
			}
			else
			{
				iTemp1 = cIdNumber[i] + i;
				iTemp2 += iTemp1 ;
				iTemp2 += cIdNumber[i];
				cTemp[i-4] = iTemp2;
				iPart9 *= 16;
				iPart9 *= 16;
				iPart9 += cTemp[i-4];

			}
		}

		//need bswap
		__asm
		{
			mov		eax,iPart3
			bswap	eax
			mov		iPart3,eax
			mov		eax,iPart9
			bswap	eax
			mov		iPart9,eax
		}

//LoopName
		iPart4 = iPart3;
		iTemp2 = 0;
		for (i = 0; i < 4; i++)
		{
			iTemp1 = iPart4 + i;
			iTemp2 += (iTemp1 % 256) + sName.GetAt(i) + 3;
			iTemp2 += cIdNumber[i];
			cTemp[i] = iTemp2;
			for (int j = 0; j < 4; j++)
			{
				iPart4 *= 16;
				iPart4 *= 16;
				iPart4 += cTemp[j];
			}
			
			//bswap
			__asm
			{
				mov		eax,iPart4
				bswap	eax
				mov		iPart4,eax
			}
		}

//LoopSerial2
		iTemp1 = iPart1;
		iTemp2 = iPart2;
		for (i = 0; i < 4; i++)
		{
			iTempx = 256;
			for (int k = 0; k < i; k++)
				iTempx *= 256;
			if (iTemp1 > 256)
			{
				cTemp1[i] = (iTemp1 % iTempx);
				cTemp2[i] = (iTemp2 % iTempx);
			}
			else
			{
				cTemp1[i] = iTemp1;
				cTemp2[i] = iTemp2;
			}
			iTemp1 -= cTemp1[i];
			iTemp2 -= cTemp2[i];
			//Lookup table
			cTemp1[i] = 255 - cTemp1[i];
			cTemp2[i] = 255 - cTemp2[i];
			//not eax = xor eax,255
			cTemp1[i] = cTemp1[i] ^ 255;
			cTemp2[i] = cTemp2[i] ^ 255;
			//xor eax 3
			cTemp1[i] = cTemp1[i] ^ 3;
			cTemp2[i] = cTemp2[i] ^ 3;
			if (iTemp1)
			{
				iTemp1 = iTemp1 / 16;
				iTemp1 = iTemp1 / 16;
			}
			if (iTemp2)
			{
				iTemp2 = iTemp2 / 16;
				iTemp2 = iTemp2 / 16;
			}

			iPart5 *= 16;
			iPart5 *= 16;
			iPart5 += cTemp1[i];
			iPart6 *= 16;
			iPart6 *= 16;
			iPart6 += cTemp2[i];
		}
		cBackup = cTemp1[0];

/*		__asm
		{
			mov		eax,iPart5
			bswap	eax
			mov		iPart5,eax
		}
*/
//LoopSerial3
		iTemp1 = iPart5;
		iTemp2 = iPart6;
		for (i = 0; i < 4; i++)
		{
			iTempx = 256;
			for (int k = 0; k < i; k++)
				iTempx *= 256;
			if (iTemp1 > 256)
			{
				cTemp1[i] = (iTemp1 % iTempx);
				cTemp2[i] = (iTemp2 % iTempx);
			}
			else
			{
				cTemp1[i] = iTemp1;
				cTemp2[i] = iTemp2;
			}
			iTemp1 -= cTemp1[i];
			iTemp2 -= cTemp2[i];
			//Lookup table
			cTemp1[i] = 255 - cTemp1[i];
			cTemp2[i] = 255 - cTemp2[i];
			//xor 2
			cTemp1[i] = cTemp1[i] ^ 2;
			cTemp2[i] = cTemp2[i] ^ 2;
			if (iTemp1)
			{
				iTemp1 /= 16;
				iTemp1 /= 16;
			}
			if (iTemp2)
			{
				iTemp2 /= 16;
				iTemp2 /= 16;
			}
			iPart7 *= 16;
			iPart7 *= 16;
			cTemp1[3] = cBackup;
			iPart7 += cTemp1[i];
			iPart8 *= 16;
			iPart8 *= 16;
			iPart8 += cTemp2[i];
		}

//FinalComparison

		if ((iPart4 == iPart7) && (iPart8 == iPart9))
			AfxMessageBox("Yeah!", 0,0);

		// what's really going on
		//
		// ID -> 3
		// Name -> 4
		// 3 -> 4
		// 4 = 7
		// 7 -> 5
		// 1 -> pwd1
		//
		// ID -> 9
		// 8 = 9
		// 8 -> 6
		// 6 -> 2
		// 2 -> pwd2 (always the same)

		m_sName.Format("%x", iPart7);
		//m_sName.Format("%x-%x-%x-%x", cTemp[0], cTemp[1], cTemp[2], cTemp[3]);
		UpdateData(false);
	}
}

