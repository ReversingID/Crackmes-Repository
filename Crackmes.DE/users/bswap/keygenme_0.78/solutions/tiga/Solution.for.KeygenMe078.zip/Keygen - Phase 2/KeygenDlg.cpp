// KeygenDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Keygen.h"
#include "KeygenDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CKeygenDlg dialog

CKeygenDlg::CKeygenDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CKeygenDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CKeygenDlg)
	m_sName = _T("");
	m_sSerial = _T("");
	m_sNumber = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CKeygenDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CKeygenDlg)
	DDX_Control(pDX, IDC_BGENERATE, m_ctlGenerate);
	DDX_Control(pDX, IDC_ENAME, m_ctlName);
	DDX_Text(pDX, IDC_ENAME, m_sName);
	DDV_MaxChars(pDX, m_sName, 16);
	DDX_Text(pDX, IDC_ESERIAL, m_sSerial);
	DDV_MaxChars(pDX, m_sSerial, 16);
	DDX_Text(pDX, IDC_ENUMBER, m_sNumber);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CKeygenDlg, CDialog)
	//{{AFX_MSG_MAP(CKeygenDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BEXIT, OnBexit)
	ON_EN_CHANGE(IDC_ENAME, OnChangeEname)
	ON_BN_CLICKED(IDC_BGENERATE, OnBgenerate)
	ON_EN_CHANGE(IDC_ESERIAL, OnChangeEserial)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CKeygenDlg message handlers

BOOL CKeygenDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	UpdateData(true);

	CRegKey hRegKey;
	srand((unsigned)time(NULL));
	DWORD dwKey = 0, dwSiteID = 536873901;
	TCHAR szBuff[16] = {0};
	DWORD dwSize = sizeof(szBuff)/sizeof(szBuff[0]);
	TCHAR szPath1[] = _T("Software\\Keygeme078\\");
	TCHAR szPath2[] = _T("Software\\Keygeme078\\Key\\");
	CString sIDKEY = "12345-7890ABCD", sNewIDKey ="12345-7890ABCD";
	unsigned char cTemp = 0;

	//Calculate IDKEY if none
	for (int i = 0; i < 14; i++)
	{
		cTemp = (rand() % 36);
		if (cTemp > 9)
			cTemp += 55;
		if (cTemp <=9)
			cTemp += 48;
		if ((i == 4) || (i == 9))
			cTemp = '-';
		if (i == 10)
			cTemp = '3';
		if (i > 10)
			cTemp = 'X';
		sIDKEY.SetAt(i, cTemp);
		cTemp = cTemp ^ 30;
		cTemp -= 2;
		cTemp = cTemp ^ 21554;
		sNewIDKey.SetAt(i, cTemp);
	}

	//Create or open
	if (hRegKey.Create(HKEY_CURRENT_USER, szPath1) != ERROR_SUCCESS)
	{
		AfxMessageBox("Registry Error!",0,0);
		m_sNumber = "PLEASE RUN THE CRACKME FIRST";
	}
	
	//Create or open
	if (hRegKey.Create(HKEY_CURRENT_USER, szPath2) != ERROR_SUCCESS)
		AfxMessageBox("Registry Error!",0,0);
	
	//Read SiteID
	if (hRegKey.QueryValue(dwKey, TEXT("Key")) == ERROR_SUCCESS)
	{
		if (dwKey == dwSiteID)
		{
			//SiteID ok
			//Read IDKEY
			if (hRegKey.QueryValue(szBuff, TEXT("IDKEY"), &dwSize) == ERROR_SUCCESS)
			{
				sIDKEY = szBuff;
				//Treat IDKEY
				for (int i = 0; i < 14; i++)
				{
					cTemp = sIDKEY.GetAt(i);
					cTemp = cTemp ^ 21554;
					cTemp += 2;
					cTemp = cTemp ^ 30;
					sIDKEY.SetAt(i, cTemp);
					m_sNumber = sIDKEY;
				}
			}
			else
			{
				//Write IDKEY
				if(hRegKey.SetValue(sNewIDKey, "IDKEY") == ERROR_SUCCESS)
				{
					m_sNumber = sIDKEY;
				}
				else
				{
					AfxMessageBox("Registry Error!",0,0);
					m_sNumber = "PLEASE RUN THE CRACKME FIRST";
				}
			}
		}
		else
		{
			//Different SiteID
			//Write SiteId to Registry
			if(hRegKey.SetValue(dwSiteID, "Key") != ERROR_SUCCESS)
			{
				AfxMessageBox("Registry Error!",0,0);
				m_sNumber = "PLEASE RUN THE CRACKME FIRST";
			}
			if (hRegKey.QueryValue(szBuff, TEXT("IDKEY"), &dwSize) == ERROR_SUCCESS)
			{
				sIDKEY = szBuff;
				//Treat Key
				for (int i = 0; i < 14; i++)
				{
					cTemp = sIDKEY.GetAt(i);
					cTemp = cTemp ^ 21554;
					cTemp += 2;
					cTemp = cTemp ^ 30;
					sIDKEY.SetAt(i, cTemp);
					m_sNumber = sIDKEY;
				}
			}
			else
			{
				//Write IDKEY
				if(hRegKey.SetValue(sNewIDKey, "IDKEY") == ERROR_SUCCESS)
				{
					m_sNumber = sIDKEY;
				}
				else
				{
					AfxMessageBox("Registry Error!",0,0);
					m_sNumber = "PLEASE RUN THE CRACKME FIRST";
				}
			}
		}

	}
	else
	{
		//No SiteID
		//Write Key
		if(hRegKey.SetValue(dwSiteID, "Key") == ERROR_SUCCESS)
		{
			//Write IDKEY
			if (hRegKey.QueryValue(szBuff, TEXT("IDKEY"), &dwSize) == ERROR_SUCCESS)
			{
				sIDKEY = szBuff;
				//Treat Key
				for (int i = 0; i < 14; i++)
				{
					cTemp = sIDKEY.GetAt(i);
					cTemp = cTemp ^ 21554;
					cTemp += 2;
					cTemp = cTemp ^ 30;
					sIDKEY.SetAt(i, cTemp);
					m_sNumber = sIDKEY;
				}
			}
			else
			{
				//Write IDKEY
				if(hRegKey.SetValue(sNewIDKey, "IDKEY") == ERROR_SUCCESS)
				{
					m_sNumber = sIDKEY;
				}
				else
				{
					AfxMessageBox("Registry Error!",0,0);
					m_sNumber = "PLEASE RUN THE CRACKME FIRST";
				}
			}
		}
		else
		{
			AfxMessageBox("Registry Error!",0,0);
			m_sNumber = "PLEASE RUN THE CRACKME FIRST";
		}
	}
	hRegKey.Close();

	if (m_sNumber == "PLEASE RUN THE CRACKME FIRST")
		m_ctlName.EnableWindow(false);

	UpdateData(false);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CKeygenDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CKeygenDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CKeygenDlg::OnBexit() 
{
	OnOK();	
}

void CKeygenDlg::OnChangeEname() 
{
	int iLength = 0;

	UpdateData(true);
	iLength = m_sName.GetLength();

	if	(iLength > 3)
	{
		m_ctlGenerate.EnableWindow(true);
	}
	else
	{
		m_ctlGenerate.EnableWindow(false);
	}


	UpdateData(false);
}

void CKeygenDlg::OnChangeEserial() 
{
}

void CKeygenDlg::OnBgenerate() 
{
	UpdateData(true);

	//Recheck IDKEY
	CRegKey hRegKey;
	TCHAR szBuff[16] = {0};
	DWORD dwSize = sizeof(szBuff)/sizeof(szBuff[0]);
	TCHAR szPath[] = _T("Software\\Keygeme078\\Key\\");
	CString sIDKEY = "", sNewIDKey ="12345-7890ABCD";
	unsigned char cTemp = 0;


	if (hRegKey.Create(HKEY_CURRENT_USER, szPath) == ERROR_SUCCESS)
	{
		if (hRegKey.QueryValue(szBuff, TEXT("IDKEY"), &dwSize) == ERROR_SUCCESS)
		{
			sIDKEY = szBuff;
			//Treat Key
			for (int i = 0; i < 14; i++)
			{
				cTemp = sIDKEY.GetAt(i);
				cTemp = cTemp ^ 21554;
				cTemp += 2;
				cTemp = cTemp ^ 30;
				sIDKEY.SetAt(i, cTemp);
				m_sNumber = sIDKEY;
			}
		}
		else
		{
			m_sNumber = "NO IDKEY FOUND!";
			AfxMessageBox("Registry Error!",0,0);
		}
	}
	else
		AfxMessageBox("Registry Error!",0,0);
	hRegKey.Close();
	
	CString sName = m_sName, sPart1 = "", sPart2 = "", sSerial = "----------------";
	unsigned char cIdNumber[8] = {0}, cTemp1[4] = {0}, cTemp2[4] = {0}, cPart1[8] = {0}, cPart2[8] = {0};
	unsigned int iTemp1 = 0, iTemp2 = 0, iTempx = 0, iBackup = 0,
		iResultID = 0, iResultName = 0, iResult1 = 0, iResult2 = 0, iResultCheck = 0,
		iNewResult1 = 0, iNewResult2 = 0, iOriginal1 = 0, iOriginal2 = 0;
	

//LoopIDKEY from registry
	for (int i = 0; i < 8; i++)
		cIdNumber[i] = m_sNumber.GetAt(i);

	for (i = 0; i < 8; i++)
	{
		if (i<4)
		{
			iTemp1 = cIdNumber[i] + i;
			iTemp2 += iTemp1 ;
			iTemp2 += cIdNumber[i];
			cTemp1[i] = iTemp2;
			iResultID <<= 8;
			iResultID += cTemp1[i];
		}
		else
		{
			//Calculate (not constant after all)
			iTemp1 = cIdNumber[i] + i;
			iTemp2 += iTemp1 ;
			iTemp2 += cIdNumber[i];
			cTemp1[i-4] = iTemp2;
			iResultCheck <<= 8;
			iResultCheck += cTemp1[i-4];
		}
	}
	
	//need bswap
	__asm
	{
		mov		eax,iResultID
		bswap	eax
		mov		iResultID,eax
		mov		eax,iResultCheck
		bswap	eax
		mov		iResultCheck,eax
	}

//LoopName from textbox
	iResultName = iResultID;
	iTemp2 = 0;
	for (i = 0; i < 4; i++)
	{
		iTemp1 = iResultName + i;
		iTemp2 += (iTemp1 % 256) + sName.GetAt(i) + 3;
		iTemp2 += cIdNumber[i];
		cTemp1[i] = iTemp2;
		for (int j = 0; j < 4; j++)
		{
			iResultName <<= 8;
			iResultName += cTemp1[j];
		}

		//need bswap
		__asm
		{
			mov		eax,iResultName
			bswap	eax
			mov		iResultName,eax
		}
	}

//Breakdown1
	//Final comparison values
	iResult1 = iResultName;//changes with name
	iResult2 = iResultCheck;//changes with IDKEY
	//Tweak
	iBackup = iResult1 % 256;
	
	for (i = 0; i < 4; i++)
	{
		cTemp1[i] = iResult1 % 256;
		cTemp2[i] = iResult2 % 256;
		iResult1 -= cTemp1[i];
		iResult2 -= cTemp2[i];
		iResult1 >>= 8;
		iResult2 >>= 8;
		//xor 2
		cTemp1[i] ^= 2;
		cTemp2[i] ^= 2;
		//Lookup table (simplified)
		cTemp1[i] = 255 - cTemp1[i];
		cTemp2[i] = 255 - cTemp2[i];
		iNewResult1 <<= 8;
		//Tweak
		cTemp1[0] = iBackup;
		iNewResult1 += cTemp1[i];
		iNewResult2 <<= 8;
		iNewResult2 += cTemp2[i];
	}

//Breakdown2
	for (i = 0; i < 4; i++)
	{
		cTemp1[i] = iNewResult1 % 256;
		cTemp2[i] = iNewResult2 % 256;
		iNewResult1 -= cTemp1[i];
		iNewResult2 -= cTemp2[i];
		iNewResult1 >>= 8;
		iNewResult2 >>= 8;
		//xor 3
		cTemp1[i] ^= 3;
		cTemp2[i] ^= 3;
		//not = xor 255 (boolean algebra)
		cTemp1[i] ^= 255;
		cTemp2[i] ^= 255;
		//Lookup table (simplified)
		cTemp1[i] = 255 - cTemp1[i];
		cTemp2[i] = 255 - cTemp2[i];
		iResult1 <<= 8;
		iResult1 += cTemp1[i];
		iResult2 <<= 8;
		iResult2 += cTemp2[i];
	}

//Get Original values
	for (i = 2003; i != 0; i--)
	{
		//lazy bswap eax ;P
		__asm
		{
			mov		eax,iResult1
			bswap	eax
			mov		iResult1,eax
		}
		iResult2--;
		//eax <-> ebx; xchng
		iTempx = iResult1;
		iResult1 = iResult2;
		iResult2 = iTempx;
		//xor 2003
		iResult1 ^= 2003;
	}
	iOriginal1 = iResult1;
	iOriginal2 = iResult2;

//bswapping and expanding original values
	__asm
	{
		mov		eax,iOriginal1
		bswap	eax
		mov		iOriginal1,eax
		mov		eax,iOriginal2
		bswap	eax
		mov		iOriginal2,eax
	}
	
	//Translating to displayable chars
	for (i = 0; i < 8; i++)
	{
		cPart1[7-i] = iOriginal1 % 16;
		cPart2[7-i] = iOriginal2 % 16;
		if (cPart1[7-i] > 9)
			cPart1[7-i] += 7;
		if (cPart2[7-i] > 9)
			cPart2[7-i] += 7;
		cPart1[7-i] += 48;
		cPart2[7-i] += 48;
		iOriginal1 >>= 4;
		iOriginal2 >>= 4;
	}
	//Export to string
	for (i = 0; i < 8; i++)
	{
		sSerial.SetAt(i, cPart1[i]);
		sSerial.SetAt(i+8, cPart2[i]);
	}

	//Show result
	if (m_sNumber == "NO IDKEY FOUND!")
		m_sSerial = "NO IDKEY FOUND!";
	else
		m_sSerial = sSerial;
	UpdateData(false);
}

