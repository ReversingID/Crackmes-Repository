Keygenme, Key State 0.85 (The Riddle) notes,
 
Goal: Try to find the right combination to make the notice say 
"Registered".  When you are able to find one possibility, you know
how it works and writing a key generator would be easy for you.
The program it packed but not really protected.  
Difficulty about (3/10).

Once again I have done it, writing a good working and original keygenme.
The meaning of it, you have 24 check boxes, mark a few and click on �register�.
When you have made a good combination you will be registered. Sounds easy ;)

For the people who think they understand my knowledge, I have made one specified code.
It will release a unlock code for the source! Have a nice time with it. 
   
And the usual disclaimer:
Whatever happens when you running this program, 
I'm not responsible for anything.  
  
If you have any comment or questions please mail,

goodwill80@hotmail.com

I want to greet everyone who knows me.

Cybult , Blue Mind, Detten , Tomkol , ^L00P , Kwasek, ShadowKat,
Harlequin, Thigo, Roy, muaddib and Zero.

Bswap.
Holland - 2003

You got this from http://www.crackmes.de/