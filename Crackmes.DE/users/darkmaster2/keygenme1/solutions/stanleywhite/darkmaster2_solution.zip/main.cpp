/*
			Keygen for Darkmasters keygenME

         Reversed & Coded by Stanley White 2003 

*/

#include <windows.h>
#include "resource.h"
#include "control.h"

BOOL CALLBACK MainDlgProc(HWND hwnd,UINT Message, WPARAM wParam, LPARAM lParam);

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
    DialogBox (GetModuleHandle(NULL), MAKEINTRESOURCE(ID_DIALOG_MAIN), NULL, MainDlgProc);
    return 0;
} 

BOOL CALLBACK MainDlgProc(HWND hwnd,UINT Message, WPARAM wParam, LPARAM lParam)
{
    switch(Message)
    {
        case WM_INITDIALOG:
          break;
        case WM_COMMAND:
          switch(LOWORD(wParam))
          {
            case ID_ABOUT:
             MessageBox(hwnd, "Keygen for Darkmasters KeygenMe#1\n\nReversed by : Stanley White",
                                     "INFO", MB_OK);
             break;
             
            case ID_GEN:
             DWORD time=GetTickCount();   // Get random value
             time ^= 0xC0DEDEAD;          // make sure it gets has 4 bytes
             itoa(time, serial, 16);      // int to ASCII string
             calculate();
             SetDlgItemText(hwnd, IDC_EDIT1, serial);
             break;
          }
          break;
        case WM_CLOSE:
          EndDialog(hwnd, 0);
          break;
        case WM_DESTROY:
          PostQuitMessage(0);
          break;
        default:
          return FALSE;
    }
    return TRUE;
}

