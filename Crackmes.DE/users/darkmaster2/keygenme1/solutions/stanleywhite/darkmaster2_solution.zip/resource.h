#define ID_DIALOG_MAIN 100
#define ID_GEN 101
#define ID_ABOUT 102
#define IDC_EDIT1 103
#define IDC_STATIC 103
