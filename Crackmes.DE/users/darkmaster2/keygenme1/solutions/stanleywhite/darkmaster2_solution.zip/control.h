char serial[8];             // our serial

int calc(void)
{
    int serialValue=0;
    for (int i=0; i<8; i++)                      // add the 8 chars
    {
        char serialChar=serial[i];
        serialValue += (int) serialChar;
    }
    int serValue=serialValue;
    serValue <<= 1;                              // *2
    serValue ^= serialValue;                     // xor 
    
    char buffer[10];
    for (int i=0; i<9; i++)
        buffer[i]=0;
        
    itoa(serValue, buffer, 10);                  // convert int to decimal string
    
    bool a=FALSE;
    int i=0;
    int dummy=0;
    serialValue=0;
    while (!a)
    {
        dummy = (int) buffer[i];
        if (dummy==0)
                a=TRUE;
        else
        {
                dummy -= 0x30;
                serialValue += dummy;
                i++;
        } 
    }
    
    return serialValue;
  
}

void calculate(void)
{
    bool a=FALSE;
    while (!a)                                  // do until valid serial found
    {
        if (calc()==20)
           a=TRUE;
        else
         serial[0]++;
        
    }
}

