#include <fstream>
#include <vector>
#include <stdio.h>
using namespace std;

int main() {
    ifstream file("deobfuscate1.exe",ios::binary);
    vector<char> code;
    ofstream target("target.exe",ios::binary);
    char ch;
    int counter=0;
    int offset;
    int cs, ip;
    int i, j;
    while(file.get(ch)&&ch!=(char)0xc3) {
        if(counter==0xa8) {
            ip=(int)ch;
            target.put(0);counter++;
            file.get(ch);
            cs=(int)ch;
            ch=(char)0x10;
            i=(cs<<8)+ip-0x1000;
        }
        target.put(ch);counter++;
    }
    do {
        code.push_back(ch);
    } while(file.get(ch));
    file.close();
    counter=0;
    while(code[i]!=(char)0xc3) {
        if(code[i]==(char)0xeb) {
            i+=(int)code[++i];
            target.put(0x90);
            target.put(0x90);counter+=2;
        } else if(code[i]==(char)0xe8) {
            target.put(code[i]);counter+=5;
            offset=0x1346-counter;
            target.put((offset&0x000000ff));
            target.put((offset&0x0000ff00)>>8);
            target.put((offset&0x00ff0000)>>16);
            target.put(offset>>24);
            i+=4;
        } else {
            target.put(code[i]);counter++;
        }
        i++;
    }
    target.put(0xc3);
    counter++;
    i=code.size()-1;
    while(code[i]==0) {
        target.put(0);counter++;
        --i;
    }
    j=code.size();
    for(i=0;i<j-counter;++i) {
        target.put(0);
    }
    target.close();
    remove("deobfuscate1.exe");
    rename("target.exe","deobfuscate1.exe");
    remove("target.exe");
    return 0;
}
