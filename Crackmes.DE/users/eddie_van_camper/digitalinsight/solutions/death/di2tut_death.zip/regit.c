/* Digital Insight Crackme 2.0 Registration programme by DEATH */
/* Very easy crackme */
#define WIN32_LEAN_AND_MEAN

/* Includes */
#include <windows.h>

/* Main programme */
int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
    ATOM atom;
    HWND hwndCrackme;
    DWORD dwPid;
    HANDLE hProcess;
    UINT uMsg;
    DWORD dwRead;

    /* Find the crackme window */
    hwndCrackme = FindWindow("AtomDlg", "Digital Insight Win32ASM CrackMe 2.0");

    if (hwndCrackme == NULL) {
        /* Error finding the window */
        MessageBox(NULL, "Cannot find crackme window", NULL, MB_OK | MB_ICONERROR);
        return(0);
    }

    /* Get Window PID */
    GetWindowThreadProcessId(hwndCrackme, &dwPid);

    /* Open the crackme process */
    hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, dwPid);

    if (hProcess == NULL) {
        /* Error opening process */
        MessageBox(NULL, "Cannot open crackme process", NULL, MB_OK | MB_ICONERROR);
        return(0);
    }

    /* Get special message value */
    ReadProcessMemory(hProcess, (LPCVOID )0x403014, (LPVOID )&uMsg, sizeof(UINT), &dwRead);

    /* We don't need the process handle anymore */
    CloseHandle(hProcess);

    /* We add a global atom "I Am Registered" (case independant) */
    atom = GlobalAddAtom("I Am Registered");

    /* Now send a message to the process window */
    SendMessage(hwndCrackme, uMsg, (WPARAM )atom, (LPARAM )0);

    /* That's it, deinitialize by deleting the atom */
    GlobalDeleteAtom(atom);

    return(0);
}
