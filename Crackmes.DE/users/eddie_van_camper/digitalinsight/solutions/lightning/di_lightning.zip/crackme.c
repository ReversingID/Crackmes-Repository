#include <windows.h>

int __stdcall WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
	ATOM RegAtom;
	long RegMsgID;
	HWND CrackMeWindow;
	
	CrackMeWindow = FindWindow("AtomDlg", "Digital Insight Win32ASM CrackMe 2.0");
	if(!CrackMeWindow)
	{
		MessageBox(NULL, "Error finding Digital Insight window", NULL, MB_OK);
		return 0;
	}

	RegMsgID = RegisterWindowMessage("RegMsg");
	if(!RegMsgID)
	{
		MessageBox(NULL, "Error registering window message", NULL, MB_OK);
		return 0;
	}

	RegAtom = GlobalAddAtom("I Am Registered");
	if(!RegAtom)
	{
		MessageBox(NULL, "Error creating Atom", NULL, MB_OK);
		return 0;
	}

	SendMessage(CrackMeWindow, RegMsgID, RegAtom, 0);

	GlobalDeleteAtom(RegAtom);

	MessageBox(NULL, "Registered Digital Insight", NULL, MB_OK);

	return 0;
}