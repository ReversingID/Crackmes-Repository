#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <time.h>
#include <math.h>
#include "resource.h"

void Decrypt(byte* dat, byte* ser)
{
	byte d0, d1, d2, s0, s1, s2, s3, tmp;
	int di, si;
	di = si = 0;
	for(int i = 0; i < 8; i++)
	{
		d0 = dat[di];
		d1 = dat[di + 1];
		d2 = dat[di + 2];

		//(ser[0] << 2 - 7D)
		for(tmp = 0; tmp < 4; tmp++)
			if(((tmp ^ d0) + 0x7D) % 4 == 0)
				break;
		s0 = ((d0 ^ tmp) + 0x7D) >> 2;


		//(~((ser[1] - 20) >> 4) & 3)
		s1 = ((~(tmp | 0xFC) << 4) + 0x20) | (d1 >> 4);
		

		//(~((ser[2] - 20) >> 2) & 0F)
		tmp = 0xF ^ (d1 & 0xF);
		s2 = ((~(tmp | 0xF0) << 2) + 0x20) | (d2 >> 6);

		
		//(~(ser[3] - 20) & 3F)
		tmp = 0x3F ^ (d2 & 0x3F);
		s3 = ~(tmp | 0xC0) + 0x20;

		ser[si]		= s0;
		ser[si + 1]	= s1;
		ser[si + 2] = s2;
		ser[si + 3] = s3;
		di += 3;
		si += 4;
	}
}

void Generate(HWND hWnd)
{
	byte a, b, c, d;
	byte ser[33], dat[24];
	memset(&ser, 0, 33);
	memset(&dat, 0, 24);
	srand(time(NULL));
	do{
		a = rand() & 0xFF;
		b = rand() & 0xFF;
		c = rand() & 0xFF;
		d = rand() & 0xFF;
	}while(sin(2 * a) + sin(2 * b) + sin(2 * c) + sin(2 * d) < 2.0 || sin(d) < 0.0 || cos(d) < 0.0);
	/*
		note that sin(d) and cos(d) must be greater or equal to 0 
		(actually sin(d) + cos(d), 2 * sin(d) and 2 * cos(d)) 
		since square root is always positive
	*/

	for(int i = 0; i < 6; i++)
	{
		dat[i * 4]		= a;
		dat[i * 4 + 1]	= b;
		dat[i * 4 + 2]	= c;
		dat[i * 4 + 3]	= d;
	}
	Decrypt(dat, ser);
	SetDlgItemText(hWnd, IDC_SERIAL, (const char*)ser);
}

static BOOL CALLBACK DlgAbout(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
		case WM_INITDIALOG:
			SetDlgItemText(hwnd, IDC_EDIT1, "2005 06 27");
			SetDlgItemText(hwnd, IDC_EDIT2, "Knight");
			SetDlgItemText(hwnd, IDC_EDIT3, "Oklahoma's KeyGen Me (oscm.exe)");
			break;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case IDOK:
					EndDialog(hwnd, 0);
					break;
			}
			break;
		default:
			return FALSE;
	}
	return true;
}

static BOOL CALLBACK DlgFunc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
		case WM_INITDIALOG:
			SendMessage(hwnd, WM_SETICON, ICON_SMALL, (LPARAM)LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1)));
			SendMessage(hwnd, WM_SETICON, ICON_BIG, (LPARAM)LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1)));
			return TRUE;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case IDC_BEXIT:
					EndDialog(hwnd, 0);
					break;
				case IDC_BABOUT:
					DialogBox(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_ABOUT), hwnd, DlgAbout);
					break;
				case IDC_BGEN:
					Generate(hwnd);
					break;
			}
			break;
		case WM_CLOSE:
			EndDialog(hwnd, 0);
		default:
			return FALSE;
	}
	return TRUE;
}

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	return DialogBox(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, DlgFunc);
}
