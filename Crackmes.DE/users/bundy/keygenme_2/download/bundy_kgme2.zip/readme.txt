Hello and welcome to my keygenme #2.

Your task is to try to write a keygen.

Well, actually you don't really have to. Just find the key for my name and you
will be able to get into the 7z file with it - where the source of this 
keygenme is, and also my own keygen (as a proof it DOES have a solution).

Then you should write a tutorial explaining what is going on in this keygenme, 
so others could learn some "simple?" tricks too :)

You may have some problems with the protection envelope I put on the keygenme.
It was tested on WinXP only and I don't think it will work on others.
As it is my own work I think it's OK to include it.

Hint: It doesn't have any anti-attach routines ;) 

Reward offered: If you will be able to get manually to the OEP and say me 
how you did it, I will send you my protection app, if you still want it 
[with ALL the bugs, of course ;) ]

Difficulty: 5/10 ?

Regards,
bundy