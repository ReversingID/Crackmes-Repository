Hi there, 

Welcome to my first Keygenme.

As usual your task is to make a keygenerator, if possible :-).
It's based on modular math or whatever it's called.

<HINT>
I though about 1024-bit long modulus, but then decided to use a 512-bit long
one. It wouldn't make a big difference.
</HINT>

Send your solution to http://www.crackmes.de or to my email.

-- 
bundy
bundy@inmail.sk
