#include <iomanip>
#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>

using namespace std;

long int abss(long int i){
    return i*((i>0)?1:-1);
}

void saveDword(unsigned char *r,unsigned long int w)
{
  *(r)   =  (w & 0xFF);
  *(r+1) = ((w & 0xFF00)>>8);
  *(r+2) = ((w & 0xFF0000)>>16);
  *(r+3) = ((w & 0xFF000000)>>24);

}

unsigned int readDword(unsigned char *r)
{
  int rs=0;

  rs |= *r;
  rs |= ((*(r+1))<<8);
  rs |= ((*(r+2))<<16);
  rs |= ((*(r+3))<<24);

  return rs;

}
void printBuf(unsigned char *b,int n)
{

  while(1){

  for (int i=0;i<30;i++){
    cout <<hex<<" "<<(unsigned int)*(b++);
    n--;
    if (n<0) {
      cout<<endl;
      return;
    }
  }
  cout <<endl;
  }
}

int main(){
    unsigned char buffer[2048];
    unsigned char emailBuf[1000];

    string name;
    string email;

    cout <<"Enter name :";
    cin >>name;
    cout <<"Enter email :";
    cin >>email;

    for (int i=0;i<2048;i++)
        buffer[i]=0;

    long int c1,c2,c3,c4;
    for (unsigned long int i=0;i<0x100;i++){
      saveDword(buffer+i*4,i);
        saveDword(buffer+i*4+0x400,name[i%name.length()]);
    }

    c1 =c2=0;
    unsigned long int t01,eax;

    for (int i=0;i<0x100;i++){
        eax = c2;
        eax += readDword(buffer+i*4);
        eax += readDword(buffer+i*4+0x400);
        c2 = abss(eax)&0xFF;
        t01 = readDword(buffer+i*4);
        saveDword(buffer+i*4,readDword(buffer+c2*4));
        saveDword(buffer+c2*4,t01);
    }

    c1=c2=c3=c4=0;

    unsigned long int t02,r;

    for (int i=0;i<0x20;i++){
      emailBuf[i]=email[i%email.length()];
      c1 = abss(c1+1);
      c1 = c1 & 0xFF;

      c2= abss(c2+readDword(buffer+c1*4))&0xFF;

      t01 = readDword(buffer+c1*4);
      saveDword(buffer+c1*4,readDword(buffer+c2*4));
      saveDword(buffer+c2*4,t01);

      t01 = readDword(buffer+c1*4);
      t01 += readDword(buffer+c2*4);
      t01 = abss(t01)&0xFF;
      t02 = readDword(buffer+t01*4);
      r = emailBuf[i]^t02;
      if (i==0) cout<<"Serial number : 0";
        else cout <<dec<<(int)(r & 0xFF);

    }
    cout <<endl;
  return 0;
}
