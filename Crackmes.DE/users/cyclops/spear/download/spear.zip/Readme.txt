				Spear
				-----
			      Reverse Me 

				  By
	
				Cyclops
--------------------------------------------------------------------------------

Hi this is my new Reverse Me.

U have to make a KeyGen for this.

Do not patch the Good Jump ,Coz that will be too easy.

--------------------------------------------------------------------------------

	..::: Rating........... [   1  ] :::..

	..::: Compiler......... [ VC++ ] :::..

	..::: Coder............ [  CYC ] :::..

--------------------------------------------------------------------------------

This is a very easy one if u understand the algo, U can create a KeyGen in 

2 mins. Otherwise u have to analyse more.................


Send ur solution to :cyclops1428@yahoo.com

--------------------------------------------------------------------------------

				---===[GREETZ]===---

		m@rio - Great work dude, & sorry for sha-2

		SkeYT - Thnx for the KeyGen [Crackme 3.0]

			To all GAMERZ at AITEC

--------------------------------------------------------------------------------

Ps:Sorry for my BAD English?? ;-)

EOF