
void CWeweDlg::OnButton1() 
{
	Randcode(0,0x43);	
	Randcode(1,0x79);
	Randcode(2,0x43);
	Randcode(3,0x6c);
	Randcode(4,0x4f);
	Randcode(5,0x70);
	Randcode(6,0x53);

ConvertToSerial();

m_edit1=serial[0];
m_edit2=serial[1];
m_edit3=serial[2];
m_edit4=serial[3];
m_edit5=serial[4];
m_edit1.MakeUpper();
m_edit2.MakeUpper();
m_edit3.MakeUpper();
m_edit4.MakeUpper();
m_edit5.MakeUpper();

UpdateData(false);
	

}


void CWeweDlg::Randcode(const int j,const int t)
{
	int total,randi,looptimes=0;
	do{ 	
		randi=rand();
		for(int i=0;i<4;i++){
			srand(GetCurrentTime()*randi);
			code[i][j]=rand()%0xfb;
			randi++;
		}		
		total=((0x5*code[0][j])%0xfb+(0xf1*code[1][j])%0xfb+(0xa*code[2][j])%0xfb+(0xf6*code[3][j])%0xfb)%0xfb;
	}while (total>t);
	code[4][j]=t-total;
}


void CWeweDlg::ConvertToSerial()
{
	char tempcode[3]="";

	for(int i=0;i<5;i++){
		strcpy(serial[i],"");
		for(int j=0;j<7;j++){
			itoa(code[i][j],tempcode,16);
			if(strlen(tempcode)==1){tempcode[1]=tempcode[0];tempcode[0]='0';}
			strcat(serial[i],tempcode);
			strcat(serial[i],"-");
		}
		*(serial[i]+20)=0;
	}
}

BOOL CWeweDlg::CopyStringToClipboard(HWND hWnd, LPCTSTR lpszText)
{
 int nlen = strlen(lpszText);
 if (nlen == 0)return FALSE;

 HGLOBAL hglbCopy;
 LPTSTR  lptstrCopy;

 if (!::OpenClipboard(hWnd))return FALSE;

 hglbCopy = GlobalAlloc(GMEM_DDESHARE, (nlen + 1) * sizeof(char)); 
 
 if (hglbCopy == NULL) 
 { 
  CloseClipboard(); 
  return FALSE; 
 } 

 EmptyClipboard();

 lptstrCopy = (LPTSTR)GlobalLock(hglbCopy); 
 memcpy(lptstrCopy, lpszText, nlen);
 lptstrCopy[nlen] = (TCHAR) 0; 
 GlobalUnlock(lptstrCopy); 
  
 SetClipboardData(CF_TEXT, hglbCopy);
 CloseClipboard();

 return TRUE;
}

void CWeweDlg::OnButton2() 
{
	CopyStringToClipboard(NULL,m_edit1);

}

void CWeweDlg::OnButton3() 
{
	CopyStringToClipboard(NULL,m_edit2);
	
}

void CWeweDlg::OnButton4() 
{
	CopyStringToClipboard(NULL,m_edit3);
	
}

void CWeweDlg::OnButton5() 
{

	CopyStringToClipboard(NULL,m_edit4);

}

void CWeweDlg::OnButton6() 
{
	CopyStringToClipboard(NULL,m_edit5);
	
}
