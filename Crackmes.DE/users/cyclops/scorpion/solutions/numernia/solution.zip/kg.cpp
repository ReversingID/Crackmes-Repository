void Generate(HWND hWnd)
{
	ICE_KEY *ik;
	ik = ice_key_create(1);
	unsigned char inblk[] = {0}, outblk[64]={0};

	char k1[100],k2[100], s[3][100]={0};
	char temp[200] = {0}, serial[300], name[100];
	int len = GetDlgItemText(hWnd,IDC_N,name,100);

	if(len < 5){
		SetDlgItemText(hWnd,IDC_EDIT1, "Username length must be over 4 chars");
	}
	else
	{

	unsigned char sha_digest[30] = {0};
	SHA1Context sha_ctx;

	big g,x,p,q,xa,xb,yb,ta,tb,r,k;
	g = mirvar(0);
	x = mirvar(0);
	ta = mirvar(1);
	tb = mirvar(0);
	p = mirvar(0);
	q = mirvar(0);
	k = mirvar(0);
	xa = mirvar(0);
	xb = mirvar(0);
	yb = mirvar(0);
	r = mirvar(0);
	
	mip->IOBASE = 16;

	cinstr(p,"811C24AFB36712781EE85A8CDD645FADF4A909A9B6E67FC27C9EE197E729CB0B");
	cinstr(q,"380CB932405DFE21EDC59B523D357251250A66DFC6B"); // p-1 factor
	cinstr(xa,"FACE"); // private key
	cinstr(yb,"588E8740DBBC468476DA120AC8E1F84C58AF2E6625B9CCF3BBE4066967A7DEC6");

	irand(GetTickCount());
	//randomize x in Z*q, actually 1 <= x <= q-1
	bigdig(41,16,x);
	//yb^x mod p
	powmod(yb,x,p,ta);
		
	cotstr(ta,temp);
	strcpy(k2,temp+8);
	strcpy(k1,temp);
	k1[8]=0;

	ice_key_set(ik,(unsigned char*)k1);
	wsprintf(temp,"%08X",CRC(name,strlen(name)));

	ice_key_encrypt(ik,(unsigned char*)temp,outblk);
	Base64Encode(outblk,8,s[1]);

	strcat(name,k2);
	
	SHA1Reset(&sha_ctx);
	SHA1Input(&sha_ctx, (unsigned char*)name, strlen(name));
    SHA1Result(&sha_ctx , sha_digest);

	for (int i = 0; i < 20; i++)
	{
		wsprintf(s[0] + i*2,"%02X",sha_digest[i]);
	}

	cinstr(r,s[0]);
	add(r,xa,r); // (r + xa)
	xgcd(r,q,r,r,r); //( r + xa )^-1 mod q
	multiply(x,r,ta); // x(r + xa)^-1 mod q
	power(ta,1,q,tb); // mod q
	cotstr(tb,s[2]);

	wsprintf(serial,"%s-%s-%s",s[0],s[1],s[2]);
	SetDlgItemText(hWnd,IDC_EDIT1,serial);

	mirkill(g);
	mirkill(x);
	mirkill(ta);
	mirkill(tb);
	mirkill(p);
	mirkill(q);
	mirkill(k);
	mirkill(xa);
	mirkill(xb);
	mirkill(yb);
	mirkill(r);
	}


	
}