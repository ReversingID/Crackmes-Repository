			SCORPiON
			--------

Hi, 

this is my newest keygenme, the algo is in my head for almost a year, and now i got some time to implement and test it. And here it is!

Protection: Crypto/Math
Difficulty: U decide :P
GFX: (un)fortunatly be ME!

Rulz
----
. No Patching
. No direct serial brute-forcing

Solution == keygen + src + tut :)

Hint
----
. One name, many serials
. Some thing is changed to override KANAL

Greetz: To a lot of people :D

Regards,
Cyclo
www.cyclops.ueuo.com
-Mera Bharat Mahan

