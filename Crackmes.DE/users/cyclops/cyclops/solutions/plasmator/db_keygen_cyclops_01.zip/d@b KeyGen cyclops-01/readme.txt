cyclops crackme
find serial
mail results to cyclops1428@blackcodemail.com