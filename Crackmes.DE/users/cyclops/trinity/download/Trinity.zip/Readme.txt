				Trinity
				-------

			CrackMe By.......: Cyclops
			Protection.......: Key File

Hi 
	This is my New KeyGenMe.
	I named it as Trinity as this has three protection mechanism.
	Its not much harder but u have to think more.....I think :-)

	
	Rulz
	----
	Do not patch the Good Jump as it would be too easy.
	No self KeyGen or Loader.
	Create a valid KeyFile Creator and ..............

	Send me the KeyFile creator with src to 
		cyclops1428@yahoo.com
	

	Happy Cracking!!!!

		Greatz to All GAMERZ in AIT-CSE

EOF