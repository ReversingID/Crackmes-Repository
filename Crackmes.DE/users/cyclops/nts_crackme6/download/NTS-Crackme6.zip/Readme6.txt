					-NTS-Crackme6
					     By
		
					   Cyclops
-------------------------------------------------------------------------------------------------

Crackme = NTS Crackme6

To_Do
-----

	Create a working keyfilegen

Addons
------
	
	This algo will be useful to every reverser.

-------------------------------------------------------------------------------------------------

Gr33tz
------
	Greetz to all the reversers,crackers,coders in Reverse Code Engineering field.
	Greetz to all the Programmers who created such nice tools.
	Greetz to crackmes.de, where i started reversing and still learning.
	Greetz to all my friends from RCE world and REAL world, with out em i shouldn't be doin 
	this.

-------------------------------------------------------------------------------------------------

Contact
-------
	U can PM me on crackmes.de or mail me cyclops1428[at]yahoo.com

-------------------------------------------------------------------------------------------------

			   ( Part of Project PolyPhemous (c) Cyclops )