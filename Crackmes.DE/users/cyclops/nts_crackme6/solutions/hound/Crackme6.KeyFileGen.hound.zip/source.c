#include <stdio.h>
#include <windows.h>
#include <time.h>

#define TABLE_VAL_SIZE 26
#define NUM 25
#define BASE 0x41

typedef struct
{
	char cVal[TABLE_VAL_SIZE];
}TABLE, *PTABLE;

void SetupTable(PTABLE pT)
{
	int i;
	char c0A = 'A';

	for (i=0; i<26; i++)
		pT->cVal[i] = c0A + i;
}

void SeedRandomNumber(void)
{
	srand((unsigned)time(NULL));
	rand();
}

int GenerateRandomNumber(int iRndMax)
{
	float fFrct = (float)rand() / (float)RAND_MAX;
	float iRet;
	iRet = fFrct * (float)iRndMax;

	return (int)iRet;
}

char * GenerateRandomString(TABLE tble, int iStrLen)
{
	int i, rndNum;
	char * szRetStr = (char *)malloc((iStrLen+1)*(sizeof(char)));
	memset((void *)szRetStr, '0', iStrLen*sizeof(char));
	*(szRetStr+iStrLen) = '\0'; 

	for (i=0; i<iStrLen; i++) {
		rndNum = GenerateRandomNumber(TABLE_VAL_SIZE);
		*(szRetStr+i) = tble.cVal[rndNum];
	}
	return szRetStr;
}

BYTE RequestByte(DWORD dwChar) {

	BYTE byTable[80], byReturn=0;
	UINT i=0,j=0,iIndex;

	
	byTable[0] = 0x7C;

	for (i=1; i<=3; i++)
		byTable[i] = 0x24;

	byTable[4] = 0x7D;

	for (i=5, j=0x72; i<=13; i++, j++)
		byTable[i] = j;

	byTable[14] = 0x7B;

	for (i=15; i <= 21; i++)
		byTable[i] = 0x24;

	for (i=22, j = 0x3E; i <= 47; i++, j++)
		byTable[i] = j;

	for (i=48; i<=53; i++)
		byTable[i] = 0x24;

	for (i=54, j=0x58; i<=79; i++, j++)
		byTable[i] = j;

	iIndex = (UINT)dwChar - 43;
	byReturn = byTable[iIndex];

	return byReturn;
}

UINT GenerateIntermediate(LPTSTR szStringTwo, BYTE * byThirdBuffer) {
	
	BYTE byFirstBuffer[4], bySecondBuffer[4];
	UINT iStringLength = (DWORD)strlen(szStringTwo);
	UINT i=0, j=0, k=0, l=0;
	BYTE byRequest = 0;
	WORD byI, byJ;
	for (i=0, j=0; i<iStringLength; i++) {

		if ((szStringTwo[i] > 0x2B) && (szStringTwo[i] < 0x7A)) {
			byRequest = RequestByte(szStringTwo[i]);

			switch (byRequest) {
			case 0x00: {
				byRequest--;
				break;
					   }
			case 0x24: {
				byRequest = 0;
				byRequest--;
				break;
					   }
			default: {
				byRequest += 0xc3;
				byRequest--;
				break;
					 }
			}

			byFirstBuffer[j] = byRequest;
			j++;

			if (j == 4) {
				byI = (WORD)byFirstBuffer[0];
				byJ = (WORD)byFirstBuffer[1];
				byI = byI << 2;
				byJ = byJ >> 4;
				byI = byI | byJ;
				bySecondBuffer[0] = (BYTE)byI;

				byI = (WORD)byFirstBuffer[2];
				byJ = (WORD)byFirstBuffer[1];
				byI = byI >> 2;
				byJ = byJ << 4;
				byI = byI | byJ;
				bySecondBuffer[1] = (BYTE)byI;

				byI = (WORD)byFirstBuffer[2];
				byJ = (WORD)byFirstBuffer[3];
				byI = byI << 6;
				byI = byI | byJ;
				bySecondBuffer[2] = (BYTE)byI;
				bySecondBuffer[3] = 0;

				byI = (WORD)bySecondBuffer[0];
				byJ = (WORD)bySecondBuffer[1];	

				byThirdBuffer[k] = (BYTE)byI;
				k++;
				byI = (WORD)bySecondBuffer[2];
				byThirdBuffer[k] = (BYTE)byJ;
				k++;
				byThirdBuffer[k] = (BYTE)byI;
				k++;

				j = 0;
			}
		}
		else
		{
			return 1;
		}
	}

	return k;


}

UINT FullStringGenerate(LPTSTR szFullString) {
		UINT i,j,k,l;
	BOOL bFlag;
	BYTE bySmallBuffer[3];
	BYTE byCompareBuffer[2];
	BYTE byLargeBuffer[64];
	LPTSTR szString;
	TCHAR szTemp[5];
	TABLE tble;
	TCHAR tChar[NUM];
	SetupTable(&tble);

	szFullString[0] = '\0'; 

	SeedRandomNumber();

	for (i=0; i<NUM; i++) {
		tChar[i] = BASE + i;

	}
	
	bFlag = 0;

	for (j=0; j<9; j++) {
		do {
			szString = GenerateRandomString(tble, 4);
			if(GenerateIntermediate(szString, bySmallBuffer) == 1)
				continue;


			for (i = 0; i<3; i++) {
				if ((bySmallBuffer[i] > 0x7F) || (bySmallBuffer[i] == 0x00) || (bySmallBuffer[i] == 0x0A)) {
					free(szString);
					bFlag = 1;
					break;
				}
				else if((i==2) && (bySmallBuffer[i] <= 0x7F)) {
					bFlag = 0;
				}
			}
		}
		while(bFlag);

		strcat(szFullString, szString);
		free(szString);
	}

	j = GenerateIntermediate(szFullString, byLargeBuffer);

	byCompareBuffer[0] = byLargeBuffer[0];
	byCompareBuffer[1] = byLargeBuffer[1];

	bFlag = 0;
	for (l=0; l<NUM; l++) {
		for (k=0; k<NUM; k++) {
			for (j=0; j<NUM; j++) {
				for (i=0; i<NUM; i++) {
					sprintf(szTemp, "%c%c%c%c", tChar[l], tChar[k], tChar[j], tChar[i]);
					GenerateIntermediate(szTemp, bySmallBuffer);

					if ((bySmallBuffer[1] == byCompareBuffer[0]) && (bySmallBuffer[2] == byCompareBuffer[1]) && (bySmallBuffer[0] <= 0x7F) && (bySmallBuffer[0] != 0x00)) {
						bFlag = 1;
						}
					
					if(bFlag)
						break;		
					}
				if(bFlag)
					break;
				}
			if(bFlag)
				break;
			}
		if(bFlag)
			break;
		}

	if(bFlag) {
		strcat(szFullString, szTemp);
		return 1;
	}

	return 0;
	}

int main()
{
	TCHAR szFullString[64];
	BYTE byBuffer[64];
	BYTE byOutput[128];
	UINT iRet, i,j;
	HANDLE hdle;
	DWORD dwWritten;

	printf("hound 2007 - KeyFileGen for CrackMe6.exe by Cyclops\n");
	printf("---------------------------------------------------\n");

	printf("Generating string");

	do {
		printf(".");
	}
	while(!FullStringGenerate(szFullString));

	printf("\n");

	printf("[!] String = %s\n", szFullString);

	iRet = GenerateIntermediate(szFullString, byBuffer);
	
	printf("[!] Hash = ");

	for (i=0; i<iRet; i++) {
		printf("%02X", byBuffer[i]);
		byOutput[i] = byBuffer[i];
	}

	printf("\n");

	byOutput[i-1] = 0x00;

	for (j=0; szFullString[j] != '\0'; j++, i++)
		byOutput[i] = (BYTE)szFullString[j];

	byOutput[i] = 0xFF;

	printf("[!] Output to Key.cyc = ");



	hdle = CreateFile("Key.cyc", GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	for (i=0; byOutput[i] != 0xFF; i++) {
		printf("%02X", byOutput[i]);
		WriteFile(hdle, &byOutput[i], 1, &dwWritten, NULL);
	}
	printf("\n");
	CloseHandle(hdle);

	return 0;
}
