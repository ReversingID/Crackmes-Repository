#include <stdio.h>
#include <windows.h>

#define NUM 0x5e
#define BASE 0x20

DWORD _FirstHash(LPTSTR szInput) {

	DWORD dw;

	_asm
	{
		PUSH ESI
		lea esi, DWORD PTR DS:[szInput]
		mov esi, DWORD PTR DS:[esi]
		XOR EAX,EAX
		MOV CL,BYTE PTR DS:[ESI]
		PUSH EDI
		LoopStart:
			MOVSX ECX,CL
			MOV EDI,ECX
			XOR EDI,0xBAD0BEEF
			ADD EDI,EAX
			MOV EAX,ECX
			AND EAX,0xFEFEFEFE
			OR EDI,EAX
			MOV EAX,ECX
			CDQ
			MOV ECX,0x0D
			IDIV ECX
			NOT EDI
			MOV CL,BYTE PTR DS:[ESI+1]
			IMUL EDI,EDX
			INC ESI
			MOV EAX,EDI
			TEST CL,CL
			JNZ LoopStart
		POP EDI
		POP ESI

		mov [dw], eax
	}

	return dw;
}





DWORD _SecondHash(LPTSTR szInput) {

	DWORD dw;

	_asm
	{
		PUSH ESI
		lea esi, DWORD PTR SS:[szInput]
		mov esi, DWORD PTR SS:[esi]
		XOR EAX,EAX
		MOV CL, BYTE PTR DS:[ESI]

		PUSH EBX
		PUSH EDI
		LoopStart:
			MOVSX ECX,CL
			MOV EDI,ECX
			MOV EBX,0x11
			XOR EDI,0xB00BFACE
			ADD EDI,EAX
			MOV EAX,ECX
			OR EAX,0xFEFEFEFE
			AND EDI,EAX
			LEA EAX,DWORD PTR DS:[ECX+ECX*2]
			SHL EAX,5
			ADD EAX,ECX
			LEA EAX,DWORD PTR DS:[EAX+EAX*8]
			SHL EAX,2
			CDQ
			IDIV EBX
			MOV EAX,ECX
			MOV ECX,5
			ADD EDI,EDX
			CDQ
			IDIV ECX
			ADD EDX,ECX
			MOV CL,BYTE PTR DS:[ESI+1]
			IMUL EDI,EDX
			INC ESI
			MOV EAX,EDI
			TEST CL,CL
			JNZ LoopStart
		POP EDI
		POP EBX
		POP ESI

		mov [dw], eax
	}

	return dw;
}

DWORD _ThirdHash(LPTSTR szInput) {

	DWORD dw;

	_asm
	{
		lea edx, dword ptr ss:[szInput]
		mov edx, dword ptr ss:[edx]

		XOR EAX,EAX
		MOV CL,BYTE PTR DS:[EDX]
		PUSH ESI
		LoopStart:
			MOVSX ECX,CL
			MOV ESI,ECX
			XOR ESI,0xBAD0BEEF
			ADD ESI,EAX
			MOV EAX,ECX
			OR EAX,0xDEADC0DE
			XOR ESI,EAX
			IMUL ESI,ECX
			MOV CL,BYTE PTR DS:[EDX+1]
			INC EDX
			TEST CL,CL
			MOV EAX,ESI
			JNZ LoopStart
		POP ESI

		mov [dw], eax
	}

	return dw;
}

void fFullHash(const LPTSTR szInput, LPTSTR szOutput)
{
	DWORD dwRet[3];
	dwRet[0] = _FirstHash(szInput);
	dwRet[1] = _SecondHash(szInput);
	dwRet[2] = _ThirdHash(szInput);

	sprintf(szOutput, "%08X-%08X-%08X", dwRet[0], dwRet[2], dwRet[1]);
}




int main() {
	
	LPTSTR szTarget = "0CEAC848-A1F55297-18B3DD62";
	LPTSTR szOutput, szTemp;

	TCHAR tChar[NUM];
	UINT i,j,k,l;


	for (i=0; i<NUM; i++) { //Setup characters to be included in string
		tChar[i] = BASE + i;
	}

	szOutput = (LPTSTR)malloc(32*sizeof(TCHAR));
	szTemp = (LPTSTR)malloc(16*sizeof(TCHAR));

	//3 character test
		for (k=0; k<NUM; k++) {
			for (j=0; j<NUM; j++) {
				for (i=0; i<NUM; i++) {
					sprintf(szTemp, "%c%c%c", tChar[k], tChar[j], tChar[i]);
					fFullHash(szTemp, szOutput);
					if (strcmp(szOutput, szTarget) == 0) {
						printf("[!] Input string = %s \t Hash = %s\n", szTemp, szOutput);
						return 1;
					}
				}
			}
		}




	free(szOutput);
	free(szTemp);


	return 0;

	
}




