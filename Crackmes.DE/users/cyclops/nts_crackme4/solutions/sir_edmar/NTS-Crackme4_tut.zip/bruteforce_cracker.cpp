#include <stdio.h>
#include <string.h>

#define RANGE_DOWN 0x30
#define RANGE_UP 0x7F

unsigned int part1(char *serial)
{
   int unsigned result;

   _asm {
	PUSH ESI
	LEA ESI, DWORD PTR SS:[serial]
	MOV esi, DWORD PTR SS:[esi]
	XOR EAX, EAX
	MOV CL, BYTE PTR DS:[ESI]
    PUSH EDI
    loopbegin:
        MOVSX ECX, CL
        MOV EDI, ECX
        XOR EDI, 0xBAD0BEEF
        ADD EDI, EAX
        MOV EAX, ECX
        AND EAX, 0xFEFEFEFE
        OR EDI, EAX
        MOV EAX, ECX
        CDQ
        MOV ECX, 0x0D
        IDIV ECX
        NOT EDI
        MOV CL, BYTE PTR DS:[ESI + 1]
        IMUL EDI, EDX
        INC ESI
        MOV EAX, EDI
        TEST CL, CL
	JNE loopbegin
	POP EDI
	POP ESI
	MOV result, ESI
	}
}

unsigned int part2(char *serial)
{
   unsigned int result;
	__asm{
		PUSH ESI
		LEA ESI, DWORD PTR SS:[serial]
		MOV esi, DWORD PTR SS:[esi]
		XOR EAX,EAX
		MOV CL, BYTE PTR DS:[ESI]
		PUSH EBX
		PUSH EDI
		loopbegin:
			MOVSX ECX,CL
			MOV EDI,ECX
			MOV EBX,0x11
			XOR EDI,0xB00BFACE
			ADD EDI,EAX
			MOV EAX,ECX
			OR EAX,0xFEFEFEFE
			AND EDI,EAX
			LEA EAX,DWORD PTR DS:[ECX*2+ECX]
			SHL EAX,0x5
			ADD EAX,ECX
			LEA EAX,DWORD PTR DS:[EAX*8+EAX]
			SHL EAX,0x2
			CDQ
			IDIV EBX
			MOV EAX,ECX
			MOV ECX,0x5
			ADD EDI,EDX
			CDQ
			IDIV ECX
			ADD EDX,ECX
			MOV CL,BYTE PTR DS:[ESI+1]
			IMUL EDI,EDX
			INC ESI
			MOV EAX,EDI
			TEST CL,CL
			JNE SHORT loopbegin
		POP EDI
		POP EBX
		POP ESI
		MOV result, ESI
	}
}
   
unsigned int part3(char *serial)
{
   unsigned int result;

    __asm {
	LEA EDX,DWORD PTR SS:[serial]
	MOV EDX, DWORD PTR SS:[EDX]
	XOR EAX,EAX
	MOV CL,BYTE PTR DS:[EDX]
	PUSH ESI
	loopbegin:
		MOVSX ECX,CL
		MOV ESI,ECX
		XOR ESI,0xBAD0BEEF
		ADD ESI,EAX
		MOV EAX,ECX
		OR EAX,0xDEADC0DE
		XOR ESI,EAX
		IMUL ESI,ECX
		MOV CL,BYTE PTR DS:[EDX+1]
		INC EDX
		TEST CL,CL
		MOV EAX,ESI
		JNE SHORT loopbegin
	POP ESI
	MOV result, ESI
	}
}
   
   
int main(){

char input[4];
char temp[4];
char compare[27]="0CEAC848-A1F55297-18B3DD62";
char toCompare[27];
unsigned int a, b, c, d;
printf("Bruteforce Cracker for NTS4 by Cyclops\nwritten by Sir_Edmar (knallerbse@gmail.com)\n\n");
for(a = RANGE_DOWN; a <= RANGE_UP; a++){
	input[0] = a;
	for(b = RANGE_DOWN; b <= RANGE_UP; b++){
		input[1] = b;
		for(c = RANGE_DOWN; c <= RANGE_UP; c++){
			input[2] = c;
			//for(d = RANGE_DOWN; d <= RANGE_UP; d++){  //for search with 4 digits
				//input[3] = d;
				input[3]= '\0';
				sprintf(toCompare, "%08X-%08X-%08X",part1(input),part3(input),part2(input));
				if(strcmp(compare,toCompare) == 0){
					printf("HIT! input: %s\nhash1: %s\nhash2: %s\n", input, toCompare, compare);
					return 1;
				}

			//}
		}
	}
}

return 0;
}
