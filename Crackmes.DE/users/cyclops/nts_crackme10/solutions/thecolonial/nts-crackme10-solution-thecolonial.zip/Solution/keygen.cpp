#include <iostream>

void ShowProgramDetails( void )
{
    ::printf( "Key generator for cyclops's NTS-Crackme10.\n" );
    ::printf( "Written by TheColonial (thecolonial@gmail.com).\n\n" );
}

void GetUserName( char* buffer, int bufferSize )
{
    const int minLength = 6;
    ::printf( "Please enter your user name (min %d characters): ", minLength );

    while( true )
    {
        ::fgets( buffer, bufferSize, stdin );

        // fgets INCLUDES the newline, so we need to cater for that
        if( ::strlen( buffer ) - 1 >= minLength )
        {
            buffer[::strlen( buffer ) - 1] = '\0';
            break;
        }

        ::printf( "Not enough characters. Try again (min %d characters): ",
            minLength );
    }
}

void GenerateSerial( char* username, char* serial )
{
    unsigned int magicNumber = 0;

    // basically include the body of the existing function! with a few tweaks
    __asm
    {
        xor     eax, eax
        xor     edx, edx
        push    ebx
        push    esi

        // load our username
        mov     esi, username
        mov     cl, [esi]

        // don't bother with the check for NULL, as we know we're always going
        // to have a valid username. Assume that we're always going to have
        // a value of zero, instead of 0x3025 for the magic number because
        // the user of the key generator won't be debugging at the same time!
        push    edi
        xor     edi, edi

loopstart:
        movsx   ecx, cl
        mov     ebx, ecx
        xor     ebx, 0C0C0C0C0h
        sub     ebx, edi
        add     ebx, edx
        imul    ebx, eax
        shl     ebx, 1
        mov     edx, ebx
        lea     ebx, [ecx+ecx*4]
        xor     edx, ebx
        and     ecx, 8000001Fh
        jns     positive
        dec     ecx
        or      ecx, 0FFFFFFE0h
        inc     ecx
positive:
        shl     edx, cl
        mov     cl, [eax+esi+1]
        xor     edx, 0BADDC001h
        inc     eax
        test    cl, cl
        jnz     loopstart

        // store the result
        mov     [magicNumber], edx

        // bit of housekeeping!
        pop     edi
        pop     esi
        pop     ebx
    }

    // print the value into a string
    ::sprintf( serial, "%08X", magicNumber );
}

void DisplayResult( char* username, char* serial )
{
    ::printf( "The serial number for '%s%' is: %s\n\n", username, serial );
}

// program entry point
int main( void )
{
    // constants for buffer sizes.
    const int usernameBufferSize = 64;
    const int serialBufferSize = 10;

    // variables for storing strings in
    char username[usernameBufferSize];
    char serial[serialBufferSize];

    // display some stuff
    ShowProgramDetails();

    // ask the user for a user name
    GetUserName( username, usernameBufferSize );

    // generate the serial
    GenerateSerial( username, serial );

    DisplayResult( username, serial );

    return EXIT_SUCCESS;
}
