Angler By Cyclops
-----------------

Err....emm...What to say?
Another keygenme from me.
Nothing great, but i found it interesting, so here it is!

To Do :- Make a keygen+tut

Rules :- NO PATCHING, NO DIRECT BRUTE OF SERIALS(Hint?)

I like to see some explanation, rather than..."I donno what it is doing, i just ripped the code and bruted..lol"

Hint :- Some names may not have serials!

Greets to a lot of friends, you know it!

Regrads,
Cyclops
http://cyclops.ueuo.com
http://crackmes.de

-Mera Bharat Mahan!