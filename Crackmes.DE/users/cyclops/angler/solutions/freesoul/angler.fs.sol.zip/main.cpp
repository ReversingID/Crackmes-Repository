#include <stdio.h>
#include <windows.h>
#include <commctrl.h> 
#include "resource.h"
#include "crc32.h"
#include <iostream.h>
#include <math.h>

#define TITLE "Angler [Cyclops] Keygen [freesoul]"

#pragma comment(lib, "comctl32.lib")

char* gen(char* name);
bool getPrimes(unsigned int top, unsigned int &factor1, unsigned int &factor2);
char fail[] = "There are no possible serials";
bool isprime(unsigned long int number);
void nextprime(unsigned int &number);

HINSTANCE	hInst;

BOOL CALLBACK DialogProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{	

	switch (message)
	{    
	case WM_CLOSE:
		EndDialog(hWnd,0);
		break;

	case WM_COMMAND:
        switch (HIWORD(wParam))
        {
        case BN_CLICKED:
    		switch (LOWORD(wParam))
		    { 
            case IDGEN:


				//Gets name
				char *name;
				name = new char[50];
				GetDlgItemText(hWnd, IDNAME, name, 50);

				//checks if there is a name and >4
				if(strlen(name)<5)
					MessageBox(hWnd, "Name lenght must > 4", "Info", MB_OK);
				else
				SetDlgItemText(hWnd, IDSERIAL, gen(name)); 

                break;

             case IDABOUT:
				MessageBox(hWnd, "keygenned by freesoul... =)", "About", MB_OK);
                
                break;
		    }
            break;
        }
		break;

	case WM_INITDIALOG:
		// Load Icon
        SendMessage(hWnd,  WM_SETICON, ICON_SMALL,(LPARAM) LoadIcon(hInst, MAKEINTRESOURCE(IDI_ICON1)));
        SendMessage(hWnd,  WM_SETICON, ICON_BIG,(LPARAM) LoadIcon(hInst, MAKEINTRESOURCE(IDI_ICON1)));
		

		
		// Position the window
		RECT r;
		GetWindowRect(hWnd, &r);
		SetWindowPos(hWnd, 0, GetSystemMetrics(SM_CXSCREEN)/2-r.right/2, GetSystemMetrics(SM_CYFULLSCREEN)/2-r.bottom/2, r.right, r.bottom, 0);	

		// Set Window title
		SetWindowText(hWnd, TITLE);

		// Set windows username in textbox
		char *name;
		name = new char[32];
		DWORD len = 32;
		GetUserName(name, &len);
		SetDlgItemText(hWnd, IDNAME, name);

		// SetFocus
		SetFocus(GetDlgItem(hWnd, IDGEN));

		break;
	}
     return 0;
}

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{
	Init_CRC32_Table();

	hInst=hInstance;
	InitCommonControls();
    DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_MAIN), NULL, (DLGPROC)DialogProc,0);
	return 0;
}

char* gen(char* name)
{
	unsigned int r1,r2,r3,r4,r5,r6,r7,r8;
	unsigned int hash1 = Get_CRC(name)-0x13373;		if(hash1%2 != 0) hash1++;
	unsigned int hash2 = Get_CRC(name+1)-0x13373;	if(hash2%2 != 0) hash2++;
	unsigned int hash3 = Get_CRC(name+2)-0x13373;	if(hash3%2 != 0) hash3++;
	unsigned int hash4 = Get_CRC(name+3)-0x13373;	if(hash4%2 != 0) hash4++;

	if(!getPrimes(hash1, r1, r5)) return (char*)fail;
	if(!getPrimes(hash2, r2, r6)) return (char*)fail;
	if(!getPrimes(hash3, r3, r7)) return (char*)fail;
	if(!getPrimes(hash4, r4, r8)) return (char*)fail;

	char* serial;
	serial = new char[72];
	sprintf(serial, "%X-%X-%X-%X-%X-%X-%X-%X", r1,r2,r3,r4,r5,r6,r7,r8);
	return serial;
}

bool isprime(unsigned int num) {
	for(int i = 2; i <= sqrt(num); i++)
		if(num % i == 0)
			return false;
   return true;
}

void nextprime(unsigned int &number) {
do 	number+=2; while(!isprime(number));
}

bool getPrimes(unsigned int top, unsigned int &factor1, unsigned int &factor2)
{

	for(factor1=3; factor1<=top/2; nextprime(factor1))
		if(isprime(top-factor1))
		{ 
		factor2 = (top-factor1); 
		return 1; 
		}
		

	return 0;
}
