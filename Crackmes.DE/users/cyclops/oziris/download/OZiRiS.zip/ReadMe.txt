
Crackme : OZiRiS
coder   : Cyclops / REAL
level 	: 2
Prot	: Custom Crypto
Solution: A working KeyGen + src + a nice tut!!!

Hi all.....

	I am coding a crackme after some intervel.
	This comprises a custom made crypto algo.
	Itz not that grt but works fine.
	Hope u enjoi it!!!

	Gr33tz fly out to
	str,xFactor,l0calh0st,K3V,mario,jB_,0x87k,HMX0101,
	x15or,lord_Phoenix,starzboy,THiN^SouRCE and all that i forgot....



		(OZiRiS - Part of Project PolyPhemous)