/* -*- mode: c++ -*-
 * keygen to cyclops's KeyGenMe-iNF1 
 * http://www.crackmes.de/users/cyclops/keygenme_inf1/
 *
 * crp-
 */
#include <iostream>
#include <iomanip>
#include <string>
#include <sstream>
#include <cstring>
#include <algorithm>

using namespace std;

char upcase_char(const char& c) {
	return toupper(c);
}

string upcase(const string& s) {
	string o(s);
	transform(o.begin(), o.end(), o.begin(), upcase_char);
	return o;
}

/* extended euclidean */
template <typename T>
T xgcd(const T& a, const T& b, T& s, T& t) {
	T m, n, u, v;

	m = a;	n = b;
	s = 1;	t = 0;
	u = 0;	v = 1;

	while(n != 0) {

		T tmp;
		T q = m / n;
		T r = m % n;

		m = n;
		n = r;

		tmp = u;
		u = s - q * u;
		s = tmp;

		tmp = v;
 		v = t - q * v;
		t = tmp;
		
	}

	return m;
}

/* multiplicative inverse of a mod b */
template<typename T> 
bool mul_inv(const T& a, const T& b, T& a_inv) {
	T d, s, t;

	d = xgcd<T>(a, b, s, t);
	
	if(d == 1) {
		/* ensure positive result */
		while(s < 0)
			s += b;
		a_inv = s;
		return true;
	}
	return false;
}


int hash(const char* str) {
        int len, i;
        int h = 0x29A;

        len = strlen(str);
        for(i = 0; i < len; i++) {
                int a, c, d, s;
                c = str[i];
                s = c ^ 0xDADA;
                s += h;
                a = c ^ 0xBABE;
                c ^= 0xF001;
                a = ~a;
                a = a + s*4;
                a >>= 3;
                a += c;
                h = a;
        }
        return h;
}

int check_key(const char* name, int key) {
	int nhash;

	nhash = hash(name) + 0x28F;
	nhash %= 0x1234;
	nhash *= key;
	if((nhash % 0x10001) == 1)
		return 1;
	else
		return 0;
}

string generate_key(string& name) {
	int nhash;
	int key;

	nhash = (hash(name.c_str()) + 0x28F) % 0x1234;
	if(nhash == 0) {
		return "no key for this name (bug in crackme...)";
	}

	if(mul_inv(nhash, 0x10001, key)) {
		ostringstream oss;
		oss << hex << key;
		return upcase(oss.str());
	} else {
		return "this never happens as 0x10001 is prime...";
	}
		
}


int main(int argc, char *argv[]) {
	string name;
	
	cout << "--[KGenMe-INF1 keygen .crp-]------------------------------------\n";
	cout << "name: ";
	cin >> name;
	cout << "key:  ";
	cout << generate_key(name) << endl;

	return 0;
}


