Hi......

This is my new keygenme.

Itz a very simple one.Very small algo.Some minor krypto basics.

Create a KeyGen.

Patching and Brute-Forcing are not allowed.

Good Luck.
