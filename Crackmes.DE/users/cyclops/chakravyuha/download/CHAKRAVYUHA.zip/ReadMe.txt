Hi all....

Chakravyuha is a keygenme which includes scaled down versions of my two creations.

Solution==keygen with src + a nice tut :D

Greetz:
	jB,sEby,mario,anorganix,starzboy,PiONEER,zairon,bLaCk-eye,lord_Phoenix,
	0x87k,HMX0101,l0calh0st,Crosys,ALiEN,Whitrat,Reverser,TheXROOSTer nd the rest...

Best Regards,
	Cyclo
	-Mera Bharath Mahan