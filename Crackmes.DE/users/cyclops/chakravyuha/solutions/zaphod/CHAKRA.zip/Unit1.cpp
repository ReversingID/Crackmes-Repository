
#include <windows.h>
#include <iostream.h>
#include <stdio.h>
#include <conio.h>
#include <tchar.h>

#define  AND &
#define  OR  |
#define  MOD %
#define  DIV /
#define  XOR ^
#define  NOT !

#pragma hdrstop

//---------------------------------------------------------------------------

#pragma argsused

DWORD func5A( DWORD, BYTE );
DWORD func5B( DWORD, BYTE );
DWORD backwards5A( DWORD, BYTE );
DWORD backwards5B( DWORD, BYTE );
DWORD SHL( DWORD, BYTE );
DWORD SHR( DWORD, BYTE );

int main( int argc, char* argv[] )
{


  DWORD A[29],B[29],C[29],D[29],E[29];
  DWORD count = 0;

  char name[64];

  name:
  name[0] = 0;
  std::cout << "\nName:   ";

  gets( name );

  int i = lstrlen( name );
  if ( i < 5 )  { printf( "Name too short!\n"); goto name; }
  if ( i > 16 ) { printf( "Name too long!\n");  goto name; }

  char nam[64] = "";
  lstrcat( nam, name );
  while ( lstrlen( nam ) < 16 ) lstrcat( nam, name );

  B[28] = nam[3] + 0x100*nam[2] + 0x10000*nam[1] + 0x1000000*nam[0];
  C[28] = nam[7] + 0x100*nam[6] + 0x10000*nam[5] + 0x1000000*nam[4];
  D[28] = nam[11] + 0x100*nam[10] + 0x10000*nam[9] + 0x1000000*nam[8];
  E[28] = nam[15] + 0x100*nam[14] + 0x10000*nam[13] + 0x1000000*nam[12];


  for ( int i = 1; i <= 8; i++ ) {

    A[28] = E[28];
    A[25] = A[28];
    D[13] = A[25];
    D[27] = D[28];
    D[26] = D[13] XOR 0x12341234;
    C[21] = C[28];
    A[18] = C[21];
    B[20] = B[28];
    B[6]  = A[18];
    B[19] = B[6] XOR 0x12341234;
    C[17] = B[19] XOR B[20];
    A[16] = C[17];
    A[15] = backwards5B( A[16], count );
    C[14] = A[15];
    A[10] = C[14];
    D[1]  = A[10];
    D[12] = D[1] XOR 0x12341234;
    E[24] = D[26] XOR D[27];
    A[23] = E[24];
    A[22] = backwards5A( A[23], count );
    E[7]  = A[22];
    A[3]  = E[7];
    B[1]  = A[3];
    B[5]  = B[1] XOR 0x12341234;
    E[3]  = B[5] XOR B[6];
    A[2]  = E[3];
    A[1]  = backwards5A( A[2], count );
    E[1]  = A[1];
    C[10] = D[12] XOR D[13];
    A[9]  = C[10];
    A[8]  = backwards5B( A[9], count );
    C[1]  = A[8];

    A[28] = A[1];
    B[28] = B[1];
    C[28] = C[1];
    D[28] = D[1];
    E[28] = E[1];

    count = count + 1;

    if ( count == 8 ) {
      printf( "\nSerial: %08X-%08X-%08X-%08X\n", B[1], C[1], D[1], E[1] );
      printf( "\n\nPress any key to continue..." );
    }
  }

  getch();

  return 0;
}
//------------------------------------------------------------------------------

  DWORD func5A( DWORD x, BYTE y ) {
    DWORD eax = x, esi = x;
    BYTE A, B;
    A = 0x20 - y;
    B = y;
    esi = SHR( esi, A );
    eax = SHL( eax, B );
    esi = esi OR eax;
    return esi;
  }

//------------------------------------------------------------------------------

  DWORD func5B( DWORD x, BYTE y ) {
    DWORD eax = x, esi = x;
    BYTE A, B;
    A = 0x20 - y;
    B = y;
    esi = SHL( esi, A );
    eax = SHR( eax, B );
    esi = esi OR eax;
    return esi;
  }

//------------------------------------------------------------------------------


  DWORD backwards5A( DWORD x, BYTE y ) {
    DWORD eax = x, esi = x;
    BYTE A, B;
    A = 0x20 - y;
    B = y;
    esi = SHL( esi, A );
    eax = SHR( eax, B );
    esi = esi OR eax;
    return esi;
  }

//------------------------------------------------------------------------------

  DWORD backwards5B( DWORD x, BYTE y ) {
    DWORD eax = x, esi = x;
    BYTE A, B;
    A = 0x20 - y;
    B = y;
    esi = SHR( esi, A );
    eax = SHL( eax, B );
    esi = esi OR eax;
    return esi;
  }

//------------------------------------------------------------------------------

  DWORD SHL( DWORD input, BYTE number_of_times ) {
    if ( number_of_times == 0x20 ) return input;
    for ( int i = 0; i < number_of_times; i++ ) {
      input = input * 2;
    }
    return input;
  }

//------------------------------------------------------------------------------

  DWORD SHR( DWORD input, BYTE number_of_times ) {
    if ( number_of_times == 0x20 ) return input;
    for ( int i = 0; i < number_of_times; i++ ) {
      input = input DIV 2;
    }
    return input;
  }

//------------------------------------------------------------------------------

