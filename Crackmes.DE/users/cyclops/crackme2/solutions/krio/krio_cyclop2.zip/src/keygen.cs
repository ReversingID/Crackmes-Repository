//
// keygen for cyclops' crackme v2.0 by krio (x) 2005
//
// note: sorry, guys, that was the only compiler on my machine! ;) get framework!
//
// compile: csc keygen.cs
//
using System;

class Keygen {

        static void Main()
        {
                string          sName;
                int[]           iName;
                int             iSerial, i;

                Console.WriteLine("---------------------------------------------------");
                Console.WriteLine(" Keygen for Cyclops' Crackme v2.0 by kRio (C) 2005");
                Console.WriteLine("---------------------------------------------------\n");
                Console.Write(" [o] Enter your name: ");

                sName = Console.ReadLine();
                sName = sName.ToLower();

                iName = new int[sName.Length];

                for(i = 0; i < iName.Length; i++)
                {
                        if (iName.Length % 2 == 0)
                        {
                                if (i % 2 == 0)
                                        iName[i] += (int) sName[i] + i;
                                else
                                        iName[i] += (int) sName[i] + (i >> 1);
                        }
                        else
                        {
                                if (i % 2 == 0)
                                        iName[i] += (int) sName[i] + (i >> 1) + 10;
                                else
                                        iName[i] += (int) sName[i] + i + 5;
                        }
                }

                iSerial = 0;

                for(i = 0; i < iName.Length; i++)
                {
                        iSerial += iName[i] * 0x8E;
                }

                Console.WriteLine(" [o] Your serial is: " + iSerial.ToString());
                Console.ReadLine();
        }
}
