#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>

int part1, part2, part3, part4;
char str_part1[30]="";
char str_part2[30]="";
char username[20]="";
char key[40];

void key_part1(){
	__asm{
	XOR ECX,ECX
	MOV EDX,0x1
	LEA EDI,username 
	MOV AL,BYTE PTR DS:[EDI] 
	loopbegin:
		MOVSX EAX,AL 
		MOV ESI,EAX 
		IMUL EAX,EDX 
		XOR ESI,0x32142001 
		XOR EDX,EDX
		ADD ECX,ESI
		MOV EBX,0x7
		OR EAX,ECX
		MOV ESI,EAX
		DIV EBX
		MOV EBX,0x5
		ADD EDX,0x2
		IMUL ECX,EDX
		MOV EAX,ECX
		XOR EDX,EDX
		DIV EBX
		MOV AL,BYTE PTR DS:[EDI+1] 
		ADD EDX,0x3 
		IMUL EDX,ESI
		INC EDI 
		TEST AL,AL
		JNZ loopbegin
	MOV part1,ECX
	MOV part2,EDX
	}
sprintf(str_part1, "%08X-%08X", part1, part2);
}

void key_part2(){
	__asm{
	PUSH EBP
	MOV ECX,1
	LEA EBX,username
	MOV AL,BYTE PTR DS:[EBX]
	XOR ESI,ESI
	XOR EDI,EDI
	loopbegin:
		MOVSX EAX,AL
		MOV EDX,EAX
		IMUL EAX,ECX
		OR EDX,0xF001F001
		MOV ECX,EAX
		SUB ESI,EDX
		XOR EDX,EDX
		MOV EBP,0x7
		LEA EAX,DWORD PTR DS:[ECX+ESI]
		OR ECX,ESI
		ADD EDI,EAX
		MOV EAX,EDI
		DIV EBP
		MOV EAX,EDI
		MOV EBP,0x0B
		ADD EDX,0x3
		IMUL ECX,EDX
		XOR EDX,EDX
		ADD ECX,EDI
		DIV EBP
		MOV AL,BYTE PTR DS:[EBX+1]
		ADD EDX,0x2
		IMUL EDX,ESI
		ADD EDX,EDI
		INC EBX
		TEST AL,AL
		MOV ESI,EDX
		JNZ loopbegin
	MOV part3,EDX
	MOV part4,ECX
	POP EBP
	}
sprintf(str_part2, "%08X-%08X", part3, part4);	
}
int main(){
printf("Keygen for -NTS-Crackme5 by Cyclops \nwritten by Sir_Edmar (knallerbse@gmail.com)\n\nInput username (at least 7 charakters): ");
scanf("%s",&username);
key_part1(); 
key_part2();
sprintf(key, "%s+%s\n", str_part1, str_part2);
printf("%s",key);
return 0;
}
