CLR SerialMe 0x01 By Cyclops
http://cyclops.ueuo.com

I was bored on a friday night, and coded this one in a snap.
It is a serial me, ie; u have to find a correct serial/serials :)

Rules: NO Patching, NO brute forcing.

It is farly simple, and can be rated some 2 or 3.

Thanx to ARA for the idea, though he was scratching his head for almost 20 mins.

Regards,
-Cyclops
-Mera Bharath Mahan