//Solution to the crackmes.de challenge CALYPSO by cyclops
//by - josh -

#include "stdafx.h"
#include "calypsokeygen.h"
#include <stdio.h>

#define MAX_LOADSTRING 100
INT_PTR CALLBACK DlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

// Global Variables:
HINSTANCE hInst;								// current instance
TCHAR szTitle[MAX_LOADSTRING];					// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];			// the main window class name

// Forward declarations of functions included in this code module:
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);

	char _41ce70;
	char  _41ce74[] = "1316245978031297";
	short _41ce86 = 0;
	short _41ce88 = 0;
	short _41ce8a = 0;

	short _41ce8c = 0;
	short _41ce8e = 0;
	short _41ce90 = 0;
	short _41ce94[8];
	int _41cea4 = 0;
	short _41cea6 = 0;
	int _41cea8 = 0;
	int _41ceac = 0;
	int _41ceae = 0;
	int _41ceb0 = 0;

	DWORD	crc32_table[256];				// Lookup table array

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

 	// TODO: Place code here.
	MSG msg;
	HACCEL hAccelTable;

	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_CALYPSO, szWindowClass, MAX_LOADSTRING);

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow))
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_CALYPSO));

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0))
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return (int) msg.wParam;
}



BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   hInst = hInstance; // Store instance handle in our global variable

   INT_PTR ip = DialogBox(hInst, MAKEINTRESOURCE(IDD_DIALOG1), 0, DlgProc);


   return FALSE;
}

void initHashGlobals()
{
	_41ce86 = 0;
	_41ce88 = 0;
	_41ce8a = 0;

	 _41ce8c = 0;
	 _41ce8e = 0;
	 _41ce90 = 0;
	_41cea4 = 0;
	_41cea6 = 0;
	_41cea8 = 0;
	_41ceac = 0;
	_41ceae = 0;
	_41ceb0 = 0;
}

//
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
INT_PTR CALLBACK DlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	const int len = 100;
	//UNREFERENCED_PARAMETER(lParam);
	
	DWORD tickCount = GetTickCount();
	DWORD tickCount2 = 0;
	int inputId = 0;
	BOOL retTrue = FALSE;

	switch (message)
	{
	case WM_INITDIALOG:
		SetDlgItemText(hDlg, IDC_EDIT1, (LPCTSTR)"123456");
		SetDlgItemText(hDlg, IDC_EDIT2, (LPCTSTR)"");
		SetWindowText(hDlg, "josh's Keygen for cyclops' CALYPSO");
		return (INT_PTR)TRUE;

	case WM_COMMAND:
	if  (LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			retTrue = TRUE;
			break;
			//return (INT_PTR)TRUE;
		}

		//
		//Get Input id
		//
		if ((LOWORD(wParam) == IDC_BUTTON1 && HIWORD(wParam) == BN_CLICKED) ||
			(LOWORD(wParam) == IDOK))
		{
			const int maxNameLen = 0x100;
			const int maxKeyLen = 0x100;
			char name[maxNameLen+1];
			memset(name, 0, maxNameLen+1);
			char key[maxKeyLen+1];
			memset(key, 0, maxKeyLen+1);
			//limit the name length
			int namelen = GetDlgItemText(hDlg, IDC_EDIT1, (LPSTR)name, maxNameLen);
			if (namelen == 0)
			{
				MessageBox(hDlg, "Please enter a name!",0,0);
			}

			init_CRC32_Table();
			initHashGlobals();

			// hash the name twice
			char nameHash1[0x100]; //
			memset(nameHash1, 0, 0x100);
			int result = hash1(name, nameHash1, 0);//123456 -> "F1AD203B-D038866A-D17A5E15-CAFFD8A7"

			char nameHash2[0x100];
			memset(nameHash2, 0, 0x100);
			//hash the name a second time
			result = hash2(name, nameHash2);//123456 ->  "92CC85F9E05F3572CF24D814CA485B334F17165B76781F0F3CD7FCF9F0289D24"	
			
			//The complete hashed name has to be appended later with the crc value
			char hashedName[0x100];
			memset(hashedName, 0, 0x100);
			sprintf(hashedName, "%s-%s", nameHash1, nameHash2);
			
			//markov compress the hashed name
			BYTE hashedNameMarkovCompressed[0x100];
			memset(hashedNameMarkovCompressed, 0, 0x100);
			int compressedLength;
			markovCompress(hashedName, strlen(hashedName),hashedNameMarkovCompressed, &compressedLength);

			int len = compressedLength;
			int rem = len % 3;
			if (rem != 0)
			{
				rem = 3-rem;
				while (rem-- != 0)
					hashedNameMarkovCompressed[len++] = 0; //to ensure dividabilty by three, to avoid padding

			}

			//test expand
			BYTE buf[0x1000];
			int maxLen = 0x500;
			memset (buf, 0, 0x1000);
			if ((markovExpand(hashedNameMarkovCompressed, (char*)buf, maxLen)< 0))
			{
				MessageBox(0, "Compression Error", 0, 0);
				break;
			}
			if (strcmp((char*)buf, hashedName))
			{
				MessageBox(0, "Compression Error", 0, 0);
				break;
			}

			//3 binary bytes ->4 ascii bytes
			base64_encode((BYTE*)hashedNameMarkovCompressed,len, key);

			memset (buf, 0, 0x1000);
			//test 4ascii -> 3 binary
			base64_decode(key, (char*)buf);

			bool error = false;
			for (int i=0; i < len; i++)
			{
				if (buf[i] != hashedNameMarkovCompressed[i])
				{
					MessageBox(0, "base64 Error", 0, 0);
					error = true;
					break;
				}
			}
			if (error)
				break;

			char HashedName_Key[0x200];
			memset(HashedName_Key, 0, 0x200);
			sprintf(HashedName_Key, "%s%s", hashedName, key);
			DWORD crc = calcCRC((const BYTE*)HashedName_Key, strlen(HashedName_Key));
			sprintf(key, "%s-%lX", key, crc); 
			SetDlgItemText(hDlg, IDC_EDIT2, (LPCTSTR)key);

		}

		break;

		default:
			//DefWindowProc(hDlg, message, wParam, lParam);
		break;

	}
	return (INT_PTR)FALSE;
}

//Dynamic markov expansion
//http://plg1.cs.uwaterloo.ca/~ftp/dmc/dmc.c, modified
int markovExpand(BYTE* in, char* out, int maxLen)
{
	BYTE curOut;
	int numOut;
	int val = 0; //int v_820_calc2 = 0;
	int curIx = 0;
	int var_800[0x200];
	int var_400[0x200];
	for (int i=0; i < 0x200; i++)
	{
		var_400[i] = 1;
		var_800[i] = 1;
	}
	int _mid = 0;
	int _min = 0;
	int _max = 0x1000000;

	DWORD in0 = (BYTE)in[0]*0x10000;
	DWORD in1 = (BYTE)in[1]*0x100;
	DWORD in2 = (BYTE)in[2];
	val = in0+in1+in2; //initialisierung mit den ersten drei werten

	numOut = 0;
	curIx = 3;

	while(1)
	{
		if (numOut >= maxLen)
			return -1;
		curOut = 0;
		if (_max -1 == val)
		{
			out[numOut] = 0;	
			return 0;
		}
		int tabBasePos[8] = {1, 2, 4, 8, 0x10, 0x20, 0x40, 0x80};

		for (int i=0; i < 8; i++)
		{
			//tabBase[i] is identical 1 << i;
			int tabIx = tabBasePos[i] + curOut - 1; 
			int tabVal = var_800[tabIx];
			int tabSum = var_400[tabIx] + var_800[tabIx];

			double predict = (double)tabVal / (double)tabSum;
			double tmp3 = _min + (_max-_min-1 ) * predict;
			_mid = int(tmp3);

			if (_mid == _min) 
				_mid++;
			if (_mid == _max-1)
				_mid--;
				
			int bitVal;
			if(val < _mid)
			{
				bitVal = 0;
				_max = _mid;
				var_800[tabIx]++; //Count all 0-bits
			}
			else
			{
				bitVal = 1;
				_min = _mid;
				var_400[tabIx]++; //Count all 1-bits
			}

			//write next bit
			curOut = curOut*2 + bitVal;

			if (_max-_min < 0x100) 
			{
				do
				{
					//##if(bitVal)_max--;
					_max--;
					val = (val& 0xffff) * 0x100 + (BYTE)in[curIx++];
					_min  = (_min & 0xffff)  * 0x100;	//acht nach links
					_max = ((_max << 8) & 0xffff00 ) ;
					if (_min >= _max)
						_max = 0x1000000;
				}
				while ( (_max - _min) < 0x100 );
			}
		}
		out[numOut++] = curOut;
	}
}
//http://plg1.cs.uwaterloo.ca/~ftp/dmc/dmc.c
void markovCompress(char* in, int numIn, BYTE* out, int* outLen)
{
	numIn =  strlen(in);

	int var_800[0x200];
	int var_400[0x200];
	for (int i=0; i < 0x200; i++)
	{
		var_400[i] = 1;
		var_800[i] = 1;
	}
	int _mid = 0;
	int _min = 0;
	int _max = 0x1000000;

	int inCnt = 0;
	int outCnt = 0;
	BYTE curOut = 0;

	for(;;)
	{
		if (inCnt == numIn)
		{
			_min = _max - 1;
			break;
		}
		BYTE c = in[inCnt++];

		int tabBaseIx[8] = {1, 2, 4, 8, 0x10, 0x20, 0x40, 0x80};

		BYTE tmpval = 0;	//reset of the state machine, necessary in this implementation
		int bit = 0;
		for (int i=0; i < 8; i++)	// i: var_814
		{
			//Preserve the order of the next two lines!!
			int tabIx = tabBaseIx[i] + tmpval - 1; 
			tmpval = (c >> (7-i));

			int tabVal = var_800[tabIx];
			int tabSum = var_400[tabIx] + var_800[tabIx];

			double predict = (double)((double)tabVal / (double)tabSum);
			double tmp3 = _min + (_max-_min-1 ) * predict ;
			_mid = int(tmp3);

			if (_mid == _min)
				_mid++;
			if (_mid == _max-1)
				_mid--;

			bit = (c << i) & 0x80;	//MSBit
			if(bit)
			{
				_min = _mid;
				var_400[tabIx]++; //Count all 1-bits
			}
			else
			{
				_max = _mid;
				var_800[tabIx]++; //Count all 0-bits
			}

			if (_max - _min < 0x100) //d.h im Byte-range
			{
				do
				{
					//##if(bit)_max--; //this is from the standard implementation 
					_max--;
					curOut = _min >> 16;
					out[outCnt++] = curOut;
					_min  = (_min & 0xffff)  * 0x100;	//acht nach links
					_max = ((_max << 8) & 0xffff00 ) ;
					if (_min >= _max)
						_max = 0x1000000;
				}
				while ( (_max - _min) < 0x100 );
			}
		}
	}
	out[outCnt++] = _min>>16;
	out[outCnt++] = _min>>8 & 0xff;
	out[outCnt++] = _min & 0xff;
	*outLen = outCnt;
}


void initBase64Table(BYTE* p)
{
	memset (p, 0, 0x83);
	p+= 0x2b;

	*p++ = 0x7c; *p++ = 0x24;  *p++ = 0x24; *p++ = 0x24;*p++ = 0x7d;
	for (int i=0; i < 10; i++)
		*p++ = 0x72+i;

	for (int i=0; i < 7; i++)
		*p++ = 0x24;

	for (int i=0; i < 26; i++)
		*p++ = 0x3e+i;

	for (int i=0; i < 6; i++)
		*p++ = 0x24;

	for (int i=0; i < 26; i++)
		*p++ = 0x58+i;


}

void base64_decode(char* in, char* out)
{
	BYTE _41644d[0x83];
	initBase64Table(_41644d);


	if (strlen(in) == 0)
		return;

	BYTE* table = _41644d;
	int ctr = 0;
	BYTE tmpAr[4];
	int outCtr = 0;
	//402347
	for (int i=0; i < strlen(in); i++)	//the key characters (unitl first hyphen)
	{
		BYTE c = (BYTE)in[i];
		if (c < 0x2b  || c > 0x7a) //'+', 'z' : range of the key characters
			c = 0;
		else
		{
			//402356
			BYTE tabVal = table[ in[i] ];		//the key characters are indices into the table
			if (tabVal != 0)	// else goto _402374;
			{
				if (tabVal ==  0x24) // '$'
					c = 0;
				else
					c = tabVal + 0xc3;
			}
			c--;

			tmpAr[ctr] = c;
			ctr = (ctr + 1) % 4;	//treat every four values together

			if (ctr == 0)
			{
				BYTE tmpOut[4];
				memset (tmpOut, 0, 4);
				base64Compress(tmpAr, tmpOut);
				for (int k =0; k < 3; k++)
					out[outCtr++] = tmpOut[k];

			}
		}
	}
}

//each 3 bytes input -> 4 bytes output
void base64_encode(BYTE* in, int len, char* out)
{
	const int tabsize = 0x83;
	BYTE table[tabsize];
	initBase64Table(table);

	int outCtr = 0;

	int ctr = 0;
	BYTE tmpAr[4];
	

	for (int i=0; i < len; i++)	//the key characters (unitl first hyphen)
	{
		BYTE c = (BYTE)in[i];
		{
			tmpAr[ctr] = c;
			ctr = (ctr + 1) % 3;	//treat every three values together

			if (i == len-3)
				int t = 123;
			if (ctr == 0)
			{
				BYTE tmpOut[5];
				memset (tmpOut, 0, 5);
				base64Expand(tmpAr, tmpOut);
				for (int k=0; k < 4; k++)
				{
					char cc = tmpOut[k];
					cc++;
					cc -= 0xc3;
					//search the table for this value
					char foundVal = 0;
					for (int r = 0; r < tabsize; r++)
					{
						if (table[r] == cc) //found
						{
							foundVal = r;
							break;
						}
					}
					out[outCtr++] = foundVal;
				}
			}
		}
	}
}

void base64Compress(BYTE* in, BYTE* out)
{
	out[0] = (in[0] << 2) | (in[1] >> 4);
	out[1] = (in[1] << 4) | (in[2] >> 2);
	out[2] = (in[2] << 6) | (in[3]);
}

//3 in, 4 out
void base64Expand(BYTE* in, BYTE* out)
{
	out[3]  = in[2] & 0x3f;		   //6 bits	
	out[2]  = (in[2] & 0xc0) >> 6; //2 bits
	out[2] |= (in[1] & 0x0f) << 2; //4 bits

	out[1]  = (in[1] & 0xf0) >> 4;	//4 bits
	out[1] |= (in[0] & 0x03) << 4;	//2 bits

	out[0]  = (in[0] & 0xfc) >> 2;  //6 bits

}


void sub_4022e0(BYTE* in, BYTE* out)
{
	BYTE _cl = in[0];
	BYTE _dl = in[1];
	_cl <<= 2;
	_dl >>= 4;
	_cl |= _dl;
	out[0] = _cl;

	BYTE dd = in[1]*16 + in[2]/4;
	out[1] = dd;

	BYTE ee = in[2]*64 + in[3];
	out[2] = ee;
	int i=123;

}


int hash2(char* name,  char* arg_4)
{
	char var_2c[0x20];
	//401fb8
	strcpy (_41ce74 , "1316245978031297");
	memset (var_2c, 0, 0x20);
	if (name[0] == 0)
		;//goto 40203a
	char* p = name;		//arg_0 als lfd. ptr
	_41ce70 = *p++;		//_41ce70
	int _esi = 0;

	do
	{
		sub_401d90();	//401fce
		short _ax = _41ce8c;
		char _bl = _41ce70;
		short _dx = 0;
		short ctr = 0x10; //401fe1
		*((char*)&_dx) = HIBYTE(_ax);
		_ax &= 0xff;
		_41ce8a = _dx;
		_41ce88 = _ax;
		_41ce86 = ctr;

		for (int i=0; i < ctr; i++)	//402006
			_41ce74[i] ^= _bl;

		*((char*)&_ax) ^= LOBYTE(_dx);
		*((char*)&_dx) = var_2c[_esi++];
		_bl ^= LOBYTE(_ax);
		*((char*)&_dx) ^= _bl;
		_41ce70 = _bl;
		var_2c[_esi-1] = LOBYTE(_dx);
		
		if (_esi >= 0x20)
			_esi = 0;
		_41ce70 = *p++;
	}
	while (_41ce70 != 0);

	for (int i=0; i < 0x420; i++)
	{
		char _bl = var_2c[_esi];
		if (_esi == 0)
			int i=999;
		_41ce70 = _bl;
		sub_401d90();
		short _ax = _41ce8c;
		short _cx = 0;
		*((char*)&_cx) = HIBYTE(_ax);
		_ax &= 0xff;
		_41ce8a = _cx;
		_41ce88 = _ax;
		char* _edi = _41ce74;

		for (int i=0; i < 0x10; i++)
			_41ce74[i] ^= _41ce70;

		
		*((char*)&_ax) ^= LOBYTE(_cx);//402093
		*((char*)&_cx) = _41ce70;
		*((char*)&_cx) ^= LOBYTE(_ax);
		_bl ^= LOBYTE(_cx);
		var_2c[_esi++] = _bl;
		_41ce70 = LOBYTE(_cx);
		if (_esi == 0x20)
			_esi = 0;

	}
	int _ebx = 0;

	//var_2c --> hex-ascii character string
	for (int i=0; i < 0x20; i++)
		sprintf(&arg_4[2*i], "%02X", unsigned char(var_2c[i]));

	return 1;
}

void sub_401d90()
{
	short* dst = (short*)_41ce94;
	short _ax = _41ce74[0] & 0xff;
	short _cx = _41ce74[1] & 0xff;
	_ax <<= 8;
	_ax += _cx;
	dst[0] = _ax;
	sub_401cb0();		//401dab

	_ax = _41ce74[2] & 0xff;
	_cx = _41ce74[3] & 0xff;
	short _dx = _41ce90;
	_ax <<= 8;
	_ax += _cx;
	_ax ^= _41ce94[0];
	_41ce8c = _dx;
	_41ce94[1] = _ax;	//401ddb
	sub_401cb0();

	_ax = _41ce74[4] & 0xff;
	_cx = _41ce74[5] & 0xff;
	_dx = _41ce90;
	_41ce8c ^= _dx; //401dfd
	_ax <<= 8;
	_ax += _cx;
	_ax ^= _41ce94[1];
	_41ce94[2] = _ax;	//401e10
	sub_401cb0();

	_ax = _41ce74[6] & 0xff;
	_cx = _41ce74[7] & 0xff;
	_dx = _41ce90;		//401e2b
	_41ce8c ^= _dx;
	_ax <<= 8;
	_ax += _cx;
	_ax ^= _41ce94[2];
	_41ce94[3] = _ax;	//401e10
	sub_401cb0();

	_ax = _41ce74[8] & 0xff;
	_cx = _41ce74[9] & 0xff;
	_dx = _41ce90;		
	_41ce8c ^= _dx;
	_ax <<= 8;
	_ax += _cx;
	_ax ^= _41ce94[3];
	_41ce94[4] = _ax;
	sub_401cb0();		//401e81

	_ax = _41ce74[10] & 0xff;
	_cx = _41ce74[11] & 0xff;
	_dx = _41ce90;		
	_41ce8c ^= _dx;
	_ax <<= 8;
	_ax += _cx;
	_ax ^= _41ce94[4];
	_41ce94[5] = _ax;
	sub_401cb0();		//401eb7

	_ax = _41ce74[12] & 0xff;
	_cx = _41ce74[13] & 0xff;
	_dx = _41ce90;		
	_41ce8c ^= _dx;
	_ax <<= 8;
	_ax += _cx;
	_ax ^= _41ce94[5];
	_41ce94[6] = _ax;
	sub_401cb0();		
	
	_ax = _41ce74[14] & 0xff;
	_cx = _41ce74[15] & 0xff;
	_dx = _41ce90;		
	_41ce8c ^= _dx;
	_ax <<= 8;
	_ax += _cx;
	_ax ^= _41ce94[6];
	_41ce94[7] = _ax;
	sub_401cb0();		

	_dx = _41ce90;		
	_41ce8c ^= _dx;
	_41ce8e = 0;
}

void sub_401cb0()
{
	short _bx = _41ce8e;
	short _ax = _41cea8;
	 short _di = 0;
	short _dx = _bx + _41cea4;
	_di = _bx;
	_41ceae = 0x4e35;
	short _si = _ax;
	short _bp = _41ce94[_di];
	*((short*)&_41ceb0) =_dx;
	*((short*)&_41cea8) = _bp;

	if (_dx != 0)
	{
		//401cf4
		int _eax = _41ceb0;
		int _ecx = _eax * 5;
		_ecx = _ecx*200 + _eax;
		int _edx = _ecx * 5;
		_edx = _eax + _edx*4;
		_dx = _edx & 0xffff;
	}
	int _eax = _41cea8;
	*((short*)&_41ceb0) = _bp;
	int _ecx = _eax * 7;
	_ecx = _ecx * 3;
	_ecx = _eax + _ecx*2;
	_eax = _eax + _ecx *4;
	_eax *= 2;
	_dx  += (short)_eax;
	*((short*)&_41cea6) = (short)_eax;	//401d34
	int i=99;
	*((short*)&_41cea8) = (short)_eax;	//
	_eax = _41ceb0;
	//401d3f
	*(((short*)&_41ceac)) = _dx;	//_41ceac
	_si += _dx;
	_ecx = _eax*5;
	*(((short*)&_41cea8)+1) = _si;	//_41cd4c
	*(((short*)&_41cea4)) = _si;	//_41cd4c
	_ecx *= 5;
	//401d5d
	int _edx = _ecx*5;
	_ecx = _eax + _edx*8;
	_ecx *= 5;
	_eax += _ecx*4 + 1;
	*(((short*)&_41ceb0)) = LOWORD(_eax);	
	*(((short*)&_41ce94)+_di) = LOWORD(_eax);
	*(((short*)&_eax)) ^= _si;
	_bx++;
	_41ce8e = _bx;
	_41ce90 = LOWORD(_eax);

}

//401c60
int hash1(char* name, char* dst, int arg_8)
{
	char var_c[9];
	char var_18[9];
	char var_24[9];
	char var_30[9];
	nameToNumbers(name, var_c, var_24, var_30, var_18, arg_8);
	sprintf(dst, "%s-%s-%s-%s", var_c, var_18, var_24, var_30);
	return 0;
}

//401330
void nameToNumbers(char* name, 
				char* arg_4,
				char* arg_8,
				char* arg_c,
				char* arg_10,
				int arg_14)
{
	int var_4 = 0;
	int var_14,
		var_8,
		var_c,
		var_10;
	if (arg_14 == 0)
	{
		var_14 = 0xdeadbeef;
		var_c = 0xb00bb00b;
		var_8 = 0x1badb002;
		var_10 = 0xca123ca1;
	}
	else
		;//not relevant

	//401381
	// Anti-Debug
	// 4013db

	//... null buffer with sin values

	DWORD* p1 = new DWORD;
	DWORD* p2 = new DWORD;
	DWORD* p3 = new DWORD;
	DWORD* p4 = new DWORD;
	*p1 = var_14;
	*p2 = var_8;
	*p3 = var_c;
	*p4 = var_10;

    char buf[0x41]; //mit sin genullt
	memset(buf, 0, 0x41);

	char nambuf[0x41];
	memset(nambuf, 0, 0x41);
	memset (nambuf, 'C', 0x40);

	memcpy(nambuf, name, strlen(name));

	DWORD* mem[4];
	mem[0] = p1;
	mem[1] = p2;
	mem[2] = p3;
	mem[3] = p4;

	int index[16] = {3, 7, 13, 17, 4, 2, 7, 9,
		5, 1, 22, 19, 8,24,21, 30};
	//4014bb

	int ix = 0;
	int bufix = 0;
    //Bei den folgenden Aufrufen wird p1, p2, p3, p4 immer im Kreis als Params rotiert
	for (int i=0; i < 16; i++)
	{
		//sub_4011b0(p1, p2, p3, p4, nambuf[0], 3 ,buf[0]);
		shiftOrAdd(mem[ix%4], mem[(ix+1) %4], mem[(ix+2) %4], mem[(ix+3) %4], nambuf[bufix+i], index[i] ,buf[bufix+i]);
		ix -= 1;
		if (ix < 0)
			ix = 3;
	}

	bufix += 16;
	for (int i=0; i < 16; i++)
	{
		//sub_4011b0(p1, p2, p3, p4, nambuf[0], 3 ,buf[0]);
		shiftOrAdd_2(mem[ix%4], mem[(ix+1) %4], mem[(ix+2) %4], mem[(ix+3) %4], nambuf[bufix+i], index[i] ,buf[bufix+i]);
		ix -= 1;
		if (ix < 0)
			ix = 3;
	}

	bufix += 16;
	for (int i=0; i < 16; i++)
	{
		//sub_4011b0(p1, p2, p3, p4, nambuf[0], 3 ,buf[0]);
		shiftOrAdd_3(mem[ix%4], mem[(ix+1) %4], mem[(ix+2) %4], mem[(ix+3) %4], nambuf[bufix+i], index[i] ,buf[bufix+i]);
		ix -= 1;
		if (ix < 0)
			ix = 3;
	}

	bufix += 16;
	for (int i=0; i < 16; i++)
	{
		//sub_4011b0(p1, p2, p3, p4, nambuf[0], 3 ,buf[0]);
		shiftOrAdd_4(mem[ix%4], mem[(ix+1) %4], mem[(ix+2) %4], mem[(ix+3) %4], nambuf[bufix+i], index[i] ,buf[bufix+i]);
		ix -= 1;
		if (ix < 0)
			ix = 3;
	}
	DWORD result = *mem[(ix+1) %4];
	var_8 += result;
	var_c += *mem[(ix+2) %4];
	var_10 += *mem[(ix+3) %4];
	var_14 += *mem[(ix+4) %4];
	int i=233;

	sprintf(arg_4, "%lX", var_14);
	sprintf(arg_8, "%lX", var_8);
	sprintf(arg_c, "%lX", var_c);
	sprintf(arg_10, "%lX", var_10);

}

//4011b0
void shiftOrAdd(DWORD* p1,	//input und result
				DWORD* p2,	//bleibt const
				DWORD* p3,	//bleibt const
				DWORD* p4,  //bleibt const 	
				char cnam,  //one name character
				int cnst,   //some constant
				char cbuf)  //one buf character
{
	DWORD result		= (DWORD)a_and_b_orLSB_c(*p2, *p3, *p4);
	DWORD sum			= *p1 + result + cnam + cbuf ;
    DWORD shiftVal	= 0x20 - cnst;
	DWORD valLeft  = sum << shiftVal;
	DWORD valRight = sum >> cnst;

	DWORD val = valLeft | valRight;
	val += *p2;

	*p1 = val;
}

//401210
void shiftOrAdd_2(DWORD* p1,	//input und result
				DWORD* p2,	//bleibt const
				DWORD* p3,	//bleibt const
				DWORD* p4,  //bleibt const 	
				char cnam,  //one name character
				int cnst,   //some constant
				char cbuf)  //one buf character
{
	DWORD result		= (DWORD)a_and_b_or_c_withLSBB(*p2, *p3, *p4);
	DWORD sum			= *p1 + result + cnam + cbuf ;
    DWORD shiftVal	= 0x20 - cnst;
	DWORD valLeft  = sum << shiftVal;
	DWORD valRight = sum >> cnst;

	DWORD val = valLeft | valRight;
	val += *p2;

	*p1 = val;
}

//401210
void shiftOrAdd_3(DWORD* p1,	//input und result
				DWORD* p2,	//bleibt const
				DWORD* p3,	//bleibt const
				DWORD* p4,  //bleibt const 	
				char cnam,  //one name character
				int cnst,   //some constant
				char cbuf)  //one buf character
{
	DWORD result		= a_xor_b_xor_c(*p2, *p3, *p4);
	DWORD sum			= *p1 + result + cnam + cbuf ;
    DWORD shiftVal	= 0x20 - cnst;
	DWORD valLeft  = sum << shiftVal;
	DWORD valRight = sum >> cnst;

	DWORD val = valLeft | valRight;
	val += *p2;

	*p1 = val;
}
//4012d0
void shiftOrAdd_4(DWORD* p1,	//input und result
				DWORD* p2,	//bleibt const
				DWORD* p3,	//bleibt const
				DWORD* p4,  //bleibt const 	
				char cnam,  //one name character
				int cnst,   //some constant
				char cbuf)  //one buf character
{
	DWORD result		= a_and_b_or_c_modifLSB(*p2, *p3, *p4);
	DWORD sum			= *p1 + result + cnam + cbuf ;
    DWORD shiftVal	= 0x20 - cnst;
	DWORD valLeft  = sum << shiftVal;
	DWORD valRight = sum >> cnst;

	DWORD val = valLeft | valRight;
	val += *p2;

	*p1 = val;
}

//sub_401130
DWORD a_and_b_orLSB_c(int v1, int v2 , int v3)
{
	if (v1 == 0)
		return ( (v1 & v2) | (v3 & 1) ); //LSBit von v3

	return ( v1 & v2 );
}
//sub_401150
DWORD a_and_b_or_c_withLSBB(int v1, int v2 , int v3)
{
	if (v3 == 0)
		v2 |= 1; //Set LSB v2

	return (v1 & v2);
	
}
//sub_401190
DWORD a_and_b_or_c_modifLSB(int v1, int v2 , int v3)
{
	if (v3 == 0)
		return ( v2 ^ (v1 & 1) );//modify LSB v2

	return v2; 
	
}
//41170
DWORD a_xor_b_xor_c(int v1, int v2 , int v3)
{
	DWORD val = v1 ^ v2;
	return val ^ v3;
}
// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}
//////////////////////////////////////////////////////////////////////
//Builds Lookup table array
void init_CRC32_Table()
{
	// This is the official polynomial used by CRC-32 
	// in PKZip, WinZip and Ethernet. 
	DWORD ulPolynomial = 0x04c11db7;

	// 256 values representing ASCII character codes.
	for(int i = 0; i <= 0xFF; i++)
	{
		crc32_table[i] = reflect(i, 8) << 24;

		for (int j = 0; j < 8; j++)
			crc32_table[i] = (crc32_table[i] << 1) ^ (crc32_table[i] & (1 << 31) ? ulPolynomial : 0);

		crc32_table[i] = reflect(crc32_table[i], 32);
	}
}			
//////////////////////////////////////////////////////////////////////
// Reflection is a requirement for the official CRC-32 standard.
// Used only by init_CRC32_Table()
DWORD reflect(const DWORD reff, const char ch)
{

	DWORD ref = reff;
	DWORD value(0);

	// Swap bit 0 for bit 7
	// bit 1 for bit 6, etc.
	for(int i = 1; i < (ch + 1); i++)
	{
		if(ref & 1)
			value |= 1 << (ch - i);
		ref >>= 1;
	}
	return value;
}
//////////////////////////////////////////////////////////////////////
DWORD calcCRC( const BYTE* buf, DWORD size)
{
	DWORD crc = 0xffffffff;
	if (size == 0)
		return crc;

	while(size--)
		crc = (crc >> 8) ^ crc32_table[(crc & 0xFF) ^ *buf++];

	crc ^= 0xffffffff;
	return crc;
}
