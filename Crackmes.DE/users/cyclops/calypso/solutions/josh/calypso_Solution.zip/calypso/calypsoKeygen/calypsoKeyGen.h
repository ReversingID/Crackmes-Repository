#pragma once

#include "resource.h"
//401c60
void nameToNumbers(char* name, 
				char* arg_4,
				char* arg_8,
				char* arg_c,
				char* arg_10,
				int arg_14);

void shiftOrAdd(DWORD* p1, 
				DWORD* p2,
				DWORD* p3,
				DWORD* p4,
				char cname,
				int  cnst,
				char cbuf);

void shiftOrAdd_2(DWORD* p1,	//input und result
				DWORD* p2,	//bleibt const
				DWORD* p3,	//bleibt const
				DWORD* p4,  //bleibt const 	
				char cnam,  //one name character
				int cnst,   //some constant
				char cbuf);  //one buf character

void shiftOrAdd_3(DWORD* p1,	//input und result
				DWORD* p2,	//bleibt const
				DWORD* p3,	//bleibt const
				DWORD* p4,  //bleibt const 	
				char cnam,  //one name character
				int cnst,   //some constant
				char cbuf);  //one buf character
void shiftOrAdd_4(DWORD* p1,	//input und result
				DWORD* p2,	//bleibt const
				DWORD* p3,	//bleibt const
				DWORD* p4,  //bleibt const 	
				char cnam,  //one name character
				int cnst,   //some constant
				char cbuf);  //one buf character

DWORD a_and_b_orLSB_c(int v1, int v2 , int v3);
DWORD a_and_b_or_c_withLSBB(int v1, int v2 , int v3);
DWORD a_xor_b_xor_c(int v1, int v2 , int v3);
DWORD a_and_b_or_c_modifLSB(int v1, int v2 , int v3);

void sub_401d90();
void sub_401cb0();
void sub_402320(char* in, char* out);
void sub_4022e0(BYTE* in, BYTE* out);
void initBase64Table(BYTE* p);
void base64_encode(BYTE* in, int len, char* out);
void base64_decode(char* in, char* out);
void base64Expand(BYTE* in, BYTE* out);
void base64Compress(BYTE* in, BYTE* out);
int hash1(char* name, char* dst, int arg_8);
int hash2(char* name,  char* arg_4);
int markovExpand(BYTE* in, char* out, int maxLen);
void markovCompress(char* in, int numIn, BYTE* out, int* outLen);
DWORD calcCRC(char* in);
void init_CRC32_Table();
DWORD reflect(const DWORD reff, const char ch);
DWORD calcCRC(const BYTE* buf, DWORD size);
