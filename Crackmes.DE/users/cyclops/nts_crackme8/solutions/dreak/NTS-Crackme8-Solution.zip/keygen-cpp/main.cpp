#include "sha256.h"
#include <cstdio>
#include <iostream>

void GenerateSerial(char* pName)
{
	SHA256 sha256;
	sha256.write(reinterpret_cast<unsigned char*>(pName), (unsigned int)strlen(pName));
	sha256.final();

	long edx = sha256.ctx.H[6];
	long eax = sha256.ctx.H[4];
	long ebx = sha256.ctx.H[2];
	long ecx = sha256.ctx.H[0];

	edx += eax;
	eax = sha256.ctx.H[7];
	edx += ebx;
	ebx = sha256.ctx.H[5];
	edx += ecx;
	ecx = sha256.ctx.H[1];
	long dwPart2 = edx;

	edx = sha256.ctx.H[3];
	eax += ebx;
	eax += edx;
	eax += ecx;

	printf("%08X%08X\r\n", eax, dwPart2);
}

int main()
{
	char szName[50];
	memset(szName, 0, sizeof(szName));
	std::cout << "Enter a name: ";
	std::cin.getline(szName, 40);
	if (strlen(szName) <= 6)
	{
		std::cout << "Username must be over 6 characters.";
		return 0;
	}
	if (strlen(szName) >= 30)
	{
		std::cout << "Username must be under 30 characters.";
		return 0;
	}
	GenerateSerial(szName);
	system("pause");
	return 0;
}