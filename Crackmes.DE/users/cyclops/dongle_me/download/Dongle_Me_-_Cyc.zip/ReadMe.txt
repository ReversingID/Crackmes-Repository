Dongle Me By Cyclops
--------------------

Acceptable solution: 1. A hardware(you can send it via snail mail..lol). Schematic and a pic/video will do.
2. A custom dongle emulator program.
A separate keygen is much appreciated ;)

Level: It is fairly easy. Both dongle and crypto.

Tested on: XP SP3, Vista x86, Vista x64

Greetings to my friends, especially the ones over #crackmesde on dalnet.
Thanks to Sam for a quick GFX, J&J for HW support.

http://crackmes.de
http://cyclops.ueuo.com