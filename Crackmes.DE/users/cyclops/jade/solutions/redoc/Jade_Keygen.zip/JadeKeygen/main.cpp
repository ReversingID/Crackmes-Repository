#define _CRT_SECURE_NO_WARNINGS
#undef UNICODE
#undef _UNICODE
#include <windows.h>
#include <stdio.h>

#define USELESS_DATA	"dummy"
#define MSG_CAPTION "Jade's Keygen by redoC"
#define SLEEP_INTERVAL	50

bool ComputeSerial (OUT char *szSerial);

const char g_szArbitraryData[64] = "redoC's keygen";	// place any string you want

//------------------------------------
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	char szBuf[256] = {0}, szOctalNumber[16] = {0};
	unsigned long dwBuf;
	HWND hJadeWnd;

	// is jade running?
	if (NULL == (hJadeWnd = FindWindow (NULL, "......................:: Jade ::.....................")))
	{
		MessageBox (NULL, "Run jade.exe first", MSG_CAPTION, 0);
		return (0);
	}

	SetForegroundWindow (hJadeWnd);

	//////////////////////////////////////////////////////////////////////
	// sockets initialization
	WSADATA wsadata;
	if (0 != WSAStartup (MAKEWORD(2,2), &wsadata))
		return (0);
	SOCKET s = socket (AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (s == INVALID_SOCKET) goto err_hand;

	sockaddr_in	addr;
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = inet_addr ("127.0.0.1");	// localhost
	addr.sin_port = htons (8241);

	if (SOCKET_ERROR == connect (s, (sockaddr*)&addr, sizeof(addr)))
		goto err_hand;

	// connection is now established
	unsigned char dataFrom[32];
	Sleep (SLEEP_INTERVAL);
	recv (s, (char*)dataFrom, sizeof(dataFrom), 0);	// HeLlO from jade
	Sleep (SLEEP_INTERVAL);
	send (s, "---...:: [CYc] ::...---", 23, 0);
	Sleep (SLEEP_INTERVAL);
	send (s, g_szArbitraryData, strlen(g_szArbitraryData), 0);	// arbitrary data
	Sleep (SLEEP_INTERVAL);
	int intBuf = recv (s, (char*)dataFrom, sizeof(dataFrom), 0);	// get hex number and convert it to octal
	strncpy (szBuf, (char*)dataFrom, intBuf);
	sscanf (szBuf, "%x", &dwBuf);
	sprintf (szOctalNumber, "%o", dwBuf);
	Sleep (SLEEP_INTERVAL);

	if (!ComputeSerial (szBuf)) goto err_hand;

	send (s, (char*)szBuf, strlen(szBuf), 0);	// send serial
	Sleep (SLEEP_INTERVAL);
	send (s, USELESS_DATA, strlen(USELESS_DATA), 0);	// send dummy data
	Sleep (SLEEP_INTERVAL);
	send (s, szOctalNumber, strlen(szOctalNumber), 0);	// send octal number
	Sleep (SLEEP_INTERVAL);
	send (s, "---...:: [cYC] ::...---", 23, 0);		// bye

	//////////////////////////////////////////////////////////////////////
	// finished
	MessageBox (hJadeWnd, "Registered, now click \'Register\' button.", MSG_CAPTION, 0);

	// quit
	goto quit_hand;
err_hand:
	MessageBox (NULL, "Error occured", MSG_CAPTION, 0);
quit_hand:
	if (s != INVALID_SOCKET) closesocket (s);
	WSACleanup ();
	return (0);
}

//------------------------------------
bool ComputeSerial (char *szSerial)
{
	DWORD dwBuf1, dwBuf2;

	// Checksum1()
	__asm
	{
	XOR EAX,EAX
	XOR EDX,EDX
	LEA EDI, [g_szArbitraryData]
	XOR ESI,ESI
	MOV CL,BYTE PTR DS:[EDI]
	TEST CL,CL
	JE SHORT jump_over
jump_loop:
	MOVSX ECX,CL
	XOR ECX, 0x159753
	MOV EAX,ECX
	ADD EDX,ECX
	OR EAX, 0x237891
	NOT EAX
	AND EAX,ECX
	MOV CL,BYTE PTR DS:[ESI+EDI+1]
	ADD EAX,EDX
	LEA EDX,DWORD PTR DS:[EDX+ESI-1]
	XOR EDX, 0xA6542689
	INC ESI
	TEST CL,CL
	JNZ SHORT jump_loop
jump_over:
	mov	DWORD PTR [dwBuf1], EDX
	mov	DWORD PTR [dwBuf2], EAX
	} //__asm

	sprintf (szSerial, "%08X%08x", dwBuf1, dwBuf2);
	szSerial[16] = '-';

	///////////////////////////////////////////////////////////////
	char szBuf[256] = {0};
	strncpy (szBuf, szSerial, 16);
	strcat (szBuf, g_szArbitraryData);

	BYTE *pHashTable = new BYTE[0x400];
	if (pHashTable == NULL) return false;

	// fill hash table
	__asm
	{
	XOR EDX,EDX
	XOR EBX,EBX
	MOV ECX, pHashTable
jump_loop2:
	MOV EAX,EDX
	MOV ESI,8
jump_loop1:
	TEST AL,1
	JE SHORT jump1
	SHR EAX,1
	XOR EAX, 0xEDB88320
	JMP SHORT jump2
jump1:
	SHR EAX,1
jump2:
	DEC ESI
	JNZ SHORT jump_loop1
	MOV DWORD PTR DS:[ECX],EAX
	ADD ECX,4
	ADD EBX,4
	INC EDX
	CMP EBX, 0x400		// CMP ECX, (pHashTable + 0x400)
	JL SHORT jump_loop2
	} //__asm

	// Checksum2()
	__asm
	{
	LEA EDX, [szBuf]
	OR EAX, 0xFFFFFFFF
	MOVSX ECX,BYTE PTR DS:[EDX]
	TEST ECX,ECX
	JE SHORT jump3
	INC EDX
jump_loop3:
	XOR ECX,EAX
	AND ECX, 0x0FF
	SHR EAX,8
	LEA ECX, DWORD PTR DS:[ECX*4]
	ADD ECX, pHashTable
	MOV ECX, [ECX]
	XOR EAX,ECX
	MOVSX ECX,BYTE PTR DS:[EDX]
	INC EDX
	TEST ECX,ECX
	JNZ SHORT jump_loop3
jump3:
	NOT EAX
	MOV	DWORD PTR [dwBuf1], EAX
	} //__asm

	delete[] pHashTable;

	sprintf (&szSerial[17], "%x", dwBuf1);
	szSerial[25] = 0;
	return true;
}