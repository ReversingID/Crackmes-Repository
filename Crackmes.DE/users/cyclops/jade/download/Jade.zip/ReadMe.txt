					Jade
					----
					 By
				       CYclops
-------------------------------------------------------------------------------------------------

		..::: Rating........... [   2  ] :::..

		..::: Packed........... [   N  ] :::..
		
		..::: Compiler......... [ VC++ ] :::..
	
		..::: Coder............ [  CYC ] :::..

-------------------------------------------------------------------------------------------------

Info
----

	The serial calculation is lame, but itz some thing diff from usual one.
	U need to install VC++ (atleast mfc42.dll ) to run the crackme.
	I have tested it only in WinXp sp2.
	Only Solution is a keygen ;-)
	Send the sol to cyclops1428@yahoo.com

-------------------------------------------------------------------------------------------------

Rulz
----

	1. No patching.
	2. No Self KeyGen.
	3. No Loaderz.

-------------------------------------------------------------------------------------------------

Greetz
------

	mario/MBE, Taliesin, m0rph3us and all at AIT and all at crackmes.de !!!