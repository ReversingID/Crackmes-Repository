import string
import random
import math


def s_generator(size=6, chars=string.ascii_uppercase + string.ascii_lowercase + string.digits):
	"""
	random string generator ripped from stackoverflow: 
	https://stackoverflow.com/questions/2257441/random-string-generation-with-upper-case-letters-and-digits-in-python
	"""

	return ''.join(random.choice(chars) for _ in range(size))


def calc_serial_value(serial):
	"""
	Generates the numeric value corresponding to 
	a serial number
	"""
	l = len(serial) - 1

	serial_value = 0
	while l >= 0:
		char = serial[l]

		if not char.isalnum():
			return False

		serial_value += ord(char) % (l+9)

		l-=1

	return serial_value

def gen_serial(user):

	"""
	Generates a serial given the user.
	Basically it uses bruteforce, exact complexity depends roughly on
	user length, with spare exceptions.
	"""


	"""
	calculate a numeric value from the user name
	"""
	user_value = 0

	c = len(user) - 1
	while c >= 0:
		char = user[c]

		if not char.isalpha():
			return False

		ipq = ((c+1) * (c+1)) & 0xffffffff

		user_value += ipq % (ord(char) + (c-1))

		c-=1



	"""
	generate random serials of all valid lengths,
	until the corresponding numeric value equals the
	one generated from the username
	"""
	while True:

		for a_size in range(10,51,10):
			trial = s_generator(size=a_size)
			if calc_serial_value(trial) == user_value:
				return trial


	return False


def gen_name(length):
	"""
	Generates funny pseudo-realistic person names.
	"""

	c = [['b','c','d','f','g','l','m','n','p','r','s','t','v','z'],['a','e','i','o','u']]

	split = -1
	if len>5:
		split = math.ceil(length/4) * 2

	name = [" "] * length
	for i in range(length):
		l = c[i%2]
		idx = random.randrange(len(l))
		name[i] = l[idx]

		if i==0 or i ==split:
			name[i] = name[i].upper()

	return "".join(name)

if __name__ == '__main__':

	print "Generating 100 valid logins...\n"

	for i in xrange(100):
		# keeping username length in a reasonable range
		username = gen_name(random.randint(10,14))
		print "Username: " + username
		serial = gen_serial(username)

		if not serial:
			print "Invalid user name"
		else:
			print "Serial: " + serial
		
		print ""