#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <windows.h>

using namespace std;

char* call1(char* key);
char* loop(int k, char* sorted, char* key);
char* call2(const char* name, int len);
bool check(char* ans1, char* ans2);
void printKey(int k, char* key);

//Program entry
int main(int argc, char* args[])
{
    const char* name;

    char* sorted = new char[8];
    char* key = new char[8];
    char* crc = new char[8];
    char* ans = new char[8];

    //Input
    string str;
    while(true)
    {
        
        cout << "Enter name: ";
        getline(cin, str);
        if(!str.empty()) break;
    }
    name = str.c_str();

    //Tranform
    crc = call2(name, (int) strlen(name));
    sorted = call1(crc);

    cout << "Possible keys:" << endl;

    //Permutations
    vector<char> v;
    for(int i=0;i<8;i++) v.push_back(sorted[i]);

    while(next_permutation(v.begin(), v.end()))
    {
        copy(v.begin(), v.end(), key);

        for(int k=0;k<7;k++)
        {
            ans = loop(k, sorted, key);
            if(check(ans, crc)) printKey(k, key);
        }
    }

    cout << "Done." << endl;
    string exit; getline(cin, exit);
    return 0;
}

//Key Transformation (1)
char* call1(char* key)
{
    char* sorted = new char[9];
    ZeroMemory(sorted, sizeof(char)*9);

    //Copy
    for(int i=0;i<8;i++)
        sorted[i] = key[i];

    //Sort
    sort(sorted, sorted+8);

    return sorted;
}

//Key Transformation (2)
char* loop(int k, char* sorted, char* key)
{
    char* ans = new char[9];
    ZeroMemory(ans, sizeof(char)*9);

    char X = k;
    for(int i=0;i<8;i++)
    {
        char C = sorted[X];
        ans[i] = C;

        //Loop 1
        int Num = 0;
        for(int j=0;j<X;j++)
        {
            if(X==0) break;
            if(sorted[j]==C) Num++;
        }

        //Loop 2
        X = 0;
        while(X<8)
        {
            if(key[X]==C)
            {
                if(Num==0) break;
                Num--;
            }
            X++;
        }
    }

    return ans;
}

//Name transformation
char* call2(const char* name, int len)
{
    char* ans = new char[9];
    ZeroMemory(ans, sizeof(char)*9);

    int hex;

    __asm
    {
        PUSH EBX
        PUSH ECX
        PUSH EDX
        PUSH ESI
        PUSH EDI
        MOV ESI,DWORD PTR SS:[EBP+0x8]
        MOV EDI,DWORD PTR SS:[EBP+0xC]
        MOV ECX,-1
        MOV EDX,ECX
label1:
        XOR EAX,EAX
        XOR EBX,EBX
        LODS BYTE PTR DS:[ESI]
        XOR AL,CL
        MOV CL,CH
        MOV CH,DL
        MOV DL,DH
        MOV DH,0x8
label2:
        SHR BX,0x1
        RCR AX,0x1
        JNB label3
        XOR AX,0x8320
        XOR BX,0x0EDB8
label3:
        DEC DH
        JNZ label2
        XOR ECX,EAX
        XOR EDX,EBX
        DEC EDI
        JNZ label1
        NOT EDX
        NOT ECX
        MOV EAX,EDX
        ROL EAX,0x10
        MOV AX,CX
        POP EDI
        POP ESI
        POP EDX
        POP ECX
        POP EBX
        MOV hex, EAX
    }

    //Convert to string
    sprintf(ans, "%08X", hex);

    return ans;
}

//Check answer
bool check(char* ans1, char* ans2)
{
    for(int j=0;j<8;j++)
        if(ans1[j] != ans2[j]) return false;

    return true;
}

//Print key
void printKey(int k, char* key)
{
    cout << k << "-";

    for(int n=0;n<8;n++)
        cout << key[n];

    cout << endl;
}