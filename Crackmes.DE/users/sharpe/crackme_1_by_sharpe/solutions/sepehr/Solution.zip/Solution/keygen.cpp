#include <iostream>
#include <memory>
#include <windows.h>
//if you're using an older version of Visual Studio use <iostream.h> and <memory.h> instead of <iostream> and <memory>
using namespace std;

int main()
{
	char name[50],serial[50];
	long len,i,a;
	memset(&name,NULL,50); //setting the serial buffers to 0
	memset(&serial,NULL,50); //setting the serial buffers to 0
	cout << endl <<"Enter The Name : ";
	cin >> name; // getting the name
	cout << endl;
	len = int(strlen(name)); // getting the lenght of name
	for(i=16;i>0;i=i-1)
	{
		a=long(name[16-i]);
		a=a+i;
		if(a<33)
			a=a+33;
		if(a>123)
			a=int(a/2);
		//{_asm{shr a,1}} can be used instead
		serial[16-i]=char(a);

        }	
	cout << endl <<"Serial : "<< serial << endl;
	return 0;
}