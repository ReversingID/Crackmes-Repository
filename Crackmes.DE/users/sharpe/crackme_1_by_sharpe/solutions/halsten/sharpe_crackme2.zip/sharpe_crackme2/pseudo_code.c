

DialogPROC() {
	[...]

	EAX = [EBP + wParam]
	if (EAX == ID_CHECK_BUTTON) {
		prtint ""
	}
	else {

	}
}

GenerateSerial(int nSerialLength) {
	esi = szSerial;
	edi = szCalculatedSerial;

	ecx = 0x10;
	while (ecx !=0 ) {
		eax = *(esi + ecx);
		call CryptLetter(eax, ecx);
		*(edi + ecx) = eax;
		;edi++;
		;esi++;
		ecx--;
	}
}

CheckUsernameAndSerial() {
	esi = szCalculatedSerial;
	edi = szSerial;
	ecx = 0x10;
	eax = 0;
	do {
		if(*(eax + 0x403100) != *(eax + M004030e0)) {
			eax = MessageBoxA(0, "Sorry but the entered values are incorrect!", szErrorTitle, 0);
		}
		eax = eax + 1;
	} while(ecx != eax);
	MessageBoxA(0, "You have entered valid values!", szWinTitle, 0);
}