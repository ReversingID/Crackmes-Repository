#include <windows.h>


char DlgName[] = "KEYGEN";
char DlgCap[] = "Sharpe's Crackme#2 Keygen";
char err1[] = "Name must be at least 1 char long!!";
const GENERATE = 1;
const NAME = 2;
const SERIAL = 3;
char Name[80]="";
char Serial[80]="";

void GenerateKey(HWND hwnd) {
	unsigned int i=0x10;
	int Len,x;
	unsigned int Char;


	GetDlgItemText(hwnd,NAME,Name,80);
	Len = strlen(Name);
	if (Len < 1) {
		MessageBox(NULL,err1,DlgCap,NULL);
		SetDlgItemText(hwnd,SERIAL,"");
		i=0;
	}
	x = 0;
	while (i>0x0) {
		Char = Name[x];
		Char += i;
		if (Char < 0x21) {
			Char += 0x21;
		}
		if (Char > 0x7B) {
			Char = Char >> 1;
		}
		Serial[x] = Char;
		x++;
		i--;
	}
	SetDlgItemText(hwnd,SERIAL,Serial);
}

BOOL CALLBACK DialogProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
	switch(uMsg) {
	case WM_INITDIALOG:
		SetDlgItemText(hwnd,NAME,"Must be at least 1 char..");
		SetDlgItemText(hwnd,SERIAL,"XXXXXXXXXXXXXX");
		break;

	case WM_CLOSE:
		ExitProcess(0);
		break;
	case WM_COMMAND:
		switch(LOWORD(wParam))
			case GENERATE:
				GenerateKey(hwnd);
				break;
	}
	return FALSE;
}

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	//vars
	HINSTANCE hWnd;

	hWnd = GetModuleHandle(NULL);
    DialogBoxParam(hWnd,DlgName,NULL,DialogProc,NULL);
    ExitProcess(NULL);

	return 1;
}
