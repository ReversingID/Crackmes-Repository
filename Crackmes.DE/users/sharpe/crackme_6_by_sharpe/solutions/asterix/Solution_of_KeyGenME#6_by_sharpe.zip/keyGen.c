#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define  MAX  256

unsigned char hash(char *);

int main(void)
{
    char name[MAX], serial[17], unlock[17];
    unsigned char value, val;
    unsigned len;

    memset(name, 0, MAX);

    printf("KeyGen for [KeyGenME #6 by sharpe] by AsTeRiX\n");   

    printf("\nEnter name: ");
    gets(name);
  
    len = strlen(name);

    if (len < 1 || len > 16) {
	fprintf(stderr, "\nERROR: The name must be between 1 and 16 symbols.\n");
	return 1;
    }

    strcpy(unlock, "0000000000002897");
    value = 0;

    _asm {
		lea     eax, [name+0]
		push    eax
		call	hash
		add     esp, 04h
  		and     eax, 0ffh
		mov     byte ptr [value], al
		lea	edi, [0 + serial]
		mov     ecx, 10h
		mov	byte ptr [val], 0

	loc_40120B:	
			
		mov	al, [value]
		add	al, cl
		mul	al
		add	al, ah
		mov	bl, [val]
		cmp	bl, 1
		jl	short loc_401225
		and	al, 0F0h
		shr	al, 4
		jmp	short loc_401227


	loc_401225:				

		and	al, 0Fh

	loc_401227:				

		neg	bl
		mov	byte ptr [val], bl
		cmp	al, 9
		jle	short loc_401232
		add	al, 7

	loc_401232:				

		add	al, 30h
		mov	[edi], al
		inc	edi
		inc	esi
		dec	ecx
		jnz	short loc_40120B	
		mov     byte ptr [edi], 0
    }    

    printf("\n======== Registration Info =========\n");
    printf("\n     Unlock: %s\n", unlock);
    printf("\n     Name:   %s", name);
    printf("\n     Serial: %s\n", serial);
    printf("\n====================================\n\n");

    system("pause");

    return 0;
}

unsigned char hash(char *name)
{
    unsigned char value;
    unsigned len;

    len = strlen(name);

    value = 0;

    _asm {
		mov	esi, [name]
		mov	ecx, [len]

	m:	
		mov	eax, ecx
		mul	cl
		add	al, ah
		mov	bl, al
		mov	al, [esi]
		mul	bl
		add	al, ah
		add	byte ptr [value], al
		inc	esi
		dec	ecx
		jnz	m
    }

    return value;
}