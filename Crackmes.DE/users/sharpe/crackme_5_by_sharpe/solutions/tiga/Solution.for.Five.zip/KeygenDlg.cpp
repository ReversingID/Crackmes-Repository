// KeygenDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Keygen.h"
#include "KeygenDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CKeygenDlg dialog

CKeygenDlg::CKeygenDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CKeygenDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CKeygenDlg)
	m_sCode = _T("");
	m_sName = _T("");
	m_sSerial = _T("");
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CKeygenDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CKeygenDlg)
	DDX_Control(pDX, IDC_ECODE, m_ctlCode);
	DDX_Control(pDX, IDBGENERATE, m_ctlGenerate);
	DDX_Text(pDX, IDC_ECODE, m_sCode);
	DDV_MaxChars(pDX, m_sCode, 16);
	DDX_Text(pDX, IDC_ENAME, m_sName);
	DDV_MaxChars(pDX, m_sName, 16);
	DDX_Text(pDX, IDC_ESERIAL, m_sSerial);
	DDV_MaxChars(pDX, m_sSerial, 16);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CKeygenDlg, CDialog)
	//{{AFX_MSG_MAP(CKeygenDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_EN_CHANGE(IDC_ENAME, OnChangeEname)
	ON_BN_CLICKED(IDBGENERATE, OnBgenerate)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CKeygenDlg message handlers

BOOL CKeygenDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CKeygenDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CKeygenDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CKeygenDlg::OnChangeEname() 
{
	UpdateData(true);

	if (m_sName.GetLength())
		m_ctlGenerate.EnableWindow(true);
	else
		m_ctlGenerate.EnableWindow(false);
}

void CKeygenDlg::OnBgenerate() 
{
	UpdateData(true);
	

	CString sUnlockCode = "", sBuffer = "";
	int iTotal = 0, iResult = 0, iChar = 0;

	//Part 1 - BruteForcer
	for (char L1 = '0'; (L1 < 'Z') && (iTotal != 37); L1++)
	{
		for (char L2 = '0'; (L2 < 'Z') && (iTotal != 37); L2++)
		{
			for (char L3 = '0'; (L3 < 'Z') && (iTotal != 37); L3++)
			{
				for (char L4 = '0'; (L4 < 'Z') && (iTotal != 37); L4++)
				{
					for (char L5 = '0'; (L5 < 'Z') && (iTotal != 37); L5++)
					{
						for (char L6 = '0'; (L6 < 'Z') && (iTotal != 37); L6++)
						{
							for (char L7 = '0'; (L7 < 'Z') && (iTotal != 37); L7++)
							{
								for (char L8 = '0'; (L8 < 'Z') && (iTotal != 37); L8++)
								{
									sUnlockCode = "";
									sUnlockCode += L1;
									sUnlockCode += L2;
									sUnlockCode += L3;
									sUnlockCode += L4;
									sUnlockCode += L5;
									sUnlockCode += L6;
									sUnlockCode += L7;
									sUnlockCode += L8;
									
									iTotal = 0;
									for (int i = 16; i > 0; i--)
									{
										int iChar = 0, iResult = 0, iTemp1 = 0, iTemp2 = 0;

										iResult = i * i;
										iResult += iResult / 256;
										if ((16 - i) < sUnlockCode.GetLength())
											iChar = sUnlockCode.GetAt(16-i);
										else
											iChar = 0;
										iResult = (iResult % 256) * iChar;
										iResult += iResult / 256;
										iTotal = (iTotal + (iResult % 256)) % 256;
									}

									if (iTotal == 37)
										m_sCode = sUnlockCode;
								}
							}
						}
					}
				}
			}
		}
	}

	//Part 2 - Same thing with name
	iTotal = 0;
	m_sSerial = "";
	for (int i = m_sName.GetLength(); i > 0; i--)
	{
		iResult = i * i;
		iResult += iResult / 256;
		iChar = m_sName.GetAt(m_sName.GetLength()-i);
		iResult = (iResult % 256) * iChar;
		iResult += iResult / 256;
		iTotal = (iTotal + (iResult % 256)) % 256;
	}

	//Part 3 - Calculating serial
	iResult = 0;
	for (i = 16; i > 0; i--)
	{
		iResult = iTotal + i;
		iResult *= iResult;
		iResult += iResult / 256;
		iResult &= 15;

		sBuffer.Format("%X", iResult);
		m_sSerial += sBuffer;
	}

	UpdateData(false);
}
