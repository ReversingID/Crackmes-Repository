using System;

namespace keygen_crackmefive
{
  public partial class Form1
  {

	private string GenSerial(string name)
	{
	  int svalue = gen1(name);
	  int al, ax;
	  string result = "";
	  for (int i = 0; i < 16; i++)
	  {
		al = (svalue + (16-i)) & 65791;
		ax = al * al;
		al = (ax & 65791) + (ax >> 8);
		al &= 15;
		if (al <= 9) al += 48; else al += 55;
		result += (char)al;
	  }
	  return result;
	}

	private int gen1(string name)
	{
	  int svalue = 0;
	  int l = name.Length;
	  for (int i = 0; i < l; i++)
		svalue += getValue(l - i, name[i]);
	  return svalue & 65791;
	}

  }
}