using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace keygen_crackmefive
{
  public partial class Form1 : Form
  {
	public Form1()
	{
	  InitializeComponent();
	  MessageBox.Show("Author : iKid - Email : windak88@yahoo.com");
	}

	private void buttonUnlock_Click(object sender, EventArgs e)
	{
	  string code = GenUnlock();
	  if (code != null) unlockText.Text = code;
	  else MessageBox.Show("Can not find unlock code with that pattern");
	}

	private void keygenButton_Click(object sender, EventArgs e)
	{
	  string serial = GenSerial(inputName.Text);
	  outSerial.Text = serial;
	}

  }
}