namespace keygen_crackmefive
{
  partial class Form1
  {
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.IContainer components = null;

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
	protected override void Dispose(bool disposing)
	{
	  if (disposing && (components != null))
	  {
		components.Dispose();
	  }
	  base.Dispose(disposing);
	}

	#region Windows Form Designer generated code

	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
	  this.buttonUnlock = new System.Windows.Forms.Button();
	  this.unlockText = new System.Windows.Forms.TextBox();
	  this.panel1 = new System.Windows.Forms.Panel();
	  this.label1 = new System.Windows.Forms.Label();
	  this.groupBox1 = new System.Windows.Forms.GroupBox();
	  this.keygenButton = new System.Windows.Forms.Button();
	  this.outSerial = new System.Windows.Forms.TextBox();
	  this.inputName = new System.Windows.Forms.TextBox();
	  this.label3 = new System.Windows.Forms.Label();
	  this.label2 = new System.Windows.Forms.Label();
	  this.panel1.SuspendLayout();
	  this.groupBox1.SuspendLayout();
	  this.SuspendLayout();
	  // 
	  // buttonUnlock
	  // 
	  this.buttonUnlock.Location = new System.Drawing.Point(97, 44);
	  this.buttonUnlock.Name = "buttonUnlock";
	  this.buttonUnlock.Size = new System.Drawing.Size(75, 23);
	  this.buttonUnlock.TabIndex = 0;
	  this.buttonUnlock.Text = "Unlock";
	  this.buttonUnlock.UseVisualStyleBackColor = true;
	  this.buttonUnlock.Click += new System.EventHandler(this.buttonUnlock_Click);
	  // 
	  // unlockText
	  // 
	  this.unlockText.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
	  this.unlockText.Location = new System.Drawing.Point(97, 13);
	  this.unlockText.MaxLength = 7;
	  this.unlockText.Name = "unlockText";
	  this.unlockText.Size = new System.Drawing.Size(178, 25);
	  this.unlockText.TabIndex = 1;
	  this.unlockText.Text = "enter the pattern you like";
	  // 
	  // panel1
	  // 
	  this.panel1.Controls.Add(this.label1);
	  this.panel1.Controls.Add(this.buttonUnlock);
	  this.panel1.Controls.Add(this.unlockText);
	  this.panel1.Location = new System.Drawing.Point(23, 12);
	  this.panel1.Name = "panel1";
	  this.panel1.Size = new System.Drawing.Size(292, 78);
	  this.panel1.TabIndex = 3;
	  // 
	  // label1
	  // 
	  this.label1.AutoSize = true;
	  this.label1.Location = new System.Drawing.Point(12, 16);
	  this.label1.Name = "label1";
	  this.label1.Size = new System.Drawing.Size(68, 15);
	  this.label1.TabIndex = 3;
	  this.label1.Text = "Unlock Code";
	  // 
	  // groupBox1
	  // 
	  this.groupBox1.Controls.Add(this.keygenButton);
	  this.groupBox1.Controls.Add(this.outSerial);
	  this.groupBox1.Controls.Add(this.inputName);
	  this.groupBox1.Controls.Add(this.label3);
	  this.groupBox1.Controls.Add(this.label2);
	  this.groupBox1.Location = new System.Drawing.Point(12, 96);
	  this.groupBox1.Name = "groupBox1";
	  this.groupBox1.Size = new System.Drawing.Size(319, 100);
	  this.groupBox1.TabIndex = 4;
	  this.groupBox1.TabStop = false;
	  this.groupBox1.Text = "Serial Generation";
	  // 
	  // keygenButton
	  // 
	  this.keygenButton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
	  this.keygenButton.Location = new System.Drawing.Point(217, 45);
	  this.keygenButton.Name = "keygenButton";
	  this.keygenButton.Size = new System.Drawing.Size(75, 23);
	  this.keygenButton.TabIndex = 4;
	  this.keygenButton.Text = "Let\'s go";
	  this.keygenButton.UseVisualStyleBackColor = true;
	  this.keygenButton.Click += new System.EventHandler(this.keygenButton_Click);
	  // 
	  // outSerial
	  // 
	  this.outSerial.Location = new System.Drawing.Point(80, 59);
	  this.outSerial.Name = "outSerial";
	  this.outSerial.ReadOnly = true;
	  this.outSerial.Size = new System.Drawing.Size(129, 23);
	  this.outSerial.TabIndex = 3;
	  // 
	  // inputName
	  // 
	  this.inputName.Location = new System.Drawing.Point(80, 29);
	  this.inputName.Name = "inputName";
	  this.inputName.Size = new System.Drawing.Size(129, 23);
	  this.inputName.TabIndex = 2;
	  // 
	  // label3
	  // 
	  this.label3.AutoSize = true;
	  this.label3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
	  this.label3.Location = new System.Drawing.Point(27, 62);
	  this.label3.Name = "label3";
	  this.label3.Size = new System.Drawing.Size(36, 16);
	  this.label3.TabIndex = 1;
	  this.label3.Text = "Serial";
	  // 
	  // label2
	  // 
	  this.label2.AutoSize = true;
	  this.label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
	  this.label2.Location = new System.Drawing.Point(27, 32);
	  this.label2.Name = "label2";
	  this.label2.Size = new System.Drawing.Size(39, 16);
	  this.label2.TabIndex = 0;
	  this.label2.Text = "Name";
	  // 
	  // Form1
	  // 
	  this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 15F);
	  this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
	  this.ClientSize = new System.Drawing.Size(339, 206);
	  this.Controls.Add(this.groupBox1);
	  this.Controls.Add(this.panel1);
	  this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
	  this.Name = "Form1";
	  this.Text = "Keygen";
	  this.panel1.ResumeLayout(false);
	  this.panel1.PerformLayout();
	  this.groupBox1.ResumeLayout(false);
	  this.groupBox1.PerformLayout();
	  this.ResumeLayout(false);

	}

	#endregion

	private System.Windows.Forms.Button buttonUnlock;
	private System.Windows.Forms.TextBox unlockText;
	private System.Windows.Forms.Panel panel1;
	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.GroupBox groupBox1;
	private System.Windows.Forms.TextBox outSerial;
	private System.Windows.Forms.TextBox inputName;
	private System.Windows.Forms.Label label3;
	private System.Windows.Forms.Label label2;
	private System.Windows.Forms.Button keygenButton;
  }
}

