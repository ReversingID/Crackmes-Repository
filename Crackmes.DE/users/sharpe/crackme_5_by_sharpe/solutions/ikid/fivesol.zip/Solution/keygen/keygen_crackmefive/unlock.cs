using System;

namespace keygen_crackmefive
{
  public partial class Form1
  {
	// configurate the unlock code form 
	const int start = '0';
	const int stop = 'z';
	const int maxLength = 8;
	//end configurate.

	public char[] unlock_code = new char[17];
	public int encodekey;
	private bool gotit = false;

	private string GenUnlock()
	{
	  gotit = false; encodekey = 0;
	  string code = unlockText.Text;
	  for (int i = 0; i < code.Length; i++) unlock_code[i] = code[i];
	  for (int i = 16; i > 16 - code.Length; i--)
	  {
		encodekey += getValue(i, (int)code[16 - i]);
		encodekey = encodekey & 65791;
	  }
	  gotry(16 - code.Length);
	  if (!gotit) return null;
	  return new String(unlock_code);
	}

	private void gotry(int p)
	{
	  if (p == 16 - maxLength)
	  {
		if ((encodekey & 65791) == 37) gotit = true;
		return;
	  }
	  for (int i = start; i <= stop; i++)
	  {
		unlock_code[16 - p] = (char)i;
		encodekey += getValue(p, i);
		gotry(p - 1);
		encodekey -= getValue(p, i);
		if (gotit) return;
	  }

	}

	private int getValue(int i, int character)
	{
	  int ax = i * i;
	  int al = ax & 65791;
	  al = (ax & 65791) + (ax >> 8);
	  ax = character * al;
	  al = (ax & 65791) + (ax >> 8);
	  return al & 65791;
	}
  }
}