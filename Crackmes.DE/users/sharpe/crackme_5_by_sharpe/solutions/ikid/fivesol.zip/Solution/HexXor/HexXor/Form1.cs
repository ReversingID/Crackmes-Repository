using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace HexXor
{
  public partial class HexXor : Form
  {
	private int xorValue;
	private string[] arr;
	private string result;
	public HexXor()
	{
	  InitializeComponent();
	  xorValue = 0;
	}

	private void start_Click(object sender, EventArgs e)
	{
	  result = "";
	  string y;
	  for (;xorValue<=255 && result.IndexOf("3A 33 40 00")<0;xorValue++)
	  {
		result = "Using " + xorValue + "\n";
		for (int i = 0; i < arr.Length; i++)
		if (arr[i].Length>1)
		{
		  int x = (int.Parse(arr[i], System.Globalization.NumberStyles.HexNumber) ^
			xorValue);
		  y = x.ToString("X");
		  while (y.Length < 2) y = "0" + y;
		  result += y + " ";
		}
		outputText.Text += result + "\n";
	  }
	  if (xorValue==255) xorValue = 0;
	}

	private void inputText_TextChanged(object sender, EventArgs e)
	{
	  char[] x = { ' ','\n' };
	  arr = inputText.Text.Split(x);
	}

  }
}