namespace HexXor
{
  partial class HexXor
  {
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.IContainer components = null;

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
	protected override void Dispose(bool disposing)
	{
	  if (disposing && (components != null))
	  {
		components.Dispose();
	  }
	  base.Dispose(disposing);
	}

	#region Windows Form Designer generated code

	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
	  this.inputText = new System.Windows.Forms.RichTextBox();
	  this.outputText = new System.Windows.Forms.RichTextBox();
	  this.start = new System.Windows.Forms.Button();
	  this.SuspendLayout();
	  // 
	  // inputText
	  // 
	  this.inputText.Location = new System.Drawing.Point(39, 12);
	  this.inputText.Name = "inputText";
	  this.inputText.Size = new System.Drawing.Size(411, 153);
	  this.inputText.TabIndex = 1;
	  this.inputText.Text = "";
	  this.inputText.TextChanged += new System.EventHandler(this.inputText_TextChanged);
	  // 
	  // outputText
	  // 
	  this.outputText.Location = new System.Drawing.Point(39, 229);
	  this.outputText.Name = "outputText";
	  this.outputText.ReadOnly = true;
	  this.outputText.Size = new System.Drawing.Size(411, 233);
	  this.outputText.TabIndex = 2;
	  this.outputText.Text = "";
	  // 
	  // start
	  // 
	  this.start.Location = new System.Drawing.Point(221, 182);
	  this.start.Name = "start";
	  this.start.Size = new System.Drawing.Size(75, 23);
	  this.start.TabIndex = 3;
	  this.start.Text = "Next";
	  this.start.UseVisualStyleBackColor = true;
	  this.start.Click += new System.EventHandler(this.start_Click);
	  // 
	  // HexXor
	  // 
	  this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 15F);
	  this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
	  this.ClientSize = new System.Drawing.Size(488, 486);
	  this.Controls.Add(this.start);
	  this.Controls.Add(this.outputText);
	  this.Controls.Add(this.inputText);
	  this.Name = "HexXor";
	  this.Text = "HexXor";
	  this.ResumeLayout(false);

	}

	#endregion

	private System.Windows.Forms.RichTextBox inputText;
	private System.Windows.Forms.RichTextBox outputText;
	private System.Windows.Forms.Button start;
  }
}

