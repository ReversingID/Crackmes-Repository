#include <stdio.h>
#include <string.h>

#define  START    '0'		
#define  END	  'z'
                   
#define  MIN_LEN   8
#define  MAX_LEN   16

enum {
   FOUND,
   NOT_FOUND
};

unsigned hash(char *);
void inc(char *, char, char);
void init(char *str, unsigned);

int main(void)
{
    char pass[MAX_LEN+1], ends[MAX_LEN+1];
    unsigned i; 
    int status;   

    for (i = MIN_LEN; i <= MAX_LEN; i++) {

	init(pass, i);
	strcpy(ends, pass);

	for (status = FOUND; hash(pass) != 0xE961C933; ) {
	     inc(pass, START, END);
	     if (!strcmp(pass, ends)) {
		status = NOT_FOUND;
	     }
	}

	if (status == FOUND)
	    printf("\nPassword %u symbols: %s", i, pass);
    }

    return 0;
}

unsigned hash(char *str1)
{    
    unsigned i, value;

    _asm {
	mov  dword ptr [value], 0	
	mov  esi, [str1]
	xor  edi, edi
    m:
	lodsb
	test al, al
	jz   m1
	mov  ecx, eax
	add  edi, eax
	rol  edi, cl
	jmp  m
    m1:
	mov  dword ptr [value], edi
    }

    return value;
}

void inc(char *str, char st, char en)
{
    unsigned i;

    for (i = strlen(str) - 1; i >= 0; i--) {
	if (str[i] == en) {
	   str[i] = st;
	   continue;
    	} else {
	   str[i]++;
	   break;
	}
    }

}

void init(char *str, unsigned len)
{
    unsigned i;

    for (i = 0; i < len; i++)
	str[i] = START;

    str[i] = '\0';
}