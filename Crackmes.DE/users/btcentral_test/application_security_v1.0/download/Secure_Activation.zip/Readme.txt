Hi All,

We have developed a secure activation method for use on our commercial programs,

Basicly what we would like you to do is to try and crack this program,
both the activation and the trial limitations.

You can do this in anyway you want - keygening, cracking, patching etc.
We just want to see how easy it is for you to crack.

Thanks
BTCentral Software Development.