#include "stdafx.h"
#include <iostream>
#include <conio.h>

int generateKey(int id)
{
	int ret;
    int num = id * 0x312;
    ret = num * 0x11;
    num = ret / 12;
    ret = num + 0x7c7;

    return ret;
}

int _tmain(int argc, _TCHAR* argv[])
{
	int id;
	printf("-------------------------------\nHonestGamer KeyGen - By Mayhem\n-------------------------------\n");

	printf("ID: ");
	std::cin >> id;
	printf ("Code: %d\n", generateKey(id));

	_getch();
}

