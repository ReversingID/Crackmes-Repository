
#undef UNICODE
#undef _UNICODE
#include <windows.h>
#include "resource.h"

// defines
#define	APP_NAME		"kidmuncher's WinCrackMe"
#define	NAME_MAX		64
// prototypes
BOOL CALLBACK DialogProc(HWND  hwndDlg, UINT  uMsg, WPARAM  wParam, LPARAM  lParam );
void Generate (HWND hDlg);
unsigned int HashName (const char *szName);
void Test (HWND hDlg);

// AGMSY4BHNTZ5CIOU06DJPV17EKQW28FLRX39 BHNTZ5CIOU06DJPV17EKQW28FLRX39AGMSY4
// CIOU06DJPV17EKQW28FLRX39AGMSY4BHNTZ5 DJPV17EKQW28FLRX39AGMSY4BHNTZ5CIOU06
unsigned char g_HashTable[4][36] = {
	0x41, 0x47, 0x4D, 0x53, 0x59, 0x34, 0x42, 0x48, 0x4E, 0x54, 0x5A, 0x35,
	0x43, 0x49, 0x4F, 0x55, 0x30, 0x36, 0x44, 0x4A, 0x50, 0x56, 0x31, 0x37,
	0x45, 0x4B, 0x51, 0x57, 0x32, 0x38, 0x46, 0x4C, 0x52, 0x58, 0x33, 0x39,
	0x42, 0x48, 0x4E, 0x54, 0x5A, 0x35, 0x43, 0x49, 0x4F, 0x55, 0x30, 0x36,
	0x44, 0x4A, 0x50, 0x56, 0x31, 0x37, 0x45, 0x4B, 0x51, 0x57, 0x32, 0x38,
	0x46, 0x4C, 0x52, 0x58, 0x33, 0x39, 0x41, 0x47, 0x4D, 0x53, 0x59, 0x34,
	0x43, 0x49, 0x4F, 0x55, 0x30, 0x36, 0x44, 0x4A, 0x50, 0x56, 0x31, 0x37,
	0x45, 0x4B, 0x51, 0x57, 0x32, 0x38, 0x46, 0x4C, 0x52, 0x58, 0x33, 0x39,
	0x41, 0x47, 0x4D, 0x53, 0x59, 0x34, 0x42, 0x48, 0x4E, 0x54, 0x5A, 0x35,
	0x44, 0x4A, 0x50, 0x56, 0x31, 0x37, 0x45, 0x4B, 0x51, 0x57, 0x32, 0x38,
	0x46, 0x4C, 0x52, 0x58, 0x33, 0x39, 0x41, 0x47, 0x4D, 0x53, 0x59, 0x34,
	0x42, 0x48, 0x4E, 0x54, 0x5A, 0x35, 0x43, 0x49, 0x4F, 0x55, 0x30, 0x36
};

//----------------------------------------
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	DialogBoxParam (hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, DialogProc, 0);
	return (0);
}

//----------------------------------------
BOOL CALLBACK DialogProc(HWND  hwndDlg, UINT  uMsg, WPARAM  wParam, LPARAM  lParam )
{
	switch (uMsg)
	{
		case WM_INITDIALOG:
			SendDlgItemMessage (hwndDlg, IDC_EDIT_NAME, EM_SETLIMITTEXT, NAME_MAX-1, 0);
			return TRUE;

		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
				case IDC_BUTTON_GENERATE:
					Generate (hwndDlg);
					return TRUE;
				case IDC_BUTTON_TEST:
					Test (hwndDlg);
					return TRUE;
				case IDCANCEL:
					EndDialog (hwndDlg, 0);
					return TRUE;
			}
			break;
	}
	return FALSE;
}

//----------------------------------------
void Generate (HWND hDlg)
{
	char szName[NAME_MAX] = {0};
	char szSerial[24] = {0};

	GetDlgItemText (hDlg, IDC_EDIT_NAME, szName, sizeof(szName));
	unsigned int dwNameHash = HashName (szName);
	if (dwNameHash < 36)
	{
		MessageBox (hDlg, "Name is not valid", "Error", 0);
		SetFocus (GetDlgItem (hDlg, IDC_EDIT_NAME));
		return;
	}

	unsigned int dwHashTableIdx[5] = {0};

	// split up to base 36
	dwHashTableIdx[4] = dwNameHash / 1679616;
	dwHashTableIdx[3] = (dwNameHash % 1679616) / 46656;
	dwHashTableIdx[2] = (dwNameHash % 46656) / 1296;
	dwHashTableIdx[1] = (dwNameHash % 1296) / 36;
	dwHashTableIdx[0] = dwNameHash % 36;

	// we have indexes, now pick up values from hash table
	for (int i=0; i<4; i++)
		for (int j=0; j<5; j++)
			if (dwHashTableIdx[j] == 36)
				szSerial[i*6 + j] = '#';	// any character outside of range A-Z, 0-9
			else
				szSerial[i*6 + j] = g_HashTable[i][dwHashTableIdx[j]];

	szSerial[5] = '-'; szSerial[11] = '-'; szSerial[17] = '-';

	SetDlgItemText (hDlg, IDC_EDIT_SERIAL, szSerial);
}

//----------------------------------------
unsigned int HashName (const char *szName)
{
	char sNameAdjusted[5] = {0};

	// User name adjusting
	if (szName == NULL) return (0);
	for (unsigned int i=0, dwLastIdx=0; dwLastIdx<5; i++)
	{
		if (szName[i]== 0)	return (0);
		char cBuf = szName[i];
		if (cBuf >= 'A' && cBuf <= 'Z')
			sNameAdjusted[dwLastIdx++] = cBuf;
		if (cBuf >= 'a' && cBuf <= 'z')
			sNameAdjusted[dwLastIdx++] = cBuf - 0x20;		// to uppercase
	}
	// hashing
	unsigned int dwHash = 0;
	for (unsigned int i=0; i<5; i++)
	{
		dwHash *= 26;
		dwHash += sNameAdjusted[i] - 'A';
	}
	return (dwHash);
}

//----------------------------------------
void Test (HWND hDlg)
{
	HWND hWnd = FindWindow (NULL, "WinCrackMe by KIDMUNCHER (c) 2009");
	if (hWnd == NULL)
	{
		MessageBox (hDlg, "Please start WinCrackMe.exe first", APP_NAME, 0);
		return;
	}

	HWND hDlgItem;
	char szBuf[NAME_MAX] = {0};

	GetDlgItemText (hDlg, IDC_EDIT_NAME, szBuf, NAME_MAX);
	if (hDlgItem = GetDlgItem (hWnd, 1003))
		SendMessage (hDlgItem, WM_SETTEXT, 0, (LPARAM)szBuf);

	GetDlgItemText (hDlg, IDC_EDIT_SERIAL, szBuf, NAME_MAX);
	if (hDlgItem = GetDlgItem (hWnd, 1004))
		SendMessage (hDlgItem, WM_SETTEXT, 0, (LPARAM)szBuf);

	SetForegroundWindow (hWnd);
	if (hDlgItem = GetDlgItem (hWnd, 1001))
		PostMessage(hDlgItem, BM_CLICK, 0, 0);
}
