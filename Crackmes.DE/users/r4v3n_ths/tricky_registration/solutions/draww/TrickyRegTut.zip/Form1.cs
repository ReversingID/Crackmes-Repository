﻿using System;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace TrickyRegSolver
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text = "draww @ crackmes.de";
            textBox2.ReadOnly = true;
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.TextLength > 0)
            {
                MD5 md = MD5.Create();
                byte[] bytes = Encoding.ASCII.GetBytes(this.textBox1.Text);
                byte[] buffer = md.ComputeHash(bytes);
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i <= buffer.Length - 1; i++)
                {
                    builder.Append(buffer[i].ToString("x2"));
                }
                textBox2.Text = ReverseString(builder.ToString());
            }
            else
            {
                textBox2.Text = "Enter something as a name!";
            }
        }
        public string ReverseString(string text)
        {
            char[] charArray = text.ToCharArray();
            Array.Reverse(charArray);
            return new string(charArray);
        }
    }
}
