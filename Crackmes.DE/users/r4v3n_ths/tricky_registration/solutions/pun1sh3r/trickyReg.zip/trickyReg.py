#!/usr/bin/python

import md5
import sys

'''
tricky registration walkthrough and keygen
when user clicks the button a few things happen:
  - it initializes an md5 object
  - it grabs user input from first textbox and generates a md5 hash
  - a second variable named str4 is used to hold the value of the reversed hash value 
  - a comparison is made between the second textbox and variable str4 if they are a match the copy is successfully registered
    otherwise it throws an error msg

'''

#creates md5 object
m = md5.new()
#generates md5 digest out of input string
m.update(sys.argv[1])
#reverses digest value
finalstr= m.hexdigest()[::-1]
#print registration code.
print finalstr