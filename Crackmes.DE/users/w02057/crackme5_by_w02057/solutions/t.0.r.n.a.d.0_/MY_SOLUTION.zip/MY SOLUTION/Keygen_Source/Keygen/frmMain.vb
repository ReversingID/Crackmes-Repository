﻿Public Class frmMain

    Private Sub btnValidate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnValidate.Click
        Dim First9Digs(8) As String
        Dim RandomNumber As System.Random
        RandomNumber = New Random(System.DateTime.Now.Millisecond)

        First9Digs(0) = 276951438
        First9Digs(1) = 294753618
        First9Digs(2) = 438951276
        First9Digs(3) = 492357816
        First9Digs(4) = 618753294
        First9Digs(5) = 672159834
        First9Digs(6) = 816357492
        First9Digs(7) = 834159672

        txtKey.Text = First9Digs(RandomNumber.Next(0, 7))

        txtSerial.Text = getserial(txtKey.Text)
    End Sub

    Private Function check(ByVal str As String) As Boolean
        Dim num As Integer = 0
        Dim num2 As Integer = 0
        Dim startIndex As Integer = 0
        Dim flag2 As Boolean = False
        Try
            num2 = 1

            ' FOLLOWING Loop CHECKS THAT ALL DIGITS ARE NOT EQUAL
            Do
                Dim num4 As Integer = (str.Length - 1)
                startIndex = 0
                Do While (startIndex <= num4)

                    If (Convert.ToInt32(str.Substring(startIndex, 1)) = num2) Then
                        If flag2 Then
                            Return False
                        End If
                        flag2 = True
                    End If
                    startIndex += 1
                Loop
                flag2 = False
                num2 += 1
            Loop While (num2 <= 9)

            ' Key is 9-digit
            ' Let : ABCDEFGHI

            ' A + E + I = 15
            ' C + E + G = 15
            ' A + B + C = 15
            ' D + E + F = 15
            ' G + H + I = 15
            ' A + D + G = 15
            ' B + E + H = 15
            ' C + F + I = 15

            If Conversion.Int(str.Substring(0, 1)) + Conversion.Int(str.Substring(4, 1) + Conversion.Int(str.Substring(8, 1))) = 15 Then
                num += 1
            End If
            If Conversion.Int(str.Substring(2, 1)) + Conversion.Int(str.Substring(4, 1)) + Conversion.Int(str.Substring(6, 1)) = 15 Then
                num += 1
            End If
            If Conversion.Int(str.Substring(0, 1)) + Conversion.Int(str.Substring(3, 1)) + Conversion.Int(str.Substring(6, 1)) = 15 Then
                num += 1
            End If
            If Conversion.Int(str.Substring(1, 1)) + Conversion.Int(str.Substring(4, 1)) + Conversion.Int(str.Substring(7, 1)) = 15 Then
                num += 1
            End If
            If Conversion.Int(str.Substring(2, 1)) + Conversion.Int(str.Substring(5, 1)) + Conversion.Int(str.Substring(8, 1)) = 15 Then
                num += 1
            End If
            If Conversion.Int(str.Substring(0, 1)) + Conversion.Int(str.Substring(1, 1)) + Conversion.Int(str.Substring(2, 1)) = 15 Then
                num += 1
            End If
            If Conversion.Int(str.Substring(3, 1)) + Conversion.Int(str.Substring(4, 1)) + Conversion.Int(str.Substring(5, 1)) = 15 Then
                num += 1
            End If
            If Conversion.Int(str.Substring(6, 1)) + Conversion.Int(str.Substring(7, 1)) + Conversion.Int(str.Substring(8, 1)) = 15 Then
                num += 1
            End If
        Catch exception1 As Exception
            Return False
        End Try
        Return (num = 8)
    End Function

    Private Function getserial(ByVal str As String) As Object
        Dim obj2 As Object
        Try
            Dim str3 As String = Convert.ToString(Me.hash(str))
            Dim str2 As String = ""
            Dim startIndex As Integer = 0
            Dim num2 As Integer = (str.Length - 1)
            startIndex = 0
            Do While (startIndex <= num2)
                str2 = (str2 & str3.Substring(CInt(Math.Round(CDbl((Convert.ToDouble(str.Substring(startIndex, 1)) - 1)))), 1))
                startIndex += 1
            Loop
            str = Convert.ToString(Me.hash(str2))
            str2 = ""
            startIndex = 1
            Do
                str2 = (str2 & str.Substring((startIndex * 4), 4))
                If (startIndex <> 5) Then
                    str2 = (str2 & "-")
                End If
                startIndex += 1
            Loop While (startIndex <= 5)
            obj2 = Strings.UCase(str2)
        Catch exception1 As Exception
            obj2 = Nothing
        End Try
        Return obj2
    End Function

    Private Function hash(ByVal str As String) As Object
        Dim provider As New System.Security.Cryptography.MD5CryptoServiceProvider
        Dim bytes As Byte() = System.Text.Encoding.ASCII.GetBytes(str)
        bytes = provider.ComputeHash(bytes)
        str = ""
        Dim num As Byte
        For Each num In bytes
            str = (str & num.ToString("x2"))
        Next
        Return str
    End Function

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        btnValidate_Click(sender, e)
    End Sub
End Class
