﻿Imports System
Imports System.Security.Cryptography
Imports System.Text


Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Button1.Text = "it seems the bruteforcer is blocked but it runs. Just be patient"
        Button1.Enabled = False
        Dim number As Double
        For number = 10000000 To 99999999

            Dim str As String = "abcdefghijklmnopqrstuvwxyz"
            Dim thestring As String
            thestring = Convert.ToString(CDbl((Convert.ToDouble(number + 57842967))))
            thestring = String.Concat(New String() {Strings.Mid(str, 1, 1), Strings.UCase(Strings.Mid(str, &H1A, 1)), Strings.UCase(Strings.Mid(str, 11, 1)), thestring, Convert.ToString(2), Strings.UCase(Strings.Mid(str, 14, 1)), Strings.Mid(str, &H12, 1)})
            Dim validatestring As String
            validatestring = (Strings.UCase(Strings.Mid(Convert.ToString(Me.sha1(thestring)), 1, 20).Insert(4, "-").Insert(9, "-").Insert(14, "-").Insert(&H13, "-")))
            If validatestring = "E9A1-CFE4-A2D6-D19B-E1E2" Then
                TextBox1.Text = TextBox1.Text & " ** " & number.ToString & "  E9A1-CFE4-A2D6-D19B-E1E2"
            End If
            If validatestring = "F68A-8002-D1FD-1BF6-E6C4" Then
                TextBox1.Text = TextBox1.Text & " ** " & number.ToString & "  F68A-8002-D1FD-1BF6-E6C4"
            End If
            If validatestring = "6F96-AFB3-2A2D-F692-1A27" Then
                TextBox1.Text = TextBox1.Text & " ** " & number.ToString & "  6F96-AFB3-2A2D-F692-1A27"
            End If
            If validatestring = "5FE6-10E5-FF3F-01AE-232E" Then
                TextBox1.Text = TextBox1.Text & " ** " & number.ToString & "  5FE6-10E5-FF3F-01AE-232E"
            End If
            If validatestring = "E04B-D618-90EF-373B-307D" Then
                TextBox1.Text = TextBox1.Text & " ** " & number.ToString & "  E04B-D618-90EF-373B-307D"
            End If
            If validatestring = "6C22-0B1F-7C4A-6ADE-2796" Then
                TextBox1.Text = TextBox1.Text & " ** " & number.ToString & "  6C22-0B1F-7C4A-6ADE-2796"
            End If
            If validatestring = "EC39-552C-9E43-8A3C-5BA2" Then
                TextBox1.Text = TextBox1.Text & " ** " & number.ToString & "  EC39-552C-9E43-8A3C-5BA2"
            End If
            If validatestring = "6C8A-82EC-5EE9-1B1D-4C26" Then
                TextBox1.Text = TextBox1.Text & " ** " & number.ToString & "  6C8A-82EC-5EE9-1B1D-4C26"
            End If
        Next number






    End Sub

    Private Function sha1(ByVal sString As String) As Object
        Dim provider As New MD5CryptoServiceProvider
        Dim bytes As Byte() = Encoding.ASCII.GetBytes(sString)
        bytes = provider.ComputeHash(bytes)
        Dim str As String = ""
        Dim num As Byte
        For Each num In bytes
            str = (str & num.ToString("x2"))
        Next
        Return str
    End Function
End Class



