This crackme is built using some of the ideas from CrackMe#3, but it is much more fun!

The main algorithm is based on a well known puzzle, but just messed around a bit so not to make it too obvious.


<<--Rules-->>
1) No patching
2) Find the 2nd key to make a matched pair.
3) Write a solution when you are done, a keygen isnt required, just a tutorial.


Have fun and enjoy!