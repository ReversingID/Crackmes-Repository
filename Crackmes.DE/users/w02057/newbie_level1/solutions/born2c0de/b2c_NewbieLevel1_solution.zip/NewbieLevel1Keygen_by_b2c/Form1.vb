﻿' Original Crackme Link : http://www.crackmes.de/users/w02057/newbie_level1/
' Keygen written by born2c0de

Public Class Form1

    Function SHA1Hash(ByVal strToHash As String) As String
        Dim sha1Obj As New Security.Cryptography.SHA1CryptoServiceProvider
        Dim bytesToHash() As Byte = System.Text.Encoding.ASCII.GetBytes(strToHash)

        bytesToHash = sha1Obj.ComputeHash(bytesToHash)

        Dim strResult As String = ""

        For Each b As Byte In bytesToHash
            strResult += b.ToString("x2")
        Next

        Return strResult
    End Function

    Private Function toltr(ByVal s As String) As String
        Dim result As String = ""
        For Each c As Char In s
            If IsNumeric(c) = False Then result += c
        Next
        Return Trim(result)
    End Function

    Private Function tonum(ByVal s As String) As String
        Dim result As String = ""
        For Each c As Char In s
            If IsNumeric(c) And c <> "0" Then result += c
        Next
        Return result
    End Function


    Private Sub btncheck_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncheck.Click
        Dim ovfEx As New OverflowException
        If txtusername.TextLength < 6 Then MsgBox("Need at least 6 chars") : Exit Sub
        Dim uname As String = Trim(LCase(Trim(txtusername.Text))) 'loc.3 at 0x4d
        Dim sha1key As String = String.Concat("pQr5", uname, "aZk9")
        Dim sharesult As String = Trim(SHA1Hash(sha1key)) ' loc.3 at 0x64
        Dim toltr_result As String = toltr(sharesult) ' loc.2 at 0x6c
        Dim tonum_result As String = tonum(sharesult) ' V_4 at 0x74
        Dim midresult As String = Mid(toltr_result, 1, 4) ' loc.0 at 0x7e
        If (tonum_result.Length - 3) < 0 Then Throw ovfEx
        Dim tmpNSub As String = Mid(tonum_result, (tonum_result.Length - 3), 4) ' V_5 at 0x90
        If (toltr_result.Length - 3) < 0 Then Throw ovfEx
        Dim tmpLSub As String = Mid(toltr_result, (toltr_result.Length - 3), 4) ' V_7 at 0xa1
        Dim tmpdouble As Double = CDbl(Trim(Mid(tonum_result, 1, 8))) * CDbl(txtusername.TextLength)
        Dim tmpmul As String = Trim(Str(tmpdouble))
        Dim newmidresult As String = Trim(Mid(tmpmul, 2, 4)) ' loc.1 at 0xca b2c
        Dim finalstring(7) As String ' V_8 at 0xd1
        finalstring(0) = midresult
        finalstring(1) = "-"
        finalstring(2) = tmpNSub
        finalstring(3) = "-"
        finalstring(4) = tmpLSub
        finalstring(5) = "-"
        finalstring(6) = newmidresult
        Dim realserial As String = UCase(String.Concat(finalstring)) 'V_6 at 0x0110
        txtserial.Text = realserial
        Clipboard.SetText(Trim(realserial))
    End Sub
End Class
