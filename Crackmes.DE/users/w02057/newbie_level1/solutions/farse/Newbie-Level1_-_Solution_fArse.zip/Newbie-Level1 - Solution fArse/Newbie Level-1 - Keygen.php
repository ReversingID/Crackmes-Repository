<?PHP
    function generate_serial($name) {
        $name2 = strtolower($name);
        $name2 = 'pQr5'.$name2.'aZk9';
        $name2 = sha1($name2);
    
        $str3 = toltr($name2);
        $str5 = tonum($name2);
        $str = substr($str3,0,4);
        $str6 = substr($str5,(strlen($str5)-4),4);
        $str8 = substr($str3,(strlen($str3)-4),4);
        $str2 = substr((substr($str5,0,8) * strlen($name)),1,4);
        $str7 = strtoupper($str.'-'.$str6.'-'.$str8.'-'.$str2);
        return $str7;
    }
    function toltr($string) {
        $str = '';
        $num = strlen($string) - 1;
        $i = 0;
        while ($i <= $num) {
            if (preg_match('/[a-z]/', substr($string,$i,1))) {
                $str .= substr($string,$i,1);
            }
            $i++;
        }
        return $str;
    }
    function tonum($string) {
        $str = '';
        $num = strlen($string) - 1;
        $i = 0;
        while ($i <= $num) {
            if (preg_match('/[1-9]/', substr($string,$i,1))) {
                $str .= substr($string,$i,1);
            }
            $i++;
        }
        return $str;
    }
    $ba = true;
    if (php_sapi_name() == "cli") {
        echo '-----------------------------------------------'."\n";
        echo 'Newbie Level-1 by w02057 Keygen - fArse'."\n\n";
        echo 'Usage:   '.__FILE__.' <name>'."\n";
        echo 'Example: '.__FILE__.' fArse08'."\n";
        echo '-----------------------------------------------'."\n\n";
        if (isset($argv[1])) {
            if (strlen($argv[1]) < 6) {
                echo 'Name must be 6 or more characters!';
            } else {
                echo 'Name:   '.$argv[1]."\n";
                echo 'Serial: '.generate_serial($argv[1])."\n";
            }
        } else {
            echo 'Please enter a name!';
        }
    } else {
?>
<html>
    <head>
        <title>Newbie Level-1 by w02057 Keygen - fArse</title>
        <style type="text/css">
            body {
                background: #FFFFCC;
                font-family: Tahoma, arial;
                font-size: 12px;
                text-align: center;
            }
            input, select {
                font-family: Tahoma, arial;
                font-size: 12px;
            }
            #container {
                margin: 0px auto 0px auto;
                width: 600px;
            }
            #content {
                text-align: left;
            }
        </style>
    </head>
    <body>
        <div id="container">
            <div id="content">
                <h1>Newbie Level-1 by w02057 Keygen - fArse</h1>
<?PHP
        if (isset($_GET['name'])) {
            $name = $_GET['name'];
            if (strlen($_GET['name']) < 6) {
                echo '              <font color="red">Name must be 6 or more characters!</font><br />'."\r\n";
                echo '              Please enter a name!<br />'."\r\n";
            } else {
                $serial = generate_serial($name);
                echo '              <b>Name:</b> '.$name.'<br />'."\r\n";
                echo '              <b>Serial:</b> '.$serial.'<br />'."\r\n";
            }
        } else {
            echo '              Please enter a name!<br />'."\r\n";
        }
?>
                <form action="<?PHP echo $_SERVER['PHP_SELF']; ?>" method="GET">
                    <input type="text" name="name" id="name" size="20" /><br />
                    <input type="submit" name="generate" id="generate" value="Generate!" />
                </form> 
            </div>
        </div>
    </body>
</html>
<?PHP
    }
?>