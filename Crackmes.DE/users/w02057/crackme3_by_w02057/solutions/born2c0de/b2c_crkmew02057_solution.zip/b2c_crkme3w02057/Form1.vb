﻿' SOLUTION TO w02057's Crackme3 by [ b o r n 2 c 0 d e ]
' Original Crackme Link : http://www.crackmes.de/users/w02057/crackme3_by_w02057/

Imports System.Security.Cryptography
Public Class Form1
    Private Function getid() As String
        Dim str As String = ""
        Dim str2 As String = ""
        Dim provider As New MD5CryptoServiceProvider
        Dim buffer As Byte() = System.Text.Encoding.ASCII.GetBytes((My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion", "ProductId", Nothing)) & Me.txtusername.Text)
        Dim num As Byte
        For Each num In provider.ComputeHash(buffer)
            str2 = (str2 & num.ToString("x2"))
        Next
        Dim num4 As Integer = (str2.Length - 1)
        Dim i As Integer = 0
        Do While (i <= num4)
            If str2.Substring(i, 1) Like "[1-9]" Then
                str = (str & str2.Substring(i, 1))
            End If
            i += 1
        Loop
        Return (Mid(str, 1, 11) & CStr(9))
    End Function

    Private Sub GenerateSerial()
        Dim random As String = "2681194357"
        Dim str, str2, str3 As String
        ' Assume Initial Serial to be 000-000-000-001

        If (Me.txtusername.Text = "") Then Interaction.MsgBox("Please enter a name.", MsgBoxStyle.Critical, "Error") : Exit Sub

        Dim expression As String = Me.getid()
        Dim text As String = random

        Dim str8 As String = CStr(CDbl((CDbl(CStr(Me.getid)) - CDbl(expression))))
        Dim count As Long = 100000
        Dim foundserial As Boolean = False
        Dim str5 As String = CStr(0)
        Dim str7 As String = ""

        For i As Long = 0L To count
            My.Application.DoEvents()
            str8 = CStr((CDbl((Me.getid)) - CDbl(expression)))
            text = random
            str7 = ""
            str5 = CStr(0)
            str = ""
            str2 = ""
            str3 = ""
            Do While (str5 <> str8)
                str7 = Mid([text], 10, 1)
                [text] = [text].Remove(9, 1)
                [text] = (str7 & [text])
                str5 = CStr(CDbl((CDbl(str5) + 1)))
            Loop
            str = CStr(Val(Mid([text], 1, 1)) + Val(Mid([text], 2, 1)) + Val(Mid([text], 3, 1)) + Val(Mid([text], 4, 1)))
            str2 = CStr(Val(Mid([text], 4, 1)) + Val(Mid([text], 5, 1)) + Val(Mid([text], 6, 1)) + Val(Mid([text], 7, 1)))
            str3 = CStr(Val(Mid([text], 7, 1)) + Val(Mid([text], 8, 1)) + Val(Mid([text], 9, 1)) + Val(Mid([text], 10, 1)))

            If ((str = str2) = CBool(str3)) Then
                foundserial = True
                ' add the separators for formatting...totally optional
                expression = expression.Insert(4, "-")
                expression = expression.Insert(8, "-")
                ' end optional code
                lstSerials.Items.Add(expression)

                If lstSerials.Items.Count >= CInt(txtNumberOfValidSerials.Text) Then
                    Exit For
                End If
            End If
            ' remove the separators if included in the main serial.
            expression = expression.Replace("-", "")

            expression = CStr(CDbl(expression) - CDbl(1))
            If i Mod 1000 = 0 Then ProgressBar1.PerformStep()

        Next
        If foundserial = False Then
            MsgBox("No Serials Found")
        End If
        ProgressBar1.Value = ProgressBar1.Maximum
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtprodId.Text = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion", "ProductId", Nothing)
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        lstSerials.Items.Clear()
        GenerateSerial()
    End Sub

    Private Sub ListBox1_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lstSerials.MouseClick
        Clipboard.SetText(lstSerials.SelectedItem.ToString)
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstSerials.SelectedIndexChanged

    End Sub
End Class
