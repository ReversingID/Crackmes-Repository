#!/usr/bin/ruby

# return a random number between min and max (inclusive)
# odd is 0 or 1, it specify if the result should be even or odd
def rand_range(min, max, odd)
	rnd = min + rand(max-min+1)
	if rnd & 1 != odd
		if rnd < max
			rnd += 1
		else
			rnd -= 1
		end
	end
	rnd
end

# maximum value for any factor: 9+9+9+9
max = 9*4

# v1 between 5 and 24, odd
v1 = rand_range(5, 24, 1)

# v2 odd because v1+v2 is even
v2 = rand_range(1, max-v1, 1)

# v3 < v2, v4 odd, v3+v4 == sum34
sum34 = (v1+v2)/2
maxv3 = [v2-1, sum34].min
v3 = rand_range(0, maxv3, 1-(sum34&1))

# v4 odd, v3+v4 == (v1+v2)/2
v4 = (v1+v2)/2 - v3


# now generate 4-digits whose sum is given
def sum_to_4digits(sum)
	# 4 random digits
	digits = Array.new(4) { rand(10) }

	# offset from the sum we want
	delta = digits.inject(sum) { |s, d| s - d }

	while delta > 0
		# increment a random digit
		i = rand(digits.length)
		if digits[i] < 9
			digits[i] += 1
			delta -= 1
		end
	end

	while delta < 0
		# decrement a random digit
		i = rand(digits.length)
		if digits[i] > 0
			digits[i] -= 1
			delta += 1
		end
	end

	digits.join
end

# print our serial ('-' can be omitted)
puts [v1, v2, v3, v4].map { |sum| sum_to_4digits(sum) }.join('-')
