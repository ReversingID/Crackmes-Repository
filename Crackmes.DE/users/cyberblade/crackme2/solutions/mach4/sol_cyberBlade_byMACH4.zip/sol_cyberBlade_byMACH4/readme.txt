Target:   CRACKME v2.00 by CyberBlade
Platform: Windoze
Language: VB5
Compiler: Compiled to P-Code

Solution by MACH4. 11.04.2009

