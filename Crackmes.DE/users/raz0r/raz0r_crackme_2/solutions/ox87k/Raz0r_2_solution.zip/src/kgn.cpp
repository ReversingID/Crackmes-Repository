#include <iostream.h>
#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <windows.h>
#include <dos.h>

char name[0xF];
unsigned char serial[100];
unsigned char string[7]={ "v8E259a" };
unsigned int len=0;
DWORD car;

void main()
{
   cout<<"**************************************\n";
	cout<<"* Raz0r's Crackme #2 KeyGen by Ox87k *\n";
   cout<<"**************************************\n\n";
	cout<<"Name: ";
	gets(name);
   len=strlen(name);

   //First CICLE
	for (int i=0;i<len;i++)
	{
      int tmp=i+2;
		car=tmp*name[i];
      if (car>0x7A)
      {
         do
         {
      		car/=0x3;
         }while(car>0x7A);
      }
      rema:
      if(car<0x30)
      {
      	car+=(i*2)+1;
         goto rema;
      }
      if(car>0x39 && car<0x41)
			car-=0x08;
      if(car>0x5A && car<0x61)
      	car-=0x07;
      serial[i]=car;
	}

   //Second CICLE
   for(int c=len;c<16;c++)
   {
      int i=c;
   	int tmp=i+2;
		car=tmp*0x61;
      rema2:
      if (car>0x7A)
      {
      		car/=0x3;
            goto rema2;
      }
      rema3:
      if(car<0x30)
      {
      	car+=0x0F;
      	goto rema3;
      }
      if(car>0x39 && car<0x41)
      {
			car-=0x08;
      	goto ex;
      }
      if(car>0x5A && car<0x61)
      	car-=0x07;

      ex:
      serial[c]=car;
   }

   if(len<9)
   {
      serial[9]='\0';
      strcat(serial,string);
   }
   else
   {
      for(int i=0;i<7;i++)
      {
      	serial[i+len]=string[(len-9)+i];
      }
   }

   serial[16]='\0';
   cout<<"Serial: "<<serial;
	cout<<"\n\nPress any key to exit...";
	getch();
}
