#include<conio.h>
#include<stdio.h>
void main()
{
	char ch[35] = {	'n','O','u','K','e','Y','s',' ','N','o','M','!','R',
			'y','T','$','*','t','h','E','p','@','(',
			'/','_','[','S','&','"','a','r','.','=',']','%'	};
	char name[7],serial[9];
	char magic;
	int i,magic_off,j;
	clrscr();
	i=0;
	while(ch[i]!='.')
		i++;
	j = 183;
	ch[i] = (char)j;
	i=j=0;
	printf("\nEnter the magic character : ");
	scanf("%c",&magic);
	while(ch[i]!=magic)
		i++;
	i++;
	printf("Enter the name : ");
	printf("\nName must be 8 chars long and third letter must be 'x' : ");
	scanf("%s",name);
	magic_off = i;
	serial[1] = name[7];
	serial[4] = name[1];
	serial[6] = name[4];
	serial[0] = ch[magic_off - 5];
	serial[3] = ch[magic_off + 2];
	j = magic_off+3;
	printf("\nmagic_offmod9 + 3 = %d",j);
	printf("\nch[at that place is ] = %c",ch[j]);
	printf("\nRemainder is %d",magic_off%9);
	serial[2] = serial[5] = serial[7] = serial[8] =serial[9] = magic;
	serial[magic_off%9] = ch[magic_off + 3];
	printf("\nSerial: ");
	for(i=0;i<=9;i++)
		printf("%c",serial[i]);
	getch();
}
