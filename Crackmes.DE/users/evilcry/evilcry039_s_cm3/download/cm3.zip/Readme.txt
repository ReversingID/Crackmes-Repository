=======================================================================
-------------------[Crackme3 By Evilcry]-----------------------------
=======================================================================

Regole:

-Il Patching e' ASSOLUTAMENTE VIETATO
-Si pu� disassemblare (per� prima dovete renderlo disassemblabile:))
-Trovare il serial esatto, magari scrivendo anche un KeyGen
-Spiegare la routine di protezione

InF0 AbuT ThIS CrRAcMe:

Questo crackme non � molto difficile. Ma ci tengo a precisare, che non � neanche a livello di quelli precedenti :-D. Protrebbe tornarvi utile forse
e dico FORSE, la conoscenza delle equazioni, ed inoltre dovete conoscere
abbastanza bene i principi dello XOR. Infine, state inguardia da sgradevoli
check (moolto semplice da trovare). Ah dimenticavo.... c'� anche un piccolo
trick Anti-Disasm ihihih. 


Se qualcuno vuole contattarmi lo faccia a: evilcry@virgilio.it


RiNgRAzIaMenTi e SaLuTi: Colgo l' occasione per porre i miei pi� cari saluti a tutti quelli che mi conoscono. Il chan #crack-it #pmode e #asm. 




 