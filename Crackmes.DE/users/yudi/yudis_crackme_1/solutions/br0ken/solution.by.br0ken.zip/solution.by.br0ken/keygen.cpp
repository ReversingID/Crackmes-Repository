#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
	
	
	char name[199];
	int len,i;
	printf("********************************************\n");
	printf("*** Keygen for Yudi's KeygenMe by br0ken ***\n");
	printf("********************************************\n");
        printf("\n\nName = ");
	gets(name);
	len=strlen(name);
	printf("\n\nSerial = ");
	for(i=0;i<len;i++)  
        printf("%X",name[i]^0x35);
	getch();
}
