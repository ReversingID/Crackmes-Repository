#include <iostream>
using namespace std;

int main () {
	char username[32], serial[32];
	int i, a;
	cout << "Please enter a username: ";
	cin >> username;

	for (i=0;i<strlen(username);i++) {
		a = (int)username[i];
		a = a ^ 0x35;
		sprintf(&serial[i*2], "%X", a);
	}

	cout << serial << endl;
	system("PAUSE");
	return 0;
}