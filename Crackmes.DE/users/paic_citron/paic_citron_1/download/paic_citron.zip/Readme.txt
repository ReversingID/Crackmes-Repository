This is my first Crackme, I hope you'll like it
this crackme is not packet encrypted,
the program doesn't works like the crackme you know
if you try to crack it using the old method everybody know
you won't get anything  :)

good luck