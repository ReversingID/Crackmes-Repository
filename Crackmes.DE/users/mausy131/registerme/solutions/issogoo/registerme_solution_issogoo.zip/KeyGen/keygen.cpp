/*
 *  KeyGen for mausy131's RegisterMe
 *
 *  Author: iSSoGoo
 */

#include <iostream>
#include <cstring>
#include <iostream>
#include <fstream>

using namespace std;

int main(){

    char fileName[] = "6D61757379.131";
    char stringOrg[] = "Dulce et decorum est pro patria mori mors et fugacem persequitur virum nec parcit inbellis iuventae poplitibus timidove tergo.";
    char *serial;
    int counter = 0;
    int strLen = 0;

    serial = new char[strlen(stringOrg) + 1];
    strLen = strlen(stringOrg);
    serial[strLen] = 0;

    if(strLen>0){

        while(strLen>0){
            serial[strLen-1] = stringOrg[counter] ^ ((strLen-1 + 'x') % 0x14);
            counter++;
            strLen--;
        }

        ofstream myfile;
        myfile.open (fileName, ios::out | ios::binary | ios::trunc);
        if(myfile.is_open()){
                myfile << serial;
                cout << "THE licencefile was generated successfully!" << endl;

        }else{
            cout << "ERROR opening the file";
        }

        myfile.close();

    }else{
        cout << "ERROR! Please chose at least one char!" << endl;
    }


    return 0;
}
