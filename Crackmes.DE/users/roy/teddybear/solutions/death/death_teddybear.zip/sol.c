/* roy's Feistel Network cipher */
/* A Fiestel Network cipher is a cipher that has a feature:     */
/* The decryption function is running the same rounds as        */
/* the encryption one, but in reverse. roy here used DESX       */
/* construction to strengthen the cipher. The encryptor roy     */
/* supplied uses the password squirrel, so we figure the        */
/* decryptor uses that password as well.                        */
#include <stdio.h>
#include <conio.h>

/* #define ENCRYPT */
/* #define DECRYPT */
#define TEDDYBEAR

/* len must be aligned to 8 bytes */
void encrypt(char *inbuf, char *outbuf, long len, char *subkey)
{
    unsigned long dw_Left;
    unsigned long dw_Right;
    unsigned long *dw_in;
    unsigned long *dw_out;
    unsigned long *dw_subkey;
    long dw_len;
    long dw_count;
    unsigned long dw_temp;
    signed long dw_temp2;
    unsigned long dw_initial_key;

    dw_len = len / 8;
    dw_in = (unsigned long *)inbuf;
    dw_out = (unsigned long *)outbuf;
    dw_subkey = (unsigned long *)subkey;
    dw_initial_key = 0xC0DEC0DE;

    while (dw_len) {
        dw_Left = dw_in[1];
        dw_Right = dw_in[0];

        /* (DESX construction) */
        dw_Right ^= dw_initial_key;
        dw_Left ^= dw_initial_key;
        dw_initial_key = dw_Left;

        for (dw_count = 0; dw_count < 0x20; dw_count++) {
            /* Save dw_Left */
            dw_temp = dw_Left;

            /* F(dw_Left) */
            dw_temp2 = dw_Left;
            dw_temp2 >>= ((dw_subkey[dw_count % 4] & 0xFF) % 32);
            dw_Left <<= ((dw_subkey[dw_count % 4] & 0xFF) % 32);
            dw_temp2 ^= dw_subkey[dw_count % 4];
            dw_temp2 |= dw_Left;

            /* Xor with dw_Right */
            dw_temp2 ^= dw_Right;

            dw_Left = dw_temp2;

            /* dw_Right is now dw_Left */
            dw_Right = dw_temp;
        }

        dw_out[1] = dw_Left;
        dw_out[0] = dw_Right;

        dw_out += 2;
        dw_in += 2;
        dw_len--;
    }
}

void decrypt(char *inbuf, char *outbuf, long len, char *subkey)
{
    unsigned long dw_Left;
    unsigned long dw_Right;
    unsigned long *dw_in;
    unsigned long *dw_out;
    unsigned long *dw_subkey;
    long dw_len;
    long dw_count;
    unsigned long dw_temp;
    signed long dw_temp2;
    unsigned long dw_initial_key;

    dw_len = len / 8;
    dw_in = (unsigned long *)inbuf;
    dw_out = (unsigned long *)outbuf;
    dw_subkey = (unsigned long *)subkey;
    dw_initial_key = 0xC0DEC0DE;

    while (dw_len) {
        dw_Left = dw_in[0];
        dw_Right = dw_in[1];

        for (dw_count = 0x1F; dw_count >= 0; dw_count--) {
            /* Save dw_Left */
            dw_temp = dw_Left;

            /* F(dw_Left) */
            dw_temp2 = dw_Left;
            dw_temp2 >>= ((dw_subkey[dw_count % 4] & 0xFF) % 32);
            dw_Left <<= ((dw_subkey[dw_count % 4] & 0xFF) % 32);
            dw_temp2 ^= dw_subkey[dw_count % 4];
            dw_temp2 |= dw_Left;

            /* Xor with dw_Right */
            dw_temp2 ^= dw_Right;

            dw_Left = dw_temp2;

            /* dw_Right is now dw_Left */
            dw_Right = dw_temp;
        }

        /* (DESX construction) */
        dw_Right ^= dw_initial_key;
        dw_Left ^= dw_initial_key;
        dw_initial_key = dw_in[0];

        dw_out[0] = dw_Left;
        dw_out[1] = dw_Right;

        dw_out += 2;
        dw_in += 2;
        dw_len--;
    }
}

#ifdef ENCRYPT
void main(void)
{
    FILE *file;
    char buffer[256];
    char obuffer[256];
    long len;
    long count;
    /* md5 hash of password 'squirrel' */
    unsigned char subkey[16] = {
        0xEA, 0xC0, 0x74, 0xB0, 0x50, 0x3B, 0x45, 0x74,
        0x0D, 0x49, 0xB1, 0x8E, 0xB6, 0x59, 0xBC, 0xFC
    };

    file = fopen("data.txt", "rb");
    if (file) {
        len = fread(&buffer, 1, sizeof(buffer), file);
        encrypt(buffer, obuffer, len, subkey);
        fclose(file);

        file = fopen("out.enc", "wb");
        if (file) {
            fwrite(&obuffer, 1, len, file);
            fclose(file);
        }
    }
}
#endif /* ENCRYPT */
#ifdef DECRYPT
void main(void)
{
    FILE *file;
    char buffer[256];
    char obuffer[256];
    long len;
    long count;
    /* md5 hash of password 'squirrel' */
    unsigned char subkey[16] = {
        0xEA, 0xC0, 0x74, 0xB0, 0x50, 0x3B, 0x45, 0x74,
        0x0D, 0x49, 0xB1, 0x8E, 0xB6, 0x59, 0xBC, 0xFC
    };

    file = fopen("out.enc", "rb");
    if (file) {
        len = fread(&buffer, 1, sizeof(buffer), file);
        decrypt(buffer, obuffer, len, subkey);
        fclose(file);

        file = fopen("out.dec", "wb");
        if (file) {
            fwrite(&obuffer, 1, len, file);
            fclose(file);
        }
    }
}
#endif /* DECRYPT */
#ifdef TEDDYBEAR
void main(void)
{
    FILE *file;
    char buffer[256];
    char obuffer[256];
    long len;
    long count;
    /* md5 hash of password 'squirrel' */
    unsigned char subkey[16] = {
        0xEA, 0xC0, 0x74, 0xB0, 0x50, 0x3B, 0x45, 0x74,
        0x0D, 0x49, 0xB1, 0x8E, 0xB6, 0x59, 0xBC, 0xFC
    };

    printf("teddybear solution by DEATH\n");

    file = fopen("tb.enc", "rb");
    if (file) {
        len = fread(&buffer, 1, sizeof(buffer), file);
        decrypt(buffer, obuffer, len, subkey);
        fclose(file);

        /* Buffer is padded with 2 NULLs */
        printf("%s\n", obuffer);
    } else {
        printf("rename teddybear.enc to tb.enc and watch decryption magic :)\n");
    }
}
#endif /* TEDDYBEAR */
