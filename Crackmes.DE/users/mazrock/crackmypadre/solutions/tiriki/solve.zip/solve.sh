./crackmypadre &
sleep 2
ps -a|grep crackmypadre|cut --delimiter=' ' -f 1 >livret_famille
