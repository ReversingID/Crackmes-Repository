When I start solve.sh>foo.txt, the file foo.txt will contain the 
password.

What solve.sh does:
First it starts crackmypadre, then it waits two seconds before it 
gets the PIDs with ps -a. This is piped thru grep which eliminates 
every line not containing crackmypadre. This is again piped to cut 
which cuts the first column and saves to the file livret_famille.

Then you just have to wait for crackmypadre to finish.