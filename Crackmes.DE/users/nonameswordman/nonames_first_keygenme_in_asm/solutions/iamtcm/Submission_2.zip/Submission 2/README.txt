CrackMe1.0ForAsm Keygen
By: TCM

1. Double Click keygen.exe

2. Enter in a username of at least 10 characters. (ex. 'RedStripeBeer').

3. If a solution is found, a file called "key.txt" will be written to the current directory.

4. View key.txt in a unicode enabled text viewer (WordPad) and use it as your key.

NOTE: All keys will be in the format X__________X where underscore is a random letter based on your name.