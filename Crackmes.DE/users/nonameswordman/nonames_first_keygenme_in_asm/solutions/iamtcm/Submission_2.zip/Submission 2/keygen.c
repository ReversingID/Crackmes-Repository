//Coded on January 29rd, 2008 by TCM
//Beer: Red Stripe (JAMAICA! JAMAICA!)
//Music: Nightmares on Wax
//Disassembler/Debugger: OllyDbg 1.10
//Compiler: Dev-C++ 4.99

//Values used for testing
//Name: RedStripeBeer
//Key: X�gkdgjeddX

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include <math.h>

#define NAMELEN 24
#define KEYLEN 12
#define MINKEYSIZE

typedef struct combo{  //Struct for value hashes
       uint32_t name_hash;
       uint32_t key_hash;
} combo_t;       

uint32_t hardCode1 = 0x00401001 + 0x0040138C; //Hardcoded Values 1
uint32_t hardCode2 = 0x00401447 + 0x0040119A; //Hardcoded Values 2
uint32_t alt = 0;

//This function imitates the username/key compare found in the keygenme
void calculateHash(char * name, char * key, combo_t * combo)
{
 combo->name_hash = (*(uint32_t *)(name+1));
 combo->key_hash  = (*(uint32_t *)(key+1));
 
 combo->name_hash += (*(uint32_t *)(name+2));
 combo->key_hash  += (*(uint32_t *)(key+5));
  
 combo->name_hash += (*(uint32_t *)(name+6));
 combo->key_hash  += (*(uint32_t *)(key+6));
  
 combo->name_hash += (*(uint32_t *)(name+3));
 combo->key_hash  += (*(uint32_t *)(key+4));
 
 combo->name_hash += hardCode2;
 combo->key_hash  += hardCode1;
}

int main()
{
 combo_t * combo = NULL;
 char * name = NULL;
 char * key = NULL;
 int p24, p16, p8;
 int length;
 
 name = (char *)malloc(sizeof(char)*NAMELEN);
 key = (char *)malloc(sizeof(char)*KEYLEN);
 combo = (combo_t *)malloc(sizeof(combo_t));
 
 if(name == NULL || key == NULL || combo == NULL)
 {
          fprintf(stderr, "- Out of Memory\n");
          return -1;
 }
 
 memcpy(key, "X000000000X", 11); //This is the initial key to start (general solution beginning)
 key[11] = '\0';

 
 fprintf(stdout, "Please enter a name that is at least 10 characters!\n");
 fprintf(stdout, "Name: ");
 fgets(name, 24, stdin); 
 length = strlen(name);
 
 if(length-1 < 10)
 {
             fprintf(stderr, "- Name is less than 10 characters\n");
             return -1;
 }
 
 //Set up pow checks
 p24 = pow(2, 24);
 p16 = pow(2, 16);
 p8 = pow(2, 8);
 
 while(1) //Infinite Loop (joy!)
 {
 
 calculateHash(name, key, combo);  //Calculate latest hash
 
 
 if(combo->name_hash != combo->key_hash)   //If hashes are not equal, then find new hash
 {
              if(combo->name_hash > combo->key_hash)  //Drilling down
              {
                           uint32_t diff = combo->name_hash - combo->key_hash; //Difference in name-key
                           uint32_t change = 0;
                           uint32_t pos = 0;
                           
                           
                           //Large if/else to find which character to increase
                           if(diff >= p24+p16+p8)
                           {
                               if(alt % 4 == 0)
                                 pos=7;
                               else if(alt % 4 == 1)
                                 pos=8;   
                               else if(alt % 4 == 2)   
                                 pos=9;
                               else
                                 pos=4;   
                                
                                   change = 1;
                           }
                           else if(diff >= p24+p16)
                           {
                                   change = diff/(p24+p16);
                                   pos=8;
                           }
                           else if(diff >= p24)
                           {
                                   change = diff/p24;
                                   if(alt % 2 == 1)
                                     pos = 9;
                                   else
                                     pos = 4;
                           }
                           else if(diff >= p16+p8)
                           {
                                   if(alt % 2 == 1)
                                          pos=3;
                                   else
                                          pos=6;
                                   change=1;
                           }
                           else if(diff >= p16)
                           {
                                   if(alt % 3 == 1)
                                     pos = 2;
                                   else if(alt % 3 == 2)
                                     pos = 5;
                                   else
                                     pos = 3;
                                   change = 1;
                           }
                           else if(diff >= p8)
                           {
                                   change = 1;
                                   if(alt % 2 == 1)
                                     pos = 2;
                                   else
                                     pos = 5;
                           }
                           else
                           {
                                  change = 1;
                                  pos = 1;
                           }
                           
                           key[pos]+=change; 
                           
              }
              else  //Change characters to make this a same signed comparison
              {
                  if(alt % 4 == 0)
                                 key[7]++;
                  else if(alt % 4 == 1)
                                 key[8]++;     
                  else if(alt % 4 == 2)   
                                 key[9]++; 
                  else
                                 key[4]++;    
                                 
                  if((uint8_t)key[7] > 253 || 
                     (uint8_t)key[8] > 253 || 
                     (uint8_t)key[9] > 253 || 
                     (uint8_t)key[4] > 253)
                  {
                            fprintf(stderr, "- Failure. Could never make the value positive\n");
                            return -1;
                  }
              }
              alt++;
}
else
    break;
}
              
 if(combo->name_hash == combo->key_hash)
 {
              FILE * outfile = fopen("key.txt", "wb");
              if(outfile == NULL)
              {
                         fprintf(stderr, "- Cannot open file key.txt for writing\n");
                         return -1;
              }
              if(fprintf(outfile, "key = %s\n", key) < 0)
              {
                         fprintf(stderr, "- Cannot write to file key.txt\n");
                         return -1;
              }
              else
              {
                         fclose(outfile);
                         fprintf(stdout, "+ Success!\n+ Please open the file key.txt with wordpad or another UNICODE enabled text editor\n");
                         fprintf(stdout, "+ For Reference: the name entered was %s\n", name);
              }
 }
 
 free(combo);
 free(key);
 free(name);
 
 system("pause");
 return 0;   
}
