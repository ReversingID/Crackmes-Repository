if you crack it,it will MessageBox ....

Please send me the letter after you crack it

(Sorry,my English is awful.)