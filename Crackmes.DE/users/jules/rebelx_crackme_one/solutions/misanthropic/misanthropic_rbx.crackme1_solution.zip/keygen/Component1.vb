Public Class Component1
    Inherits System.ComponentModel.Component

#Region " Codice generato da Progettazione componenti "

    Public Sub New(Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Necessario per il supporto della finestra di progettazione per la composizione della classe Windows.Forms
        Container.Add(me)
    End Sub

    Public Sub New()
        MyBase.New()

        'Chiamata richiesta da Progettazione componenti.
        InitializeComponent()

        'Aggiungere le eventuali istruzioni di inizializzazione dopo la chiamata a InitializeComponent()

    End Sub

    'Il componente esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Richiesto da Progettazione componenti
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue � richiesta da Progettazione componenti.
    'Pu� essere modificata in Progettazione componenti.  
    'Non modificarla nell'editor del codice.
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog

    End Sub

#End Region

End Class
