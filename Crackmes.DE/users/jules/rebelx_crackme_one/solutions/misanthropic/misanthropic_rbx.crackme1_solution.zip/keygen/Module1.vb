Module Module1
    Private af, dk, indk, nofx As Int32
    Private misfit, pennywise, snfu, vandals As String

    Sub Main()
        nofx = ((Convert.ToInt32(DateTime.Now.Day.ToString) * Convert.ToInt32(DateTime.Now.Month.ToString)) * Convert.ToInt32(DateTime.Now.Year.ToString))
        misfit = CType(((Strings.Len(Convert.ToString(System.Security.Principal.WindowsIdentity.GetCurrent.Name)) * indk) * nofx), String)
        dk = CType(Math.Round(CType(((CType(misfit, Double) * nofx) * CType(misfit, Double)), Double)), Integer)
        af = CType(Math.Round(CType((((CType(misfit, Double) * CType(misfit, Double)) * nofx) * 4), Double)), Integer)
        misfit = Conversion.Hex(((((CType(misfit, Double) * CType(misfit, Double)) * CType(misfit, Double)) * nofx) - nofx))
        dk = CType(Math.Round(CType((CType(Conversion.Oct((dk * dk)) * (dk * 5), Double)), Double)), Integer)
        vandals = (Convert.ToString(misfit) & Convert.ToString(dk) & Convert.ToString(af))
        snfu = (Convert.ToString(af) & Convert.ToString(dk) & Convert.ToString(misfit))
        Clipboard.SetDataObject(vandals)
        MsgBox("Generated serial is: " & vandals & ControlChars.CrLf & "Open the crackme and press CTRL+V" & ControlChars.CrLf & "Let's proceed with storing the keyfile (that must be in the same directory of the crackme)", MsgBoxStyle.Information, "serial")
        Dim comp As New Component1
        comp.SaveFileDialog1.DefaultExt = ".txt"
        comp.SaveFileDialog1.FileName = "rbx.crckme.txt"
        comp.SaveFileDialog1.Filter = "rbx-crackme key files (rbx.crckme.txt)|rbx.crckme.txt"
        comp.SaveFileDialog1.Title = "Save key file"
        comp.SaveFileDialog1.ShowDialog()
        Dim path As String = comp.SaveFileDialog1.FileName
        If path = "rbx.crckme.txt" Then End
        path = Left(comp.SaveFileDialog1.FileName, comp.SaveFileDialog1.FileName.LastIndexOf("\"))
        If Not System.IO.File.Exists(path.Concat("Rebelx crackme 1.exe")) Then
            MsgBox("Error while writing keyfile. The path specified is wrong.", MsgBoxStyle.Critical, "argh!")
            End
        End If
        Dim fs As System.IO.StreamWriter = New System.IO.StreamWriter(comp.SaveFileDialog1.FileName)
        fs.Write(snfu)
        fs.Close()
        MsgBox("Keyfile written succesfully.", MsgBoxStyle.Information, ":)")
    End Sub
End Module
