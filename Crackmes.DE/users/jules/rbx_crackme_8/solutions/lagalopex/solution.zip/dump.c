#include <stdio.h>
#include <sys/ptrace.h>

int main(int argc, char *argv[])
{
	char data[60];
	int i, p = atoi(argv[1]), t;
	if (ptrace(PTRACE_ATTACH, p, 0, 0)) {
		perror("ptrace attach");
		return 1;
	}

	for (i = 0; i < 30; ++i) {
		if ((t = ptrace(PTRACE_PEEKDATA, p, 0x804aa58 + 2 * i, 0)) == -1)
			perror("ptrace peek");
		else {
			data[2 * i] = t & 0xff;
			data[2 * i + 1] = (t >> 8) & 0xff;
		}
	}

	ptrace(PTRACE_DETACH, p, 0, 0);

	printf("Serial 1: %s\n", data);
	printf("Serial 2: %s\n", data+20);
	printf("Serial 3: %s\n", data+40);

	return 0;
}