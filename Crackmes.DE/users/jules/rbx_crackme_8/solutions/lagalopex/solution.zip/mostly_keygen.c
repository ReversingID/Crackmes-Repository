#include <stdio.h>
#include <string.h>
#include <math.h>

float p1(const char *name, const char *comp, char *seri)
{
	int i;
	float s1 = 0, s2 = 0, s3 = 0, c, d;
	double a, b;

	for (i = 0; name[i]; ++i)
		s1 += (name[i] ^ strlen(name))%name[i];
	for (i = 0; comp[i]; ++i)
		s2 += (comp[i] ^ strlen(comp))%comp[i];

	/* FIXME: This is the problematic loop */
	for (i = strlen(name) + strlen(comp); i > 1; --i)
		s3 += ((char)name[i]) ^ ((char)strlen(comp));

	a = sqrt(s1);
	d = (double)s3 / s2;
	b = atan(d);
	c = s1 * s2;
	d = a * b * c;

	sprintf(seri, "%f.%f", d, 0.0);
	return d;
}

float p2(const char *comp, char *seri)
{
	int i, s1 = 0, s2 = 0, s3 = 0, s4 = 0;
	float x;

	for (i = 0; i < strlen(comp); ++i)
		s1 += comp[i] ^ strlen(comp);

	for (i = strlen(comp); i > 1; --i)
		s2 += comp[i] ^ strlen(comp);

	for (i = 0; i < strlen(seri); ++i)
		s3 += seri[i] ^ s1;

	for (i = 0; i < strlen(seri); ++i)
		s4 += seri[i] ^ s2;

	x = s3 * s4;

	sprintf(seri + 20, "%4.4f.%4.4f", x, 0.0);
	return x;
}

void p3(float a, float b, char *seri)
{
	float c = -1713714.0;
	sprintf(seri+40, "%4.4f", a + b + c);
}

int main(int argc, char *argv[])
{
	char name[64] = {0x34, 0xa6, 0x04, 0x08, 0x38, 0xcc, 0xff, 0xff,
			 0xe1, 0x92, 0x04, 0x08, 0x01, 0x00, 0x00, 0x00,
			 0xff, 0xff, 0x00, 0x00, 0x48, 0xcc, 0xff, 0xff,
			 0x09, 0x89, 0x04, 0x08, 0x34, 0xa6, 0x04, 0x08,
			 0x40, 0xaa, 0x04, 0x08, 0x48, 0xcc, 0xff, 0xff,
			 0x7c, 0xcc, 0xff, 0xff, 0x89, 0x88, 0x04, 0x08,
			 0x01, 0x00, 0x00, 0x00, 0x84, 0xcc, 0xff, 0xff,
			 0x8c, 0xcc, 0xff, 0xff, 0x7e, 0x88, 0x04, 0x08};
	/* FIXME: dumped memory, previously used by pointers and thus
	 *        highly dynamic.
	 */

	char comp[32];
	char serial[60];
	float a, b;

	printf("Name: ");
	fflush(stdout);
	scanf("%s", name);
	printf("Company: ");
	fflush(stdout);
	scanf("%s", comp);

	a = p1(name, comp, serial);

	b = p2(comp, serial);

	p3(a, b, serial);

	printf("\nS1: %s\nS2: %s\nS3: %s\n", serial, serial+20, serial+40);

	return 0;
}
