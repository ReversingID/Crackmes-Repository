This is my crackme number 3, the goal is to find a correct
serial for your name or programing a keygen.
If you can manage to detect all the junkcode you are almost
done, because the calculation is simple enough.
Good Luck

P.D. I'm really sorry, because I first uploaded a version
     of the crackme with 2 bugs that now are fixed.