#include <stdio.h>

char username[51];

int main()
{
	unsigned int n;
	int tmp,len,a,b,c,d,e,f;

        printf("-------------------------------------------------------------------------------\n");
        printf("  Keygen for eSn-mIn's Linux Crackme                         by kRio (C) 2004  \n");
        printf("-------------------------------------------------------------------------------\n\n");
	printf(" [-] Enter your name: ");
	scanf("%50s",username);
	
	n=0;
	len=strlen(username);
	while (len > 0)
	{
		n = (n + username[len-1]) * 37;
		len--;
	}

	b=n%17+1;
	c=n%16+1;
	a=43-b-c;
	
	if (c==1)
	{
		printf(" [-] Your serial is : ");
		for (tmp=0;tmp<42;tmp++)
		{
			printf("a");
		}
		printf("c\n");
		printf(" [X] You sure have a lucky name! ;]\n\n");
		return 255;
	}
	
	d=c%2;
	e=a-c/2;
	f=b-c/2;
	
	#ifdef DEBUG
		printf(" [?] N = %u;\n",n);
		printf(" [?] A = (N MOD 17)+1 = %u; B = (N MOD 16)+1 = %u; C = (A-B) = %u;\n",a,b,c);
		printf(" [?] C/2 = %u; D = %u; E = %u; F = %u;\n",c/2,d,e,f);
	#endif
	
	if (a < c/2 || b < c/2)
	{
		printf(" [X] Oppsss...my algorithm is unable to find a good serial for your name!\n");
		printf(" [X] Advice: add something to your name -- empty space, plus, minus... ;]\n");
		return 1;
	}

	printf(" [-] Your serial is : ");

	for (tmp=0;tmp<e;tmp++)
	{
		printf("a");
	}
	for (tmp=0;tmp<f;tmp++)
	{
		printf("b");
	}
	for (tmp=0;tmp<c/2;tmp++)
	{
		printf("cabc");
	}
	if (d>0)
	{
		printf("c");
	}
	printf("\n\n");

	return 0;
}