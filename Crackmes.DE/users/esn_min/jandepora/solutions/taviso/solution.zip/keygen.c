#include <stdio.h>
#include <string.h>

/* keygen for eSn-mIn's crackme #4 
 *
 * 01/01/2005
 *
 * - taviso@sdf.lonestar.org 
 *
 */

int main(int argc, char **argv)
{
    char name[51], serial[51];
    unsigned int n, a, b, c, l, node;

    fprintf(stdout, "[*] Enter name: ");
    fscanf(stdin, "%50s", name);

    /* find out frequency counts of a/b/c */
    for (n = 0, l = strlen(name); l > 0; l--)
        n = (n + name[l - 1]) * 37;
    
    b = n % 17 + 1;
    c = n % 16 + 1;
    a = 43 - b - c;

    /* initialize serial */
    memset(serial, '\0', sizeof(serial));

    n = 0;

    /* we can use up a few a's and b's traversing back and forth
     * on the first node of the graph 
     */
    while (a - a%2 > c/2 && a + b + 2 >= c)
        serial[n++] = 'a', a--;
    while (b - b%2 > c/2 && a + b + 2 >= c)
        serial[n++] = 'b', b--;

    /* the rest are exhausted by traversing the pattern 
     *  
     *      1 -> 4 -> 3 -> 5 -> 1
     *
     */
    fprintf(stderr, "[*] Traversing graph...\n[*] ");
    for (node = 0; n < 43 ; n++) {
        fprintf(stderr, "%u->", node, a, b, c);
        switch (node) {
            case 0:
                serial[n] = 'c', c--, node = 1;
                break;
            case 1:
                if (b > 0) serial[n] = 'b', b--, node = 4;
                else if (a > b) serial[n] = 'a', a--, node = 2;
                else goto error;
                break;
            case 2:
                if (b >= a) serial[n] = 'b', b--, node = 3;
                else if (a > b) serial[n] = 'a', a--, node = 1;
                else goto error;
                break;
            case 3:
                if (c > 0) serial[n] = 'c', c--, node = 5;
                else if (b >= a) serial[n] = 'b', c--, node = 2;
                else if (a > b) serial[n] = 'a', c--, node = 4;
                else goto error;
                break;
            case 4:
                if (c > 0) serial[n] = 'a', a--, node = 3;
                else if (a >= b) serial[n] = 'a', a--, node = 3;
                else if (b > a) serial[n] = 'b', b--, node = 1;
                else goto error;
                break;
            case 5:
                if (c > 0) serial[n] = 'c', c--, node = 1;
                else if (b > 0) serial[n] = 'b', b--, node = 6;
                else if (a > 0) serial[n] = 'a', a--, node = 6;
                else goto error;
                break;
            case 6:
                if (b > 0) serial[n] = 'b', b--, node = 5;
                else if (a > 0) serial[n] = 'a', a--, node = 5;
                else goto error;
                break;
error:      case 7:
                fprintf(stderr, "error.\n"
                    "[!] No solutions found, try a different name!\n");
                exit(1);
        }
    }

    fprintf(stdout, "done.\n[*] Serial: %s\n", serial);
}
