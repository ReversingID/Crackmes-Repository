#include <stdio.h>
#include <windows.h>
#include "resource.h"

//#define WIN32_LEAN_AND_MEAN

#include "md5c.c"


BOOL CALLBACK DlgProc(HWND hWnd, UINT Message, WPARAM wParam, LPARAM lParam)
{	

	switch (Message)
	{    
	    case WM_CLOSE:
		  EndDialog(hWnd,0);
		  break;
	    case WM_COMMAND:
		   switch (LOWORD(wParam))
				case IDCGenerate:
						{
							DWORD c1,c2,x1,x2,x3,x4,t,a,s1,s2;
							MD5_CTX md5;
							unsigned char digest[16],szName[100]={NULL},szSerial1[17]={NULL},
								szSerial2[8]={NULL};
							int Len=GetDlgItemText(hWnd,IDName,szName,100);
							MD5Init(&md5);
							MD5Update(&md5,szName,Len);
							MD5Final(digest,&md5);

							_asm
								{
									lea edi,digest;
									mov eax,dword ptr[edi]
									mov x1,eax
									mov eax,dword ptr[edi+4]
									mov x2,eax
									mov eax,dword ptr[edi+8]
									mov x3,eax
									mov eax,dword ptr[edi+12]
									mov x4,eax;
								}
							c1=0x6779656B;
							c2=0x656D6E65;
							t=(x1^x3);
							s2=((c2/32+x2)^(c2*16+x1)^(c2+t))+c1;


							a=(s2*16+x3)^(s2+t)^(s2/32+x4);
							s1=c2+a;


							wsprintf(szSerial1,"%08X",s1);
							wsprintf(szSerial2,"%08X",s2);
							lstrcat(szSerial1,szSerial2);
							SetDlgItemText(hWnd,IDSerial,szSerial1);
						}
				
	}

return 0;
}





int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR szCmdLine, int nCmdShow)
{

  DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, (DLGPROC)DlgProc,0);
  return 0;
}
