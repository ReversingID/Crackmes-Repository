//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by KeygenDlg.rc
//
#define IDD_DIALOG1                     101
#define IDGenerate                      1000
#define IDCGenerate                     1000
#define IDSerial                        1003
#define IDName                          1004
#define lblUser                         1008
#define lblSerial                       1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
