#include <stdio.h>
#include <windows.h>
#include "resource.h"

/*A keygen for Keygenning4newbies Crackme 3 - Coded by yar0n7 */
/*Date: 28.9.2002*/

BOOL CALLBACK DlgProc(HWND hWnd, UINT Message, WPARAM wParam, LPARAM lParam)
{	

	switch (Message)
	{    
	    case WM_CLOSE:
		  EndDialog(hWnd,0);
		  break;
	    case WM_COMMAND:
		   switch (LOWORD(wParam))
				case IDCGenerate:
						{
							char szName[64]={NULL};
							char Target[]="KEYGENNING4NEWBIES";
							char Letter[]="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
							char szSerial[19]={NULL};
							char szStr[18];
							DWORD CurrentStr,MagicValue,iVal;
							short i,cont1,cont2;
							static unsigned long Table[16] = {
							0x00000012, 0x0000005C, 0x00000034, 0x00000022, 
							0x000000AB, 0x0000009D, 0x00000054, 0x00000000, 
							0x000000DD, 0x00000084, 0x000000AE, 0x00000066, 
							0x00000031, 0x00000078, 0x00000073, 0x000000CF };

							int Len=GetDlgItemText(hWnd,IDName,szName,64);

							if (Len<1) 
							{
								MessageBox(hWnd,"Please Enter a Name!","Error",MB_OK|MB_ICONEXCLAMATION);
								return 0;
							}


							lstrcat(szName," is a whore.");
							MagicValue=0x68656865;
							//Calculating the Magic value out of the entered Name 
							for(i=0,cont1=0,cont2=0; i<16 ;i++,cont1++,cont2++)
								{
								  CurrentStr=( (szName[4*i+3]<<8) + szName[4*i+2])<<8;
							 	  CurrentStr=((CurrentStr + szName[4*i+1])<<8) + szName[4*i];
								  iVal=Table[cont1];
								  iVal^=cont2;
								  CurrentStr+=iVal;
								  CurrentStr=_lrotl(CurrentStr,7);
								  MagicValue^=CurrentStr;
								}


							for(i=0;i<18;i++)
							{
							  szStr[i] = Letter[MagicValue%26]; 
							  _asm
							  {
								mov eax, dword ptr[MagicValue]
								shl eax, 3
								imul eax
								add eax, edx
								mov dword ptr[MagicValue], eax
							  }
							}

							for( i = 0 ; i<18 ; i++ )
							  szSerial[i] = (Target[i] ^ i ^ szStr[i]) + 0x30;

							SetDlgItemText(hWnd,IDSerial,szSerial);
							break;
						}
				
	}

return 0;
}



int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR szCmdLine, int nCmdShow)
{
  DialogBox(hInstance, MAKEINTRESOURCE(IDD_DIALOG1),NULL,(DLGPROC)DlgProc);
  return 0;
}
