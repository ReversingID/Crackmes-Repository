#include <stdio.h>
#include <windows.h>
#include <stdlib.h>
#include "resource.h"


BOOL CALLBACK DlgProc(HWND hWnd,UINT message,WPARAM wParam,LPARAM lParam)
{
  switch (message)
  {
	case WM_CLOSE:
	  {
		EndDialog(hWnd,0);
		return 0;
	  }
	case WM_COMMAND:
		{
			switch (LOWORD(wParam))
				{
					case IDCGenerate: 
						{
							char szName[100]={NULL};
							char Target[]="KEYGENNING4NEWBIES";
							char Letter[]="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
							char szSerial[19]={NULL};
							char szStr[18];
							__int64 Tmp;
							int Len=GetDlgItemText(hWnd,IDName,szName,100);
							DWORD CurrentStr,MagicValue,iVal;
							short i,cont1,cont2;
							static unsigned long Table[16] = {
							0x00000012, 0x0000005C, 0x00000034, 0x00000022, 
							0x000000AB, 0x0000009D, 0x00000054, 0x00000000, 
							0x000000DD, 0x00000084, 0x000000AE, 0x00000066, 
							0x00000031, 0x00000078, 0x00000073, 0x000000CF };



							lstrcat(szName," is a whore.");
							MagicValue=0x68656865;
							/*Calculating the Magic value out of the entered Name */
							for(i=0,cont1=0,cont2=0; i<16 ;i++,cont1++,cont2++)
								{
								  CurrentStr=( (szName[4*i+3]<<8) + szName[4*i+2])<<8;
							 	  CurrentStr=((CurrentStr + szName[4*i+1])<<8) + szName[4*i];
								  iVal=Table[cont1];
								  iVal^=cont2;
								  CurrentStr+=iVal;
								  CurrentStr=_lrotl(CurrentStr,7);
								  MagicValue^=CurrentStr;
								}


							for(i=0;i<18;i++)
							{
							  szStr[i] = Letter[MagicValue%26]; 
							  //Tmp = (__int64)( (DWORD)((__int64)(MagicValue*8))*((DWORD)(__int64)(MagicValue*8)) );
							  //Tmp = (DWORD)(   (Tmp & 0xFFFFFFFF ) + (Tmp>>32) );
							  //MagicValue = (DWORD)(Tmp&0xFFFFFFFF);
							  _asm
							  {
								mov eax, dword ptr[MagicValue]
								shl eax, 3
								mov edx, 12345h
								imul eax
								add eax, edx
								mov dword ptr[MagicValue], eax
							  }
							}

							for( i = 0 ; i<18 ; i++ )
							  szSerial[i] = (Target[i] ^ i ^ szStr[i]) + 0x30;

							SetDlgItemText(hWnd,IDSerial,szSerial);
						}
				}

		}

  }
return 1;
}



int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR szCmdLine, int nCmdShow)
{
  DialogBox(hInstance, MAKEINTRESOURCE(IDD_DIALOG1),NULL,(DLGPROC)DlgProc);
  return 0;
}
