keygenning4newbies Crackme 2
coded by the analyst [UCF/ID]

Goal:

code a keygen, write a tutorial and send me the package *g* to acid2600@hotmail.com.
Essays will be published on the site:)
This one is a little bit harder than the 1st one ;)
It is prolly a good target for newbies :)


www.keygenning4newbies.cjb.net

regards,

the analyst.

please also visit : www.oldreverser.cjb.net