keygenning4newbies Crackme 1
coded by the analyst [UCF/ID]

Goal:

code a keygen, write a tutorial and send me the package *g* to acid2600@hotmail.com.
Essays will be published on the site:)

www.keygenning4newbies.cjb.net

regards,

the analyst.

