/*
	Subject: 
 		Solution and keyGen for the Keygenning4newbies crackme 1.

	Author:
		stac@walla.co.il 06/10/2003 (d/m/y)
		
	URL:
		http://crackmes.de/crackmeinfo.php?ID=436
		
	Tools:
		OllyDbg for cracking the crakme.
		IDA pro for copy the source code.
		Dev-C++ with Mingw for KeyGen writng.
	
	Intro:
		Well as i see it the best way to learn from tut is to first try cracking the CrackMe
	by your self, if you work hard anuff then you will be not needing to any one solution,
	but lets stop the bullshit and begin the cracking proccess.
	

	Solution:
		This crack me very good for newbies like us, the main idea is to teach us how to
	implement the serial genaretion algorithm into the code.
	
		Lets begin.

		Start the CrackMe, I at first try to click the buttons and not entering any text,
	so i clicked the button got the message, great :) so i started the IDO look for strings
	'This serial is *NOT* Valid!! Try again... : UNREGISTERED' :) got little bit up and sow 
 	the API calls to get text from TexBoxes:
 	

CODE:0040108D                 push    64h             ; nMaxCount
CODE:0040108F                 lea     edx, [ebp+s]		; <--- get name
CODE:00401095                 push    edx             ; lpString
CODE:00401096                 push    eax             ; hWnd
CODE:00401097                 call    GetWindowTextA

CODE:004010A4                 push    64h             ; nMaxCount
CODE:004010A6                 lea     ecx, [ebp+String1] ; <--- get serial
CODE:004010AC                 push    ecx             ; lpString
CODE:004010AD                 push    eax             ; hWnd
CODE:004010AE                 call    GetWindowTextA


	now the next lines is to get length of name and to check if name is more then
	3 chars and less then 50 chars.

CODE:004010BB                 mov     esi, eax
CODE:004010BD                 lea     eax, [ebp+s]
CODE:004010C3                 push    eax             ; s
CODE:004010C4                 call    _strlen
CODE:004010C9                 pop     ecx
CODE:004010CA                 mov     [ebp+var_28], eax
CODE:004010CD                 lea     edx, [ebp+String1]
CODE:004010D3                 push    edx             ; s
CODE:004010D4                 call    _strlen
CODE:004010D9                 pop     ecx
CODE:004010DA                 push    offset s        ; s
CODE:004010DF                 call    _strlen
CODE:004010E4                 pop     ecx
CODE:004010E5                 push    offset unk_40B10E ; s
CODE:004010EA                 call    _strlen
CODE:004010EF                 pop     ecx
CODE:004010F0                 cmp     [ebp+var_28], 3	;<-- if (strlen(name)<3) jump;
CODE:004010F4                 jle     short loc_401171 ;MsgBox "name must contain bla bla :)"
CODE:004010F6                 nop
CODE:004010F7                 nop
CODE:004010F8                 nop
CODE:004010F9                 nop
CODE:004010FA                 xor     ecx, ecx
CODE:004010FC                 xor     edx, edx
CODE:004010FE                 xor     ebx, ebx
CODE:00401100                 xor     eax, eax
CODE:00401102                 cmp     [ebp+var_28], 32h ;<-- if (strlen(name)>3) jump;
CODE:00401106                 jge     short loc_401171	; MsgBox "name must contain bla bla :)"

 	next lines is code generation. :). you see pretty simple. 
 	
CODE:0040110C loc_40110C:                             ; CODE XREF: sub_401000+11Cj
															; i=0
CODE:0040110C                 movsx   eax, [ebp+ecx+s]		; get first char name[i]
CODE:00401114                 inc     ecx					; i++;
CODE:00401115                 xor     eax, ecx				; name[i-1] ^ i
CODE:00401117                 add     ebx, eax
CODE:00401119                 cmp     ecx, [ebp+var_28]		; check is i <= name_length?
CODE:0040111C                 jnz     short loc_40110C
															
															; after the loop is done...
CODE:0040111E                 imul    eax, 6				; you understand right?
CODE:00401121                 shl     ebx, 7				; you understand right? :)
CODE:00401124                 add     eax, ebx				; you understand right? this is the CODE!!!! :))))

CODE:00401126                 mov     [ebp+var_38], eax
CODE:00401129                 push    [ebp+var_38]
CODE:0040112C                 push    offset aLx      ; <-- format to show the code in HEX with UPPER CASE LETTERS
CODE:00401131                 lea     ecx, [ebp+buffer]
CODE:00401137                 push    ecx             ; buffer
CODE:00401138                 call    _sprintf
															
															;now lets push all to strcmp function
CODE:0040113D                 add     esp, 0Ch			
CODE:00401140                 lea     eax, [ebp+buffer]
CODE:00401146                 push    eax             ; lpString2
CODE:00401147                 lea     edx, [ebp+String1]
CODE:0040114D                 push    edx             ; lpString1
CODE:0040114E                 call    lstrcmpA
CODE:00401153                 test    eax, eax				; is eax==0? :) we hope so :)
CODE:00401155                 jnz     short loc_401164
CODE:00401157                 push    offset aCongratulation ; lpString
CODE:0040115C                 push    esi             ; hWnd
CODE:0040115D                 call    SetWindowTextA
CODE:00401162                 jmp     short loc_40117C
CODE:00401164 ; ???????????????????????????????????????????????????????????????????????????
CODE:00401164 
CODE:00401164 loc_401164:                             ; CODE XREF: sub_401000+155j
CODE:00401164                 push    offset aThisSerialIsNo ; lpString
CODE:00401169                 push    esi             ; hWnd
CODE:0040116A                 call    SetWindowTextA
CODE:0040116F                 jmp     short loc_40117C
CODE:00401171 ; ???????????????????????????????????????????????????????????????????????????


	that is very simmple keyGen me.	
	
	goodbye and all best from Israel!!!!!!
*/

#include <stdio.h>

#define DebugMe printf("DBG#%d\t\tEAX=%d\tEBX=%d\n",j++,_eax,_ebx);

int _strlen(const char* s)
{
	int len = 0;
	while (*s++)
		len++;
   
   return len;
}

int main()
{
    char	sName[50];
    int		szName=0, i=0, j=0, _eax=0, _ebx=0;
    
    printf("KeyGen for the keygenning4newbie by stac@walla.co.il!\n");
    printf("\nEnter name: "); gets(sName);
   	szName = _strlen(sName);

	if (szName < 3 || szName > 50)
    {
    	printf("Error: Name must be more then 3 chars and less then 50 chars.\n");
    	return 1;
    }

	/* generate code to name */
	while (i<szName)
	{
		i++;
		_eax = sName[i-1] ^ i;
		_ebx += _eax;
//		DebugMe;		
	}
	_eax *= 6;
	_ebx = _ebx << 7;
	_eax += _ebx;
	printf("Serial: %X\n",_eax);
	
    return 0;
}
