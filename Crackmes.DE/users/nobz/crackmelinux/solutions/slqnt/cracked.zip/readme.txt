File: CrackmeLinux 
md5: 50e831accdfc9f098f8e17ccedfb5692

password is: 0bfu5c4t3D=-_-"

to check:
./CrackmeLinux 0bfu5c4t3D=-_-\"
