#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

#pragma hdrstop
#include <condefs.h>
#pragma argsused

int main(int argc, char* argv[])
{
        char name [0x1d];
        int i1,i2,i3,i4,i5;
        int vect1[2]={0x0,0x10000};
        int vect2[2]={0x0,0x80000000};
        int vect3[4]={0x0,0x1,0x4000000,0x4000001};
        int vect4[2]={0x0, 0x10};
        int val;
        int ok1,ok2[2],ok3,ok4;
        int cont1,cont2,cont3, cont4,cont5;
        char s1[2][6]={{"ZZZZZ"},{"ZZZZZ"}};
        char s2[2][6]={{"ZZZZZ"},{"ZZZZZ"}};
        char s3[4][6]={{"ZZZZZ"},{"ZZZZZ"},{"ZZZZZ"},{"ZZZZZ"}};
        char s4[2][6]={{"ZZZZZ"},{"ZZZZZ"}};
        char s5[6]={"ZZZZZ"};
        // moltiplicatori
        unsigned int p1[5]={0x31C84B1,0x95EED,0x1C39,0x55,0x1};
        unsigned int p2[5]={0x4452100,0xBE1C0,0x2110,0x5C,0x1};
        unsigned int p3[5]={0x4A75410,0xCAC78,0x2284,0x5E,0x1};
        unsigned int p4[5]={0x3E92110,0xB1FA8,0x1FA4,0x5A,0x1};
        unsigned int p5[5]={0x36A2C21,0xA0C47,0x1D91,0x57,0x1};
        char *title1="keygen for Lightning's Crackme #4";
        char *title2="by ZaiRoN";

        printf("%s\n%s\n\n",title1,title2);
        printf("Your name: ");
        gets(name);

        printf("...and your serials:\n");
        /* for s1 */
        _asm{
        xor esi,esi
        xor edx,edx
        lea ebx, name
        mov ecx, dword ptr [ebx+esi]
        @1cycle2:
        movsx eax, byte ptr [ebx+esi]
        test al, al
        jz  @1end
        mov edx, eax
        push 8
        shl eax, 0x18
        pop edi
        @1cycle1:
        add eax, eax
        test eax, eax
        jns @1no_xor
        xor eax, 0xDB8173E4
        @1no_xor:
        dec edi
        jnz @1cycle1
        sub eax, edx
        xor ecx, eax
        mov eax, ecx
        shr eax, 0x1B
        shl ecx, 0x5
        or  ecx, eax
        inc esi
        cmp esi, 0x1D
        jl @1cycle2
        @1end:
        push ecx
        pop dword ptr [val]
        }
        vect1[0]=vect1[0] ^ val;
        vect1[1]=vect1[1] ^ val;
        for (cont1=0;cont1<2;cont1++)
        {
                val=vect1[cont1];
                for(i1=0;i1<5;i1++)
                {
                        if ((val / p1[i1]) !=0)
                        {
                                s1[cont1][i1]=(val/p1[i1])+0x21;
                                val=(val%p1[i1]);
                        }
                        else s1[cont1][i1]=0x21;
                }
                s1[cont1][i1]=0x0;
                /* for s3 */
                vect3[0]=0x0;
                vect3[1]=0x1;
                vect3[2]=0x4000000;
                vect3[3]=0x4000001;
                _asm {
                xor esi,esi
                lea ebx, name
                mov edx, dword ptr [ebx+esi]
                @3cycle2:
                mov al, byte ptr [ebx+esi]
                test al, al
                jz  @3end
                movsx eax, al
                mov ecx, eax
                push 8
                shl ecx, 18h
                pop edi
                @3cycle1:
                add ecx, ecx
                test ecx, ecx
                jns @3no_xor
                xor ecx, 0x69A5F02C
                @3no_xor:
                dec edi
                jnz @3cycle1
                xor eax, ecx
                xor edx, eax
                mov eax, edx
                mov ecx, edx
                shr eax, 0x1D
                shl ecx, 3
                or  eax, ecx
                inc esi
                cmp esi, 0x1D
                mov edx, eax
                jl @3cycle2
                @3end:
                push edx
                pop dword ptr [val]
                }
                vect3[0]=vect3[0] ^ val;    
                vect3[1]=vect3[1] ^ val;
                vect3[2]=vect3[2] ^ val;
                vect3[3]=vect3[3] ^ val;
                for (cont3=0;cont3<4;cont3++)
                {
                        val = vect3[cont3];
                        for(i3=0;i3<5;i3++)
                        {
                                if ((val / p3[i3]) !=0)
                                {
                                        s3[cont3][i3]=(val/p3[i3])+0x21;
                                        val=(val%p3[i3]);
                                 }
                                 else s3[cont3][i3]=0x21;
                        }
                        s3[cont3][i3]=0x0;
                        ok1=vect1[cont1];
                        ok3 = vect3[cont3];
                        // for s4
                         vect4[0]=0x0;
                         vect4[1]=0x10;
                        _asm
                        {
                        mov eax, dword ptr [ok1]
                        mov ecx, dword ptr [ok3]
                        mov esi, eax
                        xor esi, ecx
                        sub esi, eax
                        push 0x1f
                        sub esi, ecx
                        pop ecx
                        mov eax, esi
                        xor edx, edx
                        mov edi, ecx
                        div edi
                        mov eax, esi
                        mov edi, esi
                        sub ecx, edx
                        shr eax, cl
                        mov ecx, edx
                        shl edi, cl
                        or eax, edi
                        imul eax, 0x343fd
                        add eax, 0x269ec3
                        mov dword ptr [val], eax
                        sar eax, 0x10
                        and eax, 0x7fff
                        cdq
                        mov ecx, 0xffff
                        idiv ecx
                        cmp edx, 0
                        jbe @4end
                        @4cycle:
                        mov eax, dword ptr [val]
                        imul eax, 0x343fd
                        add eax, 0x269ec3
                        mov dword ptr [val], eax
                        sar eax, 0x10
                        and eax, 0x7fff
                        mov ecx, eax
                        imul ecx, esi
                        mov eax, dword ptr [val]
                        imul eax, 0x343fd
                        add eax, 0x269ec3
                        mov dword ptr [val], eax
                        sar eax, 0x10
                        and eax, 0x7fff
                        add ecx, eax
                        dec edx
                        mov esi, ecx
                        jnz @4cycle
                        @4end:
                        mov dword ptr [val], esi
                        }
                        vect4[0]=val^vect4[0];
                        vect4[1]=val^vect4[1];
                        for (cont4=0;cont4<2;cont4++)
                        {
                                val = vect4[cont4];
                                for(i4=0;i4<5;i4++)
                                {
                                        if ((val / p4[i4]) !=0)
                                        {
                                                s4[cont4][i4]=(val/p4[i4])+0x21;
                                                val=(val%p4[i4]);
                                         }
                                         else s4[cont4][i4]=0x21;
                                }
                                s4[cont4][i4]=0x0;

                                // for s2
                                ok1=vect1[cont1];
                                ok3=vect3[cont3];
                                ok4=vect4[cont4];
                                vect2[0]=0x0;
                                vect2[1]=0x80000000;

                                _asm {
                                xor ebx, ebx
                                @next:
                                mov eax, dword ptr [vect2+ebx]
                                mov dword ptr [ok2+ebx], eax
                                mov ecx, dword ptr [ok1]
                                xor ecx, dword ptr [ok3]
                                xor ecx, dword ptr [ok4]
                                xor esi,esi
                                @2cycle2:
                                xor edi,edi
                                @2cycle1:
                                mov eax, ecx
                                imul eax, edi
                                add eax, esi
                                add dword ptr [ok2+ebx], eax
                                inc edi
                                cmp edi, 0xf27
                                jnz @2cycle1
                                inc esi
                                cmp esi,0x3e8
                                jnz @2cycle2
                                mov eax, dword ptr [ok2+ebx]
                                mov dword ptr [vect2+ebx], eax
                                cmp ebx, 4
                                jz @end
                                add ebx, 4
                                jmp @next
                                @end:
                                }
                                for (cont2=0;cont2<2;cont2++)
                                {
                                        val=vect2[cont2];
                                        for(i2=0;i2<5;i2++)
                                        {
                                                if ((val / p2[i2]) !=0)
                                                {
                                                        s2[cont2][i2]=(val/p2[i2])+0x21;
                                                        val=(val%p2[i2]);
                                                }
                                                else s2[cont2][i2]=0x21;
                                        }
                                        s2[cont2][i2]=0x0;

                                        // for s5
                                        ok1=vect1[cont1];
                                        ok2[0]=vect2[cont2];
                                        ok3=vect3[cont3];
                                        ok4=vect4[cont4];
                                        _asm {
                                        mov esi, dword ptr [ok4]
                                        mov ebx, dword ptr [ok3]
                                        mov ecx, dword ptr [ok2]
                                        mov eax, dword ptr [ok1]
                                        and eax, 0x000000ff
                                        and esi, 0x00ff0000
                                        and ebx, 0x0000ff00
                                        and ecx, 0xff000000
                                        or esi, eax
                                        or esi, ebx
                                        or esi, ecx
                                        mov dword ptr [val], esi
                                        }
                                        for(i5=0;i5<5;i5++)
                                        {
                                                if ((val / p5[i5]) !=0)
                                                {
                                                s5[i5]=(val/p5[i5])+0x21;
                                                val=(val%p5[i5]);
                                                }
                                                else s5[i5]=0x21;
                                        }
                                        s5[i5]=0x0;
                                        printf("\n   %s %s %s %s %s",s1[cont1], s2[cont2], s3[cont3],s4[cont4],s5);
                                }
                        }
                }
                if (cont1==0)   printf("\npress any key for the other 16 serials...\n");
                else    printf("\n\nany key to quit...");
                getch();
        }
        return 0;
}

