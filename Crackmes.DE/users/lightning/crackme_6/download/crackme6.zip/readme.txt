Lightning's Crackme #6

I'm back with another interesting crackme. The crackme's layout is very
straight forward. I imagine it will still take time to solve though.
Can you figure out what the crackme uses? Of course, no patching is
allowed. A valid key file is allowed.

Basically, it uses a wav file for the protection. Can you name what it is
doing with the wav?

I estimate this is probably level 5 or 6 due to the time I think it will
take to solve it.

I modified this crackme from the original that was submitted to make it
a bit more reconizable as to what it is dealing with. I also decided that
it fits better as a tool-me.

Again, do email me if you solve it.

-Lightning (Lightning@Lightspeed.cx)