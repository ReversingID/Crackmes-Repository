#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int main(int argc, char *argv[])
{
	char *name;
	char *freq, *serial;
	char x, y;
	int i, j;

	printf("+---------------------------------+\n");
	printf("| KeyGen for Lightning's Crackme1 |\n");
	printf("| bY eSn-mIn - 28/1/2003          |\n");
	printf("+---------------------------------+\n\n");
	printf("Serials for the hidden edit: \"aMoxywhtlkzsgGjk\"\n");
	printf("                             \" { 7 .b~HO8_3M89\"\n\n");

	srand(time(0));

	name = (char *)malloc(33);

	printf("Enter your name: ");
	scanf("%32s",name);

	j = strlen(name);
	i = 0;

	while (j<32)
	{
		name[j] = ((char)(name[i+1] - name[i])^name[i+1])* name[j-1] % 0x5E + 0x20;
		i++; j++;
	}

	for (i=0;i<16;i++)
	{
		name[i] ^= name[i+0x10];
	}

	freq = (char *) malloc(256);
	serial = (char *) malloc(33);
	memset(freq,0,256);
	memset(serial,0,33);

	for (i=0;i<16;i++)
	{
		// Always try to find the most elegant solution
		for (y=0x21;y<=0x7E;y++)
		{
			x = ((name[i]&-2)^(y*2)) / 2 + y;
			if (x > 0x20 && x <= 0x7E && freq[x]<2 && freq[y]<2 && \
			   (i==0 || ((((serial[i-1]-serial[i+0x10-1])*2)^(serial[i+0x10-1]*2)) != x && serial[i+0x10-1] != y)))
			{
				serial[i] = x;
				serial[i+0x10] = y;
				freq[x]++; freq[y]++;
				break;
			}
		}
		// If nothing is found..
		if (serial[i]==0)
		{
			if (i==15)
			{
				printf("I've not found any serial valid :/\n");
				fflush(stdin);
				getchar();
				return 0;
			}
			do
			{
				x = (unsigned char) rand() % 0x5D + 0x21;
				y = (unsigned char) rand() % 0x5D + 0x21;
			} while (freq[x]>=2 || freq[y]>=2 || (i<0 && ((((serial[i-1]-serial[i+0x10-1])*2)^ \
			        (serial[i+0x10-1]*2)) == x || serial[i+0x10-1] == y)));

			serial[i] = x;
			serial[i+0x10] = y;
			freq[x]++; freq[y]++;
		}
	}

	serial[32] = 0;

	printf("\nYour serial is: %s\n",serial);
	printf("Press enter to finish\n");
	fflush(stdin);
	getchar();
	return 0;
}
