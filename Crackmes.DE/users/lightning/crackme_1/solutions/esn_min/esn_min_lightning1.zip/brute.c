/*  HIDDEN EDIT ENCRYPTION

    magic = 0;
    Code = Edit.value; //16 digits
    for (i=0;i<8;i++)
    {
        magic = ( ((Code[i*2] + Code[i*2+1]) * ROL(magic,6) ) ^ Code[i*2] ) - Code[i*2+1];
        Code[i] = ( ( Code[i*2] ^ Code[i*2+1] ) * 2 ) % 0x5E + 0x20;
    }
    Code[i+8] = '\0';
    if (!strcmp(Code, 'xN<X.2`"') && magic == 0x125D02B2) continue;  */

//////////////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <stdlib.h>

// #define ROL(a,b) \
  ( (a<<b)|((a>>32-b)&~(-1<<b)) )


int Generate_table(int);
unsigned int Get_magic(unsigned int,unsigned char,unsigned char);
char Get_serial(unsigned int,int);

unsigned char *pair[8];
int  size_table[8];
unsigned char hidden[] = "xN<X.2`\"";
unsigned char serial[17];

int main(int argc, char *argv[])
{
    int i;

    for (i=0;i<8;i++) size_table[i] = Generate_table(i);

    memset(serial,17,0);
    Get_serial(0,0);

    printf("The serial is %s\n",serial);
    printf("Press enter to finish\n");
    getchar();

	return 0;
}

char Get_serial(unsigned int magic, int table_n)
{
    int i;
    char b; //boolean

    if (table_n == 8) return (magic == 0x125D02B2);

    for (i=0;i<size_table[table_n];i++)
    {
		_asm("roll $6, %magic");
        b = Get_serial((((pair[table_n][i*2] + pair[table_n][i*2+1]) * magic) \
                          ^pair[table_n][i*2]) - pair[table_n][i*2+1],table_n+1);
        if (b)
        {
           serial[table_n*2] = pair[table_n][i*2];
           serial[table_n*2+1] = pair[table_n][i*2+1];
           break;
        }
    }
    return b;
}

int Generate_table (int table_n)
{
    int i = 0;
    char a, b;

    pair[table_n] = (unsigned char *) malloc(250*2);

    for (a=0x20;a<0x7F;a++) // Test only printable chars
    {
        for (b=0x20;b<0x7F;b++)
        {
            if ( ((((a^b)*2)%0x5E)+0x20) == hidden[table_n] )
            {
               pair[table_n][i*2] = a;
               pair[table_n][i*2+1] = b;
               i++;
            }
        }
    }
    return i;
}
