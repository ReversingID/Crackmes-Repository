This is my first crackme. It should be interesting. I had another crackme planned but it
became more complicated than I wanted for the first crackme.

Objectives:
 - Fairly straight forward. You must produce a keygen for this crackme. The keygen can
   not be the original EXE patched to generate a valid serial (although doing such a thing
   with this app will probably be difficult).
 - No patching of the EXE is allowed.
 - Write a decent tutorial on this crackme about how it works and how you cracked it. I
   hate reading the tutorials that don't tell you how the crackme worked or how it protected
   itself. I also hated the tutorials that rushed right thru of cracking it (go here, go
   there, etc).


I debated about telling about any of the protections in the crackme but I decided that a
regular application would not tell you about it's protection. This means you will have to
work at it. I do think it will be fairly interesting to crack though.

- Lightning
