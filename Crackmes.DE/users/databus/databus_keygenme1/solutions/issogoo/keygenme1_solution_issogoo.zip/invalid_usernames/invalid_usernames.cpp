/*
 *  This Program produces usernames for 'Keygenme1', that are invalid,
 *  although a valid serial could be calculated.
 *
 *  iSSoGoo (c) 2013
 */

#include <cstdio>

int main(){

    int sum = 6+5+4+3+2+1 + 0xDDCCBBAA;

    for(int a=0x21; a<0x7F; a++){
        for(int b=0x21; b<0x7F; b++){
            for(int c=0x21; c<0x7F; c++){
                for(int d=0x21; d<0x7F; d++){
                    for(int e=0x21; e<0x7F; e++){
                        for(int f=0x21; f<0x7F; f++){
                            if( ((a+b+c+d+e+f+sum) & 0x0FF) == 0){
                                printf("%c%c%c%c%c%c\n",a,b,c,d,e,f);
                            }
                        }
                    }
                }
            }
        }
    }

    return 0;
}
