﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class FRM_Main : Form
    {
        public FRM_Main()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
        }

        private void TXT_User_TextChanged(object sender, EventArgs e)
        {
            BTN_Gen.Enabled = (TXT_User.TextLength % 2) == 0;
        }

        private void BTN_Gen_Click(object sender, EventArgs e)
        {
            Random R = new Random(DateTime.Now.Millisecond);

            string sName = TXT_User.Text;

            int i;
            int EAX = 0;
            uint iKey = 0xDDCCBBAA;

            for (i = sName.Length; i >= 1; i--)
            {
                EAX += sName[i - 1];
                EAX += i;
            }

            uint Key1 = (uint)EAX + iKey;
            uint Key2 = Key1 * 2;

            T.Text = Key1.ToString("X2") + Convert.ToChar(48 + R.Next(10)).ToString() + Key2.ToString("X2");
        }

        private void BTN_About_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Created By Jhonjhon_123\n\n    PD Team - DevSquad\n            2009 - 2013");
        }
    }
}
