﻿using System.Drawing;
namespace WindowsFormsApplication2
{
    partial class FRM_Main
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.T = new System.Windows.Forms.TextBox();
            this.TXT_User = new System.Windows.Forms.TextBox();
            this.LB_Name = new System.Windows.Forms.Label();
            this.LB_key = new System.Windows.Forms.Label();
            this.BTN_Gen = new System.Windows.Forms.Button();
            this.BTN_About = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // T
            // 
            this.T.Location = new System.Drawing.Point(59, 38);
            this.T.Name = "T";
            this.T.ReadOnly = true;
            this.T.Size = new System.Drawing.Size(167, 20);
            this.T.TabIndex = 0;
            // 
            // TXT_User
            // 
            this.TXT_User.Location = new System.Drawing.Point(59, 6);
            this.TXT_User.Name = "TXT_User";
            this.TXT_User.Size = new System.Drawing.Size(167, 20);
            this.TXT_User.TabIndex = 1;
            this.TXT_User.TextChanged += new System.EventHandler(this.TXT_User_TextChanged);
            // 
            // LB_Name
            // 
            this.LB_Name.AutoSize = true;
            this.LB_Name.Location = new System.Drawing.Point(12, 9);
            this.LB_Name.Name = "LB_Name";
            this.LB_Name.Size = new System.Drawing.Size(41, 13);
            this.LB_Name.TabIndex = 2;
            this.LB_Name.Text = "Name: ";
            // 
            // LB_key
            // 
            this.LB_key.AutoSize = true;
            this.LB_key.Location = new System.Drawing.Point(12, 41);
            this.LB_key.Name = "LB_key";
            this.LB_key.Size = new System.Drawing.Size(31, 13);
            this.LB_key.TabIndex = 3;
            this.LB_key.Text = "Key: ";
            // 
            // BTN_Gen
            // 
            this.BTN_Gen.Enabled = false;
            this.BTN_Gen.Location = new System.Drawing.Point(232, 3);
            this.BTN_Gen.Name = "BTN_Gen";
            this.BTN_Gen.Size = new System.Drawing.Size(75, 23);
            this.BTN_Gen.TabIndex = 4;
            this.BTN_Gen.Text = "Generate";
            this.BTN_Gen.UseVisualStyleBackColor = true;
            this.BTN_Gen.Click += new System.EventHandler(this.BTN_Gen_Click);
            // 
            // BTN_About
            // 
            this.BTN_About.Location = new System.Drawing.Point(232, 35);
            this.BTN_About.Name = "BTN_About";
            this.BTN_About.Size = new System.Drawing.Size(75, 23);
            this.BTN_About.TabIndex = 5;
            this.BTN_About.Text = "About";
            this.BTN_About.UseVisualStyleBackColor = true;
            this.BTN_About.Click += new System.EventHandler(this.BTN_About_Click);
            // 
            // FRM_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(309, 64);
            this.Controls.Add(this.BTN_About);
            this.Controls.Add(this.BTN_Gen);
            this.Controls.Add(this.LB_key);
            this.Controls.Add(this.LB_Name);
            this.Controls.Add(this.TXT_User);
            this.Controls.Add(this.T);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.Name = "FRM_Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DataBus\' Keygenme1 - Keygen - By Jhonjhon_123";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox T;
        private System.Windows.Forms.TextBox TXT_User;
        private System.Windows.Forms.Label LB_Name;
        private System.Windows.Forms.Label LB_key;
        private System.Windows.Forms.Button BTN_Gen;
        private System.Windows.Forms.Button BTN_About;
    }
}

