#include <iostream>
#include <windows.h>

using namespace std;

const unsigned long int MAGIC = 0xDDCCBBAA; // Magic constant

void generate(const string & name) {
     
     unsigned int len = name.length();
     unsigned int sum, part1, part2 = 0;
     
     // Calculate name sum
     for (int i = len; i >= 0; i--) 
         sum += int(name[i]) + i;
     
     // Calculate serial
     part1 = sum + MAGIC; 
     part2 = part1 * 2;
     
     printf("Serial: %X-%X", part1, part2);
     
}

int main() {
    
    string name;
    char again;
    
    // For console colors
    HANDLE hstdin  = GetStdHandle(STD_INPUT_HANDLE);
	HANDLE hstdout = GetStdHandle(STD_OUTPUT_HANDLE);
	
	// Change console color
    CONSOLE_SCREEN_BUFFER_INFO csbi;
	GetConsoleScreenBufferInfo(hstdout, &csbi);
	SetConsoleTextAttribute(hstdout, 0xA1);
    
    do {
    
       do {
           
           system("CLS"); // CLS is not portable (i.e., Windows-only command)
           
           cout << "   /------------------------------------------------------------------------\\\n" <<
                   "   |                   Keygenerator for DataBus' Keygenme1                  |\n"  << 
                   "   |                         written by Office Jesus                        |\n"  <<
                   "   |                         17 Apr 2013 Anno Domini                        |\n"  <<
                   "   |                              Rating: 1/10                              |\n"  <<
                   "   \\------------------------------------------------------------------------/\n\n";  
        
           cout << "\nEnter your name. Your name must be longer than 5 chars and " <<
                   " the length must \nbe divisible by 2.\n\n";
                
           cout << "Name: ";
           getline(cin, name);
    
       } while ((name.length() < 5) || (name.length() % 2 == 1)); 
       
       // Go generate the serial
       generate(name);
          
       cout << "\n\n";
       
       // Want to do another one?
       cout << "Again? (Y/N): ";
       cin >> again;
    
    } while ((again == 'y') || (again == 'Y'));
    
    // Reset console
    FlushConsoleInputBuffer(hstdin);
	SetConsoleTextAttribute(hstdout, csbi.wAttributes);
    
    return 0;
    
}
