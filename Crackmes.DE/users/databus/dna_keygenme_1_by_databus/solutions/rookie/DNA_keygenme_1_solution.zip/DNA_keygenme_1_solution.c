#include <stdlib.h>
#include <stdio.h>
#include <time.h>

int main(void)
{
	char username[9]; 
	// char serial_char;
	static char serial_values[] = { 0x01, 0x10, 0x11 }; 
	static char serial_char[] = { 'T', 'C', 'G' }; 
	unsigned char cnt, sum_username=0, calc_username=0;
	unsigned char sum_serial=0;
	int serial_cnt=0;

	srand(time(NULL));
	printf("Enter Username, exactly 8 characters: ");
	gets(username);
	for(cnt=0; cnt<8; cnt++)
	{
		sum_username += username[cnt];
	}

	printf("\nUsername: %s sum: %x ", username, sum_username);
  calc_username = (sum_username - sum_username % 0x11);
	printf("calculated: %x\n", calc_username);
	printf("Serial: TAC");
	while( sum_serial < (calc_username - 0x10) )	
	{
		char mod_rand = rand() % 3;
		//printf("%c", serial_char[mod_rand]);
		//sum_serial += serial_values[mod_rand];
		printf("G");
		sum_serial += 0x11;
		serial_cnt++;
	}
	if((calc_username - sum_serial) == 0x10)
	{
		sum_serial += 0x10;
		printf("C");
		serial_cnt++;
	}
	else if((calc_username - sum_serial) > 0)
	{
		while(calc_username != sum_serial)
		{
			sum_serial++;
			printf("T");
			serial_cnt++;
		}
	}
	while((serial_cnt % 3) !=0)
	{
		printf("A");
		serial_cnt++;
	}
	printf("ATTAAAAAA\n");

	return 0;
}
