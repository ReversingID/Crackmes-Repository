Write a keygen for the program.  No cracking or brute forcing allowed.  There are multiple serial solutions per username.

Your keygen should output the most elegant solution.