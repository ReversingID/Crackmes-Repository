/* Keygen for Crackme#1byRamirez By -HeX- */
#include <stdio.h>

//The algorithm works for a name longer then 20, just did this to save memory.
#define MAX_NAME 20
#define MAX_LOOPCOUNT 6

int main(int argc, char **argv)
{
char inputName[MAX_NAME];
char serialKey[MAX_NAME];
int charCount=0;
char c;

memset(inputName,0,sizeof(inputName));
memset(serialKey,0,sizeof(serialKey));

printf("Input Name: ");
while(charCount<MAX_NAME-1)
{
	c=getchar();
	if(c=='\n' || c=='\r')
		break;
	inputName[charCount]=c;
	charCount++;
}
keygenItchar(inputName,serialKey);
printf("Key: %s",serialKey);
}
int keygenItchar(char *aNamePtr,char *aNewSerial)
{
	
	int calculatedValue2=0;
	int calculatedValue1=0;
	int nameIndexCounter=0;
	unsigned int nameLength;
	int SerialIndex=0;
	int loopCount=0;
	nameLength=strlen(aNamePtr);
	
	for(nameIndexCounter=0;nameIndexCounter<nameLength;nameIndexCounter++)
	{
		if(loopCount<=MAX_LOOPCOUNT)
		{
			calculatedValue1=calculatedValue2=aNamePtr[nameIndexCounter]>>loopCount;		
			calculatedValue1+= (aNamePtr[nameIndexCounter+1]<<(7-loopCount));
			calculatedValue1 = (calculatedValue1&0xF0) >>4;
			
			calculatedValue2=(calculatedValue2 + (aNamePtr[nameIndexCounter+1]<<(7-loopCount))) & 0x0f;
			
			calculatedValue1 += (calculatedValue1<=9) ? 0x30 : 0x37;
			calculatedValue2 += (calculatedValue2<=9) ? 0x30 : 0x37;
			
			aNewSerial[SerialIndex]= calculatedValue1; 
			aNewSerial[SerialIndex+1]=  calculatedValue2;
			loopCount++;
			SerialIndex+=2;
		}
		else
		{
			loopCount=0;
		}
			
		
	}
	aNewSerial[SerialIndex]=0;
}