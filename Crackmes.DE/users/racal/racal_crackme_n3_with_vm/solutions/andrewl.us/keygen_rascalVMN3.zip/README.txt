solution.txt    MAIN SOLUTION FILE

disasm.cpp      VM DISASSEMBLER
disasm.txt	VM DISASSEMBLER EXAMPLE OUTPUT

fulltrace.cpp   VM EXECUTION DRAWING PROGRAM
fulltrace.txt   VM EXECUTION DRAWING EXAMPLE OUTPUT

keygen.cpp      keygen source
keygen.exe      keygen executable

analysis0.txt   commented disassembly phase 0
analysis1.txt   commented disassembly phase 1

rascal.map      IDA file with my names for addresses within crackme

VM_Code.h       header file with VM code byte array used by disassembler, fulltrace

README.txt      this file

