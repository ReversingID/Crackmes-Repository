					-=English=-

This is my first keygenme (and my first one with crypto), your task is to make a valid keygen 

for, to write a tutorial about, no need to patch this 'lil shit, it's For those who need to 

learn crypto-keygening (newbies)....so good luck.


                                        -=Fran�ais=-

C'est mon premier keygenme et le premier dans le domaine de la cryptographie, le but est de faire

un G�n�rateur de cl�s valides et d'�crire un petit tutorial, pas la peine de patcher ce p'tit

program, il est d�stin� a ceux qui veulent apprendre la crypto-keygening (newbies)..bonne chance.
					
                                          -=GreetZ=-

1. RaX, PainKiller, CheeseX, CoaXcable, nAbOo and all the others......
2. Roy/fleur For his good website and good tuts.
3. La charmente Lise_Grim pour son superbe site .... Rien � dire ;)
4. All those who Keep the scene alive.....BiG thx ppl
5. To you ;)

If you have any suggestion....you can contact me at #eminence channel on eFnet.

                                                                           
                                                                          BytePtr   27-o8-2oo3


                
                         eMiNENCE  e!2003 http://www.the-eminence.com
                            We WiLL NeVeR SToP LiViNG THiS WaY!!!!