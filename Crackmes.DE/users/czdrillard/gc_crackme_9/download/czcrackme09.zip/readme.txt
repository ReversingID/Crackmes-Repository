Welcome to czCrackMe 09 from Genocide Crew

Greetz to Gandalf, Falcon and all the rest of the Crew :)
and Greetz to all you crackers readin this...May the crack be with you.

There's no sneaky apis no random numbers here just strait simple assembler.  Use softice and print out the code with W32DASM and you'll have no troubles.  Patchin or brute force not required.  just name, serial and a keygen.



czdrillard@hushmail.com 