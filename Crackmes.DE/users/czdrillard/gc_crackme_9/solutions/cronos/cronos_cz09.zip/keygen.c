//thought it was packed with upx, but not.........

#include <string.h>
#include <windows.h>
#include <stdio.h>

// slightly different atol, to take into account the
// program version which allows non-digit characters
long atolnew(unsigned char *str1)
{	long t;
	int i;
	unsigned char e;
	t=0;
	i=0;
	while(str1[i])
	{	e=str1[i]-48;
		t=t*10+e;
		i++;
	}
	return t;
}

// returns 0 for fail, 1 for success
int checkit(char *string1,char *string2)
{	int string2_length,i,count,l;
	char temp_string[10],enc_string[10];
	long r;
	i=0;
	// added zeroing of string for keygen - Cronos
	while(i<10)
	{	temp_string[i]=0;
		enc_string[i]=0;
		i++;
	}
	// simple length checks
	if(strlen(string1)<=4)
	{	return 0;
	}
	if(strlen(string2)<=4)
	{	return 0;
	}
	string2_length=strlen(string2);
	i=0;
	// convert string1 to lowercase
	while(string1[i])
	{	string1[i]|=0x20;
		i++;
	}
	i=0;
	// compute differences
	while(string2[i])
	{	string2[i]=string1[i]-string2[i];
		i++;
	}
	count=string2_length;
	// main crypt routine
	while(count)
	{	r=atolnew(string2)*count;
		wsprintf(temp_string,"%lu",r);
		i=0;
		while(temp_string[i])
		{	temp_string[i]&=0x0f;
			i++;
		}
		r=string2_length/2;
		i=r;
		l=0;
		while(r)
		{	enc_string[l]+=(temp_string[l]+temp_string[i]);
			enc_string[l]&=0x0f;
			l++;
			i++;
			r--;
		}
		count--;
	}
	i=0;
	r=string2_length/2;
	// finally check the answer
	while(r)
	{	if(enc_string[i]!=string2_length) return 0;
		i++;
		r--;
	}
	return 1;
}

void main(int argc, char *argv[])
{	char str1[10],str2[10];
	int i,j;
	j=99999;
	printf("Keygen for czcrackme09 by Cronos\n");
	printf("Usage: keygen name (name>4 chars)\n");
	if(argc<2) return;
	do
	{	j++;
		strcpy(str1,argv[1]);
		i=0;
		while(i<10) str2[i++]=0;
		wsprintf(str2,"%lu",j);
		if(!(j&0xffff)) printf("progress: %lu\r",j);
	} while(!checkit(str1,str2));
	printf("\n%lu\n",j);
}