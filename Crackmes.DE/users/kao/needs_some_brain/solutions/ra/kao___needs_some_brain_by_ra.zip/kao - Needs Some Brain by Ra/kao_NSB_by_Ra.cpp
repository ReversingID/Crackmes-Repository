/*///////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
//                                                                                 \\
//              Base for KeyGen for kao's Needs Some Brains CrackMe                \\
//                                                                                 \\
//                                     By Ra                                       \\
//                                                                                 \\
//                                                                                 \\
\\                                                                                 //
\\                                                                                 //
\\                                                                                 //
\\                                                                                 //
\\																				   //
\\                                                                                 //
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\///////////////////////////////////////////*/

#ifndef _KAO_NSB_KG_
#define _KAO_NSB_KG_

#include <string.h>
#include <math.h>

typedef unsigned int uint;

uint eval_name( char* name)
{
	uint e;
	char *p = (char *)&e;

	e = ( name[0]<<24) + ( name[1]<<16) + ( name[2]<<8) + name[3] +
		name[4] + ( name[5]<<8) + ( name[6]<<16) + ( name[7]<<24);

	e = ( e % 0x01F31D) * 0x41A7 - ( e / 0x01F31D) * 0x0B14;
	
	for(int i=0; i<3; i++)
		if( p[i] < 0)
			p[i] |= 0xF8;
		else
		{
			p[i] &= 0x07;
			if(!p[i])
				p[i]++;
		}

	if( !( ( p[2] ^ p[0]) & 0x80))
		p[0] = -p[0];

	return e;
}

uint* keygen( char* name, uint *key) //key - buffer to store result, 8 bytes at least
{
	if( strlen(name)<3 && strlen(name)>0x16 )
		return 0L;

	uint name_val = eval_name( name);
	char *p = (char*) &name_val;

	float a = (double)p[1]/(double)p[0]; 
	float b = (double)p[2]/(double)p[0];	//always < 0

	float x[2];

	if( b*b >= 4.0*a)
	{
		x[0] = (-a + sqrt(a*a - 4.0*b))/2.0;
		x[1] = (-a - sqrt(a*a - 4.0*b))/2.0;
		memcpy( key, x, 8);
		//printf("Key: %X%X\n     %X%X\n",key[0],key[1],key[1],key[0]);
	}
	//else
		//printf("No solution?!\n");

	return key;
}

#endif