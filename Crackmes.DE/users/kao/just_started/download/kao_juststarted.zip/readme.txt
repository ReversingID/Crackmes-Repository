Hi everybody!


This  is the first crackme I have created. So please be kind
and don't bitch too much about it. ;)


You must write a keygen, that generates valid serial for any
name  entered.   Patches  and  serials  do  not  count  as a
solution. 


It  is  quite  easy if you get the idea. If you don't, it'll
take   a   while...  Every name has a valid serial - you can
trust me on that!


Fan  mail,  hate  mail, ideas, solutions and bug reports are
welcome! Spam is not.



kao,

Riga, Latvia, 2003
kaspars@hotbox.ru


Greets to oorjaHalt and elfZ.