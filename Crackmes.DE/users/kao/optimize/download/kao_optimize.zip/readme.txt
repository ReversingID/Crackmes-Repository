Optimize! by kao (15-Jul-2004)


Level:			3/10
Type:			Keygenme (serial/keyfile)
Newbie friendly:	So-so.. 
Programming language:	MASM
Encryption:		None
Packer:			None
Anti-debugger:		No
Tested:			Win98SE, Win2K, WinXP English.


Hi,

I hope you've got some time to waste. ;) This crackme is not
hard, but you will still have to think. 


Don't be surprised about  code - it's more or less optimized
for  size  not  readability.  You will need to optimize your
code too.. ;)


Bruteforcing  is  possible  (as  always...)  but  not really
necessary. And you will not learn much that way. :P



RULES: 
   1)  You  have  solved it  ONLY if you get MessageBox with
   caption "Congratulations!" and text "You have solved this
   crackme!".  If  crackme closes or shows no messagebox  or
   shows different messagebox, you have failed. 

   2) No patching. It means-no EXE file patching, no process
   loaders, no API hooks. Nothing.

   3)  Please   make   sure  that your solution works on all
   systems, not just yours. :)

   4) Please submit keygen source too. :))

   5) Enjoy!


Greets,
	kao.

Riga, Latvia, 2004
kaspars@hotbox.ru

P.S.  For  those who solved this one. Could you solve it, if
you had 0Eh bytes only? ;) How?