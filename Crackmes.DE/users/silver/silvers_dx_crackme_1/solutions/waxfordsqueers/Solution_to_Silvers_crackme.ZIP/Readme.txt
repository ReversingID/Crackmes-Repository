For whatever reason, the Word file (.doc) did not save as created. It lost 
it's formatting after being saved by Word, and left a couple of pages almost 
blank. Go figure. I'm leaving it as is. The PDF file seems to be better. I 
included three types of files just in case.

The Adobe file is rendered in high quality print, so it will only work on 
Adobe Reader 5.0 and higher.

The text file is formatted for 76 colums and should wrap in a normal text 
editor. I chose 76 because I find that with 80 columns, text files often 
push characters to the next line.