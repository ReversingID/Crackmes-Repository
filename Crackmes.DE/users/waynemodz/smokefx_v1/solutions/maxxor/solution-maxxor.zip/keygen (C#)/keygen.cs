using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Enter username: ");
        string username = Console.ReadLine();
        Console.WriteLine(String.Format("{0}{1}{2}{3}", username.Length, username.Length * 666, username.Length * 250, username.Length * 10000));
        Console.ReadLine();
    }
}