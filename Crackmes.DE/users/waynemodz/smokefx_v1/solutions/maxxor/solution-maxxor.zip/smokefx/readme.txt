Hello and Welcome!
to SmokeFX v1.0

This is my first attempt of creating a crackme/keygenme
so if it is easy, then expect a version 2!

Rules are simple!
Youve got to enter a username and serial key...
Crack the serial and click Unlock...
Your success or failure shall be displayed to you.

Once youre done with that...
or if you failed with that...
You can Crack it...
Get my messagebox to display the serial key.

Created with Delphi 7.0.

Good Luck People.

Wayne Modz
waynemodz@gmail.com