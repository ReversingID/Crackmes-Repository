Hi all,
My name is GIV
Today i will show you a solution for Smoke Keygenme V2
I will look for the VA of the check button of the serial.
Is a good advice to bp MessageBoxA in all Delphi apps to see where the info of the bad/good info messagebox is created.
We will find-it after a litle trace at: 
CPU Disasm
Address   Hex dump          Command                                  Comments
0045AFA8  /.  55            PUSH EBP
Below the username lenght is compared to 4.
CPU Disasm
Address   Hex dump          Command                                  Comments
0045AFF7  |.  E8 9CD5FAFF   CALL smokefx2.SysUtils.StrLen            ; [smokefx2.SysUtils.StrLen
0045AFFC  |.  83F8 04       CMP EAX,4
And at:
CPU Disasm
Address   Hex dump          Command                                  Comments
0045AB78  /$  55            PUSH EBP                                 ; smokefx2.Unit1.sub_0045AB78(guessed void)
Is the serial check.
At:
CPU Disasm
Address   Hex dump          Command                                  Comments
0045ABC8  |.  E8 53CFFAFF   CALL smokefx2.SysUtils.LowerCase         ; [smokefx2.SysUtils.LowerCase
the name is converted to lowercase.
The " " and "." are stripped from the name. These characters are not allowed.
Here is the serial check loop:
CPU Disasm
Address   Hex dump          Command                                  Comments
0045ABD1  |. /7E 77         JLE SHORT smokefx2.0045AC4A
0045ABD3  |. |BF 01000000   MOV EDI,1
0045ABD8  |> |8B45 F4       /MOV EAX,DWORD PTR SS:[EBP-0C]
0045ABDB  |. |8A5C38 FF     |MOV BL,BYTE PTR DS:[EDI+EAX-1]
0045ABDF  |. |8BC3          |MOV EAX,EBX
0045ABE1  |. |04 D0         |ADD AL,0D0                              ; Switch (cases FFFFFF30..FFFFFF39, 2 exits)
0045ABE3  |. |2C 0A         |SUB AL,0A
0045ABE5  |. |73 3A         |JAE SHORT smokefx2.0045AC21
0045ABE7  |. |8D45 EC       |LEA EAX,[EBP-14]                        ; Cases FFFFFF30, FFFFFF31, FFFFFF32, FFFFFF33, FFFFFF34, FFFFFF35, FFFFFF36, FFFFFF37, FFFFFF38, FFFFFF39 of switch smokefx2.45ABE1
0045ABEA  |. |8BD3          |MOV EDX,EBX
0045ABEC  |. |E8 CB95FAFF   |CALL smokefx2.System.@LStrFromChar
0045ABF1  |. |8B45 EC       |MOV EAX,DWORD PTR SS:[EBP-14]
0045ABF4  |. |E8 ABD4FAFF   |CALL smokefx2.SysUtils.StrToInt         ; [smokefx2.SysUtils.StrToInt
0045ABF9  |. |E8 62FEFFFF   |CALL smokefx2.Unit1.sub_0045AA60        ; [smokefx2.Unit1.sub_0045AA60
0045ABFE  |. |8D55 F0       |LEA EDX,[EBP-10]
0045AC01  |. |E8 62D3FAFF   |CALL smokefx2.SysUtils.IntToStr         ; [smokefx2.SysUtils.IntToStr
0045AC06  |. |8B55 F0       |MOV EDX,DWORD PTR SS:[EBP-10]
0045AC09  |. |A1 F8D14500   |MOV EAX,DWORD PTR DS:[smokefx2.45D1F8]
0045AC0E  |. |8B00          |MOV EAX,DWORD PTR DS:[EAX]
0045AC10  |. |05 04030000   |ADD EAX,304
0045AC15  |. |E8 8296FAFF   |CALL smokefx2.System.@LStrCat           ; [smokefx2.System.@LStrCat
0045AC1A  |. |A1 F8D14500   |MOV EAX,DWORD PTR DS:[smokefx2.45D1F8]
0045AC1F  |. |EB 25         |JMP SHORT smokefx2.0045AC46
0045AC21  |> |8D4D E8       |LEA ECX,[EBP-18]                        ; Default case of switch smokefx2.45ABE1
0045AC24  |. |8BC3          |MOV EAX,EBX
0045AC26  |. |8BD7          |MOV EDX,EDI
0045AC28  |. |E8 5BFEFFFF   |CALL smokefx2.Unit1.sub_0045AA88
0045AC2D  |. |8B55 E8       |MOV EDX,DWORD PTR SS:[EBP-18]
0045AC30  |. |A1 F8D14500   |MOV EAX,DWORD PTR DS:[smokefx2.45D1F8]
0045AC35  |. |8B00          |MOV EAX,DWORD PTR DS:[EAX]
0045AC37  |. |05 04030000   |ADD EAX,304
0045AC3C  |. |E8 5B96FAFF   |CALL smokefx2.System.@LStrCat           ; [smokefx2.System.@LStrCat
0045AC41  |. |A1 F8D14500   |MOV EAX,DWORD PTR DS:[smokefx2.45D1F8]
0045AC46  |> |47            |INC EDI
0045AC47  |. |4E            |DEC ESI
0045AC48  |.^|75 8E         \JNZ SHORT smokefx2.0045ABD8
The things go on this way:
I use ASCII corespondent in this description.
Part one:
If the ASCII of the char of the name is from 57 to 109 (m) the calculus is:
If we have this string aaaa the serial will be b4c5d6e7.
a+his position in the string (1) = a plus one position in alphabet = b
second a + his position in the string (2) = a plus two positions in alphabet = c
etc
The second character after the resulted letter is his position in the string plus 3
First a = 1 +3 = 4
Last a = 4 + 3 = 7
etc.
Part two:
If the ASCII of the char of the name is from above 109 (n) the calculus is:
If we have this string nnnn the serial will be m2l3k4j5.
n - his position in the string (1) = a minus one position in alphabet = m
second n minus his position in the string (2) = n minus two positions in alphabet = l
etc
The second character after the resulted letter is his position in the string plus 1
First n = 1 + 1 = 2
Last n = 4 + 1 = 5
etc.

Here is the letters routine:
CPU Disasm
Address   Hex dump          Command                                  Comments
0045AA88  /$  55            PUSH EBP
0045AA89  |.  8BEC          MOV EBP,ESP
0045AA8B  |.  6A 00         PUSH 0
0045AA8D  |.  6A 00         PUSH 0
0045AA8F  |.  6A 00         PUSH 0
0045AA91  |.  6A 00         PUSH 0
0045AA93  |.  53            PUSH EBX
0045AA94  |.  56            PUSH ESI
0045AA95  |.  57            PUSH EDI
0045AA96  |.  8BF9          MOV EDI,ECX
0045AA98  |.  8BD8          MOV EBX,EAX
0045AA9A  |.  33C0          XOR EAX,EAX
0045AA9C  |.  55            PUSH EBP
0045AA9D  |.  68 51AB4500   PUSH smokefx2.0045AB51
0045AAA2  |.  64:FF30       PUSH DWORD PTR FS:[EAX]
0045AAA5  |.  64:8920       MOV DWORD PTR FS:[EAX],ESP               ; Installs SE handler 45AB51
0045AAA8  |.  83FA 0C       CMP EDX,0C
0045AAAB  |.  7E 07         JLE SHORT smokefx2.0045AAB4
0045AAAD  |.  BE 0C000000   MOV ESI,0C
0045AAB2  |.  EB 02         JMP SHORT smokefx2.0045AAB6
0045AAB4  |>  8BF2          MOV ESI,EDX
0045AAB6  |>  80FB 2E       CMP BL,2E                                ; Compara cu .
0045AAB9  |.  75 0E         JNE SHORT smokefx2.0045AAC9
0045AABB  |.  8BC7          MOV EAX,EDI
0045AABD  |.  BA 68AB4500   MOV EDX,smokefx2.0045AB68
0045AAC2  |.  E8 6195FAFF   CALL smokefx2.System.@LStrAsg            ; [smokefx2.System.@LStrAsg
0045AAC7  |.  EB 6D         JMP SHORT smokefx2.0045AB36
0045AAC9  |>  80FB 20       CMP BL,20                                ; Compara cu spatiu
0045AACC  |.  75 0E         JNE SHORT smokefx2.0045AADC
0045AACE  |.  8BC7          MOV EAX,EDI
0045AAD0  |.  BA 74AB4500   MOV EDX,smokefx2.0045AB74
0045AAD5  |.  E8 4E95FAFF   CALL smokefx2.System.@LStrAsg            ; [smokefx2.System.@LStrAsg
0045AADA  |.  EB 5A         JMP SHORT smokefx2.0045AB36
0045AADC  |>  8BC3          MOV EAX,EBX                              ; Muta hex(litera) in EAX
0045AADE  |.  04 9F         ADD AL,9F                                ; Switch (cases FFFFFF61..FFFFFF6D, 2 exits)
0045AAE0  |.  2C 0D         SUB AL,0D
0045AAE2  |.  73 28         JAE SHORT smokefx2.0045AB0C
0045AAE4  |.  8D55 FC       LEA EDX,[EBP-4]                          ; Cases FFFFFF61, FFFFFF62, FFFFFF63, FFFFFF64, FFFFFF65, FFFFFF66, FFFFFF67, FFFFFF68, FFFFFF69, FFFFFF6A, FFFFFF6B, FFFFFF6C, FFFFFF6D of switch smokefx2.45AADE
0045AAE7  |.  8D46 03       LEA EAX,[ESI+3]
0045AAEA  |.  E8 79D4FAFF   CALL smokefx2.SysUtils.IntToStr          ; [smokefx2.SysUtils.IntToStr, Atentie aici
0045AAEF  |.  8B45 FC       MOV EAX,DWORD PTR SS:[EBP-4]
0045AAF2  |.  50            PUSH EAX
0045AAF3  |.  8D45 F8       LEA EAX,[EBP-8]
0045AAF6  |.  8BD6          MOV EDX,ESI
0045AAF8  |.  02D3          ADD DL,BL
0045AAFA  |.  E8 BD96FAFF   CALL smokefx2.System.@LStrFromChar
0045AAFF  |.  8B55 F8       MOV EDX,DWORD PTR SS:[EBP-8]
0045AB02  |.  8BC7          MOV EAX,EDI
0045AB04  |.  59            POP ECX
0045AB05  |.  E8 D697FAFF   CALL smokefx2.System.@LStrCat3           ; [smokefx2.System.@LStrCat3
0045AB0A  |.  EB 2A         JMP SHORT smokefx2.0045AB36
0045AB0C  |>  8D45 F4       LEA EAX,[EBP-0C]                         ; Default case of switch smokefx2.45AADE
0045AB0F  |.  8BD6          MOV EDX,ESI
0045AB11  |.  52            PUSH EDX
0045AB12  |.  8BD3          MOV EDX,EBX
0045AB14  |.  59            POP ECX
0045AB15  |.  2AD1          SUB DL,CL
0045AB17  |.  E8 A096FAFF   CALL smokefx2.System.@LStrFromChar
0045AB1C  |.  8B45 F4       MOV EAX,DWORD PTR SS:[EBP-0C]
0045AB1F  |.  50            PUSH EAX
0045AB20  |.  8D55 F0       LEA EDX,[EBP-10]
0045AB23  |.  8D46 01       LEA EAX,[ESI+1]
0045AB26  |.  E8 3DD4FAFF   CALL smokefx2.SysUtils.IntToStr          ; [smokefx2.SysUtils.IntToStr
0045AB2B  |.  8B4D F0       MOV ECX,DWORD PTR SS:[EBP-10]
0045AB2E  |.  8BC7          MOV EAX,EDI
0045AB30  |.  5A            POP EDX
0045AB31  |.  E8 AA97FAFF   CALL smokefx2.System.@LStrCat3           ; [smokefx2.System.@LStrCat3
0045AB36  |>  33C0          XOR EAX,EAX
0045AB38  |.  5A            POP EDX
0045AB39  |.  59            POP ECX
0045AB3A  |.  59            POP ECX
0045AB3B  |.  64:8910       MOV DWORD PTR FS:[EAX],EDX
0045AB3E  |.  68 58AB4500   PUSH smokefx2.0045AB58                   ; Entry point
0045AB43  |>  8D45 F0       LEA EAX,[EBP-10]
0045AB46  |.  BA 04000000   MOV EDX,4
0045AB4B  |.  E8 A894FAFF   CALL smokefx2.System.@LStrArrayClr       ; [smokefx2.System.@LStrArrayClr
0045AB50  \.  C3            RETN                                     ; Jump to 45AB58

Part three:
If the name contains numbers the calc is this:
If car = "0" Then
                corespondent = "10"
            End If
            If car = "1" Then
                corespondent = "7"
            End If
            If car = "2" Then
                corespondent = "3"
            End If
            If car = "3" Then
                corespondent = "9"
            End If
            If car = "4" Then
                corespondent = "5"
            End If
            If car = "5" Then
                corespondent = "11"
            End If
            If car = "6" Then
                corespondent = "8"
            End If
            If car = "7" Then
                corespondent = "9"
            End If
            If car = "8" Then
                corespondent = "10"
            End If
            If car = "9" Then
                corespondent = "11"
            End If
Endif

Here is the routine for numbers:
CPU Disasm
Address   Hex dump          Command                                  Comments
0045AA60  /$  85C0          TEST EAX,EAX                             ; smokefx2.Unit1.sub_0045AA60(guessed void)
0045AA62  |.  75 06         JNZ SHORT smokefx2.0045AA6A
0045AA64  |.  B8 0A000000   MOV EAX,0A
0045AA69  |.  C3            RETN
0045AA6A  |>  83F8 05       CMP EAX,5
0045AA6D  |.  7E 0E         JLE SHORT smokefx2.0045AA7D
0045AA6F  |.  A8 01         TEST AL,01
0045AA71  |.  74 05         JZ SHORT smokefx2.0045AA78
0045AA73  |.  83C0 02       ADD EAX,2
0045AA76  |.  EB 0F         JMP SHORT smokefx2.0045AA87
0045AA78  |>  83C0 02       ADD EAX,2
0045AA7B  |.  EB 0A         JMP SHORT smokefx2.0045AA87
0045AA7D  |>  A8 01         TEST AL,01
0045AA7F  |.  74 05         JZ SHORT smokefx2.0045AA86
0045AA81  |.  83C0 06       ADD EAX,6
0045AA84  |.  EB 01         JMP SHORT smokefx2.0045AA87
0045AA86  |>  40            INC EAX
0045AA87  \>  C3            RETN


So the calculus is something like Part one plus part two plus part three.

This will be the serial.


For cracking:
CPU Disasm
Address   Hex dump          Command                                  Comments
0045AF52  |.  8B45 F8       MOV EAX,DWORD PTR SS:[EBP-8]             ; |ASCII "Not Cracked :P"

replace with MOV EAX, EDX

here is the source of the attached keygen in VB 2010:

Option Explicit On
Option Strict On

Public Class Form1

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        If TextBox1.Text.Length < 4 Then
            TextBox2.Text = "Minimum 4 characters"
            Return
        End If
        Dim intrare As String
        intrare = TextBox1.Text.ToLower
        intrare = intrare.Replace(".", "")
        intrare = intrare.Replace(" ", "")
        Dim ESI As Integer = intrare.Length
        Dim bl As Integer
        Dim stringfinal1 As String = ""
        Dim stringfinal2 As String = ""
        Dim cts As String = ""
        Dim cfr As Integer = 0
        Dim caracterdincoada As String = ""
        Dim numar As String
        For i = 0 To TextBox1.Text.Length - 1
            Dim car As String = intrare.Substring(i, 1)
            If car = "0" Then
                caracterdincoada = "10"
            End If
            If car = "1" Then
                caracterdincoada = "7"
            End If
            If car = "2" Then
                caracterdincoada = "3"
            End If
            If car = "3" Then
                caracterdincoada = "9"
            End If
            If car = "4" Then
                caracterdincoada = "5"
            End If
            If car = "5" Then
                caracterdincoada = "11"
            End If
            If car = "6" Then
                caracterdincoada = "8"
            End If
            If car = "7" Then
                caracterdincoada = "9"
            End If
            If car = "8" Then
                caracterdincoada = "10"
            End If
            If car = "9" Then
                caracterdincoada = "11"
            End If
            bl = Asc(intrare.Substring(i, 1))
            stringfinal1 = ""
            stringfinal2 = ""
            numar = intrare.Substring(i, 1)
            If bl > 57 And bl <= 109 Then
                Dim h As Integer = i + 1
                Dim rez As Integer = bl + h
                Dim rezhex As String = Conversion.Hex(rez)
                Dim second As Integer = h + 3
                Dim caracter As String = ChrW(CInt("&H" & rezhex))
                stringfinal1 = caracter & second.ToString
            End If
            If bl > 109 Then
                Dim h1 As Integer = i + 1
                Dim rez1 As Integer = bl - h1
                Dim rezhex1 As String = Conversion.Hex(rez1)
                Dim second1 As Integer = h1 + 1
                Dim caracter1 As String = ChrW(CInt("&H" & rezhex1))
                caracter1 = caracter1 & second1.ToString
                stringfinal2 = stringfinal2 & (caracter1)
            End If
            cts = cts + stringfinal2 + stringfinal1 + caracterdincoada
            TextBox2.Text = cts
        Next

    End Sub
End Class

See ya!
Written at Christmas Day of the year 2013