Keygenme #3 -- coded by LibX
------------------------------

About:

Coded in Visual Basic 6
Anti-Smartcheck
Anti-Softice
Anti-Ollydbg


Rules:

No patching
Code a keyfile generator
