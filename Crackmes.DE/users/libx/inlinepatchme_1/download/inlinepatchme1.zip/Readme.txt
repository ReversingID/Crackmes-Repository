InLinePatchMe #1 --- coded by LibX
---------------------------------------------

About:

Coded in Visual Basic 6
Anti-Softice
CRC-32


Rules:

Create an inline patch to kill the CRC32
and show "Registered to: <your name> in the textbox