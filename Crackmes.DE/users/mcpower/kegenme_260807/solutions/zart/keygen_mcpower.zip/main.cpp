#include <iostream>
#include <string.h>

using namespace std;

int main(int argc, char* argv[])
{
	int license;

	cout << "KeyGen Solution for 'mcpower's Kegenme 260807'" << endl << "cracked/coded by zart" << endl;
	cout << "Enter a license number: ";

	cin >> license;

	cout << "Serial number: " << ((((license*2) + 753) * 333) - 13) - 15 << endl;

   return 0;
}