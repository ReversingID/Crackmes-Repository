using System.Security.Cryptography;
using System;
using System.Text;

public class Cryptography
{  
    public static string EncryptData(string data2Encrypt)
    {
        byte[] buffer = Encoding.UTF8.GetBytes(data2Encrypt);
        RSACryptoServiceProvider rsa2 = new RSACryptoServiceProvider();
        string str = "<RSAKeyValue><Modulus>wc1JR2kicSZc04bRZq4Gs7OLyhwYWNKvzBsMxwLmzazVrU40o6U3QixsOj31FWksLuJPqFOxNWgNDTQN5n9B/pRzlP7e5mZ0SoOB6I2JFix+SKFIyrzEtegVwuJHr7CJO2jpt17Tn2+c6SOlPd3OvTKqUYKqupLhLQVDq6o6CwU=</Modulus><Exponent>AQAB</Exponent><P>8qVWaD/K0rEZDB6oDSh0THrr1TrL7+Q5VvXWqIDDk6trAUSTs60pXBcyQt3SW/x80hXjiJ09Q1+oknbycjT4KQ==</P><Q>zHfIAABab9gL8dgs8clJUxL+xRb5r3uDjDhrjVkr9yzYLBa29CwsBdSmDAUtBZqEpX1AwkO/kgd8yq0ukG3HfQ==</Q><DP>2Uubn+xQ9HHInoPttyrdS4hhHilzbLeTaf7qZyg4/Utrnk0NgMC341KanisMMXhhR7p2c2ds76MA0XlYEVLCUQ==</DP><DQ>Dhh72zQrB+bW+/cxMgH0Yhu/IIsy71wOd440K+xn0YRv6qouNqsM5eIBCHca4XYDiv0Vh87v1/tYKQjDWwWWaQ==</DQ><InverseQ>j29xRp2GatsEemQ9tzVm5NhnBiEdV4a2VZSjoCZKfq6vw9934+eeGMjMk5y0c8oNZksudz5VG4CC8RzCoMUm9w==</InverseQ><D>A8qCPnVeCRyZAEJI4ltRIj7G40M9bq9gZPu6ekIiRa+11lgLS5A1zoOT8me33Z1bEee3azGH6+WHK9Ty2KlwnwOFV3iGznxnYyqDl/RYHZFUOmKkfmMe0Ig6BxhYZUPXfGOd256QstYlupCO5C4F4RQ91dKbjayhMHkndMzmdsE=</D></RSAKeyValue>";
        rsa2.FromXmlString(str);
        byte[] buffer2 = rsa2.Encrypt(buffer, false);
        return Convert.ToBase64String(buffer2);
    }
}

