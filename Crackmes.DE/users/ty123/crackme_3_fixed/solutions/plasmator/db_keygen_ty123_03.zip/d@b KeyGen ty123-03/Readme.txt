Update
------

May 1st, 2004
-- Fixed a bug (Crackme3 is not working when a long volume name is set).

-- Fixed a bug (Crackme3 is not working under Win9X).


Hello all,

I am pleased to see you again!

Well, this is my third crackme, Crackme #3, coded in win32asm as before.

You have to make:

1. A valid Reg-file for Registry
2. A valid keyfile

This crackme is not for newbie, but for the beginner. Besides great OllyDbg
or similar debugger you prefer, a pencil and a piece of paper would be useful.

TIPS: It is a straightforward protection, no anti-debugger code, non packer, 
no anti-disassembling code, no blabla... Your name will be shown somewhere
when you finish the last check routine. Good luck!

Rules: All tools allowed but no patching.

Questions, bug reports, comments, especially the keygen and tutorial are 
welcomed!

Feel free to contact me via the following email.

--
ty123

ty123@18en.com