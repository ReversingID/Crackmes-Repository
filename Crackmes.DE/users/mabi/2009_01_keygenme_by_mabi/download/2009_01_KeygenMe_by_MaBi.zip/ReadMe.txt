
Try to solve this KeygenMe and make a tutorial:

- No patching
- No bruteforcing

Have fun!
MaBi