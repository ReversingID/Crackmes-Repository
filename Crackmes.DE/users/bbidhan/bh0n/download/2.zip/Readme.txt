Autor: bbidhan
Date: 09 December 2005

Platform: Windows
Compiler: Flash 5
Packer: No
Level: 2 (No so hard)

Patching: Not allowed

                     Hope you'l enjoy!