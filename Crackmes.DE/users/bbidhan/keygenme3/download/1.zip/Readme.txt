Autor: bbidhan

Platform: Windows
Compiler: VB 6.0
Packer: No
Level: 1 (No so hard)

Patching: Not allowed
KeyGenerator: This is the target.

Rulz: Open me. Type a name. Write your keygen in the enabled text. See if your password 
      is correct or incorrect in app.path\feedback.txt! . After finding password. Write 
      a keygenerator for this KeyGenMe & please send it to my email address bbidhan50@gmail.com!
      	

                                    Hope you'l enjoy a lot!