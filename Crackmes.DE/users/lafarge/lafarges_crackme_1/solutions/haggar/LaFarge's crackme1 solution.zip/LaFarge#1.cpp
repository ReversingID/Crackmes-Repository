#include<iostream>
#include<stdlib.h>
#include<string.h>
using namespace std;
void graf();
void graf()
{
cout<<" -------------------------------------------------------------------------\n";
cout<<"  LaFarge's keygenme#1\n\n";
cout<<"  User name can have min 4 characters and max 25. Don't use non-english\n";
cout<<"  alphabet letters. For more infomation read tutorial. Haggar 12.01.2005.\n";
cout<<" -------------------------------------------------------------------------\n\n\n\n\n\n";
}
int main()
{
graf();

char ime[100];
char znak[1058];
char hexa[16];
int  imeb[200];
int  broj[528];
int  x,y,i,j,D,a,b,c;

//------ Popunjavanje konstanti u matricu --------------------------------------
strcpy(znak,"xA2683AFE8D2E4E83E22F3790AB7CA8806123C645528C046E3F4C6CD155999256B595EDB1EBA58E24691815DF1CDBD70FE7ECF95DAA1E479E5B1A78D3C7B74D41D694D2CE3D325C1B36C8C3C1777FAC5F3C191D0AB28B5026293B646F9BEE5972D040F2229ADA714486F7F8ADC0F0DE422A96C26ABE8AB0765406BA3901CB3462FDA149E1BD6784332CD488910C4F9C12B87582FFCA57E98709D8F1E54B38B9C50BB628F6E6BC179F73E3E8F49D10FCB3F34AC96B0235302D517EA9C4312598A0FAD95A5E07D5637970BB08E003977AF5FBA620EA21816514CF60E4587BA400DC6D2B93AF437DAE89740D0EBFCD1F3E05DD53A716EFCC8F85B44627664813A31156434A4E534651443B5444474F544830415852494933483156383442465B5A3145385932414F4A4D5355393057484334565530413132584D52434E39435A475355424A4C4533304C4F484748445636573251495042594C4D54364B3148383744353E3533443253445051574531305834475959463735523E4C4E53363950484C35434F303555564B3454543535353637383B5B4A564E514248585253425050344C4849445A395249515143514F4A57314F4250493634564C4C49493932314B494D444E4433535836455553545458443156564E37334C44463F4A5551564859344A38344D4D583334524F5A523556573837304A4F4D4647524F5745343643594823313030300000004000557365726E61");
strcpy(hexa,"0123456789ABCDEF");
for(i=1;i<529;i++)
{
    for(j=0;j<16;j++)
    {
        if(znak[i*2-1]==hexa[j])  { x=j; }
        if(znak[i*2]==hexa[j])    { y=j; }
    }
    broj[i]=x*16+y;
}

//------ Unos ASCII vrijednosti imena u matricu --------------------------------
cout<<"  User name:    ";
cin.get(ime,100);
D=strlen(ime);
for(i=0;i<200;i++) { imeb[i]=0; }
for(i=0;i<D;i++)   { imeb[i]=(char)ime[i]; }

//------- Prva petlja koja kriptira --------------------------------------------
if(D>3 && D<15)    { c=15; }
if(D>14 && D<30)   { c=30; }
if(D>29 && D<45)   { c=45; }
for(i=D;i<c;i++)   { imeb[i]=broj[i+1]; }
for(i=0;i<c;i++)
{
    for(j=0;j<c;j++)
    {
        x=imeb[i];
        y=broj[x+1];
        a=imeb[j];
        imeb[j]=a^y;
    } 
} 

//------- Druga petlja, koja je uvjetna ----------------------------------------
if(D>3 && D<15)    { c=1; }
if(D>14 && D<30)   { c=2; }
if(D>29 && D<45)   { c=3; }
if(c>1)
{
    a=imeb[16];
    x=c-1;
    for(j=x;j>0;j--)
    {
        for(i=0;i<15;i++)
        {
            imeb[i]=imeb[i]^imeb[16-1+i];
            imeb[i+1]=imeb[i+1]^imeb[16+i];
            imeb[i+2]=imeb[i+2]^imeb[16+1+i];
            imeb[i+3]=imeb[i+3]^imeb[16+2+i];
            imeb[i+4]=imeb[i+4]^imeb[16+3+i];
            i=i+4;
        }
    a=imeb[16+15];
    }
}

//------- Treca, zadnja petlja -------------------------------------------------
imeb[15]=0;
for(i=0;i<15;i++)
{
    x=imeb[i];
    y=broj[x+257];
    x=imeb[i+1];
    imeb[i]=y;
    
    y=broj[x+257];
    x=imeb[i+2];
    imeb[i+1]=y;
    
    y=broj[x+257];
    x=imeb[i+3];
    imeb[i+2]=y;    

    y=broj[x+257];
    x=imeb[i+4];
    imeb[i+3]=y;
    
    y=broj[x+257];
    imeb[i+4]=y;
    
    i=i+4;
}
if(D<4 || D>25)
{
cout<<"\n\n\n  ERROR! Wrong name length!";
}
else
{
cout<<"\n\n  Reg. code:    ";
for(i=0;i<5;i++) { cout<<(char)imeb[i]; }
cout<<"-";
for(i=5;i<10;i++) { cout<<(char)imeb[i]; }
cout<<"-";
for(i=10;i<15;i++) { cout<<(char)imeb[i]; }
}
cout<<"\n\n\n\n\n\n\n\n  ";system("pause");
return 0;
}