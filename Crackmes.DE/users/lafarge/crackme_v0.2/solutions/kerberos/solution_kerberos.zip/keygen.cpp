#include <iomanip>
#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>

using namespace std;

int lengthOfconstString = 0x10;
char constString[]="_r <()<1-Z2[l5,^";

void initializeBuffer(char *buffer)
{
  for (int i=0;i<lengthOfconstString;i++){
    buffer[i] = constString[i];
  }
}

int main()
{
  string name;
  char buffer[0x10];
  int rep;

  initializeBuffer(buffer);
  cout <<"Enter name : ";
  cin >> name;

  rep = (lengthOfconstString>name.length()) ? lengthOfconstString: name.length();

  for (int i =0;i < rep; i++){
    //    char *p = buffer+(i%lengthOfconstString);
    int a = name[i % name.length()];
    int b = buffer[i%lengthOfconstString];
    a ^= b;
    a %= 0x19;
    buffer[i%0x10] = a+0x41;
  }
  cout <<endl;

  cout << buffer[0]<<buffer[1]<<buffer[2]<<buffer[3];
  cout << "-";
  cout << buffer[4]<<buffer[5]<<buffer[6]<<buffer[7];
  cout << "-";
  cout << buffer[8]<<buffer[9]<<buffer[10]<<buffer[11];
  cout << "-";
  cout << buffer[12]<<buffer[13]<<buffer[14]<<buffer[15]<<endl;

  return 0;
}
