#include<stdio.h>
#include<string.h>
#define N 128
char name[N];
unsigned int serial = 0;
int main(int argc, char *argv){
	printf("please enter name:\n");
	scanf("%s", name);
	int len = strlen(name);
	for(int i = 0; i < len; ++ i){
		serial += (int)name[i];
		serial *= 2;
	}
	printf("The serial is %d\n", serial);

	return 0;
}