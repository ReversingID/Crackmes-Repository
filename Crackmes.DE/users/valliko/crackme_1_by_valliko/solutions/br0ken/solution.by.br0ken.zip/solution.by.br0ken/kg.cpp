#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
	int sum=0,len,i;
	char name[666];
	printf("*****************************************\n");
	printf("*********** Keygen by br0ken ************\n");
	printf("*****************************************\n\n");
	start:
	printf("\nEnter your name (6-14 chars): ");
	scanf("%s",&name);
	len=strlen(name);
	if(len<6 || len > 14)
	{
		printf("\nInvalid name entered. Press any key to try again...");
		getch();
		goto start;
	}
	printf("Serial : ");
	for(i=0;i<len;i++)
	{
		sum=sum+name[i];
		sum=sum+sum;
	}
	printf("%d",sum);
	getch();
}