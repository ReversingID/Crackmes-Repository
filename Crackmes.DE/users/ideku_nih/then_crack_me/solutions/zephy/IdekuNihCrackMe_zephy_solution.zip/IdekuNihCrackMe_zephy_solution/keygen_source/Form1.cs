﻿using System;
using System.Windows.Forms;

namespace IdekuNihCrMe_keygen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pbExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pbGenerate_Click(object sender, EventArgs e)
        {
            if (dfName.Text.Length < 5 || dfName.Text.Length > 9)
            {
                MessageBox.Show("Name must be between 5 and 9 characters!");
                return;
            }
            dfSerial.Text = GenerateSN(dfName.Text);
        }

        private string GenerateSN(string _name)
        {
            string _serial="";
            foreach (char c in _name)
            {
                _serial += (c ^ 0x6A).ToString("X2");
            }
            _serial = _serial.ToLower();
            if (_serial.Length > 8)
            {
                _serial = _serial.Substring(0, 8) + _serial.Substring(8, _serial.Length-8).ToUpper();
            }

            return _serial;
        }
    }
}
