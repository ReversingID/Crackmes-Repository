#undef UNICODE
#undef _UNICODE
#define _CRT_SECURE_NO_WARNINGS
#include <Windows.h>                                                                                                                         
#include <CommCtrl.h>
#include <stdio.h>
#include "resource.h"
#include "SHA512/sha2.h"

#define	NAME_MAX		128

//----------------------------------
inline char *hex (ULONG64 x, char *s)
{
	const char *hex_numbers  = "0123456789ABCDEF";
	*s = 0;
	if (!x) *--s = '0';
	for (; x; x/=16) *--s = hex_numbers [x%16];
	return s;
}
//----------------------------------
bool Generate (HWND hDlg)
{
	char msg[NAME_MAX+1] = {0};
	DWORD dwNameLen;
	BYTE	sha512_digest[64];
	ULONG64 newHash = 0;
	char* pStrKey;

	if (!(dwNameLen = GetDlgItemText (hDlg, IDC_EDIT_NAME, msg, NAME_MAX)))
		{SetDlgItemText (hDlg, IDC_EDIT_SERIAL, ""); return false;}

	get_sha512 ((BYTE*)msg, dwNameLen, sha512_digest);		// SHA-512
	// 'collapse' hash
	for (DWORD i=0; i<16; i++)
	{
		newHash <<= 4;
		newHash |= sha512_digest[i*4] >> 4;
	}

	newHash += 0xDADADADADA;		// + magic constant

	pStrKey = hex (newHash, &msg[sizeof(msg)-1]);
	msg[4] = msg[9] = msg[14] = '-';
	memcpy (msg, pStrKey, 4);
	memcpy (&msg[5], &pStrKey[4], 4);
	memcpy (&msg[10], &pStrKey[8], 4);
	memcpy (&msg[15], &pStrKey[12], 4);
	msg[19] = 0;

	SetDlgItemText (hDlg, IDC_EDIT_SERIAL, msg);
	return true;
}
//----------------------------------
BOOL CALLBACK DialogProc(HWND  hwndDlg, UINT  uMsg, WPARAM  wParam, LPARAM  lParam )
{
	switch (uMsg)
	{
	case WM_INITDIALOG:
		SendDlgItemMessage (hwndDlg, IDC_EDIT_NAME, EM_SETLIMITTEXT, NAME_MAX, 0);
		HICON hIcon;
		if (hIcon = LoadIcon(GetModuleHandle(0), MAKEINTRESOURCE(IDI_ICON1))) {
			SendMessage(hwndDlg, WM_SETICON, TRUE, (LPARAM)hIcon);
			SetClassLong (hwndDlg, GCL_HICON, (LONG)hIcon);
		}
		return TRUE;

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDC_BUTTON_GENERATE:
			Generate (hwndDlg); return TRUE;
		case IDCANCEL:
			EndDialog (hwndDlg, 0); return TRUE;
		}
		break;
	}
	return FALSE;
}
//----------------------------------
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	InitCommonControls ();
	DialogBox (hInstance, MAKEINTRESOURCE(IDD_DIALOG1), 0, DialogProc);
	return 0;
}
