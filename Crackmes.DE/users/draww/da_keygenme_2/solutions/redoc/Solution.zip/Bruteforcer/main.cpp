#undef UNICODE
#undef _UNICODE
#define _CRT_SECURE_NO_WARNINGS
#include <Windows.h>                                                                                                                         
#include <CommCtrl.h>
#include <stdio.h>
#include "resource.h"
#include "SHA512/sha2.h"

// global vars
const BYTE	g_required_hash[16] = { 0xD, 0xC, 0x5, 0x3, 0xC, 0x9, 0x7, 0x3, 0xE, 0x7, 0x3, 0xC, 0xD, 0xE, 0xD, 0x6 };
HWND				g_hDlg;
DWORD			g_dwThreads, g_dwStartTime;
ULONG64		g_x[64] = {0};
volatile bool	g_bQuit;
bool					g_bBruteStarted;

#define	START_BRUTE_VAL	0xE000000000
#define	INFO_TIMER_INTERVAL		4000		// ms

//----------------------------------
inline char *dec (ULONG64 x, char *s)
{
	*s = 0;
	if (!x) *--s = '0';
	for (; x; x/=10) *--s = '0'+x%10;
	return s;
}
//----------------------------------
inline char *hex (ULONG64 x, char *s)
{
	const char *hex_numbers  = "0123456789ABCDEF";
	*s = 0;
	if (!x) *--s = '0';
	for (; x; x/=16) *--s = hex_numbers [x%16];
	return s;
}
//----------------------------------
void ResultFound (char *pStrNum)
{
	DWORD dwWritten;
	char *pChar, szPath[MAX_PATH] = {0};

	GetModuleFileName (0, szPath, sizeof(szPath));
	if (pStrNum && (pChar = strrchr (szPath, '\\')))
	{
		strcpy (++pChar, "result.txt");
		HANDLE hFile = CreateFile (szPath, GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_ALWAYS, 0, NULL);
		if (hFile != INVALID_HANDLE_VALUE)
		{
			WriteFile (hFile, pStrNum, strlen (pStrNum), &dwWritten, 0);
			CloseHandle (hFile);
		}
	}

	MessageBox (g_hDlg, pStrNum, "Founded result", 0);
}
//----------------------------------
void StartThreads (DWORD dwNumOfThreads)
{
	g_dwStartTime = GetTickCount ();

	DWORD dwThreadID;
	DWORD WINAPI ThreadProc (PVOID pParam);
	for (DWORD i=0; i<dwNumOfThreads; i++)
		CloseHandle (CreateThread (NULL, 0, ThreadProc, (LPVOID)i, 0, &dwThreadID));

	VOID CALLBACK TimerProc (HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime);
	SetTimer (g_hDlg, 123, INFO_TIMER_INTERVAL, TimerProc);
}
//----------------------------------
DWORD WINAPI ThreadProc (PVOID pParam)
{
	bool bFounded;
	BYTE sha512_digest[64];
	char msg[32] = {0};
	char *pStrNum;
	int intShift = (int)pParam;

	for (g_x[intShift]= START_BRUTE_VAL - intShift;   !g_bQuit && g_x[intShift]>16;   g_x[intShift]-=g_dwThreads)
	{
		pStrNum = dec (g_x[intShift], &msg[sizeof(msg)-1]);
		get_sha512 ((BYTE*)pStrNum, &msg[sizeof(msg)-1] - pStrNum, sha512_digest);
		bFounded = true;
		for (int i=0; i<16; i++)
			if ((sha512_digest[i*4] >> 4) != g_required_hash[i])
				{bFounded = false; break;}

		if (bFounded)
		{
			g_bQuit = true;
			KillTimer (g_hDlg, 123);
			ResultFound (pStrNum);
			break;
		}
	}
	return 0;
}
//----------------------------------
VOID CALLBACK TimerProc (HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime)
{
	char szBuf[128]={0}, szOut[1024] = {0};
	DWORD dwHours, dwMinutes, dwSeconds;
	DWORD dwVal = GetTickCount () - g_dwStartTime;

	dwHours = dwVal / 3600000; dwVal %= 3600000;
	dwMinutes = dwVal / 60000; dwVal %= 60000;
	dwSeconds = dwVal / 1000;

	sprintf_s (szOut, "%02u:%02u:%02u\r\n", dwHours, dwMinutes, dwSeconds);

	for (DWORD i=0; i<g_dwThreads; i++)
	{
		sprintf_s (szBuf, "#%d:  %llu  (%#llX)\r\n", i, g_x[i], g_x[i]);
		strcat_s (szOut, szBuf);
	}
	SetDlgItemText (g_hDlg, IDC_EDIT_INFO, szOut);
}
//----------------------------------
BOOL CALLBACK DialogProc(HWND  hwndDlg, UINT  uMsg, WPARAM  wParam, LPARAM  lParam )
{
	switch (uMsg)
	{
	case WM_INITDIALOG:
		g_hDlg = hwndDlg;
		SYSTEM_INFO sysinfo;
		GetSystemInfo (&sysinfo);
		g_dwThreads = sysinfo.dwNumberOfProcessors;
		SetDlgItemInt (g_hDlg, IDC_STATIC_CORES, g_dwThreads, FALSE);
		return TRUE;

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{

		case IDC_BUTTON_START_STOP:
			SetDlgItemText (hwndDlg, IDC_BUTTON_START_STOP, g_bBruteStarted ? "Start" : "Stop");
			if (g_bBruteStarted)
				{g_bQuit = true; g_bBruteStarted = false; KillTimer (hwndDlg, 123);}
			else
				{g_bQuit = false; StartThreads (g_dwThreads); g_bBruteStarted = true;}		// start BRUTING
			return TRUE;

		case IDC_CHECK_MINUS_ONE_CORE:
			if (IsDlgButtonChecked (hwndDlg, IDC_CHECK_MINUS_ONE_CORE))
				SetDlgItemInt (g_hDlg, IDC_STATIC_CORES, --g_dwThreads, FALSE);
			else
				SetDlgItemInt (g_hDlg, IDC_STATIC_CORES, ++g_dwThreads, FALSE);
			return TRUE;

		case IDC_BUTTON_CLOSE:
			g_bQuit = true;
			EndDialog (hwndDlg, 0); return TRUE;
		}
		break;
	}
	return FALSE;
}
//----------------------------------
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	InitCommonControls ();
	DialogBox (hInstance, MAKEINTRESOURCE(IDD_DIALOG1), 0, DialogProc);
	return 0;
}
