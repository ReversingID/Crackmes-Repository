using System;
using System.Security.Cryptography;
using System.Text;

namespace Keygen {
	
	public class KeyGen {
		private long inKeyHi;
		private long inKeyLo;
	
		public KeyGen () {
			long seed = SystemKey();
		
			this.inKeyHi = 0L;
			this.inKeyLo = seed & 0xFFL;
		
			for (int n = 0; n < 0x1a; n++)
				this.inKeyLo |= ((seed >> ((n + 8) & 0x3f)) & 1L) << ((2 * n) + 8);
		
			for (int n = 0; n < 30; n++)
				this.inKeyHi |= ((seed >> (((0x1a + n) + 8) & 0x3f)) & 1L) << (2 * n);
		}
	
		public static string Name {
			get {
				return SystemKey().ToString();
			}
		}
	
		public string GenerateSerial (uint seed) {
			char[] chars = new char[24];
		
			// Prepare asum and bsum from seed
			seed &= 0x3fffffff;
		
			long asum = ((long)seed << 30) | seed;
			long bsum = asum;
		
			asum ^= this.inKeyLo ^ 0x89b01d3da4d55a9L;
			bsum ^= this.inKeyHi ^ 0x8bc9f8bd58b03d5L;
		
			// Generate /[\x00-\x1F]+/ from asum and bsum
			long bitpos = 0x80000000000000L;
			for (int n = 23; n >= 12; n--) {
				long chrnum = bsum / bitpos;
				bsum -= chrnum * bitpos;
			
				chars[n] = (char)chrnum;
			
				bitpos /= 32L;
			}

			bitpos = 0x80000000000000L;
			for (int n = 11; n >= 0; n--) {
				long chrnum = asum / bitpos;
				asum -= chrnum * bitpos;
			
				chars[n] = (char)chrnum;
			
				bitpos /= 32L;
			}
		
			// 0x00 to 0x09 -> 0 to 9   (+'0')
			// 0x0A to 0x11 -> A to H   (+'7')
			// 0x12 to 0x13 -> J to K   (+'8')
			// 0x14 to 0x15 -> M to N   (+'9')
			// 0x16 to 0x18 -> P to R   (+':')
			// 0x19 to 0x1F -> T to Z   (+';')
			for (int n = 0; n < chars.Length; n++) {
				if (chars[n] >= 0x00 && chars[n] <= 0x09)
					chars[n] += '0';
				else if (chars[n] >= 0x0A && chars[n] <= 0x11)
					chars[n] += '7';
				else if (chars[n] >= 0x12 && chars[n] <= 0x13)
					chars[n] += '8';
				else if (chars[n] >= 0x14 && chars[n] <= 0x15)
					chars[n] += '9';
				else if (chars[n] >= 0x16 && chars[n] <= 0x18)
					chars[n] += ':';
				else if (chars[n] >= 0x19 && chars[n] <= 0x1F)
					chars[n] += ';';
			}
		
			//  1 -> L
			// (1 -> I)
			//  0 -> O
			//  5 -> S
			for (int n = 0; n < chars.Length; n++) {
				if (chars[n] == '1')
					chars[n] = 'L';
				else if (chars[n] == '0')
					chars[n] = 'O';
				else if (chars[n] == '5')
					chars[n] = 'S';
			}
		
			return new string(chars);
		}
	
		private static long SystemKey () {
			long num = 0L;
			long num2 = 0L;
			long num3 = 0L;

			SHA256Managed managed = new SHA256Managed();
			byte[] bytes = Encoding.Unicode.GetBytes(string.Concat("DrAww AliEn", Environment.MachineName, Environment.OSVersion.ToString(), Environment.ProcessorCount.ToString()));
			byte[] buffer2 = managed.ComputeHash(bytes);

			for (int i = 0; i <= 5; i++)
				num += (buffer2[i] >> (buffer2[i + 1] << 30)) * 0x1453;

			for (int j = 6; j <= 10; j++)
				num2 += ((buffer2[j] ^ (buffer2[j + 1] * 8)) & 0xcafe) ^ ((j * 2) + 0xbabe);

			for (int k = 11; k <= 15; k++)
				num3 += buffer2[k] | 0xbadc0de;

			return ((2L ^ num2) + ((2L * num) | num3));
		}
	}
}
