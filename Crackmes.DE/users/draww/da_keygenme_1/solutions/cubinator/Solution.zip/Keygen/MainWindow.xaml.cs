﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;

namespace Keygen {
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window {
		private KeyGen keygen = new KeyGen();
		private bool ready = false;

		public MainWindow () {
			InitializeComponent();
			this.DataContext = this;
		}

		private static void Copy (string str) {
			Clipboard.SetText(str, TextDataFormat.UnicodeText);
		}

		private void CopyName (object sender, RoutedEventArgs e) {
			Copy(this.UserName);
		}

		private void CopySerial (object sender, RoutedEventArgs e) {
			Copy(this.tbSerial.Text);
		}

		public static bool Patch (string path, Dictionary<long, byte[]> patches) {
			try {
				using (FileStream file = File.OpenWrite(path))
				using (BinaryWriter writer = new BinaryWriter(file)) {
					foreach (KeyValuePair<long, byte[]> patch in patches) {
						file.Position = patch.Key;
						writer.Write(patch.Value);
					}
				}

				return true;
			} catch (Exception) {
				return false;
			}
		}

		private void Patch (object sender, DragEventArgs e) {
			if (!(bool)e.Data.GetDataPresent(DataFormats.FileDrop))
				return;

			string path = ((string[])e.Data.GetData(DataFormats.FileDrop))[0];
			bool restore = (e.KeyStates & DragDropKeyStates.ControlKey) != 0;

			bool success = Patch(path, restore ? new Dictionary<long,byte[]>() {
				{ 0x278, new byte[] { 0x00, 0x16, 0x6A, 0x0A } },
				{ 0x4FF, new byte[] { 0x16 } },
				{ 0x57D, new byte[] { 0x16 } },
				{ 0x5DD, new byte[] { 0x16 } }
			} : new Dictionary<long, byte[]>() {
				{ 0x278, new byte[] { 0x38, 0xD0, 0x00, 0x00 } },
				{ 0x4FF, new byte[] { 0x17 } },
				{ 0x57D, new byte[] { 0x17 } },
				{ 0x5DD, new byte[] { 0x17 } }
			});

			if (success)
				Process.Start(path);
			else
				MessageBox.Show(this, "Modification failed", "FAILURE", MessageBoxButton.OK, MessageBoxImage.Error);
		}

		private void SeedChanged (object sender, TextChangedEventArgs e) {
			if (!this.ready)
				return;

			uint seed;

			if (!uint.TryParse((sender as TextBox).Text, out seed))
				return;
			
			this.tbSerial.Text = this.keygen.GenerateSerial(seed);

			e.Handled = true;
		}

		public string UserName {
			get {
				return KeyGen.Name;
			}
			set {}
		}

		private void WindowLoaded (object sender, RoutedEventArgs e) {
			this.ready = true;
			this.tbSeed.Text = "73";
		}

		private void CheckFilesBeforePatch (object sender, DragEventArgs e) {
			string[] files;
			e.Effects = !(bool)e.Data.GetDataPresent(DataFormats.FileDrop) || (files = (string[])e.Data.GetData(DataFormats.FileDrop)).Length != 1 || !files[0].EndsWith(".exe")
				? DragDropEffects.None
				: (e.KeyStates & DragDropKeyStates.ControlKey) == 0 ? DragDropEffects.Move : DragDropEffects.Copy;

			e.Handled = true;
		}
	}
}
