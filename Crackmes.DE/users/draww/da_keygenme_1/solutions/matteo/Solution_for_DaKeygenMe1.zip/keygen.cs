﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Security.Cryptography;

namespace Keygen_for_DAKeygenMe1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private long syskey()
        {
            long num = 0L;
            long num2 = 0L;
            long num3 = 0L;
            SHA256Managed managed = new SHA256Managed();
            byte[] bytes = Encoding.Unicode.GetBytes("DrAww AliEn" + Environment.MachineName + Environment.OSVersion.ToString() + Environment.ProcessorCount.ToString());
            byte[] buffer2 = managed.ComputeHash(bytes);
            for (int i = 0; i <= 5; i++)
            {
                num += (buffer2[i] >> (buffer2[i + 1] << 30)) * 0x1453;
            }
            for (int j = 6; j <= 10; j++)
            {
                num2 += ((buffer2[j] ^ (buffer2[j + 1] * 8)) & 0xcafe) ^ ((j * 2) + 0xbabe);
            }
            for (int k = 11; k <= 15; k++)
            {
                num3 += buffer2[k] | 0xbadc0de;
            }
            return ((2L ^ num2) + ((2L * num) | num3));
        }

        Int64 inKeyLo, inKeyHi;
        public void SetKeyGenerationSeed(long seedparm)
        {
            inKeyLo = seedparm & 0xffL;
            inKeyHi = 0L;
            for (int i = 0; i < 0x1a; i++)
            {
                inKeyLo |= ((seedparm >> ((i + 8) & 0x3f)) & 1L) << ((2 * i) + 8);
            }
            for (int j = 0; j < 30; j++)
            {
                inKeyHi |= ((seedparm >> (((0x1a + j) + 8) & 0x3f)) & 1L) << (2 * j);
            }
        }

        //simple version of validate key
        public bool ValidateKey(string key)
        {
            if (string.IsNullOrEmpty(key))
            {
                return false;
            }
            char[] chArray = new char[0x18];
            int index = 0;
            for (int i = 0; (i < key.Length) && (index < 0x18); i++)
            {
                char ch = key[i];
                if ((((ch >= '0') && (ch <= '9')) || ((ch >= 'a') && (ch <= 'z'))) || ((ch >= 'A') && (ch <= 'Z')))
                {
                    chArray[index++] = key[i];
                }
            }

            for (int k = 0; k < chArray.Length; k++)
            {
                if ((chArray[k] >= '0') && (chArray[k] <= '9'))
                {
                    chArray[k] = (char)(chArray[k] - '0'); // 0 - 9
                }
                if ((chArray[k] >= 'A') && (chArray[k] <= 'H'))
                {
                    chArray[k] = (char)(chArray[k] - '7');// 10 - 17
                }
                if ((chArray[k] >= 'J') && (chArray[k] <= 'K'))
                {
                    chArray[k] = (char)(chArray[k] - '8');// 18 - 19
                }
                if ((chArray[k] >= 'M') && (chArray[k] <= 'N'))
                {
                    chArray[k] = (char)(chArray[k] - '9');// 20 - 21
                }
                if ((chArray[k] >= 'P') && (chArray[k] <= 'R'))
                {
                    chArray[k] = (char)(chArray[k] - ':');// 22 - 24
                }
                if ((chArray[k] >= 'T') && (chArray[k] <= 'Z'))
                {
                    chArray[k] = (char)(chArray[k] - ';');// 25 - 31
                }
            }
 
            long num6 = 0L;
            long num7 = 0L;
            long num8 = 1L;
            for (int m = 0; m < 12; m++)
            {
                num6 += chArray[m] * num8;
                num8 *= 0x20L;
            }
            num8 = 1L;
            for (int n = 12; n < 0x18; n++)
            {
                num7 += chArray[n] * num8;
                num8 *= 0x20L;
            }
            num6 = (num6 ^ 0x89b01d3da4d55a9L) ^ this.inKeyLo;
            num7 = (num7 ^ 0x8bc9f8bd58b03d5L) ^ this.inKeyHi;
            long num11 = num6 & 0x3fffffffL;
            long num12 = (num6 & 0xfffffffc0000000L) >> 30;
            long num13 = num7 & 0x3fffffffL;
            long num14 = (num7 & 0xfffffffc0000000L) >> 30;
            return (((num11 == num12) && (num11 == num13)) && (num11 == num14));
        }

        //num <= 0x3FFFFFFF
        byte[] FindSolution(long num,long xorVal)
        {
            if (num > 0x3FFFFFFF)
                return null;
            long numDaTrovare = (num | (num<<30)) ^ xorVal;
            double divisione;
            long resto;
            byte[] solution = new byte[12];

            try
            {
                for (int i = 11; i >= 0; i--)
                {
                    divisione = numDaTrovare / Math.Pow(0x20, i);
                    resto = numDaTrovare % (long)Math.Pow(0x20, i);
                    numDaTrovare = resto;

                    solution[i] = (byte)Math.Floor(divisione);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Byte is too small!!");
                return null;
            }
            return solution;
        }

        char[] ConvertSolution(byte[] solution)
        {
            char[] key=new char[12];
            try
            {
                for (int k = 0; k < 12; k++)
                {
                    if ((solution[k] >= 0) && (solution[k] <= 9))
                    {
                        key[k] = (char)(solution[k] + '0'); // 0 - 9
                        continue;
                    }
                    if ((solution[k] >= 10) && (solution[k] <= 17))
                    {
                        key[k] = (char)(solution[k] + '7');// 10 - 17
                        continue;
                    }
                    if ((solution[k] >= 18) && (solution[k] <= 19))
                    {
                        key[k] = (char)(solution[k] + '8');// 18 - 19
                        continue;
                    }
                    if ((solution[k] >= 20) && (solution[k] <= 21))
                    {
                        key[k] = (char)(solution[k] + '9');// 20 - 21
                        continue;
                    }
                    if ((solution[k] >= 22) && (solution[k] <= 24))
                    {
                        key[k] = (char)(solution[k] + ':');// 22 - 24
                        continue;
                    }
                    if ((solution[k] >= 25) && (solution[k] <= 31))
                    {
                        key[k] = (char)(solution[k] + ';');// 25 - 31
                        continue;
                    }
                    throw new Exception("D'OH! no string for this byte!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
            return key;
        }

        private void btnGiveTheKey_Click(object sender, EventArgs e)
        {
            long hwIDkey=0;
            try
            {
                hwIDkey = Convert.ToInt64(txtID.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            SetKeyGenerationSeed(hwIDkey);
            byte[] sol1 = FindSolution((long)solutionNumber.Value, 0x89b01d3da4d55a9L ^ inKeyLo);
            byte[] sol2 = FindSolution((long)solutionNumber.Value, 0x8bc9f8bd58b03d5L ^ inKeyHi);
            char[] key1 = ConvertSolution(sol1);
            char[] key2 = ConvertSolution(sol2);
            string theKey = new string(key1) + new string(key2);
            txtPW.Text = theKey;
        }

        private void btnGiveID_Click(object sender, EventArgs e)
        {
            long hwIDkey = syskey();
            txtID.Text = hwIDkey.ToString();
        }    
    }
}
