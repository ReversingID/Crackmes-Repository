from sys import argv

def filter(inStr):
    outStr = ''
    for c in inStr:
        if c in alpha:
            outStr += c
    return outStr

def code_name(name):
    hash = 0
    for i in range(0, len(name)):
        hash = alpha.find(name[len(name)-i-1]) + hash * 62
    return hash

def sub_div(zn):
    if (zn < const_add):
        zn = zn + 2**64
    zn = (zn-const_add) % 2**64
    zn = (zn * const_mul_inverse) % 2**64
    return zn

const_add = 0x1F95F977396329EAL
const_mul = 0x4FE5270E13140699L

const_mul_inverse = 0x74B9061D928CEDA9L

#------------------------------------------------------------------------------
# main()
#------------------------------------------------------------------------------

#for example, "SFeS" = "513F-9D9F-E98D-085B"

myname = "SFeS"
alpha = "KbcOZYCawSUqLHnAJTu862gW3dGBNDhkmiF4toQ05xzMpj9l1PERyIVsvrXef7"

if len(argv) > 1:
   myname = argv[1]

if len(myname) > 10:
    print "Error: A user name must be 10 chars or shorter."
    exit

myname = filter(myname) #Only letters and numbers are allowed

#calculate code
lic_key = code_name(myname)
for i in range(0, 7):
    lic_key = sub_div(lic_key)

res = "%016X" % (lic_key)
print "User name: %s" % (myname)
print "License: %s-%s-%s-%s" % (res[0:4],res[4:8],res[8:12],res[12:16])

