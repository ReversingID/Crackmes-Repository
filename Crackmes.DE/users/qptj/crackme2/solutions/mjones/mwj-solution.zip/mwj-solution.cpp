#include <string>
#include <iomanip>
#include <iostream>
#include <algorithm>
#include <shlwapi.h>

#pragma comment(lib, "shlwapi.lib")

using namespace std;

void stage1 (unsigned int &, unsigned int &, unsigned int &, unsigned int &);
void stage3 (unsigned int &, unsigned int &, unsigned int &, unsigned int &, string &);

int main() {
    unsigned int var_eax, var_ebx, var_ecx, var_edx;
    unsigned int it_stage1 = 0, it_stage2 = 0, it_stage3 = 0, it_stage4 = 0;
    std::string var_esi;

    // bruteforce stage 1: var_eax == 0xFFFCF2C0
    std::cout << "Stage 1 bruteforcing... " << endl;
    do {
        var_eax = it_stage1;
        var_ebx = 1;
        var_ecx = 0;
        var_edx = 0;

        stage1(var_eax, var_ebx, var_ecx, var_edx);
        std::cout << "Input: 0x" << std::setfill('0') << std::setw(8) << std::hex << it_stage1 << "\t";
        std::cout << "Return: 0x" << std::setfill('0') << std::setw(8) << std::hex << var_eax << endl;
        it_stage1++;
    } while (var_eax != 0xFFFCF2C0);    
    std::cout << "Complete.  Serial length is " << std::dec << --it_stage1 << endl;
    std::cout << endl;
    std::cin.get();

    // bruteforce stage 2: var_eax == 33F9E44F
    it_stage2 = 100; // we know the length is three characters [100, 999]
    std::cout << "Stage 2 bruteforcing... " << endl;
    do {
        var_eax = it_stage2;
        var_ebx = 0x1C4;
        var_ecx = 0;
        var_edx = 0;

        stage1(var_eax, var_ebx, var_ecx, var_edx);
        std::cout << "Input: 0x" << std::setfill('0') << std::setw(8) << std::hex << it_stage2 << "\t";
        std::cout << "Return: 0x" << std::setfill('0') << std::setw(8) << std::hex << var_eax << endl;
        it_stage2++;
    } while (var_eax != 0x33F9E44F);
    std::cout << "Complete.  First three digits of serial are " << std::dec << --it_stage2 << endl;
    std::cout << endl;
    std::cin.get();
    
    // bruteforce stage3: var_eax == 0A3B5E6C
    it_stage3 = 10000; // we know the length is five characters [10000, 99999]
    std::cout << "Stage 3 bruteforcing... " << endl;
    do {
        var_eax = it_stage3;
        var_esi.clear();
        
        stage3(var_eax, var_ebx, var_ecx, var_edx, var_esi);
        var_eax = StrToInt(var_esi.substr(0, 8).c_str());
        var_ebx = var_eax;
        var_eax = StrToInt(var_esi.substr(9, var_esi.length() - 9).c_str());
        var_eax ^= var_ebx;
        var_eax ^= 1;
        var_ebx = 0x1D3E;
        stage1(var_eax, var_ebx, var_ecx, var_edx);

        std::cout << "Input: 0x" << std::setfill('0') << std::setw(8) << std::hex << it_stage3 << "\t";
        std::cout << "Return: 0x" << std::setfill('0') << std::setw(8) << std::hex << var_eax << endl;
        it_stage3++;
    } while (var_eax != 0x0A3B5E6C);
    std::cout << "Complete.  Next five digits of serial are " << std::dec << --it_stage3 << endl;
    std::cout << endl;
    std::cin.get();

    // bruteforce stage4
    it_stage4 = 10000000; // we know the length is eight characters [10000000, 99999999]
    std::cout << "Stage 4 bruteforcing... " << endl;
    do {
        var_eax = it_stage4;
        var_ebx = 0x921371;

        stage1(var_eax, var_ebx, var_ecx, var_edx);
        var_esi.clear();
        stage3(var_eax, var_ebx, var_ecx, var_edx, var_esi);

        std::cout << "Input: 0x" << std::setfill('0') << std::setw(8) << std::hex << it_stage4 << "\t";
        std::cout << "Return: " << var_esi << endl;
        it_stage4++;
    } while (var_esi != "100011110001001111000010001001");
    std::cout << "Complete.  Last nine digits of serial are " << std::dec << --it_stage4 << endl;
    std::cout << endl;

    // win!
    std::cout << "Serial is " << it_stage2 << "-" << it_stage3 << "-" << it_stage4 << endl;
    
    std::cin.get();
    std::cin.get();
    return 0;
}


void stage1 (unsigned int &v_eax, unsigned int &v_ebx, unsigned int &v_ecx, unsigned int &v_edx) {
    unsigned int val_eax = v_eax;
    unsigned int val_ebx = v_ebx;
    unsigned int val_ecx = v_ecx;
    unsigned int val_edx = v_edx;

    __asm {
        mov eax, val_eax
        mov ebx, val_ebx
        mov ecx, val_ecx
        mov edx, val_edx

        S1:
        MOV ECX,EAX
        MOV EDX,746h
        IMUL EAX,EAX
        IMUL EAX,EAX,4
        IMUL ECX,ECX,9
        ADD EAX,ECX
        ADD EAX,EDX
        XOR EDX,EDX
        MOV ECX,5
        IDIV ECX
        MOV EDX,153Fh
        MOV ECX,EAX
        IMUL EAX,EAX
        IMUL EAX,EAX,2
        IMUL ECX,ECX,4
        ADD EAX,ECX
        ADD EAX,EDX
        MOV ECX,15F1Fh
        SUB EAX,ECX
        XOR EDX,EDX
        MOV ECX,4
        IDIV ECX
        MOV ECX,5A2D9h
        ADD EAX,ECX
        SUB EAX,0BBD59h
        DEC EBX
        JNZ S1
        
        mov val_eax, eax
        mov val_ebx, ebx
        mov val_ecx, ecx
        mov val_edx, edx
    }

    v_eax = val_eax;
    v_ebx = val_ebx;
    v_ecx = val_ecx;
    v_edx = val_edx;
}

void stage3 (unsigned int &v_eax, unsigned int &v_ebx, unsigned int &v_ecx, unsigned int &v_edx, string &v_esi) {
    v_edx ^= v_edx;             // XOR EDX,EDX
    v_ecx = 2;                  // MOV ECX,2

    do {
        v_edx = (v_eax % v_ecx);
        v_eax /= v_ecx;         // IDIV ECX        
        v_edx += 0x30;          // ADD EDX,30
        v_esi += (char)v_edx;   // MOV BYTE PTR DS:[ESI],DL        
        v_edx ^= v_edx;         // XOR EDX,EDX
    } while (v_eax != 0);       // TEST EAX,EAX -> JNZ 
    reverse(v_esi.begin(), v_esi.end());
}