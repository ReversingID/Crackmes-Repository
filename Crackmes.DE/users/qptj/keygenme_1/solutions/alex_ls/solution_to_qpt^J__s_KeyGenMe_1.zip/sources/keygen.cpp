// coded by alex_ls

// includes
#include "baseinit.h"

// global wnd variables
static HINSTANCE hInstance;
HICON hIcon;

void CryptBlock(BYTE*);

void GetSerial1(char* sz_name, DWORD dw_esp)
{
	char p_key[0x4000];

	const BYTE sha1[]=	{
							0x70,0x56,0x93,0xD5,0x82,0x59,0xB1,0xFD,0x12,0x59,
							0xDB,0x0C,0xC6,0x2A,0x6A,0xBC,0xC5,0x18,0xE9,0xAC,
							0x0
						};

	const char str1[]="wmsdbklfdhajpishgovmboaeyrjl;amjkl;afbl;l;n,ag;'cn;'zkg;ldhcaf00";
	const char str2[]="~!@#$%^&*()_-=\\+|{[]}'';:.,/? ~!@#$%^&*()_+|{[]}'';:.,/? ~!@#$00";
	const char str3[]="31963B61A322F574D575832F5F0589497A42D61B07274EE06070B3C992705800";
	const char str4[]="XXXX-AAAA-BBBB-QQQQ====AAAA====XXXX====@##@##$$%^^$^%$$E#$#E$#00";
	const char str5[]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

	strupr(sz_name);
	
	memset(p_key,0,0x4000);
	strcpy(p_key,sz_name);

	char *sha_key1=p_key+0xe9;
	char *sha_key2=sha_key1+4;
	char *sha_key3=sha_key1+8;
	char *sha_key4=sha_key1+12;
	char *sha_key5=sha_key1+16;
	
	strcpy(sha_key1,(char*)sha1);
	*(DWORD*)(sha_key5+4)=dw_esp;
	
	lstrcat(p_key,sha_key1);
	lstrcat(p_key,sha_key3);
	lstrcat(p_key,sha_key2);
	lstrcat(p_key,sha_key5);
	lstrcat(p_key,sha_key4);
		
	lstrcat(p_key,str1);
	lstrcat(p_key,str2);
	lstrcat(p_key,str3);
	lstrcat(p_key,str4);
	lstrcat(p_key,str5);
	
	
	lstrcat(p_key,sha_key1);
	lstrcat(p_key,sha_key3);
	lstrcat(p_key,sha_key2);
	lstrcat(p_key,sha_key5);
	lstrcat(p_key,sha_key4);

	lstrcat(p_key,str1);
	lstrcat(p_key,str2);
	lstrcat(p_key,str3);
	lstrcat(p_key,str4);
	lstrcat(p_key,str5);
	
	CryptBlock((BYTE*)p_key);
	
	DWORD *p_tmp=(unsigned long*)(p_key);
	for(BYTE j=0;j<8;j++)
		p_tmp[j]^=0x12345678;
		
	wsprintf(p_key+0x00,"%04X",p_tmp[0]);
	wsprintf(p_key+0x08,"%04X",p_tmp[2]);
	wsprintf(p_key+0x10,"%04X",p_tmp[4]);
	wsprintf(p_key+0x18,"%04X",p_tmp[6]);

	strcpy(sz_name,"4210535-");
	strcat(sz_name,p_key);
	return;
}
void GetSerial2(char* sz_name)
{
	HWND h_wnd;
	HANDLE hDebugProcess;
	HANDLE hDebugThread;
	
	DWORD dw_tid;
	DWORD dw_pid;
	DWORD dw_esp;
	DWORD dw_read;
	DWORD dwContinueStatus;
	
	h_wnd=FindWindow(NULL,"KeyGenMe 1");
	if(h_wnd)
	{
		dw_tid=GetWindowThreadProcessId(h_wnd,&dw_pid);
	
		DebugActiveProcess(dw_pid);	
	
		DEBUG_EVENT DebugEvent;
		CONTEXT		Context;
	
		WaitForDebugEvent(&DebugEvent, INFINITE);
		hDebugProcess=DebugEvent.u.CreateProcessInfo.hProcess;
		hDebugThread=DebugEvent.u.CreateProcessInfo.hThread;
		Context.ContextFlags=CONTEXT_CONTROL;
		GetThreadContext(hDebugThread,&Context);
		dw_esp=Context.Esp-0x35c;
		DebugActiveProcessStop(dw_pid);
		GetSerial1(sz_name,dw_esp);
	} else
		strcpy(sz_name,"start the original keygenme before!");
	return;
};

// generate serial
DWORD WINAPI GenerateSerial(HWND hwnd)
{
	char    sz_name[0x100]={0};
	char    sz_key[0x100]={0};
	DWORD   dw_namelen=0x100;
	dw_namelen = GetDlgItemTextA(hwnd, IDC_NAME, (char*)sz_name, dw_namelen);
	
	// get username from dialog
	if ((dw_namelen > 0 )&& (dw_namelen<256))
	{
		strcpy(sz_key,sz_name);
		GetSerial1(sz_key,0);
		SetDlgItemText(hwnd, IDC_SERIAL, sz_key);
		GetSerial2(sz_name);
		SetDlgItemText(hwnd, IDC_SERIAL2, sz_name);
	}
	else
		SetDlgItemText(hwnd, IDC_NAME, NAMELENGTH_ERROR);
	return 0;
}
// wndproc function
INT_PTR CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam)
{
	switch (Message)
	{
		// init dialogbox
		case WM_INITDIALOG:
			
			SetWindowText(hwnd, NAME_INFO);
			SetDlgItemText(hwnd, IDC_NAME, "alex_ls");
			SetDlgItemText(hwnd, IDC_SERIAL, "serial for patched  keygenme");
			SetDlgItemText(hwnd, IDC_SERIAL2, "serial for original keygenme");
			SendDlgItemMessage(hwnd, IDC_NAME, EM_LIMITTEXT, MAX_NAME,0);
			SetFocus(GetDlgItem(hwnd,IDC_NAME));
			// Icon
			hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDD_DIALOG1));
			return true;
		break;

		// commands
		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
				// push generate button
				case IDC_CREATESERIAL:
					GenerateSerial(hwnd);
					break;
				// push exit button
				case IDC_EXIT:
					EndDialog(hwnd, 0);
					break;
			}
		break;
		
		// exit prog
		case WM_CLOSE:
			EndDialog(hwnd, 0);
		break;
		
		default:
			return FALSE;
	}
	return TRUE;
}

// main func
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInst, LPSTR lpCmd, int nShow)
{
	hInstance = GetModuleHandle(NULL);
	hInst =		hInstance;
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, (DLGPROC)WndProc, (LPARAM)NULL);
	return 0;
}