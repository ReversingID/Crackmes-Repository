				A few words about solution
This solution includes 2 keygenme:
KeyGenMePatched.exe  - the patched version where a key calculation algo doesn't take account of ESP VALUE
KeyGenMeOriginal.exe - original version of this keygenme

Well my keygen has 2 serial fields:
Serial1 - serial for KeyGenMePatched.exe
Serial2 - serial for KeyGenMeOriginal.exe
And here's one condition - to generate Serial2 the KeyGenMeOriginal.exe must be started,
because keygen attaches to KeyGenMeOriginal process and gets an upper stack address 
from the CONTEXT structure.
Unfortunately I can't test it on other OS - KeyGenMe 1 crashes on Vista and Windows 7!
I just made an attempt to create a fully working keygen.


			              listing

1. solution.txt		- tutorial
2. deobf.idc		- deobfuscation script for IDA PRO
3. KeyGenMePatched.exe 	- patched crackme, it was impossible to write a proper keygen in an usual way for the original version!
3. KeyGenMeOriginal.exe - original version of keygenme
4. keygen.exe 		- keygen, that generates 2 keys for patched keygenme and original one accordingly!
5. sources		- sources for keygen
