///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	HEADERS & LIBRARYS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#define 			WIN32_LEAN_&_MEAN
#include 		<stdio.h>
#include 		<stdlib.h>
#include 		<math.h>
#include 		<time.h>
#include 		<windows.h>
#include 		<commctrl.h>
#include 		<commdlg.h>
#include			<windowsx.h>
#include 		<wincrypt.h>
#include			<objbase.h>


#include "Keygen.h"

#define MUSIC

#ifdef MUSIC	
	#include "ufmod.h"
	#include "Tune.h"
	#pragma comment (lib,"Winmm.lib")
	#pragma comment (lib,"ufmod.lib")
#endif

#include <cryptohash.h>
#pragma comment(lib, "cryptohash.lib")

#include "miracl.h"
#pragma comment (lib,"miracl.lib")
#pragma comment (lib,"libcmt.lib")

#pragma comment(linker, "/NODEFAULTLIB")



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	DEFINITIONS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#define BP __asm{db 0xcc}
#pragma warn(disable: 2145)


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	FUNCTION PROTOTYPES
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int CALLBACK WinMain(HINSTANCE hInst,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nCmdShow);
INT_PTR CALLBACK MainDialogProc(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam);
void CreateKey(HWND hWnd);
void GenerateRSAKeys(big N,big D,big M);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	GLOBAL VARIABLES
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
HINSTANCE hInstance;
HICON hIcon;

LPSTR lpszProtection = 		"[ qpt^J's KeyGenMe 3 - Keygen ]\n\n"
							"Protection:\n"
							"--------------------------------------------------\n"
							"MD5 Hash\n"
							"SHA1 Hash\n"
							"Haval Hash\n"
							"XTea Cipher\n"
							"Blowfish Cipher\n"
							"Base64 Encoding\n"
							"RSA 64 Bits\n"
							"--------------------------------------------------\n";



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	CODE
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


int CALLBACK WinMain(HINSTANCE hInst,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nCmdShow)
{
	hInstance = hInst;
	DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_MAIN),NULL,MainDialogProc,0);
	ExitProcess(0);
	return FALSE;
}

INT_PTR CALLBACK MainDialogProc(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	char szUserName[200] 		= "";
	MSGBOXPARAMS mbp  		={0};
	DWORD nSize 				= sizeof(szUserName);

	switch(uMsg)
	{
		case WM_INITDIALOG:
		{
			#ifdef MUSIC
			uFMOD_PlaySong(Tune,hInstance,XM_MEMORY);
			#endif
			hIcon = LoadIcon(hInstance,MAKEINTRESOURCE(ID_ICON_MAIN));
			SendMessage(hWnd,WM_SETICON,0,(LPARAM)hIcon);
			GetUserName(szUserName,&nSize);
			SetDlgItemText(hWnd,IDC_EDIT_NAME,szUserName);
			CreateKey(hWnd);
			break;
		}

		case WM_CLOSE:
		{
			EndDialog(hWnd,0);
			break;
		}

		case WM_COMMAND:
		{
			switch(LOWORD(wParam))
			{
				case IDC_BUTTON_GENERATE:
				{
					CreateKey(hWnd);
					break;
				}

				case IDC_BUTTON_ABOUT:
				{
					mbp.cbSize = sizeof(MSGBOXPARAMS);
					mbp.hwndOwner = hWnd;
					mbp.hInstance = hInstance;
					mbp.lpszText = lpszProtection;
					mbp.lpszCaption = "[ About ]";
					mbp.lpszIcon = MAKEINTRESOURCE(ID_ICON_MAIN);
					mbp.dwStyle = MB_USERICON;
					MessageBoxIndirect(&mbp);
					break;
				}
			
			}
			break;
		}
	
	}

	return FALSE;
}

void CreateKey(HWND hWnd)
{
	char szName[255] 				= "";
	char szActivationKey[255] 		= "";
	char szAuthorizationKey[255]	 	= "";
	char lpBig2ByteOut[255] 			= "";
	char CipherOut[255] 				= "";
	
	BYTE * Md5Digest;
	BYTE *SHA1Digest;
	BYTE *HavalDigest;
	big m,d,n,c;
	miracl * mip;

	// Initilize Miracl
	mip = mirsys(5000,16);

	// Initilize big nums
	m 	= mirvar(0);
	d 	= mirvar(0);
	n 	= mirvar(0);
	c 	= mirvar(0);
	
	// Disable Generate Button
	EnableWindow(GetDlgItem(hWnd,IDC_BUTTON_GENERATE),FALSE);

	srand(GetTickCount());

	// Check length of name
	if (GetWindowTextLength(GetDlgItem(hWnd,IDC_EDIT_NAME)) > 254)
	{
		SetDlgItemText(hWnd,IDC_EDIT_AUTHORIZATION,"WTF Your Name Is Way");
		SetDlgItemText(hWnd,IDC_EDIT_ACTIVATION,"Too Fucking Long......");
		EnableWindow(GetDlgItem(hWnd,IDC_BUTTON_GENERATE),TRUE);
		return;
	}
	
	// Get name
	if (GetDlgItemText(hWnd,IDC_EDIT_NAME,szName,sizeof(szName)) == 0)
	{
		SetDlgItemText(hWnd,IDC_EDIT_ACTIVATION,"Enter your name......");
		return;
	}
	
	// Hash Name with MD5
	MD5Init();
	MD5Update(szName,strlen(szName));
	Md5Digest = MD5Final();

	// Hash MD5 of Name with SHA1
	SHA1Init();
	SHA1Update(Md5Digest, 16);
	SHA1Digest = SHA1Final();
	
	//Hash SHA1 of MD5 Digest with haval
	HavalInit(20, 0x410024);
	HavalUpdate(SHA1Digest, 20);
	HavalDigest = HavalFinal();

	// Haval Digest to big 
	bytes_to_big(8,HavalDigest,m);

	// Generate RSA Keys where N > M so that decryption is possible
	GenerateRSAKeys(n,d,m);

	// Activation Key
	big_to_bytes(sizeof(lpBig2ByteOut),n,lpBig2ByteOut,FALSE);
	XTEAInit("93C64631289064F9", 16);
	XTEAEncrypt(lpBig2ByteOut,CipherOut);
	Base64Encode(CipherOut,8,szActivationKey);
	
	//Authorization Key
	powmod(m,d,n,c);
	big_to_bytes(sizeof(lpBig2ByteOut),c,lpBig2ByteOut,FALSE);
	BlowfishInit("93C64631289064F9",16);
	BlowfishEncrypt(lpBig2ByteOut,CipherOut);
	Base64Encode(CipherOut,8,szAuthorizationKey);

	// Display Keys
	SetDlgItemText(hWnd,IDC_EDIT_ACTIVATION,szActivationKey);
	SetDlgItemText(hWnd,IDC_EDIT_AUTHORIZATION,szAuthorizationKey);
	
	// Enable Generate Button
	EnableWindow(GetDlgItem(hWnd,IDC_BUTTON_GENERATE),TRUE);

	// Kill big nums
	mirkill(m);
	mirkill(d);
	mirkill(n);
	mirkill(c);
	mirexit();

	return;
}

void GenerateRSAKeys(big N,big D,big M)
{
	big p,q,n,d,e,t,p1,q1,phi;
	
	p 	= mirvar(0);
	q	= mirvar(0);
	n 	= mirvar(0);
	d 	= mirvar(0);
	e 	= mirvar(0);
	t 	= mirvar(0);
	p1	= mirvar(0);
	q1 	= mirvar(0);
	phi 	= mirvar(0);

	irand(rand());

	do 
	{
	New:
		bigbits(32,p);
		if (subdivisible(p,2)) incr(p,1,p);
		while (!isprime(p)) incr(p,2,p);

		bigbits(32,q);
		if (subdivisible(q,2)) incr(q,1,q);
		while (!isprime(q)) incr(q,2,q);

		multiply(p,q,n);      /* n=p.q */

		if (compare(n,M)  != 1) goto New;

		lgconv(65537L,e);
		decr(p,1,p1);
		decr(q,1,q1);
		multiply(p1,q1,phi);  /* phi =(p-1)*(q-1) */
	} while (xgcd(e,phi,d,d,t)!=1);

	copy(n,N);
	copy(d,D);

	mirkill(p);
	mirkill(q);
	mirkill(n);
	mirkill(d);
	mirkill(e);
	mirkill(t);
	mirkill(p1);
	mirkill(q1);
	mirkill(phi);
}
