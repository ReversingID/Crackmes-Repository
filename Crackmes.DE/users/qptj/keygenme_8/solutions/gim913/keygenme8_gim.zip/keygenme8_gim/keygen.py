#!/usr/bin/env python
#
# Keygenme 8 / qpt^J
#
# gim913 at gmail dot com

import md2
from tblz import * 

# array module is C-dependent -> machine dependend ergo crap
# struct module doesn't support arrays
def foo(a, b):
    r = 0
    for i in xrange(b):
        r |= (a[i] << (i << 3))
    return r

def fooz(a, b):
    return [foo(a[i:i+b], b) for i in xrange(0, len(a), b)]

def bar(a):
    return reduce(lambda a,b: a^b, [1 if (a & (1 << i)) else 0 for i in xrange(63, -1, -1)])

x = raw_input("username: ")

a = fooz(md2.md2(x), 4)
b = (a[0] << 32) | (a[1])
c = fooz(tbl512, 8)

print "pass: %016X" % sum(map(lambda a: a[1]<<a[0], zip(xrange(63,-1,-1), [bar(e & b) for e in c] )))

