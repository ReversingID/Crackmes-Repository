
void memrev(char *n, int l)
{
	int a = 0;
	for (int i = 0; i < l/2; i++)
	{
		a = n[l-i];
		n[l-i] = n[i];
		n[i] = a;
	}
}

void Generate(HWND hWnd)
{
	char name[50], tname[50], serial[50];
	ZeroMemory(name,50);
	unsigned long d[2] = {0,0};
	unsigned long w[5] = {0x18,0x400,0x32,0,0}; // Checksum start values
	GetDlgItemText(hWnd,IDC_NAME,name,50);
	int len = strlen(name), x = 0;
	if(len < 5)
	{
		SetDlgItemText(hWnd,IDC_SERIAL,"Need longer name!");
	}
	else
	{

	//First, create checksums, w[0] and w[1]
	for (int i = 0; i < len; i++)
	{
		w[0] = ((name[i] + 0x56B) ^ 0x890428) + w[0];
		
		if(len <= 9){
			w[1] = ((((name[3] + len) ^ 0x54) ^ 0x25D) * w[0]) + w[1];}
		else if(len > 9){
			w[0] = ((((name[3] + len) ^ 0x54) ^ 0x25D) * w[1]) + w[0];}

		w[1] = ((name[i] + 0x56B) * 0x1024) + w[1];
	}

	//Second, create checksum, w[2]
	for (int j = 0; j < 5; j++)
	{
		w[2] = name[5-j] + w[2] + 0x134A;
		strrev(name);
	}
    //Third, modify checksums, w[0] and w[3]
	memcpy(tname + 1, name, sizeof(name));
	tname[0] = 0;
	for (int k = 5, l = 2; k > 0; k--, l++)
	{
		w[2] = w[2] + 0x134A + tname[1-x];
		w[0] = ((tname[l-x] + 0x23) * 602) + w[0];
	
		if(k < 4 && l > 2){
			memrev(tname,len);
			x^=1;
		}
	}
	//Fourth, create serial from checksums(w[0],w[1],w[2])
	strrev(name);
	d[0] = (w[0] + 0x3C) ^ (0x1337 - name[2]);
	d[1] = (w[1] + w[2]) ^ (0x18 - name[5]);
	wsprintf(serial,"RHM-%d%d",d[0],d[1]);
	SetDlgItemText(hWnd,IDC_SERIAL,serial);
	}

}