using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace EAXCrackme
{
    public partial class Keygen : Form
    {
        public Keygen()
        {
            InitializeComponent();
        }
        private void UpdateSerial(object sender, EventArgs e)
        {
            if (NameTextBox.Text != "" && NameTextBox.Text.Length> 1)
            {
                SerialTextBox.Text = CalculateSerial(NameTextBox.Text);
            }
        }
        private string CalculateSerial(string name)
        {
            try
            {
                Int32 EBX = 0x50;
                Int32 ESI = 0x4;
                int length = name.Length - 1;
                for (int i = 1; i < name.Length; i++)
                {
                    char CurrentChar = Char.ToUpper(name[i]);
                    if (Char.IsLetter(CurrentChar))
                    {
                        switch (CurrentChar)
                        {
                            case 'A':
                                EBX += ESI;
                                length -= 1;
                                break;
                            case 'B':
                                EBX ^= ESI;
                                break;
                            case 'C':
                                EBX -= ESI;
                                break;
                            case 'D':
                                EBX *= ESI;
                                break;
                            case 'E':
                                ESI += 0xd65e;
                                EBX = EBX / ESI;
                                break;
                            case 'F':
                                EBX ^= ESI;
                                break;
                            case 'G':
                                EBX += ESI;
                                length -= 1;
                                break;
                            case 'H':
                                EBX -= ESI;
                                break;
                            case 'I':
                                ESI *= 2;
                                EBX ^= ESI;
                                break;
                            case 'J':
                                ESI *= EBX;
                                EBX -= ESI;
                                break;
                            case 'K':
                                EBX += ESI;
                                length -= 1;
                                break;
                            case 'L':
                                ESI += 0x400;
                                EBX *= ESI;
                                break;
                            case 'M':
                                ESI *= EBX;
                                EBX += ESI;
                                length -= 1;
                                break;
                            case 'N':
                                float floatEBX = EBX;
                                float floatESI = ESI;
                                floatESI *= 5.5F;
                                floatEBX /= floatESI;
                                EBX = (int)Math.Floor(floatEBX);
                                break;
                            case 'O':
                                ESI *= EBX;
                                EBX += ESI;
                                length -= 1;
                                break;
                            case 'P':
                                EBX ^= ESI;
                                break;
                            case 'Q':
                                EBX *= ESI;
                                break;
                            case 'R':
                                ESI *= ESI;
                                EBX *= ESI;
                                break;
                            case 'S':
                                ESI *= EBX;
                                EBX += ESI;
                                length -= 1;
                                break;
                            case 'T':
                                EBX -= ESI;
                                break;
                            case 'U':
                                EBX = EBX / ESI;
                                break;
                            case 'V':
                                ESI *= ESI;
                                EBX ^= ESI;
                                break;
                            case 'W':
                                ESI *= EBX;
                                EBX *= ESI;
                                break;
                            case 'X':
                                ESI *= ESI;
                                EBX -= ESI;
                                break;
                            case 'Z':
                                EBX = EBX * EBX + ESI * EBX * EBX;
                                break;
                            default:
                                //like this'll ever happen
                                throw new Exception();
                        }
                    }
                }
                return (EBX + ESI + 0x400).ToString();
            }
            catch
            {
                return "ERROR!";
            }
        }
    }
}