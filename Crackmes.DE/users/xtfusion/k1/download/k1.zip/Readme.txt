
                .ii.           .ii.               
               ;MMM9           bMMMi              
             vMMMMZ.           .0MMM#:            
            .#MMMM6    0MMM0    AMMMMB            
              i@MMMMMMMb:iiWMMMMMMMMi             
                ;@MMMM.     iMMM@Bi               
,o;  t2.   6boYi,  bMo       AMZ  :vn908,         
:MMWWMM. 7MMMMMMMMzM9  CM@@;  EM9MMMMMMMMY        
:MMMMM@  @Mt.iv1MMMX   iIoo,   AMMM1Yi.SMM.       
:@MMMM$.@Ei#@MMM. M,           :M ,M@@MMc         
:@MX 6@.MM@  0W  .b.  :iiii;:   U i#v             
:Mo  $M @M6Y6i  0MXXIEMMMMMMMbtc7Mv MM.     (MOO)      
:M0  MM @t Mv   0MBW@E.   . .E#QWMo ;MM           
:M$   t$;z#,    ZMM..MM1...2MM..B;    QM;         
:M#   ;MX6M      :MQ,.,.....,.,0M     cME         
:M#   .M@i         Z@2o9EE8I1o@z :.     MM        
:M$        .bo      .$$$$$BWWW   MMo    IMA       
:MM.      zMM7                    zMM:   @Mi      
..MMn   iMM;                        WMQ   nMz     
  6MM00@M0                           MM   ,MQ     
   .MMMMMS                        .nX$A   :M9     
        M$                       6@W0     .M9     
      i$7                      ;M8      .6MMz     
      QM.                     BMMMv YI#MMMM:      
      6M,                   iMMMMMMMMMI.M0        
      9M.                    XXvv7      MQ        
      IMM@@@@@@@@@@@@@@@@@@@0tccc7IE0Q0BM$        
  
Created by: xtFusion

Sorry for my spelling

Here is my First crackme for crackmes.de
i hope you all injoy this one.

oh and sorry for the way i coded!
also i wanted to pack the file in UPX
but i was scared that someone could not
unpack it? (i feel so sorry for the one who does not know :-) )

Send me your tut to xtfusion@gmail.com

(well i have not much to say so buy!)