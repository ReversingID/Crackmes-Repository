There are 3 files in the zip archive:

Kegen: (VS9 project) the keygen source files
tutorial.txt: the tutorial
Readme.txt : this file

If you having any problem please feel free to contact with me (egogg@163.com). Thank you for your patients. Having a nice day!