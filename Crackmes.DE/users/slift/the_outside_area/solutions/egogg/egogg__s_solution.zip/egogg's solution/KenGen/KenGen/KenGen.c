// KenGen.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

typedef unsigned char BYTE;
typedef unsigned short WORD;
typedef unsigned int DWORD;

WORD target[24] = 
{
    0x86D9,
    0x2B35,
    0xA8D1,
    0x362A,
    0x06DA,
    0xCE34,
    0x3ADA,
    0xBD28,
    0x19D8,
    0x2E3F,
    0x26DC,
    0x3833,
    0x7ECA,
    0x8034,
    0xE7DD,
    0xED39,
    0x34D3,
    0x6D31,
    0x71DA,
    0xAC31,
    0x75D7,
    0x671B,
    0x56D9,
    0xB43B
};

#define MX (z>>5^y<<2) + (y>>3^z<<4)^(sum^y) + (k[p&3^e]^z);

long btea(long* v, long n, long* k);
long key[4] = {0x7746D962, 0x82F42CB6, 0x980B8641, 0xFD86B77E};
long SUMS[] = 
{
    0xd49f850f,
    0x7cf2c5c0,
    0x131508e5,
    0xfdd46def,
    0x646d3867,
    0xbb775017,
    0x85998c16,
    0xeaf9f178,
    0xe9468737,
    0x68eafda3,
    0xc254b5ec,
    0x51b0397e,
    0x760970dc,
    0x6d1c7552,
    0x5ac33f09,
    0xc3e3accd,
    0xa7c8a37b,
    0x6e67bb27,
    0xb94a9dda
};
#define ROUNDS  (sizeof(SUMS) / sizeof(SUMS[0]))


/* encode function */

WORD Encode(WORD code);
WORD Decode(WORD code);

/* map functions */

WORD map_type1(WORD code, WORD const1, BYTE shift, WORD const2);
WORD map_type2(WORD code, WORD const1, BYTE shift1, BYTE shift2, WORD const2);
WORD map_type3(WORD code, WORD const1, BYTE shift1, BYTE shift2);
WORD map_type4(WORD code, WORD const1);
WORD map_type5(WORD code, WORD const1, BYTE shift, WORD const2);
WORD map_type6(WORD code, WORD const1, BYTE shift1, BYTE shift2, BYTE shift3);
WORD map_type7(WORD code, WORD const1, BYTE shift1, BYTE shift2, BYTE shift3);

#define MAP_0_0(code)   map_type1((code), 0x2113, 0x09, 0x0F7B)
#define MAP_0_10(code)  map_type2((code), 0x5771, 0x01, 0x09, 0x0BB6)
#define MAP_0_20(code)  map_type3((code), 0xAA9D, 0x0B, 0x0A)

#define MAP_2_2(code)   map_type1((code), 0xF311, 0x0D, 0x21B4)
#define MAP_2_12(code)  map_type1((code), 0x6413, 0x0B, 0x1477)
#define MAP_2_22(code)  map_type4((code), 0x23D1)

#define MAP_4_4(code)   map_type5((code), 0x81EF, 0x0B, 0x0A9D)
#define MAP_4_14(code)  map_type1((code), 0x9EF9, 0x0A, 0x0671)
#define MAP_4_24(code)  map_type4((code), 0x0951)

#define MAP_6_6(code)   map_type1((code), 0xC349, 0x0D, 0x29F3)
#define MAP_6_16(code)  map_type6((code), 0x0733, 0x07, 0x05, 0x03)
#define MAP_6_26(code)  map_type4((code), 0x11BA)

#define MAP_8_8(code)   map_type4((code), 0x0C65)
#define MAP_8_18(code)  map_type4((code), 0x1d15)
#define MAP_8_28(code)  map_type2((code), 0x52C7, 0x02, 0x0A, 0x317C)

#define MAP_A_A(code)   map_type2((code), 0x61F7, 0x02, 0x08, 0x0A74)
#define MAP_A_1A(code)  map_type1((code), 0x8EA9, 0x0E, 0x72D9)
#define MAP_A_2A(code)  map_type1((code), 0xF91D, 0x0E, 0x41C5)

#define MAP_C_C(code)   map_type4((code), 0x0C49)
#define MAP_C_1C(code)  map_type1((code), 0x1251, 0x08, 0x0DFA)
#define MAP_C_2C(code)  map_type1((code), 0xEAF3, 0x0C, 0x116F)

#define MAP_E_E(code)   map_type1((code), 0x0E8D, 0x0A, 0x4660)
#define MAP_E_1E(code)  map_type1((code), 0x47C3, 0x0A, 0x0E45)
#define MAP_E_2E(code)  map_type7((code), 0x1F27, 0x0A, 0x05, 0x08)

int _tmain(int argc, _TCHAR* argv[])
{
    long value[4] = {0x34333231, 0x38373635, 0x32313039, 0x36353433};
    int i;
    WORD code;

    for(i = 0; i < 12; i++)
    {
        *((DWORD *)target + i) ^= 0xA5CC1A27;   
    }

    for(i = 0; i < 24; i++)
    {
        target[i] = Decode(target[i]);
    }

    /* search for the keys */
    
    for(code = 0; code != 0xFFFF; code++)
    {
        if(MAP_0_0(code) == target[0] &&
           MAP_0_10(code) == target[0x8] &&
           MAP_0_20(code) == target[0x10])
        {
            *((WORD *)value) = code;
            
            break;
        }
    }
    
    for(code = 0; code != 0xFFFF; code++)
    {
        if(MAP_2_2(code) == target[1] &&
           MAP_2_12(code) == target[0x9] &&
           MAP_2_22(code) == target[0x11])
        {
            *((WORD *)value + 1) = code;
            
            break;
        }
    }

    for(code = 0; code != 0xFFFF; code++)
    {
        if(MAP_4_4(code) == target[2] &&
           MAP_4_14(code) == target[0xA] &&
           MAP_4_24(code) == target[0x12])
        {
            *((WORD *)value + 2) = code;
            
            break;
        }
    }

    for(code = 0; code != 0xFFFF; code++)
    {
        if(MAP_6_6(code) == target[3] &&
           MAP_6_16(code) == target[0xB] &&
           MAP_6_26(code) == target[0x13])
        {
            *((WORD *)value + 3) = code;
            
            break;
        }
    }

    for(code = 0; code != 0xFFFF; code++)
    {
        if(MAP_8_8(code) == target[4] &&
           MAP_8_18(code) == target[0xC] &&
           MAP_8_28(code) == target[0x14])
        {
            *((WORD *)value + 4) = code;
            
            break;
        }
    }

    for(code = 0; code != 0xFFFF; code++)
    {
        if(MAP_A_A(code) == target[5] &&
           MAP_A_1A(code) == target[0xD] &&
           MAP_A_2A(code) == target[0x15])
        {
            *((WORD *)value + 5) = code;
            
            break;
        }
    }

    for(code = 0; code != 0xFFFF; code++)
    {
        if(MAP_C_C(code) == target[6] &&
           MAP_C_1C(code) == target[0xE] &&
           MAP_C_2C(code) == target[0x16])
        {
            *((WORD *)value + 6) = code;
            
            break;
        }
    }

    for(code = 0; code != 0xFFFF; code++)
    {
        if(MAP_E_E(code) == target[7] &&
           MAP_E_1E(code) == target[0xF] &&
           MAP_E_2E(code) == target[0x17])
        {
            *((WORD *)value + 7) = code;
            
            break;
        }
    }

    btea(value, -4, key);

    for(i = 0; i < 16; i++)
    {
        printf("%c", *((unsigned char *)value + i));
    }
    printf("\n");

	return 0;
}

long btea(long* v, long n, long* k) 
{
    unsigned long z=v[n-1], y=v[0], sum=0, e; 
    long p, q ;
    if (n > 1) 
    {
        /* Coding Part */

        //q = 6 + 52/n;
        q = ROUNDS;
        while (q > 0)
        {
            //sum += DELTA;
            sum = SUMS[ROUNDS - q];
            e = (sum >> 2) & 3;
            for (p=0; p<n-1; p++) 
            {
                y = v[p+1], z = v[p] += MX;
            }
            
            y = v[0];
            z = v[n-1] += MX;

            q--;
        }

        return 0 ; 
    } 
    else if (n < -1) 
    { 
        /* Decoding Part */
        
        n = -n;
        //q = 6 + 52/n;
        //sum = q*DELTA ;
        q = ROUNDS;
        while (q > 0) 
        {
            sum = SUMS[q - 1];
            
            e = (sum >> 2) & 3;
            for (p=n-1; p>0; p--) z = v[p-1], y = v[p] -= MX;
            z = v[n-1];
            y = v[0] -= MX;
            
            q--;
        }
        
        return 0;
    }

    return 1;
}

WORD Encode(WORD code)
{
    WORD value;

    value = 0;
    _asm
    {
        push    eax

        mov     ax, code
        ror     ax, 0x08
        not     ax

        mov     value, ax

        pop     eax
    }

    return value;
}

WORD Decode(WORD code)
{
    WORD value;

    value = 0;
    _asm
    {
        push    eax

        mov     ax, code
        not     ax
        ror     ax, 0x08

        mov     value, ax

        pop     eax
    }

    return value;
}

WORD map_type1(WORD code, WORD const1, BYTE shift, WORD const2)
{
    WORD value;
    
    value = 0;
    _asm
    {
        push    eax
        push    ebx
        push    ecx
        push    edx

        movzx   edx, code
        movzx   eax, dx
        imul    eax, const1
        shr     eax, 0x10;
        mov     ebx, eax
        mov     cl, shift
        shr     bx, cl
        mov     ax, bx
        imul    ax, const2;
        sub     dx, ax
        mov     value, dx

        pop     edx
        pop     ecx
        pop     ebx
        pop     eax
    }

    return value;
}

WORD map_type2(WORD code, WORD const1, BYTE shift1, BYTE shift2, WORD const2)
{
    WORD value;
    value = 0;

    _asm
    {
        push    eax
        push    ebx
        push    ecx
        push    edx

        movzx   edx, code
        mov     eax, edx
        mov     cl, shift1
        shr     ax, cl
        movzx   eax, ax
        imul    eax, const1
        shr     eax, 0x10
        mov     ebx, eax
        mov     cl, shift2
        shr     bx, cl
        mov     ax, bx
        imul    ax, const2
        sub     dx, ax
        mov     value, dx

        pop     edx
        pop     ecx
        pop     ebx
        pop     eax
    }

    return value;
}

WORD map_type3(WORD code, WORD const1, BYTE shift1, BYTE shift2)
{
    WORD value;
    value = 0;

    _asm
    {
        push    eax
        push    ebx
        push    edx

        movzx   edx, code
        movzx   eax, dx
        imul    eax, const1
        shr     eax, 0x10
        mov     ebx, eax
        mov     cl, shift1
        shr     bx, cl
        movzx   eax, bx
        add     eax, eax
        add     ax, bx
        mov     cl, shift2
        shl     eax, cl
        add     ax, bx
        sub     dx, ax
        mov     value, dx
        
        pop     edx
        pop     ebx
        pop     eax
    }

    return value;
}

WORD map_type4(WORD code, WORD const1)
{
    WORD value;

    value = 0;
    _asm
    {
        push    eax
        push    ebx
        push    edx

        movzx   edx, code
        mov     eax, edx
        mov     edx, 0
        movzx   ebx, const1
        div     bx
        mov     value, dx

        pop     edx
        pop     ebx
        pop     eax
    }

    return value;
}

WORD map_type5(WORD code, WORD const1, BYTE shift, WORD const2)
{
    WORD value;

    value = 0;
    _asm
    {
        push    eax
        push    ebx
        push    ecx
        push    edx

        movzx   ebx, code
        movzx   eax, bx
        imul    eax, const1
        mov     edx, eax
        shr     edx, 0x10
        mov     eax, ebx
        sub     ax, dx
        shr     ax, 1
        add     eax, edx
        mov     edx, eax
        mov     cl, shift
        shr     dx, cl
        mov     ax, dx
        imul    ax, const2
        sub     bx, ax
        mov     value, bx

        pop     edx
        pop     ecx
        pop     ebx
        pop     eax
    }

    return value;
}

WORD map_type6(WORD code, WORD const1, BYTE shift1, BYTE shift2, BYTE shift3)
{
    WORD value;

    value = 0;
    _asm
    {
        push    eax
        push    ebx
        push    ecx
        push    edx

        movzx   ebx, code
        movzx   eax, bx
        imul    eax, const1
        mov     edx, eax
        shr     edx, 0x10
        mov     eax, ebx
        sub     ax, dx
        shr     ax, 1
        add     eax, edx
        mov     edx, eax
        mov     cl, shift1
        shr     dx, cl
        movzx   eax, dx
        mov     cl, shift2
        shl     eax, cl
        sub     ax, dx
        mov     cl, shift3
        shl     eax, cl
        add     ax, dx
        sub     bx, ax
        mov     value, bx

        pop     edx
        pop     ecx
        pop     ebx
        pop     eax
    }

    return value;
}

WORD map_type7(WORD code, WORD const1, BYTE shift1, BYTE shift2, BYTE shift3)
{
    WORD value;

    value = 0;
    _asm
    {
        push    eax
        push    ebx
        push    ecx
        push    edx

        movzx   ebx, code
        movzx   eax, bx
        imul    eax, 0x1F27;const1
        shr     eax, 0x10
        mov     edx, eax
        mov     cl, shift1
        shr     dx, cl
        mov     value, dx
        movzx   eax, dx
        mov     edx, eax
        mov     cl, shift2
        shl     edx, cl
        add     dx, value
        mov     eax, edx
        mov     cl, shift3
        shl     eax, cl
        sub     ax, dx
        sub     bx, ax
        mov     value, bx

        pop     edx
        pop     ecx
        pop     ebx
        pop     eax
    }

    return value;
}