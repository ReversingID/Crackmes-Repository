#!/usr/bin/python

import sys
import warnings
from numpy import uint32
import wolframalpha

warnings.filterwarnings("ignore")

if len(sys.argv) < 3:
    print 'usage: %s your_name wolfram_appid [#_of_serials]' % sys.argv[0]
    print sys.exit(1)

name = sys.argv[1]
app_id = sys.argv[2]

count = 1
if len(sys.argv) >= 4:
    count = int(sys.argv[3])

#app_id = 'AE9QXL-X9A25GJ9TX'
client = wolframalpha.Client(app_id)

c1 = 150364
c2 = 115524
p = 0xF2A7
q = 0x3CA9D

n = uint32(0x7E4C9E32)
for _ in name:
    n *= uint32(ord(_))

sols = []
for i in range(1, p):
    res = client.query('MultiplicativeOrder[%d, %d, {%d}]' % (2, q, i))
    o = int(next(res.results).text)
    e = (c1 * n + c2 * i) % (q - 1)
    for j in range(1, p):
        if (e * j) % (q - 1) == o:
            sols.append((i, j, o))
            break
    if len(sols) >= count:
        break

print 'SERIALS:'
for s in sols:
    l = s[0]
    R = s[1]
    res = client.query('PowerMod[%d, -1, %d]' % (R, p))
    r = int(next(res.results).text)
    print '%04X-%04X' % (l, r)
