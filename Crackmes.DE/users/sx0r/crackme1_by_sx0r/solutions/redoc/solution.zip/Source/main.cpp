#include "main.h"
#include <Commctrl.h>
#include "MD5/md5.h"
extern "C" {
	#include "MIRACL/miracl.h"
}

// global vars
HWND g_hDlg;

//----------------------------------
bool Generate (HWND hDlg)
{
	DWORD i;
	MD5_CTX	ctx;
	unsigned char md5_hash[16], rewrite[5] = {0x53 ,0x21 ,0x78 ,0x30 ,0x72};
	char szName[NAME_MAX+1] = {0}, szSerial[64] = {0};

	GetDlgItemText (hDlg, IDC_EDIT_NAME, szName, sizeof(szName)-1);
	for (i=0; i<strlen (szName); i++)
		szName[i] = szName[i] - 1;

	MD5Init (&ctx);
	MD5Update (&ctx, (unsigned char*)szName, strlen(szName));
	MD5Final (md5_hash, &ctx);

	for (i=0; i<5; i++)
		md5_hash[i] = rewrite[i];

	//============================================
	// RSA scheme:
	//	C = M^E mod N
	//	M = C^D mod N

	// M = serial
	// C = md5_hash
	// E = 0x10001
	// N = 0xAD08D0361CC7FE8D1D3EAC5A68394C95
	// D = 0x1A61A59D1A764390EFBDA4459B5CE401
	//============================================

	miracl *mip;
	big M, C, E, D, N;

	mip = mirsys (300, 16);		// Initialize MIRACL library
	if (mip == 0) return false;
	M = mirvar(0); C = mirvar(0); D = mirvar(0); N = mirvar(0);		// E = mirvar(0x10001)
	mip->IOBASE = 16;

	cinstr (N, "AD08D0361CC7FE8D1D3EAC5A68394C95");
	cinstr (D, "1A61A59D1A764390EFBDA4459B5CE401");
	bytes_to_big (16, (char*)md5_hash, C);

 	powmod (C, D, N, M);	//	M = C^D mod N
	cotstr (M, szSerial);
	SetDlgItemText (hDlg, IDC_EDIT_SERIAL, szSerial);	// result !

	mirexit ();
	return true;
}
//----------------------------------
bool Test (HWND hDlg)
{
	HWND hWndCrackme, hCtrl;
	char szName[256] = {0}, szSerial[64] = {0};

	if (!GetDlgItemText (hDlg, IDC_EDIT_NAME, szName, sizeof(szName)))
		return false;
	if (!GetDlgItemText (hDlg, IDC_EDIT_SERIAL, szSerial, sizeof(szSerial)))
		return false;

	hWndCrackme = FindWindow (0, "Crackme#1 by S!x0r");
	if (hWndCrackme == 0) {
		ShellExecute (0, 0, "Crackme#1.exe", 0, 0, SW_SHOWNORMAL);
		Sleep (200);
		hWndCrackme = FindWindow (0, "Crackme#1 by S!x0r");
	}
	if (hWndCrackme == 0)
		{MSG ("Can't find crackme window"); return false;}

	hCtrl = GetDlgItem (hWndCrackme, 101);		// set name
	SendMessage (hCtrl, WM_SETTEXT, 0, (LPARAM)szName);
	hCtrl = GetDlgItem (hWndCrackme, 102);		// set serial
	SendMessage (hCtrl, WM_SETTEXT, 0, (LPARAM)szSerial);
	hCtrl = GetDlgItem (hWndCrackme, 103);		// Register button
	PostMessage (hWndCrackme, WM_COMMAND, 103, (LPARAM)hCtrl);

	return true;
}
//----------------------------------
BOOL CALLBACK DialogProc(HWND  hwndDlg, UINT  uMsg, WPARAM  wParam, LPARAM  lParam )
{
	switch (uMsg)
	{
	case WM_INITDIALOG:
		g_hDlg = hwndDlg;
		#ifdef NAME_MAX
		SendDlgItemMessage (hwndDlg, IDC_EDIT_NAME, EM_SETLIMITTEXT, NAME_MAX, 0);
		#endif
		HICON hIcon;	// dialog icon
		if (hIcon = LoadIcon(GetModuleHandle(0), MAKEINTRESOURCE(IDI_ICON1))) {
			SendMessage(hwndDlg, WM_SETICON, TRUE, (LPARAM)hIcon);
			SetClassLong (hwndDlg, GCL_HICON, (LONG)hIcon);
		}
		return TRUE;

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDC_BUTTON_GENERATE:
			Generate(hwndDlg); return TRUE;
 		case IDC_BUTTON_TEST:
 			Test (hwndDlg); return TRUE;
		case IDCANCEL:
			EndDialog (hwndDlg, 0); return TRUE;
		}
		break;
	}
	return FALSE;
}
//----------------------------------
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	InitCommonControls();
	DialogBox (hInstance, MAKEINTRESOURCE(IDD_DIALOG1), 0, DialogProc);
	return 0;
}
