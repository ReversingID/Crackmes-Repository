#undef UNICODE
#undef _UNICODE
#include <Windows.h>                                                                                                                         
#include "resource.h"

#define APP_NAME	"S!x0r's Crackme#1 - Keygen"
#define MSG(x)		MessageBox (g_hDlg,x,APP_NAME,0)
#define NAME_MAX	255