========================== 
 KeyFileME#1 by l0calh0st
   Difficulty : 2-3/10
   Coded with MASM 9.0
=========================

Your goal is code a working KeyFile Generator.
Patching is lame..
Send your Keyfile Generator along with a short 
tut to crackmes.de if you happen to solve it

I hope you Enjoy it...


Gr33ts : Look in the Target ;)

