==================================
l0calh0st's KeygenME#2	
==================================
This is my second KeygenME.It's very 
much different from the the first one.

There are some anti debugger tricks
and algo doesn't contain any crypto.
Study the algo and write a keygen along
 with a nicely written to help the noobs.

The keygen should generate many serials
 for a single name.

Good Luck!

IMPORTANT NOTE : Unzip the files to a
 folder before running the keygen.

P.S: Special thanks to Taliespin for
testing and reporting errors
	
=================================
Gr33tz :
=================================
Ank83, HMX0101, Ox87k, moofy,haggar,
 ScR1pT_, Krizma, Mods and members of 
crackme.de and YOU!!!

__________________________________
Signed by l0calh0st
11 April 2006
__________________________________