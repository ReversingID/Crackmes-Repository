#include <stdio.h>
#include <windows.h>

int main()
{
    char name[256]="";
    printf("name: ");
    gets(name);
    int len=strlen(name);
    for(int i=0; i<len; i++)
    {
        name[i]^=0x19;
        name[i]++;
    }
    printf("code: %s\n", name);
    system("pause");
    return 0;
}
