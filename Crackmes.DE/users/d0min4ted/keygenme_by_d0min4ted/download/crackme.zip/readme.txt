rules: 
no reflector
no patching
no bruteforce
no selfkeygen

have fun 
-D0min4ted
