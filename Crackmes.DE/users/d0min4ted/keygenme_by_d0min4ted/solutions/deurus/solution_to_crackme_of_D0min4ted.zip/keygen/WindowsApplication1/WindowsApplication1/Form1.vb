﻿Imports System
Imports Microsoft.VisualBasic

Public Class Form1
    Private Sub label2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles label2.TextChanged
        If (Me.label2.Text.Length < 4) Then
            Label1.Text = "Name min 4 characters"
            TextBox2.Text = ""
        Else
            Label1.Text = ""
            Dim text As String = Me.label2.Text
            Dim str3 As String = ""
            Dim chArray As Char() = [text].ToCharArray
            Dim ch As Char
            'saca codigo ascii de cada letra del nombre
            For Each ch In [text]
                Dim num2 As Integer = Convert.ToInt32(ch)
                Dim str4 As String = String.Format("{0:X}", num2)
                str3 = (str3 & str4)
            Next
            Dim array As Char() = str3.ToCharArray
            array.Reverse(array)
            Dim str5 As New String(array)
            If (str5.Length > 9) Then
                str5 = str5.Remove(9, (str5.Length - 9))
            End If
            Try
                Dim num4 As Decimal = Convert.ToDecimal(Convert.ToInt32(str5))
                Dim num5 As Double = Math.Pow(CDbl(Me.label2.Text.Length), 3)
                Dim num6 As Decimal = Math.Round(CDec((num4 * Convert.ToDecimal(num5))), 0)
                TextBox2.Text = num6
            Catch
                Label1.Text = "User not valid, try again" 'Exception with some chars
                TextBox2.Text = ""
            End Try
        End If
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Label1.Text = ""
    End Sub
End Class
