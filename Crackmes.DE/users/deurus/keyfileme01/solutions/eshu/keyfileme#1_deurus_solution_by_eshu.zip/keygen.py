# NOTE! Needs Python3.x to run

from datetime import date
from string import digits
import random

tt = date.today().timetuple()
year = tt.tm_year
month = tt.tm_mon
day = tt.tm_mday

min_serial = '0000000000'
max_serial = '9999999999'

part1_xormagic = int('85D0', 16)
part3_xormagic = int('10106', 16)

month_xor_check = int('FDE8', 16)

checkval_min = 9000.0
checkval_max = 10000.0

def make_random_serial(num):
    s = ''
    rnd = random.Random()

    for i in range(num):
        s += digits[rnd.randint(0,9)]

    return s

def compute_valid_hash():
    serial = make_random_serial(10)
    tries = 1

    while True:
        serial_part1 = int(serial[:5])
        serial_part3 = int(serial[5:])

        serial_part1_xor = serial_part1 ^ part1_xormagic
        serial_part3_xor = serial_part3 ^ part3_xormagic
        day_xor = (serial_part1_xor % 2) ^ day
        month_xor = (serial_part3_xor * 8) ^ month

        # Make sure month_xor is not zero, gives divbyzero error
        try:
            fcheckval = float((serial_part1_xor % month_xor) + serial_part3_xor)
        except:
            fcheckval = float(0)

        if (month_xor < month_xor_check) and (fcheckval > checkval_min) and (fcheckval < checkval_max):
            break

        if serial == max_serial:
            serial = min_serial
        else:
            serial = str(int(serial)+1)

        tries += 1

        # If we tried 10 million serials and still no result,
        # get some new random numbers and try again.

        if tries % 10000000 == 0:
            serial = make_random_serial(10)
            tries = 1

    return (serial_part1, serial_part3,
      fcheckval, serial_part1_xor, serial_part3_xor, day_xor, month_xor)

def main():
    valid = compute_valid_hash()

    garbage1 = make_random_serial(5)
    garbage2 = make_random_serial(5)

    correctserial = str(valid[0]) + garbage1 + str(valid[1]) + garbage2
    serialhash = '{}-{}-{}-{}-{}'.format(int(valid[2]), valid[3], valid[4], valid[5], valid[6])

    print('Serial: {}'.format(correctserial,))
    print('Hash: {}'.format(serialhash,))

if __name__ == '__main__':
    main()
