
import sys




def main ():
    filename = input('Enter your login so I give you your key: ')
    print ('Hello',filename)
    
    
    key=""  # initialisation 
    sa="3zYzaI1982Tv2FasgjkkjhkjlJt5Dpe32A"
    sb="HyukjsdfkjsdfnPQU5xWERY67345aq9nFyR"

    se="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    
    
    ##############################################
    ########           FIRST HALF 

    # 1 convert to upper case 
    filename = filename.upper()
    i = 0
    for c in filename : 
        index = se.index(c)
        if (i%2==0) :
            key += sa[index-1]
        else :
            key += sb[index-1]
        i+=1
    i -= 1  # the last adition should not be performed
    ###############################################
    ##                  Second HALF 
    key+="-"
    
    ebx = 0
    for c in filename : 
        eax = ord(c)  # 40117E movzx   eax, byte ptr [esi]
        #1/ xor with edx
        eax = eax ^ (i%2)    # 401181 xor     eax, edx
        
        #2/ Shift left
        eax = eax << 10  # shl     eax, 0Ah
        
        #3 / Xor with constant 
        eax = eax ^ 172937463 # xor     eax, 0A4ED0F7h
        
        #4 SUbtraction 
        eax -= 666  #sub     eax, 29Ah
        
        #5 accumulate 
        ebx +=eax
        
    # ebx is just a 32 bit tregister (just in case, we cut higher bits)
    ebx = ebx & 4294967295 # 4294967295 = FF|FF|FF|FF = 2^32-1 remember this unsigned number
    key+=str(ebx)    
        
        
    
    
    
    print ("Here is your key :",key)
    
    
    
    
    
if __name__ == '__main__':
    main()