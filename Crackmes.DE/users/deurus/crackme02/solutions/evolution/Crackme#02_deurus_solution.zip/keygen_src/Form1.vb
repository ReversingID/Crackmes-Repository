﻿Public Class Form1

    Private Sub cmdexit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdexit.Click
        End
    End Sub

    Private Sub cmdgen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdgen.Click
        Dim serial As String = ""
        Dim name As String = ""
        name = txtname.Text

        If Len(name) = 0 Then
            MsgBox("Insert a name at least!", vbCritical, "ERROR")
        Else

            serial = calcpersonalhash(name) & "-" & calcsha1(name) & "-" & calcmd5(name)
            txtpass.Text = serial
        End If

    End Sub
End Class
