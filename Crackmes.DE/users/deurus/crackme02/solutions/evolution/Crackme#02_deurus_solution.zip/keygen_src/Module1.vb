﻿Module Module1
    Function calcsha1(ByVal strtohash As String)

        Dim sha1Obj As New Security.Cryptography.SHA1CryptoServiceProvider
        Dim bytesToHash() As Byte = System.Text.Encoding.ASCII.GetBytes(strtohash)

        bytesToHash = sha1Obj.ComputeHash(bytesToHash)

        Dim strResult As String = ""

        For Each b As Byte In bytesToHash
            strResult += b.ToString("x2")
        Next

        Return Mid(strResult, 9, 10)
    End Function

    Function calcmd5(ByVal strtohash As String)

        Dim md5Obj As New Security.Cryptography.MD5CryptoServiceProvider
        Dim bytesToHash() As Byte = System.Text.Encoding.ASCII.GetBytes(strtohash)

        bytesToHash = md5Obj.ComputeHash(bytesToHash)

        Dim strResult As String = ""

        For Each b As Byte In bytesToHash
            strResult += b.ToString("x2")
        Next

        Return Mid(strResult, 8, 6)

    End Function

    Function calcpersonalhash(ByVal strtohash As String)

        Dim strresult As String = ""
        Dim key1 As Integer = &HF473
        Dim key2 As Integer = 0
        Dim partialchar As Byte = 0

        For i = 1 To Len(strtohash)
            key2 = (key1 >> 8) And &HFF
            key2 = key2 Xor Asc(Mid(strtohash, i, 1)) And &HFF
            strresult = strresult & Chr(key2)
            key1 += key2
            key2 = (key1 * &H6088) And &HFFFF
            key2 = (key2 + &HB87E) And &HFFFF
            key2 = (key2 + &HD5D6) And &HFFFF
            key1 = key2
        Next

        Return strresult

    End Function
End Module
