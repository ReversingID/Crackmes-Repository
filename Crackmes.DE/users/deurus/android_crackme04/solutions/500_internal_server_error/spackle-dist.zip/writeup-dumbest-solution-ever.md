My superdumb solution to the crackme was to modify the crackme activity's key checking code so it returns the generated key to me. (Hey,
this is my first attempt at a CrackMe, so don't hate on me for not actually reversing the key generation algorithm.)

First, I disassembled the existing CrackMe APK with APKTool. 

Then, I wrote a small wrapper to print out the result of the key generation:

```
package net.zhuoweizhang.spackle;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.text.*;

import android.widget.*;

import com.deurus.androidcrackme4.crackme;

public class MainActivity extends Activity
{

	private static int checkPointNum = 0;
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		checkPointNum = 0;
		checkpoint();
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		try {
			crackme instance = new crackme();
			instance.attachBaseContext(this.createPackageContext("com.deurus.androidcrackme4", Context.CONTEXT_IGNORE_SECURITY));
			String key = instance.createKey();
			ClipboardManager mgr = (ClipboardManager) this.getSystemService(CLIPBOARD_SERVICE);
			mgr.setText(key);
			new AlertDialog.Builder(this).setMessage(key).setPositiveButton(android.R.string.ok, null).show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void checkpoint() {
		System.out.println("CHECKPOINT " + checkPointNum);
		checkPointNum++;
	}

	public static void checkpoint2() {
		System.out.println("Anne");
	}

	public static void checkpoint3() {
		System.out.println("Diana");
	}
}
```
Basically, this creates an instance of our modified crackme class, attach a package context onto it so methods that depend on a Context works, then executes
a method called createKey. 

There's no such createKey method in the original class - that's what I made next. 

I decompiled the crackme using Dex2Jar and Fernflower to get a sense of where the key was being generated. It turns out that it was generated in the 
onCreate method, and compared against a key stored in the SharedPreferences. So instead of comparing the key, I can just make it return the key as a string. 

I changed the method signature of onCreate from

`.method public onCreate(Landroid/os/Bundle;)V` to `.method public createKey()Ljava/lang/String;`

then, I deleted all the code pertaining to layout - every line up to 
`const-string v5, "Prefs"`

Finally, I found the code where the key was compared, and changed it from

```    sget-object v5, Lcom/deurus/androidcrackme4/crackme;->i:Ljava/lang/String;

    invoke-virtual {v5, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_6
```

to

```
    sget-object v5, Lcom/deurus/androidcrackme4/crackme;->i:Ljava/lang/String;

    return-object v5
```

And now it's supposed to return the key as a String. However, a few things still needed to be added:

To attach the context to the Activity, I made the attachBaseContext method public:
```
	public void attachBaseContext(Context base) {
		super.attachBaseContext(base);
	}
```
And to get around NullPointerExceptions when trying to get the application context, I just did this:
```
	public Context getApplicationContext() {
		return this;
	}
```
There were two other null pointer exceptions, so I ended up commenting two lines that uses the no-longer-initialized EditTexts.

During the course of trying to make this work, I also added liberal amounts of tracing, done by calling MainActivity.checkpoint() and friends. 
It was done this way because no registers were needed to call the static void methods.

To build the project, a script builds the APK with a skeleton version of crackme.java, then the APK is torn apart by APKTool, the modified
smali files from the decompiled CrackMe apk are added, and finally a script signs the APK and installs it to the emulator.

I have tested this against the emulator and it works fine. I can register with any user name.

Through this, I've learned a couple of neat tricks on debugging Smali code, and gained experience of creating a keygen. If I were to do it again, I would
not modify onCreate as drastically, and allow the activity to run as usual, only passing the key via a method to prevent NullPointerExceptions when
it tries to access the nonexistent UI widgets.

I found this to be rewarding, and I'm looking forward to trying some of the other crackmes - next time, 
I'll actually try to understand the generation formula.
