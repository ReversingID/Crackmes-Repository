#!/usr/bin/ruby

if ARGV.length == 3 then
  puts "[*] Keygen Solution for Deurus Android CrackMe 03 - diff"
  puts " [*] Name : " + ARGV[0]
  puts " [*] IMEI : " + ARGV[1]
  puts " [*] Sim Serial : " + ARGV[2]

  name = ""
  (0..3).each do |i|
    name += "" + ARGV[0][i].to_s
  end

  imei = ARGV[1][0..5].to_i
  sim = ARGV[2][0..5].to_i

  print " [*] Generated Serial : "
  print (0x6b016 ^ name[0..4].to_i)
  print "-"
  print (imei ^ sim)
  print "-"
  print ARGV[1][0..5]
  print "\n"
else
  puts "[!] Error, need three args, name, imei and sim serial #"
end