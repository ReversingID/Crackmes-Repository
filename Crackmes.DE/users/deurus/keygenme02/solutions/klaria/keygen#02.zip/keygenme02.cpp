#include <GL/freeglut.h>

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <winbase.h>

#ifdef _MSC_VER
/* DUMP MEMORY LEAKS */
#include <crtdbg.h>
#endif

static void shapesPrintf (int row, int col, const char *fmt, ...)
{
    static char buf[256];
    int viewport[4];
    void *font = GLUT_BITMAP_9_BY_15;
    va_list args;

    va_start(args, fmt);
#if defined(WIN32) && !defined(__CYGWIN__)
    (void) _vsnprintf (buf, sizeof(buf), fmt, args);
#else
    (void) vsnprintf (buf, sizeof(buf), fmt, args);
#endif
    va_end(args);

    glGetIntegerv(GL_VIEWPORT,viewport);

    glPushMatrix();
    glLoadIdentity();

    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();

        glOrtho(0,viewport[2],0,viewport[3],-1,1);

        glRasterPos2i
        (
              glutBitmapWidth(font, ' ') * col,
            - glutBitmapHeight(font) * (row+2) + viewport[3]
        );
        glutBitmapString (font, (unsigned char*)buf);

    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
}

//var declarations::.

DWORD serial1=0;
DWORD snb=0;
DWORD snc=0;
DWORD l_u=0xff;
char nombre[50];
char user[50];
int i=0;
bool cursor=0;

DWORD calcular_code_1(void){
      DWORD a=0;
      DWORD b=0;
      DWORD c=0;
      for(int j=0;j<=i;j++){
                          a=b=nombre[j];
                          a+=0x1cb1;
                          a=a<<9;
                          a+=c;
                          b+=a-0x40;
                          c=b;
                         }
      return c;
      }   

DWORD calcular_code_2_3(void){
      DWORD a=0;
      DWORD b=0;
      DWORD c=0;
      for(int j=0;j<=i;j++){
              a=nombre[4];
              a*=0x5;
              b=nombre[1];
              b*=0x144;
              a+=c+b;
              c=a;
              }
       return c;
       } 
DWORD calcular_code_2_2(void){
      DWORD a=0;
      DWORD b=0;
      for(int j=0;j<=strlen(user);j++){
              a=user[j];
              a*=0x7;
              b=b+a+0xf7c5;
              }
      return b;
      }
void calcular(void){
      GetUserNameA(user,&l_u);
      serial1=calcular_code_1();
      snc=calcular_code_2_3();
      snb=calcular_code_2_2();
      }
      
void keyboard(unsigned char key, int w, int h){
     if(key==0xd)calcular();
     else
         if(key==0x8)nombre[--i]=0;
         else
              nombre[i++]=key;
     }                     

void init(void){
     glClearColor(0,0,0,0);
     glShadeModel(GL_FLAT);
     }

void idle(void){
     Sleep(100);
     glutPostRedisplay();
     cursor=!cursor;
     }


void display(){
     glClear(GL_COLOR_BUFFER_BIT);
     glColor3f(0,1,0);
     shapesPrintf(1,3,"Keygen");
     shapesPrintf(2,3,"By: Juan Carlos Laria");
     shapesPrintf(3,3,"Press ENTER to generate!");
     glColor3f(0.984,0.6705,0.9411);
     shapesPrintf(1,11,"KeygenMe#02 by deurus");
     glColor3f(0,1,1);
     shapesPrintf(5,3,"Name:%s",nombre);
     glColor3f(1,1,0);
     shapesPrintf(7,3,"Check1-> %i",serial1);
     glColor3f(1,0,1);
     shapesPrintf(8,3,"Check2-> A-%s-B-%d-C-%d",user,snb,snc);
     glColor3f(1,0,0);
     if(cursor)shapesPrintf(5,8+i,"_");
     glutSwapBuffers();
     }

int main(int argc, char** argv){
    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_DOUBLE|GLUT_RGB);
    glutInitWindowSize(375,200);
    glutCreateWindow("Keygen_by Klaria");
    init();
    glutDisplayFunc(display);
    glutIdleFunc(idle);
    glutKeyboardFunc(keyboard);
    glutMainLoop();
    return 0;
}