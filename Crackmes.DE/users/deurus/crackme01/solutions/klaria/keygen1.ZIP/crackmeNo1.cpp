#include <stdio.h>
#include <windows.h>


using namespace std;

char nombre[0x20];
int i=0;


DWORD calcular(void){
       
      WORD day,month,year;
      SYSTEMTIME t;
      DWORD b=0;
      FILE *out;
      
      GetLocalTime(&t);
      day=t.wDay;
      month=t.wMonth;
      year=t.wYear;
      out =fopen("license.txt","w+");
      fprintf(out,"%s\n",nombre);

      for(int j=0;j<i;j++){
      
             b+=nombre[j] xor day;
             b+=nombre[j]% month;
             b+=nombre[j] xor year;
             fprintf(out,"%d-",b);
            }
      
      fprintf(out,"%d",i);
      fclose(out);
      }
      
int main(int argc, char *argv[])
{
    char a;
    printf("Keygen by Klaria\nLicense.txt will be generated\nWrite yor name:");
    while(1){
           a=getchar();
           if(a=='\n')break;
           nombre[i++]=a;
           }
           
    calcular();
    
    return EXIT_SUCCESS;
}
