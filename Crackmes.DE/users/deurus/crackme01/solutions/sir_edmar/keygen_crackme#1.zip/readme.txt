keygen for crackme#1

for comments see the .c file.
this was my first crackme solved.

-- Sir_Edmar (knallerbse@gmail.com) 10/02/2010
