/*
Keygen for CrackMe#1 by deurus seen on crackmes.de
Written by Sir_Edmar (knallerbse@gmail.com) - 10/02/2010
Hope my solution is valid didnt got much sleep last night. worked on it till 4am in the morning ;)
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>


int main()
{
int year = 0;
int month = 0;
int day = 0;
char str_month[3];
char str_day[3];
char str_year[5];
struct tm time_struct;
time_t now;
char buffer[5];
char username[100];
int name_length = 0;
int cnt = 0;
time(&now);
int a, b, c, d;
time_struct = *localtime(&now);
    printf("Crackme#1 (written by deurus) Keygen (written by Sir_Edmar)\n");
strftime(&str_year, 5, "%Y", &time_struct);
year = atoi(str_year);
strftime(&str_month, 4, "%m", &time_struct);
month = atoi(str_month);
strftime(&str_day, 4, "%d", &time_struct);
day = atoi(str_day);

    a = 0;
    b = 0;
    c = 0;
    d = 0;
    printf("todays date (needed for calculation): %d.%d.%d\n",day,month,year);
    printf("enter username:");
    scanf("%s", username);
    name_length=strlen(username)+1;
    //routine implemented just like the asm code seen in ollydbg
    //the routine retrieves the local date for its calculations. so don't wonder how the 3 'magic' numbers came from.
    //just play with your date settings and you can see in ollydbg a difference
    //all equations were retrieved by step by step debugging and looking whats changed in the key-creation-routine
    for (cnt = 0; cnt <= name_length-2; cnt++){

        a = name_length;        //MOV EAX,DWORD PTR SS:[EBP-34]
        c = username[cnt];
        a = day;                //MOVZX EAX,WORD PTR DS:[451DAC]
        a = c ^ a;              //XOR EAX,ECX
        b +=a;                  //ADD EBX,EAX
        a = c;                  //MOV ECX;EAX
        d =  a % month;         //divide a by month and take the rest of the division to continue calculating
                                //this was acutally for me the hardest part to understand whats going on here
                                //MOVZX EAX,WORD PTR DS:[451DAE]
                                //PUSH EAX
                                //MOV EAX,ECX
                                //POP EDX
                                //MOV EDI,EDX
                                //IDIV EDI
        b += d;                 //ADD EBX,EDX
        a = year;               //MOVZX EAX,WORD PTR DS:[451DB0]
        c = c ^ a;              //XOR ECX,EAX
        b += c;                 //ADD EBX,ECX
        printf("%d-", b);
    }

  printf("%d\n",name_length-1);
  system("pause");
return 0;
}
