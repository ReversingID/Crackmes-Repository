                              Mastermind                        ;Date: 18/08/2003
                                    by Spider

No, it's not the game...  The name only reflects what I think of anyone
who solves it... A real mastermind!
This is a name/serial protection, but the check routine is very uncommon.
To solve it you must reach the following: 

- Find the serial for your name
- Write a generic keygenerator
- And, if you want, find the Easter Eggs!

Yeah, there are three hidden Easter Eggs... find them! :-)
You may do whatever you think of the crackme and use any tool you want; of course,
the crackme is solved only if you write a working keygen.

I hope you'll like it :)


For any comment, criticism, question or whatever else, don't hesitate to mail me.

Bye,
   Spider

e-mail   : spider_xx87@hotmail.com
my URL   : http://bigspider.cjb.net

UIC's URL: http://quequero.cjb.net
