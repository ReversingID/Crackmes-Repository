#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <conio.h>

int main()
{
	char name[20] = "";
	char serial[27]="33D20FBBD169C1xxxx00004040";
	int i;
	unsigned int val;
	char buffer[5]="";

	printf("Keygen for Spider's Mastermind crackme\nby ZaiRoN\n\n");

	printf("Your name: ");
	gets(name);

	val = 0x8E310BD4;
	for (i=strlen(name)-1; i>=0;i--)
	{
		val *= name[i];
		val ^= 0xD86F936E;
	}
	val %= 0xC350;
	val += 0x1F4;

	sprintf(buffer,"%X",val);

	if (strlen(buffer) == 2)
	{
		serial[14] = buffer[0];
		serial[15] = buffer[1];
		serial[16] = 0x30;
		serial[17] = 0x30;
	}
	else if (strlen(buffer) == 3)
	{
		serial[14] = buffer[1];
		serial[15] = buffer[2];
		serial[16] = 0x30;
		serial[17] = buffer[0];
	} else
	{
		serial[14] = buffer[2];
		serial[15] = buffer[3];
		serial[16] = buffer[0];
		serial[17] = buffer[1];
	}
	printf("\n\nSerial: %s", serial);

	getch();
	return 0;
}
