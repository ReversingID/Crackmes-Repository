                   88888
      ,88888         8888       88888B
    .d8P"`88b         `88b     488P"  
   ,888    888          88a   d88"    
  .c88'     v8h.         `8h J88'     
  d88        888  888      8888'      
 j887        888 ;8888     }88K       
 888B        888 88 `88   .88888      
 8888       J88 j88  Q88  d88  8&     
 8888b._  ,488  88'  `d8& 88   `88.   
 888888888888  d88     S8W8     `88b  
 `o88888888P ,888P      888       88q 
                      ,d88         88b,
                     88888          888B .inc
Crackme MMX 1.0
===============
1.Level 1, no VB shit.

2.If you write a working keygen(with usage of mmx instructions)
please email it to themoon@poland.com

themoon

http://www.dnx.prv.pl