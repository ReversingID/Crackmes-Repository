
  -----------------------------------------
  Crackme #5 - Digital Arithmetic
  by Malfunction
  -----------------------------------------
  
  After more than four years I am back with a new crackme :). I hope you
  will like it as much as I enjoyed coding it.
  
  This crackme is a usual keygenme. The aim is to write a keygen which can
  generate the correct keyfile for a given name. No patching allowed!
  The crackme has a tiny bit of encryption and anti-debug here and there,
  but the main difficulty should be to create a working keyfile.
  This might require a bit of special knowledge, but I am sure that you
  should be able to find your answers on the web if you're stuck.
  
  As usual, I tested this crackme by writing my own keygen. I tested my
  crackme intensively on a machine running WinXP SP2. However, I'm
  not perfect (actually, I am very far from being perfect) and so I can't
  garantuee that this crackme is 100% bug-free. Please let me know if you
  encounter any bugs in this crackme. Any feedback about this crackme
  is welcome.
  
  Happy reversing!
  
  (C) 2008   Malfunction
