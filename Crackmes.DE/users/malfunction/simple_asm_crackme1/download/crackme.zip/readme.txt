A little crackme - (c) 2oo3 by Malfunction
------------------------------------------

feeling bored, but inspired by Vecna's homepage i decided
to write this little crackme. lemme lose some words about
it:

- completely written in asm (hll crackmes suck ;))
- no automatically generated code (neither used at runtime
  nor at compiling time)
- the aim is to get the password which should consist
  of plain ANSI and should be copied into the clipboard
- after the file was run the clipboard is empty
  (this is actually an unintentional and weird bug)

i know that i could have put much more anti-debug stuff
into that program, but nevertheless it has some nice code.
i guess it will be absolutely no problem for a cracker
with good reverse engineering skills.
so have a try, challenger! :)

suggestions, questions, criticism: mal.function@gmx.net