#include <stdio.h>
#include <string.h>
#include <windows.h>
#include <stdlib.h>
#include "resource.h"

#define BLOCK1_FILE "block1.dat"
#define BLOCK2_FILE "block2.dat"

#define MAX_NAME 20

BOOL generated = FALSE;

unsigned char block1[256];
unsigned char block2[256];

BOOL CALLBACK abtProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam);
unsigned char asciify(unsigned char x);

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	DialogBox(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_DLG1), NULL, abtProc);
	return 0;
}

BOOL CALLBACK abtProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam)
{
	char x, temp;
	LPSTR name, serial;	

	HANDLE hBlock1, hBlock2;
	UINT bytesRead, i, j, k, z;

	name = GlobalAlloc(GPTR, MAX_NAME);

	switch(Message)
	{
		case WM_INITDIALOG:
			return TRUE;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case IDC_BTN1:
					if ((bytesRead = GetDlgItemText(hwnd, IDC_EDT1, name, MAX_NAME)) == 0)
					{
						MessageBox(hwnd, "Enter a fucking name!", "Moron", MB_OK | MB_ICONEXCLAMATION);
						return TRUE;
					}
					z = bytesRead;

					for (i = 0; i < z/2; i++)
					{
						j = z-i-1;
						temp = name[i];
						name[i] = name[j]-1;
						name[j] = temp-1;

					}
					if (z % 2)
						name[z/2]++;

					if ((hBlock1 = CreateFile(BLOCK1_FILE, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL)) == INVALID_HANDLE_VALUE)
					{
						MessageBox(hwnd, "Unable to open block1.dat file!", "Error", MB_OK | MB_ICONEXCLAMATION);
						return TRUE;
					}

					if ((hBlock2 = CreateFile(BLOCK2_FILE, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL)) == INVALID_HANDLE_VALUE)
					{
						MessageBox(hwnd, "Unable to open block2.dat file!", "Error", MB_OK | MB_ICONEXCLAMATION);
						return TRUE;
					}

					if (ReadFile(hBlock1, block1, 256, &bytesRead, NULL) == 0)
					{
						MessageBox(hwnd, "Corrupt block1.dat file!", "Error", MB_OK | MB_ICONEXCLAMATION);
						return TRUE;
					}
					if (bytesRead != 256)
					{
						MessageBox(hwnd, "Corrupt block1.dat file!", "Error", MB_OK | MB_ICONEXCLAMATION);
						return TRUE;
					}

					if (ReadFile(hBlock2, block2, 256, &bytesRead, NULL) == 0)
					{
						MessageBox(hwnd, "Corrupt block2.dat file!", "Error", MB_OK | MB_ICONEXCLAMATION);
						return TRUE;
					}

					if (bytesRead != 256)
					{
						MessageBox(hwnd, "Corrupt block2.dat file!", "Error", MB_OK | MB_ICONEXCLAMATION);
						return TRUE;
					}

					for (i = 0; i < z; i++)
					{
						for (j = 0; j < 256; j++)
						{
							if (block2[j] == name[i])
								break;
						}	
						for (k = 0; k < 256; k++)
						{
							if (block1[k] == j)
							break;
						}
						name[i] = k;
					}

					for (i = z-1; i >= 1; i--)
					{
						j = i-1;
						x = name[i]+1;
						
						_asm{
							mov	al, x
							ror	al, 3
							mov	x, al
						}

						x -= name[j];
						name[i] = x;
					}

					for (i = 0; i < z/2; i++)
					{
						j = z-i-1;
						temp = name[i];
						name[i] = name[j]-1;
						name[j] = temp-1;

					}
					if (z % 2)
						name[z/2]++;

					serial = GlobalAlloc(GPTR, (2*z)+1);
					serial[2*z] = 0;

					for (i = 0; i < z; i++)
					{
						x = name[i];
						_asm{
							xor	al, al
							mov	al, x
							shr	al, 4
							mov	x, al
						}
						serial[2*i] = asciify(x);

						x = name[i];
						_asm{
							xor	al, al
							mov	al, x
							shl	al, 4
							shr	al, 4
							mov	x, al
						}
						serial[(2*i)+1] = asciify(x);
					}
					
					generated = TRUE;
					SetDlgItemText(hwnd, IDC_EDT2, serial);
					break;

				default:
					break;
			}
			break;

		case WM_CLOSE:
			EndDialog(hwnd, 0);
			return TRUE;

		default:
			return FALSE;
	}
	return TRUE;
}

unsigned char asciify(unsigned char x)
{
	if (x >= 0 && x <= 9)
		return x+0x30;
	if (x >= 0xA && x <= 0xC)
		return x+0x57;
	return x+0x37;
}
