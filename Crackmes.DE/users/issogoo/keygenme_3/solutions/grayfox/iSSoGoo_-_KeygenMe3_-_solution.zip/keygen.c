#include <stdio.h>
#include <stdint.h>
#include <string.h>

void test_key(unsigned char key[11]) {
  uint32_t dword;
  uint8_t al, cl;
  unsigned char esi[10];
  memcpy(esi, key, 10);

  for(int eax = 0; eax < 2; eax++) {
    dword  = esi[0 + 4 * eax];
    dword |= esi[1 + 4 * eax] << 8;
    dword |= esi[2 + 4 * eax] << 16;
    dword |= esi[3 + 4 * eax] << 24;

    dword ^= 0x01234567;

    for(int i = 0; i < 4; i++)
      esi[i + 4 * eax] = *(((unsigned char *) &dword) + i);

    esi[4 * eax] &= 0xE;
  }

  cl = esi[8];
  for(int eax = 0; eax < 0xA; eax++) {
    cl += esi[eax];
    esi[8] = cl;
  }

  for(int eax = 0; eax < 2; eax++) {
    dword  = esi[0 + 4 * eax];
    dword |= esi[1 + 4 * eax] << 8;
    dword |= esi[2 + 4 * eax] << 16;
    dword |= esi[3 + 4 * eax] << 24;

    dword ^= 0x089ABCDE;

    for(int i = 0; i < 4; i++)
      esi[i + 4 * eax] = *(((unsigned char *) &dword) + i);

    esi[4 * eax] &= 0xE;
  }

  al = esi[9];
  for(int ecx = 0; ecx < 0xA; ecx++) {
    al += esi[ecx];
    esi[9] = al;
  }

  if(esi[8] == 0x42 && al == 0xDE) {
    printf("%s\n", key);
  }
}

int main() {
  unsigned char test_string[11] = { 0 };

  for(int a = 0; a < 26; a++) {
    for(int b = 0; b < 26; b++) {
      for(int c = 0; c < 26; c++) {
  	for(int d = 0; d < 26; d++) {
  	  for(int e = 0; e < 26; e++) {
	    for(int f = 0; f < 26; f++) {
	      test_string[0] = 'a';
	      test_string[1] = 'a';
	      test_string[2] = 'a';
	      test_string[3] = 'a';
	      test_string[4] = 'a' + a;
	      test_string[5] = 'a' + b;
	      test_string[6] = 'a' + c;
	      test_string[7] = 'a' + d;
	      test_string[8] = 'a' + e;
	      test_string[9] = 'a' + f;

	      test_key(test_string);
	    }
	  }
	}
      }
    }
  }
}
