#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

// GLOBAL VARS

char Serial[10];
char Original[10];

char CHARS[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
int nCHARS = 0;
int nKeysToCreate = 0;
int nKeysFound = 0;
FILE * fOut;
time_t StartTime;
double SecondsPassed;

unsigned long ulKeysTried = 0;


// Gen function
// Generates a checksum from a serial
void Gen(char * Serial)
{
    ulKeysTried++;

    for(int i = 0; i < 2; i++)
    {
        *(unsigned int*)(Serial + i * 4) ^= 0x1234567;
        *(unsigned char*)(Serial + i * 4) &= 0xE;
    }

    unsigned char Val1 = *(unsigned char*)(Serial + 8);
    for(int i = 0; i < 10; i++)
    {
        Val1 += *(unsigned char*)(Serial + i);
        *(unsigned char*)(Serial+8) = Val1;
    }

    for(int i = 0; i < 2; i++)
    {
        *(unsigned int*)(Serial+i*4) ^= 0x89ABCDE;
        *(unsigned char*)(Serial+i*4) &= 0xE;
    }

    unsigned char Val2 = *(unsigned char*)(Serial+9);
    for(int i = 0; i < 10; i++)
    {
        Val2 += *(unsigned char*)(Serial + i);
        *(unsigned char*)(Serial+9) = Val2;
    }
    return;
}

int main(int argc, char * argv[])
{
    srand(time(NULL));
    nCHARS = strlen(CHARS);

    if(argc < 3)
    {
        printf("You can create multiple keys:\n%s [NumKeys] [OutputFile]\n", argv[0]);
    }

    if(argc == 3)
    {
        nKeysToCreate = atoi(argv[1]);
        fOut = fopen(argv[2], "w");

        if(fOut == NULL)
            return -1;
    }

    StartTime = time(NULL);
    while(1)
    {
        for(int n = 0; n < 10; n++)
        {
            Serial[n] = CHARS[rand()%(nCHARS-1)];

            Original[n] = Serial[n];
        }

        Gen(Serial);        // Generate the checksum from the random key

        if(Serial[8] == 66 && Serial[9] == -34) // Check it
        {
            nKeysFound++;
            printf("Found: %s\nTried %lu keys so far.\n", Original, ulKeysTried);

            if (argc == 3)
            {
                fprintf(fOut, "%s\n", Original);
                if(nKeysFound >= nKeysToCreate)
                {
                    SecondsPassed = difftime(time(NULL), StartTime);
                    printf("Took %.f seconds to create %d keys.\n", SecondsPassed, nKeysFound);
                    fprintf(fOut, "Took %.f seconds to create %d keys.\n", SecondsPassed, nKeysFound);
                    fclose(fOut);
                    return 1;
                }
            }
            else
            {
                getchar();
                return 1;
            }
        }
    }

    fclose(fOut);
    return 0;
}
