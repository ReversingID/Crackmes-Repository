char s0[] = "tr4cefqijL";

unsigned int help,help2,test,test2;
help  = ((s0[0] ^ 0x67)&0xE) + ((s0[4] ^ 0x67)&0xE) + (s0[1] ^ 0x45) + (s0[2] ^ 0x23) + (s0[3] ^ 0x01) + (s0[5] ^ 0x45) + (s0[6] ^ 0x23) + ( s0[7] ^ 0x01);
help2 = (s0[1]^0xF9) + (s0[2]^0xB9) + (s0[3]^0x09) + ((s0[4]& 0xE) ^ 0x8) + (s0[5]^0xF9) + (s0[6]^0xB9) + ((s0[0]& 0xE) ^ 0x8) + (s0[7]^0x09);
test  = 2*s0[8] +   s0[9] + 2*help;
test2 = 4*s0[8] + 4*s0[9] + 4*help + 2*help2;

printf("DE == %02X?\n",test2&0xFF);
printf("42 == %02X?\n",test&0xFF);