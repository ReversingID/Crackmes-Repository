#include <stdio.h>
#include <string.h>

int check(char * str)
{
	union
	{
		char string[11];
		int number[2];
	} u;
	char ch;
	strcpy(u.string, str);
	
	u.number[0] ^= 0x1234567;
	u.string[0] &= 0xE;
	u.number[1] ^= 0x1234567;
	u.string[4] &= 0xE;
	
	ch = u.string[8];
	for(unsigned int i = 0; i < 10; i++)
	{
		ch += u.string[i];
		u.string[8] = ch;
	}
	
	u.number[0] ^= 0x89ABCDE;
	u.string[0] &= 0xE;
	u.number[1] ^= 0x89ABCDE;
	u.string[4] &= 0xE;
	
	ch = u.string[9];
	for(unsigned int i = 0; i < 10; i++)
	{
		ch += u.string[i];
		u.string[9] = ch;
	}
	
	if(u.string[8] != (char)0x42 || u.string[9] != (char)0xDE)
	{
		return 1;
	}
	return 0;
}

int main()
{
	char tab[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	int len = strlen(tab);
	char str[11] = "AAAAAAAAAA";
	
	for(int i = 0; i < len; i++)
	for(int j = 0; j < len; j++)
	for(int k = 0; k < len; k++)
	for(int l = 0; l < len; l++)
	for(int m = 0; m < len; m++)
	for(int n = 0; n < len; n++)
	for(int o = 0; o < len; o++)
	for(int p = 0; p < len; p++)
	for(int q = 0; q < len; q++)
	for(int r = 0; r < len; r++)
	{
		str[0] = tab[i];
		str[1] = tab[j];
		str[2] = tab[k];
		str[3] = tab[l];
		str[4] = tab[m];
		str[5] = tab[n];
		str[6] = tab[o];
		str[7] = tab[p];
		str[8] = tab[q];
		str[9] = tab[r];
		if(check(str) == 0)
			printf("%s\n", str);
	}
	return 0;
}