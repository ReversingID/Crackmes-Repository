#include <iostream>
#include <cstdlib>
using namespace std;

unsigned int Gen(unsigned int key1)
{
    int key2 = key1;
    
    for(int leet = 1337, i = 2; leet != 0; leet--, i++)
        key2 ^= i;

    return key2;
}

int main()
{
    unsigned int key[2];
    srand(time(NULL));
    
    for(int i=0; i<=5; i++)
    {
        key[0] = rand();
        key[1] = Gen(key[0]);
    
        cout << "key1: " << key[0] << endl;
        cout << "key2: " << key[1] << endl;
        cout << "-------------------------" << endl;
    }
    cin.get();

    return 0;
}
