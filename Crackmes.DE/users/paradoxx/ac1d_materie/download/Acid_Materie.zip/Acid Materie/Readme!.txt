Hi guys.

Try to Solve this Keygenme!

RuleZ:

-NoPatching ( u can patch it but its not a valid res.)
-Write a Keygen!

written in C++ by #ParadoxX[AC1D]  5.3.2010
Coding FTW!

Dreaming in Digital
Living in realtime
Thinking in binary
Talking in IP...