Bustme #4 : bpx

This crackme was custom packed by me.
To find the key, think like a hacker.

Tested on windows 98, 2000, XP.

Good Luck =)