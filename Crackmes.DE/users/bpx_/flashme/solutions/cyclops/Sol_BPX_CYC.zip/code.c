//Generate Serial
void GenSerial(HWND hWnd)
{
	int len;
	char szName[MAX_NAME+1];
	//char szSerial[MAX_SERIAL];

	char rb64[100];
	char res[100];
	int i;
	int mcod;
	int temp;

	len = GetDlgItemText(hWnd, IDC_Name, szName, MAX_NAME);
	if(len < 4)
	{
		SetDlgItemText(hWnd,
			IDC_Serial,
			"Name needs to be 4 chars or longer...");
	}
	else
	{
		B64Encode(szName, rb64);
		i = 0;
		mcod = 127;
		mcod = mcod + lstrlen(rb64);
		mcod = mcod + lstrlen(szName);
		while (i <= lstrlen(rb64))
		{
			mcod = mcod + (i + (rb64[i] & 255));
			if (i <= lstrlen(szName))
			{
				mcod = mcod + (i + (szName[i] & 255));
			} // end if
			i = i + 1;
		} // end while
		mcod = mcod * mcod;
		mcod = mcod ^ -1;
		temp = mcod;
		
		if(mcod < 0)
		{
			temp = -mcod;
			wsprintf(res,"-%X%d",temp,mcod);
		}
		else
		{
			wsprintf(res,"%X%d",temp,mcod);
		}
		for(i=0;i<lstrlen(res);i++)
		{
			if(res[i] == '-')
				res[i] = 'X';
		}

		SetDlgItemText(hWnd, IDC_Serial, res);
	}
}