FlashMe :: bpx

- Preface:

So far as I can tell, there are
very few flash based crackmes
available right now. So i'll 
contribute this lil' bastard.

Flash is becoming more and more
relevant as adobe gains popularity
and more and more apps find homes
online.

- The Crackme:

Keygen it, there are several
methods in place to stop 
decompilation and analysis. 
It should be fairly difficult.

So make sure you got the latest
version of flash [9.0?], an get crackin!

- Side note:

For another good challenge I
recommend reversing the myspace
music player.

[10:02 PM 3/27/2007]
