::BustMe #2::

Easy Custom pack.
Keygen/Unpack this badboy.

Congrats deroko for solving bustme #1.

::bpx.2k6::