
Your task is to register and be able to play this small game.
The best solution is to make a keymaker but if you cant you might try patching :)

A 100% working crackme/game will have a status like this:

******* found..
******* verification OK
Registered to: <your name>
Key is GOOD for this game :)

and the dialogbox caption will show your registered name.

NEO

