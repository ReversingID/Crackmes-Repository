helper.gp    - support functions (PARI/GP script)
factor.gp    - main factoring program (PARI/GP script)
keyfile.bin  - generated key file registered to "neotren"
keygen.cpp   - keygen source
keygen.exe   - keygen
solution.txt - main solution text
cryptome.idc - IDA script to make your listing look like mine
readme.txt   - this, of course

