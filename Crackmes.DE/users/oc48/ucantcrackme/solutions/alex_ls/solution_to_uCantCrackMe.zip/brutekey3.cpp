#define _WIN32_WINNT    0x0400
#include <windows.h>
#include <wincrypt.h>
#include <stdio.h>

#define BUFSIZE 256
#define MD5LEN  16


DWORD CreateMD5Hash ()
{
    HCRYPTPROV h_prov = 0;
    HCRYPTHASH h_hash = 0;
    
    DWORD	cb_hash;
	DWORD	dw_error;
    
	BYTE	p_strbuf[BUFSIZE];
    BYTE	p_hash[MD5LEN];
    
	dw_error=0;
    // Get handle to the crypto provider
    if (!CryptAcquireContext(&h_prov, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT))
    {
        dw_error = GetLastError();
        printf("CryptAcquireContext failed: %d\n", dw_error); 
        return dw_error;
    }

    if (!CryptCreateHash(h_prov, CALG_MD5, 0, 0, &h_hash))
    {
        dw_error = GetLastError();
	    printf("CryptAcquireContext failed: %d\n", dw_error); 
        CryptReleaseContext(h_prov, 0);
        return dw_error;
    }

	 for(DWORD i=0x0;i<0xffffffff;i++)
	 {
		sprintf((char*)p_strbuf,"(:!!!%x!!!:)",i);
		if (!CryptHashData(h_hash, p_strbuf, strlen((char*)p_strbuf), 0))
		{
            dw_error = GetLastError();
            CryptReleaseContext(h_prov, 0);
            CryptDestroyHash(h_hash);
            return dw_error;
		};
	    cb_hash = MD5LEN;
		if (CryptGetHashParam(h_hash, HP_HASHVAL, p_hash, &cb_hash, 0))
		{
			if(*(DWORD*)(p_hash)==0xe9c36fe8) break;
		}
	    else
        {
			dw_error = GetLastError();
			printf("CryptGetHashParam failed: %d\n", dw_error); 
			return dw_error;
		};
		
		CryptDestroyHash(h_hash);
		CryptCreateHash(h_prov, CALG_MD5, 0, 0, &h_hash);
		printf("current key-%x\r",i);
	};
	
	printf("\nKEY3=%x\n",i);
    
	CryptDestroyHash(h_hash);
    CryptReleaseContext(h_prov, 0);
	return dw_error;
}

//---------------------------------------
//NAME: MAIN()
//---------------------------------------
int main(int argc,char **argv)
{
	CreateMD5Hash();
	return 0;
};



