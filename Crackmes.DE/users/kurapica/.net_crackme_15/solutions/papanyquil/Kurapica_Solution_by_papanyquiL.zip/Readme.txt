Hi everyone, and welcome to my tutorial on cracking Kurapica�s �.NET CrackME #15�.  Let me first send out some greetz to Kurapica, all of the members over at BlackStorm (http://portal.b-at-s.info/news.php), obnoxious, T.0.R.N.A.D.0, and all of my friends at crackmes.de.


-papanyquiL