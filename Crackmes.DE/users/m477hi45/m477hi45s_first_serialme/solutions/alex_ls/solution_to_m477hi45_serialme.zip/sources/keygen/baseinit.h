//baseinit.h

#ifndef BASEINIT_H
#define BASEINIT_H

// includes
#define WINDOWS_LEAN
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>

#include "resource.h"

void init_cipher();
void create_key(BYTE *p_key);
void update_block(BYTE *p_key);
void encrypt_block(BYTE *p_key);
void init_block(BYTE *p_key,DWORD dw_strlen);

// defines
#define NAME_INFO		"Keygen for crackme m477hi45's serialme"

#define MAX_NAME   256
#define MAX_SERIAL 256
// errors
#define NAMELENGTH_ERROR		"Name must be 5 - 256 chars long!"

#endif