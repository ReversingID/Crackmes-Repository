#ifndef _VBSTOOL_H
#define _VBSTOOL_H

#include <stdio.h>
#include <stdlib.h>


typedef unsigned char byte;
typedef unsigned long dword;
typedef unsigned short word;

typedef struct tagHeader
{
	dword packsize;
	dword unpacksize;
	
} FILEHEADER;


#endif _VBSTOOL_H