#include "vbsextract.h"


//---------------------------------------
//Name: ShowUsage()
//---------------------------------------
void show_usage()
{
	printf("coded by alex_ls (2010)\n");
	printf("usage: vbsextract exe_file vbs_file\n");
};

extern "C" void __stdcall decompress_vbs(byte *p_dstbuf, byte *p_srcbuf);

//---------------------------------------
//NAME: MAIN()
//---------------------------------------
int main(int argc,char **argv)
{
	if(argc!=3)
	{
		show_usage();
		return -1;
	};


	FILE *p_file;

	if ((p_file=fopen(argv[1],"rb"))==NULL)
	{
		printf("Can't open source file %s\n",argv[1]);
		return -1;
	};
	
	FILEHEADER s_header;
	
	byte	*p_srcbuf;
	byte	*p_dstbuf;
	word	w_sig;

	fseek(p_file,-(long)(sizeof(FILEHEADER)),SEEK_END);
	fread(&s_header,1,sizeof(FILEHEADER),p_file);

	fseek(p_file,-(long)(s_header.packsize+sizeof(FILEHEADER)),SEEK_END);
	
	fread(&w_sig,1,2,p_file);
	if(w_sig!=0x434a)
	{
		printf("error: this file has no compressed vb script!\n");
		fclose(p_file);
		return -1;
	};
	
	p_srcbuf=new byte[s_header.packsize];
	p_dstbuf=new byte[s_header.unpacksize];
	
	fseek(p_file,-2,SEEK_CUR);
	fread(p_srcbuf,1,s_header.packsize,p_file);
	fclose(p_file);
	
	//uncompress buffer
	decompress_vbs(p_dstbuf,p_srcbuf);

	if ((p_file=fopen(argv[2],"wb"))==NULL)
	{
		printf("Can't create dest file %s\n",argv[2]);
		return -1;
	};

	fwrite(p_dstbuf,1,s_header.unpacksize,p_file);
	fclose(p_file);
		
	delete p_dstbuf;
	delete p_srcbuf;
	
	return 0;
};



