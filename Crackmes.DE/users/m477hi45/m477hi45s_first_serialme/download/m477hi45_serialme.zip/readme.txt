Thats my first serialme!
Written with VBS.


-Patch the nag
-Write a keygen

