Thats my first crackme.
Its very easy, just for beginners ;)
Please run it via DOS.
It will ask you for 4 key strokes...  and compares them with the hardcoded key.
I wrote it in Assambly.



I hope you write a nice tutorial to this ;)


