Program: crackme
Author:  cr4ckd0r
release Date:  April 02, 2015

About:

This is my first Crackme:
rules: solve my crackme
       write a keygen and tutorial

