====	CRACKME #1	====
2007-10-24 	21.00(Local Time/GMT+5.30) 
by Haunted

difficulity	= 1/10

This is my first crackme.
i hope it wont be difficult.

rules
-------
find a correct serial
Write a Keygen(If you want)
