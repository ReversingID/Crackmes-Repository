#define _WIN32_WINNT 0x0501
#include "resource.h"
#include <windows.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <iostream>
HINSTANCE hinst;
HWND hwnd;
BOOL APIENTRY DlgProc(HWND Dlg,UINT message,WPARAM wParam,LPARAM lParam);
BOOL APIENTRY Dialog1Proc(HWND, UINT, WPARAM, LPARAM);
long ebx,ecx,edx,sum2,s1,s2,s3,s4;
int nb3,val2;
unsigned long sum1;
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                                                LPSTR lpCmdLine, int nCmdShow)
{
       DialogBox(hInstance,"DIALOG1",NULL,(DLGPROC)DlgProc);


       return 0;
}
//---------------------------------------------------------------------------

BOOL APIENTRY DlgProc(HWND hDlg,UINT uMsg,WPARAM wParam,LPARAM lParam)
{

    switch (uMsg)
    {
      case WM_INITDIALOG:

         return TRUE;

      case WM_COMMAND:
         if (LOWORD(wParam) == IDOK)
              {

               char name[256]="",serial[31]="HNT-",buf1[31]="",message[41]="",bit1[33];
               char message1[20]= "invalid name";
               int lpc,lgtab,sum=0,int1=0,i;
               long EAX,ECX,EDX=0,res,res1,res2,val1=0 ;
                sum2=0;
                nb3=0;
                sum1=0;
// read of the name
                GetDlgItemText(hDlg, IDE_EDIT1, name, 256);
                int ln = strlen(name);
                if (ln <  2 )
                  {
                    strcpy (message, message1);
                    goto IMPRES;
                  }
// calculation of the first nine values of the serial

                 int j = ln / 2;
                sum= int(name[0])* int(name[ln-1]) * int(name[j]);  // value of the first char. * value of the last char.
                                                                    //   * value of the middle char



                for (int i = 1;i<5;i++)  // calculation of the position 5 to 8 of the serial
                                          // position 1 to 4 eqaul always "HNT-"
                    {
                       serial[8-i]= sum%10+48;   // decimal value of the rest of the division by 10
                        sum = sum / 10;
                    }

                serial[8]='-';  // position 9 of the serial = "-"

// calculation of pos 10 to 13 of the serial
                EAX = ln;
                ECX = ln;
                for (i = 0;i < ln;i++)
                    {
                      res = EDX / 256;
                      EDX =   ((res*256) + int(name[ln-1-i]));
                      EDX = EDX * (ln-i) ;
                      EAX = EAX + EDX;

                    //    MOV DL,BYTE PTR DS:[EBX+ECX]
                    //    IMUL EDX,ECX
                    //    ADD EAX,EDX


                    };
                val2 = EAX;  // val2 will be use allso in step 4

        // let's find the value of EBX,ECX,EDX registers after CPUID execute

                    asm
                      (
                        ".intel_syntax noprefix\n"
                        "XOR EAX,EAX\n"
                        "CPUID\n"
                        "mov _ebx, EBX\n"
                        "mov _ecx, ECX\n"   // will be use for the  step 3
                        "mov _edx, EDX\n"   // will be use for the  step 3
                        ".att_syntax noprefix\n"
                      );

                      val1 = ebx;


                // converting  in  bits + operator AND


                    for (int i = 31;i>-1;i--)
                    {
                        bit1[31-i] =((val1 >> i)&1) & ((val2 >> i)&1);
                    }

                // converting in hexa
                    for (int i= 0; i<32;i++)
                    {
                        nb3 = nb3 + (pow(2,31-i)* int(bit1[i]));
                        }





                /* the same in asm
                asm
                      (
                        ".intel_syntax noprefix\n"
                        "XOR EAX,EAX\n"

                        "mov EAX, _val2\n"
                        "AND EAX,EBX\n"
                        "mov _nb3,EAX\n"
                        ".att_syntax noprefix\n"
                      );

                */

                    for (int i = 1;i<5;i++)   // calculation of the position 9 to 12 of the serial
                    {
                        serial[13-i] = nb3%10+48;  // decimal value of the rest of the division by 10
                        nb3 = nb3 / 10;
                    }

                    serial[13]='-';  // position 9 of the serial = "-"

// step 3

                    lpc = strlen(name);
                sum1 =0;
                for (i = 0;i < lpc;i++)
                    {
                    sum1 = sum1 + int(name[i]);  // sum of all the charar. of the name
                    };

                int sumname = sum1;  // will be use later (step 4)
                sum1 = sum1 ^ edx; // (value edx from CPUID)

                        // ecx from CPUID
                asm
                      (
                        ".intel_syntax noprefix\n"
                        "XOR EAX,EAX\n"
                        "mov EAX, _sum1\n"
                        "mov ECX, _ecx\n"
                        "OR EAX,ECX\n"
                        "mov _nb3,EAX\n"
                        ".att_syntax noprefix\n"
                      );
                sum1 = (int(name[0])*int(name[1]))*nb3;




                for (int i = 1;i<5;i++)  // calculation of the position 14 to 17 of the serial
                    {
                       serial[18-i]= sum1%10+48;    // decimal value of the rest of the division by 10
                        sum1 = sum1 / 10;
                    }
                    serial[18]= '-';

// step 4

                    serial[19]=sumname%26 + 65;  // value of sumname in step3
                    serial[20] = val2%26 + 65;

                    wsprintf(message,"%s",serial);

 IMPRES:              SetDlgItemText(hDlg, IDE_EDIT3,message) ;

              }
         if (LOWORD(wParam) == IDCANCEL)
                {
                   EndDialog(hDlg,0);
                   return TRUE;
                }


         if(LOWORD(wParam) == IDM_ABOUT)
                       DialogBox(hinst, "DIALOG2" , hwnd, (DLGPROC)Dialog1Proc);

      default:
         return FALSE;
    }
}

BOOL APIENTRY Dialog1Proc(HWND hDlg,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
    switch (uMsg)
    {
      case WM_INITDIALOG:

         return TRUE;

      case WM_COMMAND:
         if (LOWORD(wParam) == IDCANCEL || LOWORD(wParam) == IDOK)
                {
                   EndDialog(hDlg,0);
                   return TRUE;
                }

      default:
         return FALSE;
    }
}
