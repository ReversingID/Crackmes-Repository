#define IDE_EDIT1 101
#define IDE_EDIT2 102
#define IDE_EDIT3 103
#define IDM_ABOUT 3
