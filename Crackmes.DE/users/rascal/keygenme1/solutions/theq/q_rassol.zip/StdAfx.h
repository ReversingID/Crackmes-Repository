#ifndef KEYGEN_STDAFX_H_INCLUDED
#define KEYGEN_STDAFX_H_INCLUDED

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers

// Windows Header Files:
#include <windows.h>

// stl
#include <string>
using namespace std;

#endif
