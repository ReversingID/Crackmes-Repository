#ifndef BIGNUMBER_H_INCLUDED
#define BIGNUMBER_H_INCLUDED

/********************************************
				BigNumber
This library is aimed to perform calculations
on huge unsigned interger numbers.
The mathematical core is written in assembly.
It's requiered in order to access the  carry 
flag, and so perform long calculations.
Written specificaly for the RSA implementation.
\********************************************/

#include "StdAfx.h"

// 12 bytes max to describe a number
#define MAX_BIGNUM_SIZE	(14*sizeof(DWORD))
#define MAX_DECIMAL_SIZE (40*MAX_BIGNUM_SIZE)
#define MAX_FERNAT_TESTS 4

typedef unsigned char BYTE;
typedef BYTE BIG_NUMBER[MAX_BIGNUM_SIZE];
typedef BIG_NUMBER*	PBIG_NUMBER;

#ifndef BASE_NUMBER_DEFINED
#define BASE_NUMBER_DEFINED
enum FormatNumberBase
{
	DISPLAY_IN_DECIMAL = 0xa,
	DISPLAY_IN_HEX = 0x10
};
#endif


class BigNumber
{
public:
	BigNumber();
	BigNumber(PBIG_NUMBER number);
	BigNumber(int number);
	BigNumber(char* decimalNumber);
	virtual ~BigNumber();

	//
	// big numbers and RSA
	//
	bool setRandomGeneratorSeed(char* passphrase);
	bool setMaxRand(int maxRandomValue /*valid dword count*/);
	bool generateRandomValue();
	bool generatePrime(DWORD stopTime = 0/*in milliseconds */);

	// format number (text form)
	bool getFormatNumber(char* displayNumber, FormatNumberBase displayBase = DISPLAY_IN_DECIMAL);

	// ---------------------\
	// overload operators	|
	// ---------------------/
	// type cast
	operator PBIG_NUMBER () { return &_numberArray; }
	operator char () { return (char)_numberArray[0]; }


	// assign
	BigNumber& operator=( const PBIG_NUMBER newValue );
	BigNumber& operator=( const int newValue );
	BigNumber& operator=( const char* newDecValue );

	// compares
	bool operator==( PBIG_NUMBER valueToCompare );
	bool operator==( int valueToCompare );
	bool operator>( PBIG_NUMBER valueToCompare );
	bool operator>( int valueToCompare );
	bool operator<( PBIG_NUMBER valueToCompare );
	bool operator<( int valueToCompare );

	// calculations
	BigNumber operator+( PBIG_NUMBER addValue );
	BigNumber operator+( int addValue );
	BigNumber operator-( PBIG_NUMBER subValue );
	BigNumber operator-( int subValue );
	BigNumber operator*( PBIG_NUMBER mulValue );
	BigNumber operator*( int mulValue );
	BigNumber operator/( PBIG_NUMBER divValue );
	BigNumber operator/( int divValue );
	BigNumber operator%( PBIG_NUMBER modValue );
	BigNumber operator%( int modValue );

	PBIG_NUMBER getArray() { return &_numberArray; }
	bool		isNegative();
	int			getMaxBits();
private:
	// all different constructors call this
	BigNumber::generalConstructor();

	// conversions
	void convertDecimalToBignum(const char* decimalNumber, BigNumber* targetBN);
	bool convertBignumToOtherBase(BigNumber* sourceBN, FormatNumberBase selectedBase, char* outFormatNumber);

	// max random number
	int			_limitNumber;
	// the number's bytes
	BIG_NUMBER	_numberArray;
};

// process B^exp (mod M)
bool expModulus(BigNumber* baseNumber, BigNumber* exponent, BigNumber* modulusNumber, BigNumber* modRemainer);
// calculate the inverse of a mod n
BigNumber inverseModulus(BigNumber &a, BigNumber &n);

#endif
