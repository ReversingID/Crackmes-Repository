#include "stdafx.h"
#include "BigNumber.h"
#include "MathMachine.h"

#include <stdlib.h>

//
// constructor / destructor
//
BigNumber::BigNumber()
{
	*this = (int) 0;
	generalConstructor();
}

BigNumber::BigNumber(PBIG_NUMBER number)
{
	*this = number;
	generalConstructor();
}

BigNumber::BigNumber(int number)
{
	*this = number;
	generalConstructor();
}
BigNumber::BigNumber(char* decimalNumber)
{
	*this = decimalNumber;
	generalConstructor();
}

BigNumber::generalConstructor()
{
	_limitNumber = (sizeof(_numberArray)/sizeof(short int));
}

BigNumber::~BigNumber()
{

}

//
// assign new value
//
BigNumber& BigNumber::operator=( const PBIG_NUMBER newValue )
{
	memcpy(_numberArray, newValue, sizeof(_numberArray));
	return *this;
}

BigNumber& BigNumber::operator=( const int newValue )
{
	ZeroMemory(_numberArray,sizeof(_numberArray));
	((int*)_numberArray)[0] = newValue;
	return *this;
}

BigNumber& BigNumber::operator=( const char* newDecValue )
{
	*this = (int) 0;
	convertDecimalToBignum(newDecValue, this);
	return *this;
}

// return last bit
bool BigNumber::isNegative()
{
	char lastByte = _numberArray[MAX_BIGNUM_SIZE-1];
	return (lastByte & 0x80 ? true : false);
}

int	BigNumber::getMaxBits()
{
	BigNumber localNumber = *this;
	if (localNumber == 0)
	{
		return 0;
	}

	int nBits = 8 * sizeof(BIG_NUMBER);

	while ( BN_rol(localNumber) == 0 )
	{
		nBits--;
	}

	return nBits;
}

// format number (text form)
bool BigNumber::getFormatNumber(char* displayNumber, FormatNumberBase displayBase)
{
	if ( IsBadWritePtr( displayNumber, MAX_DECIMAL_SIZE) !=0 )
	{
		// buffer not big enough
		return false;
	}
	ZeroMemory(displayNumber,MAX_DECIMAL_SIZE);
	return convertBignumToOtherBase(this,displayBase, displayNumber);
}

//
// Conversions
//
void BigNumber::convertDecimalToBignum(const char* decimalNumber, BigNumber* targetBN)
{
	#define DECIMAL_BASE (0xA)
	BigNumber baseNumber(1);
	int decimalDigitsCount = lstrlen(decimalNumber) - 1;
	// start from the last digit
	for (int i=decimalDigitsCount; i>=0; i--)
	{
		// grab decimal digit
		int digit = (int) decimalNumber[i];
		digit -= 0x30;
		// calculate the hex value
		(*targetBN) = (*targetBN) + (PBIG_NUMBER) (baseNumber * digit);
		// update base
		baseNumber = baseNumber * DECIMAL_BASE;
	}
}

bool BigNumber::convertBignumToOtherBase(BigNumber* sourceBN, FormatNumberBase selectedBase, char* outFormatNumber)
{
	char	backwordNumber[MAX_DECIMAL_SIZE];
	ZeroMemory(backwordNumber, sizeof(backwordNumber));

	int		baseNumber = (int) selectedBase;
	char*	digitTable = 0;
	switch (selectedBase)
	{
		case DISPLAY_IN_DECIMAL:
			{
				digitTable = "0123456789";
			}
			break;
		case DISPLAY_IN_HEX:
			{
				digitTable = "0123456789ABCDEF";
			}
			break;
	}

	BigNumber bigResult = (*sourceBN);
	int outTextIndex = 0;
	do
	{
		int reminder = BN_divByInt( bigResult, baseNumber, bigResult);
		char newBaseDigit =  digitTable[reminder];
		backwordNumber[outTextIndex++] = newBaseDigit;
	} while (bigResult > baseNumber);

	char newBaseDigit =  digitTable[bigResult];
	backwordNumber[outTextIndex++] = newBaseDigit;

	for (int i=lstrlen(backwordNumber)-1, j=0;
		 i>=0;
		 j++, i--)
	{
		outFormatNumber[j] = backwordNumber[i];
	}

	return true;
}

//
// compare
//
bool BigNumber::operator==( PBIG_NUMBER valueToCompare )
{
	int compareResult = BN_compare( &_numberArray, valueToCompare );
	return compareResult==0 ? true : false;
}

bool BigNumber::operator==( int valueToCompare )
{
	BigNumber bigTemp( valueToCompare );
	int compareResult = BN_compare( &_numberArray, bigTemp );
	return compareResult==0 ? true : false;
}

bool BigNumber::operator>( PBIG_NUMBER valueToCompare )
{
	int compareResult = BN_compare( &_numberArray, valueToCompare );
	return compareResult==-1 ? true : false;
}

bool BigNumber::operator>( int valueToCompare )
{
	BigNumber bigTemp( valueToCompare );
	int compareResult = BN_compare( &_numberArray, bigTemp );
	return compareResult==-1 ? true : false;
}

bool BigNumber::operator<( PBIG_NUMBER valueToCompare )
{
	int compareResult = BN_compare( &_numberArray, valueToCompare );
	return compareResult==1 ? true : false;
}

bool BigNumber::operator<( int valueToCompare )
{
	BigNumber bigTemp( valueToCompare );
	int compareResult = BN_compare( &_numberArray, bigTemp );
	return compareResult==1 ? true : false;
}

//
// Calculations
//
BigNumber BigNumber::operator+( PBIG_NUMBER addValue )
{
	BigNumber bigResult;
	BN_add( &_numberArray, addValue, bigResult);
	return bigResult;
}

BigNumber BigNumber::operator+( int addValue )
{
	BigNumber bigSource( addValue );
	BigNumber bigResult;
	BN_add( &_numberArray, bigSource, bigResult);
	return bigResult;
}

BigNumber BigNumber::operator-( PBIG_NUMBER subValue )
{
	BigNumber bigResult;
	BN_sub( &_numberArray, subValue, bigResult);
	return bigResult;
}

BigNumber BigNumber::operator-( int subValue )
{
	BigNumber bigSource( subValue );
	BigNumber bigResult;
	BN_sub( &_numberArray, bigSource, bigResult);
	return bigResult;
}

BigNumber BigNumber::operator*( PBIG_NUMBER mulValue )
{
	BigNumber bigResult;
	BN_mul( &_numberArray, mulValue, bigResult);
	return bigResult;
}

BigNumber BigNumber::operator*( int mulValue )
{
	BigNumber bigMultiplier(mulValue);
	BigNumber bigResult;
	BN_mul( &_numberArray, bigMultiplier, bigResult);
	return bigResult;
}

BigNumber BigNumber::operator/( PBIG_NUMBER divValue )
{
	BigNumber bigResult;
	BigNumber bigRemainder;
	BN_div( &_numberArray, divValue, bigResult, bigRemainder);
	return bigResult;
}

BigNumber BigNumber::operator/( int divValue )
{
	BigNumber bigDivisor( divValue );
	BigNumber bigResult;
	BigNumber bigRemainder;
	BN_div( &_numberArray, bigDivisor, bigResult, bigRemainder);
	return bigResult;
}

BigNumber BigNumber::operator%( PBIG_NUMBER modValue )
{
	BigNumber bigResult;
	BigNumber bigRemainder;
	BN_div( &_numberArray, modValue, bigResult, bigRemainder);
	return bigRemainder;
}

BigNumber BigNumber::operator%( int modValue )
{
	BigNumber bigDivisor( modValue );
	BigNumber bigResult;
	BigNumber bigRemainder;
	BN_div( &_numberArray, bigDivisor, bigResult, bigRemainder);
	return bigRemainder;
}


//
// big numbers and RSA
//
bool BigNumber::setMaxRand(int maxRandomValue)
{
	_limitNumber = maxRandomValue / sizeof(short int);
	return true;
}
bool BigNumber::generateRandomValue()
{
	for (int i=0; i < _limitNumber; i++)
		((short int*)_numberArray)[i] = rand();
	return true;
}

bool BigNumber::generatePrime(DWORD stopTime)
{
	DWORD genStartTime = GetTickCount();
	#define ELLAPSED_TIME	\
			(GetTickCount()-genStartTime)

	// update seed
	srand( GetTickCount() );

	bool possiblePrimeFound = false;
	bool timeUp = false;
	while ( !timeUp && !possiblePrimeFound)
	{
		// 1. init with a random value
		generateRandomValue();

		// 2. Fermat's test (Fermat's little theorem): 
		//	  if P is prime, than N^(P-1) = 1 (mod P)
		//    experiment with some N, until satisfied
		int	 numberOfTest = 0;
		bool runTestAgain = true;
		BigNumber fermatRemainder;
		BigNumber N = 3;
		BigNumber fermatExponent = (*this - 1);
		while (runTestAgain && numberOfTest < MAX_FERNAT_TESTS)
		{
			expModulus( &N, &fermatExponent, this, &fermatRemainder);
			if (fermatRemainder == 1)
			{
				numberOfTest++;
				N = N + 1;
			}
			else
			{
				runTestAgain = false;
			}
		}

		if (numberOfTest >= MAX_FERNAT_TESTS)
		{
			possiblePrimeFound = true;
		}

		// check time
		if (stopTime)
		{
			timeUp = ELLAPSED_TIME > stopTime ? true:false;
		}
	}
	if (timeUp)
	{
		// time is up, and still no prime found..zero the number
		*this = (int) 0;
		return false;
	}

	return possiblePrimeFound;
}

// working with pointer to a result big number is faster than
// returning a big number, and then re-assiging the value.
bool expModulus(BigNumber* baseNumber, BigNumber* exponent, BigNumber* modulusNumber, BigNumber* modRemainer)
{
	BigNumber runningSquareMod = (*baseNumber);
	BigNumber runningBaseMod(1);
	BigNumber localExponent = (*exponent);

	for (int bits=0; bits < (MAX_BIGNUM_SIZE*32); bits++)
	{
		// keep dividing exponent by 2, until 1 is reached
		int bitSet = BN_shr(localExponent,false);
		if (bitSet == 1)
		{
			// update running base modulus :
			// runningBaseMod = (runningBaseMod * runningSquareMod) % (*modulus);
			BN_mulMod(runningBaseMod, runningSquareMod, *modulusNumber, runningBaseMod);
		}

		// update running square modulus :
		// runningSquareMod = (runningSquareMod * runningSquareMod) % (*modulus);
		BN_mulMod(runningSquareMod, runningSquareMod, *modulusNumber, runningSquareMod);
		if (localExponent == 1)
		{
			break;
		}
	}
	// finall modulus:
	//*modRemainer = (runningBaseMod * runningSquareMod) % (*modulus);
	BN_mulMod(runningBaseMod, runningSquareMod, (*modulusNumber), (*modRemainer));
	return true;
}

/*********************************************
Invese modulus function is taken from Philip 
Zimmermann's cryptography library.
In RSA:
	d is the inverse modulus of e mod (phi_n).

This is my (lame, but working) attemp:
	BigNumber _d;
	BigNumber S = 20;
	BigNumber remainder;
	do
	{	
		S = S + 1;
		_d = ((S*phi_n) + 1) / parentRSA->_rsa_e;
		remainder = _d*parentRSA->_rsa_e % phi_n;
	} while ( !(remainder == 1) );
For performace, its best to use the function
below.
**********************************************/
#define iplus1  ( i==2 ? 0 : i+1 )	// used by Euclid algorithms
#define iminus1 ( i==0 ? 2 : i-1 )	// used by Euclid algorithms

BigNumber inverseModulus(BigNumber &a, BigNumber &n)
{
    BigNumber g[3];
	g[0] = n;
	g[1] = a;
    BigNumber v[3];
	v[0] = 0;
	v[1] = 1;
    BigNumber y;

	BigNumber bigMinusOne(1);
	BigNumber bigTemp;
	bigMinusOne = bigTemp - bigMinusOne;

    for (int i=1; g[i] > 0; i = iplus1)
    {
        y = g[iminus1] / g[i];
        g[iplus1] = g[iminus1] % g[i];
        //v[iplus1] = v[iminus1] - (v[i] * y);
		bigTemp = (v[i] * y);
		bigTemp = bigTemp * bigMinusOne;
		v[iplus1] = v[iminus1] + bigTemp;
    }

    if ( v[iminus1].isNegative() )
	{
        v[iminus1] = v[iminus1] + n;
	}
    return v[iminus1];
}