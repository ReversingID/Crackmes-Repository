// math machine extern functions

extern "C" 
{
	// 0 if (x==y) ; -1 if (x>y) ; 1 if (x<y)
	int __stdcall BN_compare( PBIG_NUMBER x, PBIG_NUMBER y);

	// r = a+b
	int __stdcall BN_add( PBIG_NUMBER a, PBIG_NUMBER b, PBIG_NUMBER r );
	// r = a-b  (returns 1 if b>a)
	int __stdcall BN_sub( PBIG_NUMBER a, PBIG_NUMBER b, PBIG_NUMBER r );
	// r = a*b
	int __stdcall BN_mul( PBIG_NUMBER a, PBIG_NUMBER b, PBIG_NUMBER r );
	// r = a/b 
	int __stdcall BN_div( PBIG_NUMBER a, PBIG_NUMBER b, PBIG_NUMBER r, PBIG_NUMBER remainder );
	// r = a/b (returns the remainder)
	int __stdcall BN_divByInt( PBIG_NUMBER a, DWORD b, PBIG_NUMBER r );

	// 1 bit rotation
	int __stdcall BN_shr( PBIG_NUMBER a, bool newLBit );
	int __stdcall BN_shl( PBIG_NUMBER a, bool newRBit );
	int __stdcall BN_ror( PBIG_NUMBER a );
	int __stdcall BN_rol( PBIG_NUMBER a );

	// r = (a*b) % modulus
	int __stdcall BN_mulMod( PBIG_NUMBER a, PBIG_NUMBER b, PBIG_NUMBER modulus, PBIG_NUMBER r );
}
