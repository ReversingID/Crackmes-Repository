/***************************************
		Hash Algorithms Library
***************************************/

#ifndef HASHALGOS_H_INCLUDED
#define HASHALGOS_H_INCLUDED

enum SupportedHashAlgos
{
	HASH_TIGER,
	HASH_MD5,
	HASH_SHA,
	HASH_RIPEMD,
	HASH_HAVAL
};

//
// Hash Crypt Context
//
#define MAX_HASH_SIZE (100)
typedef struct  HashCryptContext*					 HCPTR;
typedef bool	(__cdecl *HASH_INIT_FUNCTION)		(HCPTR cryptContext);
typedef bool	(__cdecl *HASH_SHUTDOWN_FUNCTION)	(HCPTR cryptContext);
typedef bool	(__cdecl *HASH_FUNCTION)			(HCPTR cryptContext,char *message, int messageSize);
struct HashCryptContext
{
	SupportedHashAlgos			workingHash;
	HASH_INIT_FUNCTION			initFunc;
	HASH_SHUTDOWN_FUNCTION		shutdownFunc;
	HASH_FUNCTION				hashFunction;
	int							blockSize;	// in bits
	int							hashSize;	// in bits
	char						hashResult[MAX_HASH_SIZE];
};

struct HashRateResult
{
	int		bytesProcessed;
	int		bitsProcessed;	// same as bytesProcessed only in bits
	float	secondsTaken;	// test duration in seconds
	float	rateBitsPerSecond;
};

#ifndef BASE_NUMBER_DEFINED
#define BASE_NUMBER_DEFINED
enum FormatNumberBase
{
	DISPLAY_IN_DECIMAL = 0xa,
	DISPLAY_IN_HEX = 0x10
};
#endif

//
// hash algos lib
//
class HashAlgos  
{
public:
	HashAlgos();
	virtual ~HashAlgos();

	// handle crypt context
	HashCryptContext	* createHashCryptContext(SupportedHashAlgos selectedHash);
	bool deleteHashCryptContext(HashCryptContext* cryptContext);

	// handle hash functions
	bool hashMessage(HashCryptContext* cryptContext, char *message, int messageSize);

	// information and tests
	bool formatHashResult(HashCryptContext* cryptContext, FormatNumberBase selectedBase, char *outFormatNumber); 
	int	 getMaxFormatText();
	int	 getMaxHashSize(HashCryptContext* cryptContext) { return cryptContext->hashSize >> 3; }

	bool ratePerformance(HashCryptContext* cryptContext, HashRateResult* rateResult/*out*/, int bytesToProcess = 64*1024 /*in*/);
};


#endif


