#include "stdafx.h"
#include "Common.h"

namespace	NS_HashCommon
{



} // end namespace	NS_HashCommon
