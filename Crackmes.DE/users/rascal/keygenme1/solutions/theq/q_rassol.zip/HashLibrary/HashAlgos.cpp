#include "stdafx.h"
#include "HashAlgos.h"

#include "BigNumber.h"

//
// hash algorithms
//
#include "Tiger.h"
HashCryptContext	TigerHashInfo = 
{
	HASH_TIGER,					/*workingHash	*/
	&TigerHash::initHash,		/*initFunc		*/
	&TigerHash::shutdownHash,	/*shutdownFunc	*/
	&TigerHash::hasher,			/*hashFunction	*/
	TigerHash::BLOCK_SIZE_BITS,	/*blockSize		*/
	TigerHash::HASH_SIZE_BITS	/*hashSize		*/
};

#include "MD5.h"
HashCryptContext	MD5HashInfo = 
{
	HASH_MD5,					/*workingHash	*/
	&MD5Hash::initHash,			/*initFunc		*/
	&MD5Hash::shutdownHash,		/*shutdownFunc	*/
	&MD5Hash::hasher,			/*hashFunction	*/
	MD5Hash::BLOCK_SIZE_BITS,	/*blockSize		*/
	MD5Hash::HASH_SIZE_BITS		/*hashSize		*/
};


//
// hash lib constructor
// 
HashAlgos::HashAlgos()
{
}

HashAlgos::~HashAlgos()
{
}



//
// create a new crypt context
//
HashCryptContext	* HashAlgos::createHashCryptContext(SupportedHashAlgos selectedHash)
{
	// check if crypt algo avaliable
	HashCryptContext	*foundAlgoInfo = 0;
	switch (selectedHash)
	{
		case HASH_TIGER:
			foundAlgoInfo = &TigerHashInfo;
			break;
		case HASH_MD5:
			foundAlgoInfo  = &MD5HashInfo;
			break;
	}

	if (foundAlgoInfo)
	{
		// create a new context, and copy the default info
		HashCryptContext	*newContext = new HashCryptContext;
		memcpy(newContext, foundAlgoInfo, sizeof(HashCryptContext));
		// init cipher and return
		newContext->initFunc(newContext);
		return newContext;
	}
	else
		// error - selected cipher not found
		return 0;
}

//
// clear crypt context
//
bool HashAlgos::deleteHashCryptContext(HashCryptContext* cryptContext)
{
	// shutdown cipher, and delete the context
	cryptContext->shutdownFunc(cryptContext);
	delete cryptContext;
	return true;
}


bool HashAlgos::hashMessage(HashCryptContext* cryptContext, char *message, int messageSize)
{
	if (cryptContext->hashFunction)
	{
		return cryptContext->hashFunction(cryptContext,message, messageSize);
	}
	return false;
}


bool HashAlgos::formatHashResult(HashCryptContext* cryptContext, FormatNumberBase selectedBase, char *outFormatNumber)
{
	// Call the format number function from the bignum
	// library (yeah, its slow, i know it!)
	outFormatNumber[0]=0;
	char	displayOutput[MAX_DECIMAL_SIZE];
	for (int i=0; i < getMaxHashSize(cryptContext); i++)
	{
		BigNumber byte = (int) ((unsigned char*) cryptContext->hashResult)[i];
		byte.getFormatNumber(displayOutput, selectedBase);
		lstrcat(outFormatNumber, displayOutput);
	}
	return true;
}

int HashAlgos::getMaxFormatText()
{
	return MAX_DECIMAL_SIZE;
}

bool HashAlgos::ratePerformance(HashCryptContext* cryptContext, HashRateResult* rateResult/*out*/, int bytesToProcess/*in*/)
{
	if ( bytesToProcess > 64*1024)
	{
		return false;
	}
	char *	testBuffer = new char[bytesToProcess];
	FillMemory(testBuffer, bytesToProcess, 0x51);
	int		testIterations = 100;

	HashCryptContext	* testCrypContext = new HashCryptContext;
	memcpy(testCrypContext, cryptContext, sizeof(HashCryptContext));

	// test timer
	long	startTime = GetTickCount();

	for(int i=0; i<testIterations; i++)
	{
		hashMessage(testCrypContext, testBuffer, bytesToProcess);
	}

	long	finishTime = GetTickCount();
	float	durationMillSeconds = (finishTime - startTime);

	// free buffers
	delete testCrypContext;
	delete testBuffer;

	// fill report
	rateResult->bytesProcessed = bytesToProcess * testIterations;
	rateResult->bitsProcessed = rateResult->bytesProcessed << 3;
	rateResult->secondsTaken = durationMillSeconds / 1000;
	rateResult->rateBitsPerSecond =  rateResult->bitsProcessed / rateResult->secondsTaken;
	return true;
}
