#ifndef MD5_H_INCLUDED
#define MD5_H_INCLUDED

#include "HashAlgos.h"

namespace MD5Hash  
{
const BLOCK_SIZE_BITS = (512);
const BLOCK_SIZE = BLOCK_SIZE_BITS >> 3;
const HASH_SIZE_BITS  = (128);
const HASH_SIZE = HASH_SIZE_BITS >> 3;

	bool	initHash(HCPTR cryptContext);
	bool	shutdownHash(HCPTR cryptContext);

	bool	hasher(HCPTR cryptContext,char *message, int messageSize);
};

#endif
