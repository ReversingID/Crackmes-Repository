#ifndef TIGERHASH_H_INCLUDED
#define TIGERHASH_H_INCLUDED

#include "HashAlgos.h"

namespace TigerHash  
{
const BLOCK_SIZE_BITS = (512);
const BLOCK_SIZE = BLOCK_SIZE_BITS >> 3;
const HASH_SIZE_BITS  = (192);
const HASH_SIZE = HASH_SIZE_BITS >> 3;

	bool	initHash(HCPTR cryptContext);
	bool	shutdownHash(HCPTR cryptContext);

	bool	hasher(HCPTR cryptContext,char *message, int messageSize);
};

#endif
