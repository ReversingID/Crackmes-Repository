#ifndef HASH_LIB_STDAFX_H_INCLUDED
#define HASH_LIB_STDAFX_H_INCLUDED

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers

// Windows Header Files:
#include <windows.h>

// stl
#include <stack>
#include <string>
using namespace std;

#endif
