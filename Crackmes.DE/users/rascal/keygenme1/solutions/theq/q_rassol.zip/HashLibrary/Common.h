#ifndef HASH_COMMON_H_INCLUDED
#define HASH_COMMON_H_INCLUDED

namespace	NS_HashCommon
{

};


#endif