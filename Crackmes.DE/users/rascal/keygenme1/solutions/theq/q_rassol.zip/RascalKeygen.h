#ifndef RASCAL_KEYGEN_H_INCLUDED
#define RASCAL_KEYGEN_H_INCLUDED

#include "HashAlgos.h"
#include "BigNumber.h"

#include "resource.h"
LRESULT CALLBACK MainDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

//
// keygen structures
//
#define MAX_CODE_SIZE		(0x800)
typedef unsigned char UCHAR;
#pragma pack(push,1)
struct  ActivationCode
{
	int		_messageSize;
	UCHAR	_message[0x50];
	
	int		_key1Size;
	UCHAR	_key1[0xc0];

	int		_key2Size;
	UCHAR	_key2[0xc0];

	int		_key3Size;
	UCHAR	_key3[0x200];

	int		_key4Size;
	UCHAR	_key4[0x18];

	UCHAR	_magicByte;
};
#pragma pack(pop)

typedef UCHAR	EncodedActicationCode[MAX_CODE_SIZE];

//
// functions proto-types
//
bool	generateActivationCode();
bool	encodeActivationCode(ActivationCode *activationCode);
bool	encodeCodeSegment(UCHAR* encData, int encSize, EncodedActicationCode finalActivationCode, int &findex, bool encodeSize = true);
int		reverseBignumberBytes(BigNumber *bigNumber, bool dwordAlign = true);

bool	encryptName(ActivationCode *activationCode);

#endif