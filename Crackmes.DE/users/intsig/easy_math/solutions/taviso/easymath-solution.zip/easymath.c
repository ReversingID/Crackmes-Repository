#include <unistd.h>
#include <sys/ptrace.h>
#include <stdio.h>

/* approximation of easymath crackme by intsig 
 * Tavis Ormandy, <taviso@sdf.lonestra.org>
 * 03/01/2006
 */

int main(int argc, char **argv)
{
    char *done = "done\n";

    if (argv[1] == NULL) {
        return 0;
    }

    if (ptrace(PTRACE_TRACEME, 0, NULL, NULL) == -1) {
        ptrace(PTRACE_DETACH, getpid(), NULL, NULL);
        return 0;
    }

    if (atoi(argv[1]) * 12 == 17712) {
        puts(done);
    }

    return 0;
}
