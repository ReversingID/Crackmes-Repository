#!/usr/bin/perl
##-- kbp - 20080925 --##

use strict;


##-- vars --##
my ($todaysDate, $todaysDateAsNumber, $name, $nameLength, $i, $serial);
my $nameSum = 0;
my $minimumNameLength = 5;


##-- subs --##
sub getDate {

	my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime time;
	$mon += 1;
	$mday = sprintf("%02d", $mday);
	$mon = sprintf("%02d", $mon);
	$year += 1900;
	$todaysDate = "$mday" . "$mon" ."$year";
		
}

sub atoi {
  my $t;
  foreach my $d (split(//, shift())) {
    $t = $t * 10 + $d;
  }
  return $t;
}

sub nameSumDecimal {

  for ( $i=0; $i<$nameLength; $i++ ) {
  
      $nameSum += ord(substr($name, $i, 1));
     
  }
}

sub generateSerial {

  &nameSumDecimal;
  &getDate;
  $todaysDateAsNumber = atoi($todaysDate);
  $serial = $todaysDateAsNumber * $nameSum

}


##-- main --##
print "-= This is a keygen for Thomas' crackme1 from www.crackmes.de =-\n";
print "Please enter your name: ";
$name = <STDIN>;
chomp $name;
$nameLength = length($name);
if ( $nameLength >= $minimumNameLength) {
 
  &generateSerial;
  print "Your serial is: $serial\n";
  
}
else {

  print "Your name must be at least $minimumNameLength characters.\n";
  
}