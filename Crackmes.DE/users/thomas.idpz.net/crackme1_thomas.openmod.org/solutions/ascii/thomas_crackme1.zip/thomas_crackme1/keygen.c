#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int main(int argc, char *argv[]) {

	// Check if a name is given as argument
	if (argc != 2) {
		printf("This keygen need a name as first argument.\n");
		return EXIT_FAILURE;
	}
	
	// Just for beautifull code
	char *name = argv[1];
	
	// For store the key
	unsigned int key = 0;
	
	// Get the current date
	time_t timestamp = time(NULL);
	
	// Convert the date to an integer
	char buffer[9];
	strftime(buffer, sizeof(buffer), "%d%m%Y", localtime(&timestamp));
	unsigned int date = atoi(buffer);
	
	// Compute the key
	unsigned int count = 0;
	for (; count < strlen(name); count++)
		key += name[count] * date;
	
	// Show result
	printf("Name: %s\n", name);
	printf("Key: %i\n", key);
	printf("The key works for today only.\n");
	
	return EXIT_SUCCESS;
}
