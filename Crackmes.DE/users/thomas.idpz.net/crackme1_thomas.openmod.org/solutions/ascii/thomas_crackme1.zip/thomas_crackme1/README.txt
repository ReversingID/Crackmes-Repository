Solution for
http://crackmes.de/users/thomas.idpz.net/crackme1_thomas.openmod.org/

Tool used: OllyDbg

	My first step was to find a working key. For that I search where the
condition for checking the key is done. Enter anything as name/key, you will see
a message box with the text "try again". This string is referenced at
0x00403fb3. If you look above this address, you will see another string
reference "good cracker, now keygen it". Good, now search for the last asm
condition. Found at 0x00403f1c. Put a breakpoint on it, and run this crackmes.
Now look at the stack, you can see the username, and a bit above an unicode
string with only numbers ("1545393465"). Let's try this string as key. We are
lucky, that's the key.

	Now, we are going to make a keygen. For this part, I was very lucky. I saw
directly the key in ST7 register. So the key may be compute here. Maybe, you
already notice but the username length must be greater than 5. The string
reference for "Name must be more than 5 caracters" is at 0x00403c61. Hmm... this
address is near the last condition found at 0x00403f1c. The key must be compute
between this two addresses. If you look closer, You will see a loop between
addresses 0x00403d15 and 0x00403e90. Put a breakpoint at the start of this loop.
Run the program to crack with an easy username to remenber, let's try with
"abcde". When the breakpoint is hit, continue and count how many time the
breakpoint is hit. The breakpoint is hit 5 times. Same as the username length.
In the loop you can see another string reference at 0x00403e0e "ddmmyyyy". This
string looks like a date used as integer. Re-run the program, wait for the
second time the breakpoint is hit. The program may used the first char. In ST7
register I found 302834679. In this loop you can see some VB multiplication and
addition (MSVBVM60.__vbaVarMul and MSVBVM60.__vbaVarAdd) references. So let's
try with our last number. 302834679 / 97 (letter 'a') = 3122007. :o today is
03/12/2007. If you continue debugging this way, you can see the program just
additionning each answer for each letter.

ex: 3122007 * 97 + 3122007 * 98 + 3122007 * 99 + 3122007 * 100 + 3122007 * 101
 = 1545393465

PS: The keygen was done under Linux, maybe you can't compile it with M$
 compiler.
PPS: As you already notice, I'm not a native english speaker ;)

ascii
