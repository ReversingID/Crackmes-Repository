manatails007's 2nd crackme.
Almost as same as 1st except it is crypted ManaLock.
If you can patch this, patch,:)