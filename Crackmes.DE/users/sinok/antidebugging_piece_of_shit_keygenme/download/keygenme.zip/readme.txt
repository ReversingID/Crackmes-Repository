Create a keygen and post the source code. Your solution is not considered valid without a working source code.

Optional: Write how to disable all the anti-debugging functions.

Made by Sinok.