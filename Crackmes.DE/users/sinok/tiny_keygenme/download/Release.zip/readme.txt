Notes:
- Yes, the program crashes when you click on check. It's not a bug.
- The program is really clean, finding the "check" is REALLY easy.

New interesting features in this version :)
Enjoy cracking this =D
