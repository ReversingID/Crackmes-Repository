Author: Sinok

Instructions
-------------------------------------------
Find the password, no patching, enjoy, and good luck.