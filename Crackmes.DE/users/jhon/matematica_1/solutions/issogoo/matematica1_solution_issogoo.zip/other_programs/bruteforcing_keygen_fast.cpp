#include <iostream>
#include <iomanip>

using namespace std;


inline int power(int base, int expo){

    int tmp = base;

    if(expo==1){
        return base;
    }else{
        if(base==0){
            return 0;
        }

        if(base==1){
            return 1;
        }

        /* Keep in Mind, that expo=0 is like expo=0xFFFFFFFF ! */
        expo--;
        while(expo>0){
            tmp*=base;
            expo--;
        }
    }

    return tmp;
}


int main(){

    int EAX, EBX, EDX, ESI, EDI;

    for(int num1=0xA4FF5; num1<=9999999; num1+=0xA4FF5){
        for(int num2=0xA4FF5; num2<=9999999; num2+=0xA4FF5){
            EBX = num1/0xA4FF5;
            ESI = num2/0xA4FF5;
            EDI = power(EBX, 3);
            EAX = (EBX-1)*EBX;
            EDX = (EBX-2)*5;
            EAX = EAX-EDX;
            EDI = EDI*EAX;
            EDX = (ESI-1)*ESI;
            EAX = (ESI-2)*5;
            EDX = EDX-EAX;
            EAX = power(ESI, EDX);

            if(EAX==EDI){
                cout << setfill('0') << setw(7) << num1 << "-" << setfill('0') << setw(7) << num2 << endl;
            }
        }
    }

    return 0;
}
