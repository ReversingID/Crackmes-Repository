#include <iostream>
#include <cstdlib>
#include <iomanip>
#include <ctime>
#include <cstdio>

#define MAX_ADD 0xA4FF5

using namespace std;

int rand10000(){
    return rand() % 10000;
}

int main(){

    srand(time(NULL));

    int num1 = 1351658 + (rand10000()+rand10000()*100) % MAX_ADD;
    int num2 = 2703316 + (rand10000()+rand10000()*100) % MAX_ADD;

    cout << "Here is a serial: " << setfill('0') << setw(7) << num1 << "-" << setfill('0') << setw(7) << num2 << endl;


}
