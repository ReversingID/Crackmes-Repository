#include <stdio.h>
#include <string.h>

void main()
{
 char Name[50], cat[7];
 int i2;
 memcpy(cat, "Rc1-420", 8);
 printf("Keygen Rom4n's crackme#1\n\tBy Sorvats");
 printf("\n\nYour Name?--->");
 scanf("%s", Name);
 strcat(Name, "C00L");
 strcat(cat, Name);
 printf("\nSerial-------->%s", cat);
 printf("\n\nCtrl+C to close");
while(i2)
{
     i2=1;
}
}
