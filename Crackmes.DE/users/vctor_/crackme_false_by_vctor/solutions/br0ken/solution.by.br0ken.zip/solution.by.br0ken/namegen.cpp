#include<conio.h>
#include<stdio.h>
#include<string.h>
void main()
{
	char serial[199]={'0'},name[199]={'0'};
	int i=0,j=0,len;
	printf("************************************************\n");
	printf("*** Name-Gen for V!ctor's KeygenMe by br0ken ***\n");
	printf("************************************************\n");
	printf("\n\nEnter a serial (min 2 chars, numbers prefered) :  ");
	scanf("%s",serial);
	len=strlen(serial);
	do
	{
		name[i]=serial[j]+serial[j+1]-0x23;
		i=i+1;
	    j=j+2; 
	}
	while(i<=len);
	name[len/2]='\0';
printf("\n\nValid Name : %s",name);
printf("\n\nUsage\n*****\n\n");
printf("1. Put the name and serial in the cme and press check.\n");
printf("2. You'll get the badboy.\n");
printf("3. Now, press exit, you'll get the goodboy :)\n");
getch();

}