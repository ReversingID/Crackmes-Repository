After you run keygen.exe you will find valid username / serial in the "key.txt" file.
Username will contain many unprintable characters so if you don't want type (alt-xxx)
use crackme1 < key.txt.