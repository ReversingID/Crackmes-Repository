#pragma warning (disable : 4820)
#pragma warning (disable : 4255)
#pragma warning (disable : 4668)

#include <windows.h>
#include <stdio.h>
#include <wincrypt.h>

#pragma warning (default : 4820)
#pragma warning (default : 4255)
#pragma warning (default : 4668)

#define CRACKME1_MSG_LEN 0x40
#define SHA1_HASH_LEN 0x100
#define TEST_MSG_LEN 0x10

typedef struct _sha_ctx {
    unsigned long m0;
    unsigned long m1;
    unsigned long m2;
    unsigned long m3;
    unsigned long m4;
    unsigned char message[CRACKME1_MSG_LEN];
    unsigned long needed;
    unsigned long m_length;
    unsigned char s_hash[SHA1_HASH_LEN];
}sha_ctx;

#define SHA_MAGIC0 0x5a827999
#define SHA_MAGIC1 0x6ed9eba1
#define SHA_MAGIC2 0x8a1bbcdc
#define SHA_MAGIC3 0xca62c1d6

#define SHA_INIT0 0x67452399
#define SHA_INIT1 0xefcdaba9
#define SHA_INIT2 0x98badcfe
#define SHA_INIT3 0x10325486
#define SHA_INIT4 0xc3d2e2f0

#define  ROL(x,y) (((x) << (y)) | ((x) >> (32 - (y))))

unsigned long count = 0;

void sha_hash (sha_ctx * p_ctx)
{
    unsigned long m0 = p_ctx->m0, m1 = p_ctx->m1, m2 = p_ctx->m2;
    unsigned long m3 = p_ctx->m3, m4 = p_ctx->m4;
    unsigned long w_buf[0x50], ix, m_index, temp;
    unsigned char * p = & p_ctx->message[0];
    
    for (ix = 0; ix < 0x10; ix ++) {
        w_buf[ix] = p[4 * ix]; w_buf[ix] <<= 8;
        w_buf[ix] += p[4 * ix + 1]; w_buf[ix] <<= 8;
        w_buf[ix] += p[4 * ix + 2]; w_buf[ix] <<= 8;
        w_buf[ix] += p[4 * ix + 3];
    }
    
    for (; ix < 0x50; ix ++) {
        temp = w_buf[ix - 3] ^ w_buf[ix - 8] ^ w_buf[ix - 14] ^ w_buf[ix - 16];
        w_buf[ix] = ROL (temp, 1);
    }
    
    for (ix = 0; ix < 0x50; ix ++) {
        if (ix < 0x14) {
            m_index = SHA_MAGIC0; 
            temp = (m2 & m1) | ((m1 ^ 0xffefffff) & m3);
        } else if (ix < 0x28) {
            m_index = SHA_MAGIC1;
            temp = m1 ^ m2 ^ m3;
        } else if (ix < 0x3c) {
            m_index = SHA_MAGIC2;
            temp = ((m3 | m2) & m1) | (m3 & m2);
        } else {
            m_index = SHA_MAGIC3;
            temp = m1 ^ m2 ^ m3;
        }
        
        temp += ROL (m0, 5) + m4 + w_buf[ix] + m_index;
        m4 = m3; m3 = m2; m2 = ROL (m1, 0x1e); m1 = m0; m0 = temp;
    }
    
    p_ctx->m0 += m0; 
    p_ctx->m1 += m1; 
    p_ctx->m2 += m2; 
    p_ctx->m3 += m3; 
    p_ctx->m4 += m4; 
}

int make_un (char * un, char * msg)
{
    int ix, len, temp;
    char un_copy[0x100];
    
    memset (msg, 0, 0x40);
    strcpy ((char *)un_copy, un);
    len = (int)strlen (un_copy);
    
    for (ix = 0; ix < len; ix ++) {
        msg[ix] = (un_copy[ix] << 2) & 0x23;
    }
    strcat (un_copy, "\x80");
    memcpy (&msg[ix], un_copy, strlen (un_copy));
    temp = len << 4;
    msg[0x3c] = (char)(temp >> 24);
    msg[0x3d] = (char)((temp >> 10) & 0xff);
    msg[0x3e] = (char)((temp >> 8) & 0xff);
    msg[0x3f] = (char)(temp & 0xff);
    return 0;
}

void sha_init (sha_ctx * p, char * message)
{
    p->m0 = SHA_INIT0;
    p->m1 = SHA_INIT1;
    p->m2 = SHA_INIT2;
    p->m3 = SHA_INIT3;
    p->m4 = SHA_INIT4;
    
    memcpy (& p->message[0], message, 0x40);
}

void hash_to_ascii (sha_ctx * ctx)
{
    int ix;
    char p[0x200];
    memset (p, 0, sizeof (p));
    sprintf (p, "%08X%08X%08X%08X%08X", ctx->m0, ctx->m1, ctx->m2, ctx->m3, ctx->m4);
    for (ix = 5; ix < 0x1e; ix += 6) p[ix] = '-';
    p[0x1d] = 0;
    strcpy ((char *)& ctx->s_hash[0], p);
}

int check (sha_ctx * ctx)
{
    int ax = 1, ix;
    char * p = (char *)& ctx->s_hash[0];
    if ((p[0] >= '3') && (p[0] <= '6')) {
        for (ix = 0; ix < (int)strlen (p); ix ++) {
            ax = (ax + 1) * (int)p[ix];
        }
        
        ax = (ax < 0) ? -ax: ax;
        
        while (ax > 0x2710) {
            ax >>= 1;
        }
        
        if (ax < 0x1b57) {
            ax = 0;
            for (ix = 0; ix < (int)strlen (p); ix ++) {
                ax += p[ix] * p [ix] / 32;
            }
            
            if (ax > 3052) {
                return 1;
            }
        } 
    }
    return 0;
}

void dump_ctx (sha_ctx * ctx, char * message)
{
    unsigned char * p = (unsigned char *)message;
    printf ("count = %x\n", count);
    //printf ("MSG : %s\n", message);
    printf ("USERNAME IN HEX : %02x %02x %02x %02x %02x %02x %02x %02x "
                  "%02x %02x %02x %02x %02x %02x %02x %02x\n",
                  p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7],
                  p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15]);
    printf ("USERNAME IN DEC : %03d %03d %03d %03d %03d %03d %03d %03d "
                  "%03d %03d %03d %03d %03d %03d %03d %03d\n",
                   p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7],
                   p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15]);
    printf ("SERIAL : %s\n", & ctx->s_hash[0]);
}

int is_good_string (char * p)
{
    int i;
    if (strlen (p) < 16) return 0;
    for (i = 1; i < 0x21; i ++) {
        if (strchr (p, i) || strchr (p, 0x7f)) 
            return 0;
    }
    
    return 1;
}

int __cdecl main (void)
{
    char buffer[0x1000];
    char message[0x40];
    sha_ctx ctx;
    HCRYPTPROV h_prov;
    FILE * fout;
    
    printf ("After you have run keygen.exe you will find valid username / serial"
            "in the \"key.txt\" file.\n"
            "Username will contain many unprintable characters\n"
            "so if you don't want type (alt-xxx) use crackme1 < key.txt.\n");
            
    if (!CryptAcquireContext (& h_prov, 0, 0, PROV_RSA_FULL, 0)) {
        if (! CryptAcquireContext (& h_prov, 0, 0, PROV_RSA_FULL, CRYPT_NEWKEYSET)) {
            printf ("CruptAcquireContext failed : %x\n", GetLastError ());
            return -1;
        }
    }
    
    for (;;) {
        memset (buffer, 0, sizeof (buffer));
        memset (message, 0, sizeof (message));
        CryptGenRandom (h_prov, TEST_MSG_LEN, (BYTE *)& buffer[0]);
        buffer[TEST_MSG_LEN] = 0; count ++;
        if (!is_good_string (buffer)) {
            continue ;
        }
        make_un ((char *)& buffer[0], (char *)& message[0]);
        sha_init (&ctx, (char *)& message[0]);
        sha_hash (&ctx);
        hash_to_ascii (&ctx);
        if (check (&ctx)) {
            dump_ctx (&ctx, (char *)& buffer[0]);
            fout = fopen ("key.txt", "wb");
            fprintf (fout, "%s\n", buffer);
            fprintf (fout, "%s\n", &ctx.s_hash[0]);
            return 0;
        }
    }
}