int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{
	hInst=hInstance;
	InitCommonControls();

	STARTUPINFO lpSi;
	PROCESS_INFORMATION lpPi;
	DWORD rval;
	GetStartupInfo (&lpSi);

	rval=CreateProcess("Virulent_CLI.exe",NULL,NULL,NULL,0,NORMAL_PRIORITY_CLASS,NULL,NULL,&lpSi,&lpPi);

	if(rval==0)
	{
		MessageBox(0,"Cannot find Virulent_CLI.exe\nPlease copy exe and dlls to keygen's direcory and try again!",szApp,0);
		return -1;
	}
	WaitForInputIdle(lpPi.hProcess,INFINITE);

	Sleep(200);

	char szName[50];

	WriteProcessMemory(lpPi.hProcess,(LPVOID)0x004A160B,"\x70",1,NULL);
	WriteProcessMemory(lpPi.hProcess,(LPVOID)0x004A1614,"\x70",1,NULL);
	WriteProcessMemory(lpPi.hProcess,(LPVOID)0x004A161D,"\x70",1,NULL);
	rval=WriteProcessMemory(lpPi.hProcess,(LPVOID)0x004A1626,"\x70",1,NULL);
	if(rval == 0)
	{
		sprintf(szName,"Cant write:%08X",GetLastError());
		MessageBox(0,szName,"",0);
	}
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, (DLGPROC)DialogProc,0);
	return 0;
}
void Make_Serial(char *name,char *szSerial)
{

	SHA1* sha1 = new SHA1();
	sha1->addBytes( name, strlen( name ) );
	unsigned char* digest = sha1->getDigest();
	sha1->hexPrinter( digest, 12, szSerial );
	delete sha1;
	free( digest );

	int Var1,Var4;

	Var1 = 6;
	while(Var1 < 0x17)
	{
		szSerial[Var1] = '-';
		Var4 = Var1+1;
		while(Var1+4 > Var4)
		{
			if(szSerial[Var4] <= 64)
			{
				szSerial[Var4] += 32;
			}
			else
			{
				szSerial[Var4] += 16;
			}
			while(1)
			{
				if(szSerial[Var4] <= 90)
					break;
				szSerial[Var4] -= 25;
			}
			Var4++;
		}
		Var1 += 6;
	}
	Var4 = 0;
	while( Var4 <= 0x17)
	{
		if(szSerial[Var4] != 45)
		{
			while(1)
			{
				if(szSerial[Var4] <= 90)
					break;
				szSerial[Var4] -= 2;
			}
		}
		Var4++;
	}
}