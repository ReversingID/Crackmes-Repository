Virulent - by Drakenza

What makes this crackme interesting is the fact that it "mutates." It breaks off a thread that randomly switches between a number of algorithms. Because of this, a traditional keygen won't work.

What you have to do is analyze the crackme and its libraries, and write a loader/trainer that modifies the crackme in memory and disables the mutation mechanism in some way. Then write a keygen for the current algorithm scheme. Not too difficult ;)

-------------------------

RULES:

Patching is allowed with the following restrictions:
- No patches that modify any algorithm(s).
- No patches that modify the validation routine(s). This means, no patches to make it accept all serials, etc.
- No jump patching, unless it's absolutely necessary for your keygen.
- Absolutely NO self-keygens. It will seem very tempting, but DON'T.

Any patching must be related to the mutation scheme, nothing else!

Any patches that you require must be done through a loader/trainer (you can't patch the executable or DLLs directly).

ABSOLUTELY NO BRUTEFORCING.

-------------------------

One last note: You may NOT link the DLLs in your code. You must reverse the algorithms yourself!