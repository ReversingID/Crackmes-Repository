#include <stdio.h>

char buff[100];
int i,j;

void main(void)
{ scanf("%s",buff);
  printf("ADCM4-");
  i=0;
  while(buff[i])
  { j=(((int)buff[i]/6)*((int)buff[i]/4))/((int)buff[i]/10);
    printf("%d",j);
    i++;
  }
  printf("-YEAH!\n");
}