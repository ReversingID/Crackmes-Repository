#include <iostream>
#include <string>

using namespace std;

int main()
{
    string any_symbols;
    char yes_no = 'n';

    while (yes_no == 'n')
        {
            cout << "Enter any symbols: \n";
            cin >> any_symbols;
            cout << "\n";
            cout << "User: " << any_symbols << "\n";

            cout << "Key: ";
            for (int i = any_symbols.size() - 1; i >= 0 ; --i)
                {
                    cout << any_symbols[i];
                    if (i != 0)
                        cout << "-";
                }

            cout << "\n\n";
            cout << "Exit? ('n' - no): ";
            cin >> yes_no;
            cout << "\n\n";
        }

    return 0;
}
