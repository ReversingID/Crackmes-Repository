[CrackMe]		CrackMe#2 by BaKaE
[Language]		Delphi
[Protection]		like an umbrella while a hurricane
[Fun while Cracking]	yep
[hint]			not yet
[OS]			tested on XP Pro SP1 and XP Home SP2
[Difficult]		3/10 or 4/10

rulez:

1. dont patch the algo
2. write a KeyGen
3. send me your Solution + KeyGen
4. hurry solving thiz if you want CrackMe#3
