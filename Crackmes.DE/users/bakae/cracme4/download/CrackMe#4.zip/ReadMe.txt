Thiz is my fourth CrackMe, it should be harder, than my other CrackMes.

Rulez:		1. Have Fun
		2. Don't patch any jump
		3. Avoid to use DeDe
		4. Avoid to give up

Thiz is all, now go on and Crack It