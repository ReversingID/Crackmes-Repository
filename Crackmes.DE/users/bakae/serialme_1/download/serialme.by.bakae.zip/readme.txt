Hello folks,

this is a very easy serial, like a serial check, in games.
should be level 1 (for beginners)

have fun and bugreport @ me (via pm) or any admin on crackmes.de

ps: please DONT patch, just keygen it

cya