[CrackMe]		CrackMe#3 by BaKaE
[Language]		Delphi
[Protection]		Better than the other 2
[hints]			Crying may not help
[OS]			tested on XP Pro SP1 and XP Home SP2
[Difficult]		3/10 or 4/10

rulez:

1. Dont' use DeDe. This is not allowed.
2. Patching is allowed but don't patch the algo or cmps or "Good Boy Jump"
3. send me your Solution + KeyGen

This CrackMe maybe don't work on 95,98 or Me, Sorry!!