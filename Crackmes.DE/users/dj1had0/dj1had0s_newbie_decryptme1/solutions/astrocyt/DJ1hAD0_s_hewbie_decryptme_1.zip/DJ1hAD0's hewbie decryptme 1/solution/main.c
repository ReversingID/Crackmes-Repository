int main(int argc, char* argv)
{
	puts("Magic word:");
	char input[10];
	fgets(input);
	int l = strlen(input);
	int charssum=0;
	for(int i=1;i<=9;i++)
	{
		charssum += input[i];
	}
	
	int subs = charssum - 864;
	if(subs == 0x14)
	{
		for(int i = 0; i < strlen(encrypted); i++)
		{
			encrypted[i] = 0x14 ^ encrypted[i];
		}
	}
	
	return 0;
}