This is my first keygenme submitted.  It was made and intended for beginners.  Once solved, I will post my source code (if requested).  Again, this is for beginners, if you're an accomplished cracker :P, this will probably be quite boring!

Rules:
*No brute-forcing
*No patching
*Create a working keygen

A special thanks to T.0.R.N.A.D.0. for giving out some of his source code to help me out in my quest for higher knowledge.  :D



-papanyquiL

-----------------------------------------------------------------------

************
* SOLUTION *
************

Tools you need:

 Reflector (are you wondered?)
 VS 2008
 Brain


Open first the KeyME in Reflector, to see what we get there.

You See something like this:

Form1
 |- CheckSerial_Click
 |- CloseApp
 |- CreateSerial
 |- Dispose
 |- Exit_Click_1
 |- GenerateKey
 |- InitializeComponent
 |- linkLabel1_LinkClicked
 |
 |- etc.
 :
 :
 .
 .

Special is here: He swapped the names as follow:


CheckSerial_Click -> is the exit Button (unloads the Application)

Exit_Click_1 -> This one makes the serial
 |-> CreateSerial
      |-> He put here a senseless For-loop, ignore it..
	    |-> In the Sub 'Me.CloseApp' is all what we need

Open VS 2008 and drag 2 Textboxes and one Button on the Form.

Copy the Following Code in there:

- Code --------------------------------------------

Public Class Form1

Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
  Dim str As String = "papanyquiL"
    Dim i As Integer

    For i = 0 To Me.TextBox1.Text.Length - 1
        str = (str & (Me.TextBox1.Text & 1 & 3).Replace(" ", "").Replace("a", "@").Replace("b", "1").Replace("c", "*").Replace("d", "4").Replace("e", "!").Replace("f", "#").Replace("g", "-").Replace("h", "%").Replace("i", ChrW(163)).Replace("j", "$").Replace("k", "^").Replace("l", "'").Replace("m", ".").Replace("n", "~").Replace("o", "+").Replace("p", "=").Replace("q", "2").Replace("r", "\").Replace("s", "9").Replace("t", "/").Replace("u", "6").Replace("v", ":").Replace("w", "8").Replace("x", "]").Replace("y", "7").Replace("z", "[") & (Me.TextBox1.Text.Length Xor i))
    Next i

TextBox2.Text = str

End Sub
End Class

- End Code ----------------------------------------

Now you see in TextBox2.Text the correct serial for your name in Textbox1.Text!
 -> or use my KeyGen!


Thanks to papanyquiL, it's nice one :D

Greez
 Filler









