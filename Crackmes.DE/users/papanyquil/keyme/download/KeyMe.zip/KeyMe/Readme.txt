This is my first keygenme submitted.  It was made and intended for beginners.  Once solved, I will post my source code (if requested).  Again, this is for beginners, if you're an accomplished cracker :P, this will probably be quite boring!

Rules:
*No brute-forcing
*No patching
*Create a working keygen

A special thanks to T.0.R.N.A.D.0. for giving out some of his source code to help me out in my quest for higher knowledge.  :D



-papanyquiL