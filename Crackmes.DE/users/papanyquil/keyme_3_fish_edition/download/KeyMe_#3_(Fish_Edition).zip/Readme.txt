KeyMe #3 (Fish Edition) - #3 in my KeyMe series.. Hopefully you'll figure out why I call it the 'Fish Edition.'  Hopefully you all enjoy it :D
Rules:
*I don't care... do whatever you want... but please make a keygen :P
*Write a small tut

Much appreciation toward T.0.R.N.A.D.0. and obnoxious for the help of their source code to aid me in my quest for higher knowledge. :D


************************************************UPDATED AND FIXED VERSION!***************************************************************************



-papanyquiL