The #2 in my 'KeyMe' series.. Promises to be much better (and more difficult) than my first.
Rules:
*No patching
*No brute-forcing
*Please write a small tut when solved
*Create a valid keygen

Much appreciation toward T.0.R.N.A.D.0. and obnoxious for the help of their source code to aid me in my quest for higher knowledge. :D


*****On a side note, DO NOT open this program if you're epileptic...*****

-papanyquiL