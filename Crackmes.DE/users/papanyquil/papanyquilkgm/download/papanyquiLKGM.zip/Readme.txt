My first time making a crackme in C++, and my first time doing any real coding in C++ to be exact.. ***Praise online learning resources***  Very simple encryption, try and crack it.  :D

Rules:
*No patching
*No brute-forcing
*If you're not too busy, make a valid keygen and tut -_-

Greetz to all my friends at crackmes.de

-papanyquiL

P.S. - If you're saying to yourself, "Wow, this guy has posted 3 crack/keygenme's in 3 days.  He must be some kind of non-sleeping craftaholic..."  Yes, this is pretty much ALL I do now.  My new found hobby.  Thanks for everyone's support through my learning of the trade.