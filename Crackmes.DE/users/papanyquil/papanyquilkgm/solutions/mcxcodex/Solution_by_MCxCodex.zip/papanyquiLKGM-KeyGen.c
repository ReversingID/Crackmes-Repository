#include <stdio.h>
#include<string.h>
#include<conio.h>

void main()
{
	printf("------------------------------------\n");
	printf("----- KeyGen for papanyquiLKGM -----\n");
	printf("------------------------------------\n");
	printf("---------- By MCxCodex -------------\n");
	printf("------------------------------------\n");
	printf("\nInsert Username: ");

	char username[255];
	int i=0, Lenght=0;

	gets(username);
	Lenght=strlen(username);
	printf("\nPassword: ");

	for(i=0; i<Lenght; i++)
	{
	  username[i] += 2;		
	}
	
	printf("%s", username);
	printf("\n\n\nPress any key to quit...");
	getch();	
}