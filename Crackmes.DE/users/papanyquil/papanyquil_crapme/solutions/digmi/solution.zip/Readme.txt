DDDDDDDDDDDDD           iiii          GGGGGGGGGGGGG MMMMMMMM               MMMMMMMM   iiii  
D::::::::::::DDD       i::::i      GGG::::::::::::G M:::::::M             M:::::::M  i::::i 
D:::::::::::::::DD      iiii     GG:::::::::::::::G M::::::::M           M::::::::M   iiii  
DDD:::::DDDDD:::::D             G:::::GGGGGGGG::::G M:::::::::M         M:::::::::M         
  D:::::D    D:::::D  iiiiiii  G:::::G       GGGGGG M::::::::::M       M::::::::::M iiiiiii 
  D:::::D     D:::::D i:::::i G:::::G               M:::::::::::M     M:::::::::::M i:::::i 
  D:::::D     D:::::D  i::::i G:::::G               M:::::::M::::M   M::::M:::::::M  i::::i 
  D:::::D     D:::::D  i::::i G:::::G    GGGGGGGGGG M::::::M M::::M M::::M M::::::M  i::::i 
  D:::::D     D:::::D  i::::i G:::::G    G::::::::G M::::::M  M::::M::::M  M::::::M  i::::i 
  D:::::D     D:::::D  i::::i G:::::G    GGGGG::::G M::::::M   M:::::::M   M::::::M  i::::i 
  D:::::D     D:::::D  i::::i G:::::G        G::::G M::::::M    M:::::M    M::::::M  i::::i 
  D:::::D    D:::::D   i::::i  G:::::G       G::::G M::::::M     MMMMM     M::::::M  i::::i 
DDD:::::DDDDD:::::D   i::::::i  G:::::GGGGGGGG::::G M::::::M               M::::::M i::::::i
D:::::::::::::::DD    i::::::i   GG:::::::::::::::G M::::::M               M::::::M i::::::i
D::::::::::::DDD      i::::::i     GGG::::::GGG:::G M::::::M               M::::::M i::::::i
DDDDDDDDDDDDD         iiiiiiii        GGGGGG   GGGG MMMMMMMM               MMMMMMMM iiiiiiii

                      .-----------------------------------------------.
                      |     papanyquiL CrapME - Solution by DiGMi     |
                      '-----------------------------------------------'
 
Tools:
	(*) Reflector - http://www.red-gate.com/products/reflector/
	(*) Microsoft Visual Studio 2005 (or higher)

Introduction:
	papanyquiL decided to build his crackme using .NET. Therefore, we can easily "reverse 
	engineer" the executable and take a look at the source code using Reflector. After 
	looking at the source code the obvious solution would be to copy the code in order to
	create our keygen. Here we will see a simplier way that will create a keygen in a few
	simple steps.

Instructions:
1) Run the executable and take a look at the crackme.
   You should see 2 textboxes(Username and Serial) and 2 buttons (exit, and another
   disabled button which stay that way no matter what we do).
2) Run Reflector and open the crackme's executable.
3) In the left side of the application you should see a tree view, expand the node
   "papnyquiL CrapME". Now you should see all the namespaces that this .net assembly
   has. expand "papanyquiL_CrapME" namespace.
4) As you can see, there are several classes in this namespace:
	* Form1
	* Genome
	* Population
	* Program
	* SudokuGenome
	* ValidateMe
   You can probably guess that Form1 is the class wrapping the form we saw when we ran
   the executable.
   Right click on Form1 and click "Disassemble".
5) At the right side of the application should now appear the decleration of Form1.
   Have you noticed two important functions?
   That's right!
	(*) private void txtUsername_TextChanged(object sender, EventArgs e)
	(*) private void btnValidate_Click(object sender, EventArgs e)
6) Do you remember that the other button in the executable was disabled?
   Lets check "txtUsername_TextChanged" and see what we can do inorder to change that.
.------------------------------------------------------------------.
| private void txtUsername_TextChanged(object sender, EventArgs e) |
| {                                                                |
|     ValidateMe me = new ValidateMe(this.txtUsername.Text);       |
|     if (me.IsValidated(this.txtUsername.Text))                   |
|     {                                                            |
|         this.btnValidate.Enabled = true;                         |
|     }                                                            |
|     else if (this.txtUsername.Text == "")                        |
|     {                                                            |
|         this.btnValidate.Enabled = false;                        |
|     }                                                            |
| }                                                                |
'------------------------------------------------------------------'
   As we can see, every time we change the text in the usename textbox a new instance of
   ValidateMe is created and IsValidated is called in order to determine whether the 
   username is valid or not. So we just need IsValidated to return true.
   Lets take a look at IsValidated:
.------------------------------------------------------------------.
| public bool IsValidated(string stuff)                            |
| {                                                                |
|     try                                                          |
|     {                                                            |
|         if (stuff.Contains("@") && (stuff.Length >= 6))          |
|         {                                                        |
|             return true;                                         |
|         }                                                        |
|     }                                                            |
|     catch (Exception exception)                                  |
|     {                                                            |
|         MessageBox.Show(exception.Message);                      |
|     }                                                            |
|     return false;                                                |
| }                                                                |
'------------------------------------------------------------------'
   This function will return true only if the input (username in our case) will be at
   least 6 charcters long and will contain at least one '@'.
   Try it! It will now enable the validate button!
   But when you clicked it you got the following message box
---------------------------
Try Again
---------------------------
It was a good try; just not good enough.
---------------------------
OK   
---------------------------
7) Now lets take a look at btnValidate_Click function and see how does the software
   validate our serial
.---------------------------------------------------------------------------------------.
| private void btnValidate_Click(object sender, EventArgs e)                            |
| {                                                                                     |
|     try                                                                               |
|     {                                                                                 |
|         if (!this.Congrats(this.txtUsername.Text))                                    |
|         {                                                                             |
|             MessageBox.Show("It was a good try; just not good enough.", "Try Again"); |
|         }                                                                             |
|     }                                                                                 |
|     catch (Exception exception)                                                       |
|     {                                                                                 |
|         MessageBox.Show(exception.Message);                                           |
|     }                                                                                 |
| }                                                                                     |
'---------------------------------------------------------------------------------------'
   If congrats returns "false" we will gate a failure message, but if it returns true
   nothing happens?!
   Lets take a look at Congrats:
.---------------------------------------------------------------------------------------.
| public bool Congrats(string username)                                                 |
| {                                                                                     |
|     string password = username + this.pass;                                           |
|     string clearText = this.genome.CalculateFitness().ToString();                     |
|     string str3 = this.Encrypt(clearText, password);                                  |
|     try                                                                               |
|     {                                                                                 |
|         if (this.txtKey.Text == str3)                                                 |
|         {                                                                             |
|             MessageBox.Show("Congratulations, now write a tutorial!", "Success!");    |
|             return true;                                                              |
|         }                                                                             |
|     }                                                                                 |
|     catch (Exception exception)                                                       |
|     {                                                                                 |
|         MessageBox.Show(exception.Message);                                           |
|     }                                                                                 |
|     return false;                                                                     |
| }                                                                                     |
'---------------------------------------------------------------------------------------'
   The important line here is: "if (this.txtKey.Text == str3)"
   It seems like the program does some calculations using the username and them just
   comapres the result with the serial textbox.
   Taking a quick look on the constructor of Form1 we will see two important details:
       1. this.pass = "234Adfz#;dkf#ggFF12312DFE";
       2. this.genome = new SudokuGenome();
   So all we need to do is just reproduce the code and use str3 as the keygen.
   We can start investigate how this.Enctypt works, and what this.genome.CalculateFitness
   does, or just take it for granted.
   I chose the second object.
8) Create a new .NET Application and add the executable as reference.
   All you need to do is to create SudokuGenome instance, call the CalculateFitness method
   Create a form instance and call the encrypt method with the right information.
   See the application added, it's that simple.


	I hope I was clear enough. This is my first real tutorial.

DDDDDDDDDDDDD           iiii          GGGGGGGGGGGGG MMMMMMMM               MMMMMMMM   iiii  
D::::::::::::DDD       i::::i      GGG::::::::::::G M:::::::M             M:::::::M  i::::i 
D:::::::::::::::DD      iiii     GG:::::::::::::::G M::::::::M           M::::::::M   iiii  
DDD:::::DDDDD:::::D             G:::::GGGGGGGG::::G M:::::::::M         M:::::::::M         
  D:::::D    D:::::D  iiiiiii  G:::::G       GGGGGG M::::::::::M       M::::::::::M iiiiiii 
  D:::::D     D:::::D i:::::i G:::::G               M:::::::::::M     M:::::::::::M i:::::i 
  D:::::D     D:::::D  i::::i G:::::G               M:::::::M::::M   M::::M:::::::M  i::::i 
  D:::::D     D:::::D  i::::i G:::::G    GGGGGGGGGG M::::::M M::::M M::::M M::::::M  i::::i 
  D:::::D     D:::::D  i::::i G:::::G    G::::::::G M::::::M  M::::M::::M  M::::::M  i::::i 
  D:::::D     D:::::D  i::::i G:::::G    GGGGG::::G M::::::M   M:::::::M   M::::::M  i::::i 
  D:::::D     D:::::D  i::::i G:::::G        G::::G M::::::M    M:::::M    M::::::M  i::::i 
  D:::::D    D:::::D   i::::i  G:::::G       G::::G M::::::M     MMMMM     M::::::M  i::::i 
DDD:::::DDDDD:::::D   i::::::i  G:::::GGGGGGGG::::G M::::::M               M::::::M i::::::i
D:::::::::::::::DD    i::::::i   GG:::::::::::::::G M::::::M               M::::::M i::::::i
D::::::::::::DDD      i::::::i     GGG::::::GGG:::G M::::::M               M::::::M i::::::i
DDDDDDDDDDDDD         iiiiiiii        GGGGGG   GGGG MMMMMMMM               MMMMMMMM iiiiiiii