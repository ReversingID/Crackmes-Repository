using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using papanyquiL_CrapME;

namespace Keygen
{
	public partial class frmMain : Form
	{
		public frmMain()
		{
			InitializeComponent();
		}

		private void _txtUsername_TextChanged(object sender, EventArgs e)
		{
			ValidateMe validator = new ValidateMe(_txtUsername.Text);
			_btnGenerate.Enabled = validator.IsValidated(_txtUsername.Text);
		}

		private void _btnGenerate_Click(object sender, EventArgs e)
		{
			using (Form1 frm = new Form1())
			{
				string password = _txtUsername.Text + "234Adfz#;dkf#ggFF12312DFE"; 
				string clearText = new SudokuGenome().CalculateFitness().ToString();
				_txtSerial.Text = frm.Encrypt(clearText, password);
			}
		}
	}
}