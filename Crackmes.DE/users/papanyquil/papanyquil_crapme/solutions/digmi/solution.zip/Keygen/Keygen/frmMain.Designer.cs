namespace Keygen
{
	partial class frmMain
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Windows.Forms.Label _lblUsername;
			System.Windows.Forms.Label _lblSerial;
			System.Windows.Forms.Label _lblNote;
			this._btnGenerate = new System.Windows.Forms.Button();
			this._txtUsername = new System.Windows.Forms.TextBox();
			this._txtSerial = new System.Windows.Forms.TextBox();
			_lblUsername = new System.Windows.Forms.Label();
			_lblSerial = new System.Windows.Forms.Label();
			_lblNote = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// _btnGenerate
			// 
			this._btnGenerate.Enabled = false;
			this._btnGenerate.Location = new System.Drawing.Point(430, 57);
			this._btnGenerate.Name = "_btnGenerate";
			this._btnGenerate.Size = new System.Drawing.Size(75, 23);
			this._btnGenerate.TabIndex = 0;
			this._btnGenerate.Text = "&Generate";
			this._btnGenerate.UseVisualStyleBackColor = true;
			this._btnGenerate.Click += new System.EventHandler(this._btnGenerate_Click);
			// 
			// _lblUsername
			// 
			_lblUsername.AutoSize = true;
			_lblUsername.Location = new System.Drawing.Point(12, 9);
			_lblUsername.Name = "_lblUsername";
			_lblUsername.Size = new System.Drawing.Size(58, 13);
			_lblUsername.TabIndex = 1;
			_lblUsername.Text = "Username:";
			// 
			// _txtUsername
			// 
			this._txtUsername.Location = new System.Drawing.Point(76, 6);
			this._txtUsername.Name = "_txtUsername";
			this._txtUsername.Size = new System.Drawing.Size(429, 20);
			this._txtUsername.TabIndex = 2;
			this._txtUsername.TextChanged += new System.EventHandler(this._txtUsername_TextChanged);
			// 
			// _txtSerial
			// 
			this._txtSerial.Location = new System.Drawing.Point(76, 32);
			this._txtSerial.Name = "_txtSerial";
			this._txtSerial.ReadOnly = true;
			this._txtSerial.Size = new System.Drawing.Size(429, 20);
			this._txtSerial.TabIndex = 4;
			// 
			// _lblSerial
			// 
			_lblSerial.AutoSize = true;
			_lblSerial.Location = new System.Drawing.Point(12, 35);
			_lblSerial.Name = "_lblSerial";
			_lblSerial.Size = new System.Drawing.Size(36, 13);
			_lblSerial.TabIndex = 3;
			_lblSerial.Text = "Serial:";
			// 
			// _lblNote
			// 
			_lblNote.AutoSize = true;
			_lblNote.Location = new System.Drawing.Point(13, 62);
			_lblNote.Name = "_lblNote";
			_lblNote.Size = new System.Drawing.Size(371, 13);
			_lblNote.TabIndex = 5;
			_lblNote.Text = "Username must be at least 6 charcters long and must contain at least one \'@\'";
			// 
			// frmMain
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(517, 92);
			this.Controls.Add(_lblNote);
			this.Controls.Add(this._txtSerial);
			this.Controls.Add(_lblSerial);
			this.Controls.Add(this._txtUsername);
			this.Controls.Add(_lblUsername);
			this.Controls.Add(this._btnGenerate);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.Name = "frmMain";
			this.Text = "papanyquiL CrapME Keygen - by DiGMi";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox _txtUsername;
		private System.Windows.Forms.TextBox _txtSerial;
		private System.Windows.Forms.Button _btnGenerate;
	}
}

