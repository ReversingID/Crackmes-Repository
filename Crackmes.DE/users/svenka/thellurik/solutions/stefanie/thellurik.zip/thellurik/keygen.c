#include <stdio.h>
#include <string.h>

#define CONSTANT1	("1337")

int main(int t, char **c)
{
	char buf[20], buf2[20];
	int i, len;
	unsigned long sum;


	if (t < 2) {
		fprintf(stderr, "usage: %s name\n", *c);
		return -1;
	}

	len = strlen(c[1]);

	for (i=sum=0; i < len; i++) 
		sum += c[1][i];
	

	sum += 0x3a2f49;

	sum <<=(c[1][0] & 0xff);
	sum ^= 0x1337;

	sprintf(buf, "%lu", sum);
	sprintf(buf2, "~%s#%s#~", CONSTANT1, buf);
	printf("name: %s\n", c[1]);
	printf("c0de: %s\n", buf2);

	return 0;
}
