/* fixthelurric.c
 * fix relevant elf components of thelluric crackme
 * - niel
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <elf.h>
#include <string.h>

#define _err(x)	((x) < 0 ? 1 : 0)

static int not_elf(Elf32_Ehdr *h)
{
	return (strncmp(ELFMAG, h->e_ident, SELFMAG)) ? 1 : 0;
}

int main(int t, char **c)
{
	int fd, i;
	char *map;
	struct stat st;
	Elf32_Shdr *s;
	Elf32_Ehdr *h;


	const char crackme[] = "thellurik";

	fd = open(crackme, O_RDWR);
	if (_err(fd)) {
		perror("open file");
		exit(2);
	}

	if (_err(stat(crackme, &st))) {
		perror("get stat file");
		exit(3);
	}

	if (!st.st_size) {
		fprintf(stderr, "file is empty\n");
		exit(4);
	}

	map = mmap(0, st.st_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	if (_err(map)) {
		perror("mmap file");
		exit(5);
	}

	h = (Elf32_Ehdr *) map;
	if (not_elf(h)) {
		fprintf(stderr, "file is not an ELF file\n");
		goto clean;
	}

	s = (Elf32_Shdr *)((char *)h + h->e_shoff);

	int ctr;


	/* after locating the SHT_STRTAB in question
	 * (there are 3 of this actually), we correct the offset entry to point
	 * to the correct offset.
	 *
	 * now, this requires a bit of looking thru a hexdump to find a block
	 * that contains some "usual" strings like .symtab .text .got.plt etc...
	 */
	for (i = ctr = 0; i < h->e_shnum; i++, s++) {
		if (s->sh_type == SHT_STRTAB) {
			if (ctr == 1) {
				/* these values, i got from
				 * looking at the hexdump */
				s->sh_size = 0x11ff - 0x10d8;
				s->sh_entsize = 0;
				s->sh_offset = 0x10d8;
				break;
			}
			ctr++;
		}
	}


	/* finally, reflect the corrected SHT_STRTAB section in the elf header */
	h->e_shstrndx = i;

clean:
	munmap(map, st.st_size);
	close(fd);
	return 0;
}

