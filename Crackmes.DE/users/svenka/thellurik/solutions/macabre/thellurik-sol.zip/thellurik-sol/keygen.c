#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
	if(argc != 2) return -1;
	char *name = argv[1];
	int i,key=0;
	for(i=0;i<strlen(name);i++) key+=name[i];
	key= key + 0x3A2F49 << name[0] ^ 0x1337;
	printf("[x] c0de: ~1337#%lu#~\n",key);
}
