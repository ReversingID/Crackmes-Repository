// FJLJDlg.cpp : implementation file
//

#include "stdafx.h"
#include "FJLJ.h"
#include "FJLJDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFJLJDlg dialog

CFJLJDlg::CFJLJDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFJLJDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFJLJDlg)
	m_sName = _T("");
	m_sSerial = _T("");
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CFJLJDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFJLJDlg)
	DDX_Control(pDX, IDBGENERATE, m_ctlBgenerate);
	DDX_Text(pDX, IDC_ENAME, m_sName);
	DDV_MaxChars(pDX, m_sName, 15);
	DDX_Text(pDX, IDC_ESERIAL, m_sSerial);
	DDV_MaxChars(pDX, m_sSerial, 47);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CFJLJDlg, CDialog)
	//{{AFX_MSG_MAP(CFJLJDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_EN_CHANGE(IDC_ENAME, OnChangeEname)
	ON_BN_CLICKED(IDBGENERATE, OnBgenerate)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFJLJDlg message handlers

BOOL CFJLJDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CFJLJDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CFJLJDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CFJLJDlg::OnChangeEname() 
{
	UpdateData(true);

	if (m_sName.GetLength() < 4)
		m_ctlBgenerate.EnableWindow(false);
	else
		m_ctlBgenerate.EnableWindow(true);

	m_sSerial.Empty();

	UpdateData(false);
}

void CFJLJDlg::OnBgenerate() 
{
	UpdateData(true);
	
	CString sName(m_sName);

	for (int i = 0; i < sName.GetLength(); i++)
	{
		sName.SetAt(i, sName[i] ^ 0xDE);
		sName.SetAt(i, sName[i] - 0x7A);
		sName.SetAt(i, sName[i] + 0x30);
	}
	m_sSerial = sName + '-';

	for (i = 0; i < sName.GetLength(); i++)
	{
		sName.SetAt(i, sName[i] ^ 0xA2);
		sName.SetAt(i, sName[i] - 0xB2);
		sName.SetAt(i, sName[i] + 0x30);
	}
	m_sSerial += sName + '-';

	for (i = 0; i < sName.GetLength(); i++)
	{
		sName.SetAt(i, sName[i] ^ 0xF2);
		sName.SetAt(i, sName[i] - 0x8E);
		sName.SetAt(i, sName[i] + 0x30);
	}
	m_sSerial += sName;

	UpdateData(false);
}
