// FJLJ.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "FJLJ.h"
#include "FJLJDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFJLJApp

BEGIN_MESSAGE_MAP(CFJLJApp, CWinApp)
	//{{AFX_MSG_MAP(CFJLJApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFJLJApp construction

CFJLJApp::CFJLJApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CFJLJApp object

CFJLJApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CFJLJApp initialization

BOOL CFJLJApp::InitInstance()
{
	// Standard initialization

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	CFJLJDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
	}
	else if (nResponse == IDCANCEL)
	{
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
