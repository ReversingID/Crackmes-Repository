ok so this is my first real crackme and i hope it isnt too easy.
i tried to throw in a few "tricks" :) mainly just so that the
noobs that first look at text strings will get very discouraged
quickly. i hope that when this is solved the tutorial will be a
great learning utility for all noobs :). i will be writing a tut
after a number of people have solved it. now for the rules :).

1. if you are going to take the patching route, it may only be done delicatley.
   no changing messages to make a badboy look like a good boy. hmmm nah lets
   make this a keygen only, unless you are submitting a patched version with a
   keygen. i will gladley take artisting patching solutions, and look forward
   to viewing them. but please make a keygen first :)

2. number one just about covered everything. so i wont talk your ear of anymore.
   crack it and have fun doing so. drop me a message or an email when you are
   done :) rubymaster3000@gmail.com.


good luck and i look forward to seeing many solutions :)

FJLJ