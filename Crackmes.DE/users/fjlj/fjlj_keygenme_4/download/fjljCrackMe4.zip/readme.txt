i expect a keygen for the solution.
no self keygenning..

good luck :)