FJLJ Crackme #2
By: TCM

Instructions:

1. Double Click Keygen.exe
2. Copy Information and Paste it into the program.