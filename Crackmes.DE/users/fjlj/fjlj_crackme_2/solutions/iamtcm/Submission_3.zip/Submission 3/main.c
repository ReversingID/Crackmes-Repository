//Coded on November 17th, 2009 by TCM
//Tea: Irish Breakfast
//Music: Fuck Buttons - Tarot Sport (2009)
//Disassembler/Debugger: OllyDbg 1.10
//Compiler: Dev-C++ 4.9.9.2

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>

uint32_t GOAL; 
uint32_t uAddr;

void doUsername(char * username) //Our username hash function
{
	uint32_t addrOne = 0x0043F200; //Hardcoded address

	int val = 0;
	int count = 0;
	int length = strlen(username);
	
	while(count != length)
		val = (val + username[count++]) & 0xFF;
	addrOne += val;
	
	GOAL = addrOne; //Setting up the goal address
	
	addrOne+= (addrOne ^ 0x43F200) + 0x10;
	uAddr = addrOne; //Setting up an address needed for the serial function
}

uint32_t doSerial(char * serial) //The Serial's hash Compute function
{
	int count;
	uint32_t addrOne = uAddr;

	
	for(count = 0; count < strlen(serial); count++) //Round 1 (value add)
		addrOne+= (uint8_t)serial[count];

	for(count = strlen(serial)-2; count >= 0; count=count-2) //Round 2 (half subtract)
		addrOne-= (uint8_t)serial[count];
	
	for(count = 0; count < strlen(serial); count = count + 4) //Round 3 (1/4 to the power 4)
		addrOne-= (serial[count] & 0xFF) << 4;

	addrOne += 0x4D6; //Plus a fancy constant
	return addrOne;
}

char * bruteLoop() //mmmmm breakfast
{
	char * guess;
	int lposCount = 0;
	int lowerPositions[6] = {7,5,3,1}; //These positions in the serial will lower the value of our hash
	int hposCount = 0;
	int higherPositions[2] = {0,4}; //These positions in the serial will raise the value of the hash
	uint32_t diff;
	
	guess = malloc(sizeof(char) * 9);
    if(guess == null)
             return - 1; //No memory :(
             
	strcpy(guess, "00000000"); //We always start with a hashes of all 0's, fairly arbitrary

	diff = goalDiff(doSerial(guess)); //Calculate the different in the serial/username hash
	

    //The Hash Tweeker
	while(diff != 0)
	{
		if (((int32_t)diff) < 0 ) //Negative Numbers need to be overflower to positive
		{
			uint32_t negDiff = 0xFFFFFFFF - diff;
			negDiff = negDiff >> 4;
			negDiff++;

			if(negDiff >= 0x4A)
				guess[higherPositions[hposCount++]] = 'z';
			else if(negDiff >=0x31)
				guess[higherPositions[hposCount++]] = 'a' + (negDiff-0x31);
			else if(negDiff >=0x2A)
				guess[higherPositions[hposCount++]] = 'Z';
			else if(negDiff >=0x11)
				guess[higherPositions[hposCount++]] = 'A' + (negDiff-0x11);
			else if(negDiff >=0x9)
				guess[higherPositions[hposCount++]] = '9';
			else
				guess[higherPositions[hposCount++]] = '0'+negDiff;
		}
		else  //Positive numbers need to be lowered to zero
		{
			if(diff >= 0x4A)
				guess[lowerPositions[lposCount++]] = 'z';
			else if(diff >=0x31)
				guess[lowerPositions[lposCount++]] = 'a' + (diff-0x31);
			else if(diff >=0x2A)
				guess[lowerPositions[lposCount++]] = 'Z';
			else if(diff >=0x11)
				guess[lowerPositions[lposCount++]] = 'A' + (diff-0x11);
			else if(diff >=0x9)
				guess[lowerPositions[lposCount++]] = '9';
			else
				guess[lowerPositions[lposCount++]] = '0'+diff;
		}
		diff = goalDiff(doSerial(guess));
	}
	return guess;
}
	
int goalDiff(uint32_t address) //Almost entirely useless, nice!
{
	return GOAL-address;
}


int main()
{
	char username[9]; //Max username is 8 characters
	char * serial;
	int preComputedAddress = 0;
	memset(username, 0, 9);

	printf("Enter a username: ");
	scanf("%s", username);

	doUsername(username);
	serial = bruteLoop();

	printf("Username:\t%s\nSerial:\t\t%s\n",username,serial); 	
    system("pause");		

	return 0;
}
