#include <iostream>
#include <conio.h>
using namespace std;
int getrand(int imin=0x30,int imax=0x39);
int serailChecsum(unsigned char *,int );
int main(int argc, char* argv[])
{	
	cout<<"name ? \n";
	char  *name = new char;
	cin >> name;
	unsigned char i1=0;
	int l = strlen(name);
	for (int i = 0; i <  l; i++)
	{
		i1 += (char) name[i] ;
	}
	unsigned int nameCheckSum = 0x43f200;
	nameCheckSum +=i1;
	unsigned int i5 = nameCheckSum+i1+0x10;
	unsigned int sCheckSum = 0;
	unsigned char serial[9]	={getrand(),0,getrand(),getrand(),getrand(),0,getrand(),getrand(),0};
	sCheckSum = serailChecsum(&serial[0],i5);
	int diff = nameCheckSum-sCheckSum;
	unsigned char ic1=0,ic0=0;
	while (diff > 122 *2 )
	{
		serial[3] = int(serial[3])-30 + 97;
		sCheckSum = serailChecsum(&serial[0],i5);
		diff = nameCheckSum-sCheckSum;
	}
	while (1)	
	{
		 ic0 = getrand(0x41,0x5a);
		 ic1 = diff-ic0;
		if ((ic1 < 0x7a && ic1 > 0x61) || (ic1 < 0x5a && ic1 > 0x41)) break;
	}
	serial[1]= ic0;
	serial[5]=ic1;
	sCheckSum = serailChecsum(serial,i5);
	diff = nameCheckSum-sCheckSum;
	cout <<"serial " << serial <<"\nPress any key to quit";
	_getch();
return 0;
}

int serailChecsum( unsigned char *serial,int i5){
	int ct = 8;
	for (int i = 0; i < ct ; i++)
	{
		i5+=serial[i];
	}	
	for (int i = 0; i < ct/2; i++)
	{
		unsigned char ichar = serial[i*2];
		i5-= (int) ichar ;
	}
	for (int i = 0; i <  ct/4; i++)
	{
		unsigned  char ichar =serial[i*4];
		unsigned int c =  ichar<< 4;
		i5-=  c;

	}
	
	return i5+=0x4d6;
}

int getrand(int imin,int imax){
	 int rnm = (double)rand() / (RAND_MAX + 1) * (imax -imin )+imin;
	 return rnm;
}
