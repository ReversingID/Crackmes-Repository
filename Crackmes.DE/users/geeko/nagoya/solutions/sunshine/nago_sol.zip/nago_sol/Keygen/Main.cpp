/*
 * Key Generator for geeko's nagoya crackme
 *
 * visit: www.sunshine2k.de
 * Sunshine, November 2k6
 */



#include <windows.h>
#include "Resource.h"


int GenSerial(LPSTR szNumber)
{
	int len = lstrlen(szNumber);
	int eax = 0;
	int ebx = 0;
	int bl = 0;

	for (int i = 0; i < len; i++)
		szNumber[i] = szNumber[i] - 0x30;

	for (int i = 0; i < len; i++)
	{
		eax = eax << 1;
		ebx = eax;
		eax = eax << 1;
		eax = eax << 1;
		bl = ebx & 0x000000FF;
		bl += szNumber[i];
		ebx = ebx & 0xFFFFFF00;
		ebx = ebx | bl;
		eax += ebx;
	}

	for (int i = 0; i < len; i++)
		szNumber[i] = szNumber[i] + 0x30;

	return eax;
}

void Generate(HWND hwnd)
{
	char temp[10];
	ZeroMemory(temp, 10);

	for (int i = 0; i < 999999; i++)
	{
		wsprintf(temp, "%d",i);
		if (GenSerial(temp) == 0x3039)
		{
			SendMessage(GetDlgItem(hwnd, ID_KEYLIST), LB_INSERTSTRING, -1, (LPARAM)"The serial is:");
			SendMessage(GetDlgItem(hwnd, ID_KEYLIST), LB_INSERTSTRING, -1, (LPARAM)temp);
		}
	}

}

BOOL DlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{

	switch(msg)
	{
	case WM_CLOSE:
		{
			EndDialog(hwnd, 0);
			PostQuitMessage(0);
		}
		break;

	case WM_COMMAND:
		{
			switch (wParam)
			{
			case ID_GENBUTTON:
				{
					ShowWindow(GetDlgItem(hwnd, ID_WAITLABEL), SW_SHOW);
					UpdateWindow(hwnd);
					Generate(hwnd);
					ShowWindow(GetDlgItem(hwnd, ID_WAITLABEL), SW_HIDE);
				}
				break;

			case ID_ABOUT:
				{
					MessageBox(hwnd, "Bruteforces the key for geeko's nagoya crackme\n\n"
									 "--------------------------------\n"
									 "Visit my site: www.sunshine2k.de\n"
									 "Sunshine, November 2k6", "About...", MB_ICONINFORMATION);
				}
				break;

			default:break;
			}
		}
		break;


	default:break;

	}
	return FALSE;
}


int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{

	DialogBoxParamA(hInstance, MAKEINTRESOURCE(101), NULL, (DLGPROC)DlgProc, NULL);
	return 0;
}