what we have learned from Evolution 1:

As we saw in 'Evolution1' crackme's solutions, storing the password hardencoded in exe, especialy near the pass checking routine, is very bad, as a guy said: 'just 30 seconds crack'.
So let's work just a little bit on this bad practice: evolution 2;

In this crackme you have to do anything you want to play the little game.

thanx to boon,reenox,tornado and all

