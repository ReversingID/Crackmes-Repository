/* Replace "dll.h" with the name of your header */
#include "dll.h"
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <fstream.h>

BOOL CALLBACK EnumChildProc(HWND hwndChild, LPARAM lParam) {
    char window_class[200];
    char text[2000];
    int lenght;
    ofstream costy;

     if (hwndChild != 0){
          //each time the function find an object get its class         
          GetClassName(hwndChild, window_class,200);
          //the class of the textbox is TMemo
          //You can find it with windowjuggler an olly plugin
          //or an utility called Spy++
          if (strcmp("TMemo", window_class)==0){
               //The dll is called when the "Save" Button get the focus.
               //So the "Save" Button must lose the focus
               //or this dll would be called a lot of times
               //With the next istruction the textbox get the focus
               SetFocus(hwndChild);
               //Get the text lenght inside the textbox
               lenght=GetWindowTextLength(hwndChild);
               //get the text
               GetWindowText(hwndChild, text, lenght);
               //Save the text in a file called "costy007.txt"
               //In the crackme directory
               costy.open("costy007.txt");
               costy<<text;
               costy.close();
               //Well done!
               MessageBox(0, "OK", "OK",0);
               //Don't search other object i already founded
               //the text box
               return FALSE;
               }             
          //this isn't a text box search again 
          return TRUE;
          }
     else
         //If the dll arrives here there is a great problem
         //Becouse the textbox hasn't been founded
         //Anyway I tried a lot of time
         //It never arrives here.
         return FALSE;
     }
     
DLLIMPORT void SAVE (void)
{   

    HWND main_form;      
    //Get The Crackme Window
    main_form=GetActiveWindow();
    //scan all object inside the window
    EnumChildWindows(main_form, EnumChildProc, 0);
}




BOOL APIENTRY DllMain (HINSTANCE hInst     /* Library instance handle. */ ,
                       DWORD reason        /* Reason this function is being called. */ ,
                       LPVOID reserved     /* Not used. */ )
{
    switch (reason)
    {
      case DLL_PROCESS_ATTACH:
        break;

      case DLL_PROCESS_DETACH:
        break;

      case DLL_THREAD_ATTACH:
        break;

      case DLL_THREAD_DETACH:
        break;
    }

    /* Returns TRUE on success, FALSE on failure */
    return TRUE;
}

//written by costy
