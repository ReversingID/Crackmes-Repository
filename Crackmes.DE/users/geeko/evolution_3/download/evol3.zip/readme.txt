what we have learned from Evolution 2:

Keeping hard encoded password (clear text) in the exe is again a bad idea, even it has a tricky name, or is put far from checking routine.
So let's work just a little bit on this bad practice: evolution 3;

In this crackme you have to do anything you want to play the little game.

thanx to obnoxious,tornado and all

