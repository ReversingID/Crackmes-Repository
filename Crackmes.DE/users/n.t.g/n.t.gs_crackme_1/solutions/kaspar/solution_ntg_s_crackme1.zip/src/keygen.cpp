#include <stdio.h>
#include <windows.h>
#include "resource.h"
#include <fstream>

using namespace std ;

HINSTANCE	hInst;

BOOL CALLBACK DialogProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	TCHAR Name[20];
	DWORD Serial[20];

	int count=0x10;
	int teller=0;

	TCHAR szSerial[100] = {0};


	switch (message)
	{    
	case WM_CLOSE:
		EndDialog(hWnd,0);
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDCANCEL:
			EndDialog(hWnd, IDCANCEL);
			break;

		case IDGEN:
		
				GetDlgItemText(hWnd,IDC_EDIT1,Name,20);
				__asm{
					     push ebx
							 push esi
							 push edi
						//	 push eax							 
							 lea ebx,Name
DRIE:MOVSX ESI,BYTE PTR DS:[EBX]
							 IMUL ESI,ESI,0x1BE
							 inc count
							 MOV EAX,count
							 PUSH 1
							 XOR EAX,0x253E
							 ADD EAX,ESI
							 POP ESI
							 CMP teller,ESI
							 JNZ EEN
							 IMUL EDI,EDI,-0x15
							 ADD EAX,EDI
EEN:TEST EAX,EAX
							 mov teller,ESI
							 MOV EDI,EAX
							 JNZ TWEE
							 PUSH 2D
							 POP EDI
TWEE:INC EBX
							 CMP BYTE PTR DS:[EBX],0x0
							 JNZ DRIE
							 AND EDI,0x1E8E
							 IMUL EDI,EDI,0x178
							 CMP EDI,0x0F423F
							 JGE VIER
							 LEA EDI,DWORD PTR DS:[EDI+EDI*2]
VIER:XOR ECX,ECX
	                         MOV EAX,EDI
							 TEST EDI,EDI
							 JE VIJF
ZES:PUSH 0x0A
							 XOR EDX,EDX
							 POP EBX
							 DIV EBX
							 INC ECX
							 TEST EAX,EAX
							 JNZ ZES
VIJF:MOV EAX,ECX
	                         PUSH 2
							 CDQ
							 POP EBX
							 mov count,ECX
							 IDIV EBX
							 TEST EDX,EDX
							 JNZ ZEVEN
							 AND BYTE PTR SS:[EBP+ECX-0x2C],DL
							 JMP ACHT
ZEVEN:MOV BYTE PTR SS:[EBP+ECX-0x2C],0x4E
	                         AND BYTE PTR SS:[EBP+ECX-0x2B],0x0
							 INC ECX
							 MOV EAX,ECX
							 DEC ECX
							 mov count,EAX
ACHT:DEC ECX
							 JS NEGEN
							 MOV EAX,EDI
							 PUSH 0x0A
							 CDQ
							 POP EBX
							 IDIV EBX
							 MOV EAX,EDI
							 PUSH EBX
							 POP EDI
							 ADD DL,0x30
							 MOV BYTE PTR SS:[EBP+ECX-0x2C],DL
							 CDQ
							 IDIV EDI
							 MOV EDI,EAX
							 JMP ACHT


NEGEN:LEA EAX,DWORD PTR DS:[EBP+ECX-0x2B]
	                         mov Serial,EAX
							 MOV EBX,EAX
							 MOV ESI,[EAX]
							 XOR EAX,EAX
							 pop edi
						     pop esi
							 pop ebx
				}

				wsprintf(szSerial,"%s",*Serial);

				SetDlgItemText(hWnd,IDC_EDIT2,szSerial);
				for(int i=1;i<8;i++)
				{
					szSerial[i]=szSerial[i*2];
				}

				ofstream ofstr;
				ofstr.open("ntg.ntg");
				ofstr << szSerial;
				ofstr.close();


			break;
		
		}
		break;

	}
     return 0;
}

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{
	hInst=hInstance;
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, (DLGPROC)DialogProc,0);
	return 0;
}