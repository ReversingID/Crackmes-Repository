Only 3 steps:

1* - Enable The form.
2* - Make an Button that will close the application... 
3* - write a tutorial!


Good Luck!
