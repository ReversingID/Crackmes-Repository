*******************
*    README!      *
*                 *
*******************

Rules:

1. Enable Serial Textbox.
2. Get Rid of the Serial textbox Nasty Nag!!
3.Enable The Register Button.
4.Get Rid of Register Button Nag!
5.Stop it From Closing!
6.Make The Program accept any Serial.
7.Remake the message 'WRONG' to 'Right!'
8.Write a Solution!

Good Luck!

Megadactor... 
