It's very simple:
Just solve the program will end after pressing 'enter'.
Enjoy! :-)

Additional ( no must ):
Write a patch!

14/09/2007 - NrZ0e1