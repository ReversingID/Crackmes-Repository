Public Class Form1

    Private Sub btnGenerate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGenerate.Click
        Dim num As Integer = Strings.Len(Me.txtUsername.Text)
        Dim num2 As Integer = ((num + &H51) + &H231F)
        Dim str3 As String = (Strings.StrReverse(Strings.Mid(Me.txtUsername.Text, 2, 3)) & "d- " & CStr(num2) & CStr(num))

        txtSerial.Text = str3
    End Sub

    Private Sub btnAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAbout.Click
        MsgBox("halsten (C) 2007", MsgBoxStyle.Information)
    End Sub
End Class
