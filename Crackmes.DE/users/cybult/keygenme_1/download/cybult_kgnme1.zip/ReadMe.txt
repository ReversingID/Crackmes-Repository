//*//*//*//*//*//*//*//*//*//*//*//*//*//*//*//*//*//
     K e y g e n M e   v 1. 0   b y   c y b u l t  
//*//*//*//*//*//*//*//*//*//*//*//*//*//*//*//*//*//

Hi, as usual, you must write a full working
keygen and let me know about your nice
success via email cybult@poczta.onet.pl
you can use  anything  to solve thizz little
crackme, even your girlfriend's breasts ;)

Good luck, cybult             April 12th 2002

cybult
cybult@poczta.onet.pl