--2006-- - Batch or Not?
**
hi,i think it's first time you'll try 2 crack this kind of CM..
have g00d luck!
everything is possible.
just get the right password.
-----------------------------
=]