Imports System.Text
Imports System.Security.Cryptography
Imports System.IO
Imports System.Windows.Forms
Imports Microsoft.VisualBasic.CompilerServices
Imports Microsoft.Win32
Imports System.Management


Public Class Form1
    Private Sub btnGenerate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGenerate.Click
        Dim str As String = Conversions.ToString(DateTime.Today.Month)
        Dim str3 As String = Conversions.ToString(DateTime.Today.Day)
        Dim str4 As String = Conversions.ToString(CDbl((Conversions.ToDouble(str) * Conversions.ToDouble(str3))))
        Dim str5 As String = Conversions.ToString(CDbl((3 * (Conversions.ToDouble(str4) + 12))))
        Dim volumeSerialNumber As String = GetVolumeSerialNumber("C")
        Dim str7 As String = Conversions.ToString(txtUsername.TextLength)
        Dim str2 As String = (str & str7)
        Dim str9 As String = Strings.Mid(Strings.StrReverse(txtUsername.Text), 4, 2)
        Dim str10 As String = (str5 & str2 & volumeSerialNumber & str9)

        txtSerial.Text = str10
    End Sub

    Public Function GetVolumeSerialNumber(ByVal driveletter As String) As String
        Dim str As String
        Dim searcher As New ManagementObjectSearcher(("SELECT * FROM Win32_LogicalDisk WHERE Name = '" & driveletter & ":'"))
        Dim obj2 As ManagementObject
        For Each obj2 In searcher.Get
            Return Conversions.ToString(obj2.Item("VolumeSerialNumber"))
        Next
        Return str
    End Function

    Private Sub btnAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAbout.Click
        MsgBox("halsten (C) 2007", MsgBoxStyle.Information)
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End
    End Sub
End Class


