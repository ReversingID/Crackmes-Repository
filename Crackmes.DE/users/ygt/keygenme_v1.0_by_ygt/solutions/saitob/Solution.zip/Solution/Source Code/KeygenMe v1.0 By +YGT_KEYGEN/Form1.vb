'You must import this for the keygen to work.
'To import System.Management goto Project->Add Referance->Scroll down and select System.management->click Ok.
Imports System.management
Imports Microsoft.VisualBasic.CompilerServices


Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If (((Me.txtName.TextLength < 4) Or (Operators.CompareString(Me.txtName.Text, "", False) = 0))) Then
            MsgBox("You name must be > 4!", MsgBoxStyle.Exclamation, "Message")
            Exit Sub
        End If
        txtSerial.Text = "Generating Serial..."
        Timer1.Start()
    End Sub

    Public Function GetVolumeSerialNumber(ByVal driveletter As String) As String
        Dim text As String
        Dim searcher As New ManagementObjectSearcher(("SELECT * FROM Win32_LogicalDisk WHERE Name = '" & driveletter & ":'"))
        Dim obj2 As ManagementObject
        For Each obj2 In searcher.Get
            Return (obj2.Item("VolumeSerialNumber")).ToString
        Next
        Return [text]
    End Function



    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Timer1.Stop()
        Dim text As String = DateTime.Today.Month.ToString
        Dim text3 As String = DateTime.Today.Day.ToString
        Dim text4 As String = Conversions.ToString(CDbl((Conversions.ToDouble([text]) * Conversions.ToDouble(text3))))
        Dim text5 As String = Conversions.ToString(CDbl((3 * (Conversions.ToDouble(text4) + 12))))
        Dim volumeSerialNumber As String = Me.GetVolumeSerialNumber("C")
        Dim text7 As String = Conversions.ToString(Me.txtName.TextLength)
        Dim text2 As String = ([text] & text7)
        Dim text9 As String = Strings.Mid(Strings.StrReverse(Me.txtName.Text), 4, 2)
        Dim right As String = (text5 & text2 & volumeSerialNumber & text9)
        txtSerial.Text = right
    End Sub
End Class
