#include <iostream>

using namespace std;

int main()
{
	int len = 0;
	char username[64];

	do
	{
		cout << "Username: ";

		//Intentionally only reading 40 characters, due to the bug in the keygenme
		cin.getline(username, 40);

		len = strlen(username);
		if(len < 4) cout << "Username must be at least four characters!" << endl;
	}
	while(len < 4); 

	unsigned int v0 = 0, v1 = 0, v2 = 0;
	for(int i = 0; i < len; i++)
	{
		v0 -= (username[i] - 0x19);
	}

	v1 = (v0 * v0 * v0);
	v2 = (0x40E0F8 * 0x40E0F8) - 0x40E0F8;

	printf("Your key: Bon-%lX-%lX-%lX\n", v0, v1, v2);
	return 0;
}