#include<stdio.h>
#include<windows.h>

/*
KeyGen for [ KeyGenMe #1 By Boonz ] By Cyclops
*/
main()
{
	char name[50];
	char ser1[15],ser2[15],ser3[15],serial[50];
	int i=0;
	unsigned int result=0,dummy1=0;
	int dummy=0;
	printf("KeyGen for [ KeyGenMe #1 By Boonz ] By Cyclops\n\n");
	printf("Enter the name :");
	fgets(name,50,stdin);
	name[strlen(name)-1]=0x00;
	if(strlen(name)<0x04||strlen(name)>0x32)
	{
		printf("Name length between 0x04 to 0x32!!!\n");
		return 0;
	}
	while(name[i]!='\0')
	{
		dummy-=name[i]-0x19;
		i++;
	}
	sprintf(ser1,"%lX",dummy);
	result+=dummy;
	result=(unsigned)result*dummy;
	result=(unsigned)result*dummy;
	sprintf(ser2,"%lX",result);
	result=0x0040e0f8;
	dummy1=(unsigned)result*result;
	dummy1-=result;
	sprintf(ser3,"%lX",dummy1);
	sprintf(serial,"Bon-%s-%s-%s",ser1,ser2,ser3);
	printf("Serial :%s\n",serial);
	getchar();
	return 0;
}