				���Crackme#2���
				  by Shus�as

Hi once again. Here is my second name/serial crackme.
Like in previous try to find a real serial.
There is only one request - Do Not Patch.
Send your tutorial or keygen.
Enjoy and good luck.