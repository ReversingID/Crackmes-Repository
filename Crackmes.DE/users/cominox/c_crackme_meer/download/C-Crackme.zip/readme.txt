This crackme was made in C language in 30 lines
HINT: 
it's right in front of you ! ERRRR ! 