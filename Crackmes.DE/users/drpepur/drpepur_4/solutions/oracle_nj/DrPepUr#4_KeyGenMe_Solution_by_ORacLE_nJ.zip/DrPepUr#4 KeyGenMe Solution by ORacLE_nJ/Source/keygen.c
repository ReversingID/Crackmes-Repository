#include<stdio.h>
#include<conio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
#include<windows.h>
#include<winbase.h>
#include"md5.cpp"

WINBASEAPI BOOL WINAPI GetComputerNameA(LPTSTR, LPDWORD);	
 
typedef unsigned long int dword;


dword crc_table[256];

void crc_init()
{
	dword crcpoly=0xEDB88320,t,i,j;
	for(i=0; i<256;i++)
	{
		t=i;
		for(j=8;j>0;j--)
		{
			if(t&1)
				t=(t>>1)^crcpoly;
			else
				t=t>>1;
		}
		crc_table[i]=t;
	}
}

dword docrc(char *s)
{
	unsigned int i;
	dword crc32=0xFFFFFFFF;
	for(i=0; i<strlen(s); i++)
	{
		crc32=crc_table[(crc32 ^ (s[i])) & 0xFF] ^ (crc32 >> 8);
	}
	return ~crc32;
}


void fixMD5(char *Str, int l)
{
	if(l<8)
	{
		Str[l]=(char)0x80;
	}
}



void main()
{
	unsigned int i, j, l1=0, l2, l3;
	int u1, u2, al;
	dword crc1, crc2, size, bcrc;
	dword s1=0, s2=0, s3=0, s4=0, s5=0, s6=0;
	unsigned char h1[34]={0}, h2[34]={0}, h3[34]={0}, h4[34]={0}, h5[34]={0};
	char CRCstr[10]={0}, n[50]="0", CompName[20]={0}, ch;

	char *head1="DrPepUr #4 KeyGenMe's Keygen by ORacLE_nJ";
	char *head2="\n=========================================\n\n";
	
	size = sizeof(CompName);

	crc_init();

	puts(head1);
	puts(head2);

	while(n[0]=='\0' || l1<5)
	{
		printf("\nName (Min 5 Chars):: ");
		gets(n);
		l1=strlen(n);
	}

	
	printf("\n\nDo you want to Generate Serial for Debugging Environment?\n");
	printf("(Press Y if Yes, Else any other key. . .)\n");
	scanf("%c", &ch);
	
	if(ch=='Y' || ch=='y')
	{
		al=u2=0x19;
	}
	else
	{
		printf("\nDefault Chosen: Outside Debugger\n\n");
		al=u2=1;
	}

	u1 = 0x25 - ((al+0x25)^0x34);

	for(i=0;i<l1;i++)
	{
		s1 = (((n[l1-i-1]+0x55)^u1)<<u2) & 0xFF;	//We need only AL
		s2 = s2 + s1;
		s2 = s2^0x45875614;
	}

	s3 = s2^0x12345678;

	s4 =  ((s3&0xFF)<<24)|							//Bswap
		  ((s3&0xFF00)<<8)|
		  ((s3&0xFF0000)>>8)|
		  ((s3&0xFF000000)>>24);

	s5 = s4*0x4523;
	s6 = s5-0x500;

	l2 = sprintf(h1,"%.8X%.8X%.8X%.8X",s6,s5,s4,s2);

	fixMD5(&h1[0],l2);
	GetMD5(h1, l2, h2);

	for(i=0;i<32;i++)
		h2[i]=toupper(h2[i]);

	


	GetComputerNameA(&CompName[0], &size);

	crc1=docrc(&CompName[0]);

	bcrc =  ((crc1&0xFF)<<24)|						//Bswap
			((crc1&0xFF00)<<8)|
			((crc1&0xFF0000)>>8)|
			((crc1&0xFF000000)>>24);

	
	CompName[0] = (unsigned char)(CompName[0]^(crc1&0xFF));
	CompName[1] = (unsigned char)(CompName[1]^((crc1&0xFF00)>>8));
	CompName[2] = (unsigned char)(CompName[2]^((crc1&0xFF0000)>>16));
	CompName[3] = (unsigned char)(CompName[3]^((crc1&0xFF000000)>>24));

	CompName[4] = (unsigned char)((CompName[4]^(bcrc&0xFF)));
	CompName[5] = (unsigned char)((CompName[5]^((bcrc&0xFF00)>>8)));
	CompName[6] = (unsigned char)((CompName[6]^((bcrc&0xFF0000)>>16)));
	CompName[7] = (unsigned char)((CompName[7]^((bcrc&0xFF000000))>>24));


	fixMD5(&CompName[0], size);
	GetMD5(CompName, size, h3);

	for(i=0;i<strlen(h3);i++)
		h3[i]=toupper(h3[i]);


	for(i=0,j=strlen(h3);i<strlen(h2);i++,j--)
	{
		h4[i]=(((h2[j-1]^h3[i])+h1[j-1])<<6)^u1;
	}

	l3 = strlen(h4);

	GetMD5(h4, l3, h5);

	for(i=0;i<strlen(h5);i++)
		h5[i]=toupper(h5[i]);


	crc2=docrc(&h5[0]);
	sprintf(CRCstr,"%.8X", crc2);

	for(i=8,j=0;i<12;i++,j++)
	{
		h5[i]=CRCstr[j];
	}

	for(i=0;i<strlen(h5);i++)
	{
		if(i==7 || i==15 || i==23)
			h5[i]='-';
		else
			h5[i]=h5[i];
	}

	printf("\nSerial:: DRP-%s\n\n", h5);
	getch();
}



