#include <stdio.h>
#include <string.h>
#include <conio.h>

typedef unsigned long int dword;


char ch[53] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-";
unsigned int i0, i1, i2, i3;

#define		L(x)	for(i##x=0;i##x<strlen(ch);i##x++){


dword crc_table[256];

void crc_init()
{
	dword crcpoly=0xEDB88320,t,i,j;
	for(i=0; i<256;i++)
	{
		t=i;
		for(j=8;j>0;j--)
		{
			if(t&1)
				t=(t>>1)^crcpoly;
			else
				t=t>>1;
		}
		crc_table[i]=t;
	}
}

dword docrc(char *s)
{
	int i;
	dword crc32=0xFFFFFFFF;
	for(i=0; i<strlen(s); i++)
	{
		crc32=crc_table[(crc32 ^ (s[i])) & 0xFF] ^ (crc32 >> 8);
	}
	return ~crc32;
}



void main()
{
	char n[5]={0};
	dword crc;

	crc_init();

	
	L(0) L(1)
	L(2) L(3)

	sprintf(n, "%c%c%c%c", ch[i0], ch[i1], ch[i2], ch[i3]);

	crc=docrc(&n[0]);

	if(crc == 0xA56EEB89)
	{
		printf("\n\n\nResult of brute force:: %s\n\n",n);
		getch();
		exit(0);
	}

	}}}}

	printf("\n\nDone...");
	getch();
}
