Solution by COSTY 

Excuse my for my bad English.

You need to extract DrPepur5.reg and DrPepUr5.exe
 in the same directory.
If you try loading DrPepUr5.exe directly from the
zip file it will not work correctly because it can't
 read DrPepur5.reg.

