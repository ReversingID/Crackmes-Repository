#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <conio.h>
#include <stdlib.h>

#include "sha1.c"

unsigned long Checksum(char *, int);

unsigned char chk[10], s1, ODRet= 0x0A;
unsigned char d1[21], d2[21], n[75];
unsigned char digest1[41], digest2[41], tmp[5]={0};
unsigned char part1[30], part2[21], serial[25];
unsigned long i, j, l, s2=0;
char ch;

void main()
{
	SHA_CTX sha;

	printf("\n\nName : ");
	gets(n);
	l = strlen(n);
	
	if(l > 4){
	printf("\n\nDo you want to Generate Serial for Debugging Environment?\n");
	printf("(Press Y if Yes, Else any other key)\n");
	scanf("%c", &ch);

	if(ch == 'Y' || ch == 'y')
		ODRet = 0x0A;
	else 
	{
		printf("Default Chosen: Outside Debugger\n\n");
		ODRet = 0x01;
	}

	//b - Checksum
	s2 = Checksum(n, l);
	ltoa(s2, chk, 16);

	for(i=0; i<strlen(chk); i++)
	{
		chk[i] = toupper(chk[i]);
	}


	//c - SHA of Checksum
	SHAInit(&sha);
	SHAUpdate(&sha, chk, strlen(chk));
	SHAFinal(d1, &sha);


	for (i=0; i<20; i++)
	{
		sprintf(tmp, "%02X", d1[i]);
		strcat(digest1, tmp);
	}


	//e - SHA of (c)
	SHAInit(&sha);
	SHAUpdate(&sha, digest1, strlen(digest1));
	SHAFinal(d2, &sha);
	
	for (i=0; i<20; i++)
	{
		sprintf(tmp, "%02X", d2[i]);
		strcat(digest2, tmp);
	}

	//First  4 bytes of e
	for(i=0; i<4; i++)
	{
		part1[i] = digest2[i];
	}


	// Even Bytes of e
	for(i=0,j=0; i<strlen(digest2); i++, j=j+2)
	{
		part2[i] = digest2[j];
	}


	// strcat(first 4 bytes of e), f)
	strcat(part1, part2);


	// Print Serial
	for(i=0; i<strlen(part1); i++)
	{
		if(i == 6)
		{
			serial[i] = '-';
		}
		else
			serial[i] = part1[i];
	}

	printf("\nSerial : %s\n\n", serial);
	}
	else
		printf("\nError ! \nYour Name Must Be Atleast 5 Chars.....\n");
	getch();
}

unsigned long Checksum(char *n, int l)
{
	//b - Checksum
	for(i=l; i!=0; i--)
	{
		s1 = n[i-1];
		_asm
		{
			MOV		AL, s1
			IMUL    EAX, EAX, 5
			ADD     AL, ODRet
			BSWAP   EAX
			ADD		s2, EAX
		}
		ODRet++;
	}

	s2 ^= 0x12345678;
	return(s2);
}
