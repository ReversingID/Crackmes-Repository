/* Target: DrPepUr #3 by DrPepUr
 * Type: KeygenMe
 * Difficulty: 1
 * Date: 25-12-09 21:20
 * Author: Kilobyte
 * count: #9
*/

#include <stdio.h>
#include <string.h>
#include <windows.h>
#include "sha1.h"

unsigned long bswap(unsigned long in)
{
	return (((in & 0x000000FF) << 24) + ((in & 0x0000FF00) << 8)
			+ ((in & 0x00FF0000) >> 8) + ((in & 0xFF000000) >> 24));
}


int main()
{
    SHA1Context sha;

	DWORD tmp,nvalue;
    int i,n;					// misc variables, counters, subscripts etc

	char name[51];				// name
	char hashbuf[64] = {0};		// hash buffer for hash operations
	char nvalstr[10];			// name value string
	char nvaluehash[64];		// name value hash
	char tmpbuff[64] = {0};		// temporary buffer
	char serial[64] = {0};		// serial buffer


	//title
	printf("DrPepU #3 Keygen by Kilobyte\n");
	printf("----------------------------\n");

	// prompt for name
	printf("Name: ");
    fgets(name, 51, stdin);
    name[strlen(name) - 1] = '\0';

	// check name length
	if (strlen(name) < 5) {
        printf("Name must be >= 5\n");
        system("pause");
        return(1);
    }

	// calculate sha for name
	SHA1Reset(&sha);
    SHA1Input(&sha, (const unsigned char *) name, strlen(name));
	SHA1Result(&sha);
	wsprintf(hashbuf, "%.8X%.8X%.8X%.8X%.8X", sha.Message_Digest[0],
                                        sha.Message_Digest[1],
                                        sha.Message_Digest[2],
                                        sha.Message_Digest[3],
										sha.Message_Digest[4]);

	i = strlen(name) - 1;			// array index 5 = 0 - 4
	n = 0; tmp = 0; nvalue = 0;
	while(i > -1)					// calculate name value
	{
		tmp = bswap((((tmp & 0xFFFFFF00) | name[i]) * 5) + n);
		nvalue += tmp;
		n++;
		i--;
	}
	nvalue ^= 0x12345678;
	wsprintf(nvalstr,"%X",nvalue);

	SHA1Reset(&sha);
    SHA1Input(&sha, (const unsigned char *) nvalstr, strlen(nvalstr));
	SHA1Result(&sha);
	wsprintf(nvaluehash, "%.8X%.8X%.8X%.8X%.8X", sha.Message_Digest[0],
										sha.Message_Digest[1],
                                        sha.Message_Digest[2],
                                        sha.Message_Digest[3],
                                        sha.Message_Digest[4]);

	for (i = 0,n = 0; i < 5; i++,n += 4)
	{
		hashbuf[n] += (sha.Message_Digest[i] & 0x000000FF);
		hashbuf[n+1] += (sha.Message_Digest[i] & 0x0000FF00) >> 8;
		hashbuf[n+2] += (sha.Message_Digest[i] & 0x00FF0000) >> 16;
		hashbuf[n+3] += (sha.Message_Digest[i] & 0xFF000000) >> 24;
	}

	SHA1Reset(&sha);
	SHA1Input(&sha, (const unsigned char *)nvaluehash, strlen(hashbuf));
	SHA1Result(&sha);
	wsprintf(hashbuf, "%.8X%.8X%.8X%.8X%.8X", sha.Message_Digest[0],
										sha.Message_Digest[1],
                                        sha.Message_Digest[2],
                                        sha.Message_Digest[3],
                                        sha.Message_Digest[4]);

	// prepare and finalize serial
	for (n = 0; n < 4; n++)
		serial[n] = hashbuf[n];
	for (i = 0, n = 4; i < strlen(hashbuf); n++, i += 2)
		serial[n] = hashbuf[i];
	serial[6] = '-';

	// print serial
	printf("serial: %s\n", serial);
	system("pause");

    return 0;
}
