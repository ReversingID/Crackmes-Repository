#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#pragma argsused
int main(int argc, char* argv[])
{
        unsigned char key[11];
        unsigned char mas[10];
        double d;
        unsigned int a,t1,t2,t3;
        printf("KeyGen for DrPepUr`s DrPepUr_6 crackme\n");
        printf("Created by Jesi\n");
        while(1){
          key[0]=random('z'-'A')+'A'; mas[0]=key[0]-0x40;//1-st
          key[1]=random('z'-'A')+'A'; mas[1]=key[1]-0x40;//2-nd
          for(int i=1;i<9;i++){
            a=i*mas[0]*mas[1]+mas[1];
            d=sin(a);
            if((i==1)||(i==4)||(i==7)){
              t1=2;
              t2=4;
              t3=0x31;
            }
            else{
              t1=10;
              t2=12;
              t3=0x41;
            }
            a=floor((d*t1)+0.5)+t2;
            mas[i+1]=a; key[i+1]=a+t3;
          }
          key[10]=0;
          printf("Generated S/N is: %s\n",key);
          printf("Exit-e: ");
          a=getc(stdin);
          if(a=='e'){
            break;
          }
        }
        return 0;
}
//---------------------------------------------------------------------------
