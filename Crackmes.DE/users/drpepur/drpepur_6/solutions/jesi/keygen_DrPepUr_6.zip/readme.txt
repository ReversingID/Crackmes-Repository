I'm sorry for my bad english :-(
tutorial.doc - msword tutrorial
full_sub_list.doc - msword subroutine IDA disassembly code
1.idc - IDA dumped database
keygen.cpp - C++ source of keygen
keygen.exe - keygen
