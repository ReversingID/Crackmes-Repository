Crackme #2 by zyzygy


Framework:.NET Framework v1.1 

Description: This is a very easy crackme. The algorithm as with all .NET applications is pretty much visible.Your task is to get it to say registered by using any means.

You may patch it or you may make a keygen out of it(this should be the easiest!) but I would like to see it patched. 


Hope you learn something from it.

Perhaps in the next version I shall come up with a better protection.

Comments and suggestions are welcomed.

Email :
zyzygygr8@yahoo.com
