Some time ago, I coded a freeware application in which a registration scheme was only implemented to help me keep track of its use (free registration). 
I amused myself coding a rather difficult scheme, however, it can easily be made many times harder. 
To comply with forum rules, I have grabbed the registration scheme and made a CrackMe from it. 
Everything is allowed : serialfishing, patching, brute forcing ... the ultimate goal being a keygen.
The only nag in the real stuff is when clicking the "Register" button as each time an action is required, the registration scheme is re-run internally to decide on acting or not. To make the reverseme easier, I have also implemented a startup and closing nag. 
It's clear that killing the nags and About Box is NOT helping. This only confirms the non-registration internally. 
In a valid solution, the goodboys are shown.
I built some useless code around the CrackMe to make it the normal size of the software. 
ReverseMe is not packed nor encrypted. I believe it is virtually impossible without the following hints though :
 1. For the application to be registered, it must say "REGISTERED" on the registration window. However, all the obvious goodboys in the strings (Success ... Registration SuccessFull ... Thanks for your support !!!! ... REGISTERED) are NOT used but are diversion code, seek elsewhere !
2. This "reverseme" is in fact part of an application which has 20 (twenty !) checks and doublechecks. If any of these fail, you are sent in the woods to go play with Robin Hood. In this case, the real serial is never calculated (only a fake diversion serial is calculated). BTW, assume anything by "checks and doublechecks", like suppose : verifying if the length of a certain part of the serial is right, else --> go see Robin in the woods.
3. This reverseme is part of a real application : at startup, it verifies for "was I previously registered or not ?". If it was registered before, the registration scheme is not shown in the real application. BTW, the reverseme shows the goodboy at startup when registered before (because there is no "application" here).
4. Find the ring0 debugger checks (find them all !) --> else go see Robin Hood  
5. Find the ring3 debugger checks (find them all !) --> else go see Robin Hood  
6. Find the anti-tracing --> else go see Robin Hood  
7. ALL detecting is silent : if anything suspicious is detected --> go see Robin Hood  
8. Expect some more tricks, probably these being the most important factor of faillure of all. 

Success and have fun !
lena151

EDIT @ end june 2007: this ReverseMe's defences are mainly based on anti-debugging. It is probably too difficult to be solved without more help than the above. It is almost a year and hasn't been solved yet. An unsolved ReverseMe is a bad ReverseMe, so, I have included the DebuggerDetected file to help you solve the ReverseMe: it is the samee as the original ReverseM, only it displays on the closing nag if your debugger is detected or not. Just run it in and out your debugger to see the differences (no Ring0 debugger being installed). Eliminate all detection first or the real scheme is never run! Then you will be able to find the real algo.

INFO: this ReverseMe made from a real program was part of vivid discussions on some boards to prove that not everything is "crackable". It seems that claiming not everything is crackable was right because after challenging and almost 1000 downloads from 6 different boards... the ReverseMe is still not cracked. With 99.9% of the info given away now, I hope it soon will get cracked indeed!