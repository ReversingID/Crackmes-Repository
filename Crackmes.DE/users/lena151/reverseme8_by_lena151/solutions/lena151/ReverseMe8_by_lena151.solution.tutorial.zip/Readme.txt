Included is the solution to my own ReverseMe#8.
I've made a solution myself (in flash format) because it seemed that quite a lot of people had difficulties solving it.
Best regards
lena151.