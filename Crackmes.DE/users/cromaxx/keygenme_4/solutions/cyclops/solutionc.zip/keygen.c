#include<stdio.h>
#include<string.h>

/*	KeyGenerator For CromaxX's KeyGenMe #4.
	Coded by ..........: Cyclops
	Protection ........: Simple Math
	Ambiguity .........: Some unknown bug in pressing mouse and typing 'Enter'
*/

main()
{
	long r1=0,r2=0,r3=0,r4=0,r5=0,r6=0,r7=0,r8=0;
	long dummy=0,dummy1=0,dummy2=0,dummy3=0;
	int i=0;
	char name[50];
	char serial[70];
	short len;
	printf("\nKeyGenerator For CraomaxX's KeyGenMe #4\n\n");
	printf("Coded by ...........: Cyclops (cyclops1428@yahoo.com)\n\n");
	printf("The Computed serial varies when pressing mouse and typing \'Enter\' \n");
	printf("I have used the value which was on my computer.This may change in ur computer.\n");
	printf("Please change the value of ecx in line 42 of this source code.\n");
	printf("U can get the value from location 00401616.Set a brkpt there and get the value.\n\n");
	printf("Enter the name:");
	scanf("%[^\n]",name);			//Get the name 
	len=strlen(name);
	if(len<3)						//Check the length
	{
		printf("The name length should be greater than 3.\n");
		return -1;
	}
	while(name[i]!='\0')			//initial result
	{
		dummy=name[i];
		dummy^=0xc50711;
		r1+=dummy;
		i++;
	}
	r2=r1;
	__asm
	{
		mov ecx,0d4h				//The magic number
		mov eax,r2
		shl eax,cl
		mov cx,len
		sar eax,cl
		mov r2,eax
	}
	r1++;
	dummy=r2;
	dummy^=r1;
	dummy1=r1;
	dummy2=r2;
	dummy1-=dummy2;
	dummy+=dummy1;
	dummy1=r1;
	dummy1+=dummy2;
	dummy1^=dummy;
	r3=dummy1;							//The 3rd result
	dummy=r2;
	dummy^=r1;
	dummy2=r2;
	dummy1=r1;
	dummy1+=dummy2;
	dummy+=dummy1;
	dummy^=dummy1;
	r4=dummy;							//The 4th result
	dummy1=r3;
	dummy1^=r4;
	dummy1+=0x6d617858;
	r5=dummy1;							//The fifth result
	dummy=r3;
	dummy1&=dummy;
	dummy1^=r4;
	r6=dummy1;							//The sixth result
	dummy=r3;
	dummy1=r5;
	dummy+=r4;
	dummy1+=dummy;
	dummy1^=dummy;
	r7=dummy1;							//The seventh result
	dummy=dummy2=r4;
	dummy1=r3;
	dummy|=dummy1;
	dummy1^=dummy;
	__asm
	{
		mov eax,dummy1
		mov ecx,dummy
		shl eax,cl
		mov dummy1,eax
	}
	dummy1&=dummy;
	dummy1|=0x6d617858;
	r8=dummy1;							//The eigth result

	/*	
	 *  Check if any thing is -ve .
	 *	If any thing is negative, change to +ve
	 */

	if(r1<0)
		r1=-r1;
	if(r2<0)
		r2=-r2;
	if(r3<0)
		r3=-r3;
	if(r4<0)
		r4=-r4;
	if(r5<0)
		r5=-r5;
	if(r6<0)
		r6=-r6;
	if(r7<0)
		r7=-r7;
	if(r8<0)
		r8=-r8;
	/*	Sprintf the results */
	sprintf(serial,"C%dr%do%dm%da%dx%dX",r1,r2,r3,r4,r5,r8);
	i=0;
	while(serial[i]!='\0')
		serial[i++]+=2;		//Increment each by 2
	printf("The Serial Is:%s\n",serial);
	getchar();
	getchar();
	return 0;
}