#include <iostream.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <conio.h>
#include <windows.h>

void main()
{
        char name[50];
        DWORD code;
        DWORD serial;
        int len;

        cout<<"Keygenme #2 by CromaxX - Keygen by Ox87k"<<"\n\n";
        //name:
        cout<<"Name: ";
        gets(name);
        //len name
        len=strlen(name);

        code=((name[0]*len)*(0x3B9ACA00+name[0]));
        while(code>0x7FFFFFFF)
        {
        		code+=0x3B9ACA00;
        }

        cout<<"Code: "<<code<<endl;
        
        serial=(len*code)*0x3E7;

        while(serial>0x7FFFFFFF)
        {
        		serial+=0x3B9ACA00;
        }

        cout<<"Serial: "<<serial;
        cout<<"\n\nPress any key for exit..";
        getch();
}
