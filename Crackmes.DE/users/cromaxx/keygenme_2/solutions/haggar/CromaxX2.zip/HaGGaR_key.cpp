#include<iostream>
#include<stdlib.h>
#include<string.h>
using namespace std;
int main()
{

cout<<"\n [ CromaxX Keygenme #2 - keygen by haggar ]\n\n\n";
    
    
    
    
   int  length,code,serial;
   char name[200];


   cout<<"\n\n  Enter name:    ";
   cin.get(name,200);
   length=strlen(name);
   
   cout<<"\n\n  Enter code:    ";
   cin>>code;
   
   code=code*length;
   code=code*999;
   
   while(code<0)
   {
       code=code+1000000000;
   }
 
   
   cout<<"\n\n  Serial is:     "<<code;
   
   
   cout<<"\n\n\n\n\n\n\n\n  ";
   system("pause");
   
   


}