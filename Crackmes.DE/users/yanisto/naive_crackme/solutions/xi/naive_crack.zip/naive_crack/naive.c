#include <stdio.h>

#define NOP 0x90

#define FILENAME "naive-crk"

/* virtual address of file start */
#define VADDR 0x8047000

int
main()

{
  FILE *fp;
  unsigned char buf[10];

  fp = fopen(FILENAME, "r+");
  if (!fp)
  {
    perror("fopen");
    exit(1);
  }

  fseek(fp, 0x0804841D - VADDR, SEEK_SET);

  /*
   * Change the test eax, eax instruction to 2 nops - this bypasses
   * the ptrace test
   */
  buf[0] = NOP;
  buf[1] = NOP;
  fwrite(buf, 1, 2, fp);

  /*
   * Change the je +3e6 to a and eax, 0 - this bypasses
   * the password check
   */
  fseek(fp, 0x0804847A - VADDR, SEEK_SET);
  buf[0] = 0x25;
  buf[1] = 0x00;
  buf[2] = 0x00;
  buf[3] = 0x00;
  buf[4] = 0x00;
  buf[5] = NOP;
  fwrite(buf, 1, 6, fp);

  /*
   * Change the jne instruction to 6 nops - this bypasses
   * one last test which i'm not sure what it is
   */
  fseek(fp, 0x08048878 - VADDR, SEEK_SET);
  buf[0] = NOP;
  buf[1] = NOP;
  buf[2] = NOP;
  buf[3] = NOP;
  buf[4] = NOP;
  buf[5] = NOP;
  fwrite(buf, 1, 6, fp);

  fclose(fp);
}
