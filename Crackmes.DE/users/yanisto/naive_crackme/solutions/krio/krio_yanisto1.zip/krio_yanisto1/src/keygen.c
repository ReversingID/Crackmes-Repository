//
// keygenerator for yanisto's naive crackme by krio (c) 2004
//
#include <stdio.h>

// user defined constants

#define PASSWORD_LOWER	0x20
#define PASSWORD_UPPER	0x7E

// crackme defined constants

#define DWORD_1		0x50
#define DWORD_2		0x61
#define DWORD_3		0x7E
#define DWORD_4		0x03
#define PASSWORD_SIZE	8

// other constants

#define MAX_MATCH	255
#define KRIO_IS		31337

int check_symbol(char da_char)
{
	if (da_char >= PASSWORD_LOWER)
	{
		if (da_char <= PASSWORD_UPPER) return 0;
	}
	return KRIO_IS;
}

int main()
{
	char p[PASSWORD_SIZE][MAX_MATCH],password[PASSWORD_SIZE];
	int i,t,e,m;

	for(i=0;i<=PASSWORD_SIZE;i++)
	{
		for(t=0;t<MAX_MATCH;t++)
		{
			p[i][t]=0;
		}
	}

	#ifdef DEBUG
		printf("stage 0: workspace initialized...\n");
	#endif

	for(i=PASSWORD_LOWER;i<=PASSWORD_UPPER;i++)
	{
		#ifdef DEBUG
			printf("stage 0: trying symbol 0x%02X...\n",i);
		#endif
	
		if (check_symbol(i^DWORD_1) == 0)
		{
			#ifdef DEBUG
				printf("match 1: %04X %04X\n",i,i^DWORD_1);
			#endif
			
			p[2][0]++;
			p[2][p[2][0]]=i;

			p[6][0]++;
			p[6][p[6][0]]=i^DWORD_1;
		}
		
		if (check_symbol(i^DWORD_2) == 0)
		{
			#ifdef DEBUG
				printf("match 2: %04X %04X\n",i,i^DWORD_2);
			#endif

			p[1][0]++;
			p[1][p[1][0]]=i;

			p[5][0]++;
			p[5][p[5][0]]=i^DWORD_2;
		}
		
		if (check_symbol(i^DWORD_3) == 0)
		{
			#ifdef DEBUG
				printf("match 3: %04X %04X\n",i,i^DWORD_3);
			#endif
 
			p[4][0]++;
			p[4][p[4][0]]=i;

			p[8][0]++;
			p[8][p[8][0]]=i^DWORD_3;
		}
		
		if (check_symbol(i^DWORD_4) == 0)
		{
			#ifdef DEBUG
				printf("match 4: %04X %04X\n",i,i^DWORD_4);
			#endif

			p[3][0]++;
			p[3][p[3][0]]=i;

			p[7][0]++;
			p[7][p[7][0]]=i^DWORD_4;
		}
	}

	#ifdef DEBUG
		printf("stage 1: passwords generated...\n");
		printf("match 1: %u matches generated...\n",p[2][0]);
		printf("match 2: %u matches generated...\n",p[1][0]);
		printf("match 3: %u matches generated...\n",p[4][0]);
		printf("match 4: %u matches generated...\n",p[3][0]);
	#endif

	for (i=0;i<PASSWORD_SIZE;i++)
	{
		if (p[i+1][0] == 0)
		{
			printf("no passwords found...\n");
			exit(KRIO_IS);
		}
	}

	#ifdef DEBUG
		printf("stage 1: %u maximum possible matches...\n",MAX_MATCH);
	#endif
	
	password[8]=0x00;

	for(i=0;i<p[2][0];i++)
	{
		for(t=0;t<p[1][0];t++)
		{
			for(e=0;e<p[4][0];e++)
			{
				for(m=0;m<p[3][0];m++)
				{
					password[0]=p[1][t+1];
					password[1]=p[2][i+1];
					password[2]=p[3][m+1];
					password[3]=p[4][e+1];
					password[4]=p[5][t+1];
					password[5]=p[6][i+1];
					password[6]=p[7][m+1];
					password[7]=p[8][e+1];
					printf("%s\n",password);
				}
			}
		}		
	}

	#ifdef DEBUG
		printf("syncing discs... :)\n");
	#endif

	return 0;
}
