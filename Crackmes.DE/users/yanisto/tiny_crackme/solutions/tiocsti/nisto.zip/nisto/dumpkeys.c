#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>

union key
{
	unsigned char buff[4];
	unsigned int d;
};

int checkBuff(unsigned char *buff)
{
	int i;
	for(i=0;i < 4;i++)
	{
		if(buff[i] < 32 || buff[i] > 126)
			return 0;
	}
	return 1;
}


main()
{
	unsigned int basecsum = 0x7d5c6d9;
	unsigned int fixedxor = 0x5508046B;
	unsigned int i=0;
	unsigned int r;
	union key k;

	do
	{
		r = basecsum;
		//printf("result = basecsum %x\n", r);
		r = r + ((i << 16) + (i >> 16));
		//printf("result = result + swappedkey %x\n", r);
		r = r ^ fixedxor;
		//printf("result = result xor fixedxor %x\n", r);
		r = r ^ i;
		//printf("result = result xor key %x\n", r);
		if(r == 0)
		{
			k.d = i;
			if(checkBuff(k.buff))
				printf("key=\"%c%c%c%c\" (%x)\n", k.buff[0], k.buff[1], k.buff[2], k.buff[3], i);
		}
		i++;
	} while(i);
}

