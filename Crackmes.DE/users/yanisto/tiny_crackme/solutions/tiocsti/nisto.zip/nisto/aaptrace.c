#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ptrace.h>
#include <sys/signal.h>
#include <sys/syscall.h>
#include <asm/unistd.h>
#include <linux/user.h>

int handle_ptrace_singlestep(pid_t pid, FILE *fp)
{
	struct user_regs_struct regs;
	ptrace(PTRACE_GETREGS, pid, 0, &regs);
	fprintf(fp, "%08x eax=%x ebx=%x ecx=%x edx=%x esi=%x edi=%x\n",
		regs.eip,
		regs.eax,
		regs.ebx,
		regs.ecx,
		regs.edx,
		regs.esi,
		regs.edi);
	ptrace(PTRACE_SINGLESTEP, pid, 0, 0);
	return 1;
}

int handle_ptrace_syscall(pid_t pid, FILE *fp)
{
	struct user_regs_struct regs;
        ptrace(PTRACE_GETREGS, pid, 0, &regs);
	if(regs.orig_eax == __NR_ptrace && regs.eax == -1)
        {
		fprintf(fp, "identified anti ptrace code...disabling\n");
        	regs.eax = 0;
                ptrace(PTRACE_SETREGS, pid, 0, &regs);
        }
	else if(regs.orig_eax == __NR_read && regs.ebx == 1 && regs.eax == 4) 
	{
		FILE *outputfile;
		unsigned int i = 0x00200000;
		unsigned int dataword;

		fprintf(fp, "identified sys_read, trying to dump image and switch to single step mode\n");
		ptrace(PTRACE_POKEDATA, pid, regs.ecx, 0);

		outputfile = fopen("bmcrack.bin", "wb");
		for(;i < 0x00200320;i+=4)
		{
			dataword = ptrace(PTRACE_PEEKDATA, pid, i, 0);
			fwrite(&dataword, 4, 1, outputfile);
		}
		fclose(outputfile);
		ptrace(PTRACE_SINGLESTEP, pid, 0, 0);
		return 1;
	}
		
        ptrace(PTRACE_SYSCALL, pid, 0, 0);
	return 0;
}

int main(int argc, char **argv)
{
	long ptracehandle;
	pid_t mypid;
	FILE *fp=NULL;
	int state=0;

	mypid = fork();
	switch(mypid)
	{
		case 0:
			// child process
			ptrace(PTRACE_TRACEME, 0, 0, 0);
			execl(argv[1], argv[1], NULL);
			_exit(0);
		case -1:
			// error
			perror("fork");
			_exit(-1);
		default:
			fp = fopen("log.txt", "wt");
			if(!fp)
			{
				perror("fopen");
				kill(mypid, 9);
				wait(NULL);
				_exit(-1);
			}
			wait(NULL);
			if(kill(mypid, 0) == -1)
			{
				fclose(fp);
				exit(0);
			}
			ptrace(PTRACE_SYSCALL, mypid, 0, 0);
			while(1)
			{
				wait(NULL);
				if(kill(mypid, 0) == -1)
				{
					fclose(fp);
					exit(0);
				}
				if(state == 0)
					state=handle_ptrace_syscall(mypid, fp);
				else
					state=handle_ptrace_singlestep(mypid, fp);
			}
	}
}

				
		

