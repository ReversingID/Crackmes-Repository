//
// unpacker for yanisto's tiny crackme by krio (c) 2004
//
// note: verification is based on filesize and can be abused... take care! :)
//
#include <stdio.h>
#include <fcntl.h>

// crackme defined constants

#define CRACKME_SIZE	795
#define D1_SIZE		677
#define D1_OFFSET	0x004B
#define D1_KEY		0x3F5479F1
#define D2_SIZE		244
#define D2_OFFSET	0x19E
#define D2_KEY		0xBEEFC0DA
#define P1_OFFSET	0x0304
#define P1_DWORD	0x00000000
#define P2_OFFSET	0x0058
#define P2_DWORD1	0x9090D231
#define P2_DWORD2	0x59E89090
#define TABLE_OFFSET	0x0008
#define TABLE_SIZE	0x02DF

// other constants

#define KRIO_IS	31337

int main(int argc, char *argv[])
{
	int hfile,i;
	void *hmem;
	int *mem_decrypt;

// in the beginning was the light...

	if (argc < 3)
	{
		printf("yanisto's tiny crackme unpacker by krio\n");
		printf("---------------------------------------\n");
		printf("usage: unpack <tiny_crackme> <unpacked>\n");
		return KRIO_IS;
	}

// start up crackme analysis...

	if ((hfile=open(argv[1],O_NONBLOCK)) == -1)
	{
		printf("error: cannot access file...\n");
		return KRIO_IS;
	}

	if (lseek(hfile,0,SEEK_END) != CRACKME_SIZE)
	{
		printf("error: incorrect crackme filesize...\n");
		close(hfile);
		return KRIO_IS;
	}

	lseek(hfile,0,SEEK_SET);

	if ((hmem=(void *)malloc(CRACKME_SIZE)) == 0)
	{
		printf("error: not enough memory...\n");
		close(hfile);
		return KRIO_IS;
	}

	if (read(hfile,hmem,CRACKME_SIZE) == -1)
	{
		printf("error: cannot read file...\n");
		close(hfile);
		free(hmem);
		return KRIO_IS;
	}

	close(hfile);

// part 1 of unpacking...

	mem_decrypt=hmem+D1_OFFSET;
	
	for(i=0;i<D1_SIZE/sizeof(int);i++)
	{
		*(mem_decrypt+i)=*(mem_decrypt+i)^D1_KEY;
	}

	mem_decrypt=hmem+P1_OFFSET;
	*(mem_decrypt)=P1_DWORD;

// part 2 of unpacking...

	mem_decrypt=hmem+D2_OFFSET;

	for(i=0;i<D2_SIZE/sizeof(int);i++)
	{
		*(mem_decrypt+i)=*(mem_decrypt+i)^D2_KEY;
	}

// dumping table... :)

	if ((hfile=creat("table.dmp",400)) == -1)
	{
		printf("error: cannot dump table...\n");
		free(hmem);
		return KRIO_IS;
	}

	if (write(hfile,hmem+TABLE_OFFSET,TABLE_SIZE) == -1)
	{
		printf("error: cannot access table...\n");
		free(hmem);
		close(hfile);
		return KRIO_IS;
	}

	close(hfile);

// part 3 of unpacking...

	mem_decrypt=hmem+P2_OFFSET;
	*(mem_decrypt)=P2_DWORD1;
	*(mem_decrypt+1)=P2_DWORD2;

// finilize unpacking...

	if ((hfile=creat(argv[2],0x0FFFF)) == -1)
	{
		printf("error: cannot create file...\n");
		free(hmem);
		return KRIO_IS;
	}

	if (write(hfile,hmem,CRACKME_SIZE) == -1)
	{
		printf("error: cannot write file...\n");
	}

	close(hfile);
	free(hmem);

	return 0;
}
