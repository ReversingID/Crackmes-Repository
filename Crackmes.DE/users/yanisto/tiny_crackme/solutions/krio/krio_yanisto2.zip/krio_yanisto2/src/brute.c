//
// bruteforcer for yanisto's tiny crackme by krio (c) 2004
//
#include <stdio.h>
#include "dump.h"

// user constants

#define PASSWORD_LOWER	0x20
#define PASSWORD_UPPER	0x7E

// table constants

#define HARD_XOR	0x5508046B
#define DUMP_SIZE	735
#define PASSWORD_SIZE	0x0004

// other constants

#define KRIO_IS	31337

int main()
{
	char password[PASSWORD_SIZE];
	int i,t,e,m,s,sum;
	int *pass;

	for(i=PASSWORD_LOWER;i<=PASSWORD_UPPER;i++)
	{
		for(t=PASSWORD_LOWER;t<=PASSWORD_UPPER;t++)
		{
			for(e=PASSWORD_LOWER;e<=PASSWORD_UPPER;e++)
			{
				for(m=PASSWORD_LOWER;m<=PASSWORD_UPPER;m++)
				{
					dump[0x28E]=t;
					dump[0x28F]=i;
					dump[0x290]=m;
					dump[0x291]=e;

					sum=0;

					for(s=0;s<(DUMP_SIZE/sizeof(int));s++)
					{
						sum+=*((int *)dump+s);
					}

					pass=(void *)dump+0x28E;

					if (((sum^HARD_XOR)^*(pass)) == 0)
					{
						password[0]=t;
						password[1]=i;
						password[2]=m;
						password[3]=e;
						password[4]=0x00;
						
						printf("%s\n",password);
					}
				}
			}
		}
	}

	return KRIO_IS;
}
