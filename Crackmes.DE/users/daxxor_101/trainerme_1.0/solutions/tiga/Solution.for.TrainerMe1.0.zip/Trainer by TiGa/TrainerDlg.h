// TrainerDlg.h : header file
//

#if !defined(AFX_TRAINERDLG_H__CEF58ECB_AEF7_47B3_A812_1C6B6DA7199F__INCLUDED_)
#define AFX_TRAINERDLG_H__CEF58ECB_AEF7_47B3_A812_1C6B6DA7199F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CTrainerDlg dialog

class CTrainerDlg : public CDialog
{
// Construction
public:
	HANDLE m_hProcess;
	CTrainerDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CTrainerDlg)
	enum { IDD = IDD_TRAINER_DIALOG };
	CButton	m_ctlHealth;
	CButton	m_ctlAmmo;
	BOOL	m_chkHealth;
	BOOL	m_chkAmmo;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTrainerDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CTrainerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBexit();
	afx_msg void OnChkammo();
	afx_msg void OnChkhealth();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRAINERDLG_H__CEF58ECB_AEF7_47B3_A812_1C6B6DA7199F__INCLUDED_)
