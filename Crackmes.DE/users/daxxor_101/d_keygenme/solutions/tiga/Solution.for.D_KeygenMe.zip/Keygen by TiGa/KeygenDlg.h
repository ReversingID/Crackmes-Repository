// KeygenDlg.h : header file
//

#if !defined(AFX_KEYGENDLG_H__8BB1A39D_83F5_4495_85FF_A89E46490484__INCLUDED_)
#define AFX_KEYGENDLG_H__8BB1A39D_83F5_4495_85FF_A89E46490484__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CKeygenDlg dialog

class CKeygenDlg : public CDialog
{
// Construction
public:
	CKeygenDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CKeygenDlg)
	enum { IDD = IDD_KEYGEN_DIALOG };
	CString	m_sName;
	CString	m_sSerial;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CKeygenDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CKeygenDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBgenerate();
	afx_msg void OnBexit();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_KEYGENDLG_H__8BB1A39D_83F5_4495_85FF_A89E46490484__INCLUDED_)
