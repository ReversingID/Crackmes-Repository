KeygenMe . by DaXXoR 

This crackme was written in D :: http://www.digitalmars.com/d/

DaXXoR101@gmail.com