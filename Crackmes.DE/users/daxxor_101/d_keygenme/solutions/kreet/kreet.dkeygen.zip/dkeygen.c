#include <stdio.h>
#include <string.h>

int main() {
   char username[32]="";
   int genkey=574,i=0;

   printf("Name: ");
   scanf("%s",username);
   for (i=0; i< strlen(username); i++) {
      genkey *= username[i] / 5;
      genkey += username[i];
   }
   printf("Serial: %i\n",genkey);
   return 0;
}