Rules:
	No Patching - This problem is trivial if a patch is applied.
	Tutorial Required.