//
//
//Solution for [iLL_LeaT's Crypta-Lock-O-Matic] by Cyclops
//http://cyclops.ueuo.com
//http://crackmes.de
//
//


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.IO;
using System.Xml;
using System.Management;

namespace Keygen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnGen_Click(object sender, EventArgs e)
        {
            try
            {
                string D = "Ptuoal7rw4SxO0jt3wgK2C5bJ3QABxVfbsEUztg2wCdyaMfmoWab8SI2bPPLUhgB";
                string DP = "dnNr+7p03Q1jlCE5PtjR4C1QplGOwiIB";
                string DQ = "1selUgUqptgVMuNiPGeOAF4y6DReJ6X9";
                string IQ = "HWqPdnMOr1cq2UA3oPEPJFV34bJCJSkH";
                string E = "AQAB";
                string N = "ygRPNzqg7AUUyf61erN+paBuWMVXagXp7QAm6an+yCjCYeH8udFQlktaiEmGe8aP";
                string P = "4kVxYifwp6OY+oObWwUMsUlmjW7NFAiB";
                string Q = "5I8TvCvqRLK5uJa61qW7nLhXnlQ+M8cP";
                string szName = "iLL_LeaT";

                RSACryptoServiceProvider rsa = new RSACryptoServiceProvider(0x180);

                RSAParameters param = new RSAParameters();
                param.D = Convert.FromBase64String(D);
                param.DP = Convert.FromBase64String(DP);
                param.DQ = Convert.FromBase64String(DQ);
                param.InverseQ = Convert.FromBase64String(IQ);
                param.Exponent = Convert.FromBase64String(E);
                param.Modulus = Convert.FromBase64String(N);
                param.P = Convert.FromBase64String(P);
                param.Q = Convert.FromBase64String(Q);

                rsa.ImportParameters(param);
                List<string> mACAddress = GetMACAddress();
                if ((mACAddress.Count > 0))
                {
                    szName = mACAddress[0];
                }
                byte[] signature = rsa.SignData(new UnicodeEncoding().GetBytes(szName), new SHA1CryptoServiceProvider());
                string serial = "<xml><key>" + szName + "</key><code>" + Convert.ToBase64String(signature) + "</code></xml>";
                txtSerial.Text = Convert.ToBase64String(Encoding.UTF8.GetBytes(serial));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private static List<string> GetMACAddress()
        {
            ManagementObjectCollection instances = new ManagementClass("Win32_NetworkAdapterConfiguration").GetInstances();
            List<string> list = new List<string>();
            foreach (ManagementObject obj2 in instances)
            {
                if ((bool)obj2["IPEnabled"])
                {
                    list.Add(obj2["MacAddress"].ToString().Replace(":", ""));
                }
                obj2.Dispose();
            }
            return list;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}