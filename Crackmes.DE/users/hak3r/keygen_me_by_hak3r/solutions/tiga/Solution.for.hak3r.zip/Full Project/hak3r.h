// hak3r.h : main header file for the HAK3R application
//

#if !defined(AFX_HAK3R_H__65555526_2BB6_4B9B_921A_7D8FFA3A3AFA__INCLUDED_)
#define AFX_HAK3R_H__65555526_2BB6_4B9B_921A_7D8FFA3A3AFA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CHak3rApp:
// See hak3r.cpp for the implementation of this class
//

class CHak3rApp : public CWinApp
{
public:
	CHak3rApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHak3rApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CHak3rApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HAK3R_H__65555526_2BB6_4B9B_921A_7D8FFA3A3AFA__INCLUDED_)
