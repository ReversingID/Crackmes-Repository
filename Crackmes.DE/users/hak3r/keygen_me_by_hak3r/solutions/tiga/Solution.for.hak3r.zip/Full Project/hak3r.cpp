// hak3r.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "hak3r.h"
#include "hak3rDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHak3rApp

BEGIN_MESSAGE_MAP(CHak3rApp, CWinApp)
	//{{AFX_MSG_MAP(CHak3rApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHak3rApp construction

CHak3rApp::CHak3rApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CHak3rApp object

CHak3rApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CHak3rApp initialization

BOOL CHak3rApp::InitInstance()
{
	// Standard initialization

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	CHak3rDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
	}
	else if (nResponse == IDCANCEL)
	{
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
