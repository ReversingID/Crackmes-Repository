// hak3rDlg.cpp : implementation file
//

#include "stdafx.h"
#include "hak3r.h"
#include "hak3rDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHak3rDlg dialog

CHak3rDlg::CHak3rDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CHak3rDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CHak3rDlg)
	m_sName = _T("");
	m_sSerial = _T("");
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CHak3rDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHak3rDlg)
	DDX_Text(pDX, IDC_ENAME, m_sName);
	DDV_MaxChars(pDX, m_sName, 10);
	DDX_Text(pDX, IDC_ESERIAL, m_sSerial);
	DDV_MaxChars(pDX, m_sSerial, 10);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CHak3rDlg, CDialog)
	//{{AFX_MSG_MAP(CHak3rDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BGENERATE, OnBgenerate)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHak3rDlg message handlers

BOOL CHak3rDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CHak3rDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CHak3rDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CHak3rDlg::OnBgenerate() 
{
	//Read Name
	GetDlgItemText(IDC_ENAME, m_sName);

	//Initialize Variable
	int iTotal = 0x1A;

	//Calculate Serial
	for (int i = 0; i < m_sName.GetLength(); i++)
	{
		iTotal += 0x22;
		iTotal += m_sName[i] ^ 0x1A;
	}
	iTotal *= iTotal;

	//Output as Decimal String
	m_sSerial.Format("%d", iTotal);

	//Save Name
	SetDlgItemText(IDC_ESERIAL, m_sSerial);
}
