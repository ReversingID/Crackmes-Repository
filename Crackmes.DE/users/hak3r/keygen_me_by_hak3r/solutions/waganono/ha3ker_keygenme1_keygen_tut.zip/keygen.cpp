#include <windows.h>




void KeyGen(const unsigned char *name,char *serial){
	DWORD ind=0,sum,len;

	// Init
	len = lstrlen((char *)name);

	// Make it :)
	sum = len * 0x22;
	while(ind!=len)
		sum+=(name[ind++]^0x1A);
	sum+=0x1A;
	sum*=sum;

	// Final fight :)
	wsprintf(serial,"%u",sum);
}