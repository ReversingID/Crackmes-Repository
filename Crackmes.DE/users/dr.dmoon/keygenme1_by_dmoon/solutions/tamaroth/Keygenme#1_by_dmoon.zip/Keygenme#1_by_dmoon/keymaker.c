#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <string.h>
#include <math.h>
#include <stdio.h>
#include "keymakerres.h"
#include "md5.h"

static BOOL CALLBACK DialogFunc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam);
void GenerateSerial(char name[]);
char hex_output[16*2 + 1];
char lpName[0x20];

int APIENTRY WinMain(HINSTANCE hinst, HINSTANCE hinstPrev, LPSTR lpCmdLine, int nCmdShow)
{
	char test1[0x20];
	memset(test1, 0, 0x20);
	strcpy(test1, "tamaroth");
	GenerateSerial(test1);
	WNDCLASS wc;
	INITCOMMONCONTROLSEX cc;

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = DefDlgProc;
	wc.cbWndExtra = DLGWINDOWEXTRA;
	wc.hInstance = hinst;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = (HBRUSH) (COLOR_WINDOW + 1);
	wc.lpszClassName = "keymaker";
	RegisterClass(&wc);
	memset(&cc,0,sizeof(cc));
	cc.dwSize = sizeof(cc);
	cc.dwICC = 0xffffffff;
	InitCommonControlsEx(&cc);

	return DialogBox(hinst, MAKEINTRESOURCE(IDD_MAINDIALOG), NULL, (DLGPROC) DialogFunc);

}
static int InitializeApp(HWND hDlg,WPARAM wParam, LPARAM lParam)
{
	return 1;
}

void GenerateSerial(char name[])
{
	md5_state_t state;
	md5_byte_t digest[16];
	memset(hex_output, 0, 16*2+1);
	md5_init(&state);
	md5_append(&state, (const md5_byte_t *)name, 0x20);
	md5_finish(&state, digest);
	for(int a=0; a < 0x10; a++)
		sprintf(hex_output, "%s%X", hex_output, digest[a]);
}

static BOOL CALLBACK DialogFunc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg) {
	case WM_INITDIALOG:
		InitializeApp(hwndDlg,wParam,lParam);
		return TRUE;
	case WM_COMMAND:
		switch (LOWORD(wParam)) {
			case IDOK:
				memset(lpName, 0, 0x20);
				int len = GetDlgItemTextA(hwndDlg, IDC_EDIT0, lpName, 0x20);
				if(len < 5){
					SetDlgItemTextA(hwndDlg, IDC_EDIT3, "Too short name, has to be at least 4 digit long");
					return 1;
				}
				GenerateSerial(lpName);
				SetDlgItemTextA(hwndDlg, IDC_EDIT3, hex_output);
				return 1;
			case IDCANCEL:
				EndDialog(hwndDlg,0);
				return 1;
		}
		break;
	case WM_CLOSE:
		EndDialog(hwndDlg,0);
		return TRUE;

	}
	return FALSE;
}
