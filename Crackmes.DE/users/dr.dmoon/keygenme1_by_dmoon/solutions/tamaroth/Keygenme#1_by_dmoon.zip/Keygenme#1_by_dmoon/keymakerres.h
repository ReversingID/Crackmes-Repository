#define IDD_MAINDIALOG	100
#define IDOK 1
#define IDCANCEL 2
#define IDC_EDIT0 0
#define IDC_EDIT3 3
