
/*
================================
  [ Keygenme#1 by BlZbB ]

   Solution by Dionosis
   January  24, 2010

   Dionosis.RE@gmail.com
================================
*/


#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


void GetPassword( char *nameEntered, char password[13])
{
	int i, j;
	int nameLength;
	unsigned int magic_l, magic_h;

	char byte;
	char *magicTab;
	char carsTab[37]= "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";


	// Mask serial string with dashs in the form of XX-YYYY-ZZZZ
    password[2]= 0x2D;
	password[7]= 0x2D;
	password[12]= 0;


	// Randomizes first part of the serial
	// XX-....-....
	for( i=0; i<2; i++)  {
	    password[i]= carsTab[(unsigned int)(rand()%0x24)];
	}


	// Computes magic dwords
	magic_h= 0;
	for( nameLength=0; nameEntered[nameLength]; nameLength++);

	for( i=0; i<nameLength; i++)  {
		magic_h+= nameEntered[i] * (nameLength-i);  }

	magic_h^=    0x13131313;
	magic_h=     ~magic_h;
	magic_h^=    0x1234ABCD;

	magic_l=     magic_h;
	magic_l&=    0x0F0F0F0F;

	magic_h&=    0xF0F0F0F0;
	magic_h>>=   4;


	// Transforme second part of the serial to ANSI
	// ..-YYYY-....
	magicTab= (char *)&magic_l;

	for( i=0; i<4; i++)  {
		password[i+3]= magicTab[i]<10? magicTab[i]+0x30: magicTab[i]+0x37;
	}


	// Transforme third part of the serial to ANSI
	// ..-....-ZZZZ
	magicTab= (char *)&magic_h;

	for( i=0; i<4; i++)  {
		password[i+8]= magicTab[i]<10? magicTab[i]+0x30: magicTab[i]+0x37;
	}
}


int main( int argc, char *argv[])
{
	char nameEntered[]= "Dionosis\0";
	char password[13];


	srand( time(0));

	printf("\n Solution for '%s' :\n", nameEntered);

	GetPassword( nameEntered, password);
	printf( "\n    > Serial :    %s\n", password);

    printf("\n\n");
	system("pause");


	return 0;
}
