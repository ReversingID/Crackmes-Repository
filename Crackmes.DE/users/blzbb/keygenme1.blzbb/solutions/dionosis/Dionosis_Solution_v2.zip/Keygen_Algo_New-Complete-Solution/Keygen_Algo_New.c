
/*
================================
  [ Keygenme#1 by BlZbB ]

   Solution by Dionosis
   January  24, 2010

   Dionosis.RE@gmail.com
================================
*/


#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


char* Latin2EAscii( char *Source, char *Destination, int maxLength)
{
	int i;
	unsigned char cur;

	char EAscii[ 0x5F] =  {
		      0xAD, 0xBD, 0x9C, 0xCF, 0xBE, 0xDD, 0xF5, 0xF9, 0xB8, 0xA6, 0xAE, 0xAA, 0xF0, 0xA9, 0xEE,
		0xF8, 0xF1,	0xFD, 0xFC, 0xEF, 0xE6, 0xF4, 0xFA, 0xF7, 0xFB, 0xA7, 0xAF, 0xAC, 0xAB, 0xF3, 0xA8,
		0xB7, 0xB5, 0xB6, 0xC7, 0x8E, 0x8F, 0x92, 0x80, 0xD4, 0x90, 0xD2, 0xD3, 0xDE, 0xD6, 0xD7, 0xD8,
		0xD1, 0xA5, 0xE3, 0xE0,	0xE2, 0xE5, 0x99, 0x9E, 0x9D, 0xEB, 0xE9, 0xEA, 0x9A, 0xED, 0xE7, 0xE1,
		0x85, 0xA0, 0x83, 0xC6, 0x84, 0x86, 0x91, 0x87, 0x8A, 0x82, 0x88, 0x89, 0x8D, 0xA1, 0x8C, 0x8B,
		0xD0, 0xA4, 0x95, 0xA2, 0x93, 0xE4,	0x94, 0xF6, 0x9B, 0x97, 0xA3, 0x96, 0x81, 0xEC, 0xE8, 0x98  };

    for( i=0; Source[i] && i<maxLength; i++)  {

		cur= (unsigned char)Source[i];

		Destination[i]= cur<0xA1? cur: EAscii[cur-0xA1];
    }

	return Destination;
}


int ComputeSerial( char *nameEntered, char password[13], int nameLength, char sa, char sb, unsigned int magic_h_startValue)
{
	int i, j;
	unsigned int magic_l, magic_h;

	char byte;
	char *magicTab;


	// Set the first part of the serial
	// XX-....-....
    password[0]= sa;
    password[1]= sb;

	// Computes magic dwords
	magic_h= magic_h_startValue;

	i= magic_h? 0x50: 0;

	for( ; i<nameLength; i++)  {
		magic_h+= ((unsigned char)nameEntered[i]) * (nameLength-i);  }

	magic_h^=    0x13131313;
	magic_h=     ~magic_h;
	magic_h^=    0x1234ABCD;

	magic_l=     magic_h;
	magic_l&=    0x0F0F0F0F;

	magic_h&=    0xF0F0F0F0;
	magic_h>>=   4;

	// Transforme second part of the serial to ANSI
	// ..-YYYY-....
	magicTab= (char *)&magic_l;

	for( i=0; i<4; i++)  {
		password[i+3]= magicTab[i]<10? magicTab[i]+0x30: magicTab[i]+0x37;
	}

	// Transforme third part of the serial to ANSI
	// ..-....-ZZZZ
	magicTab= (char *)&magic_h;

	for( i=0; i<4; i++)  {
		password[i+8]= magicTab[i]<10? magicTab[i]+0x30: magicTab[i]+0x37;
	}


	return 1;
}


int GetPassword( char *nameEntered, char password[13])
{
     int i;
	int nameLength;
	unsigned int magic_h_startValue;

    char sa, sb, samax, sbmax, setop, semax;
	int  sc, sd, se, sf, sg, sh, si, sj;
	int  round;

	char *nameSpecial;
	unsigned int *magicSerial_l, *magicSerial_h, *magicRandom_l, *magicRandom_h;

	char hexTab[16];


    // Allocates the serial and masks it with dashs in the form of XX-YYYY-ZZZZ
    password[2]= 0x2D;
	password[7]= 0x2D;
	password[12]= 0;

	// Randomizes first part of the serial
	// XX-....-....
    sa= (char)('A' + (unsigned int)(rand()%26));
	sb= (char)('A' + (unsigned int)(rand()%26));

    // Retrieve nameEntered's length
    for( nameLength=0; nameEntered[nameLength]; nameLength++);

	if( nameLength>=0x50)  { nameLength= 0x5C; }

	// Allocates a buffer of nameLength char, and copy into it the first 0x50 characters of the name
    nameSpecial= (char*)malloc(nameLength+1);

    for( i=0; i<nameLength; i++)  {
        nameSpecial[i]= nameEntered[i];
    }

	nameSpecial[nameLength]= 0;

	// Converts nameSpecial to extended ascii
	Latin2EAscii( nameSpecial, nameSpecial, nameLength);

    // If the nameEntered's length is lower than 0x50, compute a simple serial
    if( nameLength<0x50)  {

        printf( "\n      Basic computing.");

        return ComputeSerial( nameSpecial, password, nameLength, sa, sb, 0);
    }

    // Else, bruteforce a serial
    else  {

        printf( "\n      Brute forcing...");

        // Generate hexTab
        for( i=0; i<16; i++)  {
            hexTab[i]= i<10? i+0x30: i+0x37;
        }

        // Calculate the fixed part of the sum
        magic_h_startValue= 0;

        for( i=0; i<0x50; i++)  {
            magic_h_startValue+= ((unsigned char)nameSpecial[i]) * (0x5C-i);  }

        // Masks nameSpecial with dashs in the form of XX-YYYY-ZZZZ
        nameSpecial[0x52]= 0x2D;
        nameSpecial[0x57]= 0x2D;
        nameSpecial[0x5C]= 0;

        // Get dwords (YYYY and ZZZZ) addresses
        magicSerial_l= (unsigned int*)(password+3);
        magicSerial_h= (unsigned int*)(password+8);
        magicRandom_l= (unsigned int*)(nameSpecial+0x53);
        magicRandom_h= (unsigned int*)(nameSpecial+0x58);

        // Perform 3 rounds
        samax= 'Z';
        sbmax= 'Z';

        for( round=0; round<3; round++)  {

            // Performe a bruteforce with little optimisations
            for( sj=0; sj<=0xF; sj++)  {
                for( si=0; si<=0xF; si++)  {
                    for( sf=0; sf<=0xF; sf++)  {
                        for( ; sa<=samax; sa++)  {
                            for( ; sb<=sbmax; sb++)  {
                                for( se=0; se<=0xF; se++)  {
                                    for( sh=0; sh<=0xF; sh++)  {
                                        for( sg=0; sg<=0xF; sg++)  {
                                            for( sd=0; sd<=0xF; sd++)  {
                                                for( sc=0; sc<=0xF; sc++)  {

                                                    nameSpecial[0x50]= sa;						 // X1
                                                    nameSpecial[0x51]= sb;						 // X2
                                                    nameSpecial[0x53]= hexTab[sc];				 // Y1
                                                    nameSpecial[0x54]= hexTab[sd];				 // Y2
                                                    nameSpecial[0x55]= hexTab[(se+0xA)&0xF];     // Y3
                                                    nameSpecial[0x56]= hexTab[(sf+0xE)&0xF];	 // Y4
                                                    nameSpecial[0x58]= hexTab[sg];				 // Z1
                                                    nameSpecial[0x59]= hexTab[(sh+0x4)&0xF];	 // Z2
                                                    nameSpecial[0x5A]= hexTab[(si+0xD)&0xF];	 // Z3
                                                    nameSpecial[0x5B]= hexTab[(sj+0xF)&0xF];	 // Z4

                                                    if( ComputeSerial( nameSpecial, password, 0x5C/*nameLength*/, sa, sb, magic_h_startValue))  {

                                                        // If we found a valid serial
                                                        if( (*magicSerial_l==*magicRandom_l) && (*magicSerial_h==*magicRandom_h) )  {

                                                            free( nameSpecial);

                                                            return 1;
                                                        }
                                                    }

                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // If no serial was found, try another start values
            if( round)  {
                sa= '!';
                sb= '!';
                samax= '~';
                sbmax= '~';
            }

            else  {
                sa= 'A';
                sb= 'A';
            }
        }
    }


// If no serial was found
free( nameSpecial);


return 0;
}


int main( int argc, char *argv[])
{
	char nameEntered1[]= "Dionosis\0";
	char nameEntered2[]= "DionosisDionosisDionosisDionosisDionosisDionosisDionosisDionosisDionosisDionosis\0";
	char password[13];


	srand( time(0));


	printf("\n Solution for '%s' :   \n", nameEntered1);

	if( GetPassword( nameEntered1, password))  {
        printf( "\n\n    > Serial :    %s\n", password);
	}
	else  {
	    printf( "\n\n    > Sorry but no serial was found for this name :(\n");
	}


	printf("\n");


	printf("\n Solution for '%s' :   \n", nameEntered2);

    if( GetPassword( nameEntered2, password))  {
        printf( "\n\n    > Serial :    %s\n", password);
	}
	else  {
	    printf( "\n\n    > Sorry but no serial was found for this name :(\n");
	}


    printf("\n\n");
	system("pause");


	return 0;
}
