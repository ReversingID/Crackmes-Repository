#define WIN32_LEAN_AND_MEAN

#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include "resource.h"

class Keygen {
	public:
		static void GenerateKey(char *name, char *key)
		{
			unsigned int eax = 0, ebx = 0;
			char *key2 = new char[16];
		    
			// some hashing or what
			for(unsigned int i = 0; i<strlen(name); i++) {
				eax = name[i];
				eax *= strlen(name)-i;
				ebx += eax;
			}

			ebx  ^= 0x13131313;
			ebx   = ~ebx;
			ebx  ^= 0x1234ABCD;
			eax   = ebx;
			eax  &= 0x0F0F0F0F;
			ebx  &= 0xF0F0F0F0;
			ebx >>= 4;
		    
			// copy ints into key-string
			strncpy(&key2[0], (char *)&eax, 4);
			strncpy(&key2[4], (char *)&ebx, 4);

			// make readable string
			for(int i=0; i<8; i++)
			{
				if(key2[i] > 9)
					key2[i] += 0x37;
				else
					key2[i] |= 0x30;
			}
			key2[8] = '\0';

			// first two characters can be whatever
			// make final string
			sprintf(key, "%c%c-", rand()%25+65, rand()%25+65);
			for(int i=0; i<4; i++)
				key[i+3] = key2[i];
			key[7] = '-';
			for(int i=4; i<8; i++) 
				key[i+4] = key2[i];
			key[12] = '\0';

			return;
		}

		static BOOL CALLBACK DialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
		{
			switch(uMsg)
			{
				case WM_INITDIALOG:
					SetDlgItemText(hwndDlg, IDC_EDIT_NAME,   "DjH2oo7");
					SetDlgItemText(hwndDlg, IDC_EDIT_SERIAL, "Click it!");
					return TRUE;

				case WM_CLOSE:
					EndDialog(hwndDlg, 0);
					return TRUE;

				case WM_COMMAND:
					switch(LOWORD(wParam))
					{
						case ID_GENERATE:
							char *name = new char[255];
							char *key  = new char[16];

							GetDlgItemText(hwndDlg, IDC_EDIT_NAME, name, 255);
							GenerateKey(name, key);
							SetDlgItemText(hwndDlg, IDC_EDIT_SERIAL, key);
							return TRUE;
					}
			}

			return FALSE;
		}
};


int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
	return DialogBox(hInstance, MAKEINTRESOURCE(ID_DIALOG), NULL, Keygen::DialogProc);
}
