=============================
Crackme name: C-rackme #1
Language: C++
Size(In KB): 103
Packed: Yes
Special Packed: Yes
Protection: HardCoded Serial
=============================

Rulez:
No patching allowed! Just find the valid serial.

Gr33tz:
CES, DVS, PhrozenCrew, DiGERATi, xyzero, GOVATENT

Credits:
Haykuro