keygen/solution for OMG keygenme 
     user2k(at)user2k.wz.cz
Included source code(gcc) + linux binary

SOLUTION (someone wanted more text :P):

What we need ? - IDA should be enough

Start from main function (IDA should point us there)
Lets have a look at code -> comments to code to the right :)

00401000 ; int __cdecl main(int argc, const char **argv, const char *envp)
00401000
00401000       sub     esp, 308h
00401006       mov     eax, dword_403000
0040100B       xor     eax, esp
0040100D       mov     [esp+308h+var_4], eax
00401014       push    ebp
00401015       xor     ebp, ebp       ; ebp = 0 -> will be used later

     [......................skipped some lines .......................]

00401069       call    ds:IsDebuggerPresent ; all of these can be
00401069                           ; patched or skipped while debugging 

     [......................skipped some lines .......................]

004010A8       push    eax             ; our username pointer
004010A9       push    offset aS       ; "%s"
004010AE       call    edi ; scanf     ; get string with scanf

     [......................skipped some lines .......................]

004010BB       push    ecx             ; our serial
004010BC       push    offset aS       ; "%s"
004010C1       call    edi ; scanf     ; same like upper

004010C3       lea     eax, [esp+338h+var_104] ; ptr to username
004010CA       add     esp, 24h
004010CD       lea     edx, [eax+1]    ; ptr of second byte in username
004010D0       mov     cl, [eax]       ; get username byte by byte
004010D2       inc     eax             ; by incrasing pointer
004010D3       test    cl, cl          ; and testing if we are at the end
004010D5       jnz     short loc_4010D0 
                                       ; in result we are at byte 0x00
                                       ; after our username
004010D7       sub     eax, edx        ; calculate length of username
004010D9       push    ebx
004010DA       mov     ebx, eax        ; here is our length
004010DC       xor     edi, edi        ; setting index for procedure below
                                       ; (sth like i=0)
004010DE       test    ebx, ebx        ; test if username length is above 0
004010E0       jle     short loc_401105; if not jump there
004010E2
004010E2       call    ds:IsDebuggerPresent ; to nop/skip
004010E8       test    eax, eax             ;       or skip
004010EA       jnz     loc_4012A8           ;          while debugging
004010F0       movsx   edx, [esp+edi+318h+var_104] ; get byte from username
004010F8       imul    edx, 0DEADBEEFh      ; multiply our byte with constant
004010FE       inc     edi                  ; increase index
004010FF       add     ebp, edx             ; at first ebp=0 -> see 401015
004010FF                           ; now we add result from multiply to ebp
00401101       cmp     edi, ebx    ; compare index and length
00401103       jl      short loc_4010E2	; index lower? jump !
00401105       mov     eax, ebp	       ; eax = our result now
00401107       and     eax, 80000001h  ; this is signed check for the % 2
00401107                               ; (modulus from dividing eax by 2)
00401107                               ; ----------------------------------
00401107                               ; check for sign and first bit in eax
00401107                               ; (preserve both if they are set)
0040110C       jns     short loc_401113 ; no sign bit, so we jump
0040110C                               ; if there was first bit
0040110C                               ; it stayed
0040110E       dec     eax             ; but if sign bit = 1
0040110E                               ; we must produce our rest
0040110E                               ; with minus sign (two ways)
0040110E                               ;
0040110E                               ; 1' eax = 80000000h
0040110E                               ; dec eax => 7FFFFFFFh
0040110E                               ; or eax,FFFFFFFEh => FFFFFFFFh
0040110E                               ; inc eax => 0 [so eax %	2 = 0]
0040110E                               ;
0040110E                               ; 2' eax = 80000001h
0040110E                               ; dec eax = 80000000h
0040110E                               ; or eax, FFFFFFFEh => FFFFFFFEh
0040110E                               ; inc eax => FFFFFFFFh
0040110E                               ; [so eax %2 = -1]
0040110F       or      eax, 0FFFFFFFEh
00401112       inc     eax
00401113       jnz     short loc_40112B; eax%2 != 0 jump to second serial
                                       ; generator

00401115       mov     eax, ebp	       ; first way of making serial
00401115                               ; --------------------------
00401115                               ; our result from DEADBEEF-ing
00401115                               ; is in eax now
00401117       cdq                     ; if there was a sign bit in eax
00401117                               ; full edx with bits (FFFFFFFFh) = -1
00401117                               ; and if there wasnt -> clear edx
00401118       sub     eax, edx        ; so if edx=0 nothing change
00401118                               ; but if edx=-1 we add 1 to eax
0040111A       mov     ecx, eax        ; and store result in ecx
0040111C       mov     eax, ebp        ; and one more time our result
0040111C                               ; in eax
0040111E       cdq                     ; CDQ means (Convert Double toQuad)
0040111E                               ; see 401117 comment
0040111F       and     edx, 3          ; if edx = FFFFFFFFh -> and edx,3 = 3
0040111F                               ; else edx = 0
00401122       add     eax, edx        ; so we adding 3 or 0 to our
00401122                               ; result depending on the
00401122                               ; sign of our result
00401124       sar     ecx, 1          ; sar [signed arithmetic shift]
00401124                               ; (preserve highest bit)
00401124                               ; so we signed divide ecx by 2
00401126       sar     eax, 2          ; and signed divide eax by 4
00401129       jmp     short loc_401136;
0040112B ; ---------------------------------------------------------------------------
0040112B       lea     ecx, [ebp+ebp+0]; second way of making serial
0040112B                               ; ---------------------------
0040112B                               ; ecx = our result * 2
0040112F       lea     eax, ds:0[ebp*4]; and eax = our result * 4

00401136       push    ecx             ;SERIAL ITSELF
00401136                               ; ----------------
00401136                               ; ecx value - third part of serial
00401137       push    eax             ; eax value - second part of serial
00401138       push    ebp             ; ebp value - first part of serial
00401139       lea     ecx, [esp+324h+Dest]
00401140       push    offset "%X-%X-%X; there is how our serial
00401140                               ; should look like
00401140                               ; see that there is no
00401140                               ; %08X so if one of our
00401140                               ; values has one or more zeros
00401140                               ; at start, our serial
00401140                               ; could by thinner than others

And thats all, rest is just for good look :) see yea... keygen included

00401145       push    ecx             ; Dest
00401146       call    ds:sprintf
0040114C       push    offset aCalculating ; "\tCalculating"
