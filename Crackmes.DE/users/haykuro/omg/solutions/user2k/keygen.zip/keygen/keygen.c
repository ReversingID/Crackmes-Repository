// keygen for omg by user2k(at)user2k.wz.cz
//  must be easier way to the second part 
//    (after %2 in code)...
// ... but this works.
//
// use in peace :)

#include <string.h>
#include <stdio.h>

int main(void)
{
    char username[255];
    int ulen,i;
    long ebp,eax,ecx;
    ebp = 0;eax = 0;ecx = 0;
    
    printf("enter username : ");
    scanf("%s",&username);
    ulen = strlen(username);
    i=0;
    for (i=0;i<ulen;i++) 			// 0x4010f0
	ebp += (username[i])*0x0DEADBEEF;
    if (ebp%2) {				// 0x401105 if rest from div
	ecx = ebp*2;				// jump here 0x40112b
	eax = ebp*4;				
    }						
    else {
        ecx = ebp;				// 0x401115 if not 
	eax = ebp;				// (rewrited) gcc should
	if (ebp<0)				// have got beeter code
	{					// for that
	    ecx+=1;
	    eax+=3;
	}
	ecx=ecx/2;
	eax=eax/4;
    }
    printf("%X-%X-%X\r\n",ebp,eax,ecx);
    return 0;
}