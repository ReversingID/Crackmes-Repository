#!/bin/sh

gcc keygen.c -o keygen