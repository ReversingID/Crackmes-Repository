Haykuro's OMG keygen by str_2006

Hi.
Nothing special in this keygenme, just some antidebugging checks
with IsDebuggerPresent() and some mul.
For mode info check the src.

if ( IsDebuggerPresent() )
    return 0;
  printf("**********************************\n");
  printf("*      HAYKUROS NOOB KEYGENME    *\n");
  printf("**********************************\n");
  printf("Please enter your name: ");
  scanf("%s", &szName);
  printf("Please enter your serial: ");
  scanf("%s", &szSerial);
  v4 = &szName;
  do
    NameLen = *v4++;
  while ( NameLen );
  v19 = v4 - &Dst;
  v5 = v19;
  v6 = 0;
  if ( v19 <= 0 )
  {
LABEL_7:
    v7 = (part1 & 0x80000001) == 0;
    if ( (part1 & 0x80000001) < 0 )
      v7 = (((part1 & 0x80000001) - 1) | 0xFFFFFFFE) == -1;
    if ( v7 )
    {
      part3 = part1 / 2;
      part2 = part1 / 4;
    }
    else
    {
      part3 = 2 * part1;
      part2 = 4 * part1;
    }
    sprintf(&Dest, "%X-%X-%X", part1, part2, part3);

 while ( !IsDebuggerPresent() )
  {
    v20 = -559038737 * *(&szName + v6++);
    part1 += v20;
    if ( v6 >= v5 )
      goto LABEL_7;
  }
  
  
  
10.06.2008
Best regards
sEby TEAM {RES}