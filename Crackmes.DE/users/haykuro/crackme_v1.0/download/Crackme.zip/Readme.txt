=============
Crackme v1.0
=============

Rules:
No modifying the resource..
Only allowed to patch the bytes..

Credits:
Created by - Haykuro

===============================================================================================
Greetz:
stoner, Kemicza, ILA, Synbios, all of CES, all of DVS, all of The PhrozenCrew, all of DiGERATi
===============================================================================================

===========================
Copyright (c) 2004 Haykuro
===========================