Video Solution to Crackme by Podkn
Solved by MACH4

Tools:
PEID
DeDe
OllyDBG
Visual Studio


If you have problems with the flash video screen size, Google for "SWF Opener" by UnH Solutions, I wouldn't be without it!

Greetz to Podkn, Crackmes.de and all crackers!

MACH4.