#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  FILE *hFile = NULL;

  if(argc<2)
  {
            printf("Usage: keygen <name, 10 chars only!>\n");
            return 0;
  }
  
  int len = strlen(argv[1]);
  if(len != 10)
  {
         printf("Error, the name needs have 10 chars!!!\n");
         return 0;
  }
  
  char password[10];
  memset(password,0,10);
  int i;
  for(i=0;i < 10;i++)
            password[i] = (*(argv[1]+i)) ^  0x16; // a little xor operation
            
  printf("Password: %s\n",password);
  hFile = fopen("password.txt","w");
  if(hFile)
  {
           fwrite(password,1,10,hFile);
           fclose(hFile);
  }
  system("PAUSE");	
  return 0;
}
