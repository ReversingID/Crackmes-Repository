#include <stdio.h>
#include <windows.h>
#include <direct.h>

int getSeconds(void)
{
	SYSTEMTIME SystemTime;
	GetLocalTime(&SystemTime);
	return SystemTime.wSecond;
}

int getMinute(void)
{
	SYSTEMTIME SystemTime;
	GetLocalTime(&SystemTime);
	return SystemTime.wMinute;
}

int getHour(void)
{
	SYSTEMTIME SystemTime;
	GetLocalTime(&SystemTime);
	return SystemTime.wHour;
}

// Returns # of files in this directory
int nFiles(void)
{
	WIN32_FIND_DATA fdata;
    char dir[MAX_PATH];
    HANDLE hFind;
	int n = 0;

    _getcwd(dir,MAX_PATH);

	if(dir[strlen(dir)-1] == '\\') strcat(dir, "*");
	else strcat(dir, "\\*");

    hFind = FindFirstFile(dir, &fdata);

    if (hFind == INVALID_HANDLE_VALUE) 
       return 0;

    do
    {
       if (!(fdata.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) &&
				!(fdata.dwFileAttributes & FILE_ATTRIBUTE_HIDDEN) &&
				!(fdata.dwFileAttributes & FILE_ATTRIBUTE_SYSTEM))
          n++;
    }
    while (FindNextFile(hFind, &fdata) != 0);
 
    FindClose(hFind);
    return n;
}

int main(int argc, char *argv[])
{
	char name[45];
	char serial[128];
	int i;
	DWORD mod;

	printf("CoilBuilt's Keygen for kamikaze's Crackme#4\n");
	printf("Note: only run this from the same directory as the crackme!\n\n");
    printf("Name please (1 or more characters): ");
	gets(name);

	mod = i = 0;
	while(name[i] != '\0')
	{
		mod += ((int)name[i] * getHour()); 
		i++;
	}

	mod ^= 12345;
	mod *= getMinute();

	sprintf(serial,"%d%d123456%02X%d",99*getMinute(),mod,name[0],nFiles());
	
	printf("Serial: %s - valid for %d more seconds\n\n", serial, 60 - getSeconds());
	getchar();
    return 0;
}

