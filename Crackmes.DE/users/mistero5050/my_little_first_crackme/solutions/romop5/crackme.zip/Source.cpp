/*
	"My little first crackme" password decryptor
	Purpose:	to decrypt/recreate original ASCII password from hashed binary
				array that I have found in crackme
	Author:		Romop5 <rom.dobias@gmail.com>
	Note:		the main is stored in the end of document
				reversed with OllyDbg 1.0
*/
#include <stdio.h>
#include <cstring>

// fill ups an array with ascending numbers (for instance, when len is 2, fill up array with 0,1)
void GenerateIteratorArray(unsigned char* array, unsigned int stringlen)
{
	unsigned char counter = 0;
	do
	{
		array[counter] = counter;
		counter++;
	} while (counter < stringlen);
}
void SwapChar(char* string, unsigned int a, unsigned int b)
{
	unsigned char stepchar = string[a];
	string[a] = string[b];
	string[b] = stepchar;
}

// reverse the string
void ReverseString(char* string, unsigned int len)
{
	for (int i = (len / 2)-1; i >= 0; i--)
	{
		SwapChar(string, i, len - i - 1);
	}
}

void AddArrayToString(char* string, unsigned char* array, unsigned int len)
{
	for (int i = 0; i < len; i++)
	{
		string[i] += array[i];
	}
}

void SubtractArrayFromString(char* string, unsigned char* array, unsigned int len)
{
	for (int i = 0; i < len; i++)
	{
		string[i] -= array[i];
	}
}

// len must be even
void SwapCouples(char* string, unsigned int len)
{
	unsigned int newlen = len / 2;
	for (unsigned int i = 0; i < newlen; i++)
	{
		SwapChar(string, i * 2, (i * 2) + 1);
	}
}


void EncryptString(char* string, unsigned int len)
{
	//printf("Before: %s\n",string);
	unsigned char* iteray = new unsigned char[len];
	GenerateIteratorArray(iteray, len);
	//ReverseString(string, len);
	for (int i = 0; i < len; i++)
	{
		ReverseString(string, len);

		//printf("%s = ", string);
		AddArrayToString(string, iteray, len);

		//printf("%s\n", string);
		SwapCouples(string, len);
		//ReverseString(string, len);
		//printf("%d: %s\n",i, string);
	}
	//printf("After: %s\n", string);
}

// This simple function is a reverse function of encrypt function, stored at
// XXX in crackme.exe
// a static array is created which contains ascending numbers (0-(LENGTH-1)
// a this array is used to sum up(during encrypt) or subtract(decrypt) bytes
void DecryptString(char* string, unsigned int len)
{
	unsigned char* iteray = new unsigned char[len];
	GenerateIteratorArray(iteray, len);
	for (int i = 0; i < len; i++)
	{
		// swap couples in string/array (SLOVAKIA->LSVOKAAI)
		SwapCouples(string, len);
		SubtractArrayFromString(string, iteray, len);
		// reverse string (roman->namor)
		ReverseString(string, len);
	}
}

// An useful function for debugging
void printhex(unsigned char* data, unsigned int length)
{
	for (int i = 0; i < length;i++)
		printf("%2X:",data[i]);
	printf("\n");
}


int main()
{
	// password, that is stored in program
	// NOTE: originally, each password byte is stored in DWORD, made up with
	// MOVSX, that's not important for our decrypt/dehash
	unsigned char password[] = { 
		0xA5,0x8F,0xB0,0x87,
		0xB4,0x81,0xB6,0x93,
		0xA1,0x8F,0xB0,0x7F,
		0xB4,0x85,0xB5,0x8F,
		0xAE,0x96,0xAB,0x8E,
		0xA9,0x7F,0xB6,0x88,
		0xAB,0x93,0xA1,0x83,
		0xB4,0x81,0xA5,0x8B,
		0xAF,0x85 };

	// Get original ASCII password from hashed one
	DecryptString((char*)password,34);
	// Print the plain text(at first, make it printable adding \0)
	char result[35];
	memcpy(result, password, 34);
	result[34] = NULL;
	printf("Password is : '%s'\n", result);

	// Encrypt the plaintext
	/* 
	EncryptString((char*)password, 34);
	printhex((unsigned char*)password, 34);
	*/
}