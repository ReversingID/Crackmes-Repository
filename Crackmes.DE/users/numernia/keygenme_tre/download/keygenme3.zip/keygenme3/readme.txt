Keygenme Tre
------------
2010

Protection: Crypto curves...
Level: 4-5...
Language: C++

- This crackme uses a own written biglib, some interesting cryptography implemented with it.
- The crashes when invalid serial is NOT a bug.
- Tested on WinXP SP3
- Keygenerator is the only valid solution.

Best regards to my friends.