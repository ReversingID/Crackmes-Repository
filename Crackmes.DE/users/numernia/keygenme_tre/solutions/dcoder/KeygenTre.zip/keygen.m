p := 3410286041003;
a := 621;
b := 645;
E := EllipticCurve([GF(p)|a,b]);
q := #E;
P := E ! [0x1C08985EE09, 0x1CE7C1306E7];
Q := E ! [0x43DA35440F, 0x65E9A84ED7];
x := 2408408535581;
repeat
	m := Random(2^24);
until (Ceiling(Log(2,m)) mod 2) eq 0;
k := Random(q);
r := (IntegerRing()!(k*P)[1] + m) mod q;
s := (k - x*r) mod q;

str := Sprintf("%o%o%oNM", IntegerToString(m+2^24,16)[2..7],
                           IntegerToString(r+2^44,16)[2..12],
                           IntegerToString(s+2^44,16)[2..12]);
printf "%o-%o-%o-%o-%o-%o-%o-NM", str[1..6], 
                                    str[7..10], 
                                    str[11..14], 
                                    str[15..17], 
                                    str[18..21], 
                                    str[22..25], 
                                    str[26..28];
quit;