Hello Reversers,

This is the first KeygenMe I've ever written. The intention was for me to play with some ideas, learn something along the way AND hopefully be the first to write a KeygenMe specific to 64-bit editions of Windows. This is the result. It's far from rocket science, and I'm sure there's nothing here that you haven't seen before. I do hope you enjoy breaking it into tiny pieces! Patching is a piece of cake, and isn't the intention of this KeygenMe, so please don't bother submitting a patch solution.

As I said, this is my first, so be gentle with me :)

If you manage to reverse it, I'd love to hear from you. Please submit your tutorials, discussions and keygenerators to the Crackmes website, and send them to me too at thecolonial@gmail.com

Cheers!


Info:
Language: C/C++ using Visual Studio 2005 with SP1
Platform: Windows x64 only.

Example working Key:
Name: TheColonial
Email: thecolonial@gmail.com
Serial: tJAw0JiiiiQwwSA0QwSA0QwSA0QwSA0QwSA0QttttttttttttttttttttttQ

Note!: This serial is only valid for my machine :)