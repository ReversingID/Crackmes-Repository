#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    char* name = new char[100];
    cout << "Please input your name: ";
    cin >> name;
    int seed = 0;
    for (int i = 0; i < strlen(name); i++) {
        seed += name[i] * i;
    }
    srand(seed);
    int n1 = rand() + rand();
    int n2 = rand() + rand();
    int n3 = rand() + rand();
    int n4 = rand() + rand();
    cout << "Your serial is: " << n1 << "-" << n2 << "-" << n3 << "-" << n4 << endl;
    cout << "Have a nice day!" << endl;
    system("PAUSE");
    return EXIT_SUCCESS;
}
