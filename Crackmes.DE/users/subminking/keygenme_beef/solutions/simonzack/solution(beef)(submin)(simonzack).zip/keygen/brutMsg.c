#include <stdio.h>
#include <stdlib.h>

#include "beecrypt/md5.h"
#include "beecrypt/sha512.h"

#define bool BOOL
#define true TRUE
#define false FALSE

int main(){
	byte msg[4];
	byte md5_digest[16];
	byte sha512_digest[64];
	md5Param param_md5;
	sha512Param param_sha512;

    unsigned int msgStart,msgEnd;
    FILE* stream;
	stream=fopen("config.txt","r");
	if(stream==NULL){
        puts("Error: cannot find config.txt");
        return 1;
	}
    fscanf(stream,"%08x",&msgStart);
    fscanf(stream,"%08x",&msgEnd);
    fclose(stream);

    unsigned int i;
    //if msgEnd is 0xFFFFFFFF, will go into loop, this fixes it
    bool loopTimes=1;
    if(msgEnd==0xFFFFFFFF){
        loopTimes++;
        msgEnd--;
    }
	for(i=msgStart;i<=msgEnd || (i=0xFFFFFFFF,msgEnd=0,--loopTimes);i++){
        *((DWORD*)msg)=i;
        if((i&0xFFFFFF)==0){
            printf("%02x\n",i>>24);
        }
        if(sha512Reset(&param_sha512)) return -1;
        if(sha512Update(&param_sha512,(byte*)&msg,4)) return -1;
        if(sha512Digest(&param_sha512,sha512_digest)) return -1;
        if(md5Reset(&param_md5)) return -1;
        if(md5Update(&param_md5,(byte*)&sha512_digest,64)) return -1;
        if(md5Digest(&param_md5,md5_digest)) return -1;
        if(md5_digest[0]==0x02 &&
            md5_digest[1]==0x94 &&
            md5_digest[2]==0xD7 &&
            md5_digest[3]==0xE9){
                printf("%02x",msg[0]);
                printf("%02x",msg[1]);
                printf("%02x",msg[2]);
                printf("%02x",msg[3]);
                puts("");
                return 0;
        }
	}
	return 0;
}
