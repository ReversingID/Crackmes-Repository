﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;

namespace keygen{
    class Program{
        public static byte[] hex2bytes(string hexEncoded){
            byte[] buffer = null;
            if ((hexEncoded == null) || (hexEncoded.Length == 0))
            {
                return null;
            }
            try
            {
                int num = Convert.ToInt32((double) (((double) hexEncoded.Length) / 2.0));
                byte[] buffer2 = new byte[(num - 1) + 1];
                int num2 = num - 1;
                for (int i = 0; i <= num2; i++)
                {
                    buffer2[i] = Convert.ToByte(hexEncoded.Substring(i * 2, 2), 0x10);
                }
                buffer = buffer2;
            }
            catch (Exception)
            {
            }
            return buffer;
        }

        public static string bytes2hex(byte[] ba){
            if ((ba == null) || (ba.Length == 0))
            {
                return "";
            }
            StringBuilder builder = new StringBuilder();
            foreach (byte num in ba)
            {
                builder.Append(string.Format("{0:X2}", num));
            }
            return builder.ToString();
        }

        public static byte[] CreateSignature(byte[] p_data,BigInteger G,BigInteger X,BigInteger P){
            // define P -1
            BigInteger x_pminusone = P - 1;
            // create K, which is the random number        
            BigInteger K;
            do {
                K = new BigInteger();
                K.genRandomBits(P.bitCount() -1, new Random());
            } while (K.gcd(x_pminusone) != 1);

            // compute the values A and B
            BigInteger A = G.modPow(K, P);
            BigInteger B = ((K.modInverse(x_pminusone) * (new BigInteger(p_data) - (X * (A)))) % x_pminusone + x_pminusone) % x_pminusone;
            // copy the bytes from A and B into the result array
            byte[] x_a_bytes = A.getBytes();
            byte[] x_b_bytes = B.getBytes();
            // define the result size
            int x_result_size = (((P.bitCount() + 7) / 8) * 2);
            // create an array to contain the ciphertext
            byte[] x_result = new byte[x_result_size];
            // populate the arrays
            Array.Copy(x_a_bytes, 0, x_result, x_result_size / 2 - x_a_bytes.Length, x_a_bytes.Length);        
            Array.Copy(x_b_bytes, 0, x_result, x_result_size - x_b_bytes.Length, x_b_bytes.Length);
            // return the result array
            return x_result;
        }

        public static bool VerifySignature(byte[] p_data, byte[] p_sig,BigInteger G,BigInteger Y,BigInteger P){
            // define the result size
            int x_result_size = p_sig.Length / 2;
            // extract the byte arrays that represent A and B
            byte[] x_a_bytes = new byte[x_result_size];
            Array.Copy(p_sig, 0, x_a_bytes, 0, x_a_bytes.Length);
            byte[] x_b_bytes = new Byte[x_result_size];
            Array.Copy(p_sig, x_result_size, x_b_bytes, 0, x_b_bytes.Length);
            // create big integers from the byte arrays
            BigInteger A = new BigInteger(x_a_bytes);
            BigInteger B = new BigInteger(x_b_bytes);
            // create the two results
            BigInteger x_result1 = (Y.modPow(A, P) * A.modPow(B, P))%P;
            BigInteger x_result2 = G.modPow(new BigInteger(p_data), P);
            // return true if the two results are the same
            return x_result1 == x_result2;
        }

        static bool verifyKey(string name, string key, string signature){
            BigInteger G=new BigInteger("64D35476D95B900B50298E20930C36A18474160B",16);
            BigInteger P=new BigInteger("FBA5A6624D4D1258036D90F2FCE1756BED3B555B",16);
            BigInteger Y=new BigInteger("843A467934285BB42AC90F30FC5CB75691AB0153",16);
            if (VerifySignature(hex2bytes(key), hex2bytes(signature), G, Y, P)){
                SHA512Managed sha512 = new SHA512Managed();
                MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
                BigInteger _name = new BigInteger(name,0x10);
                BigInteger exp = new BigInteger("10001", 0x10);
                BigInteger n = new BigInteger("7AAD2FF13AECB6495384259DA3C709BF5A134974556A5642485FD2D4D76F1709", 0x10);
                BigInteger res = _name.modPow(exp, n);
                string str = Encoding.Default.GetString(res.getBytes());
                return bytes2hex(md5.ComputeHash(sha512.ComputeHash(Encoding.ASCII.GetBytes(str.Substring(str.Length - 4, 4))))).Substring(0, 8) == "0294D7E9";
            }
            return false;
        }

        static string[] genKey(string name,byte[] key){
            BigInteger G = new BigInteger("64D35476D95B900B50298E20930C36A18474160B", 16);
            BigInteger P = new BigInteger("FBA5A6624D4D1258036D90F2FCE1756BED3B555B", 16);
            BigInteger X = new BigInteger("1F0D31F08F1D3B72B566369670CBE6D39A9CC3F6", 16);
            name += "w00t";
            string nameHex = bytes2hex(System.Text.Encoding.ASCII.GetBytes(name));
            BigInteger _name = new BigInteger(nameHex, 0x10);
            BigInteger d = new BigInteger("5C8B8A3F515481AF8F71816F0ABE7C7AEBA85B847C00DE52A4FAFD48041BAC81",0x10);
            BigInteger n = new BigInteger("7AAD2FF13AECB6495384259DA3C709BF5A134974556A5642485FD2D4D76F1709", 0x10);
            BigInteger res = _name.modPow(d, n);
            byte[] str = res.getBytes();
            byte[] signature = CreateSignature(key, G, X, P);
            return new string[] {bytes2hex(str), bytes2hex(key), bytes2hex(signature)};
        }

        static void Main(string[] args){
            /*
            string name = "smk";
            //string nameHex = bytes2hex(System.Text.Encoding.ASCII.GetBytes(name));
            //Console.WriteLine(verifyKey(nameHex, "12345678", "03144DE33B4BBCBED7D4334472498BF72B449CEF4CFE272878BE7D1E25DB410A541190A1BD16D240"));
            byte[] key = { 0x12, 0x34, 0x56, 0x78 };
            string[] res = genKey(name, key);
            Console.WriteLine(res[0]);
            Console.WriteLine(res[1]);
            Console.WriteLine(res[2]);
            Console.WriteLine(verifyKey(res[0],res[1],res[2]));
            Console.Read();
            */
            Console.Write("name: ");
            string name = Console.ReadLine();
            if(name.Length==0){
                Console.WriteLine("please enter a name");
                return;
            }
            Console.Write("key1 (hex string): ");
            string _key = Console.ReadLine().ToUpper();
            if (_key.Length == 0){
                Console.WriteLine("please enter a key");
                return;
            }
            //check if _key is in hex
            if (_key.Length % 2 != 0){
                Console.WriteLine("please enter a key with even length");
                return;
            }
            for (int i = 0; i < _key.Length; i++)
            {
                if ("0123456789ABCDEF".IndexOf(_key[i]) == -1)
                {
                    Console.WriteLine("please enter a hex string");
                    return;
                }
            }
            byte[] key = hex2bytes(_key);
            string[] res = genKey(name, key);
            Console.WriteLine("key1: " + res[1]);
            Console.WriteLine("key2: " + res[0]);
            Console.WriteLine("key3: " + res[2]);
        }
    }
}
