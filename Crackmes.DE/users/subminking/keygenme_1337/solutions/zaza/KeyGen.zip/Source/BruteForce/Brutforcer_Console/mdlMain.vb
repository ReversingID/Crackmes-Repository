﻿Imports System.Security.Cryptography
Imports System.Text

Module mdlMain

    Sub Main()
        Console.WriteLine("Bruteforce start... [" & Now & "]")

        Try

            For X1 = 33 To 122  'From ascii 33 to 122 (4 chars) [spec. symbols + digits + alph...]
                For X2 = 33 To 122
                    For X3 = 33 To 122
                        For X4 = 33 To 122
                            Dim tmpStr As String = Chr(X1) & Chr(X2) & Chr(X3) & Chr(X4)
                            Console.Title = X1.ToString("D3") & "-" & X2.ToString("D3") & "-" & X3.ToString("D3") & "-" & X4.ToString("D3")

                            If CheckKey(tmpStr) Then
                                Console.WriteLine("Key found: " & tmpStr & " [" & X1.ToString("X2") & " " & X2.ToString("X2") & " " & X3.ToString("X2") & " " & X4.ToString("X2") & "]")
                            End If

                        Next
                    Next
                Next
            Next

        Catch ex As Exception
            Console.WriteLine("ERROR!!!    " & Console.Title & vbCrLf & ex.Message, MsgBoxStyle.Critical, "ERROR!")
        End Try

        Console.WriteLine(vbCrLf & "Bruteforce done... [" & Now & "]")

        Console.WriteLine("Press any key...")
        Do While Console.Read = 0
        Loop
        End
    End Sub

    Private Function CheckKey(ByVal key As String) As Boolean
        Try
            Dim buffer2 As Byte() = New MD5CryptoServiceProvider().ComputeHash(Encoding.Default.GetBytes(key.Substring((key.Length - 4), 4)))
            Dim str2 As String = Nothing
            Dim num As Byte
            For Each num In buffer2
                str2 = (str2 & num.ToString("X2"))
            Next

            Return (str2.Substring(0, 8) = "92253E43")

        Catch exception1 As Exception
            Return False
        End Try
    End Function

End Module
