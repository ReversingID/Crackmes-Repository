﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Форма переопределяет dispose для очистки списка компонентов.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Является обязательной для конструктора форм Windows Forms
    Private components As System.ComponentModel.IContainer

    'Примечание: следующая процедура является обязательной для конструктора форм Windows Forms
    'Для ее изменения используйте конструктор форм Windows Form.  
    'Не изменяйте ее в редакторе исходного кода.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtSerial = New System.Windows.Forms.TextBox()
        Me.btnGenerate = New System.Windows.Forms.Button()
        Me.lnkZaZa = New System.Windows.Forms.LinkLabel()
        Me.SuspendLayout()
        '
        'txtSerial
        '
        Me.txtSerial.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.txtSerial.Location = New System.Drawing.Point(12, 12)
        Me.txtSerial.Name = "txtSerial"
        Me.txtSerial.ReadOnly = True
        Me.txtSerial.Size = New System.Drawing.Size(371, 31)
        Me.txtSerial.TabIndex = 0
        Me.txtSerial.Text = "12345678901234561234567890123456"
        Me.txtSerial.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnGenerate
        '
        Me.btnGenerate.Location = New System.Drawing.Point(264, 49)
        Me.btnGenerate.Name = "btnGenerate"
        Me.btnGenerate.Size = New System.Drawing.Size(119, 24)
        Me.btnGenerate.TabIndex = 1
        Me.btnGenerate.Text = "Generate it..."
        Me.btnGenerate.UseVisualStyleBackColor = True
        '
        'lnkZaZa
        '
        Me.lnkZaZa.AutoSize = True
        Me.lnkZaZa.Location = New System.Drawing.Point(12, 55)
        Me.lnkZaZa.Name = "lnkZaZa"
        Me.lnkZaZa.Size = New System.Drawing.Size(47, 13)
        Me.lnkZaZa.TabIndex = 6
        Me.lnkZaZa.TabStop = True
        Me.lnkZaZa.Text = "by ZaZa"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(395, 85)
        Me.Controls.Add(Me.lnkZaZa)
        Me.Controls.Add(Me.btnGenerate)
        Me.Controls.Add(Me.txtSerial)
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Keygen for SK's KeygenMe #1337"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtSerial As System.Windows.Forms.TextBox
    Friend WithEvents btnGenerate As System.Windows.Forms.Button
    Friend WithEvents lnkZaZa As System.Windows.Forms.LinkLabel

End Class
