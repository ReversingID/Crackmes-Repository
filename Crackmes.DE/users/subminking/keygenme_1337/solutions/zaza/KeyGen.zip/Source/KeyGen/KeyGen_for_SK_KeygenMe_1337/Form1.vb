﻿Imports System.Numerics
Imports System.Globalization
Imports System.Security.Cryptography
Imports System.Text

Public Class frmMain

    Private Sub lnkZaZa_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkZaZa.LinkClicked
        System.Diagnostics.Process.Start("http://crackmes.de/users/zaza")
    End Sub

    Private Sub btnGenerate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGenerate.Click
        txtSerial.Text = GetKey()
    End Sub

    Private Function GetKey() As String
        Dim bytes(15) As Byte
        'It's a RSA... ))
        Dim exp As New BigInteger(&H10001)  'It's a EXP
        Dim d As BigInteger = BigInteger.Parse("597623D719AEAD965149DC461D5CCB41", NumberStyles.HexNumber)  'It's a D...
        Dim n As BigInteger = BigInteger.Parse("75B677A38DE2ED08D6EA9C7DE3D4CC61", NumberStyles.HexNumber)  'It's a N

CheckKey_Label:
        bytes(0) = &H57 : bytes(1) = &H42 : bytes(2) = &H35 : bytes(3) = &H42   'B5BW (Reverse = WB5B)

        For I = 4 To 15 'Randomize...
Ret_Label:
            Randomize()
            Dim RND_byte As Integer = Rnd() * 255
            If RND_byte < 1 Or RND_byte > 255 Then GoTo Ret_Label
            bytes(I) = CByte(RND_byte)
        Next

        'Calculating
        Dim [integer] As New BigInteger(bytes)
        Dim tmpIntKey As BigInteger = BigInteger.ModPow([integer], d, n)
        If tmpIntKey.Sign < 0 Then GoTo CheckKey_Label

        Dim Key As String = tmpIntKey.ToString("X")
        'Dim Key As String = "650347D84FCE7450D8895C5F2C8CA614"

        'Verifying...
        If CheckKey(Key) Then
            Dim intKey As BigInteger = New BigInteger(bytes)
            Dim HEXKey As BigInteger = BigInteger.ModPow(intKey, d, n)
            'If calculating value >0 OK! else repeating...
            If HEXKey.Sign < 0 Then GoTo CheckKey_Label

            Clipboard.SetText(HEXKey.ToString("X")) 'Copy to clipboard
            Return HEXKey.ToString("X")
        Else
            GoTo CheckKey_Label
        End If

    End Function

    Private Function CheckKey(ByVal key As String) As Boolean
        Try

            Dim [integer] As BigInteger = BigInteger.Parse(key, NumberStyles.HexNumber)
            Dim exp As BigInteger = BigInteger.Parse("10001", NumberStyles.HexNumber)
            Dim n As BigInteger = BigInteger.Parse("75B677A38DE2ED08D6EA9C7DE3D4CC61", NumberStyles.HexNumber)
            Dim bytes As Byte() = BigInteger.ModPow([integer], exp, n).ToByteArray

            Array.Reverse(bytes)

            Dim str As String = Encoding.Default.GetString(bytes)
            Dim buffer2 As Byte() = New MD5CryptoServiceProvider().ComputeHash(Encoding.Default.GetBytes(str.Substring((str.Length - 4), 4)))
            Dim str2 As String = Nothing
            Dim num As Byte
            For Each num In buffer2
                str2 = (str2 & num.ToString("X2"))
            Next
            Return (str2.Substring(0, 8) = "92253E43")
        Catch exception1 As Exception
            Return False
        End Try
    End Function

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtSerial.Text = GetKey()
    End Sub

End Class
