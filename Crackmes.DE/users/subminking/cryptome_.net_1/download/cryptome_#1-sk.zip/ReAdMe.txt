*************************************
**                                 **
** Name        : CryptoMe .NET #1  **
** Coding      : Average           **
** Protection  : Average/Hard      **
**                                 **
** Restrictions: No patching!      **
**                                 **
*************************************

This simple CryptoMe has just a few
algos - But there is one major rule:
NO PATCHING whatsoever!

Tools needed:
-------------
Brain


Goal:
-----
Best - Make a keygen in any other language
       than .NET...
Good - Make a keygen in .NET...
Bad  - Keygen + Patch (NOT ALLOWED!)


..:: GREETZ ::..
----------------
To the ones that support me the most!

/Regards, SubmiN|KinG