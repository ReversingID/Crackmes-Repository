﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ASCIIEncoding encoding = new ASCIIEncoding();
            textBox2.Text = Convert.ToBase64String(EncryptData(encoding.GetBytes(textBox1.Text), "A306E8546BC58861", PaddingMode.None));
        }
        public static byte[] EncryptData(byte[] data, String password, PaddingMode paddingMode)
        {
            RijndaelManaged rm = new RijndaelManaged();
            ASCIIEncoding encoding = new ASCIIEncoding();
            byte[] key = encoding.GetBytes(password);
            rm.BlockSize = 0x80;
            rm.KeySize = 0x80;
            rm.Padding = PaddingMode.ISO10126;
            rm.Mode = CipherMode.ECB;
            rm.GenerateIV();
            rm.Key = key;
            ICryptoTransform encryptor = rm.CreateEncryptor(key, rm.IV);
            using (MemoryStream msEncrypt = new MemoryStream())
            using (CryptoStream encStream = new
            CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
            {
                encStream.Write(data, 0, data.Length);
                encStream.FlushFinalBlock();
                return msEncrypt.ToArray();
            }
        }
    }
}
