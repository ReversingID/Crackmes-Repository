*******************n00b*******************
******************************************
** Product   : KeygenMe No.8            **
** Langauge  : .NET 2.x                 **
** Protection: Thats for u to find out;)**
**                                      **
** Difficult : 4 out of 10 :=)          **
** Solution  : Keygen only!!            **
**************************************2007
******************************************

This KeygenMe is written in .NET and is
hopefully a bit harder than the usual .NET
keygenme you can find out there...

Anyhow, the rules are simple;
-------------------------------------------
1: NO PATCHING!
2: KEYGEN ONLY!

-----------------------------------EXAMPLE-
Name: n00b
Code: gnfJkYkKb57y71vO4lg7Lw==


/(C)2007 n00b