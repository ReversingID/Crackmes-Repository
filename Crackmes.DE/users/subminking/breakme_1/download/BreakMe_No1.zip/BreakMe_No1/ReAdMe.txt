SK's BreakMe #1:
----------------
Written in .NET, and the following rules apply:
-NO PATCHING
-NO BRUTEFORCE
-NO CHEATING
-KEYGEN ONLY!


/Enjoy this one!