

Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim str As String = String.Format("{0:X2}", TextBox3.Text)
        Dim str2 As String = String.Format("{0:X2}", (str.Length * &H7D8).ToString)
        TextBox4.Text = str & "-" & str2

        Dim buffer As Byte() = New Security.Cryptography.MD5CryptoServiceProvider().ComputeHash(System.Text.Encoding.Default.GetBytes(TextBox3.Text))
        Dim builder As New System.Text.StringBuilder
        Dim num As Byte
        For Each num In buffer
            builder.Append(String.Format("{0:X2}", num))
        Next
        TextBox5.Text = builder.ToString

    End Sub

End Class
