#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

void print_serial(char *name);

int main(int argc, char **argv)
{
	char name[64];
	int done;

	do 
	{
		printf("Enter name: ");
		done = scanf("%s", &name);

		if (strlen(name) > 0xA) {
			printf("Name must be less than 11 characters\n");
			done = 0;
		}
	} while (!done);
	
	print_serial(name);

	return 1;
}

void print_serial(char *name)
{
	int i;
	DWORD EAX, ESI, EDX, ECX;

	EAX = ECX = 0x0;
	ESI = EDX = 0x3;

	for (i = 0; i < strlen(name); i++)
	{
		EAX = name[i];
		ECX = EDX + EAX;
		ECX *= ESI;
		ESI = EAX * 8;
		ESI -= EAX;
		EDX++;
		ESI += ECX + 0x1341;
	}

	ESI &= 0xDEADBEEF;

	printf("Serial: %d\n", ESI);
}