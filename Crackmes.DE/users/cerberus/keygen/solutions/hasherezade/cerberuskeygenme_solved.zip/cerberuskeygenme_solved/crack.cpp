/*
 * Solution for cerberus keygenme
 * coded by hasherezade
 *
 * */

#include <cstdlib>
#include <iostream>

using namespace std;

char user[50];
int ebp=0x32;
int esi=0x18;


int Loop1(){
    int eax,edx,i=0;
    int ebx=0x400;
    int len=strlen(user);
    int var_164;
    do{
       	eax=user[i]+0x56b;
        esi+=eax^0x890428;
        edx=(user[3]+len)^0x209;
        if(len<=9){
            edx*=esi;
            ebx+=edx;  
        }else{
            edx*=ebx;
            esi+=edx; 
	} 
        edx=(eax<<7)+eax;
        edx=ebx+(eax+edx*8)*4;
        var_164=ebx=edx;
	i++;
    }while(i<len);
    return var_164;
}


void Loop3(){
    int j=1;
    int i=5;
    int eax,edx,ecx;
    do{
        eax=user[j]+0x23;
        ebp=user[0]+ebp+0x134a;
        ecx=eax+eax*2;
        ecx+=ecx*4;
        edx=ecx+ecx*4;
        eax+=edx*4;
        esi+=eax*2;
        strrev(user);
        j++;
    }while(--i);
}

int Loop2(){
    int edi=5;
    int esp=0;
    int eax;
    do{ 
        eax=user[edi];
        ebp+=0x134a+eax;
        strrev(user);
        edi--;
    }while(edi>0);
    return ebp;
}

int main(int argc, char *argv[])
{
    int eax,edx;
    cout<<"user: ";
    fgets(user, 50, stdin);
    for(int i=strlen(user)-1;i>0;i--){
    	if(user[i]=='\n') 
		user[i]='\0';
    }
    if(strlen(user)<5){
    	cout<<"Supply a username longer than 4"<<endl;
	system("PAUSE");
	return EXIT_FAILURE;
    }

    int k1,k2;
    int var_164=Loop1();
    Loop2();
    Loop3();
    k2=(0x18-user[5])^(ebp+var_164);
    k1=(0x1337-user[2])^(esi+0x3c);
    
    printf("key:  LNT-%d-%d\n",k1,k2);
    system("PAUSE");
    return EXIT_SUCCESS;
}
