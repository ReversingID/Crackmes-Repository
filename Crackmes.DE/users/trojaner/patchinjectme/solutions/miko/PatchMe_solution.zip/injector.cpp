/*
Solution by Miko ((c)Digital, 2013. Visit http://deepinsecurity.blogspot.com)

You may also find this solution with pictures at my blog: http://deepinsecurity.blogspot.com/2013/11/crackmes-reverse-write-up-trojaners.html
*/

#include <windows.h>
 
BOOL InjectLibrary(HANDLE hProcess, char *fnDll) {
 
    BOOL success = FALSE;
    HANDLE hThread = NULL;
    char *fnRemote = NULL;
    FARPROC procLoadLibraryA = NULL;
 
    size_t lenFilename = strlen(fnDll) + 1;
 
    /* Allocate space in the remote process */
    fnRemote = (char *)VirtualAllocEx(hProcess, NULL, lenFilename, MEM_COMMIT, PAGE_READWRITE);
     
    if (fnRemote) {
 
        /* Write the filename to the remote process. */
        if (WriteProcessMemory(hProcess, fnRemote, fnDll, lenFilename, NULL)) {
 
            /* Get the address of the LoadLibraryA function */
            procLoadLibraryA = GetProcAddress(GetModuleHandle("Kernel32"), "LoadLibraryA");
            hThread = CreateRemoteThread(hProcess, NULL, 0, (LPTHREAD_START_ROUTINE)procLoadLibraryA, fnRemote, 0, NULL);
 
            if (hThread) {
                WaitForSingleObject(hThread, INFINITE);
                success = TRUE;
            }
        }
 
        VirtualFreeEx(hProcess, fnRemote, 0, MEM_RELEASE);
    }
 
    return success;
}
 
int main() { 
	STARTUPINFO info;
	PROCESS_INFORMATION process_info;
	ZeroMemory(&info, sizeof(STARTUPINFO));
	info.cb = sizeof(STARTUPINFO);
	
	if (CreateProcess("PatchMe.exe",NULL, NULL,NULL,NULL,NORMAL_PRIORITY_CLASS |CREATE_SUSPENDED,NULL,NULL,&info,&process_info) == TRUE)
	{
		InjectLibrary(process_info.hProcess, "injection.dll");	
	}
	ResumeThread(process_info.hThread);
    
    return 0;
}