/*
Solution by Miko ((c)Digital, 2013. Visit http://deepinsecurity.blogspot.com)

You may also find this solution with pictures at my blog: http://deepinsecurity.blogspot.com/2013/11/crackmes-reverse-write-up-trojaners.html
*/
#include <windows.h>
#include <stdio.h>

#include <Psapi.h>
#include <stdio.h>
#include <tchar.h>
#include <strsafe.h>

#define FIRST_USE_OFFSET -0x949
#define SECOND_USE_OFFSET -0x8b3

void ErrorExit(LPTSTR lpszFunction);
void patchJump(LPVOID moduleEntryPoint, DWORD patchOffset, LPVOID targetToJump, BOOL printBeforeAndAfter = TRUE);

void returnOne()
{
	printf("returnOne called\n");
	__asm {
		mov eax, 1
	}

}
void printCurrentProcessMemoryAtAddress(LPVOID address,SIZE_T dwLen)
{
	unsigned char* mem = new unsigned char[dwLen];
	SIZE_T read;

	if (ReadProcessMemory(GetCurrentProcess(), address,mem,dwLen,&read) == FALSE) 
	{
		ErrorExit(TEXT("ReadProcessMemory"));
	}
	else 
	{
		int lineCount = read / 16;
		for(int i = 0; i < lineCount; i++)
		{
			printf("line %d :",i);
			int columnCount = ((i == lineCount - 1) ? ((read % 16 == 0)? 16 : read % 16) : 16 );
			for ( int j = 0; j < columnCount; ++j)
			{
				printf("%02hhX ", mem[i * 16 + j]);
			}
			printf("\n");
		}
	}
	delete[] mem;
}
bool APIENTRY DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved) {

	if (dwReason == DLL_PROCESS_ATTACH) {
		HMODULE modules[1024];
		DWORD cbNeeded;
		MODULEINFO module_info;

		printf("DLL injection by Digital\n");
		printf("Pointer to returnOne:%08x\n", returnOne);
		returnOne();
		if (EnumProcessModules(GetCurrentProcess(),modules,sizeof(modules),&cbNeeded))
		{
			for (DWORD i = 0; i < cbNeeded / sizeof(HMODULE); ++i)
			{
				TCHAR szModName[MAX_PATH];
				if ( GetModuleFileNameEx( GetCurrentProcess(), modules[i], szModName,sizeof(szModName) / sizeof(TCHAR)))
				{
					_tprintf( TEXT("\t%s (0x%08X)\n"), szModName, modules[i] );
				}
			}
		}

		if (GetModuleInformation(GetCurrentProcess(),modules[0],&module_info, sizeof(module_info)) == FALSE)
		{
			ErrorExit(TEXT("GetModuleInformation"));
		}
		printf("EntryPoint:%08x\n",module_info.EntryPoint);

		patchJump(module_info.EntryPoint,FIRST_USE_OFFSET,returnOne);
		patchJump(module_info.EntryPoint,SECOND_USE_OFFSET,returnOne);
	}

	return true;
}

void patchJump(LPVOID moduleEntryPoint, DWORD patchOffset, LPVOID targetToJump, BOOL printBeforeAndAfter)
{
	LPCH address = (LPCH)moduleEntryPoint + patchOffset;
	DWORD offsetForJump = 0;
	DWORD written = 0;
	UCHAR patch[5];

	if (printBeforeAndAfter)
	{
		printCurrentProcessMemoryAtAddress(address ,30);
	}

	offsetForJump =  (DWORD)returnOne - (DWORD)address - 5;
	printf("Jump offset : %08x\n", offsetForJump);

	patch[0] = (unsigned char)0xe8;
	*(PDWORD)&patch[1] = offsetForJump;

	if (WriteProcessMemory(GetCurrentProcess(),address,patch, sizeof(patch), &written) == FALSE || written != sizeof(patch))
	{
		ErrorExit(TEXT("WriteProcessMemory"));
	}
	printf("After:\n");
	if (printBeforeAndAfter)
	{
		printCurrentProcessMemoryAtAddress(address,30);
	}
}

void ErrorExit(LPTSTR lpszFunction) 
{ 
	LPVOID lpMsgBuf;
	LPVOID lpDisplayBuf;
	DWORD dw = GetLastError(); 

	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM |
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		dw,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR) &lpMsgBuf,
		0, NULL );

	lpDisplayBuf = (LPVOID)LocalAlloc(LMEM_ZEROINIT, 
		(lstrlen((LPCTSTR)lpMsgBuf) + lstrlen((LPCTSTR)lpszFunction) + 40) * sizeof(TCHAR)); 
	StringCchPrintf((LPTSTR)lpDisplayBuf, 
		LocalSize(lpDisplayBuf) / sizeof(TCHAR),
		TEXT("%s failed with error %d: %s"), 
		lpszFunction, dw, lpMsgBuf); 
	MessageBox(NULL, (LPCTSTR)lpDisplayBuf, TEXT("Error"), MB_OK); 

	LocalFree(lpMsgBuf);
	LocalFree(lpDisplayBuf);
	ExitProcess(dw); 
}