Hopefully interesting windows keygenme.

Written purely in C++ for your pleasure.

No obfuscation or anti-debug.


 - GiM, Apr/May 2012

