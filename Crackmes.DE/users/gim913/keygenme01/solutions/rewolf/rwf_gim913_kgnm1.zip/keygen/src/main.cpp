#include <Windows.h>
#include <string>
#include <vector>
#include "M_APM.H"

void createValue(MAPM& v, unsigned char* data, unsigned int dataSize)
{
	v = 0;
	for (unsigned int i = 0; i < dataSize; i++)
	{
		v *= 0x100;
		v += data[i];
	}
}

void printValue(MAPM& v, char* prefix = 0)
{
	char str[0x100];
	str[0] = 0;
	v.toFixPtString(str, 10);
	if (prefix)
		printf("%s: ", prefix);
	printf("%s\n", str);
}

void sub_40136D(MAPM& v1, MAPM& _A, MAPM& B, MAPM& _C)
{
	MAPM A = _A;
	MAPM C = _C;
	if (C != 0)
	{
		if ((C % 2) != 0)
		{
			B = (B * A) % v1;
		}
		A = (A * A) % v1;
		C = C.integer_divide(2);
		sub_40136D(v1, A, B, C);
	}
}

MAPM powmod(MAPM& v, MAPM& exp, MAPM& mod)
{
	MAPM B = 1;
	sub_40136D(mod, v, B, exp);
	return B;
}

MAPM EEA(MAPM& a, MAPM& b)
{
	MAPM u = 1;
	MAPM x = 0;
	MAPM w = a;
	MAPM z = b;

	while (w != 0)
	{
		if (w < z)
		{
			MAPM t = u;
			u = x;
			x = t;

			t = w;
			w = z;
			z = t;
		}
		MAPM q = w.integer_divide(z);
		u = u - q*x;
		w = w - q*z;
	}
	if (x < 0)
		x += b;

	return x;
}

MAPM legendre_symbol(MAPM& a, MAPM& p)
{
	MAPM ret = powmod(a, (p - 1)/2, p);
	return (ret == p - 1) ? -1 : ret;
}

MAPM modular_sqrt(MAPM& a, MAPM& p)
{
	if (legendre_symbol(a, p) != 1)
		return 0;
	else if (a == 0)
		return 0;
	else if (p == 2)
		return p;
	else if ((p % 4) == 3)
		return powmod(a, (p + 1) / 4, p);

	MAPM s = p - 1;
	MAPM e = 0;
	while ((s % 2) == 0)
	{
		s /= 2;
		e += 1;
	}

	MAPM n = 2;
	while (legendre_symbol(n, p) != -1)
		n += 1;

	MAPM x = powmod(a, (s + 1)/2, p);
	MAPM b = powmod(a, s, p);
	MAPM g = powmod(n, s, p);
	MAPM r = e;

	while (1)
	{
		MAPM t = b;
		MAPM m = 0;
		for (; m < e; m++)
		{
			if (t == 1)
				break;
			t = powmod(t, MAPM(2), p);
		}
		if (m == 0)
			return x;

		MAPM gs = powmod(g, pow(2, r - m - 1), p);
		g = (gs * gs) % p;
		x = (x * gs) % p;
		b = (b * g) % p;
		r = m;
	}
}

void base36(int v, char* outBuf, int pad = 0)
{
	static const char charset[] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	char* t = outBuf;
	int i = 0;
	while (v != 0)
	{
		*t++ = charset[v % 36];
		v /= 36;
		i++;
	}
	for (; i < pad; i++)
	{
		*t++ = '0';
	}
	*t = 0;
	strrev(outBuf);
}

int mapm2int(MAPM& v)
{
	char temp[0x100];
	v.toIntegerString(temp);
	int tmp;
	sscanf(temp, "%d", &tmp);
	return tmp;
}

bool parity(unsigned int v)
{
	v ^= v >> 16;
	v ^= v >> 8;
	v ^= v >> 4;
	v &= 0xf;
	return ((0x6996 >> v) & 1) ? true : false;
}

void printSerialNumber(MAPM& v)
{
	char ser1[32];
	int tmp = mapm2int(2*(v % 0x1000000));
	if (parity(tmp))
		tmp++;
	base36(tmp, ser1, 5);
	v = v.integer_divide(0x1000000);

	char ser2[32];
	tmp = mapm2int(2*(v % 0x1000000));
	if (parity(tmp))
		tmp++;
	base36(tmp, ser2, 5);
	v = v.integer_divide(0x1000000);

	char ser3[32];
	tmp = mapm2int(2*(v % 0x1000000));
	if (parity(tmp))
		tmp++;
	base36(tmp, ser3, 5);
	printf("%s%s%s\n", ser3, ser2, ser1);
}

extern "C" void __stdcall _rwf_md5(unsigned char* outBuf, char* inBuf, int inSize);

int main(int argc, char* argv[])
{
	if (argc != 2)
	{
		printf("Usage:\n    %s your_name\n", argv[0]);
		return 0;
	}

	unsigned char str_md5[0x10];
	_rwf_md5(str_md5, argv[1], strlen(argv[1]));

	MAPM _mod;
	unsigned char str[] = "gim913!\x95";
	createValue(_mod, str, sizeof(str) - 1);
	//printValue(_mod);

// 	unsigned char str_md5[] = 
// 	{ 
// 		0xf8, 0x35, 0xfb, 0x4e, 0x4e, 0x31, 0x3b, 0xf1, 
// 		0xd1, 0x26, 0x8e, 0xdd, 0x3c, 0xa9, 0x28, 0x0f 
// 	};
	MAPM _a;
	MAPM _b;
	MAPM _c;
	MAPM v5;
	createValue(_a, str_md5, 5);
	createValue(_b, str_md5 + 5, 5);
	createValue(_c, str_md5 + 10, 5);
	createValue(v5, str_md5 + 15, 1);

	_b = (512 * _b) + v5;

	MAPM A = (_b * _b) - (4 * _a * _c);
	if (A >= 0)
	{
		A %= _mod;

		MAPM B = 1;
		sub_40136D(_mod, A, B, (_mod - 1)/2);
		if (B != 1)
		{
			printf("Wrong username.\n");
			return 0;
		}
	}

	MAPM delta = _b*_b - 4*_a*_c;
	delta = modular_sqrt(delta, _mod);

	MAPM x1 = (- _b - delta) * EEA(2*_a, _mod);
	MAPM x2 = (- _b + delta) * EEA(2*_a, _mod);
	x1 %= _mod;
	x2 %= _mod;
	if (x1 < 0)
		x1 += _mod;
	if (x2 < 0)
		x2 += _mod;

	//
	printf("Serial 1: "); printSerialNumber(x1);
	printf("Serial 2: "); printSerialNumber(x2);
	//
	return 0;
}

