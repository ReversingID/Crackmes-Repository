#include <stdio.h>
#include <stdlib.h>

int main()
{
	char username[20] = {0};
	char sn[7] = {0};

	printf("plz input your name (must length of 6):");
	gets(username);

	long resultofname = 0;
	for(int i = 0; i < 6; i++)
		resultofname = (resultofname + username[i]) ^ 0xC;

	resultofname ^= 0xC;
	
	long s = resultofname;
	for(i = 0; i < 6; i++)
	{
		if(s > 0x100)
		{
			s -= 'z';
			sn[5-i] = 'z';
			s ^= 0x1a;
		}
		else
		{
			if(i == 5)
				sn[5-i] = s;
			else
			{
				s -= 'A';
				sn[5-i] = 'A';
				s ^= 0x1a;
			}
		}
	}

	printf("the sn is not unique.\nthe sn for you is: %s\n",sn);
	return 0;
}