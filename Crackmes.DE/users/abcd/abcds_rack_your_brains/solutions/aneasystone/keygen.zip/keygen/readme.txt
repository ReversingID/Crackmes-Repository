
sorry for that i haven't written a tutorial for you.
but the keygen i think can lets you understand this crackme.
thanks for your supports.

----------------lined by aneasystone--------------------
use the exception of DividedByZero.
at first, the username and sn is requested to be length of 6.
second, we need to know the steps of calculation;
and the process is like following:
(for example: username = "easyst")
and the result = (((('e'^0xc+'a')^0xc+'s')^0xc+'y')^0xc+'s')^0xc+'t' = 0x028d
(for example: sn = "123456")
and then the result of sn is : (((('1'^0x1a+'2')^0x1a+'3')^0x1a+'4')^0x1a+'5')^0x1a+'6' = 0x????

plz look at here:
00401148   .  83F9 06       cmp     ecx, 6
0040114B   .  7D 23         jge     short 00401170
0040114D   .  0FBEB40D D8FE>movsx   esi, byte ptr [ebp+ecx-128]-------- username
00401155   .  83F0 0C       xor     eax, 0C
00401158   .  03C6          add     eax, esi
0040115A   .  8945 DC       mov     [ebp-24], eax
0040115D   .  0FBEB40D D8FD>movsx   esi, byte ptr [ebp+ecx-228]-------- sn
00401165   .  83F2 1A       xor     edx, 1A
00401168   .  03D6          add     edx, esi
0040116A   .  8955 D8       mov     [ebp-28], edx
0040116D   .  41            inc     ecx
0040116E   .^ EB D5         jmp     short 00401145
00401170   >  8BC8          mov     ecx, eax
00401172   .  2BCA          sub     ecx, edx--------------------------- ecx=ecx-edx 
00401174   .  99            cdq
00401175   .  F7F9          idiv    ecx-------------------------------- eax=eax/ecx ;HOW ABOUT ECX=0 !

when i began to crack this, i tried so many times, 
at the end i found that whatever i input, the result is same. i failed.
and then i realized the importance of the word
EXCEPTION!
i tried to find an exception,so easy one: DividedByZero

and now the question is how to find a sn
whose result after calculting is equal to the result of username
then i take a try to make a keygen like following
but i know it is not the unique one.
the keygen is not so good, shame on myself...

--------------lined by aneasystone-------------------
									by aneasystone 
									2008.4.10
