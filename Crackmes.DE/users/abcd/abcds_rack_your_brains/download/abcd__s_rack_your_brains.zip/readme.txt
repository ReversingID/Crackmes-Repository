This is a tough one,make no exception.

Find the correct username/password combination.
Keygen it....or give 3 possible combinations...
(Hint already given in question itself :P)

Happy reverse engineering,
Regards,
abcd 