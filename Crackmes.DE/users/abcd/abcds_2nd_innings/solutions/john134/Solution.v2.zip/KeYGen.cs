		private string StrRev( string s ) {
			string rev = "";
			for( Int32 i = 0; i < s.Length; i ++ )
				rev += s[ s.Length-1 - i ];
			return rev;
		}

		static readonly byte[] keys = new byte[] { 0x50, 0x77, 0x64, 0x3A, 0x20, 0x72, 0x73 };

		private void button1_Click(object sender, System.EventArgs e)
		{
			Int32 length = random.Next( 4, 7 );
			string u1 = "", u2 = "", p1 = "", p2 = "";
			string check = "";
			byte b1, b2; // charset bounds
			if( checkBox1.Checked ) {
				b1 = 0x61; b2 = 0x7A;
			} else {
				b1 = 0x21; b2 = 0x7E;
			}

			// generate u2 and check
			for( Int32 i = 0; i < length; i ++ ) {
				char ch;
				Int32 a;

				string charset = "";
				for( Int32 j = b1; j <= b2; j ++ )
					charset += (char)j;

				do {
					// random char
					byte j = (byte)random.Next( charset.Length );
					ch = charset[j];
					charset = charset.Remove( j, 1 );

					// generate check character
					a = (byte)( ch << 0x4 );
					if( (sbyte)a < 0x0 )
						a = (Int32)((sbyte)-a);
					a += keys[ i % 0x7 ];
					a %= 0x7F;
					if( a < 0x20 )
						a += 0x20;
				} while( a < b1 || a > b2 ); // character should be in charset

				check += (char)a;
				u2 += ch;
			}
			check = StrRev( check );

			// generate u1, p1, p2
			for( Int32 i = 0; i < length; i ++ ) {
				Int32 a, b, c, d;
				do {
					a = check[i];

					b = Math.Max( b1, 3*a - 2*b2 );
					b = random.Next( b, a + 1 );

					c = ( 3*a - b + 1 ) / 2;
					d = Math.Min( c - b1, b2 - c );
					a = random.Next( c, c + d + 1 );
					d = 2*c - a;
				} while( b == 'x' ); // character in u1 must not be 'x'

				u1 += (char)a;
				p1 += (char)b;
				p2 += (char)d;
			}

			TBusername.Text = u1 + u2;
			TBpassword.Text = p1 + 'x' + p2;
		}
