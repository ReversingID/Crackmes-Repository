// qnix
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    int i;
    char pwd[8] = {0};
    srand(time(NULL));

    pwd[0] = (char)((rand()%(122-65))+65);
    pwd[7] = pwd[1] = pwd[0]^0x39;
    pwd[2] = 0x27;
    pwd[3] = 0x57;
    pwd[4] = 0x4e;
    pwd[5] = 0x6d;
    pwd[6] = 'r';
    for(i=0;i<8;i++) printf("\\x%.2x", pwd[i]);
    return 0;
}
