This is my first cm :) Shouldn't be hard, but there is some obfuscation.
Just try to find a working key or make a keygen.
Please NO patching/injecting!
