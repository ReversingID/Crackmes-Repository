#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

int rol(int x)
{
  int i=(x << 2)& 0xFF;
  i |= ((x & 64 ) >>6);
  i |= ((x & 128) >>6);

  return i;
}

int main()
{
  string name;
  vector<int> array;

  ofstream output("file.nfo",ios::out | ios::binary);

  cout <<"Enter name : ";
  cin >> name;

  for(int i=0;i<name.length();i++){
    int p = rol(name[i]);
    p +=0x32;
    p ^=0x15;
    p ^=0x16;

    p  = rol(p);
    p += 0x32;
    p = p & 0xFF;
    p ^= 0x15;
    p ^= 0x16;
    output <<(char)p;
  }

  return 0;
}
