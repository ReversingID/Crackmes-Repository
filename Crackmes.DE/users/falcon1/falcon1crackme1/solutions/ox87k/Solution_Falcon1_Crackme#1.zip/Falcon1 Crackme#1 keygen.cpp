#include <iostream.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <conio.h>
#include <windows.h>

void main()
{
	char name[50];
   char serial[50];
	DWORD serial1=0;
	DWORD serial2=0;
	DWORD serial3=0;
	int len;

   cout<<"Falcon1 Crackme #1 - Keygen by Ox87k"<<"\n\n";
   //name:
   cout<<"Name: ";
   gets(name);
   //len name
   len=strlen(name);
	serial1=len;

   //serial2
	for (int i=0;i<len;i++)
	{
		serial2+=name[i]*0x539;
	}

   //serial3
	for (int i=0;i<len;i++)
	{
		serial3+=name[i];
	}

   sprintf(serial,"%d%c%d%c%d",serial1,0x2D,serial2,0x2D,serial3);
	cout<<"Serial: "<<serial;
	cout<<"\n\nPress any key for exit..";
	getch();
}
