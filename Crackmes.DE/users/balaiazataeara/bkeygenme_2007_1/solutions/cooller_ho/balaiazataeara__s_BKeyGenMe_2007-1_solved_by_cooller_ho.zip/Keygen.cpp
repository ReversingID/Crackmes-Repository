#include <iostream>
#include <string>
#include <cmath>

using namespace std;


void output_char(const string::const_iterator name_char, unsigned long& magic_num, unsigned long& remainder, unsigned int& output_counter) {


	long a = *name_char + remainder + (long)magic_num;
	magic_num = (unsigned long)a + magic_num + 1;
	
	double b = a;
	b /= 10;
	b = floor(b);
	b *= 10;
	remainder = a - (long)b;
	
	cout << remainder;
	output_counter++;

	if (output_counter % 4 == 0) {
		
		cout << "-";
		
	}


}

int main()
{

	string name;

	cout << "Keygen for balaiazataeara's BKeyGenMe 2007-1 \ncoded by cooller_ho @ NTUEE\n" << endl;
	cout << "Enter your name: ";

	cin >> name;
	if (name.size() < 5 || name.size() > 25) {
		
		cout << "Too long or too short.." << endl;
		system("PAUSE");
		return 1;
		
	}
	
	cout << "Your key: ";
	
	unsigned long magic_num = 1337;
	unsigned long remainder = 0;
	
	unsigned int output_counter = 0;
	string::const_iterator pos = name.begin();
	unsigned int pos_counter = 0;
	
	while (pos != name.end()) {		
		
		if (pos_counter % 5 == 0) {
		
			output_char(pos, magic_num, remainder, output_counter);
			output_char(pos, magic_num, remainder, output_counter);
			output_char(pos, magic_num, remainder, output_counter);
			output_char(pos, magic_num, remainder, output_counter);			
		
		} else {
		
			output_char(pos, magic_num, remainder, output_counter);
			output_char(pos, magic_num, remainder, output_counter);
			output_char(pos, magic_num, remainder, output_counter);

		}
		
		pos++;
		pos_counter++;

	}

	cout << endl;
	system("PAUSE");
	return 0;

}
