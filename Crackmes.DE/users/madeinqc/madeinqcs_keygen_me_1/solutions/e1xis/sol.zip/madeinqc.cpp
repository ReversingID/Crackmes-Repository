//============================================================================
// Name        : madeinqc.cpp
// Author      : e1xis
// Copyright   : CopyrighT!!
// Description : keygen for madeinqc's Keygen-me 1
//============================================================================

#include <cstdlib>
#include <iostream>
#include <sstream>
#include <string>

using namespace std;

const char compareTo[] = {0x09, 0x0D, 0xFF, 0x23, 0x15, 0xFF, 0x1D, 0xD7};

/**
 * The decoded algorithm of the serial-validator in the Crack-me. It ought to be the extended Euclidean
 * algorithm, but unfortunately it is not correctly implemented. See noted section below.
 */
bool checkCharacters(const char uc, const char pc, const int idx) {

	// init

	int val1 = 0;		// ebp_1c
	int val2 = 1;		// ebp_20
	int prevVal1 = 1;	// ebp_14
	int prevVal2 = 0;	// ebp_18
	int a = uc;			// ebp_4
	int b = pc;			// ebp_8

	// iteration

	while (b != 0) {
		int rem = a % b;	// ebp_24
		int div = a / b;	// ebp_28

		a = b;
		b = rem;

		int newVal1 = prevVal1 - val1 * div;	// ebp_2c
		// wrong: should have been prevVal2 [epb_18] instead of prevVal1
		int newVal2 = prevVal1 - val2 * div;	// ebp_30

		prevVal1 = val1;
		prevVal2 = val2;

		val1 = newVal1;
		val2 = newVal2;
	}

	return ( prevVal1 == compareTo[idx%8]);
}

/** A simpler version of the same algorithm to determine the quotients. */
const pair<int,int> extendedEuclideanRec(const pair<int,int> prev) {
	int a = prev.first;
	int b = prev.second;

	if ( 0 == b || a%b == 0) return pair<int,int>(0,1);

	pair<int,int> ret = extendedEuclideanRec(pair<int,int>(b,a%b));

	int x = ret.first;
	int y = ret.second;

	return pair<int,int>(y, x-y*((int)(a/b)));
}

int gcd(int a, int b) {
   return ( b != 0 ? gcd(b, a % b) : a );
}

const char generateSerialChar(const char uc, const char expc) {
	for (int c=0; c<255; ++c) {
		const int d = gcd(uc, c);
		const pair<int,int> p = extendedEuclideanRec(pair<int,int>(uc,c));
		if ( p.first == expc && uc*p.first+c*p.second == d) {
			// we accept these values in a serial only
			if (('a' <=c && c<='z') || ('A' <=c && c<='Z') || ('0' <=c && c<='9'))
				return c;
		}
	}

	throw 1;
}

const string generateSerial(string &username) {
	stringstream ss;

	for (unsigned int i=0; i<username.length(); ++i) {
		bool foundMatch = false;
		int shift = 0;

		do {
			try {
				ss << generateSerialChar(username[i] + shift, compareTo[i%8]);
				// we modify the username until we get a somewhat readable serial
				username[i] = username[i] + shift;
				foundMatch = true;
			} catch (const int i) {
				shift += i;
			}
		} while (!foundMatch);
	}

	return ss.str();
}

int main(void) {
	cout << "Keygen application for Madeinqc's Keygen-me 1 " << endl
		 << "http://www.crackmes.de/users/madeinqc/madeinqcs_keygen_me_1/" << endl << endl
		 << "Note: the implementation of the algorithm in the CM has a minor bug (see sol.txt for the "
			"details). There're usernames for which a valid serial (ok, a serial with a key of 'normal' "
			"characters) cannot be generated. In these cases, the username is modified in order to "
			"create a simple serial." << endl ;
	cout << "================================================================================" << endl
		 << "Type Q to quit."
		 << endl << endl;

	do {
		string user;

		do{
			cout << "Username? ";
			cin >> user;

			if (user == "Q") exit(0);
			if (user.length()<4)
				cerr << "Username contains at least 4 characters." << endl;
		} while (user.length()<4);

		string serial = generateSerial(user);

		cout << "[user:" << user << "]" << endl;
		cout << "[serial:" << serial << "]" << endl;
	} while (1);

    return 0;
}
