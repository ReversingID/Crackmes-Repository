This crack-me was made by Madeinqc

RULES
---------

You need to find the "Good Boy" message (the message that 
tell you that you win).

No patching is required so... no patching allowed.

That's all! Have fun and send me your tutorial or questions on

madeinqc_cracking@hotmail.com


Here's a tip below for the ones who really can't find it...





























































TIPS: It's in the Menu