CrackMe by Fereter #2.
CrackMe on Windows.
Difficulty: below medium.
The CrackMe has a protection from static analysis (crypted strings, complex logics of execution, some hidden API calls), anti-debug, a light protection against patching.
The goal is either to patch CrackMe so it accepted any data or to create a KeyGen.