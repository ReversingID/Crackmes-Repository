#ifndef __TRACEQ_H
#define __TRACEQ_H

void pretty_print_regs(struct user_regs_struct *regs);
bool process_debug_event(pid_t pid);

bool pt_pokedata(pid_t pid, uintptr_t address, uint32_t *dwords, size_t ndwords);
bool pt_peekdata(pid_t pid, uintptr_t address, uint32_t *dwords, size_t ndwords);
bool pt_getregs(pid_t pid, struct user_regs_struct *regs);
bool pt_setregs(pid_t pid, struct user_regs_struct *regs);
bool pt_continue(pid_t pid, int signal);
bool pt_attach(pid_t pid);

bool bosscall_save_trap_state(pid_t pid);
bool bosscall_restore_trap_state(pid_t pid);
bool bosscall_enable_emulation(pid_t pid);

// Eflags macros
#define EFLAGS_CF_MASK   0x00000001 // carry flag
#define EFLAGS_PF_MASK   0x00000004 // parity flag
#define EFLAGS_AF_MASK   0x00000010 // auxiliary carry flag
#define EFLAGS_ZF_MASK   0x00000040 // zero flag
#define EFLAGS_SF_MASK   0x00000080 // sign flag
#define EFLAGS_TF_MASK   0x00000100 // trap flag
#define EFLAGS_IF_MASK   0x00000200 // interrupt flag
#define EFLAGS_DF_MASK   0x00000400 // direction flag
#define EFLAGS_OF_MASK   0x00000800 // overflow flag
#define EFLAGS_IOPL_MASK 0x00003000 // I/O privilege level
#define EFLAGS_NT_MASK   0x00004000 // nested task
#define EFLAGS_RF_MASK   0x00010000 // resume flag
#define EFLAGS_VM_MASK   0x00020000 // virtual 8086 mode
#define EFLAGS_AC_MASK   0x00040000 // alignment check
#define EFLAGS_VIF_MASK  0x00080000 // virtual interrupt flag
#define EFLAGS_VIP_MASK  0x00100000 // virtual interrupt pending
#define EFLAGS_ID_MASK   0x00200000 // identification flag

// Bosscall macros
#define BOSSCALL_MAGIC              0xB055CA11
#define BOSSCALL_ENABLE_EMULATION   0x5E7
#define BOSSCALL_DISABLE_EMULATION  0x800005E7

#else
# warning traceq.h included twice
#endif
