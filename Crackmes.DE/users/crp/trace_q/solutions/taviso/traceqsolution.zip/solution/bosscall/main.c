#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <asm/user.h>
#include <stdbool.h>
#include <stdlib.h>
#include <sys/prctl.h>
#include <signal.h>
#include <sys/ptrace.h>
#include <linux/ptrace.h>
#include <sys/types.h>
#include <wait.h>
#include <assert.h>

#include "traceq.h"

// Path to trace-q binary
const char kTraceQBinary[] = "./trace-q";

int main(int argc, char **argv)
{
    pid_t pid;
    int status;
    
    fprintf(stderr, "info: starting trace-q in bosskey mode...\n");

    // Check if username and password was specified
    if (argc < 3) {
        fprintf(stderr, "error: please specify user/key, e.g. %s username regkey\n", argv[0]);
        return 1;
    }

    switch (pid = fork()) {
        case  0: // First use prctl() so I dont have to worry about cleaning up dead
                 // processes.
                 prctl(PR_SET_PDEATHSIG, SIGKILL);

                 // Request trace
                 ptrace(PTRACE_TRACEME);

                 // Start trace-q in boss-key mode so that it doesnt fork() a child
                 execl(kTraceQBinary, "trace-q", argv[1], argv[2], "--magic-boss-key", NULL);

                 // Oops!
                 abort();
        case -1: fprintf(stderr, "error: fork failed, %m\n");
                 return 1;
        default: fprintf(stderr, "info: trace-q pid %d, waiting for initial trap\n", pid);
                 break;
    }

    // Wait for the initial trap caused by the TRACEME.
    if (waitpid(pid, &status, 0) != pid) {
        fprintf(stderr, "error: unexpected waitpid result, %m\n");
        return 1;
    }
    
    // Make sure that looks sane
    assert(WIFSTOPPED(status) && WSTOPSIG(status) == SIGTRAP);

    // I also want to track system calls
    ptrace(PTRACE_SETOPTIONS, pid, 0, PTRACE_O_TRACESYSGOOD);

    // Save process state
    if (bosscall_save_trap_state(pid) == false) {
        fprintf(stderr, "error: failed to save process trap state\n");
        abort();
    }

    // Okay, continue process
    if (pt_continue(pid, 0) != true) {
        fprintf(stderr, "error: unable to continue process\n");
        return 1;
    }
    
    fprintf(stderr, "info: initial trap handled, now entering event loop\n");

    // Wait for and process debug events
    while (process_debug_event(pid))
        ;
    
    fprintf(stderr, "info: no more events!\n");

    return 0;
}
