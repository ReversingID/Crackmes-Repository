#include <stdint.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>
#include <assert.h>
#include <search.h>
#include <string.h>
#include <sys/types.h>
#include <asm/user.h>

#include "traceq.h"

// Description of the data stored @0xB2000
typedef struct __attribute__((packed)) {
    uintptr_t   address;    // Expected trap address
    union {
        struct __attribute__((packed)) {
            unsigned    operand     : 4;
            unsigned    opcode      : 4;
            unsigned    unused      : 24;
        } dec;
        uint32_t enc;
    } instruction;          // Instruction, encoded or decoded
    uint32_t    unknown;    // Dont know
    int32_t     target;     // Branch target
} trapevent_t;

// Opcodes supported
enum {
    VM_OPCODE_STACK     = 0x5,
    VM_OPCODE_JCC_SHORT = 0x7,
    VM_OPCODE_JCC_NEAR  = 0x8,
};

// Number of trap events that trace-q defines (@0xB00B1)
static const size_t kNumEvents = 0x2ed;

// Offset of trap data in the trace-q binary
static const size_t kTrapDataOffset = 0xd5fc + 0x3000;

// Name of the files
static const char kTraceQBinary[] = "./trace-q";
static const char kIdaBossOn[] = "./idabosson.idc";
static const char kIdaBossOff[] = "./idabossoff.idc";

// Rva offset (i.e. subtract this from an rva to get file offset).
// yes, i'm lazy
static uintptr_t kRvaOffset = 0x8048000;

// Emulated event data
static trapevent_t kEmulatedEvents[749];

bool bosscall_enable_script(void);
bool bosscall_disable_script(FILE *traceq);

int main(int argc, char **argv)
{
    FILE *traceq;

    // Open binary for reading
    if ((traceq = fopen(kTraceQBinary, "r")) == NULL) {
        fprintf(stderr, "error: failed to open %s, %m\n", kTraceQBinary);
        abort();
    }

    // Seek to the data
    if (fseek(traceq, kTrapDataOffset, SEEK_SET) != 0) {
        fprintf(stderr, "error: failed to seek to trap data, %m\n");
        abort();
    }

    // Read in the data
    if (fread(kEmulatedEvents, sizeof(trapevent_t), kNumEvents, traceq) != kNumEvents) {
        fprintf(stderr, "error: failed to read event data, %m\n");
        abort();
    }
    
    // Verify that matches the data I see in IDA
    assert(sizeof(trapevent_t) == 0x10);
    assert(kEmulatedEvents[0].address == 0x804A3C4);
    assert(kEmulatedEvents[0].instruction.dec.opcode == VM_OPCODE_STACK);
    assert(kEmulatedEvents[kNumEvents - 1].address == 0x8048776);
    assert(kEmulatedEvents[kNumEvents - 1].instruction.dec.opcode == VM_OPCODE_STACK);
    assert(kEmulatedEvents[kNumEvents - 3].address == 0x8049AED);
    assert(kEmulatedEvents[kNumEvents - 3].instruction.dec.opcode == VM_OPCODE_JCC_SHORT);
    
    fprintf(stderr, "info: read %u events from %s\n", kNumEvents, kTraceQBinary);

    bosscall_enable_script();
    bosscall_disable_script(traceq);

    // Finished
    fclose(traceq);
    return 0;
}

bool bosscall_disable_script(FILE *traceq)
{
    FILE *script;
    unsigned i;
    uint8_t origdata[6];

    if ((script = fopen(kIdaBossOff, "w")) == NULL) {
        fprintf(stderr, "error: failed to open %s, %m\n", kIdaBossOn);
        abort();
    }

    fprintf(script, "static main() {\n");

    // Okay, now generate patch data
    for (i = 0; i < kNumEvents; i++) {

        // Seek to the location of this trap
        if (fseek(traceq, kEmulatedEvents[i].address - kRvaOffset, SEEK_SET) != 0) {
            fprintf(stderr, "error: seek failed, %m\n");
            abort();
        }

        // Read in whatever is there
        if (fread(origdata, 1, sizeof(origdata), traceq) != sizeof(origdata)) {
            fprintf(stderr, "error: fread failed, %m\n");
            abort();
        }

        // Check if it's a fake
        if (origdata[0] != 0xcc) {
            fprintf(stderr, "info: skipping fake event %#x\n", kEmulatedEvents[i].address);
            continue;
        }


        // Find out what to patch
        switch (kEmulatedEvents[i].instruction.dec.opcode) {
            case VM_OPCODE_STACK:
                // Okay, nop the CC
                fprintf(script, "PatchByte(0x%08x, 0x90);\n", kEmulatedEvents[i].address);
                break;
            case VM_OPCODE_JCC_SHORT:
                // Okay, nop the CC
                fprintf(script, "PatchByte(0x%08x, 0x90);\n", kEmulatedEvents[i].address);

                // Restore second byte
                fprintf(script, "PatchByte(0x%08x, 0x%02hhx);\n",
                                kEmulatedEvents[i].address + 1,
                                origdata[1]);
                break;
            case VM_OPCODE_JCC_NEAR:
                // Okay, nop the CC
                fprintf(script, "PatchByte(0x%08x, 0x90);\n", kEmulatedEvents[i].address);

                // five bytes remaining
                fprintf(script, "PatchByte(0x%08x, 0x%02hhx);\n", kEmulatedEvents[i].address + 1, origdata[1]);
                fprintf(script, "PatchByte(0x%08x, 0x%02hhx);\n", kEmulatedEvents[i].address + 2, origdata[2]);
                fprintf(script, "PatchByte(0x%08x, 0x%02hhx);\n", kEmulatedEvents[i].address + 3, origdata[3]);
                fprintf(script, "PatchByte(0x%08x, 0x%02hhx);\n", kEmulatedEvents[i].address + 4, origdata[4]);
                fprintf(script, "PatchByte(0x%08x, 0x%02hhx);\n", kEmulatedEvents[i].address + 5, origdata[5]);
                break;
            default:
                fprintf(stderr, "error: unexpected opcode %#x at index %u, aborting.\n",
                                kEmulatedEvents[i].instruction.dec.opcode,
                                i);
                abort();
        }
    }

    fprintf(stderr, "info: processed %u operations\n", i);
    
    fprintf(script, "Message(\"Bosscall Emulation Disabled\\n\");\nRefresh();\nAnalyzeArea(0,-1);\n}\n");

    fclose(script);
    return true;
}

// Patch every address
bool bosscall_enable_script(void)
{
    FILE *script;
    unsigned i;

    if ((script = fopen(kIdaBossOn, "w")) == NULL) {
        fprintf(stderr, "error: failed to open %s, %m\n", kIdaBossOn);
        abort();
    }
    fprintf(script, "static main() {\n");

    // Okay, now generate patch data
    for (i = 0; i < kNumEvents; i++) {

        // Find out what to patch
        switch (kEmulatedEvents[i].instruction.dec.opcode) {
            case VM_OPCODE_STACK:
                // 1 byte instruction, just clobber the opcode
                fprintf(script, "PatchByte(0x%08x, 0x%02hhx);\n",
                                kEmulatedEvents[i].address,
                                kEmulatedEvents[i].instruction.enc);
                break;
            case VM_OPCODE_JCC_SHORT:
                // These have to be true
                assert(kEmulatedEvents[i].target <= INT8_MAX);
                assert(kEmulatedEvents[i].target >= INT8_MIN);

                // This would be an infinite loop
                assert(kEmulatedEvents[i].target != -2);
            
                // 2 byte instruction, clobber the opcode and target
                fprintf(script, "PatchByte(0x%08x, 0x%02hhx);\n",
                                kEmulatedEvents[i].address,
                                kEmulatedEvents[i].instruction.enc);
                fprintf(script, "PatchByte(0x%08x, 0x%02hhx);\n",
                                kEmulatedEvents[i].address + 1,
                                kEmulatedEvents[i].target);
                break;
            case VM_OPCODE_JCC_NEAR:
                // This would be an infinite loop
                assert(kEmulatedEvents[i].target != -6);

                // This would be silly, why not use a short jmp?
                assert(kEmulatedEvents[i].target > INT8_MAX || kEmulatedEvents[i].target < INT8_MIN);

                // 6 byte instruction, clobber opcode, prefix and target
                fprintf(script, "PatchByte(0x%08x, 0x0F);\n",
                                kEmulatedEvents[i].address);
                fprintf(script, "PatchByte(0x%08x, 0x%02hhx);\n",
                                kEmulatedEvents[i].address + 1,
                                kEmulatedEvents[i].instruction.enc);
                fprintf(script, "PatchDword(0x%08x, 0x%08x);\n",
                                kEmulatedEvents[i].address + 2,
                                kEmulatedEvents[i].target);
                break;
            default:
                fprintf(stderr, "error: unexpected opcode %#x at index %u, aborting.\n",
                                kEmulatedEvents[i].instruction.dec.opcode,
                                i);
                abort();
        }
    }

    fprintf(stderr, "info: processed %u operations\n", i);
    fprintf(script, "Message(\"Bosscall Emulation Enabled\\n\");\nRefresh();\nAnalyzeArea(0,-1);\n}\n");
    fclose(script);
    return true;
}
