#ifndef _GNU_SOURCE
# define _GNU_SOURCE
#endif
#include <stdio.h>
#include <assert.h>
#include <stdint.h>
#include <unistd.h>
#include <asm/user.h>
#include <stdbool.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <asm/unistd.h>

#include "traceq.h"

// This routine is based on the logic @B0332
bool process_debug_event(pid_t pid)
{
    int status;
    static bool emulated;
    struct user_regs_struct regs;

    // Wait for the child to stop
    if (waitpid(pid, &status, 0) != pid) {
        fprintf(stderr, "error: unexpected waitpid() result, %m\n");
        abort();
    }

    if (WIFSTOPPED(status)) {
        // Grab the registers
        if (pt_getregs(pid, &regs) == false) {
            fprintf(stderr, "error: unable to read registers\n");
            abort();
        }

        switch (WSTOPSIG(status)) {
            case SIGTRAP:
                // This is the expected path
                fprintf(stderr, "info: debug event occurred, status %#x\n", status);

                // Pretty rint registers for debugging
                pretty_print_regs(&regs);

                if (regs.eax == BOSSCALL_MAGIC) {
                    switch (regs.ebx) {
                        case BOSSCALL_ENABLE_EMULATION:
                            fprintf(stderr, "info: child requests emulation enabled\n");
                            
                            // This wouldnt make sense
                            assert(emulated == false);

                            // Patch everything
                            if (bosscall_enable_emulation(pid) == false) {
                                fprintf(stderr, "error: failed to enable fake emulation\n");
                                abort();
                            }

                            // Return Code
                            regs.eax = 0x1020304;
                            regs.ebx = 0x10203040;
                            
                            // Save state
                            emulated = true;
                            break;
                        case BOSSCALL_DISABLE_EMULATION:
                            fprintf(stderr, "info: child requests emulation disabled\n");
                            
                            // This wouldnt make sense
                            assert(emulated == true);

                            // Put process back the way it was
                            if (bosscall_restore_trap_state(pid) == false) {
                                fprintf(stderr, "error: failed to restore original state\n");
                                abort();
                            }

                            // Return Code
                            regs.eax = 0x10203040u;
                            regs.ebx = 0x1020304;

                            // Save state
                            emulated = false;
                            break;
                        default:
                            fprintf(stderr, "error: unimplemented bosscall encountered\n");
                            abort();
                    }
                } else {
                    fprintf(stderr, "error: unexpected debug trap occurred\n");
                }

                pt_setregs(pid, &regs);
                pt_continue(pid, 0);
                return true;
            case SIGTRAP | 0x80:
                // Child makes a systemcall, check if it's expected
                switch (regs.orig_eax) {
                    case __NR_nanosleep:
                        // Child calls nanosleep() while printing messages at 0x0804832C, this 
                        // is probably intended as a way to pause the child before it hits the
                        // initial bosscall (i.e. stty stop).

                        // I don't need this any more, and would prefer it ran faster, so change
                        // it to a getpid() :-)
                        regs.orig_eax = __NR_getpid;

                        // Install
                        pt_setregs(pid, &regs);
                        break;
                    case __NR_mmap:
                    case __NR_write:
                    case __NR_exit:
                    case __NR_getpid:
                        break;
                    default:
                        fprintf(stderr, "error: child makes unexpected syscall %lu!\n", regs.orig_eax);
                        pretty_print_regs(&regs);
                        abort();
                }
                pt_continue(pid, 0);
                return true;
            default:
                fprintf(stderr, "error: child stopped with unexpected %s!\n",
                                strsignal(WSTOPSIG(status)));
                pretty_print_regs(&regs);
                abort();
        }
    } else if (WIFEXITED(status)) {
        fprintf(stderr, "info: child exited with status %d!\n", WEXITSTATUS(status));
        return false;
    } else if (WIFSIGNALED(status)) {
        fprintf(stderr, "error: child was killed with %s! unexpected!\n", strsignal(WTERMSIG(status)));
        pretty_print_regs(&regs);
        abort();
    } else {
        fprintf(stderr, "error: unsure why waitpid returned.\n");
        pretty_print_regs(&regs);
        abort();
    }

    return false;
}

// Quick utility routine to pretty print user_regs_struct, with similar output
// to softice (except I dont care about segment registers or most of the
// eflags).
void pretty_print_regs(struct user_regs_struct *regs)
{
    fprintf(stderr,
        " - Registers --------------------------------------------------\n"
        " eax:%#010lx, ebx:%#010lx, ecx:%#010lx, edx:%#010lx            \n"
        " esi:%#010lx, edi:%#010lx, ebp:%#010lx, esp:%#010lx            \n"
        " eip:%#010lx, eflags:%#010lx [ %s%s%s%s%s%s%s%s%s ]            \n"
        " --------------------------------------------------------------\n",
        regs->eax, regs->ebx, regs->ecx, regs->edx, regs->esi,
        regs->edi, regs->ebp, regs->esp, regs->eip, regs->eflags,
        regs->eflags & EFLAGS_CF_MASK ? "C" : "c",
        regs->eflags & EFLAGS_PF_MASK ? "P" : "p",
        regs->eflags & EFLAGS_AF_MASK ? "A" : "a",
        regs->eflags & EFLAGS_ZF_MASK ? "Z" : "z",
        regs->eflags & EFLAGS_SF_MASK ? "S" : "s",
        regs->eflags & EFLAGS_TF_MASK ? "T" : "t",
        regs->eflags & EFLAGS_IF_MASK ? "I" : "i",
        regs->eflags & EFLAGS_DF_MASK ? "D" : "d",
        regs->eflags & EFLAGS_OF_MASK ? "O" : "o");
    return;
}
