#include <stdint.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>
#include <assert.h>
#include <search.h>
#include <string.h>
#include <sys/types.h>
#include <asm/user.h>

#include "traceq.h"

// Description of the data stored @0xB2000
typedef struct __attribute__((packed)) {
    uintptr_t   address;    // Expected trap address
    union {
        struct __attribute__((packed)) {
            unsigned    operand     : 4;
            unsigned    opcode      : 4;
            unsigned    unused      : 24;
        } dec;
        uint32_t enc;
    } instruction;          // Instruction, encoded or decoded
    uint32_t    unknown;    // Dont know
    int32_t     target;     // Branch target
} trapevent_t;

// Opcodes supported
enum {
    VM_OPCODE_STACK     = 0x5,
    VM_OPCODE_JCC_SHORT = 0x7,
    VM_OPCODE_JCC_NEAR  = 0x8,
};

// Number of trap events that trace-q defines (@0xB00B1)
static const size_t kNumEvents = 0x2ed;

// Offset of trap data in the trace-q binary
static const size_t kTrapDataOffset = 0xd5fc + 0x3000;

// Name of the trace-q binary
static const char kTraceQBinary[] = "./trace-q";

// Emulated event data
static trapevent_t kEmulatedEvents[749];

// Saved trap state
static struct savedtrap {
    uintptr_t   address;
    union {
        uint8_t     bytes[8];
        uint16_t    words[4];
        uint32_t    dwords[2];
    } data;
} kSavedTrapData[749];

static void pretty_print_event(size_t index);

// Constructor to read in event data
void __attribute__((constructor)) init()
{
    FILE *traceq;

    memset(kSavedTrapData, 0x00, sizeof(kSavedTrapData));
    memset(kEmulatedEvents, 0x00, sizeof(kEmulatedEvents));

    // Open binary for reading
    if ((traceq = fopen(kTraceQBinary, "r")) == NULL) {
        fprintf(stderr, "error: failed to open %s, %m\n", kTraceQBinary);
        abort();
    }

    // Seek to the data
    if (fseek(traceq, kTrapDataOffset, SEEK_SET) != 0) {
        fprintf(stderr, "error: failed to seek to trap data, %m\n");
        abort();
    }

    // Read in the data
    if (fread(kEmulatedEvents, sizeof(trapevent_t), kNumEvents, traceq) != kNumEvents) {
        fprintf(stderr, "error: failed to read event data, %m\n");
        abort();
    }
    
    // Verify that matches the data I see in IDA
    assert(sizeof(trapevent_t) == 0x10);
    assert(kEmulatedEvents[0].address == 0x804A3C4);
    assert(kEmulatedEvents[0].instruction.dec.opcode == VM_OPCODE_STACK);
    assert(kEmulatedEvents[kNumEvents - 1].address == 0x8048776);
    assert(kEmulatedEvents[kNumEvents - 1].instruction.dec.opcode == VM_OPCODE_STACK);
    assert(kEmulatedEvents[kNumEvents - 3].address == 0x8049AED);
    assert(kEmulatedEvents[kNumEvents - 3].instruction.dec.opcode == VM_OPCODE_JCC_SHORT);
    
    fprintf(stderr, "info: read %u events from %s\n", kNumEvents, kTraceQBinary);

    // Finished
    fclose(traceq);
    return;
}

// Backup 8 bytes (the next dword boundary after the longest emulated
// instruction) of data from every trap address. I round it up because
// ptrace is designed to deal with dwords, and shifting out bytes is a
// nuisance.
bool bosscall_save_trap_state(pid_t pid)
{
    unsigned i;
    static bool saved;

    // Check if I've already saved state
    if (saved == true) {
        return saved;
    }

    // Okay, backup every address
    for (i = 0; i < kNumEvents; i++) {
    
        // I should only be called once, verify that.
        assert(kSavedTrapData[i].data.dwords[0] == 0);
        assert(kSavedTrapData[i].data.dwords[1] == 0);
        assert(kSavedTrapData[i].address == 0);

        kSavedTrapData[i].address = kEmulatedEvents[i].address;

        // Read the data
        if (pt_peekdata(pid, kEmulatedEvents[i].address, kSavedTrapData[i].data.dwords, 2) == false) {
            fprintf(stderr, "error: unable to peak at data @%#x\n", kEmulatedEvents[i].address);
            abort();
            return false;
        }

        // Patch over traps with nops in non-emulated mode
        if (kSavedTrapData[i].data.bytes[0] != 0xcc) {
            fprintf(stderr, "warn: expected instruction @%#010x to be int3, but it's %#04hhx!\n",
                            kEmulatedEvents[i].address,
                            kSavedTrapData[i].data.bytes[0]);
            pretty_print_event(i);
            fprintf(stderr, "info: not patching event %u, crp is sneaky ;-)\n", i);
        } else {
            kSavedTrapData[i].data.bytes[0] = 0x90;
        }
    }

    // Done
    fprintf(stderr, "info: saved state from %u addresses in %d\n", kNumEvents, pid);

    // Record success
    saved = true;

    return true;
}

// Emulation has been disabled, so retore previous state, be careful to restore
// the right size, in case they overlap.
bool bosscall_restore_trap_state(pid_t pid)
{
    struct savedtrap patch = {0};
    unsigned i;

    // Okay, now generate patch data
    for (i = 0; i < kNumEvents; i++) {

        // These should be synchronized
        assert(kSavedTrapData[i].address == kEmulatedEvents[i].address);

        // Read the current data
        if (pt_peekdata(pid, kEmulatedEvents[i].address, patch.data.dwords, 2) == false) {
            fprintf(stderr, "error: unable to peek at data @%#x\n", kEmulatedEvents[i].address);
            abort();
            return false;
        }

        // Find out what to patch
        switch (kEmulatedEvents[i].instruction.dec.opcode) {
            case VM_OPCODE_STACK:
                // 1 byte instruction, just clobber the opcode
                patch.data.bytes[0] = kSavedTrapData[i].data.bytes[0];
                break;
            case VM_OPCODE_JCC_SHORT:
                // 2 byte instruction, clobber the opcode and target
                patch.data.bytes[0] = kSavedTrapData[i].data.bytes[0];
                patch.data.bytes[1] = kSavedTrapData[i].data.bytes[1];
                break;
            case VM_OPCODE_JCC_NEAR:
                // 6 byte instruction, clobber opcode, prefix and target
                patch.data.bytes[0] = kSavedTrapData[i].data.bytes[0];
                patch.data.bytes[1] = kSavedTrapData[i].data.bytes[1];
                patch.data.words[1] = kSavedTrapData[i].data.words[1];
                patch.data.words[2] = kSavedTrapData[i].data.words[2];
                break;
            default:
                fprintf(stderr, "error: unexpected opcode %#x at index %u, aborting.\n",
                                kEmulatedEvents[i].instruction.dec.opcode,
                                i);
                abort();
        }
        
        // Poke it into process
        if (pt_pokedata(pid, kEmulatedEvents[i].address, patch.data.dwords, 2) == false) {
            fprintf(stderr, "error: unable to poke data @%#x\n", kEmulatedEvents[i].address);
            abort();
            return false;
        }
    }

    fprintf(stderr, "info: processed %u known trap events\n", i);
    return true;
}

// Dump an event in IDA syntax for easy error checking
static void pretty_print_event(size_t index)
{
    fprintf(stderr, "\ttrapevent_t <offset loc_%08X, %#x, %#x, %#hx>; %u\n",
                    kEmulatedEvents[index].address,
                    kEmulatedEvents[index].instruction.enc,
                    kEmulatedEvents[index].unknown,
                    kEmulatedEvents[index].target,
                    index);

}

// Patch every address
bool bosscall_enable_emulation(pid_t pid)
{
    struct savedtrap patch = {0};
    unsigned i;

    // Okay, now generate patch data
    for (i = 0; i < kNumEvents; i++) {

        // Read the current data
        if (pt_peekdata(pid, kEmulatedEvents[i].address, patch.data.dwords, 2) == false) {
            fprintf(stderr, "error: unable to peek at data @%#x\n", kEmulatedEvents[i].address);
            abort();
            return false;
        }

        // Find out what to patch
        switch (kEmulatedEvents[i].instruction.dec.opcode) {
            case VM_OPCODE_STACK:
                // 1 byte instruction, just clobber the opcode
                patch.data.bytes[0] = kEmulatedEvents[i].instruction.enc;
                break;
            case VM_OPCODE_JCC_SHORT:
                // These have to be true
                assert(kEmulatedEvents[i].target <= INT8_MAX);
                assert(kEmulatedEvents[i].target >= INT8_MIN);

                // This would be an infinite loop
                assert(kEmulatedEvents[i].target != -2);
            
                // 2 byte instruction, clobber the opcode and target
                patch.data.bytes[0] = kEmulatedEvents[i].instruction.enc;
                patch.data.bytes[1] = kEmulatedEvents[i].target;
                break;
            case VM_OPCODE_JCC_NEAR:
                // This would be an infinite loop
                assert(kEmulatedEvents[i].target != -6);

                // This would be silly, why not use a short jmp?
                assert(kEmulatedEvents[i].target > INT8_MAX || kEmulatedEvents[i].target < INT8_MIN);

                // 6 byte instruction, clobber opcode, prefix and target
                patch.data.bytes[0] = 0x0F;
                patch.data.bytes[1] = kEmulatedEvents[i].instruction.enc;
                patch.data.words[1] = kEmulatedEvents[i].target & 0xffff;
                patch.data.words[2] = kEmulatedEvents[i].target >> 16;
                break;
            default:
                fprintf(stderr, "error: unexpected opcode %#x at index %u, aborting.\n",
                                kEmulatedEvents[i].instruction.dec.opcode,
                                i);
                abort();
        }
        
        // Poke it into process
        if (pt_pokedata(pid, kEmulatedEvents[i].address, patch.data.dwords, 2) == false) {
            fprintf(stderr, "error: unable to poke data @%#x\n", kEmulatedEvents[i].address);
            abort();
            return false;
        }
    }

    fprintf(stderr, "info: processed %u known trap events\n", i);
    return true;
}
