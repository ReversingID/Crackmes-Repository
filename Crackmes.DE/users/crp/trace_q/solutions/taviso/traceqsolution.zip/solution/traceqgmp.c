#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <gmp.h>

// Solution to trace-q by crp-
//
// Output is Mathematica script to find a solution for the string specified on the commandline.
//
//  -- taviso@sdf.lonestar.org

#define STATE_SIZE 10

int main(int argc, char **argv)
{
    mpz_t primes[STATE_SIZE];
    mpz_t compos[STATE_SIZE];
    mpz_t result;
    size_t userlen;
    char *username;
    unsigned tmp, i, j, k, l, m, n, o;

    // Hardcoded Primes
    mpz_init_set_str(primes[0], "e89d7d769dd057021fe63342d", 16);
    mpz_init_set_str(primes[1], "9f55dbc108f84396f8e5277b3", 16);
    mpz_init_set_str(primes[2], "c77fb1b587e00fefc31580ae7", 16);
    mpz_init_set_str(primes[3], "9a0b6c9de7d0ab8d57e0b4213", 16);
    mpz_init_set_str(primes[4], "843a5f65adaee40141e759f43", 16);
    mpz_init_set_str(primes[5], "92796572ab3cf50ef5e1de059", 16);
    mpz_init_set_str(primes[6], "9a22bc2330181978410cf0e23", 16);
    mpz_init_set_str(primes[7], "8774cc7b902d6431ff505c045", 16);
    mpz_init_set_str(primes[8], "affbdbc2ca596675f190a14c1", 16);
    mpz_init_set_str(primes[9], "c803a2a22ac0d60c811f28bc1", 16);

    // Initialise Composites
    for (i = 0; i < STATE_SIZE; i++) {
        mpz_init(compos[i]);
    }

    // Fetch username
    username = argv[1];
    
    // Find out how to distribute the characters
    if ((userlen = strlen(username) - 1) < STATE_SIZE) {
        userlen = STATE_SIZE;
    }
    
    // This logic is from around @80486CE
    for (i = 0; i < userlen; i++) {
        mpz_add_ui(compos[i % STATE_SIZE], compos[i % STATE_SIZE], username[i % strlen(username)]);
    }

    tmp = - strlen(username);       // eax
    k = strlen(username) - 0x1F;
    l = tmp - 0x17;
    m = tmp + 0x0D;
    n = tmp + 0x07;

    mpz_init(result);

    for (j = 0; j < username[0]; j++, n++, m++, l++, k++) {
        if (j & 0x01) mpz_add(compos[j % STATE_SIZE], compos[j % STATE_SIZE], compos[(j + 3) % STATE_SIZE]);
        if (j & 0x02) mpz_add(compos[j % STATE_SIZE], compos[j % STATE_SIZE], compos[(j - 1) % STATE_SIZE]);
        if (j & 0x04) mpz_add(compos[j % STATE_SIZE], compos[j % STATE_SIZE], compos[(j - 5) % STATE_SIZE]);
        if (j & 0x08) mpz_add(compos[j % STATE_SIZE], compos[j % STATE_SIZE], compos[(j - 7) % STATE_SIZE]);
        if (j & 0x10) mpz_add(compos[j % STATE_SIZE], compos[j % STATE_SIZE], compos[n % STATE_SIZE]);
        if (j & 0x20) mpz_add(compos[j % STATE_SIZE], compos[j % STATE_SIZE], compos[m % STATE_SIZE]);
        if (j & 0x40) mpz_add(compos[j % STATE_SIZE], compos[j % STATE_SIZE], compos[l % STATE_SIZE]);

        o = j % STATE_SIZE;

        mpz_add(compos[o], compos[o], compos[k % STATE_SIZE]);
        mpz_mul(result, compos[o], compos[(j + 42) % STATE_SIZE]);
        mpz_mod(compos[o], result, primes[o]);
    }

    fprintf(stdout, "TraceQPrimes := { ");
    
    for (i = 0; i < STATE_SIZE; i++) {
        gmp_printf("16^^%Zx%s", primes[i], (i == STATE_SIZE - 1) ? "" : ", ");
    }

    fprintf(stdout, "}\nTraceQCompos := { ");

    for (i = 0; i < STATE_SIZE; i++) {
        gmp_printf("16^^%Zx%s", compos[i], (i == STATE_SIZE - 1) ? "" : ", ");
    }

    fprintf(stdout, "}\nBaseForm[ChineseRemainder[TraceQCompos, TraceQPrimes], 16]\n");

    return 0;
}
