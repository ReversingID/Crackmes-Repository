#include <sys/ptrace.h>
#include <stdbool.h>
#include <stdint.h>
#include <unistd.h>
#include <stdio.h>
#include <asm/user.h>
#include <errno.h>

#include "traceq.h"

bool pt_pokedata(pid_t pid, uintptr_t address, uint32_t *dwords, size_t ndwords)
{
    size_t i;
    for (i = 0; i < ndwords; i++) {
        if (ptrace(PTRACE_POKEDATA, pid, address + i * sizeof(uint32_t), dwords[i]) == -1) {
            fprintf(stderr, "pt_pokedata(%d, %#010x) failed, %m\n", pid, address);
            return false;
        }
    }
    return true;
}

bool pt_peekdata(pid_t pid, uintptr_t address, uint32_t *dwords, size_t ndwords)
{
    size_t i;
    for (errno = 0, i = 0; i < ndwords; i++) {
        dwords[i] = ptrace(PTRACE_PEEKDATA, pid, address + i * sizeof(uint32_t), NULL);

        // Check that worked
        if (errno) {
            fprintf(stderr, "pt_peekdata(%d, %#010x) failed, %m\n", pid, address);
            return false;
        }
    }
    return true;
}

bool pt_getregs(pid_t pid, struct user_regs_struct *regs)
{
    if (ptrace(PTRACE_GETREGS, pid, NULL, regs) == -1) {
        fprintf(stderr, "pt_getregs(%d) failed, %m\n", pid);
        return false;
    }
    return true;
}

bool pt_setregs(pid_t pid, struct user_regs_struct *regs)
{
    if (ptrace(PTRACE_SETREGS, pid, NULL, regs) == -1) {
        fprintf(stderr, "pt_setregs(%d) failed, %m\n", pid);
        return false;
    }
    return true;
}

bool pt_continue(pid_t pid, int signal)
{
    if (ptrace(PTRACE_SYSCALL, pid, NULL, signal) == -1) {
        fprintf(stderr, "pt_continue(%d, %d) failed, %m\n", pid, signal);
        return false;
    }
    return true;
}

bool pt_attach(pid_t pid)
{
    if (ptrace(PTRACE_ATTACH, pid, NULL, NULL) == -1) {
        fprintf(stderr, "pt_attach(%d) failed, %m\n", pid);
        return false;
    }
    return true;
}
