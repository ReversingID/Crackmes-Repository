#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <pwd.h>
#include <stdio.h>

/* keygen for `collide` crackme by crp- */

/* Tavis Ormandy <taviso@sdf.lonestar.org> (February 2006) */

#define KEYFILE ".key"

/* these are two vectors with the same md5
 */

unsigned m0[32] = {
    0x08615431, 0x87ef05bc, 0xcc244b83, 0x8cc95aad, 
    0xfd1c9d54, 0x9c7e624a, 0xc8552172, 0x45811838, 
    0x0632ed45, 0x03b34801, 0x8c56e74b, 0x62b1738a, 
    0xb1f2f6ee, 0xbbfe8cc2, 0xeffb8b67, 0xa4c9c210, 
    0xef697587, 0x430e0f8f, 0xe58d7a20, 0xfce18a4f, 
    0xc6848e33, 0x0bf398bd, 0x75d70512, 0xb17dd552, 
    0x9b77d76d, 0x4a2f33a1, 0xa27e2d86, 0xd684dc69, 
    0x29ea2cb5, 0x705bf34d, 0x4608b6fd, 0x899c9e27, 
};

unsigned int m1[32] = {
    0x08615431, 0x87ef05bc, 0xcc244b83, 0x8cc95aad, 
    0x7d1c9d54, 0x9c7e624a, 0xc8552172, 0x45811838, 
    0x0632ed45, 0x03b34801, 0x8c56e74b, 0x62b1f38a, 
    0xb1f2f6ee, 0xbbfe8cc2, 0x6ffb8b67, 0xa4c9c210, 
    0xef697587, 0x430e0f8f, 0xe58d7a20, 0xfce18a4f, 
    0x46848e33, 0x0bf398bd, 0x75d70512, 0xb17dd552, 
    0x9b77d76d, 0x4a2f33a1, 0xa27e2d86, 0xd6845c69, 
    0x29ea2cb5, 0x705bf34d, 0xc608b6fd, 0x899c9e27, 
};

/* how far must we seek before starting data (ie, first word of vector) */
#define PADDING (0x5431 - (sizeof(m0)))

#define JUNK 3  /* how many bytes to add to make filesize multiple of 16 */

/* actual key data structure */
typedef struct __attribute__ ((__packed__)) {
    unsigned prefix[32];        /* collision vector */
    unsigned char pad[PADDING]; /* padding so offsets line up correctly */
    unsigned uid_mplier;        /* data is at (mplier * mcand + add) ^ xor */
    unsigned uid_mcand;       
    unsigned uid_add;           /* ie, multiplier, multiplicand, add, xor */
    unsigned uid_xor;
    unsigned gid_mplier;
    unsigned gid_mcand;
    unsigned gid_add;
    unsigned gid_xor;
    unsigned hash_mplier;
    unsigned hash_mcand;
    unsigned hash_add;
    signed hash_xor;
    unsigned uid;             /* users uid */
    unsigned gid;             /* users gid */
    unsigned hash;            /* users passwd hash */
    unsigned char junk[JUNK]; /* junk to make up file size */
} keybuf_t;

/* this structure stores passwd hash data, used to encrypt signature */
typedef struct {
    unsigned uid;
    unsigned gid;
    signed hash;
} pwdhash_t;

int gen_passwd_hash(pwdhash_t *pwhash, uid_t uid);
void stage1_encrypt(unsigned *data, pwdhash_t *pwdhash);
FILE *fdopen(int fildes, const char *mode);

#define PWDCOMP(x, y, z) ((x * y) ^ z) /* PWDCOMP, ie passwd hash complement */

int main(int argc, char **argv)
{
    keybuf_t keydata, signature;
    pwdhash_t pwdhash;
    int keyfd, i;
    FILE *key;

    fprintf(stdout, "[*] creating keyfile...\n");

    /* delete any existing keyfile if possible */
    (void) unlink(KEYFILE);

    /* attempt to create keyfile with correct permissions */
    if ((keyfd = open(KEYFILE, O_WRONLY | O_CREAT | O_EXCL, S_IRUSR)) == -1) {
        fprintf(stderr, "[!] error, unable to create keyfile.\n");
        return 1;
    }

    /* change that into a file pointer */
    if ((key = fdopen(keyfd, "w")) == NULL) {
        fprintf(stderr, "[!] error, unable to obtain file pointer.\n");
        return 1;
    }

    /* generate unique value from passwd data */
    if (gen_passwd_hash(&pwdhash, getuid()) == 1) {
        fprintf(stderr, "[!] error, failed to generate passwd hash.\n");
        return 1;
    }

    fprintf(stderr, "[*] hash for uid %u, with gid %u would be %#010x.\n",
            pwdhash.uid, pwdhash.gid, pwdhash.hash);
    fprintf(stderr, "[*] secondary hash would be %#010x.\n",
            PWDCOMP(pwdhash.uid, pwdhash.gid, pwdhash.hash));
    
    /* initialize that buffer to zero */
    memset(&keydata, 0x00, sizeof(keydata));

    fprintf(stdout, "[*] generating key buffer...\n");

    /* insert offsets */
    keydata.uid_xor  = (unsigned) &keydata.uid  - (unsigned) &keydata;
    keydata.gid_xor  = (unsigned) &keydata.gid  - (unsigned) &keydata;
    keydata.hash_xor = (unsigned) &keydata.hash - (unsigned) &keydata;

    /* now fill in the data */
    keydata.uid  = pwdhash.uid;
    keydata.gid  = pwdhash.gid;
    keydata.hash = pwdhash.hash;

    fprintf(stdout, "[*] generating signature buffer...\n");

    /* copy key data into signature buffer */
    memcpy(&signature, &keydata, sizeof(keydata));

    /* now insert colission vectors */
    fprintf(stdout, "[*] creating colissions...\n");
    memcpy(&keydata.prefix, m0, sizeof(m0));
    memcpy(&signature.prefix, m1, sizeof(m1));

    fprintf(stdout, "[*] writing your keydata...\n");

    /* that's it, that's the first buffer, let's write it out */
    if (fwrite(&keydata, 1, sizeof(keydata), key) != sizeof(keydata)) {
        fprintf(stderr, "[!] error, a write operation failed.\n");
        return 1;
    }

    fprintf(stdout, "[*] encrypting signature to your passwd hash...\n");

    /* now we can encrypt this buffer, and write it back */
    for (i = 0; i < sizeof(signature); i += sizeof(unsigned) * 2)
        stage1_encrypt((unsigned *)((char *) &signature + i), &pwdhash);

    fprintf(stdout, "[*] appending encrypted signature to keyfile...\n");

    /* okay, and now write this out */
    if (fwrite(&signature, 1, sizeof(signature), key) != sizeof(signature)) {
        fprintf(stderr, "[!] error, a write operation failed.\n");
        return 1;
    }

    /* cleanup */
    fclose(key);

    fprintf(stdout, "[*] all done.\n");

    return 0;
}

/* this function calculates a unique hash from the data returned by
 * getpwuid(). this is used numerous times within collide */
int gen_passwd_hash(pwdhash_t *pwhash, uid_t uid)
{
    struct passwd *pw;

     if ((pw = getpwuid(uid)) == NULL)
         return 1;

     for (pwhash->hash = 0x63; *pw->pw_name; pw->pw_name++) {
         pwhash->hash = ((pwhash->hash * *pw->pw_name) >> 3) ^ *pw->pw_name;
         while (pwhash->hash & 3) {
             pwhash->hash <<= 1;
         }
     }

     pwhash->uid = pw->pw_uid;
     pwhash->gid = pw->pw_gid;
     pwhash->hash += ((pw->pw_uid & 1) * 2) + (pw->pw_gid & 1);

     return 0;
}

/* this function encrypts two dwords of data at *data according to the
 * data in pwdhash. */
void stage1_encrypt(unsigned *data, pwdhash_t *pwdhash)
{
    /* this key is used in stage 1 for the deccryption of second half of
     * the key data */
    unsigned key1 = 0x9e3779b9, key2, i;

    for (i = 0, key2 = key1; i < 32; i++) {
        *(data) += ((((*(data+1) << 4) + pwdhash->uid)
                ^ (key2 + *(data+1)))) ^ (((*(data+1) >> 5) + pwdhash->gid));
        *(data+1) += (((*(data) << 4) + pwdhash->hash) 
                ^ (key2 + *(data))) ^ (((*(data) >> 5) + 
                    PWDCOMP(pwdhash->uid, pwdhash->gid, pwdhash->hash)));
        key2 += key1;
    }

    return;
}
