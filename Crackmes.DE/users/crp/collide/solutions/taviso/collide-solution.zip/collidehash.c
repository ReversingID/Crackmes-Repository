#include <stdio.h>
#include <string.h>
#include <limits.h>

/* the hardcoded key from collide */
unsigned key[] = { 0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476, 
                   0x00000000, 0x00000000, 0x00000000, 0x00000000,
                   0x00000000, 0x00000000, 0x00000000, 0x00000000,
                   0x00000000, 0x00000000, 0x00000000, 0x00000000,
                   0x00000000, 0x00000000, 0x00000000, 0x00000000,
                   0x00000000, 0x00000000, 0x00000000, 0x00000000,
                   0x00000000, 0x00000000 };

void longcrypt(unsigned key[], const unsigned dat[], unsigned n);
static void *setkey(unsigned int *buf);
static unsigned rol(unsigned i, unsigned char n);

#define HASH1(k, a, b, c, d, e, i, s, n) \
    (rol((((k[a] & k[b]) | (~k[c] & k[d])) + i + k[e]) - s, n) + k[b])
#define HASH2(k, a, b, c, d, e, i, s, n) \
    (rol(((k[a] ^ k[b] ^ k[c]) + i + k[d]) - s, n) + k[e])
#define HASH3(k, a, b, c, d, e, i, s, n) \
    (rol(((((~k[a] | k[b]) ^ k[c]) + i + k[d]) - s), n) + k[e])

 /*
  * the function this code is based on is at 0x8048fCb in collide.
  */
void longcrypt(unsigned key[], const unsigned dat[], unsigned n)
{
    unsigned buf[KEYSIZE];

    memcpy(buf, key, sizeof(buf));

    key[0] = HASH1(key, 2, 1, 1, 3, 0, dat[0], 0x28955b88, 0x07); 
    key[3] = HASH1(key, 1, 0, 0, 2, 3, dat[1], 0x173848aa, 0x0c);
    key[2] = HASH1(key, 0, 3, 3, 1, 2, dat[2], - 0x242070db, 0x11);
    key[1] = HASH1(key, 3, 2, 2, 0, 1, dat[3], 0x3e423112, 0x16);
    key[0] = HASH1(key, 2, 1, 1, 3, 0, dat[4], 0x0a83f051, 0x07);
    key[3] = HASH1(key, 1, 0, 0, 2, 3, dat[5], - 0x4787c62a, 0x0c);
    key[2] = HASH1(key, 0, 3, 3, 1, 2, dat[6], 0x57cfb9ed, 0x11);
    key[1] = HASH1(key, 3, 2, 2, 0, 1, dat[7], 0x02b96aff, 0x16);
    key[0] = HASH1(key, 2, 1, 1, 3, 0, dat[8], - 0x698098d8, 0x07);
    key[3] = HASH1(key, 1, 0, 0, 2, 3, dat[9], 0x74bb0851, 0x0c);
    key[2] = HASH1(key, 0, 3, 3, 1, 2, dat[10], 0x0000a44f, 0x11);
    key[1] = HASH1(key, 3, 2, 2, 0, 1, dat[11], 0x76a32842, 0x16);
    key[0] = HASH1(key, 2, 1, 1, 3, 0, dat[12], - 0x6b901122, 0x07);
    key[3] = HASH1(key, 1, 0, 0, 2, 3, dat[13], 0x02678e6d, 0x0c);
    key[2] = HASH1(key, 0, 3, 3, 1, 2, dat[14], 0x5986bc72, 0x11);
    key[1] = HASH1(key, 3, 2, 2, 0, 1, dat[15], - 0x49b40821, 0x16);
    key[0] = HASH1(key, 3, 1, 3, 2, 0, dat[1], 0x09e1da9e, 0x05);
    key[3] = HASH1(key, 2, 0, 2, 1, 3, dat[6], 0x3fbf4cc0, 0x09);
    key[2] = HASH1(key, 1, 3, 1, 0, 2, dat[11], - 0x265e5a51, 0x0e);
    key[1] = HASH1(key, 0, 2, 0, 3, 1, dat[0], 0x16493856, 0x14);
    key[0] = HASH1(key, 3, 1, 3, 2, 0, dat[5], 0x29d0efa3, 0x05);
    key[3] = HASH1(key, 2, 0, 2, 1, 3, dat[10], - 0x02441453, 0x09);
    key[2] = HASH1(key, 1, 3, 1, 0, 2, dat[15], 0x275e197f, 0x0e);
    key[1] = HASH1(key, 0, 2, 0, 3, 1, dat[4], 0x182c0438, 0x14);
    key[0] = HASH1(key, 3, 1, 3, 2, 0, dat[9], - 0x21e1cde6, 0x05);
    key[3] = HASH1(key, 2, 0, 2, 1, 3, dat[14], 0x3cc8f82a, 0x09);
    key[2] = HASH1(key, 1, 3, 1, 0, 2, dat[3], 0x0b2af279, 0x0e);
    key[1] = HASH1(key, 0, 2, 0, 3, 1, dat[8], - 0x455a14ed, 0x14);
    key[0] = HASH1(key, 3, 1, 3, 2, 0, dat[13], 0x561c16fb, 0x05);
    key[3] = HASH1(key, 2, 0, 2, 1, 3, dat[2], 0x03105c08, 0x09);
    key[2] = HASH1(key, 1, 3, 1, 0, 2, dat[7], - 0x676f02d9, 0x0e);
    key[1] = HASH1(key, 0, 2, 0, 3, 1, dat[12], 0x72d5b376, 0x14);
    key[0] = HASH2(key, 2, 1, 3, 0, 1, dat[5], 0x0005c6be, 0x04);
    key[3] = HASH2(key, 1, 0, 2, 3, 0, dat[8], 0x788e097f, 0x0b);
    key[2] = HASH2(key, 0, 3, 1, 2, 3, dat[11], - 0x6d9d6122, 0x10);
    key[1] = HASH2(key, 3, 2, 0, 1, 2, dat[14], 0x021ac7f4, 0x17);
    key[0] = HASH2(key, 2, 1, 3, 0, 1, dat[1], 0x5b4115bc, 0x04);
    key[3] = HASH2(key, 1, 0, 2, 3, 0, dat[4], - 0x4bdecfa9, 0x0b);
    key[2] = HASH2(key, 0, 3, 1, 2, 3, dat[7], 0x0944b4a0, 0x10);
    key[1] = HASH2(key, 3, 2, 0, 1, 2, dat[10], 0x41404390, 0x17);
    key[0] = HASH2(key, 2, 1, 3, 0, 1, dat[13], - 0x289b7ec6, 0x04);
    key[3] = HASH2(key, 1, 0, 2, 3, 0, dat[0], 0x155ed806, 0x0b);
    key[2] = HASH2(key, 0, 3, 1, 2, 3, dat[3], 0x2b10cf7b, 0x10);
    key[1] = HASH2(key, 3, 2, 0, 1, 2, dat[6], - 0x04881d05, 0x17);
    key[0] = HASH2(key, 2, 1, 3, 0, 1, dat[9], 0x262b2fc7, 0x04);
    key[3] = HASH2(key, 1, 0, 2, 3, 0, dat[12], 0x1924661b, 0x0b);
    key[2] = HASH2(key, 0, 3, 1, 2, 3, dat[15], - 0x1fa27cf8, 0x10);
    key[1] = HASH2(key, 3, 2, 0, 1, 2, dat[2], 0x3b53a99b, 0x17);
    key[0] = HASH3(key, 3, 1, 2, 0, 1, dat[0], 0xbd6ddbc, 0x06);
    key[3] = HASH3(key, 2, 0, 1, 3, 0, dat[7], - 0x432aff97, 0x0a);
    key[2] = HASH3(key, 1, 3, 0, 2, 3, dat[14], 0x546bdc59, 0x0f);
    key[1] = HASH3(key, 0, 2, 3, 1, 2, dat[5], 0x036c5fc7, 0x15);
    key[0] = HASH3(key, 3, 1, 2, 0, 1, dat[12], - 0x655b59c3, 0x06);
    key[3] = HASH3(key, 2, 0, 1, 3, 0, dat[3], 0x70f3336e, 0x0a);
    key[2] = HASH3(key, 1, 3, 0, 2, 3, dat[10], 0x00100b83, 0x0f);
    key[1] = HASH3(key, 0, 2, 3, 1, 2, dat[1], 0x7a7ba22f, 0x15);
    key[0] = HASH3(key, 3, 1, 2, 0, 1, dat[8], - 0x6fa87e4f, 0x06);
    key[3] = HASH3(key, 2, 0, 1, 3, 0, dat[15], 0x01d31920, 0x0a);
    key[2] = HASH3(key, 1, 3, 0, 2, 3, dat[6], 0x5cfebcec, 0x0f);
    key[1] = HASH3(key, 0, 2, 3, 1, 2, dat[13], - 0x4e0811a1, 0x15);
    key[0] = HASH3(key, 3, 1, 2, 0, 1, dat[4], 0x8ac817e, 0x06);
    key[3] = HASH3(key, 2, 0, 1, 3, 0, dat[11], 0x42c50dcb, 0x0a);
    key[2] = HASH3(key, 1, 3, 0, 2, 3, dat[2], - 0x2ad7d2bb, 0x0f);
    key[1] = HASH3(key, 0, 2, 3, 1, 2, dat[9], 0x14792c6f, 0x15);

    key[0] += buf[0];
    key[1] += buf[1];
    key[2] += buf[2];
    key[3] += buf[3];

    key[4] += n << 3;
    key[5] += n >> 29;

    return;
}

/* quick rotate left utility function */
static unsigned rol(unsigned i, unsigned char n) 
{
   return (i << n) | (i >> (sizeof(i) * CHAR_BIT - n));
}

/* copy the hardcoded key onto argument at *buf */
static void *setkey(unsigned int *buf)
{
    return memcpy(buf, key, sizeof(key));
}
