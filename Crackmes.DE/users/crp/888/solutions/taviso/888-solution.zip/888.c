#include <stdlib.h>
#include <stdio.h>
#include <limits.h>

/* quick code to generate keys for 888 crackme */
/* by Tavis Ormandy, <taviso@sdf.lonestar.org> */

int main(int argc, char **argv)
{
    unsigned count;
    int x, y;

    if (argv[1]) {
        count = (unsigned) atoi(argv[1]);
    } else {
        fprintf(stderr, "usage: %s <number of keys to generate>\n", argv[0]);
        return 1;
    }

    for (x = 4096; x > 0; x++) {
        for (y = 4096; y > 0; y++) {
            if (((x * y) % 0x10001) == 1) {
                fprintf(stderr, "key1=%d key2=%d\n", x, y);
                if (--count == 0)
                    return 0;
                break;
            }
        }
    }
    return 0;
}
