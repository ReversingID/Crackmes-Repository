///
// * macabre's keygen for crp-'s bf crackme
///
// It will generate a key for the logged in user or you
// may specify a different user on the command line
///
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <pwd.h>

int main(int argc, char *argv[]) {
  char *user;
  FILE *fp;
  int cnt,cnt2;
  int len;
  long key=0;
  char keydata[1024];
  char genkey[4096];
  int keylen=0;
  int base;
  int add;
  struct passwd *pwinfo;

  if(argc == 1) {
	pwinfo=getpwuid(getuid());
	user=pwinfo->pw_name;
  } else if((argc == 2 && argv[1][0]=='-') || argc > 2) {
     printf("Usage: %s <username>\n",argv[0]);
     return 1;
  } else {
  	user=argv[1];
  }

  printf("Generating key for %s...\n",user);
  len=strlen(user);

  for(cnt=0;cnt < len; cnt++) {
  	key+=user[cnt]+len;
  }
  key*=len;
  key<<=10;
  for(cnt=0;cnt < len; cnt++) {
	key-=user[cnt];
	key+=cnt;
  }
  key+=key*2;
  printf("Calculated Key=%u\n",key);
  sprintf(keydata,"%u",key);
  keylen=strlen(keydata);
  sprintf(genkey,"[Key for %s (%u) - Macabre's Keygen]\n",user,key);
  for(cnt=0;cnt<keylen;cnt++) {
  	if(cnt < len) {
	  	base=user[cnt];
	} else {
		base = 0;
	}
  	strcat(genkey,",");
  	if(keydata[cnt] > base) {
		add=keydata[cnt]-base;
		for(cnt2=0;cnt2<add;cnt2++) {
			strcat(genkey,"+");
		}
	} else if(keydata[cnt] < base) {
		add=base-keydata[cnt];
		for(cnt2=0;cnt2<add;cnt2++) {
			strcat(genkey,"-");
		}
	} 
	strcat(genkey,".");
  }
  strcat(genkey,"\n");
  printf("Generating keyfile 'key.bf' ... ");
  fp=fopen("key.bf","w");
  fwrite(genkey,strlen(genkey),1,fp);
  fclose(fp);
  printf("done.\n");
  return 0;
}
