#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void initkeybuf(unsigned c);
void encryptkeybuf(char *key, unsigned ndwords);
unsigned char countbytes(unsigned x);
unsigned finalize(void);
void stage1_verify(void);
void stage3_verify(void);
int  stage5_verify(void);

unsigned len;
unsigned stage1_code; 
unsigned int buf[625];
unsigned int matrix[2] = { 0x00, 0x9908B0DF};
unsigned char first[16];
unsigned int third[4096];
unsigned char fifth[16];
char KEY1[0x0D];
char USER[0x0C];

int main(int argc, char **argv)
{
    unsigned x, y, z;

    if (argv[1] == NULL) {
        fprintf(stderr, "[!] usage: %s <registration name>\n", argv[0]);
        return 1;
    }

    strncpy(KEY1, argv[1], 0x0c);

    for (z = y = 0; y < 0xC; y++ ) {
       if (KEY1[y] == '\n' || KEY1[y] == '\0')
           z++;
       if (z) {
           KEY1[y] = '-';
       }
    }

    KEY1[y] = '\0';

    fprintf(stdout, "[*] replicating crackme state...\n");

    stage1_verify();
    stage3_verify();
    stage5_verify();

    do {
        strncat(USER, getenv("USER"), 0x0B);
    } while (strlen(USER) < 0x0B);

    fprintf(stdout, "[*] XORing your user data, %s, with state data...\n", USER);
    fprintf(stdout, "[*] Key1: %s\n[*] Key2: ", KEY1);

    for (x = 0; x < 0xc; x++)
        printf("%02hhx", (USER[x] ^ fifth[x]) & 0xff);

    printf("\n" );

    return 0;
}


/* this function is located 0x8048A74 during execution and appears to initialize a static
 * buffer based on a argument. At several locations `c` is a constant hardcoded, at others it
 * is based on the result of some other calculation.
 * 
 * There does not appear to be a return code.
 */
void initkeybuf(unsigned c)
{
    unsigned *com = buf + 1;

    for (len = 1, *com = c; len <= 0x26f; len++)
        com[len] = (((buf[len] >> 0x1e) ^ buf[len]) * 0x6c078965) + len;
}

/* this function is located at 0x8048AED during execution and only appears to be called
 * on the first key. the first argument is a pointer to the key to use, and the second
 * is the number of dwords that make up the key. The function relies on a static buffer
 * and modifies a static integer that is read by later routines.
 *
 * The return code appears to be ignored, or is void.
 */
void encryptkeybuf(char *key, unsigned ndwords)
{
    unsigned i, n, m;

    initkeybuf(0x12bd6aa);

    len = (ndwords < 0x270) ? 0x270 : ndwords;

    for (i = len, n = 1; i > 0; i--, n++)
        buf[n+1] = ((((buf[n] >> 0x1e) ^ buf[n]) * 1664525) ^ buf[n+1]) +
                   (((unsigned *) key)[m = (n-1) % ndwords] + m);

    buf[n=1] = buf[624];
    buf[n+1] = ((((buf[n] >> 0x1e) ^ buf[n]) * 1664525) ^ buf[n+1])+
               (((unsigned *) key)[m] + m);

    for (len = 2; len <= 0x26f; len++)
        buf[len+1] = ((((buf[len] >> 0x1e) ^ buf[len]) * 0x5d588b65) ^
                      buf[len+1]) - len;

    buf[n=1] = buf[624];
    buf[n+1] = ((((buf[n] >> 0x1e) ^ buf[n]) * 0x5d588b65) ^ buf[n+1]) - n;
    buf[1] = 0x80000000;
    return;
}

/* this routine is called in the first stage of key verification */
unsigned finalize(void)
{
    unsigned t, i, *b = buf + 1;

    if (len > 0x26f) {
        if (len == 0x271) initkeybuf(0x1571);

        for (i = 0; i <= 0xe2; i++) {
            t = (b[i+1] & 0x7FFFFFFF) | (b[i] & 0x80000000);
            b[i] = matrix[t & 1] ^ ((t >> 1) ^ b[397+i]);
        }

        for (; i <= 0x26e; i++) {
            t = (b[i+1] & 0x7FFFFFFF) | (b[i] & 0x80000000);
            b[i] = matrix[t & 1] ^ ((t >> 1) ^ b[i-0xE3]);
        }

        t = (b[0] & 0x7FFFFFFF) | (b[623] & 0x80000000);
        b[623] = matrix[t & 1] ^ ((t >> 1) ^ b[396]);

        len = 0;

    }

    t = b[len] ^ (b[len] >> 0xb);
    t ^= (t << 7) & 0x9d2c5680;
    t ^= (t << 0xf) & 0xefc60000;
    t ^= (t >> 0x12);

    ++len;

    return t;
}

void stage1_verify(void)
{
    unsigned i, keylen = strlen(KEY1);

    if ((keylen & 3) != 0) keylen -= keylen & 3;

    encryptkeybuf(KEY1, keylen >> 2);

    for (i = 0; i <= 0xf; i++) {
        first[i] = finalize() & 0xff;
        stage1_code += finalize();
    }

    ++stage1_code;   

    return;
}

void stage3_verify(void)
{
    unsigned x, y;

    initkeybuf(stage1_code);

    for (x = 0; x <= 0x0f; x++)
        for (y = 0; y <= 0xff; y++)
            third[(x << 8) + y] = finalize();

    return;
}

int stage5_verify(void)
{
    unsigned i, n;

    for (i = 0; i <= 0xf; i++) {
        if (i <= 0xb) {
            fifth[i] = countbytes(third[first[i] + (i << 8)]);
        } else {
          for (n = 0; n <= 0xb; n++) {
              fifth[n] ^= countbytes(third[first[i] + (i << 8)]);
          }
        }
    }

    return 1;
}

/* just returns the sum of each byte */
unsigned char countbytes(unsigned x)
{
    unsigned char k = 0;
    k += (x & 0x000000ff) >>  0;
    k += (x & 0x0000ff00) >>  8;
    k += (x & 0x00ff0000) >> 16;
    k += (x & 0xff000000) >> 24;
    return k;
}

