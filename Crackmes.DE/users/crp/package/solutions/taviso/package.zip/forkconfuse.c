#include <time.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>

int main(int argc, char **argv)
{
    time_t t;
    pid_t me, pid;

    me = getpid();

    t = time(NULL);
    switch (pid = fork()) {
        default: t++;
        case  0: if ((t & 1) == 0) goto fail;
    }

    t = time(NULL);
    switch (pid = fork()) {
        default: t++;
        case  0: if ((t & 1) == 0) goto fail;
    }

    t = time(NULL);
    switch (pid = fork()) {
        default: t++; 
        case  0: if ((t & 1) == 0) goto fail;
    }

    printf("ppid was %u, but pid that completed was %u\n", me, getpid());

fail:
    return 0;
}
