#include <windows.h>
#include <stdio.h>

//the buffer as it sits in the crackme. This needs to be transformed
//to what we want
char EncryptedBuff[0x80] = 
{
    (char)0x0D, (char)0x20, (char)0x73, (char)0x61, 
    (char)0x74, (char)0x48, (char)0xA8, (char)0x7F, 
    (char)0x37, (char)0x6E, (char)0x53, (char)0xC5, 
    (char)0x71, (char)0x2E, (char)0x64, (char)0xDF, 
    (char)0x53, (char)0xD3, (char)0x42, (char)0x60, 
    (char)0x73, (char)0x90, (char)0x78, (char)0x45, 
    (char)0x00, (char)0x2D, (char)0x6F, (char)0xAE, 
    (char)0x3C, (char)0x01, (char)0x01, (char)0x53, 
    (char)0x5B, (char)0x64, (char)0x64, (char)0x5B, 
    (char)0x48, (char)0x04, (char)0x05, (char)0x02, 
    (char)0x48, (char)0x1C, (char)0x1C, (char)0x00, 
    (char)0x10, (char)0x02, (char)0x0E, (char)0x08, 
    (char)0x0E, (char)0x45, (char)0x1C, (char)0x4E, 
    (char)0x74, (char)0x7B, (char)0x48, (char)0x26, 
    (char)0x00, (char)0x02, (char)0x0F, (char)0x0E, 
    (char)0x00, (char)0x16, (char)0x45, (char)0x01, 
    (char)0x18, (char)0x4F, (char)0x06, (char)0x45, 
    (char)0x1A, (char)0x0C, (char)0x04, (char)0x4E, 
    (char)0x5B, (char)0x49, (char)0x15, (char)0x48, 
    (char)0x43, (char)0x0E, (char)0x4E, (char)0x17, 
    (char)0x10, (char)0x00, (char)0x1E, (char)0x0C, 
    (char)0x1C, (char)0x47, (char)0x48, (char)0x09, 
    (char)0x15, (char)0x04, (char)0x46, (char)0x42, 
    (char)0x06, (char)0x08, (char)0x1B, (char)0x7D, 
    (char)0x3E, (char)0x1C, (char)0x16, (char)0x0C, 
    (char)0x7E, (char)0x66, (char)0x09, (char)0x18, 
    (char)0x09, (char)0x12, (char)0x48, (char)0x4F, 
    (char)0x12, (char)0x48, (char)0x04, (char)0x57, 
    (char)0x01, (char)0x5C, (char)0x41, (char)0x47, 
    (char)0x3C, (char)0x1B, (char)0x5E, (char)0x45, 
    (char)0x18, (char)0x11, (char)0x49, (char)0x00, 
    (char)0x1E, (char)0x09, (char)0x07, (char)0x32
};

//the data that will be written out to the keyfile
char KeyFile[0x81] =
{
	(char)0x00,
    (char)0xE8, (char)0x00, (char)0x00, (char)0x00, 
    (char)0x00, (char)0x6A, (char)0x00, (char)0x68, 
    (char)0xCC, (char)0x10, (char)0x40, (char)0x00, 
    (char)0x68, (char)0xE1, (char)0x10, (char)0x40, 
    (char)0x00, (char)0xE9, (char)0x4E, (char)0x02, 
    (char)0x00, (char)0x00, (char)0x20, (char)0x4C, 
    (char)0x54, (char)0x48, (char)0x20, (char)0xC3, 
    (char)0x43, (char)0x72, (char)0x61, (char)0x63, 
    (char)0x6B, (char)0x65, (char)0x64, (char)0x20, 
    (char)0x62, (char)0x79, (char)0x20, (char)0x4C, 
    (char)0x69, (char)0x67, (char)0x68, (char)0x74, 
    (char)0x6E, (char)0x69, (char)0x6E, (char)0x67, 
    (char)0x00, (char)0x52, (char)0x65, (char)0x67, 
    (char)0x69, (char)0x73, (char)0x74, (char)0x65, 
    (char)0x72, (char)0x65, (char)0x64, (char)0x20, 
    (char)0x74, (char)0x6F, (char)0x20, (char)0x00, 
    (char)0x00, (char)0x00, (char)0x00, (char)0x00, 
    (char)0x00, (char)0x00, (char)0x00, (char)0x00, 
    (char)0x00, (char)0x00, (char)0x00, (char)0x00, 
    (char)0x00, (char)0x00, (char)0x00, (char)0x00, 
    (char)0x00, (char)0x00, (char)0x00, (char)0x00, 
    (char)0x00, (char)0x00, (char)0x00, (char)0x00, 
    (char)0x00, (char)0x00, (char)0x00, (char)0x00, 
    (char)0x00, (char)0x00, (char)0x00, (char)0x00, 
    (char)0x00, (char)0x00, (char)0x00, (char)0x00, 
    (char)0x00, (char)0x00, (char)0x00, (char)0x00, 
    (char)0x00, (char)0x00, (char)0x00, (char)0x00, 
    (char)0x00, (char)0x00, (char)0x00, (char)0x00,
    (char)0x00, (char)0x00, (char)0x00, (char)0x00, 
    (char)0x00, (char)0x00, (char)0x00, (char)0x00, 
    (char)0x00, (char)0x00, (char)0x00, (char)0x00, 
    (char)0x00, (char)0x00, (char)0x00, (char)0x00
};

char MiddleBuff[0x100];

int main()
{
	char	RegName[50];
	long	NameLen;
	long	Counter=0;
	long	MagicValue;
	char	HexConvert;
	HANDLE	FileHandle;

	while(1)
	{
		printf("KeyGen for F0dder's #2 Crackme");
		printf("\n\nRegistered Name: ");
		scanf("%[^\n\0]s", RegName);
		if(strlen(RegName) > 16)
		{
			printf("\nName must be shorter than 16 characters");
			continue;
		}

		if(strlen(RegName) == 0)
		{
			printf("\n\nNo name entered. Exiting.");
			printf("\nCtrl+C to close");
			while(1)
				Counter++;
		}

		break;
	}

	//get the length of the name
	NameLen = strlen(RegName);

	//blank the middle buffer out
	memset(MiddleBuff, 0, 0x80);

	//copy the name into what will be the buffer for the keyfile
	memcpy(&KeyFile[0x40], RegName, NameLen);

	//copy the name until it is 16 chars long
	memcpy(MiddleBuff, &RegName, NameLen);
	if(NameLen < 16)
	{
		Counter = 16 / NameLen;
		Counter++;
		while(Counter)
		{
			memcpy(&MiddleBuff[NameLen * Counter], RegName, NameLen);
			Counter--;
		}
	}

	//generate one of the buffers used based on the name/key passed in
	for(Counter=0; Counter < 0x70; Counter++)
		MiddleBuff[Counter+0x10] = MiddleBuff[Counter] ^ MiddleBuff[Counter + 1];


	//now, take the KeyFile buff and manipulate it so we get what we want
	//for executable code
	for(Counter=0x7F; Counter >= 0; Counter--)
		KeyFile[Counter] = KeyFile[Counter] ^ EncryptedBuff[Counter-1];

	//you may note that I didn't do any changes to the last 32 bytes. The last
	//32 bytes are "garbage" bytes as far as I am conserned as they are used to
	//cause the buffer to pass
	MagicValue = 0x0BADC0DE;
	_asm
	{
		mov ecx, 0x60
		mov eax, 0x0BADC0DE
		lea ebx, KeyFile

	GenMagic:
		xor al, [ebx]
		rol eax, 1

		inc ebx
		dec ecx
		jnz GenMagic

		//time to manipulate the last 32 bytes so the MagicValue becomes what we want
		//I could sit down and figure out exactly how many bytes I need and how to manipulate
		//them to get what I want but this is just easier
		
		lea ebx, [KeyFile + 60h]
		mov edi, 0xFCC5A375
		mov ecx, 0x20

	FixMagic:
		mov edx, edi
		mov dh, al
		and dh, 1
		and dl, 1
		cmp dh, dl
		
		je NoMagic
		mov [ebx], 0x01
		jmp NextMagic

	NoMagic:
		mov [ebx], 0x00

	NextMagic:
		inc ebx
		dec ecx
		rol eax, 1
		rol edi, 1
		jne FixMagic
	}

	//the last step should be to take the KeyFile buffer and the MiddleBuff and xor em together
	for(Counter=0; Counter < 0x80; Counter++)
		KeyFile[Counter] = KeyFile[Counter] ^ MiddleBuff[Counter];

	//now the final step. convert each char to hex to put out to the file.
	MagicValue = 0;
	for(Counter=0; Counter < 0x80; Counter++, MagicValue++)
	{
		HexConvert = (KeyFile[Counter] >> 4) & 0x0F;
		if(HexConvert > 0x09)
			MiddleBuff[MagicValue] = HexConvert + 0x37;
		else
			MiddleBuff[MagicValue] = HexConvert + 0x30;


		MagicValue++;
		HexConvert = KeyFile[Counter] & 0xF;
		if(HexConvert > 0x09)
			MiddleBuff[MagicValue] = HexConvert + 0x37;
		else
			MiddleBuff[MagicValue] = HexConvert + 0x30;

	}

	FileHandle = CreateFile("skeleton.key", GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, 0, NULL);
	if((long)FileHandle == 0xFFFFFFFF)
		printf("Error opening skeleton.key file");
	else
	{
		WriteFile(FileHandle, MiddleBuff, 0x100, &Counter, 0);
		CloseHandle(FileHandle);
		printf("Keyfile generated.");
	}


	printf("\n\nCtrl+C to close");
	while(1)
		Counter++;

	return 0;

}