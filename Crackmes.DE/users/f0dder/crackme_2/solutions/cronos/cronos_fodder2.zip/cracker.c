#include <string.h>
#include <stdio.h>
#include <fcntl.h>
#include <process.h>
#include <io.h>
#include <sys\stat.h>
#include <errno.h>

unsigned char book[70000];    // usher10.txt=55k
unsigned char encstring[0x91]; // encrypted string = 0x91 bytes
unsigned char decstring[0x91]; // decrypted string = 0x91 bytes
int infile,
    blen,
    len;
char nick[]="Cronos";
char nickstring[128];
char keyfile[128];
char keyf[256];

void trydecrypt(char *buff)
{ int c,i;
  unsigned long csum;

  for(c=0;c<0x91;c++)
  { decstring[c]=encstring[c]^buff[(c+1)&0x7f];
  }

  // check the byte we know
  if(decstring[0x4010cb-0x4010b0]!=0xc3)
    return;

  // check the checksum we know
  csum=0xbadc0de;
  for(c=0;c<128;c++)
  { csum=csum^buff[c];
    csum=(csum<<1)+(csum>>31);
  }
  if(csum!=0xfcc5a375)
    return;

  // candidate: dump info on it
  printf("Found candidate:\n");
  for(c=0;c<128;c++)
    printf("%c",buff[c]);
  printf("\n");
  printf("Decrypted buffer:\n");
  for(c=0;c<0x91;c++)
    printf("%02x",decstring[c]);
  printf("\n");
  for(c=0;c<0x91;c++)
  { if(isprint(decstring[c]))
      printf("%c",decstring[c]);
    else
      printf(".");
  }
  printf("\n\n");

  // now to calculate a keyfile for our nick.....
  for(i=0;i<strlen(nick);i++)
  { nickstring[i]=nick[i];
  }
  for(i=strlen(nick);i<16;i++)
  { nickstring[i]=nickstring[i-strlen(nick)];
  }
  for(i=16;i<128;i++)
  { nickstring[i]=nickstring[i-16]^nickstring[i-15];
  }
  for(i=0;i<128;i++)
  { keyfile[i]=nickstring[i]^buff[i];
    keyf[i*2]=((keyfile[i]&0xf0)>>4)+'0';
    keyf[i*2+1]=((keyfile[i]&0x0f))+'0';
    if(keyf[i*2]>'9')
      keyf[i*2]=((keyfile[i]&0xf0)>>4)+'A'-10;
    if(keyf[i*2+1]>'9')
      keyf[i*2+1]=((keyfile[i]&0x0f))+'A'-10;
  }
  // write file
  printf("Writing Keyfile....\n");
  if ((infile=open("skeleton.key",O_CREAT|O_TRUNC|O_BINARY|O_WRONLY,S_IREAD|S_IWRITE))==-1)
  { printf("Can't Open file\n");
    exit(1);
  }
  lseek(infile,0x0,SEEK_SET);
  blen=write(infile,keyf,256);
  printf("Wrote %d bytes to skeleton.key\n",blen);
  if(errno==EACCES)
    printf("Access error\n");
  close(infile);
}

void main(void)
{ int i;

  if ((infile=open("usher10.txt",O_BINARY))==-1)
  { printf("Can't Open file\n");
    exit(1);
  }
  blen=read(infile,book,70000);
  printf("Read %d bytes from usher10.txt\n",blen);
  close(infile);

  if ((infile=open("crackme2.exe",O_BINARY))==-1)
  { printf("Can't Open file\n");
    exit(1);
  }
  lseek(infile,0x4b0,SEEK_SET);
  len=read(infile,encstring,0x91);
  printf("Read %d bytes from crackme2.exe\n",len);
  close(infile);

  for(i=0;i<blen-len;i++)
  { trydecrypt(&book[i]);
  }
}
