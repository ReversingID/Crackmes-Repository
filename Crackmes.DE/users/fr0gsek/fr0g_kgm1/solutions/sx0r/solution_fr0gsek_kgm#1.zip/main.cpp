#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main()
{
    string table    = "SeRiAlAbCdEfGhIjKlMnOpQrStUvWxYz";
    string login    = "";
    char serial[32] = "";

    unsigned int y = 0;

    cout << "Keyfilemaker for fr0g's KGM#1\n\n" << endl;

    cout << "Enter Login: ";
    getline(cin, login);


    if (login.length() < 5)
        cout << "Enter a least 5 chars!" << endl;
    else
    {
        for (int x = 31; x >= 0; x--)
        {
            serial[x] = table[x] ^ login[y];
            y += 1;

            if (y == login.length())
                y = 0;
        }

        ofstream output ("/var/tmp/thegame.serial", ofstream::binary);
        output.write(serial, sizeof serial);
        output.close();

        cout << "Keyfile written" << endl;
    }

    return 0;
}
