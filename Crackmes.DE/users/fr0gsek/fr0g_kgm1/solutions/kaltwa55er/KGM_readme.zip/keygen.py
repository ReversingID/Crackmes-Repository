#!/usr/bin/python

username = (raw_input('Enter username: '))
username_len = len(username)
data2XOR = 'SeRiAlAbCdEfGhIjKlMnOpQrStUvWxYz'

y = 0

for x in range (0,32):
  if (x==0):
    user2XOR = username[y]
  else:
    user2XOR = user2XOR + username[y]
  y=y+1
  if (y==username_len):
    y = 0

user2XOR = user2XOR[::-1]

for x in range (0,32):
    if (x==0):
        encode = str(unichr(ord(user2XOR[x]) ^ ord(data2XOR[x])))
    else:
        encode += str(unichr(ord(user2XOR[x]) ^ ord(data2XOR[x])))

ofile = open("/var/tmp/thegame.serial","wb")
ofile.write(encode);
ofile.close
