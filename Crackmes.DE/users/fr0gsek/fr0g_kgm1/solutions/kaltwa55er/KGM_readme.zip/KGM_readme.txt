 // ////////////////////////////////////////////////////////////////////////
 //                         KGM#1 Keygen Solution                         //
 // ////////////////////////////////////////////////////////////////////////
 //                                                                       // 
 // Name:  Kaltwa55er							  //
 // Date:  9/25/16							  //
 // Tools: used: GDB, objdump                                             //
 //                                                                       //
 // ////////////////////////////////////////////////////////////////////////
 When the program is run it asks for a login name of at least 5 characters
 long and prints a message a serial file is not found

 I used objdump to get an idea of the program layout using objdump -D KGM#1
 and then opened with GDB to start stepping through the program.

 We enter the program here and begin with writing to the console and asking for a user name
 
 8048097:	b8 04 00 00 00       	mov    $0x4,%eax              // Entry Point
 804809c:	bb 01 00 00 00       	mov    $0x1,%ebx
 80480a1:	b9 b8 91 04 08       	mov    $0x80491b8,%ecx
 80480a6:	ba 1a 00 00 00       	mov    $0x1a,%edx
 80480ab:	cd 80                	int    $0x80                  // System write "KGM#1 (fr0g 2k16)", "Login: "
 80480ad:	b8 03 00 00 00       	mov    $0x3,%eax
 80480b2:	31 db                	xor    %ebx,%ebx
 80480b4:	b9 90 92 04 08       	mov    $0x8049290,%ecx        // Username buffer pointer
 80480b9:	ba 20 00 00 00       	mov    $0x20,%edx             
 80480be:	cd 80                	int    $0x80                  // System read
 80480c0:	48                   	dec    %eax
 80480c1:	50                   	push   %eax
 80480c2:	c6 80 90 92 04 08 00 	movb   $0x0,0x8049290(%eax)
 80480c9:	68 90 92 04 08       	push   $0x8049290
 80480ce:	e8 ad ff ff ff       	call   0x8048080              // Call to get the length of the username

 The username must be at least 5 characters long or we branch off to an output message
 and exit the program
 
 80480d3:	83 f8 05             	cmp    $0x5,%eax              
 80480d6:	5e                   	pop    %esi                   
 80480d7:	73 1b                	jae    0x80480f4              // Jump if username is 5 characters or greater
 80480d9:	b8 04 00 00 00       	mov    $0x4,%eax
 80480de:	bb 01 00 00 00       	mov    $0x1,%ebx
 80480e3:	b9 d2 91 04 08       	mov    $0x80491d2,%ecx        // "The login must be 5 chars long at least"
 80480e8:	ba 28 00 00 00       	mov    $0x28,%edx
 80480ed:	cd 80                	int    $0x80                  // System write 
 80480ef:	e9 b9 00 00 00       	jmp    0x80481ad

 Program opens a file expecting it to have a specific name and location
 
 80480f4:	b8 05 00 00 00       	mov    $0x5,%eax
 80480f9:	bb fa 91 04 08       	mov    $0x80491fa,%ebx        // Filename expected "var/tmp/thegame.serial"
 80480fe:	31 c9                	xor    %ecx,%ecx
 8048100:	cd 80                	int    $0x80                  // System open
 8048102:	50                   	push   %eax
 8048103:	83 f8 fe             	cmp    $0xfffffffe,%eax       // Compare -2(no such file)
 8048106:	75 1b                	jne    0x8048123
 8048108:	b8 04 00 00 00       	mov    $0x4,%eax              // Here if no file found
 804810d:	bb 01 00 00 00       	mov    $0x1,%ebx
 8048112:	b9 33 92 04 08       	mov    $0x8049233,%ecx        // "Serial file not found"
 8048117:	ba 16 00 00 00       	mov    $0x16,%edx
 804811c:	cd 80                	int    $0x80                  // System write
 804811e:	e9 8a 00 00 00       	jmp    0x80481ad              // Jump to system exit

  
 8048123:	b8 03 00 00 00       	mov    $0x3,%eax              // Here if file found
 8048128:	5b                   	pop    %ebx
 8048129:	b9 b0 92 04 08       	mov    $0x80492b0,%ecx
 804812e:	ba 20 00 00 00       	mov    $0x20,%edx
 8048133:	cd 80                	int    $0x80                  // System read
 8048135+:	83 f8 20             	cmp    $0x20,%eax            
 8048138:	74 16                	je     0x8048150              // Jump if 32 characters
 804813a:	b8 04 00 00 00       	mov    $0x4,%eax
 804813f:	bb 01 00 00 00       	mov    $0x1,%ebx
 8048144:	b9 12 92 04 08       	mov    $0x8049212,%ecx        // "The Serial must be 32 chars long"
 8048149:	ba 21 00 00 00       	mov    $0x21,%edx
 804814e:	cd 80                	int    $0x80                  // System write

 The program now checks the serial regardless of serial character length. Memory location 0x8040249
 contains the string "SeRiAlAbCdEfGhIjKlMnOpQrStUvWxYz" which will be XORd with the username.
 The first character of the username will XORd with the 32nd string in memory. We repeat the username
 if less then 32 charcters long.
 Example:

 username = foobar
 
 SeRiAlAbCdEfGhIjKlMnOpQrStUvWxYz ^ ofraboofraboofraboofraboofraboof
 
 8048150:	5f                   	pop    %edi                   // From 32 char compare
 8048151:	b9 20 00 00 00       	mov    $0x20,%ecx
 8048156:	31 d2                	xor    %edx,%edx
 8048158:	49                   	dec    %ecx
 8048159:	8a a1 49 92 04 08    	mov    0x8049249(%ecx),%ah    // get character from string in memory
 804815f:	8a 82 90 92 04 08    	mov    0x8049290(%edx),%al    // get character from username
 8048165:	30 e0                	xor    %ah,%al                // XOR characters
 8048167:	3a 81 b0 92 04 08    	cmp    0x80492b0(%ecx),%al    // Compare with serial found in file
 804816d:	75 26                	jne    0x8048195              // Jump if no correct
 804816f:	42                   	inc    %edx
 8048170:	39 fa                	cmp    %edi,%edx              // Compare to username length
 8048172:	72 02                	jb     0x8048176              // Jump if not equal
 8048174:	31 d2                	xor    %edx,%edx              // EDX is reset to 0
 8048176:	83 f9 00             	cmp    $0x0,%ecx              // Check to see if we have reached 0
 8048179:	75 dd                	jne    0x8048158              // Jump until we go from 32 down to 0
 804817b:	eb 00                	jmp    0x804817d              
 804817d:	b8 04 00 00 00       	mov    $0x4,%eax 
 8048182:	bb 01 00 00 00       	mov    $0x1,%ebx
 8048187:	b9 7d 92 04 08       	mov    $0x804927d,%ecx        // "Yeh, you did it"
 804818c:	ba 10 00 00 00       	mov    $0x10,%edx
 8048191:	cd 80                   int    $0x80                  // System write
 8048193:	eb 18                	jmp    0x80481ad
 
 8048195:	b8 04 00 00 00       	mov    $0x4,%eax
 804819a:	bb 01 00 00 00       	mov    $0x1,%ebx
 804819f:	b9 69 92 04 08       	mov    $0x8049269,%ecx        // "Wrong, try again..."
 80481a4:	ba 14 00 00 00       	mov    $0x14,%edx
 80481a9:	cd 80                	int    $0x80                  // System Write 
 80481ab:	eb 00                	jmp    0x80481ad
 
 80481ad:	b8 01 00 00 00       	mov    $0x1,%eax         
 80481b2:	31 db                	xor    %ebx,%ebx
 80481b4:	cd 80                	int    $0x80                  // System Exit

 I made a python file to create the serial file the program expects using a
 given username

 // ////////////////////////////////////////////////////////////////////////
 //                        Serial Generator                               //
 // ////////////////////////////////////////////////////////////////////////
 #!/usr/bin/python

username = (raw_input('Enter username: '))
username_len = len(username)
data2XOR = 'SeRiAlAbCdEfGhIjKlMnOpQrStUvWxYz'

y = 0

for x in range (0,32):
  if (x==0):
    user2XOR = username[y]
  else:
    user2XOR = user2XOR + username[y]
  y=y+1
  if (y==username_len):
    y = 0

user2XOR = user2XOR[::-1]

for x in range (0,32):
    if (x==0):
        encode = str(unichr(ord(user2XOR[x]) ^ ord(data2XOR[x])))
    else:
        encode += str(unichr(ord(user2XOR[x]) ^ ord(data2XOR[x])))

ofile = open("/var/tmp/thegame.serial","wb")
ofile.write(encode);
ofile.close