#!/bin/bash
#script for generating keys for login for KGM.
#there is a issue with non-printable ascii char 
#where they load into the program incorrectly eg ESC (27) will load as \027 and fail.
#this is an issue with the program
login=$1
#key used 
crypt=SeRiAlAbCdEfGhIjKlMnOpQrStUvWxYz
#get length of login
check=${#login}
#inits
i='0'
pos='0'
c='0'

while [ "$i" -lt 32 ]
	do
	if [ "$c" -eq "$check" ]; then
		c=0;
		fi
		#buffer postion 
		buff=$(($pos + $i))
		#first variable to xor login letter 
		x=$(printf '%d' "'${login:$c:1}")
		#second variable for xor crypt letter.
		y=$(printf '%d' "'${crypt:$buff:1}")
		#print ascii char
		printf "\\$(printf '%03o' "$(( y  ^ x ))")"
		#inc 
		c=$(( $c + 1))
		i=$(( $i + 1 ))
	done



