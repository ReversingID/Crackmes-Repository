Solution for "Keygenme #2 by Nicohogtag"
Solved by vigilanz (vigilanz@wolfnode.de), 2013

This time a solution written in Pascal (fpc/lazarus, but console program) w/ inline assembler.

I cannot say much about the algorithm because ... I don't need to understand it. This crackme's
generation code could easily be copied and adapted 1:1 in the keygen.

What I can say is that ... this one seems a little bit buggy, isn't it? It takes first 10 
characters from the user name, but the buffer seems too short, if you enter a short name,
positions 8 and 9 are 0x74, 0xFF.

However, variable addresses were changed to match what's expected by the pascal compiler,
so e.g. 

mov     eax, [ebp+var_10]

becomes

mov     eax, [var_10]

forthermore, loading the initial username via

mov     eax, ebp
add     eax, [ebp+var_20]
sub     eax, 8

translates to 

lea     eax, [uname]
add     eax, [var_20]

in my keygen.

For a real tutorial ... what can I say? The program reads user input for the user name
at .text:00401445, and .text:00401500 compares the calculated serial with what the user
entered (converted to integer).

-vigilanz