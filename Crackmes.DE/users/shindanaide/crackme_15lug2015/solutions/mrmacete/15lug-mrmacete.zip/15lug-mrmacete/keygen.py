
def keygen():
	i = len("CrackME_15lug2015")
	i *= 40
	i -= 52
	i += 219
	i += 9608
	i += 208
	i -= 229

	return i

if __name__ == "__main__":
	print keygen()