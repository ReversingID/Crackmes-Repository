Skip this section if you do this crackme entirely in IDA.

==CUT

First step is to bypass the anti-debug. The anti-debug is done through using
the TLS directory: when a thread starts, TlsCallback_0 at 0x4011D3 is run:

.text:004011D3 TlsCallback_0   proc near
.text:004011D3                 cmp     byte ptr ds:start, 0CCh
.text:004011DA                 jnz     short entry_bp_detect
.text:004011DC                 mov     eax, 40119Dh
.text:004011E1                 mov     word ptr [eax], 0FF9Ah
.text:004011E6
.text:004011E6 entry_bp_detect:
.text:004011E6                 retn
.text:004011E6 TlsCallback_0   endp

If a breakpoint is set at the entry of the program (as a debugger does), then
the address of the function in the CALL instruction at 0x40119C is overwritten.

In order to prevent you from just attaching after process creation to avoid your
debugger breakpointing at the start, an unhandled exception filter is set up and
then an invalid-instruction exception is induced. Since the exception structure 
isn't actually used and you can't return from an unhandled excpetion, you can
 eplace the exception-causing instruction:

.text:00401015                 db 2 dup(0F0h), 0C7h, 0C8h, 0EBh, 38h, 0FFh, 35h ; force interrupt

with a jump to the start of the exception handler (the actual main).

Now, just patch the instruction at 0x40119C with the correct address, which you
can discover by opening the exe in IDA.

==ENDCUT

The key-check function is discovered to be at 0x401066. The listing is a bit
long to include here.

The key-check function calls a function at 0x40105A a lot, which maps
the byte at [ESI] to a value, then increments ESI:

.text:0040105A read_byte       proc near
.text:0040105A                 lodsb
.text:0040105B                 sub     al, 30h         ; map "0" -> 0x0
.text:0040105D                 jb      short loc_401063 ; if val after map < 0, force to 0
.text:0040105F                 cmp     al, 9           ; if val is not a number, force to 0
.text:00401061                 jbe     short locret_401065 ; else return val
.text:00401063
.text:00401063 loc_401063:
.text:00401063                 xor     eax, eax
.text:00401065
.text:00401065 locret_401065:
.text:00401065                 retn
.text:00401065 read_byte       endp


The real key-check function can be expressed as a series of rules:

Let key be the key as a null-terminated ASCII string.
Let p[n] be the array of return values of read_bytes when ESI = key + n.

For all n, 0 <= p[n] <= 9, by the definition of read_byte.

For all n 0 <= n < 6, 1 <= p[n] <= 6, due to:

.text:00401117 digit_restrict:                         ; CODE XREF: key_check+BFj
.text:00401117                 call    read_byte
.text:0040111C                 test    eax, eax
.text:0040111E                 jz      short key_exit
.text:00401120                 cmp     eax, 6
.text:00401123                 ja      short key_exit


1: p[0] + p[1] + p[2] = p[2] + p[3] + p[4]
	simplifies to p[0] + p[1] = p[3] + p[4].
2: p[0] + p[1] + 2*p[2] + p[3] + p[4] = p[0] + p[2] + p[3] + 2*p[4] + p[5]
	simplifies to p[1] + p[2] = p[4] + p[5].
3: p[6] = '-'.
4: floor((p[0] + p[2] + p[3] + 2*p[4]+ p[5]) / 2) = p[7] + 10*p[8].
	Note that key[8] can be '\0', which implies p[8] = 0.
	
	This implies:
	p[7] = floor((p[0] + p[2] + p[3] + 2*p[4]+ p[5]) / 2) mod 10
	p[8] = floor((p[0] + p[2] + p[3] + 2*p[4]+ p[5]) / 2) / 10
5: No repeats in the first six digits

Since it is p[7] and p[8] are computable based on p[0] - p[5] and p[6] is
a constant, the main issue is getting a set of p[0] - p[5] that satisfy
conditions 1 and 2. It is readily apparent that this is an underdetermined
system of equations. By binding four of the six unknowns: p[1], p[4], p[3],
and p[5], the system of equations becomes determined.

So, we need to find an efficient way to bind them. Since there is a no-repeat
rule for the first 6 digits, this can be done in 360 tries by choosing them
as a 4-permutation of 1-6, computing the other values, and verifying that they
are all within their respective bounds and that p[0] and p[2] aren't repeats.

Since p[8] = 0 if key[8] = 0, there are remaining combinations if key[8] is
anything other than a digit (including the null character). I believe the
intention was to use the null character, but the crackme also allows other
answers.

Keygen source is provided. It's...poorly written in parts, though.

Answer list (30 all-numeric):
516243-21
416325-11
615342-21
614523-11
426153-21
624351-21
325416-01
523614-01
236145-11
435162-21
534261-21
632541-11
145236-01
243516-90
243516-9
342615-90
342615-9
541632-01
254163-11
452361-11
153426-90
153426-9
351624-90
351624-9
163254-01
162435-90
162435-9
361452-01
261534-90
261534-9
