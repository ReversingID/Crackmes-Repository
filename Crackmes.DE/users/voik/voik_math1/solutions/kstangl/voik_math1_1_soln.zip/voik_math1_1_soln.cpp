// voik_math1_1_soln.cpp : Defines the entry point for the console application.
//

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct solution
{
	int key[8]; /* While keys are 7 or 8 chars long, one is always a hyphen. */
	struct solution *next;
	bool has_null;
};

bool valid_init(struct solution *cur)
{
	if(cur->key[4] +cur->key[5] <= cur->key[1])
		return false;

	if(cur->key[3] + cur->key[4] <= cur->key[1])
		return false;

	return true;
}

/* Obsolete */
bool incr_soln(struct solution *cur)
{
	/* Increment {1, 3, 4, 5} with max of 6. */		
	if(++cur->key[5] == 7)
	{
		cur->key[5] = 1;
		if(++cur->key[4] == 7)
		{
			cur->key[4] = 1;
			if(++cur->key[3] == 7)
			{
				cur->key[3] = 1;
				if(++cur->key[1] == 7)
					return false;
			}
		}
	}
	return true;
}


bool next_valid_soln(struct solution* cur, bool& first)
{
	if(first)
	{
		/* Set initial permutation */

		/* BUG: missing 426153-21 -> {1,3,4,5} = {2, 1, 5, 3} */
		cur->key[1] = 1;
		cur->key[3] = 2;
		cur->key[4] = 3;
		cur->key[5] = 4;
		first = false;
		return true;
	}
	else
	{
		/* Free digits are 
		 * ({1...6} - (key[1], key[2], key[4], key[5]). */
		bool free_digit[6];
		unsigned idx[4] = {1, 3, 4, 5};
		unsigned i;

		memset(&free_digit[0], (int)true, sizeof(free_digit));

		for(i = 0; i < 4; i++)
			free_digit[cur->key[idx[i]] - 1] = false;

		/* Increment cur->key[5] to next highest free digit.
		 * If no free digits are higher, free cur->key[5], increment key[4], etc. */

		for(i = cur->key[5]; i < 6; i++)
		{
			if(free_digit[i])
			{
				cur->key[5] = i + 1;
				return true;
			}
		}

		/* No higher free digit. */
		free_digit[cur->key[5] - 1] = true;
		for(i = cur->key[4]; i < 6; i++)
		{
			if(free_digit[i])
			{
				free_digit[cur->key[4] - 1] = true;
				cur->key[4] = i + 1;
				free_digit[i] = false;
				/* Bind cur->key[5] */

				for(unsigned j = 0; j < 6; j++)
				{
					/* At least one digit is free */
					if(free_digit[j])
					{
						cur->key[5] = j + 1;
						return true;
					}
				}
				/* Unreachable */
				assert(false);
			}
		}


		/* I think you get the point here */
		free_digit[cur->key[4] - 1] = true;

		for(i = cur->key[3]; i < 6; i++)
		{
			if(free_digit[i])
			{
				free_digit[cur->key[3] - 1] = true;
				cur->key[3] = i + 1;
				free_digit[i] = false;

				/* Bind cur->key[4] */
				unsigned j;

				for(j = 0; j < 6; j++)
				{
					if(free_digit[j])
					{
						free_digit[j] = false;
						cur->key[4] = j + 1;
						break;
					}
				}

				/* and 5 */

				for(j = 0; j < 6; j++)
				{
					if(free_digit[j])
					{
						free_digit[j] = false;
						cur->key[5] = j + 1;
						return true;
					}
				}


			}
		}

		/* WHAT IS FUNCTION, IS 3AM */
		free_digit[cur->key[3] - 1] = true;

		for(i = cur->key[1]; i < 6; i++)
		{
			if(free_digit[i])
			{
				free_digit[cur->key[1] - 1] = true;
				cur->key[1] = i + 1;
				free_digit[i] = false;

				/* Bind cur->key[3] */
				unsigned j;

				for(j = 0; j < 6; j++)
				{
					if(free_digit[j])
					{
						free_digit[j] = false;
						cur->key[3] = j + 1;
						break;
					}
				}

				/* and 4 */
				for(j = 0; j < 6; j++)
				{
					if(free_digit[j])
					{
						free_digit[j] = false;
						cur->key[4] = j + 1;
						break;
					}
				}

				/* and 5 */
				for(j = 0; j < 6; j++)
				{
					if(free_digit[j])
					{
						free_digit[j] = false;
						cur->key[5] = j + 1;
						return true;
					}
				}
				
			}
		}

		return false;

	}
}

int main(int argc, char* argv[])
{
	struct solution root;
	memset(&root, 0, sizeof(struct solution));
	bool first = true;

	/* KEY LIMITS:
	 * p[0] to p[5] are 1-6
	 * p[6] = '-'
	 * p[7], p[8] computed based off p[0] to p[5], 0-9
	 *
	 * SYSTEM OF EQNS:
	 * p[0] + p[1] = p[3] + p[4]
	 * p[1] + p[2] = p[4] + p[5]
	 * 
	 * p[7] or p[8] rule:
	 * if p[8] is NULL, p[8] = 0
	 * floor((p[0] + p[2] + p[3] + 2*p[4] + p[5]) / 2) = p[7] + 8*p[8]
	 */

	/* The first two "rules" can be treated as an underdetermined system of
	 * equations. The equations share p[1] and p[4], so we bind them first.
	 * BINDING ORDER: p[1], p[4], p[3], p[0], p[5], p[2] */
	struct solution *cur = &root, *prev = NULL;
	while(true)
	{
		cur->has_null = false;
		if(prev == NULL)
		{
			prev = cur;
		}
		else if(cur != prev)
		{
			memcpy(cur, prev, sizeof(struct solution));
			prev = cur;
		}
		/* Increment and overflow, check for repeats */

		if(!next_valid_soln(cur, first))
			exit(0);

		//printf("Genned X%dX%d%d%d\n", cur->key[1], cur->key[3], cur->key[4], cur->key[5]);

		cur->key[0] = cur->key[3] + cur->key[4] - cur->key[1];
		if(cur->key[0] <= 0 || cur->key[0] > 6)
			continue;

		/* Check 0 no-repeats vs {1,4,3,5}*/
		unsigned idx_1[4] = {1,4,3,5};
		unsigned i, inv = 0;
		for(i = 0; i < 4; i++)
		{
			if(cur->key[0] == cur->key[idx_1[i]])
			{
				inv = 1;
				break;
			}
		}
		if(inv == 1)
		{
			continue;
		}
	
		cur->key[2] = cur->key[4] + cur->key[5] - cur->key[1];
		if(cur->key[2] <= 0 || cur->key[2] > 6)
			continue;

		/* Check 2 no-repeats */
		unsigned idx_2[5] = {1,4,3,5,0};
		for(i = 0; i < 5; i++)
		{
			if(cur->key[2] == cur->key[idx_2[i]])
			{
				inv = 1;
				break;
			}
		}

		if(inv == 1)
		{
			continue;
		}
		/* If we've gotten this far, we can generate a valid solution */

		int div = (cur->key[0] + cur->key[2] + cur->key[3] + 
			2*cur->key[4] +cur->key[5]) / 2;

		cur->key[6] = div % 10;
		cur->key[7] = div / 10;

		/* Copy the solution to a 'fake' to use for next */
		struct solution *next = reinterpret_cast<struct solution*>(malloc(sizeof(struct solution)));
		memcpy(next, cur, sizeof(struct solution));
		prev = cur;
		cur->next =next;
		cur = next;

		printf("%d%d%d%d%d%d-%d", cur->key[0], cur->key[1],
			cur->key[2], cur->key[3], cur->key[4], cur->key[5], cur->key[6]);

		if(cur->key[7] == 0)
		{
			printf("%d\n", cur->key[7]);

			printf("%d%d%d%d%d%d-%d\n", cur->key[0], cur->key[1],
				cur->key[2], cur->key[3], cur->key[4], cur->key[5], cur->key[6]);
		}
		else
			printf("%d\n", cur->key[7]);
	}

	/* Never reached */
	return 0;
}

