from datetime import datetime, date, time 
import os
import subprocess as sub

def bruteforce(appname,ii):
  
  print("\n\n")
  log =[]

  cmd = [appname,"%d" %(ii)]
  log.append(cmd)
  log.append("\nProgram started \n")
  start = datetime.now() 
  log.append(start)
  print "Program started " 
  print start
  p = sub.Popen(cmd,stdout=sub.PIPE,stderr=sub.PIPE)
  output, errors = p.communicate()
  print output
  log.append(output)
  log.append("\nProgram ended \n")
  stop = datetime.now() 
  print "Program started (reprint)" 
  print start
  print "Program ended " 
  print stop
  log.append(stop)
  straux = "program was running for"
  log.append("\n%s\n" %(straux))
  print straux 
  straux =  "[0x%x] running time = %s \n" %(ii,stop-start)
  print straux
  log.append(straux)

  return(log)


def fullpara_group_01(fname = "summary_selected.log",\
vlist = [2,7,9,11,13,14,15,18,19,21,23,26,28,29,30,31,32,35,36,38,39,40,41,43,45,46,47,49,50,51,52,55,56,57,58,59,57,58,59,60,62,63]):
  appname = "./bkey04"
  for ii in vlist:     
    log=bruteforce(appname,ii) 
    f = open(fname,"a")
    for ele in log:
      f.write("%s" %(ele))
    f.close()
  

def fullpara_group_02(fname = "summary_selected.log",\
vlist = [0,1,3,4,5,6,8,10,12,14,16,17,20,22,23,24,25,27,28,33,34,37,40,42,44,45,48,50,53,54,56,60,61]):
  appname = "./bkey03"
  for ii in vlist:     
    log=bruteforce(appname,ii) 
    f = open(fname,"a")
    for ele in log:
      f.write("%s" %(ele))
    f.close()

"""
Similar to bkey03 but no recursion
"""
def fullpara_group_03(fname = "summary_selected.log",\
vlist = [0,1,3,4,5,6,8,10,12,14,16,17,20,22,23,24,25,27,28,33,34,37,40,42,44,45,48,50,53,54,56,60,61]):  
  appname = "./bkey04_vector"
  for ii in vlist:     
    log=bruteforce(appname,ii) 
    f = open(fname,"a")
    for ele in log:
      f.write("%s" %(ele))
    f.close()

 
def running_comp(fname):

 fresults  = fname #"timecomp.dat"
 #vlist = [0,1,3,4,5,6,11,14,50]
 vlist = [1,3,6,11,14, 23, 28, 40, 45, 50, 56, 60] 
 fullpara_group_02(fresults,vlist)
 fullpara_group_03(fresults,vlist)
 fullpara_group_01(fresults,vlist)



"""
"""
def search_print_missing():
  vlist = [2,7,9,11,13,14,15,18,19,21,23,26,28,29,30,31,32,35,36,38,39,40,41,43,45,46,47,49,50,51,52,55,56,57,58,59,57,58,59,60,62,63]
  vlist = vlist + [0,1,3,4,5,6,8,10,12,14,16,17,20,22,23,24,25,27,28,33,34,37,40,42,44,45,48,50,53,54,56,60,61] 
  
  print vlist
  for ii in range(0,64):
    if not(ii  in vlist):
      print "missing value %d" %(ii)


def search_print_repeated(): 
  vlist04 = [2,7,9,11,13,14,15,18,19,21,23,26,28,29,30,31,32,35,36,38,39,40,41,43,45,46,47,49,50,51,52,55,56,57,58,59,57,58,59,60,62,63]
  vlist03 = [0,1,3,4,5,6,8,10,12,14,16,17,20,22,23,24,25,27,28,33,34,37,40,42,44,45,48,50,53,54,56,60,61] 
  
  for ele in vlist04:
    if (ele in vlist03):
      print "repeated value value %d" %(ele)
 
 
if __name__ == "__main__":
  search_print_missing()
  search_print_repeated()
  
  fresults= "fulltimelogg_bkey04.log"
  fullpara_group_01(fresults)
  fresults= "fulltimelogg_bkey03.log"
  fullpara_group_02(fresults)
  fresults= "timecomp.dat"
  running_comp(fresults)





"""
1. Buscar y asociar los valores que me faltan para la 
   generaci'on de la table grande

2. comparacion de timepo de ejecucion para diferentes algoritmos
"""
