/*
 joder , se comio cuatro minutos m'as que con el 03.
 no siempre precalcular todo es tan fantasticos
*/

#include<stdio.h>


typedef struct {
  unsigned char len;
  unsigned char valcharp1lst[30];
} mem_t;

unsigned char resvect[65];
char usedvect[65];

mem_t dlvlas[65];

mem_t itermem[65];


unsigned char done = 0;


unsigned char  blcalcs(unsigned char actual){
 unsigned char bl ;
 unsigned char al ;

 bl = 0; 
 al = actual;
 
 if ( al < 0x10 ){ 
   bl = bl | 0x03;
   if ( al < 0x08 ){ 
     bl = bl | 0x0c;
   }
 }
 
 if ( al >= 0x30 ){ 
   bl = bl | 0xc0;
   if ( al >= 0x38 ){ 
     bl = bl | 0x30;
   }
 }

 switch (al%8){
    case 0:
      bl = bl | 0x41;
    case 1:
      bl = bl | 0x14;
     break;
   
    case 2:
    case 3:
    case 4:
    case 5:
      bl = bl;
     break;
     
    case 6:
      bl = bl | 0x28;
     break;
    case 7:
      bl = bl | 0x82; /* Me parece que esto es raro */
      bl = bl | 0x28; 
     break;  
    default:
      printf("blcalc Error");
 }
 
 bl = bl ^ 0xff;
 return(bl);
}

unsigned char dlcalcsrev(unsigned char actual, 
                         unsigned char bl,
			 unsigned char *valcharp1lst){
 unsigned char ii = 0;
 char aux ;
 
 if ((bl&0x01) !=0 ) {
   aux = (actual-17)&0x0ff;
   if ( aux <= 0x3f) {
     valcharp1lst[ii++] = aux;
   }
 }
 
 if ((bl&0x02) !=0 ) {
   aux = (actual-15)&0x0ff;
   if ( aux <= 0x3f) {
     valcharp1lst[ii++] = aux;
   }
 }
 
 if ((bl&0x04) !=0 ) {
   aux = (actual-10)&0x0ff;
   if ( aux <= 0x3f) {
     valcharp1lst[ii++] = aux;
   }
 }

 if ((bl&0x08) !=0 ) {
   aux = (actual-6)&0x0ff;
   if ( aux <= 0x3f) {
     valcharp1lst[ii++] = aux;
   }
 }

 if ((bl&0x10) !=0 ) {
   aux = (actual+6)&0x0ff;
   if ( aux <= 0x3f) {
     valcharp1lst[ii++] = aux;
   }
 }

 if ((bl&0x20) !=0 ) {
   aux = (actual+10)&0x0ff;
   if ( aux <= 0x3f) {
     valcharp1lst[ii++] = aux;
   }
 }

 if ((bl&0x40) !=0 ) {
   aux = (actual+15)&0x0ff;
   if ( aux <= 0x3f) {
     valcharp1lst[ii++] = aux;
   }
 }

 if ((bl&0x80) !=0 ) {
   aux = (actual+17)&0x0ff;
   if ( aux <= 0x3f) {
     valcharp1lst[ii++] = aux;
   }
 } 
 return(ii);
}


/**
  *
  */
unsigned char searchnext_localnextlst(unsigned char actual,unsigned char itercount){
  //unsigned char bl;
  //unsigned char valcharp1lst[30];
  unsigned char counter; 
  unsigned char found;
  unsigned char lenvallist;
  unsigned char nextval;
  unsigned char ii;

  unsigned char newlen;
  
  resvect[itercount] = actual;
  usedvect[actual]= actual;
    
  if (itercount>62) {
     done = 1;  
     printf("---+++---+++---+++ done! +++---+++---+++--- ]\n");
     return(0);
  } else {
    found = 0;
    counter = 0; 
    lenvallist = dlvlas[actual].len;
    
    newlen = 0;
    for (ii=0; ii < lenvallist; ii++) { 
       nextval = dlvlas[actual].valcharp1lst[ii];
       if (usedvect[nextval] == -1) {
           itermem[actual].valcharp1lst[newlen++] = nextval; 
       }
    }
    itermem[actual].len=newlen;
    
    //printf("1. counter = %d and %d \n",counter,lenvallist);
    while ((counter < newlen) && (found == 0)) { 
       nextval = itermem[actual].valcharp1lst[counter];
      
       if (searchnext_localnextlst(nextval,itercount+1)== 0){
	     found = 1;
       } else {
         if (itercount>61) {
           for (ii=0; ii <itercount;ii++){
	    printf("0x%x, ",resvect[ii]);
	   }  
	    printf("\n\n");
         }
         counter = counter + 1;
       }

	
/*       if ( (usedvect[nextval] == -1) &&
            (searchnext_localnextlst(nextval,itercount+1)== 0)){
	  found = 1;
       } else {
	  counter = counter + 1;
       }
       */
    }/*while*/
    if (found == 0) {
      usedvect[actual] = -1;
      return(-1);
    } else {
      return(0);
    }
  }

}



/*

typedef struct {
  unsigned char len;
  unsigned char valcharp1lst[30];
} mem_t;

*/


int main  (int argc, char *argv[]){
  unsigned char ii,jj;
  unsigned char bl;
  unsigned char valcharp1lst[30];
  
  unsigned char  searchValue;
  
  searchValue = atoi(argv[1]);
  printf("  ----- Search Value %2d = 0x%X-----\n",searchValue,searchValue);
  
  for (ii=0; ii<64; ii++){
    usedvect[ii]= -1;
    bl = blcalcs(ii); 
    dlvlas[ii].len= dlcalcsrev(ii,bl,dlvlas[ii].valcharp1lst);
  }  
 
  for (ii=0; ii<64; ii++){
    itermem[ii].len = 0;
    for (jj=0; jj<30; jj++){
      itermem[ii].valcharp1lst[jj] = 0 ;
    }  
  }  
 
  // dump the content of the precomputed dl vals
  for (ii=0; ii<64; ii++){
    printf("[0x%X]\tlength = %d ",ii,dlvlas[ii].len);
    for (jj=0; jj <dlvlas[ii].len; jj++){
      printf(" 0x%X",dlvlas[ii].valcharp1lst[jj]);
    }
    printf("\n");
  }
    
  searchnext_localnextlst(searchValue,0);

  printf("String %d = [",searchValue);
  for (ii = 0 ; ii<64; ii++){
    printf("0x%X , ",resvect[ii]); 
  }
  printf("]\n");
  return(0);
}
