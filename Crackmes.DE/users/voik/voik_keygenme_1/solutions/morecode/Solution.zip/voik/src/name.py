from bitops import ROR, ROL


"""
"""
def username_trans_01(userstr):
  ecx = 0 
  edx = 0
  eax = len(userstr)
  if (eax >= 4):
    for vchar in userstr:
        al = ord(vchar)
        dl = (0x000000ff&edx)
        dl = dl ^ al
        edx = (edx&0xffffff00)|(0x000000ff&dl)
        cl = 8
        while ( cl>0 ):
           cf = edx& 0x00000001
           edx = (edx>>1) & 0xffffffff 
           if ( cf == 1 ):
              edx = edx ^ 0xEDB88320
           cl = cl -1
  return(edx)


"""
edx : from username_trans_01 
dword_403014 : string from serial trans 2
"""
def username_trans_02(value):
  edx = (value << 0x1a) & 0xffffffff 
  edx = ROL(edx,6,32)
  edx = edx ^ 0x3f
  al = 0x000000ff & edx
  return(al)  
  

"""
"""
def username_trans_02_simple(value):
  edx = (value &0x3f) ^ 0x3f  
  al = 0x000000ff & edx
  return(al)  



def username_trans_02_reverse(al):
  value = (al ^ 0x3f) & 0x3f
  return(value)  


"""
   calling to automatic test routines
"""
def test_all_main():


 userstr = "angangueo"
 edx =  username_trans_01(userstr)
 print "name = %s -> %X" %(userstr,edx) 

 
 al1 = username_trans_02(edx)
 print "username trans 2 = 0x%X => 0x%X" %(edx,al1)
 al2 = username_trans_02_simple(edx)
 print "username trans 2 = 0x%X => 0x%X" %(edx,al2)







if __name__ == "__main__":
  test_all_main()
