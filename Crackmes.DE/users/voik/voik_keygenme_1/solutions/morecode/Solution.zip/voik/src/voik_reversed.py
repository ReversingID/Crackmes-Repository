from bitops import ROR, ROL
from name import username_trans_01, username_trans_02
from serial import serialTrans_01, serialTrans_02
from finalchecks import final_checks_01

userstr = "angangueo"
serial="0D4976F32E29EB4FAFD7FBBDDEDCF9ABBC6B726B22A198DD9D61CD5C655F3844E478F14B05028046068961220231B870"

edx =  username_trans_01(userstr)
al = username_trans_02(edx)
print "name = %s -> %X -> al = 0x%X" %(userstr,edx,al) 

lpAddress = [0]*0x30 
lpAddress=serialTrans_01(serial,lpAddress)

dword_403014 = [0]*0x40
dword_403014 = serialTrans_02(lpAddress,dword_403014)

print dword_403014[0]
if (dword_403014[0] == al):
   final_checks_01(dword_403014)
else:
  print "Generated seed from name does not match first element if transformed serial-> error"
