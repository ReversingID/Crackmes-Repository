
"""

"""
def ROR(x, n, bits = 32):
    mask = (2L**n) - 1
    mask_bits = x & mask
    return (x >> n) | (mask_bits << (bits - n))

"""

"""
def ROL(x, n, bits = 32):
    return ROR(x, bits - n)


def main_test():
  inlist  = [ 0x01       ,0x02 ,0xffffffff]
  outlist = [ 0x80000000 ,0x01 ,0xffffffff]
  
  ii = 0
  for value in inlist:
     res = ROR(value,1,32)
     print " value = %X resu = %X expected = %X" %(value,res,outlist[ii])
     ii = ii + 1

  ii = 0
  for value in outlist:
     res = ROL(value,1,32)
     print " value = %X resu = %X expected = %X" %(value,res,inlist[ii])
     ii = ii + 1



if __name__ == "__main__":
    main_test()
