from bitops import ROR, ROL


"""
"""
def dumpHexvector(msg,vector):
   strem = []
   print ("%s" %(msg))
   for ele in vector:
      aux = "%X" %(ele)
      if (len(aux)==1):
        aux = '0'+aux
  
      strem.append("0x"+aux)
   print strem 


"""
from hex character to hex value
"""  
def sub_chr2Hexval(bval):
  if (bval>=0x30) and (bval<=0x39):
      bval = bval - 0x30
  if (bval>=0x41) and (bval<=0x46):
      bval = bval - 0x37
  if (bval>=0x61) and (bval<=0x66):
      bval = bval - 0x57
  return (bval)
  

def sub_chr2Hexval_test():  
  bvallist    = ['0','1','9','a','b','f','A','B','F']
  bvallistres = [0,1,9,0x0a,0x0b,0x0f,0x0A,0x0B,0x0F]
  ii = 0 
  error = 0
  while (ii < len(bvallist)): 
    retval = sub_chr2Hexval(ord(bvallist[ii]))    
    if ( retval != bvallistres[ii]):
      error = 1
      print "error. Value does not match !!!!"
      print "%d .-original value %s retval = %X ==> expected %X " %(ii,bvallist[ii], retval,bvallistres[ii]) 
    
    ii = ii + 1   
  if (error == 0):
    print "OK!!!!!"
     

"""
From the Serial string chars generate hexadecimal values in byte format
"""    
def serialTrans_01(lpString,lpAddress):
  ecx = 0x30
  edi = 0
  esi = 0  
  while (ecx>0) : 
    eax = 0 
    al  = ord(lpString[esi])
    esi = esi + 1
    eax = sub_chr2Hexval(al)
    eax = eax << 8

    al  = ord(lpString[esi])  
    esi = esi + 1
    aux = sub_chr2Hexval(al)
    
    al = 0x000000ff & aux 
    al = al << 4
    eax = (eax&0xffffff00)|(0x000000ff&al)
    eax = eax >> 4
    
    lpAddress[edi] = eax 
    edi = edi + 1
    ecx = ecx - 1 
  return(lpAddress)


"""
"""
def serialTrans_01_test(lpString,lpAddressExpected):
 
  lpAddress = [0]*0x30 
  print "%4d : lpString : %s" %(len(lpString),lpString)  
  lpAddress = serialTrans_01(lpString,lpAddress)
  dumpHexvector("%4d : lpAddress : " %(len(lpAddress)),lpAddress)
   
  ii = 0
  while (ii<len(lpAddress)):
    if (lpAddress[ii] != lpAddressExpected[ii]):
       print "- + - + - + - + - + - + "
       print " Error %x != %x !!!!" %(lpAddress[ii],lpAddressExpected[ii]) 
       print "- + - + - + - + - + - + "     
    ii = ii + 1


"""
"""    
def serialTrans_02(lpAddress,dword_403014):
  ecx = 0x10;
  esi = 0
  edi = 0
  while (ecx>0):
    eax = 0 
    al = lpAddress[esi]
    esi = esi + 1
    eax = (eax&0xffffff00)|(0x000000ff&al)
    eax = eax << 8
    al = lpAddress[esi]
    esi = esi + 1
    eax = (eax&0xffffff00)|(0x000000ff&al)
    eax = eax << 8
    al = lpAddress[esi]
    esi = esi + 1
    eax = (eax&0xffffff00)|(0x000000ff&al)
    eax = ROL(eax,0x0E,32)
    dword_403014[edi] = 0x000000ff & eax
    edi = edi + 1
    al = 0
    eax = (eax&0xffffff00)|(0x000000ff&al)
    eax = ROL(eax,0x06,32)
    dword_403014[edi] = 0x000000ff & eax
    edi = edi + 1
    al = 0
    eax = (eax&0xffffff00)|(0x000000ff&al)
    eax = ROL(eax,0x06,32)
    dword_403014[edi] = 0x000000ff & eax
    edi = edi + 1
    al = 0
    eax = (eax&0xffffff00)|(0x000000ff&al)
    eax = ROL(eax,0x06,32)
    dword_403014[edi] = 0x000000ff & eax
    edi = edi + 1
    ecx = ecx - 1 
  return(dword_403014)



"""
"""
def serialTrans_02_test():
  lpAddress            = [0x12,0x34,0x56,0x78,0x90,0xAB,0xCD,0xEF,0x12,0x34,0x56,0x78,0x90,0xAB,0xCD,0xEF,0x12,0x34,0x56,0x78,0x90,0xAB,0xCD,0xEF,0x12,0x34,0x56,0x78,0x90,0xAB,0xCD,0xEF,0x12,0x34,0x56,0x78,0x90,0x12,0x34,0x56,0x78,0x90,0x12,0x34,0x56,0x78,0x90,0x0AB]  
  dword_403014Expected = [0x04,0x23,0x11,0x16,0x1E,0x09,0x02,0x2B,0x33,0x1E,0x3C,0x12,0x0D,0x05,0x19,0x38,0x24,0x0A,0x2F,0x0D,0x3B,0x31,0x08,0x34,0x15,0x27,0x22,0x10,0x2A,0x3C,0x37,0x2F,0x04,0x23,0x11,0x16,0x1E,0x09,0x02,0x2B,0x33,0x1E,0x3C,0x12,0x0D,0x05,0x19,0x38,0x24,0x01,0x08,0x34,0x15,0x27,0x22,0x10,0x04,0x23,0x11,0x16,0x1E,0x09,0x02,0x2B,0x00]
  dword_403014 = [0]*0x40

  dword_403014 = serialTrans_02(lpAddress,dword_403014) 
  #print dword_403014


  ii = 0
  while (ii<len(dword_403014)):
    if (dword_403014[ii] != dword_403014Expected[ii]):
       print "- + - + - + - + - + - + "
       print " %d Error %x != %x !!!!" %(ii, dword_403014[ii],dword_403014Expected[ii]) 
       print "- + - + - + - + - + - + "     
    ii = ii + 1


"""
"""
def serialTrans_02_reverse(strin):
  strout = []
  ii = 0 
  i = 0 
  #itera = 0
  while (ii < 64):
    aux = 0x00000000
    aux = aux | strin[ii+3]
    aux = ROR(aux,0x06,32)     
    aux = aux | strin[ii+2]
    aux = ROR(aux,0x06,32)     
    aux = aux | strin[ii+1]
    aux = ROR(aux,0x06,32)     
    aux = aux | strin[ii]
    aux = ROR(aux,0x0E,32)     
  
    strout.append( (aux>>16) & 0x000000ff)    
    strout.append( (aux>>8) & 0x000000ff )
    strout.append( (aux) & 0x000000ff)
    i = i + 3
    ii = ii + 4
  return(strout)
  


"""

"""
def serialTrans_02_reverse_test():

  strin = [0x03,0x0D,0x17,0x21,0x30,0x3F,0x2E,0x1D,0x0C,0x02,0x0C,0x16,0x20,0x2F,0x1E,0x0D,0x03,0x0D,0x17,0x21,0x30,0x3F,0x2E,0x1D,0x0C,0x02,0x0C,0x16,0x20,0x2F,0x1E,0x0D,0x03,0x0D,0x17,0x21,0x30,0x3F,0x2E,0x1D,0x0C,0x02,0x0C,0x16,0x20,0x2F,0x1E,0x0D,0x03,0x0D,0x17,0x21,0x30,0x3F,0x2E,0x1D,0x0C,0x02,0x0C,0x16,0x20,0x2F,0x1E,0x0D]

  strout = serialTrans_02_reverse(strin) 
  dumpHexvector("Input serial:", strin)
  dumpHexvector("Transformed serial:",strout)      
  st=[]
  for ele in strout:
    aux = "%X" %(ele)
    if (len(aux)==1):
      aux = '0'+aux
    st.append(aux)
  print ''.join(st)
  
  print " End Recovered Frame"
   
   

"""
   calling to automatic test routines
"""
def test_all_main():

 funame = sub_chr2Hexval_test
 print "|-------- Running %s --------|" %(funame.func_name)
 funame()
 
 funame = serialTrans_01_test
 print "|-------- Running %s --------|" %(funame.func_name)
 lpString =  "0CD0CD0CD0CD0CD0CD0CD0CD0CD0CD0CD0CD0CD0CD0CD0CD0CD0CD0CD0CD0CD0CD0CD0CD0CD0CD0CD0CD0CD0CD0CD0CD"
 lpAddressExpected =  [0x0C,0xD0,0xCD,0x0C,0xD0,0xCD,0x0C,0xD0,0xCD,0x0C,0xD0,0xCD,0x0C,0xD0,0xCD,0x0C,0xD0,0xCD,0x0C,0xD0,0xCD,0x0C,0xD0,0xCD,0x0C,0xD0,0xCD,0x0C,0xD0,0xCD,0x0C,0xD0,0xCD,0x0C,0xD0,0xCD,0x0C,0xD0,0xCD,0x0C,0xD0,0xCD,0x0C,0xD0,0xCD,0x0C,0xD0,0xCD]
 funame(lpString,lpAddressExpected)
 
 lpString  = "1234567890abcdef1234567890ABCDEF1234567890ABCDEF1234567890abcdef123456789012345678901234567890ab"
 lpAddressExpected = [0x12,0x34,0x56,0x78,0x90,0xAB,0xCD,0xEF,0x12,0x34,0x56,0x78,0x90,0xAB,0xCD,0xEF,0x12,0x34,0x56,0x78,0x90,0xAB,0xCD,0xEF,0x12,0x34,0x56,0x78,0x90,0xAB,0xCD,0xEF,0x12,0x34,0x56,0x78,0x90,0x12,0x34,0x56,0x78,0x90,0x12,0x34,0x56,0x78,0x90,0xAB]  
 funame(lpString,lpAddressExpected)
 
 funame = serialTrans_02_test
 print "|-------- Running %s --------|" %(funame.func_name)
 funame()

 funame = serialTrans_02_reverse_test
 print "|-------- Running %s --------|" %(funame.func_name)
 funame()


if __name__ == "__main__":
  test_all_main()
