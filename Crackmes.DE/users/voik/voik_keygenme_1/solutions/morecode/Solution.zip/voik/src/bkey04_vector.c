/*
  hemos cambiado el while por do while y el limite los hemos pasado 
  desde el final hasta cero, aunque parece que mejora de 39 minutos a 
  12, puede ser circunstancial, no podemos asegurar nada ya que 
  depende de en que posicion se encuentre la busqueda, 
  si el valor deseado se encuentra por el final, claramente lo 
  encontraremos mucho antes
  Anima de cojones que tan s'olo tarde 12 minutos.....
*/

#include<stdio.h>
typedef struct {
  unsigned char actual;
  unsigned char len;
  unsigned char li;
  unsigned char valcharp1lst[30];
} mem_t;

//unsigned char resvect[65];
char usedvect[65];

mem_t dlvlas[65];
mem_t itermem[65];

mem_t resvect[65]; 

unsigned char done = 0;


unsigned char  blcalcs(unsigned char actual){
 unsigned char bl ;
 unsigned char al ;

 bl = 0; 
 al = actual;
 
 if ( al < 0x10 ){ 
   bl = bl | 0x03;
   if ( al < 0x08 ){ 
     bl = bl | 0x0c;
   }
 }
 
 if ( al >= 0x30 ){ 
   bl = bl | 0xc0;
   if ( al >= 0x38 ){ 
     bl = bl | 0x30;
   }
 }

 switch (al%8){
    case 0:
      bl = bl | 0x41;
    case 1:
      bl = bl | 0x14;
     break;
   
    case 2:
    case 3:
    case 4:
    case 5:
      bl = bl;
     break;
     
    case 6:
      bl = bl | 0x28;
     break;
    case 7:
      bl = bl | 0x82; /* Me parece que esto es raro */
      bl = bl | 0x28; 
     break;  
    default:
      printf("blcalc Error");
 }
 
 bl = bl ^ 0xff;
 return(bl);
}

unsigned char dlcalcsrev(unsigned char actual, 
                         unsigned char bl,
			 unsigned char *valcharp1lst){
 unsigned char ii = 0;
 char aux ;
 
 if ((bl&0x01) !=0 ) {
   aux = (actual-17)&0x0ff;
   if ( aux <= 0x3f) {
     valcharp1lst[ii++] = aux;
   }
 }
 
 if ((bl&0x02) !=0 ) {
   aux = (actual-15)&0x0ff;
   if ( aux <= 0x3f) {
     valcharp1lst[ii++] = aux;
   }
 }
 
 if ((bl&0x04) !=0 ) {
   aux = (actual-10)&0x0ff;
   if ( aux <= 0x3f) {
     valcharp1lst[ii++] = aux;
   }
 }

 if ((bl&0x08) !=0 ) {
   aux = (actual-6)&0x0ff;
   if ( aux <= 0x3f) {
     valcharp1lst[ii++] = aux;
   }
 }

 if ((bl&0x10) !=0 ) {
   aux = (actual+6)&0x0ff;
   if ( aux <= 0x3f) {
     valcharp1lst[ii++] = aux;
   }
 }

 if ((bl&0x20) !=0 ) {
   aux = (actual+10)&0x0ff;
   if ( aux <= 0x3f) {
     valcharp1lst[ii++] = aux;
   }
 }

 if ((bl&0x40) !=0 ) {
   aux = (actual+15)&0x0ff;
   if ( aux <= 0x3f) {
     valcharp1lst[ii++] = aux;
   }
 }

 if ((bl&0x80) !=0 ) {
   aux = (actual+17)&0x0ff;
   if ( aux <= 0x3f) {
     valcharp1lst[ii++] = aux;
   }
 } 
 return(ii);
}



/**
  *
  */
unsigned char searchnext_localnextlst(mem_t actual){
  
  char counter; 
  unsigned char found;
  unsigned char lenvallist;
  mem_t nextval;
  unsigned char ii;
  unsigned char itercount;

  itercount = 0; 
  resvect[itercount] = actual;
  
  while (itercount < 63) {  
      // chech that the next value is not used if used, move to the next value
      actual = resvect[itercount];     
      while ((actual.li<actual.len) && 
         usedvect[actual.valcharp1lst[actual.li]] !=-1){
	 actual.li++;     
      }
      if (actual.li == actual.len) {
         // all of the values were already used. 
         if ( itercount > 0 ) {	   
           usedvect[actual.actual]=-1; 
           itercount = itercount -1;
	   resvect[itercount].li++;
         } else {
           printf ("Got bck to 0! do not how could that happend.");
	   return(-1);
         }

      } else {
        resvect[itercount] = actual;            // store modifications in the register
        usedvect[actual.actual]= actual.actual; // search register update
	itercount++;
        resvect[itercount]= itermem[actual.valcharp1lst[actual.li]];
        resvect[itercount].li = 0;
      }       
  }/*while not done loop*/

}


int main( int argc, char *argv[]){
  unsigned char ii,jj;
  unsigned char bl;
  unsigned char valcharp1lst[30];
  unsigned char found ;  
  unsigned char searchValue;
  mem_t actual; 
 
  if (argc < 2){
    printf ("Missing argument !!!\n");   
    return(-1);
  }
  searchValue = atoi(argv[1]);
  if (searchValue > 63){
    printf ("value out of range!!!\n");
    return(-1);
  }  
  printf("  ----- Search Value %2d = 0x%X-----\n",searchValue,searchValue);
  
  for (ii=0; ii<64; ii++){
    usedvect[ii]= -1;
    bl = blcalcs(ii); 
    dlvlas[ii].len= dlcalcsrev(ii,bl,dlvlas[ii].valcharp1lst);
  }  
 
  /* initialization of the memory*/
  for (ii=0; ii<64; ii++){
    itermem[ii].len = 0;
    itermem[ii].li = 0;
    itermem[ii].actual = ii;
    for (jj=0; jj<30; jj++){
      itermem[ii].valcharp1lst[jj] = 0 ;
    }  
  }  
  
  // dump the content of the precomputed dl vals
  for (ii=0; ii<64; ii++){
    //printf("[0x%X]\tlength = %d ",ii,dlvlas[ii].len);
    itermem[ii].len = dlvlas[ii].len;
    for (jj=0; jj <dlvlas[ii].len; jj++){
      itermem[ii].valcharp1lst[jj] = dlvlas[ii].valcharp1lst[jj];
      //printf(" 0x%X",dlvlas[ii].valcharp1lst[jj]);
    }
    //printf("\n");
  }
 
  actual = itermem[searchValue];
  searchnext_localnextlst(actual);

  printf("String %d = [",searchValue);
  for (ii = 0 ; ii<64; ii++){
    printf("0x%X , ",resvect[ii].actual); 
  }
  printf("]\n");
  return(0);
}
