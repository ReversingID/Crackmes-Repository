I don't know how difficult it is, but i believe it's not easy.
This is my first KeygenMe.

Your task: Keygen it!

Have fun! ;)