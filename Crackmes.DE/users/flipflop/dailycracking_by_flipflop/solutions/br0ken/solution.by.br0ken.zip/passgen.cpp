#include <stdio.h>
#include <time.h>
#include <conio.h>
int main ()
{
  time_t raw;
  struct tm * time_INF;
  char buffer [80];
  printf("Pass generator for flipflop coded by br0ken.\n\n\n");
  time (&raw);
  time_INF = localtime (&raw);

  strftime (buffer,80,"The generated password is = Crack%d",time_INF);
  puts (buffer);
  printf("\n\nNOTE\n****");
  printf("\n\n1. This pass is valid for today only! Run the passgen tomorrow\n   to get tomorrow's valid pass.\n");
  printf("\n2. To see the goodboy you need to run the cme from the commandline.");
  printf("\n\nPress anykey to quit.");
  getch();
  return 0;
}