#include "windows.h"

LRESULT CALLBACK WndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
bool KeyGen(char * name, char * serial);
HWND hName, hSerial, hButton;

int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{

	WNDCLASSEX wc;
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.cbClsExtra = NULL;
	wc.cbWndExtra = NULL;
	wc.hbrBackground = (HBRUSH)1;
	wc.hIcon = LoadIcon(NULL,IDI_WINLOGO);
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);

	wc.hIconSm = NULL;
	wc.hInstance = hInstance;
	wc.lpfnWndProc = WndProc;
	wc.lpszClassName = "KeyGenClass";
	wc.lpszMenuName = NULL;
	wc.style  = CS_HREDRAW | CS_VREDRAW;

	RegisterClassEx(&wc);

	HWND hwnd = CreateWindowEx(WS_EX_OVERLAPPEDWINDOW,
							   "KeyGenClass", "5mIn Keygen",
							    WS_VISIBLE|WS_SYSMENU|WS_CLIPSIBLINGS|WS_CAPTION, 
								250,150, 
								140, 130, 
								NULL,NULL, 
								hInstance, NULL);

	ShowWindow(hwnd, SW_SHOWNORMAL);
	UpdateWindow(hwnd);
	
	while(1)
	{
	MSG uMsg;
	if(!GetMessage(&uMsg,NULL,0,0))
		break;
	TranslateMessage(&uMsg);
	DispatchMessage(&uMsg);
	}
return 0;

}
//-------------------------------------------------------------------------------------------

LRESULT CALLBACK WndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if(uMsg == WM_DESTROY)
		PostQuitMessage(NULL);
	else if(uMsg == WM_CREATE)
	{
		hName   = CreateWindowEx(WS_EX_CLIENTEDGE,"EDIT","Name (>=12 chars)", WS_CHILDWINDOW|ES_AUTOHSCROLL|WS_VISIBLE,  0, 0,130,20,hwnd,NULL,NULL,0);
		hSerial = CreateWindowEx(WS_EX_CLIENTEDGE,"EDIT","Serial", WS_CHILDWINDOW|ES_READONLY|WS_VISIBLE,0,30,130,20,hwnd,NULL,NULL,0); 
		hButton = CreateWindowEx(WS_EX_CLIENTEDGE,"BUTTON","Gen", WS_CHILDWINDOW|WS_VISIBLE, 40, 60, 50,30,hwnd,NULL,NULL,0); 
	}
	else if(uMsg == WM_COMMAND)
	{
		if((HIWORD(wParam) == EN_CHANGE && lParam == (int)hName) || (HIWORD(wParam) == BN_CLICKED && lParam==(int)hButton))
		{
			char name[13], serial[15];
			GetWindowText(hName,name,13);
			if(!KeyGen(name, serial))
				strcpy(serial, "Name is short");
			SetWindowText(hSerial,serial);
		}

	}
	else
		return DefWindowProc(hwnd,uMsg,wParam,lParam);
}
//------------------------------------------------------------------------------------

bool KeyGen(char * name, char* serial)
{

unsigned char char_before, char_after = 0;
int added, to_add;

if(lstrlen(name) < 12)		// Name is too short ?
	return false;		

strcpy(serial,name);	// copy name to serial (step 1)

do
{
	for(int i = 11; i >= 4; i--)	// change 4-11 chars
	{
		char_before = serial[i];	// step 2
		char_after  = char_before + (unsigned char)(rand()&0xF); // add random number (step 3)
		if(char_after > 'z')	// if we get overflow
			char_after = char_after - 0x5B; // get rid of overflow
		
		to_add  = char_before ^ char_after;		// step 4
		added = serial[i-4] + to_add;			// step 5
		if(added < ' ' || added > 'z')	// is it good character
		{
			continue;	// we get invalid char, skip it
		}
		else
		{
			serial[i-4] = added;	
			serial[i] = char_after;	// step 6
		}
	}
}
while(!strcmp(name,serial));	// if Name=Serial, repeat
return true;
}