My first cm... A bit original(I hope so). Na packers/protectors, 1 easy anti-debug protection.
rules:
-find password -> "Well done :)"
-no patching


Hope you enjoy :)