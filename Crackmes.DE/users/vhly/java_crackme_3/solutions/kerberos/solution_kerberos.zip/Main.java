package keygen3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.security.NoSuchAlgorithmException;
import java.util.Date;
import java.util.GregorianCalendar;

import java.util.zip.CRC32;
import java.security.MessageDigest;
import sun.misc.BASE64Encoder;

/**
 *
 * @author Kerberos
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    static void caseJ(int j,MessageDigest messagedigest){
        switch(j % 3) {
            case 0:
                messagedigest.update("Email is What? \"vhly@163.com is Right!\",So YOu Can Only Make a KeyGen".getBytes());
                break;
                
            case 1:
                messagedigest.update("I love YoU , My Girls, HAHaaaaa!".getBytes());
                break;
                
            case 2:
                messagedigest.update("GivE a Right Reason, I Think this CrackMe 's Serial is Ofen change for A Name".getBytes());
                break;
        }
    }
    /**
     * @param args the command line arguments
     */
    static void caseK(int k,MessageDigest messagedigest){
        switch(k % 5) {
            case 0:
                messagedigest.update("Good Luck For Writer".getBytes());
                break;
                
            case 1:
                messagedigest.update("Foikd This is Very EasY?".getBytes());
                break;
                
            case 2:
                messagedigest.update("The Day is g\\ook/risse.x-> vhly".getBytes());
                break;
                
            case 3:
                messagedigest.update("No ONe Can sToP mE!ARe You".getBytes());
                break;
                
            case 4:
                messagedigest.update("Thank you for CraCK This :)".getBytes());
                break;
        }
    }
    
    public static void main(String[] args) {
        BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(System.in));
        Date date = new Date();
        String name;
        
        try{
            System.out.print("Enter your name : ");
            name = bufferedreader.readLine();
        }catch(IOException e){
            System.err.println("There is some error with your input stream");
            name = "Kerberos";
        }
        //start of console serial code generation
        MessageDigest messagedigest=null;
        try{
            messagedigest = MessageDigest.getInstance("MD5");
        }catch(NoSuchAlgorithmException ex){
            System.err.println("Your system doesn't know anything abou MD5 ... you're using Windows, rigth? :))");
        }
        
        int k,j,i = date.getYear() + 1900;
        j = date.getMonth() + 1;
        k = date.getDate();
        
        caseK(k, messagedigest);
        caseJ(j,messagedigest);
        char acc[] = name.toCharArray();
        char c = '\0';
        c = (char)(0x20 + (k % 4));
        
        for(int l = 0; l < acc.length; l++){
            acc[l] ^= c;
        }
        
        messagedigest.update(new String(acc).getBytes());
        BASE64Encoder base64encoder = new BASE64Encoder();
        StringBuffer b = new StringBuffer(base64encoder.encode(messagedigest.digest())).reverse();
        System.out.println("Console password : " + b);

        // start of GUI serial code generation
        String s1 = (new StringBuilder()).append("VHLY IS ").append(name).append(" The World 's Kid").toString();
        
        char ac[] = s1.toCharArray();
        
        i = date.getDate();
        
        c = 'A';
        if(i % 6 == 3)
            c ^= 'G';
        else
            c ^= 's';
        
        for(j = 0; j < ac.length; j++)
            ac[j] ^= c;
        
        
        String t1 = new String(ac);
        CRC32 crc32 = new CRC32();
        crc32.update(t1.getBytes());
        
        long l = crc32.getValue()-834L;
        
        System.out.println("GUI password : "+Long.toString(l, 36));
    }
    
}
