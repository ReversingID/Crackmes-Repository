package keygen;

import java.io.*;
import java.util.zip.CRC32;
import java.security.MessageDigest;
/**
 * Keygen
 * @author Kerberos
 */
public class Main {  
    /** Creates a new instance of Main */
    public Main() {
    }
    
    public static void main(String[] args) {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String text="";
        
        System.out.print("Name : ");
        try{
            text = br.readLine();
        }catch(IOException e){
            System.out.println("There is same error ... ");
        }
        
        byte array[]=null;
        try {
            MessageDigest messagedigest = MessageDigest.getInstance("MD5");
            messagedigest.update(("vhly[FR]"+text).getBytes());
            array= messagedigest.digest();
        } catch(Exception exception) { }
        
        CRC32 crc32 = new CRC32();
        crc32.update(array);
        long l = crc32.getValue();
        
        System.out.println("Serial: "+Long.toString(l, 36));
    }
   
}
