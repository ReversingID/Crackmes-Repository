package org.ebfe.cm.vhlycm4;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.zip.CRC32;
import sun.misc.BASE64Encoder;

public class Keygen {

	private static final String magic = "vhly[FR]'s CrackMe #4 KeyFile";
	private String name;
	private String serial;
	private long   crc;
	private Object keyfile;
	
	public Keygen(String name) throws Exception {
		this.name = name;
		this.serial = generateSerial();
		this.crc = calcCRC();
		this.keyfile = generateKeyFile();
	}
	
	private Object generateKeyFile() 
		throws ClassNotFoundException, InstantiationException, 
		        IllegalAccessException, InvocationTargetException {
		/* this code might look a bit strange, but as at compile time
		 * the KeyFile class is still crypted and i didnt want to 
		 * extract/modify the crackme classes, i use reflection here
		 */
		Class c = Class.forName("com.vhly.crackmes.cm4.KeyFile");
		Object o = c.newInstance();
		Method meths[] = c.getMethods();
		
		for(Method m : meths) {
			String mname = m.getName();
			
			if("setName".equals(mname)) {
				m.invoke(o, this.name);
			} else if("setSerial".equals(mname)) {
				m.invoke(o, this.serial);
			} else if("setCRC".equals(mname)) {
				m.invoke(o, this.crc);
			}
		}
		
		return o;
	}

	private String generateSerial() throws NoSuchAlgorithmException {
		StringBuilder sb = new StringBuilder();
		
		sb.append("aAF#@QRAJSEFjkaos0dvjkl;asefQ$@#%@Q$T%Jmoa0pl_)(*&(^*%^%$  ");
	        sb.append(name);
		sb.append("    asdfjkl;asdfQ#$TSHSDFHGSdfgjkopasdu90zxcv");
		sb = sb.reverse();
			
		MessageDigest md = MessageDigest.getInstance("SHA-1");
		md.update(sb.toString().getBytes());

		BASE64Encoder b64enc = new BASE64Encoder();
	        return b64enc.encodeBuffer(md.digest());
	}

	private long calcCRC() {
	        CRC32 crc32 = new CRC32();
		crc32.update(magic.getBytes());
		crc32.update(name.getBytes());
	        crc32.update(serial.getBytes());
	        return crc32.getValue();
	}
	
	public void writeKeyFile(File file) throws IOException {
		FileOutputStream fo = new FileOutputStream(file);
		ObjectOutputStream os = new ObjectOutputStream(fo);
		os.writeObject(this.keyfile);
		os.flush();
		os.close();
	}

	public String getName() {
		return name;
	}

	public String getSerial() {
		return serial;
	}

	public long getCrc() {
		return crc;
	}
}
