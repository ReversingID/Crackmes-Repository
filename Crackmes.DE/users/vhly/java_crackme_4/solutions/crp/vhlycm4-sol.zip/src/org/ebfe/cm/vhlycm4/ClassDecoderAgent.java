package org.ebfe.cm.vhlycm4;

import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.IllegalClassFormatException;
import java.lang.instrument.Instrumentation;
import java.security.ProtectionDomain;

public class ClassDecoderAgent implements ClassFileTransformer {
	private static final boolean DEBUG = false;
	private static boolean loaded = false;
	
	public static void premain(String args, Instrumentation instr) {
		ClassDecoderAgent.loaded = true;
		log("premain()");
		ClassFileTransformer cft = new ClassDecoderAgent();
		instr.addTransformer(cft);
	}

	public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer) throws IllegalClassFormatException {
		log("transform(" + className +")");
		if(className.startsWith("com/vhly/crackmes/cm4")) {
			log("decode: " + className);
			byte newClass[] = new byte[classfileBuffer.length];
			for (int i = 0; i < classfileBuffer.length; i++) {
				newClass[i] = (byte)((int)classfileBuffer[i] ^ 0xa8 ^ 0x63);
			}
			return newClass;
		} 
		return null;
	}
	
	private static void log(String s) {
		if(DEBUG)
			System.out.println(s);
	}

	public static boolean isLoaded() {
		return loaded;
	}
}
