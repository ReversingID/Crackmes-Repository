package org.ebfe.cm.vhlycm4;

public class RunKeygen {
	
	public static void main(String[] args) {
		if(ClassDecoderAgent.isLoaded()) {
			KeygenUI ui = new KeygenUI();
			ui.setDefaultCloseOperation(KeygenUI.EXIT_ON_CLOSE);
			ui.setVisible(true);
		} else {
			System.err.println("ClassDecoderAgent not loaded");
		}
	}
}
