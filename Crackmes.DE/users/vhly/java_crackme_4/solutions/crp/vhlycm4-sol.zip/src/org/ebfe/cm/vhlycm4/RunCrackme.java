package org.ebfe.cm.vhlycm4;

public class RunCrackme {
	
	public static void main(String args[]) throws Exception {
		/* just instanciate it... this requires that the deocder agent is loaded */
		if(ClassDecoderAgent.isLoaded()) {
			Class c = Class.forName("com.vhly.crackmes.cm4.Main");
			Object o = c.newInstance(); 
		} else {
			System.err.println("ClassDecoderAgent not loaded");
		}
	}
	
}
