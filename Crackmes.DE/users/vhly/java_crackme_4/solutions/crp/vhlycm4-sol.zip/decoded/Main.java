// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Main.java

package com.vhly.crackmes.cm4;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import javax.swing.*;

// Referenced classes of package com.vhly.crackmes.cm4:
//            KeyFile

public class Main extends JFrame
    implements ActionListener
{

    public Main()
    {
        super("Java CrackMe #4 by vhly[FR]");
        setDefaultCloseOperation(3);
        Container container = getContentPane();
        container.setLayout(new BorderLayout());
        JPanel jpanel = new JPanel();
        jpanel.setLayout(new FlowLayout());
        lblFile = new JLabel("License File:");
        txtFile = new JTextField(20);
        btnOpen = new JButton("...");
        btnOpen.addActionListener(this);
        jpanel.add(lblFile);
        jpanel.add(txtFile);
        jpanel.add(btnOpen);
        container.add(jpanel, "North");
        lblResult = new JLabel("                 UnRegister!");
        container.add(lblResult, "South");
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension dimension = toolkit.getScreenSize();
        int i = (int)dimension.getWidth();
        int j = (int)dimension.getHeight();
        pack();
        int k = (int)getSize().getWidth();
        int l = (int)getSize().getHeight();
        i = i / 2 - k / 2;
        j = j / 2 - l / 2;
        setLocation(i, j);
        setResizable(false);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent actionevent)
    {
        JFileChooser jfilechooser = new JFileChooser(new File("."));
        int i = jfilechooser.showOpenDialog(this);
        if(i == 0)
        {
            txtFile.setText(jfilechooser.getSelectedFile().getPath());
            try
            {
                FileInputStream fileinputstream = new FileInputStream(jfilechooser.getSelectedFile().getPath());
                ObjectInputStream objectinputstream = new ObjectInputStream(fileinputstream);
                KeyFile keyfile = (KeyFile)objectinputstream.readObject();
                if(keyfile.isVal())
                    lblResult.setText("                 Registed to " + keyfile.getName());
                else
                    lblResult.setText("                 UnRegisted!");
                keyfile = null;
                objectinputstream.close();
                fileinputstream.close();
            }
            catch(Exception exception)
            {
                lblResult.setText("                 UnRegisted!");
                exception.printStackTrace();
                return;
            }
        }
    }

    public static void main(String args[])
        throws Exception
    {
        JFrame.setDefaultLookAndFeelDecorated(true);
        SwingUtilities.invokeLater(new Runnable() {

            public void run()
            {
                Main main1 = new Main();
            }

        });
    }

    private JLabel lblFile;
    private JTextField txtFile;
    private JButton btnOpen;
    private JLabel lblResult;
}
