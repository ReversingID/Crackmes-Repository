// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   KeyFile.java

package com.vhly.crackmes.cm4;

import java.io.Serializable;
import java.security.MessageDigest;
import java.util.zip.CRC32;
import sun.misc.BASE64Encoder;

public class KeyFile
    implements Serializable
{

    public KeyFile()
    {
        magic = "vhly[FR]'s CrackMe #4 KeyFile";
        name = "vhly[FR]";
        serial = "null";
        crcvalue = 0L;
    }

    public final String getName()
    {
        return name;
    }

    public final void setName(String s)
    {
        name = s;
    }

    public final void setSerial(String s)
    {
        serial = s;
    }

    public final void setCRC(long l)
    {
        crcvalue = l;
    }

    public final boolean isVal()
    {
        String s;
        CRC32 crc32 = new CRC32();
        crc32.update(magic.getBytes());
        crc32.update(name.getBytes());
        crc32.update(serial.getBytes());
        long l = crc32.getValue();
        crc32 = null;
        if(l != crcvalue)
            return false;
        StringBuffer stringbuffer = new StringBuffer();
        stringbuffer.append("aAF#@QRAJSEFjkaos0dvjkl;asefQ$@#%@Q$T%Jmoa0pl_)(*&(^*%^%$");
        stringbuffer.append("  ");
        stringbuffer.append(name);
        stringbuffer.append("    asdfjkl;asdfQ#$TSHSDFHGSdfgjkopasdu90zxcv");
        StringBuffer stringbuffer1 = stringbuffer.reverse();
        stringbuffer = null;
        s = stringbuffer1.toString();
        stringbuffer1 = null;
        String s1;
        MessageDigest messagedigest = MessageDigest.getInstance("SHA-1");
        messagedigest.update(s.getBytes());
        byte abyte0[] = messagedigest.digest();
        messagedigest = null;
        BASE64Encoder base64encoder = new BASE64Encoder();
        s1 = base64encoder.encodeBuffer(abyte0);
        base64encoder = null;
        Exception exception;
        return s1.equals(serial);
        exception;
        return false;
    }

    private String magic;
    private String name;
    private String serial;
    private long crcvalue;
}
