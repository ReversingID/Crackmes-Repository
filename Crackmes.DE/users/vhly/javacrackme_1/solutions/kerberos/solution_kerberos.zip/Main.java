/*
 * Main.java
 *
 * Created on 9. leden 2006, 21:41
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package keygen;

import sun.misc.BASE64Encoder;
import java.io.*;

/**
 *
 * @author Kerberos
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));        
        byte array[] = new byte[300];
        String text="";
          
        System.out.print("Name : ");        
        try{
            //System.in.read(array);            
            text = br.readLine();
        }catch(IOException e){
            System.out.println("There is same error ... ");
        }
    
        BASE64Encoder base64encoder = new BASE64Encoder();
        String s3 = base64encoder.encode(text.getBytes());
        System.out.println("Serial : "+s3);                
    }
    
}
