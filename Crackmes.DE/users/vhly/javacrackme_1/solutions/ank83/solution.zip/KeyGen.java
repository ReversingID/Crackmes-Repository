import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import sun.misc.BASE64Encoder;

public class KeyGen extends JFrame implements ActionListener
{
	public KeyGen()
	{
		super("KeyGen by Ank83");
		Container container = getContentPane();
		getContentPane().setLayout(null);
		Name.setBounds(5, 5, 80, 20);
		addActionListener.setBounds(90, 5, 150, 20);
		Serial.setBounds(5, 30, 80, 20);
		SerialT.setBounds(90, 30, 150, 20);
		Gen.setBounds(5, 60, 90, 30);
		Gen.addActionListener(this);
		Exit.setBounds(150, 60, 90, 30);
		Exit.addActionListener(this);
		container.add(Name);
		container.add(addActionListener);
		container.add(Serial);
		container.add(SerialT);
		container.add(Gen);
		container.add(Exit);
		setDefaultCloseOperation(3);
		setSize(255, 130);
		setLocation(200, 100);
		setVisible(true);
	}
	
	public final void actionPerformed(ActionEvent actionevent)
	{
		String s = actionevent.getActionCommand();
        		if(s.equals("Exit"))
        		{
			setVisible(false);
            		System.exit(0);
        		} 
        		else
        		if(s.equals("Generate"))
        		{
            		String s1 = addActionListener.getText();
            		String s2 = SerialT.getText();
            		if(s1 == null)
                			return;
            		if(s2 == null)
                		return;
            		if(s1.length() <= 3)
            		{
                			JOptionPane.showMessageDialog(this, "Enter a name longer that 3 chars !");
                			return;
            		}
            		BASE64Encoder base64encoder = new BASE64Encoder();
            		String s3 = base64encoder.encode(s1.getBytes());
            		SerialT.setText(s3);
        		}
    	}



    	public static final void main(String args[])
    	{
        		KeyGen key = new KeyGen();
    	}

    	private static JLabel Name = new JLabel("Name: ");
    	private static JLabel Serial = new JLabel("Serial: ");
    	private static JTextField addActionListener = new JTextField();
    	private static JTextField SerialT = new JTextField();
    	private static JButton Gen = new JButton("Generate");
    	private static JButton Exit = new JButton("Exit");
}