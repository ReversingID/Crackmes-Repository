2003-12-20

Welcome in my third crackme, I called The PowerPuff Girls,
it's not hard, maybe just long and a little bit time-consuming.
rules of the game:
make keygen, no cheating.

If you have any comments/solutions mail me at cyberbobpl@tlen.pl
Good luck, cyberbob 

greets:
	cybult, ryba, tomkol, WiteG, Spanska
---