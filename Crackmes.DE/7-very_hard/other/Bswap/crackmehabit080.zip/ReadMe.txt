Crackme Habit 0.80 notes,
 
Goal : Try to find the right combination to unlock the code,
And make the box say "Registered" difficulty about (7/10).

I can not say much about it, I can say one thing when you are 
able to unlock it you are addicted to cracking ! 
In the first regbox (Key no 1) you only have to look for numbers
(0 - 9), however the second regbox (Key no 2) it needs ASCII
(from 32 (dec) = space to 122 (dec) = z).

The source is included however it's protected your unlock key
will be the key 2.
Example ( key no 2 = ABCDEFGHIJ12 you unlock code
Will be: ABCDEFGHIJ12 ).


And the usual disclaimer:
Whatever happens when you running this program, 
I'm not responsible for anything.  
  
If you have any comment or questions please mail,

goodwill80@hotmail.com

I want to greet everyone who knows me.

Cybult , Blue Mind, Detten , Tomkol , ^L00P , Iczelion , Kwasek, 
Harlequin, Thigo, Roy, muaddib and Zero.

Bswap.
Holland - 2003
