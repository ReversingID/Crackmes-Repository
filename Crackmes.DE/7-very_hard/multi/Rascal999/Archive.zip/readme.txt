crackme - The file to be decrypted ;)
enc - The file that encrypts/decrypts files

Challenge: Decrypt the encoded message

Limits: None! Do what you want. Use anything.

Updates:

v2 06/07/08:

-UNLIMITED passwords can be used to encrypt messages (sorta)
-Passwords are now strings (characters and numbers can be used)
-Comma issue fixed (line input)
-Excessive messages or passwords can lead to
impossibility of decryption (not sure why), don't go mad

v1:

-Encrypt was written in FreeBASIC
-Two passwords are required to decrypt the message
-The passwords can only be integers
-When encrypting (not sure why), don't use commas(,)
It terminates the put

If you want encrypt.bas, email me!

Good luck (you won't be able to do it)