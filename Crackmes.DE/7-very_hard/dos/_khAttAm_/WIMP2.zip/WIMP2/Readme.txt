_khAttAm_'s What is my Password 2
---------------------------------
(6/23/2005)

"_khAttAm_'s What is my password 2" is out. 

Like version 1, it is very difficult to crack. 

With much more programming (2 x 4 hrs, I think), I have made this crackme very-very difficult to crack. 

This should be very-very difficult, if not impossible. I will rate it 7-8 out of 10. And that is too high for a serial-only 16-Bit application, isn't it?

If you think you are good at finding passwords/serials, you should try this one.

And No Patching Please. A valid working password/serial is needed.

Best of Luck..........

Note: If you are trying to run it on XP with Ntfs, it may not run. To run it, you may need to copy it to the root Directory, eg c:\

