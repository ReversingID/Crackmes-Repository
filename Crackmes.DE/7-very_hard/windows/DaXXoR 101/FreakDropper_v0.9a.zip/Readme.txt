Packed with my own monster :: FreakDropper v0.9a

Note: almost all crackers will get a validation error running this exe, that is because it checks for installations of cracking tools as well as if they are running.

-DaX