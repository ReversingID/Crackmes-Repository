crackme - The file to be decrypted ;)
encrypt.exe - The file that encrypts/decrypts files

Challenge: Decrypt the encoded message

Limits: None! Do what you want. Use anything.

Notes:

-Encrypt was written in FreeBASIC
-Two passwords are required to decrypt the message
-The passwords can only be INTEGERS and a maximum of 9 digits
-When encrypting (not sure why), don't use commas(,)
It terminates the put

If you want encrypt.bas, email me!

Good luck (you won't be able to do it)

You may use this for domestic use if you want. It's pretty secure
and I only count on brute-force being able to crack it. Prove me
wrong?

Executable for distribution ONLY.