		-----------------------------------------------------------
     			Zrobione dla Think Devise Hack (TDHack.com)
               			przez aTahualpa
		-----------------------------------------------------------



	Napisa�em sw�j w�asny program do szyfrowania wiadomo�ci!
Mo�esz dzi�ki niemu ukry� swoje tajne informacje �eby nikt nieupowa�niony nie mia� do nich dost�pu. Nazwa�em go "Program szyfruj�cy"



----Jak to dzia�a?
	Wiadomo�� do zaszyfrowania nale�y wpisa� do pliku "plaintext.txt" nast�pnie odpali� program.
Zostaniesz poproszony o podanie dw�ch liczb, z kt�rych powstanie specjalny klucz do szyfrowania twojej wiadomo�ci.
Koniecznie zapami�taj te liczby i nikomu ich nie pokazuj! Bez nich nie odszyfrujesz wiadomo�ci spowrotem!
Kiedy podasz liczby program zaszyfruje i zapisze wiadomo�� w pliku "ciphertext.txt"




----Jaki szyfr jest wykorzystywany przez Program szyfruj�cy?
	To moja tejemnica ;) Nie jest to �aden ze znanych szyfr�w historycznych. Ale ma zwi�zek z pewnym zagadnieniem matematycznym.




----Jak rozszyfrowa� wiadomo��?
	To proste, wystarczy w Programie dekoduj�cym wpisa� klucz, kt�ry zosta� u�yty przy szyfrowaniu. Jeszcze nie napisa�em programu dekoduj�cego ale zabiore si� za to w najbli�szym czasie.





			### CHANGELOG ###

v. 1.0 (12.09.2007)
-Pierwsza wersja programu.
-Wymyslenie i stworzenie algorytmu szyfruj�cego.

v. 1.1 (13.09.2007)
-Dodano mo�liwo�� generowania w�asnych kluczy.
-Dodano wczytywanie i zapisywanie wiadomo�ci z/do pliku tekstowego.
-Kosmetyczne zmiany.
-Podej�cie do stworzenia programu deszyfruj�cego.

v. 1.2 (15.09.2007)
Podw�jna katastrofa! :(
-Ca�kowicie nieudana pr�ba napisania deszyfratora. Le�y to poza moimi umiej�tno�ciami. W takim razie odkodowaniem wiadomo�ci musi zaj�� si� u�ytkownik
-Majstrowa�em przy zapisywaniu zaszyfrowanej wiadomo�ci i co� zepsu�em :( I teraz program szyfruje wiadomo�� ale nigdzie jej nie zapisuje :( Straszna rzecz! Nie wiem jak z tym sobie poradzi�.







U�ytkowniku TDHack.com! Sam sobie nie poradz� z napisaniem Programu deszyfruj�cego. 
Napisz taki program a w zamian dam Ci has�o na strone. Jest ono w pliku zadanie.txt.
Zakodowane tym programem oczywi�cie :)
Powodzenia!






